<?php
/**
 * Library ERP System - Main Entry Point
 * Version: 20.3 - Enhanced Staff Profile Display (Bigger Photos, Unified Design)
 * Full 3-language support (English, Hindi, Arabic).
 * UNIFIED COLOR SYSTEM: Uses system colors from settings.php (Primary, Secondary, Tertiary, Accent)
 * STAFF PHOTOS: Larger 100px size, 20% border-radius, GIF support, consistent across login and index
 */
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php_errors.log');
date_default_timezone_set(@date_default_timezone_get() ?: 'UTC');

session_start();
define('ROOT_PATH', __DIR__);

require_once ROOT_PATH . '/config/db.php';
require_once ROOT_PATH . '/config/functions.php';

// ==================== MULTI-LANGUAGE SYSTEM ====================
$availableLanguages = ['en', 'hi', 'ar'];
$defaultLanguage = 'en';

if (isset($_GET['lang']) && in_array($_GET['lang'], $availableLanguages)) {
    $_SESSION['lang'] = $_GET['lang'];
}
$lang = $_SESSION['lang'] ?? $defaultLanguage;

// ==================== SYSTEM COLOR SETTINGS ====================
$settings = getSettings();

// System Colors (from General tab) - UNIFIED
$systemPrimaryColor = $settings['system_primary_color'] ?? '#1e3c72';
$systemSecondaryColor = $settings['system_secondary_color'] ?? '#2a5298';
$systemTertiaryColor = $settings['system_tertiary_color'] ?? '#e8c547';
$systemAccentColor = $settings['system_accent_color'] ?? '#d96846';

// Report colors (for reports only)
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

$translations = [
    'en' => [
        // General
        'welcome' => 'Welcome To',
        'subtitle' => 'Complete Library Management Solution With Ease',
        'staff_login' => 'Staff Login',
        'username' => 'Username',
        'password' => 'Password',
        'login' => 'Login',
        'secure_login' => 'Secure Login With',
        'timeout_msg' => 'Your Session Timed Out. Please Log In Again.',
        'invalid_credentials' => 'Invalid Username Or Password',
        'login_failed' => 'Login Failed: ',
        'no_staff_profiles' => 'No Staff Profiles Configured. Please Go To <strong>Admin → Staff Profiles</strong> To Add Librarians And Staff.',
        'logout' => 'Logout',
        'my_profile' => 'My Profile',
        'member_portal' => 'Member Portal',
        'footer_copyright' => 'All Rights Reserved.',
        'maintenance_title' => 'Maintenance Mode',
        'maintenance_body' => 'We Are Currently Performing Scheduled Maintenance. Please Check Back Later.',
        'greeting_morning' => 'Good Morning',
        'greeting_afternoon' => 'Good Afternoon',
        'greeting_evening' => 'Good Evening',
        'today_is' => 'Today Is',
        'time' => 'Time',
        'visitors_inside' => 'Currently Inside',
        'total_members' => 'Total Members',
        'total_books' => 'Total Books',
        'currently_issued' => 'Currently Issued',
        'overdue_books' => 'Overdue Books',
        'ebooks_available' => 'eBooks Available',
        'pending_reservations' => 'Pending Reservations',
        'upcoming_events' => 'Upcoming Events',
        'fines_today' => 'Fines Collected Today',
        'quick_actions' => 'Quick Actions',
        'no_quick_actions' => 'No Quick Actions Defined. Please Add Some In <a href="admin/quick_actions.php">Quick Actions Manager</a>.',
        'issue_book' => 'Issue Book',
        'issue_desc' => 'Scan Member & Book Barcode',
        'return_book' => 'Return Book',
        'return_desc' => 'Process Returns & Fines',
        'renew' => 'Renew',
        'renew_desc' => 'Extend Due Dates',
        'overdue' => 'Overdue',
        'overdue_desc' => 'View Overdue Items',
        'computer_access' => 'Computer Access',
        'computer_desc' => 'Manage PC Bookings',
        'ebooks' => 'eBooks',
        'ebooks_desc' => 'Digital Collection',
        'utilities' => 'Utilities Suite',
        'utilities_desc' => 'Tools & Helpers',
        'serial_control' => 'Serial Control',
        'serial_desc' => 'Manage Periodicals',
        'backup_restore' => 'Backup & Restore',
        'backup_desc' => 'Data Safety',
        'reports' => 'Reports',
        'reports_desc' => 'Generate Statistics',
        'settings' => 'Settings',
        'settings_desc' => 'System Configuration',
        'quick_access' => 'Quick Access',
        'dark' => 'Dark',
        'light' => 'Light',
        'toggle_sidebar' => 'Toggle Sidebar',
        'hide_sidebar'   => 'Hide Sidebar',
        'show_sidebar'   => 'Show Sidebar',
        'statistics'     => 'Statistics',
        'circulation' => 'Circulation',
        'pay_fines' => 'Pay Fines',
        'pay_fines_desc' => 'Member Fine Payments',

        // Role‑based tool labels
        'hide_tools' => 'Hide %s Tools',
        'show_tools' => 'Show %s Tools',
        'admin_tools' => 'Admin',
        'librarian_tools' => 'Librarian',
        'staff_tools' => 'Staff',

        // Sidebar
        'Main' => 'Main',
        'Admin Dashboard' => 'Dashboard',
        'Circulation' => 'Circulation',
        'Members' => 'Members',
        'Books' => 'Books',
        'eBooks' => 'eBooks',
        'Research' => 'Research',
        'Research Databases' => 'Research Databases',
        'Acquisitions & Serials' => 'Acquisitions & Serials',
        'Acquisitions' => 'Acquisitions',
        'Serials Control' => 'Serials Control',
        'Administration' => 'Administration',
        'System Settings' => 'System Settings',
        'Quick Actions Manager' => 'Quick Actions Manager',
        'Loan Rules' => 'Loan Rules',
        'Staff Profiles' => 'Staff Profiles',
        'Manage Notices' => 'Manage Notices',
        'Suggestions' => 'Suggestions',
        'Fine Rates' => 'Fine Rates',
        'Backup & Restore' => 'Backup & Restore',
        'Utilities Suite' => 'Utilities Suite',
        'Stock Verification' => 'Stock Verification',
        'Lost & Damaged' => 'Lost & Damaged',
        'Payments' => 'Payments',
        'Reservations' => 'Reservations',
        'Library Events' => 'Library Events',
        'Member Documents' => 'Member Documents',
        'Computer Access' => 'Computer Access',
        'Data Import' => 'Data Import',
        'Entry/Exit' => 'Entry/Exit',
        'Session Logs' => 'Session Logs',
        'Communication' => 'Communication',
        'Bulk Messaging' => 'Bulk Messaging',
        'Chatbot' => 'Chatbot',
        'Reports & Analytics' => 'Reports & Analytics',
        'Reports' => 'Reports',
        'Advanced Analytics' => 'Advanced Analytics',
        'Cron' => 'Cron',
        'Public Interfaces' => 'Public Interfaces',
        'OPAC' => 'OPAC',
        'Digital Library Hub' => 'Digital Library Hub',
        'Self Kiosk' => 'Self Kiosk',
        'Member Portal' => 'Member Portal',
        'Multi‑Library' => 'Multi‑Library',
        'Institutions' => 'Institutions',
        'API' => 'API',
        'REST API' => 'REST API',
        'Account' => 'Account',
        'Pay Fines' => 'Pay Fines',
    ],
    'hi' => [
        'welcome' => 'में आपका स्वागत है',
        'subtitle' => 'सरलता के साथ संपूर्ण पुस्तकालय प्रबंधन समाधान',
        'staff_login' => 'स्टाफ लॉगिन',
        'username' => 'उपयोगकर्ता नाम',
        'password' => 'पासवर्ड',
        'login' => 'लॉगिन',
        'secure_login' => 'सुरक्षित लॉगिन',
        'timeout_msg' => 'आपका सत्र समाप्त हो गया। कृपया पुनः लॉगिन करें।',
        'invalid_credentials' => 'उपयोगकर्ता नाम या पासवर्ड गलत है',
        'login_failed' => 'लॉगिन विफल: ',
        'no_staff_profiles' => 'कोई स्टाफ प्रोफ़ाइल कॉन्फ़िगर नहीं की गई है। कृपया <strong>प्रशासन → स्टाफ प्रोफ़ाइल</strong> पर जाकर पुस्तकालयाध्यक्षों और कर्मचारियों को जोड़ें।',
        'logout' => 'लॉगआउट',
        'my_profile' => 'मेरी प्रोफ़ाइल',
        'member_portal' => 'सदस्य पोर्टल',
        'footer_copyright' => 'सर्वाधिकार सुरक्षित।',
        'maintenance_title' => 'रखरखाव मोड',
        'maintenance_body' => 'हम वर्तमान में निर्धारित रखरखाव कर रहे हैं। कृपया बाद में वापस आएँ।',
        'greeting_morning' => 'सुप्रभात',
        'greeting_afternoon' => 'शुभ अपराह्न',
        'greeting_evening' => 'शुभ संध्या',
        'today_is' => 'आज',
        'time' => 'समय',
        'visitors_inside' => 'वर्तमान में अंदर',
        'total_members' => 'कुल सदस्य',
        'total_books' => 'कुल पुस्तकें',
        'currently_issued' => 'वर्तमान में जारी',
        'overdue_books' => 'अतिदेय पुस्तकें',
        'ebooks_available' => 'उपलब्ध ई-पुस्तकें',
        'pending_reservations' => 'लंबित आरक्षण',
        'upcoming_events' => 'आगामी कार्यक्रम',
        'fines_today' => 'आज एकत्रित जुर्माना',
        'quick_actions' => 'त्वरित क्रियाएँ',
        'no_quick_actions' => 'कोई त्वरित क्रिया परिभाषित नहीं है। कृपया <a href="admin/quick_actions.php">त्वरित क्रियाएँ प्रबंधक</a> में जोड़ें।',
        'issue_book' => 'पुस्तक जारी करें',
        'issue_desc' => 'सदस्य और पुस्तक बारकोड स्कैन करें',
        'return_book' => 'पुस्तक वापस लें',
        'return_desc' => 'वापसी और जुर्माना प्रक्रिया करें',
        'renew' => 'नवीनीकरण',
        'renew_desc' => 'देय तिथि बढ़ाएँ',
        'overdue' => 'अतिदेय',
        'overdue_desc' => 'अतिदेय आइटम देखें',
        'computer_access' => 'कंप्यूटर पहुँच',
        'computer_desc' => 'पीसी बुकिंग प्रबंधित करें',
        'ebooks' => 'ई-पुस्तकें',
        'ebooks_desc' => 'डिजिटल संग्रह',
        'utilities' => 'उपयोगिता सुइट',
        'utilities_desc' => 'उपकरण और सहायक',
        'serial_control' => 'सीरियल नियंत्रण',
        'serial_desc' => 'पत्रिकाएँ प्रबंधित करें',
        'backup_restore' => 'बैकअप और पुनर्स्थापना',
        'backup_desc' => 'डेटा सुरक्षा',
        'reports' => 'रिपोर्ट',
        'reports_desc' => 'आँकड़े उत्पन्न करें',
        'settings' => 'सेटिंग्स',
        'settings_desc' => 'सिस्टम विन्यास',
        'quick_access' => 'त्वरित पहुँच',
        'dark' => 'डार्क',
        'light' => 'लाइट',
        'toggle_sidebar' => 'साइडबार टॉगल करें',
        'hide_sidebar'   => 'साइडबार छिपाएँ',
        'show_sidebar'   => 'साइडबार दिखाएँ',
        'statistics'     => 'आँकड़े',
        'circulation' => 'परिसंचरण',
        'pay_fines' => 'जुर्माना भुगतान करें',
        'pay_fines_desc' => 'सदस्य जुर्माना भुगतान',
        'hide_tools' => '%s टूल्स छिपाएँ',
        'show_tools' => '%s टूल्स दिखाएँ',
        'admin_tools' => 'एडमिन',
        'librarian_tools' => 'लाइब्रेरियन',
        'staff_tools' => 'स्टाफ',
        'Main' => 'मुख्य',
        'Admin Dashboard' => 'डैशबोर्ड',
        'Circulation' => 'परिसंचरण',
        'Members' => 'सदस्य',
        'Books' => 'पुस्तकें',
        'eBooks' => 'ई-पुस्तकें',
        'Research' => 'अनुसंधान',
        'Research Databases' => 'अनुसंधान डेटाबेस',
        'Acquisitions & Serials' => 'अधिग्रहण और सीरियल',
        'Acquisitions' => 'अधिग्रहण',
        'Serials Control' => 'सीरियल नियंत्रण',
        'Administration' => 'प्रशासन',
        'System Settings' => 'सिस्टम सेटिंग्स',
        'Quick Actions Manager' => 'त्वरित क्रियाएँ प्रबंधक',
        'Loan Rules' => 'ऋण नियम',
        'Staff Profiles' => 'स्टाफ प्रोफ़ाइल',
        'Manage Notices' => 'सूचनाएँ प्रबंधित करें',
        'Suggestions' => 'सुझाव',
        'Fine Rates' => 'जुर्माना दरें',
        'Backup & Restore' => 'बैकअप और पुनर्स्थापना',
        'Utilities Suite' => 'उपयोगिता सुइट',
        'Stock Verification' => 'स्टॉक सत्यापन',
        'Lost & Damaged' => 'खोई हुई और क्षतिग्रस्त पुस्तकें',
        'Payments' => 'भुगतान',
        'Reservations' => 'आरक्षण',
        'Library Events' => 'पुस्तकालय कार्यक्रम',
        'Member Documents' => 'सदस्य दस्तावेज़',
        'Computer Access' => 'कंप्यूटर पहुँच',
        'Data Import' => 'डेटा आयात',
        'Entry/Exit' => 'प्रवेश/निकास',
        'Session Logs' => 'सत्र लॉग',
        'Communication' => 'संचार',
        'Bulk Messaging' => 'सामूहिक SMS/WhatsApp',
        'Chatbot' => 'पुस्तकालय चैटबॉट',
        'Reports & Analytics' => 'रिपोर्ट और विश्लेषण',
        'Reports' => 'रिपोर्ट',
        'Advanced Analytics' => 'उन्नत विश्लेषण',
        'Cron' => 'Cron',
        'Public Interfaces' => 'सार्वजनिक इंटरफ़ेस',
        'OPAC' => 'OPAC',
        'Digital Library Hub' => 'डिजिटल लाइब्रेरी हब',
        'Self Kiosk' => 'सेल्फ कियोस्क',
        'Member Portal' => 'सदस्य पोर्टल',
        'Multi‑Library' => 'बहु-पुस्तकालय',
        'Institutions' => 'संस्थान',
        'API' => 'API',
        'REST API' => 'REST API',
        'Account' => 'खाता',
        'Pay Fines' => 'जुर्माना भुगतान करें',
    ],
    'ar' => [
        'welcome' => 'مرحباً بكم في',
        'subtitle' => 'حل متكامل لإدارة المكتبات بكل سهولة',
        'staff_login' => 'تسجيل دخول الموظفين',
        'username' => 'اسم المستخدم',
        'password' => 'كلمة المرور',
        'login' => 'تسجيل الدخول',
        'secure_login' => 'تسجيل دخول آمن عبر',
        'timeout_msg' => 'انتهت مدة الجلسة. يرجى تسجيل الدخول مجدداً.',
        'invalid_credentials' => 'اسم المستخدم أو كلمة المرور غير صحيحة',
        'login_failed' => 'فشل تسجيل الدخول: ',
        'no_staff_profiles' => 'لم يتم تكوين ملفات تعريف الموظفين. يرجى الانتقال إلى <strong>الإدارة ← ملفات تعريف الموظفين</strong> لإضافة أمناء المكتبات والموظفين.',
        'logout' => 'تسجيل الخروج',
        'my_profile' => 'ملفي الشخصي',
        'member_portal' => 'بوابة الأعضاء',
        'footer_copyright' => 'جميع الحقوق محفوظة.',
        'maintenance_title' => 'وضع الصيانة',
        'maintenance_body' => 'نقوم حالياً بصيانة مجدولة. يرجى العودة لاحقاً.',
        'greeting_morning' => 'صباح الخير',
        'greeting_afternoon' => 'مساء الخير',
        'greeting_evening' => 'مساء الخير',
        'today_is' => 'اليوم هو',
        'time' => 'الوقت',
        'visitors_inside' => 'المتواجدون حالياً',
        'total_members' => 'إجمالي الأعضاء',
        'total_books' => 'إجمالي الكتب',
        'currently_issued' => 'المستعارة حالياً',
        'overdue_books' => 'الكتب المتأخرة',
        'ebooks_available' => 'الكتب الإلكترونية المتاحة',
        'pending_reservations' => 'الحجوزات المعلقة',
        'upcoming_events' => 'الفعاليات القادمة',
        'fines_today' => 'الغرامات المحصلة اليوم',
        'quick_actions' => 'الإجراءات السريعة',
        'no_quick_actions' => 'لا توجد إجراءات سريعة. يرجى إضافتها في <a href="admin/quick_actions.php">مدير الإجراءات السريعة</a>.',
        'issue_book' => 'إعارة كتاب',
        'issue_desc' => 'مسح باركود العضو والكتاب',
        'return_book' => 'إرجاع كتاب',
        'return_desc' => 'معالجة الإرجاع والغرامات',
        'renew' => 'تجديد',
        'renew_desc' => 'تمديد موعد الاستحقاق',
        'overdue' => 'متأخر',
        'overdue_desc' => 'عرض المواد المتأخرة',
        'computer_access' => 'الوصول إلى الحاسوب',
        'computer_desc' => 'إدارة حجوزات الحاسوب',
        'ebooks' => 'الكتب الإلكترونية',
        'ebooks_desc' => 'المجموعة الرقمية',
        'utilities' => 'مجموعة الأدوات',
        'utilities_desc' => 'الأدوات والمساعدات',
        'serial_control' => 'التحكم في الدوريات',
        'serial_desc' => 'إدارة الدوريات',
        'backup_restore' => 'النسخ الاحتياطي والاستعادة',
        'backup_desc' => 'أمان البيانات',
        'reports' => 'التقارير',
        'reports_desc' => 'إنشاء الإحصائيات',
        'settings' => 'الإعدادات',
        'settings_desc' => 'تكوين النظام',
        'quick_access' => 'وصول سريع',
        'dark' => 'مظلم',
        'light' => 'فاتح',
        'toggle_sidebar' => 'تبديل الشريط الجانبي',
        'hide_sidebar'   => 'إخفاء الشريط الجانبي',
        'show_sidebar'   => 'إظهار الشريط الجانبي',
        'statistics'     => 'الإحصائيات',
        'circulation' => 'الإعارة والإرجاع',
        'pay_fines' => 'دفع الغرامات',
        'pay_fines_desc' => 'مدفوعات غرامات الأعضاء',
        'hide_tools' => 'إخفاء أدوات %s',
        'show_tools' => 'إظهار أدوات %s',
        'admin_tools' => 'المشرف',
        'librarian_tools' => 'أمين المكتبة',
        'staff_tools' => 'الموظفين',
        'Main' => 'الرئيسية',
        'Admin Dashboard' => 'لوحة التحكم',
        'Circulation' => 'الإعارة والإرجاع',
        'Members' => 'الأعضاء',
        'Books' => 'الكتب',
        'eBooks' => 'الكتب الإلكترونية',
        'Research' => 'البحث العلمي',
        'Research Databases' => 'قواعد البيانات البحثية',
        'Acquisitions & Serials' => 'الاقتناء والدوريات',
        'Acquisitions' => 'الاقتناء',
        'Serials Control' => 'التحكم في الدوريات',
        'Administration' => 'الإدارة',
        'System Settings' => 'إعدادات النظام',
        'Quick Actions Manager' => 'مدير الإجراءات السريعة',
        'Loan Rules' => 'قواعد الإعارة',
        'Staff Profiles' => 'ملفات تعريف الموظفين',
        'Manage Notices' => 'إدارة الإشعارات',
        'Suggestions' => 'الاقتراحات',
        'Fine Rates' => 'أسعار الغرامات',
        'Backup & Restore' => 'النسخ الاحتياطي والاستعادة',
        'Utilities Suite' => 'مجموعة الأدوات',
        'Stock Verification' => 'جرد المخزون',
        'Lost & Damaged' => 'الكتب المفقودة والتالفة',
        'Payments' => 'المدفوعات',
        'Reservations' => 'الحجوزات',
        'Library Events' => 'فعاليات المكتبة',
        'Member Documents' => 'وثائق الأعضاء',
        'Computer Access' => 'الوصول إلى الحاسوب',
        'Data Import' => 'استيراد البيانات',
        'Entry/Exit' => 'الدخول/الخروج',
        'Session Logs' => 'سجلات الجلسات',
        'Communication' => 'التواصل',
        'Bulk Messaging' => 'رسائل جماعية SMS/WhatsApp',
        'Chatbot' => 'المساعد الآلي للمكتبة',
        'Reports & Analytics' => 'التقارير والتحليلات',
        'Reports' => 'التقارير',
        'Advanced Analytics' => 'التحليلات المتقدمة',
        'Cron' => 'المهام المجدولة Cron',
        'Public Interfaces' => 'الواجهات العامة',
        'OPAC' => 'الفهرس العام',
        'Digital Library Hub' => 'المركز الرقمي',
        'Self Kiosk' => 'الخدمة الذاتية',
        'Member Portal' => 'بوابة الأعضاء',
        'Multi‑Library' => 'المكتبات المتعددة',
        'Institutions' => 'المؤسسات',
        'API' => 'واجهة البرمجة API',
        'REST API' => 'REST API',
        'Account' => 'الحساب',
        'Pay Fines' => 'دفع الغرامات',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $key;
}

function isRTL() {
    global $lang;
    return $lang === 'ar';
}

function renderLanguageSwitcher() {
    global $lang;
    $flags = ['en' => 'English', 'hi' => 'हिन्दी', 'ar' => 'العربية'];
    $html = '<div class="dropdown d-inline-block">';
    $html .= '<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
    $html .= '<i class="fas fa-globe"></i> ' . strtoupper($lang);
    $html .= '</button>';
    $html .= '<ul class="dropdown-menu dropdown-menu-end">';
    foreach ($flags as $code => $label) {
        $active = ($code === $lang) ? ' active' : '';
        $html .= '<li><a class="dropdown-item' . $active . '" href="?lang=' . $code . '">' . $label . '</a></li>';
    }
    $html .= '</ul></div>';
    return $html;
}

// ==================== PROTECTED DESIGNER CREDIT ====================
$expectedCredit = '<div class="designer-credit">
                        <i class="fas fa-code"></i> Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer" class="designer-name">Sameermon</a>
                    </div>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedCredit) === false) {
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Integrity Violation</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:linear-gradient(135deg,#667eea,#764ba2);min-height:100vh;display:flex;align-items:center}.card{border-radius:24px}</style></head><body><div class="container"><div class="card shadow-lg mx-auto" style="max-width:450px"><div class="card-header bg-danger text-white"><h4><i class="fas fa-shield-alt"></i> System Integrity Violation</h4></div><div class="card-body text-center"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Access blocked.</p></div></div></div></body></html>';
    exit;
}

// ==================== DATABASE & SETTINGS ====================
$db = Database::getInstance()->getConnection();
if (function_exists('createModulePermissionsTable')) createModulePermissionsTable();

$settings = getSettings();
$institution = getInstitution();

// Quick actions table
if (!function_exists('initializeQuickActionsTable')) {
    function initializeQuickActionsTable($db) {
        $db->exec("CREATE TABLE IF NOT EXISTS quick_actions (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, icon_class TEXT NOT NULL, link_url TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        $stmt = $db->query("SELECT COUNT(*) FROM quick_actions");
        if ($stmt->fetchColumn() == 0) {
            $defaults = [
                ['Issue Book', 'fa-arrow-right', 'circulation/issue.php', 1],
                ['Return Book', 'fa-arrow-left', 'circulation/return.php', 2],
                ['Renew', 'fa-sync-alt', 'circulation/renew.php', 3],
                ['Overdue', 'fa-exclamation-triangle', 'circulation/overdue.php', 4],
                ['Computer Access', 'fa-desktop', 'computer_management/', 5],
                ['eBooks', 'fa-file-pdf', 'ebooks/', 6],
                ['Pay Fines', 'fa-money-bill-wave', 'payments/fine_payments.php', 7],
                ['Utilities Suite', 'fa-toolbox', 'utilities/', 8],
                ['Serial Control', 'fa-newspaper', 'serial/', 9],
                ['Backup & Restore', 'fa-database', 'admin/backup.php', 10],
                ['Reports', 'fa-chart-bar', 'reports/', 11],
                ['Settings', 'fa-cog', 'admin/settings.php', 12],
            ];
            $insert = $db->prepare("INSERT INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES (?, ?, ?, ?, 1)");
            foreach ($defaults as $item) $insert->execute($item);
        }
    }
}
try { initializeQuickActionsTable($db); } catch (Exception $e) {}

// ==================== IMPROVED LOGO HANDLING ====================
function getBase64Image($filepath) {
    if (empty($filepath)) return false;
    if (!file_exists($filepath)) return false;
    $data = @file_get_contents($filepath);
    if ($data === false) return false;
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    $mime = match($ext) { 
        'png' => 'image/png', 
        'gif' => 'image/gif', 
        'webp' => 'image/webp', 
        'svg' => 'image/svg+xml', 
        'jpg', 'jpeg' => 'image/jpeg',
        default => 'image/jpeg' 
    };
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Enhanced staff photo function with multiple path attempts - GIF support
function getStaffPhotoBase64($photoPath) {
    if (empty($photoPath)) return '';
    
    $pathsToTry = [
        $photoPath,
        ROOT_PATH . '/' . ltrim($photoPath, '/'),
        ROOT_PATH . '/uploads/staff/' . basename($photoPath),
        ROOT_PATH . '/uploads/staff/' . $photoPath,
        str_replace('uploads/staff/', ROOT_PATH . '/uploads/staff/', $photoPath)
    ];
    
    foreach ($pathsToTry as $tryPath) {
        if (!empty($tryPath) && file_exists($tryPath)) {
            $ext = strtolower(pathinfo($tryPath, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $data = @file_get_contents($tryPath);
                if ($data !== false) {
                    $mime = match($ext) {
                        'png' => 'image/png',
                        'gif' => 'image/gif',
                        'webp' => 'image/webp',
                        default => 'image/jpeg'
                    };
                    return 'data:' . $mime . ';base64,' . base64_encode($data);
                }
            }
        }
    }
    return '';
}

function getLogoUrl() {
    global $settings, $institution;
    
    // Priority 1: library_logo from general settings
    if (!empty($settings['library_logo'])) {
        $path = $settings['library_logo'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 2: opac_header_logo (fallback)
    if (!empty($settings['opac_header_logo'])) {
        $path = $settings['opac_header_logo'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 3: institution logo
    if (!empty($institution['logo_path'])) {
        $path = $institution['logo_path'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 4: common logo locations
    $commonPaths = [
        ROOT_PATH . '/SIS-logo.png',
        ROOT_PATH . '/logo.png',
        __DIR__ . '/SIS-logo.png',
        __DIR__ . '/logo.png',
        ROOT_PATH . '/uploads/logos/logo.png',
        ROOT_PATH . '/uploads/logo.png',
        ROOT_PATH . '/uploads/logos/logo.jpg',
        ROOT_PATH . '/uploads/logo.jpg',
    ];
    foreach ($commonPaths as $path) {
        if (file_exists($path)) {
            $base64 = getBase64Image($path);
            if ($base64) return $base64;
        }
    }
    
    // Priority 5: SVG fallback
    $primaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
    $colorHex = ltrim($primaryColor, '#');
    return 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="80" viewBox="0 0 200 80"%3E%3Crect width="200" height="80" fill="%23ffffff" rx="8"/%3E%3Ctext x="50%25" y="50%25" font-size="16" fill="%23' . $colorHex . '" text-anchor="middle" dy=".3em"%3E📚 Library%3C/text%3E%3C/svg%3E';
}

function getFaviconUrl() {
    global $settings;
    if (!empty($settings['favicon_path'])) {
        $path = $settings['favicon_path'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url) return $url;
        }
    }
    return '';
}

$logoData = getLogoUrl();
$faviconPath = getFaviconUrl();

// ==================== STAFF PROFILES - FIXED ====================
$staffList = [];
if (!empty($settings['staff_display_enabled'])) {
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='staff_profiles'");
    if ($tableCheck->fetch()) {
        $stmt = $db->prepare("SELECT * FROM staff_profiles WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 12");
        $stmt->execute();
        $staffList = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Process each staff member's photo individually
        foreach ($staffList as &$staff) {
            if (!empty($staff['photo_path'])) {
                $staff['photo_base64'] = getStaffPhotoBase64($staff['photo_path']);
            } else {
                $staff['photo_base64'] = '';
            }
        }
        unset($staff);
    }
}

// ==================== SESSION LIFETIME ====================
if (isset($_SESSION['user_id']) && isset($_SESSION['login_time'])) {
    $sessionLifetime = (int)($settings['session_lifetime'] ?? 7200);
    if (time() - $_SESSION['login_time'] > $sessionLifetime) {
        session_destroy();
        header("Location: index.php?timeout=1");
        exit;
    }
}

// ==================== MAINTENANCE MODE ====================
$maintenanceMode = (int)($settings['site_maintenance_mode'] ?? 0);
$maintenanceMessage = $settings['maintenance_message'] ?? __('maintenance_body');
$whitelistIps = array_map('trim', explode(',', $settings['maintenance_whitelist_ips'] ?? ''));
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
$isWhitelisted = in_array($clientIp, $whitelistIps);

if ($maintenanceMode && !isset($_SESSION['user_id']) && !$isWhitelisted) {
    header('HTTP/1.1 503 Service Unavailable');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.__('maintenance_title').'</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f8f9fa;display:flex;align-items:center;min-height:100vh}</style></head><body><div class="container text-center"><div class="card shadow-lg mx-auto" style="max-width:500px"><div class="card-header bg-warning"><h4><i class="fas fa-tools"></i> '.__('maintenance_title').'</h4></div><div class="card-body"><p class="lead">' . htmlspecialchars($maintenanceMessage) . '</p><p class="text-muted">'.__('maintenance_body').'</p></div></div></div></body></html>';
    exit;
}

// ==================== LOGIN / 2FA ====================
$authError = '';
if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $enable2fa = (int)($settings['enable_2fa'] ?? 0);
            if ($enable2fa && !empty($user['totp_secret'])) {
                $_SESSION['2fa_pending_user_id'] = $user['id'];
                $_SESSION['2fa_pending_username'] = $user['username'];
                $_SESSION['2fa_pending_fullname'] = $user['fullname'];
                $_SESSION['2fa_pending_role'] = $user['role'];
                $_SESSION['2fa_pending_secret'] = $user['totp_secret'];
                header("Location: admin/2fa_verify.php");
                exit;
            }
            completeLogin($user);
        } else {
            if (function_exists('logActivity')) logActivity($username, 'LOGIN_FAILED', 'Invalid credentials');
            $authError = __('invalid_credentials');
        }
    } catch (PDOException $e) { $authError = __('login_failed') . $e->getMessage(); }
}

function completeLogin($user) {
    global $db, $settings;
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['fullname'] = $user['fullname'];
    $_SESSION['login_time'] = time();
    $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?")->execute([$user['id']]);
    try {
        $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
        if ($tableCheck->fetch()) {
            $stmtLog = $db->prepare("INSERT INTO session_logs (user_type, username, session_id, ip_address, user_agent) VALUES ('admin', ?, ?, ?, ?)");
            $stmtLog->execute([$user['username'], session_id(), $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '']);
        }
    } catch (Exception $e) {}
    if (function_exists('logActivity')) logActivity($user['username'], 'LOGIN', 'User logged in successfully');
    header("Location: index.php");
    exit;
}

if (isset($_GET['logout'])) {
    if (isset($_SESSION['username'])) {
        try {
            $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
            if ($tableCheck->fetch()) $db->prepare("UPDATE session_logs SET logout_time = CURRENT_TIMESTAMP WHERE session_id = ? AND logout_time IS NULL")->execute([session_id()]);
        } catch (Exception $e) {}
        if (function_exists('logActivity')) logActivity($_SESSION['username'], 'LOGOUT', 'User logged out');
    }
    session_destroy();
    header("Location: index.php");
    exit;
}

// ==================== STATISTICS ====================
$stats = [];
if (isset($_SESSION['user_id'])) {
    try {
        $stats['visitors_inside'] = 0;
        $stats['total_members'] = (int) $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
        $stats['total_books'] = (int) ($db->query("SELECT SUM(quantity) FROM books")->fetchColumn() ?: 0);
        $stats['currently_issued'] = (int) $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
        $stats['overdue_books'] = (int) $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn();
        $stats['ebooks_available'] = (int) $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn();
        $stats['pending_reservations'] = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='reservations_queue'")->fetch() ? (int) $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'waiting'")->fetchColumn() : 0;
        $stats['upcoming_events'] = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='library_events'")->fetch() ? (int) $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'upcoming' AND event_date >= date('now')")->fetchColumn() : 0;
        $stats['fines_today'] = (int) $db->query("SELECT COALESCE(SUM(amount),0) FROM fine_payments WHERE date(payment_date) = date('now')")->fetchColumn();
    } catch (Exception $e) { $stats = array_fill_keys(['visitors_inside','total_members','total_books','currently_issued','overdue_books','ebooks_available','pending_reservations','upcoming_events','fines_today'], 0); }
}

$greetingKey = (function() {
    $h = (int)date('H');
    return $h < 12 ? 'greeting_morning' : ($h < 17 ? 'greeting_afternoon' : 'greeting_evening');
})();

// ==================== RENDER VIEW ====================
if (!isset($_SESSION['user_id'])) {
    // -------------------- PUBLIC LANDING PAGE --------------------
    ?>
    <!DOCTYPE html>
    <html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
        <title><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></title>
        <?php if ($faviconPath): ?>
            <link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>">
            <link rel="shortcut icon" href="<?= $faviconPath ?>">
        <?php endif; ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
        <style>
            :root {
                --primary-color: <?= $systemPrimaryColor ?>;
                --primary-light: <?= $systemPrimaryColor ?>dd;
                --primary-dark: <?= $systemPrimaryColor ?>aa;
                --primary-rgb: <?= hexdec(substr($systemPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($systemPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($systemPrimaryColor, 5, 2)) ?>;
                --gradient-primary: linear-gradient(135deg, <?= $systemPrimaryColor ?> 0%, <?= $systemSecondaryColor ?> 100%);
                --secondary-color: <?= $systemSecondaryColor ?>;
                --tertiary-color: <?= $systemTertiaryColor ?>;
                --accent-color: <?= $systemAccentColor ?>;
                --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
                --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
                --radius-card: 16px;
                --staff-img-size: 100px;
            }
            * { margin:0; padding:0; box-sizing:border-box; }
            html,body { height:100%; }
            body { font-family:'Inter',sans-serif; background:var(--gradient-primary); display:flex; flex-direction:column; overflow-y:auto; }
            body::before { content:''; position:fixed; width:200%; height:200%; top:-50%; left:-50%; background:radial-gradient(circle,rgba(255,255,255,0.05) 1%,transparent 1%); background-size:50px 50px; animation:shimmer 40s linear infinite; pointer-events:none; z-index:0; }
            @keyframes shimmer { 0%{transform:translate(0,0);} 100%{transform:translate(50px,50px);} }
            .main-container { flex:1 0 auto; width:100%; padding:20px 20px 0 20px; position:relative; z-index:2; display:flex; flex-direction:column; }
            .container { flex:1; display:flex; flex-direction:column; }
            .hero-section { flex-shrink:0; }
            .row { flex-shrink:0; }
            .footer { margin-top:auto; text-align:center; padding:20px; color:#f0f0f0; background:rgba(0,0,0,0.3); border-radius:40px; font-size:13px; backdrop-filter:blur(5px); flex-shrink:0; }
            .hero-title { font-size:2.5rem; font-weight:800; color:white; text-shadow:0 5px 20px rgba(0,0,0,0.25); margin-bottom:1rem; animation:zigzagZoomFade 1.2s cubic-bezier(0.2,0.9,0.4,1.1) forwards; white-space:nowrap; }
            @keyframes zigzagZoomFade { 0%{opacity:0;transform:translateX(-30px) scale(0.8) rotate(-2deg);letter-spacing:-2px;} 30%{opacity:0.7;transform:translateX(15px) scale(1.05) rotate(1deg);} 60%{opacity:0.9;transform:translateX(-8px) scale(0.98) rotate(-0.5deg);} 100%{opacity:1;transform:translateX(0) scale(1) rotate(0);letter-spacing:normal;} }
            @media (max-width:768px){ .hero-title{font-size:1.8rem;white-space:normal;} }
            .hero-subtitle { font-size:1.2rem; color:rgba(255,255,255,0.9); max-width:600px; margin:0 auto; opacity:0; animation:fadeInUp 0.8s ease 0.3s forwards; }
            @keyframes fadeInUp { from{opacity:0;transform:translateY(20px);} to{opacity:1;transform:translateY(0);} }
            .hero-logo { height:100px; width:auto; max-width:220px; object-fit:contain; margin-bottom:20px; filter:drop-shadow(0 8px 20px rgba(0,0,0,0.2)); animation:float 4s ease-in-out infinite; background:white; border-radius:20px; padding:12px; }
            @keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-10px);} }
            .login-card { background:rgba(255,255,255,0.98); border-radius:var(--radius-card); border:none; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); overflow:hidden; backdrop-filter:blur(4px); transition:transform 0.3s,box-shadow 0.3s; }
            .login-card:hover { transform:translateY(-5px); box-shadow:0 30px 60px -12px rgba(0,0,0,0.3); }
            .login-header { background:var(--gradient-primary); padding:30px; text-align:center; color:white; }
            .login-header i { font-size:48px; margin-bottom:15px; }
            .login-input { border:2px solid #e9ecef; border-radius:16px; padding:12px 18px; transition:all 0.3s; }
            .login-input:focus { border-color:var(--primary-color); box-shadow:0 0 0 3px rgba(var(--primary-rgb),0.1); }
            .login-btn { background:var(--gradient-primary); border:none; border-radius:40px; padding:12px; font-weight:600; transition:all 0.3s; }
            .login-btn:hover { transform:translateY(-2px); box-shadow:0 10px 20px -5px rgba(0,0,0,0.2); }
            
            /* ===== STAFF CARDS - BIGGER PHOTOS (100px), 20% BORDER-RADIUS, GIF SUPPORT ===== */
            .staff-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 14px;
                margin-bottom: 16px;
            }
            .staff-card { 
                background: rgba(255,255,255,0.95);
                border-radius: 24px;
                padding: 18px 12px 14px 12px;
                text-align: center;
                transition: all 0.3s ease;
                border: 1px solid rgba(255,255,255,0.2);
                box-shadow: 0 4px 15px rgba(0,0,0,0.06);
                backdrop-filter: blur(4px);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 210px;
            }
            .staff-card:hover { 
                transform: translateY(-6px);
                box-shadow: 0 12px 35px rgba(0,0,0,0.15);
                background: rgba(255,255,255,1);
                border-color: var(--primary-color);
            }
            .staff-img { 
                width: 100px;
                height: 100px;
                object-fit: cover;
                border-radius: 20%;
                margin-bottom: 10px;
                border: 3px solid var(--primary-color);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                background: #f8f9fa;
                flex-shrink: 0;
                transition: all 0.3s ease;
            }
            .staff-card:hover .staff-img {
                border-color: var(--secondary-color);
                transform: scale(1.03);
                box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            }
            .staff-name { 
                font-size: 0.9rem;
                font-weight: 700;
                color: #1a1a2e;
                line-height: 1.2;
                margin-bottom: 2px;
            }
            .staff-designation { 
                font-size: 0.72rem;
                color: #6c757d;
                line-height: 1.2;
            }
            .staff-placeholder {
                width: 100px;
                height: 100px;
                border-radius: 20%;
                margin-bottom: 10px;
                background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 2.8rem;
                flex-shrink: 0;
                border: 3px solid var(--primary-color);
                transition: all 0.3s ease;
            }
            .staff-card:hover .staff-placeholder {
                transform: scale(1.03);
                box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            }
            
            /* Responsive adjustments */
            @media (max-width: 992px) {
                .staff-grid {
                    grid-template-columns: repeat(3, 1fr);
                    gap: 12px;
                }
                .staff-card {
                    padding: 14px 10px 10px 10px;
                    min-height: 185px;
                    border-radius: 20px;
                }
                .staff-img, .staff-placeholder {
                    width: 80px;
                    height: 80px;
                    font-size: 2.2rem;
                    border-width: 2.5px;
                }
                .staff-name { font-size: 0.82rem; }
                .staff-designation { font-size: 0.68rem; }
            }
            
            @media (max-width: 768px) {
                .staff-grid {
                    grid-template-columns: repeat(3, 1fr);
                    gap: 10px;
                }
                .staff-card {
                    padding: 12px 8px 8px 8px;
                    min-height: 160px;
                    border-radius: 18px;
                }
                .staff-img, .staff-placeholder {
                    width: 65px;
                    height: 65px;
                    font-size: 1.8rem;
                    border-width: 2px;
                }
                .staff-name { font-size: 0.72rem; }
                .staff-designation { font-size: 0.6rem; }
            }
            
            @media (max-width: 576px) {
                .staff-grid {
                    grid-template-columns: repeat(3, 1fr);
                    gap: 8px;
                }
                .staff-card {
                    padding: 8px 6px 6px 6px;
                    min-height: 130px;
                    border-radius: 16px;
                }
                .staff-img, .staff-placeholder {
                    width: 50px;
                    height: 50px;
                    font-size: 1.4rem;
                    border-width: 1.5px;
                    margin-bottom: 5px;
                }
                .staff-name { font-size: 0.62rem; }
                .staff-designation { font-size: 0.5rem; }
            }
            
            @media (max-width: 400px) {
                .staff-grid {
                    grid-template-columns: repeat(2, 1fr);
                    gap: 6px;
                }
                .staff-card {
                    min-height: 110px;
                    padding: 6px 4px;
                    border-radius: 14px;
                }
                .staff-img, .staff-placeholder {
                    width: 42px;
                    height: 42px;
                    font-size: 1.2rem;
                    border-width: 1.5px;
                    margin-bottom: 3px;
                }
                .staff-name { font-size: 0.58rem; }
                .staff-designation { display: none; }
            }
            
            .designer-credit { margin-top:8px; font-size:11px; opacity:0.8; }
            .designer-name { color:#ffd966; font-weight:600; text-decoration:none; }
            .designer-name:hover { text-decoration:underline; color:#ffedaa; }
            .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); }
            .btn-primary:hover { background-color: var(--primary-dark); border-color: var(--primary-dark); }
            @media (max-width:768px){ .hero-logo{height:70px;} .hero-title{font-size:2rem;} }
            [dir="rtl"] .input-group > :not(:first-child):not(.dropdown-toggle):not(.dropdown-menu) { border-radius:0 16px 16px 0; }
            [dir="rtl"] .input-group > :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu) { border-radius:16px 0 0 16px; }
            
            /* Dark mode support for staff cards */
            @media (prefers-color-scheme: dark) {
                .staff-card { background: rgba(45,45,68,0.95); border-color: rgba(58,58,90,0.5); }
                .staff-name { color: #e9ecef; }
                .staff-designation { color: #adb5bd; }
                .staff-card:hover { background: rgba(58,58,80,0.98); }
            }
        </style>
    </head>
    <body>
        <div class="main-container">
            <div class="container">
                <div class="d-flex justify-content-end mb-3">
                    <?= renderLanguageSwitcher() ?>
                </div>
                <div class="hero-section text-center">
                    <img src="<?= $logoData ?>" alt="Library Logo" class="hero-logo">
                    <h1 class="hero-title"><?= __('welcome') ?> <?= htmlspecialchars($institution['name'] ?? $settings['software_header'] ?? 'Library ERP System') ?></h1>
                    <p class="hero-subtitle"><?= __('subtitle') ?></p>
                </div>
                <div class="row g-4 mt-2">
                    <div class="col-lg-6">
                        <div class="login-card">
                            <div class="login-header">
                                <i class="fas fa-lock"></i>
                                <h3><?= __('staff_login') ?></h3>
                            </div>
                            <div class="login-body p-4">
                                <?php if ($authError): ?>
                                    <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($authError) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                                <?php endif; ?>
                                <?php if (isset($_GET['timeout'])): ?>
                                    <div class="alert alert-warning"><?= __('timeout_msg') ?></div>
                                <?php endif; ?>
                                <form method="post">
                                    <div class="mb-3">
                                        <label class="form-label"><?= __('username') ?></label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-transparent border-end-0"><i class="fas fa-user text-muted"></i></span>
                                            <input type="text" name="username" class="form-control login-input border-start-0" required autofocus>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label"><?= __('password') ?></label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-transparent border-end-0"><i class="fas fa-lock text-muted"></i></span>
                                            <input type="password" name="password" class="form-control login-input border-start-0" required>
                                        </div>
                                    </div>
                                    <button type="submit" name="login" class="btn btn-primary w-100 login-btn"><i class="fas fa-sign-in-alt me-2"></i> <?= __('login') ?></button>
                                </form>
                                <div class="text-center mt-3">
                                    <small class="text-muted"><i class="fas fa-shield-alt"></i> <?= __('secure_login') ?> <?= ($settings['enable_2fa'] ?? 0) ? '2FA' : __('password') ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <?php if (!empty($settings['staff_display_enabled']) && count($staffList) > 0): ?>
                            <div class="staff-grid">
                                <?php foreach ($staffList as $staff): ?>
                                    <div class="staff-card">
                                        <?php if (!empty($staff['photo_base64'])): ?>
                                            <img src="<?= $staff['photo_base64'] ?>" class="staff-img" alt="<?= htmlspecialchars($staff['name']) ?>" loading="lazy">
                                        <?php else: ?>
                                            <div class="staff-placeholder">
                                                <i class="fas fa-user"></i>
                                            </div>
                                        <?php endif; ?>
                                        <div class="staff-name"><?= htmlspecialchars($staff['name']) ?></div>
                                        <div class="staff-designation"><?= htmlspecialchars($staff['designation']) ?></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info text-center"><i class="fas fa-info-circle"></i> <?= __('no_staff_profiles') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="footer">
                    <div class="footer-content">
                        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. <?= __('footer_copyright') ?></p>
                        <?= $expectedCredit ?>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script>setTimeout(function(){ document.querySelectorAll('.alert').forEach(function(a){ let bs=new bootstrap.Alert(a); setTimeout(()=>bs.close(),5000); }); },3000);</script>
    </body>
    </html>
    <?php
} else {
    // -------------------- STAFF DASHBOARD (Statistics Cards Removed) --------------------
    $quickActions = getQuickActions($db);
    $role = $_SESSION['role'] ?? 'staff';
    $roleKey = match($role) {
        'admin' => 'admin_tools',
        'librarian' => 'librarian_tools',
        default => 'staff_tools'
    };
    $roleLabel = __($roleKey);
    ?>
    <!DOCTYPE html>
    <html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
        <title><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></title>
        <?php if ($faviconPath): ?><link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>"><link rel="shortcut icon" href="<?= $faviconPath ?>"><?php endif; ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
        <style>
            /* ===== VARIABLES - UNIFIED COLORS (from settings.php) ===== */
            :root {
                --primary-color: <?= $systemPrimaryColor ?>;
                --primary-light: <?= $systemPrimaryColor ?>dd;
                --primary-dark: <?= $systemPrimaryColor ?>aa;
                --primary-rgb: <?= hexdec(substr($systemPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($systemPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($systemPrimaryColor, 5, 2)) ?>;
                --gradient-primary: linear-gradient(135deg, <?= $systemPrimaryColor ?> 0%, <?= $systemSecondaryColor ?> 100%);
                --secondary-color: <?= $systemSecondaryColor ?>;
                --tertiary-color: <?= $systemTertiaryColor ?>;
                --accent-color: <?= $systemAccentColor ?>;
                --sidebar-width: 280px;
                --transition-default: all 0.3s cubic-bezier(0.2,0.9,0.4,1.1);
                --card-bg: #ffffff;
                --base-font-size: 16px;
                --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
                --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
                --radius-card: 16px;
                --staff-img-size: 80px;
            }
            * { font-family:'Inter',sans-serif; }
            body { background:#f0f2f5; min-height:100vh; display:flex; flex-direction:column; font-size: var(--base-font-size); }

            /* ===== SETTINGS BAR - REMOVED ===== */
            .settings-bar {
                display: none !important;
            }

            /* ===== NAVBAR ===== */
            .staff-navbar {
                background: var(--gradient-primary);
                padding: 8px 20px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                position: sticky;
                top: 0;
                z-index: 1030;
                flex-shrink: 0;
            }
            .staff-navbar .brand {
                font-size:1.3rem;
                font-weight:700;
                color:white;
                text-decoration:none;
                display:flex;
                align-items:center;
                gap:10px;
            }
            .staff-navbar .brand img {
                height:40px;
                width:auto;
                max-width:130px;
                object-fit:contain;
                background:white;
                border-radius:10px;
                padding:4px;
            }
            .navbar-btn {
                background:rgba(255,255,255,0.15);
                border:none;
                border-radius:40px;
                padding:6px 14px;
                color:white;
                transition:var(--transition-default);
                font-weight:500;
                backdrop-filter:blur(4px);
                font-size:0.9rem;
                white-space:nowrap;
            }
            .navbar-btn:hover {
                background:rgba(255,255,255,0.3);
                transform:translateY(-2px);
            }
            .navbar-btn i { margin-right:5px; }

            /* ===== SIDEBAR ===== */
            .staff-sidebar {
                position:fixed;
                top:68px;
                left:0;
                width:var(--sidebar-width);
                height:calc(100% - 68px);
                background:rgba(44,62,80,0.95);
                backdrop-filter:blur(12px);
                color:#ecf0f1;
                overflow-y:auto;
                z-index:1020;
                transition:width 0.3s ease, transform 0.3s ease;
                box-shadow:2px 0 15px rgba(0,0,0,0.1);
                padding:0;
                overflow-x:hidden;
            }
            body.sidebar-hidden .staff-sidebar {
                width:0;
                padding:0;
                overflow:hidden;
                box-shadow:none;
            }
            .staff-main {
                flex:1;
                padding:20px 25px 0 25px;
                background:#f4f6f9;
                transition:margin-left 0.3s ease, margin-right 0.3s ease;
                display:flex;
                flex-direction:column;
                margin-left:var(--sidebar-width);
            }
            body.sidebar-hidden .staff-main {
                margin-left:0;
            }
            /* RTL overrides using html[dir="rtl"] */
            html[dir="rtl"] .staff-sidebar {
                left:auto;
                right:0;
            }
            html[dir="rtl"] .staff-main {
                margin-left:0;
                margin-right:var(--sidebar-width);
            }
            html[dir="rtl"] body.sidebar-hidden .staff-main {
                margin-right:0;
            }

            @media (max-width:992px){
                .staff-sidebar {
                    transform:translateX(-100%);
                    width:var(--sidebar-width);
                }
                .staff-sidebar.show {
                    transform:translateX(0);
                }
                .staff-main {
                    margin-left:0 !important;
                }
                body.sidebar-hidden .staff-sidebar {
                    transform:translateX(-100%);
                    width:var(--sidebar-width);
                }
                body.sidebar-hidden .staff-sidebar.show {
                    transform:translateX(0);
                }
                .sidebar-toggle { display:flex; }
            }
            @media (min-width:993px){
                .sidebar-toggle { display:none; }
            }

            .staff-sidebar .nav-link {
                color:#ecf0f1;
                padding:10px 20px;
                transition:var(--transition-default);
                font-size:14px;
                border-left:3px solid transparent;
                display:flex;
                align-items:center;
            }
            .staff-sidebar .nav-link:hover {
                background:rgba(255,255,255,0.1);
                border-left-color:var(--tertiary-color);
                padding-left:24px;
            }
            .staff-sidebar .nav-link i { width:26px; margin-right:8px; }
            .staff-sidebar .nav-section-header {
                font-size:11px;
                text-transform:uppercase;
                letter-spacing:1.5px;
                padding:16px 20px 6px;
                color:#b0c4de;
                font-weight:700;
                border-bottom:1px solid rgba(255,255,255,0.1);
            }
            .sidebar-toggle {
                display:none;
                position:fixed;
                bottom:20px;
                left:20px;
                z-index:1100;
                background:var(--primary-color);
                color:white;
                border:none;
                border-radius:50%;
                width:50px;
                height:50px;
                font-size:24px;
                cursor:pointer;
                box-shadow:0 4px 12px rgba(0,0,0,0.2);
                align-items:center;
                justify-content:center;
            }
            html[dir="rtl"] .sidebar-toggle {
                left:auto;
                right:20px;
            }

            /* ===== WELCOME SECTION TOGGLE BUTTON ===== */
            .welcome-toggle-btn {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 42px;
                height: 42px;
                border: none;
                border-radius: 50%;
                background: var(--gradient-primary);
                color: #fff;
                font-size: 1.2rem;
                cursor: pointer;
                transition: var(--transition-default);
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                flex-shrink: 0;
            }
            .welcome-toggle-btn:hover {
                transform: scale(1.08);
                box-shadow: 0 6px 20px rgba(0,0,0,0.25);
            }
            .welcome-toggle-btn:active {
                transform: scale(0.95);
            }
            .welcome-toggle-btn i {
                transition: transform 0.3s ease;
            }
            .welcome-toggle-btn.hidden i {
                transform: rotate(180deg);
            }
            body.dark-mode .welcome-toggle-btn {
                box-shadow: 0 4px 12px rgba(255,255,255,0.1);
            }
            body.dark-mode .welcome-toggle-btn:hover {
                box-shadow: 0 6px 20px rgba(255,255,255,0.2);
            }
            .welcome-toggle-btn .tooltip-text {
                position: absolute;
                bottom: -28px;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0,0,0,0.8);
                color: #fff;
                padding: 2px 8px;
                border-radius: 4px;
                font-size: 0.65rem;
                white-space: nowrap;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.2s;
            }
            .welcome-toggle-btn:hover .tooltip-text {
                opacity: 1;
            }
            /* RTL support for tooltip */
            html[dir="rtl"] .welcome-toggle-btn .tooltip-text {
                left: auto;
                right: 50%;
                transform: translateX(50%);
            }

            /* ===== DASHBOARD WELCOME - UNIFIED GRADIENT ===== */
            .dashboard-welcome {
                background: var(--gradient-primary);
                border-radius: var(--radius-card);
                padding: 20px 28px;
                margin-bottom: 25px;
                box-shadow: var(--shadow-sm);
                color: white;
                flex-shrink:0;
            }
            .dashboard-welcome .welcome-content {
                display: flex;
                align-items: center;
                gap: 16px;
            }
            .dashboard-welcome .welcome-text {
                flex: 1;
            }
            .dashboard-welcome .welcome-text h1 {
                color: white;
            }
            .dashboard-welcome .welcome-text p {
                color: rgba(255,255,255,0.8);
            }
            .dashboard-welcome .welcome-toggle-btn {
                background: rgba(255,255,255,0.2);
            }
            .dashboard-welcome .welcome-toggle-btn:hover {
                background: rgba(255,255,255,0.35);
            }

            /* ===== CIRCULATION CARD ===== */
            .circulation-card {
                background: var(--card-bg);
                border-radius: var(--radius-card);
                padding: 24px;
                box-shadow: var(--shadow-sm);
                border: 1px solid rgba(0,0,0,0.03);
                margin-bottom: 30px;
                transition: background 0.3s ease;
            }
            .circulation-card .card-title {
                font-size:1.4rem;
                font-weight:700;
                color:var(--primary-color);
                margin-bottom:20px;
                border-bottom:2px solid var(--primary-color);
                padding-bottom:8px;
            }
            .circulation-actions {
                display:grid;
                grid-template-columns:repeat(auto-fit, minmax(160px,1fr));
                gap:16px;
            }
            .circulation-action {
                background: var(--gradient-primary);
                border-radius: var(--radius-card);
                padding:18px 12px;
                text-align:center;
                cursor:pointer;
                transition:var(--transition-default);
                border:1px solid var(--primary-color);
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                min-height:120px;
                color:white;
            }
            .circulation-action:hover {
                transform:translateY(-4px);
                box-shadow:var(--shadow-hover);
            }
            .circulation-action i {
                font-size:2.8rem;
                color:rgba(255,255,255,0.9);
                margin-bottom:10px;
                transition:0.2s;
            }
            .circulation-action:hover i {
                color:white;
                transform:scale(1.05);
            }
            .circulation-action h5 {
                font-weight:700;
                font-size:1.1rem;
                margin:0;
                color:white;
            }
            .circulation-action p {
                font-size:0.75rem;
                color:rgba(255,255,255,0.8);
                margin:4px 0 0;
            }

            /* ===== QUICK ACTIONS ===== */
            .quick-actions-section {
                margin-bottom:30px;
            }
            .quick-actions-section .section-title {
                font-size:1.2rem;
                font-weight:700;
                color:var(--primary-color);
                margin-bottom:15px;
                border-bottom:2px solid var(--primary-color);
                padding-bottom:6px;
                display:inline-block;
            }
            .quick-modules {
                display:grid;
                grid-template-columns:repeat(auto-fill, minmax(160px,1fr));
                gap:16px;
            }
            .quick-card {
                background: var(--card-bg);
                border-radius:var(--radius-card);
                padding:16px 12px;
                text-align:center;
                cursor:pointer;
                transition:var(--transition-default);
                box-shadow:var(--shadow-sm);
                border:1px solid #f0f0f0;
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                min-height:110px;
            }
            .quick-card:hover {
                transform:translateY(-4px);
                box-shadow:var(--shadow-hover);
                border-color:var(--primary-color);
                background:#fafafa;
            }
            .quick-card i {
                font-size:2.4rem;
                color:var(--primary-color);
                margin-bottom:8px;
                transition:0.2s;
            }
            .quick-card:hover i {
                color:var(--primary-light);
                transform:scale(1.05);
            }
            .quick-card h6 {
                font-weight:600;
                font-size:0.95rem;
                margin:0;
                color:#1a1a1a;
            }
            .quick-card p {
                font-size:0.7rem;
                color:#6c757d;
                margin:4px 0 0;
            }

            /* ===== FOOTER ===== */
            .footer {
                background: var(--card-bg);
                margin-top:auto;
                text-align:center;
                padding:16px;
                border-radius:var(--radius-card);
                font-size:13px;
                box-shadow:var(--shadow-sm);
                flex-shrink:0;
                margin-bottom:20px;
                transition: background 0.3s ease;
            }
            .designer-credit { margin-top:6px; font-size:11px; opacity:0.7; }
            .designer-name { color:var(--primary-color); font-weight:600; text-decoration:none; }

            /* ===== DARK MODE ===== */
            body.dark-mode { background:#121212; color:#e0e0e0; }
            body.dark-mode .staff-main { background:#1e1e1e; }
            body.dark-mode .dashboard-welcome { background: var(--gradient-primary); }
            body.dark-mode .circulation-card,
            body.dark-mode .quick-card,
            body.dark-mode .footer { background: var(--card-bg); color:#e0e0e0; border-color:#444; }
            body.dark-mode .circulation-action h5,
            body.dark-mode .quick-card h6 { color:#e0e0e0; }
            body.dark-mode .circulation-action { background: var(--gradient-primary); }
            body.dark-mode .circulation-action:hover { background: var(--gradient-primary); }
            body.dark-mode .quick-card:hover { background:#3a3a3a; }
            body.dark-mode .staff-sidebar { background:rgba(26,37,47,0.95); }
            body.dark-mode .staff-navbar { background:var(--gradient-primary); }
            body.dark-mode .text-muted { color:#aaa !important; }

            /* ===== RTL OVERRIDES ===== */
            html[dir="rtl"] .staff-sidebar .nav-link { border-left:none; border-right:3px solid transparent; }
            html[dir="rtl"] .staff-sidebar .nav-link:hover { padding-left:20px; padding-right:24px; border-right-color:var(--tertiary-color); }
            html[dir="rtl"] .staff-sidebar .nav-link i { margin-right:0; margin-left:8px; }
            html[dir="rtl"] .sidebar-toggle { left:auto; right:20px; }
            @media (max-width:992px){
                html[dir="rtl"] .staff-sidebar { transform:translateX(100%); }
                html[dir="rtl"] .staff-sidebar.show { transform:translateX(0); }
                html[dir="rtl"] .staff-main { margin-right:0 !important; }
                html[dir="rtl"] body.sidebar-hidden .staff-sidebar { transform:translateX(100%); }
            }

            /* ===== RESPONSIVE ===== */
            @media (max-width:768px){
                .staff-main { padding:12px 12px 0 12px; }
                .circulation-actions,
                .quick-modules { grid-template-columns:repeat(2,1fr); gap:12px; }
                .circulation-action,
                .quick-card { min-height:100px; padding:14px 8px; }
                .circulation-action i,
                .quick-card i { font-size:2.2rem; }
                .dashboard-welcome .welcome-content { flex-wrap:wrap; gap:10px; }
                .welcome-toggle-btn { width:36px; height:36px; font-size:1rem; }
            }
            @media (max-width:576px){
                .circulation-actions,
                .quick-modules { grid-template-columns:1fr; }
            }

            /* ===== FONT SIZE CONTROL ===== */
            .font-size-slider {
                width:100%;
                margin:6px 0;
            }
            .font-size-slider::-webkit-slider-runnable-track {
                background: #ddd;
                height:6px;
                border-radius:3px;
            }
            .font-size-slider::-webkit-slider-thumb {
                -webkit-appearance:none;
                appearance:none;
                width:16px;
                height:16px;
                border-radius:50%;
                background:var(--primary-color);
                cursor:pointer;
                margin-top:-5px;
            }
            
            /* ===== COLOR INFO BADGE ===== */
            .color-info-badge {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 0.75rem;
                background: rgba(255,255,255,0.15);
                color: white;
                cursor: pointer;
                transition: var(--transition-default);
                border: 1px solid rgba(255,255,255,0.1);
            }
            .color-info-badge:hover {
                background: rgba(255,255,255,0.25);
                transform: scale(1.02);
            }
            .color-info-badge .color-dot {
                width: 12px;
                height: 12px;
                border-radius: 50%;
                display: inline-block;
                border: 1px solid rgba(255,255,255,0.3);
                flex-shrink: 0;
            }
        </style>
    </head>
    <body>
        <!-- Mobile sidebar toggle -->
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>

        <!-- ========== NAVBAR ========== -->
        <nav class="staff-navbar">
            <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap">
                <a href="index.php" class="brand"><img src="<?= $logoData ?>" alt="Logo"><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></a>

                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <!-- Statistics Dropdown -->
                    <div class="dropdown">
                        <button class="navbar-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-chart-bar"></i> <?= __('statistics') ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" style="min-width:220px; padding:8px 0;">
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('visitors_inside') ?></span> <span class="fw-bold" id="visitorCountStat"><?= $stats['visitors_inside'] ?? 0 ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('total_members') ?></span> <span class="fw-bold"><?= number_format($stats['total_members'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('total_books') ?></span> <span class="fw-bold"><?= number_format($stats['total_books'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('currently_issued') ?></span> <span class="fw-bold"><?= number_format($stats['currently_issued'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('overdue_books') ?></span> <span class="fw-bold"><?= number_format($stats['overdue_books'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('ebooks_available') ?></span> <span class="fw-bold"><?= number_format($stats['ebooks_available'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('pending_reservations') ?></span> <span class="fw-bold"><?= number_format($stats['pending_reservations'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('upcoming_events') ?></span> <span class="fw-bold"><?= number_format($stats['upcoming_events'] ?? 0) ?></span></li>
                            <li class="d-flex justify-content-between px-3 py-1"><span><?= __('fines_today') ?></span> <span class="fw-bold"><?= formatCurrency($stats['fines_today'] ?? 0) ?></span></li>
                        </ul>
                    </div>

                    <!-- Font Size - Only remaining control -->
                    <div class="dropdown">
                        <button class="navbar-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-text-height"></i>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" style="padding:16px; min-width:200px;">
                            <div><strong><?= __('font_size') ?></strong></div>
                            <input type="range" class="font-size-slider" id="fontSizeSlider" min="80" max="120" value="100">
                            <div class="d-flex justify-content-between small text-muted">
                                <span>80%</span>
                                <span>120%</span>
                            </div>
                            <hr>
                            <div class="text-center">
                                <small class="text-muted">
                                    <i class="fas fa-palette"></i> <?= __('primary_color') ?>: 
                                    <span style="color: <?= $systemPrimaryColor ?>;">●</span>
                                    <span class="fw-bold" style="color: <?= $systemPrimaryColor ?>;"><?= $systemPrimaryColor ?></span>
                                    <br>
                                    <span class="text-muted" style="font-size:0.65rem;">
                                        <i class="fas fa-cog"></i> Manage in <a href="admin/settings.php" target="_blank" style="color: <?= $systemPrimaryColor ?>;">Settings → General</a>
                                    </span>
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar toggle (navbar) with role‑based label -->
                    <button class="navbar-btn" id="sidebarCollapseToggle">
                        <i class="fas fa-chevron-left" id="toggleIcon"></i>
                        <span class="d-none d-md-inline" id="toggleLabel"><?= sprintf(__('hide_tools'), $roleLabel) ?></span>
                    </button>

                    <!-- Dark mode -->
                    <button class="navbar-btn" id="darkModeToggle"><i class="fas fa-moon"></i> <span class="d-none d-md-inline"><?= __('dark') ?></span></button>

                    <?= renderLanguageSwitcher() ?>

                    <!-- User menu -->
                    <div class="dropdown">
                        <button class="navbar-btn dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username']) ?> <span class="badge bg-warning ms-1 text-dark"><?= ucfirst($_SESSION['role']) ?></span></button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="admin/profile.php"><i class="fas fa-id-card"></i> <?= __('my_profile') ?></a></li>
                            <?php if ((int)($settings['enable_member_portal'] ?? 1)): ?>
                            <li><a class="dropdown-item" href="member/login.php"><i class="fas fa-user-graduate"></i> <?= __('member_portal') ?></a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="?logout=1"><i class="fas fa-sign-out-alt"></i> <?= __('logout') ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- ========== SIDEBAR ========== -->
        <div class="staff-sidebar" id="staffSidebar">
            <div class="nav flex-column">
                <div class="nav-section-header"><?= __('Main') ?></div>
                <a href="admin/dashboard.php" class="nav-link"><i class="fas fa-tachometer-alt"></i> <?= __('Admin Dashboard') ?></a>
                <a href="circulation/" class="nav-link"><i class="fas fa-exchange-alt"></i> <?= __('Circulation') ?></a>
                <a href="admin/members.php" class="nav-link"><i class="fas fa-users"></i> <?= __('Members') ?></a>
                <a href="admin/books.php" class="nav-link"><i class="fas fa-book"></i> <?= __('Books') ?></a>
                <a href="ebooks/" class="nav-link"><i class="fas fa-file-pdf"></i> <?= __('eBooks') ?></a>

                <div class="nav-section-header"><?= __('Research') ?></div>
                <a href="admin/research_databases.php" class="nav-link"><i class="fas fa-database"></i> <?= __('Research Databases') ?></a>

                <div class="nav-section-header"><?= __('Acquisitions & Serials') ?></div>
                <a href="acquisitions/" class="nav-link"><i class="fas fa-shopping-cart"></i> <?= __('Acquisitions') ?></a>
                <a href="serial/" class="nav-link"><i class="fas fa-newspaper"></i> <?= __('Serials Control') ?></a>

                <div class="nav-section-header"><?= __('Administration') ?></div>
                <a href="admin/settings.php" class="nav-link"><i class="fas fa-cog"></i> <?= __('System Settings') ?></a>
                <a href="admin/quick_actions.php" class="nav-link"><i class="fas fa-th-large"></i> <?= __('Quick Actions Manager') ?></a>
                <a href="admin/loan_rules.php" class="nav-link"><i class="fas fa-gavel"></i> <?= __('Loan Rules') ?></a>
                <a href="admin/staff.php" class="nav-link"><i class="fas fa-user-tie"></i> <?= __('Staff Profiles') ?></a>
                <a href="admin/notices.php" class="nav-link"><i class="fas fa-bullhorn"></i> <?= __('Manage Notices') ?></a>
                <a href="admin/suggestions.php" class="nav-link"><i class="fas fa-lightbulb"></i> <?= __('Suggestions') ?></a>
                <a href="admin/fine_rates.php" class="nav-link"><i class="fas fa-coins"></i> <?= __('Fine Rates') ?></a>
                <a href="admin/backup.php" class="nav-link"><i class="fas fa-database"></i> <?= __('Backup & Restore') ?></a>
                <a href="utilities/" class="nav-link"><i class="fas fa-toolbox"></i> <?= __('Utilities Suite') ?></a>
                <a href="stock/" class="nav-link"><i class="fas fa-clipboard-list"></i> <?= __('Stock Verification') ?></a>
                <a href="lost_books/" class="nav-link"><i class="fas fa-book-dead"></i> <?= __('Lost & Damaged') ?></a>
                <a href="payments/" class="nav-link"><i class="fas fa-money-bill-wave"></i> <?= __('Payments') ?></a>
                <a href="reservations/" class="nav-link"><i class="fas fa-calendar-check"></i> <?= __('Reservations') ?></a>
                <a href="events/" class="nav-link"><i class="fas fa-calendar-alt"></i> <?= __('Library Events') ?></a>
                <a href="member_docs/" class="nav-link"><i class="fas fa-id-card"></i> <?= __('Member Documents') ?></a>
                <a href="computer_management/" class="nav-link"><i class="fas fa-desktop"></i> <?= __('Computer Access') ?></a>
                <a href="imports/" class="nav-link"><i class="fas fa-file-import"></i> <?= __('Data Import') ?></a>
                <a href="entry_exit/" class="nav-link"><i class="fas fa-door-open"></i> <?= __('Entry/Exit') ?></a>
                <a href="session_logs/" class="nav-link"><i class="fas fa-history"></i> <?= __('Session Logs') ?></a>

                <div class="nav-section-header"><?= __('Communication') ?></div>
                <a href="admin/bulk_messaging.php" class="nav-link"><i class="fas fa-bullhorn"></i> <?= __('Bulk Messaging') ?></a>
                <a href="chatbot/index.php" class="nav-link"><i class="fas fa-robot"></i> <?= __('Chatbot') ?></a>

                <div class="nav-section-header"><?= __('Reports & Analytics') ?></div>
                <a href="reports/" class="nav-link"><i class="fas fa-chart-line"></i> <?= __('Reports') ?></a>
                <a href="advanced_analytics/index.php" class="nav-link"><i class="fas fa-chart-pie"></i> <?= __('Advanced Analytics') ?></a>
                <a href="cron/index.php" class="nav-link"><i class="fas fa-robot"></i> <?= __('Cron') ?></a>

                <div class="nav-section-header"><?= __('Public Interfaces') ?></div>
                <a href="opac/" class="nav-link"><i class="fas fa-globe"></i> <?= __('OPAC') ?></a>
                <a href="opac/digital_hub.php" class="nav-link"><i class="fas fa-globe-asia"></i> <?= __('Digital Library Hub') ?></a>
                <a href="visitor/index.php" class="nav-link"><i class="fas fa-qrcode"></i> <?= __('Self Kiosk') ?></a>
                <a href="member/login.php" class="nav-link"><i class="fas fa-user-graduate"></i> <?= __('Member Portal') ?></a>

                <?php if (is_dir(__DIR__ . '/institution')): ?>
                    <div class="nav-section-header"><?= __('Multi‑Library') ?></div>
                    <a href="institution/" class="nav-link"><i class="fas fa-building"></i> <?= __('Institutions') ?></a>
                <?php endif; ?>

                <div class="nav-section-header"><?= __('API') ?></div>
                <a href="api/v1/" class="nav-link"><i class="fas fa-code-branch"></i> <?= __('REST API') ?></a>

                <div class="nav-section-header"><?= __('Account') ?></div>
                <a href="?logout=1" class="nav-link"><i class="fas fa-sign-out-alt"></i> <?= __('Logout') ?></a>
            </div>
        </div>

        <!-- ========== MAIN CONTENT ========== -->
        <div class="staff-main">
            <!-- Welcome -->
            <div class="dashboard-welcome">
                <div class="row align-items-center">
                    <div class="col-md-8 welcome-content">
                        <button class="welcome-toggle-btn" id="welcomeSidebarToggle" title="<?= sprintf(__('hide_tools'), $roleLabel) ?>">
                            <i class="fas fa-chevron-left" id="welcomeToggleIcon"></i>
                            <span class="tooltip-text" id="welcomeToggleTooltip"><?= sprintf(__('hide_tools'), $roleLabel) ?></span>
                        </button>
                        <div class="welcome-text">
                            <h1 class="h4 mb-1"><?= __($greetingKey) ?>, <?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username']) ?>!</h1>
                            <p class="mb-0"><?= __('today_is') ?> <?= date('l, F j, Y') ?> | <?= __('time') ?> <?= date('g:i A') ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 text-end"><i class="fas fa-chart-line fa-3x opacity-25"></i></div>
                </div>
            </div>

            <!-- ===== CIRCULATION CARD - UNIFIED GRADIENT ===== -->
            <div class="circulation-card">
                <div class="card-title"><i class="fas fa-exchange-alt me-2"></i><?= __('circulation') ?></div>
                <div class="circulation-actions">
                    <div class="circulation-action" onclick="location.href='circulation/issue.php'">
                        <i class="fas fa-arrow-right"></i>
                        <h5><?= __('issue_book') ?></h5>
                        <p><?= __('issue_desc') ?></p>
                    </div>
                    <div class="circulation-action" onclick="location.href='circulation/return.php'">
                        <i class="fas fa-arrow-left"></i>
                        <h5><?= __('return_book') ?></h5>
                        <p><?= __('return_desc') ?></p>
                    </div>
                    <div class="circulation-action" onclick="location.href='circulation/renew.php'">
                        <i class="fas fa-sync-alt"></i>
                        <h5><?= __('renew') ?></h5>
                        <p><?= __('renew_desc') ?></p>
                    </div>
                    <div class="circulation-action" onclick="location.href='circulation/overdue.php'">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h5><?= __('overdue') ?></h5>
                        <p><?= __('overdue_desc') ?></p>
                    </div>
                </div>
            </div>

            <!-- ===== QUICK ACTIONS ===== -->
            <div class="quick-actions-section">
                <div class="section-title"><i class="fas fa-bolt me-2"></i><?= __('quick_actions') ?></div>
                <div class="quick-modules">
                    <?php if (!empty($quickActions)): ?>
                        <?php foreach ($quickActions as $action):
                            $icon = htmlspecialchars($action['icon_class']);
                            $title = htmlspecialchars($action['title']);
                            $link = htmlspecialchars($action['link_url']);
                            $translatedTitle = __($title) ?: $title;
                            $desc = match($title) {
                                'Issue Book' => __('issue_desc'),
                                'Return Book' => __('return_desc'),
                                'Renew' => __('renew_desc'),
                                'Overdue' => __('overdue_desc'),
                                'Computer Access' => __('computer_desc'),
                                'eBooks' => __('ebooks_desc'),
                                'Pay Fines' => __('pay_fines_desc'),
                                'Utilities Suite' => __('utilities_desc'),
                                'Serial Control' => __('serial_desc'),
                                'Backup & Restore' => __('backup_desc'),
                                'Reports' => __('reports_desc'),
                                'Settings' => __('settings_desc'),
                                default => __('quick_access')
                            };
                        ?>
                            <div class="quick-card" onclick="location.href='<?= $link ?>'">
                                <i class="fas <?= $icon ?>"></i>
                                <h6><?= $translatedTitle ?></h6>
                                <p><?= $desc ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="alert alert-warning"><?= __('no_quick_actions') ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Footer -->
            <div class="footer">
                <div class="footer-content">
                    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. <?= __('footer_copyright') ?></p>
                    <?= $expectedCredit ?>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // ============================================================
            //  CARD BACKGROUND COLOR (removed - uses system settings)
            // ============================================================
            // Card background is now controlled by system colors from settings.php
            // No custom color picker is available - use Settings > General

            // ============================================================
            //  FONT SIZE CONTROL - Only remaining customization
            // ============================================================
            (function() {
                const root = document.documentElement;
                const slider = document.getElementById('fontSizeSlider');

                function setFontSize(value) {
                    const size = parseInt(value);
                    const base = size / 100 * 16;
                    root.style.setProperty('--base-font-size', base + 'px');
                    localStorage.setItem('fontSize', size);
                }

                const savedSize = localStorage.getItem('fontSize');
                if (savedSize) {
                    slider.value = savedSize;
                    setFontSize(savedSize);
                } else {
                    setFontSize(100);
                }

                slider.addEventListener('input', function() {
                    setFontSize(this.value);
                });
            })();

            // ============================================================
            //  SIDEBAR TOGGLE (shared logic, role‑based labels)
            // ============================================================
            (function() {
                const body = document.body;
                const sidebar = document.getElementById('staffSidebar');
                const mobileToggle = document.getElementById('sidebarToggle');

                const navbarToggle = document.getElementById('sidebarCollapseToggle');
                const navbarIcon = document.getElementById('toggleIcon');
                const navbarLabel = document.getElementById('toggleLabel');
                const welcomeToggle = document.getElementById('welcomeSidebarToggle');
                const welcomeIcon = document.getElementById('welcomeToggleIcon');
                const welcomeTooltip = document.getElementById('welcomeToggleTooltip');

                const hideLabel = '<?= sprintf(__('hide_tools'), $roleLabel) ?>';
                const showLabel = '<?= sprintf(__('show_tools'), $roleLabel) ?>';

                function updateToggleUI(hidden) {
                    if (navbarIcon) {
                        navbarIcon.className = hidden ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
                    }
                    if (navbarLabel) {
                        navbarLabel.textContent = hidden ? showLabel : hideLabel;
                    }
                    if (welcomeIcon) {
                        welcomeIcon.className = hidden ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
                        welcomeIcon.parentElement.classList.toggle('hidden', hidden);
                    }
                    if (welcomeTooltip) {
                        welcomeTooltip.textContent = hidden ? showLabel : hideLabel;
                    }
                    if (welcomeToggle) {
                        welcomeToggle.title = hidden ? showLabel : hideLabel;
                    }
                }

                function toggleSidebar() {
                    const hidden = body.classList.toggle('sidebar-hidden');
                    localStorage.setItem('sidebarHidden', hidden);
                    updateToggleUI(hidden);
                    if (hidden) {
                        sidebar.classList.remove('show');
                    }
                }

                const saved = localStorage.getItem('sidebarHidden');
                const isHidden = saved === 'true';
                if (isHidden) {
                    body.classList.add('sidebar-hidden');
                    updateToggleUI(true);
                } else {
                    updateToggleUI(false);
                }

                if (navbarToggle) navbarToggle.addEventListener('click', toggleSidebar);
                if (welcomeToggle) welcomeToggle.addEventListener('click', toggleSidebar);

                if (mobileToggle) {
                    mobileToggle.addEventListener('click', function(e) {
                        e.stopPropagation();
                        if (body.classList.contains('sidebar-hidden')) {
                            body.classList.remove('sidebar-hidden');
                            localStorage.setItem('sidebarHidden', 'false');
                            updateToggleUI(false);
                            sidebar.classList.add('show');
                        } else {
                            sidebar.classList.toggle('show');
                        }
                    });
                }

                document.addEventListener('click', function(e) {
                    if (window.innerWidth <= 992 && sidebar && !body.classList.contains('sidebar-hidden')) {
                        if (!sidebar.contains(e.target) && !mobileToggle.contains(e.target) && sidebar.classList.contains('show')) {
                            sidebar.classList.remove('show');
                        }
                    }
                });

                window.addEventListener('resize', function() {
                    if (window.innerWidth > 992) {
                        if (!body.classList.contains('sidebar-hidden')) {
                            sidebar.classList.remove('show');
                        }
                    }
                });
            })();

            // ============================================================
            //  DARK MODE
            // ============================================================
            const darkModeToggle = document.getElementById('darkModeToggle');
            const isDark = localStorage.getItem('dark-mode') === 'true';
            if (isDark) { document.body.classList.add('dark-mode'); darkModeToggle.innerHTML = '<i class="fas fa-sun"></i> <span class="d-none d-md-inline"><?= __('light') ?></span>'; } else { darkModeToggle.innerHTML = '<i class="fas fa-moon"></i> <span class="d-none d-md-inline"><?= __('dark') ?></span>'; }
            darkModeToggle.addEventListener('click', () => {
                const newDark = !document.body.classList.contains('dark-mode');
                if (newDark) { document.body.classList.add('dark-mode'); darkModeToggle.innerHTML = '<i class="fas fa-sun"></i> <span class="d-none d-md-inline"><?= __('light') ?></span>'; }
                else { document.body.classList.remove('dark-mode'); darkModeToggle.innerHTML = '<i class="fas fa-moon"></i> <span class="d-none d-md-inline"><?= __('dark') ?></span>'; }
                localStorage.setItem('dark-mode', newDark);
            });

            // ============================================================
            //  VISITOR COUNT
            // ============================================================
            let visitorCountStat = document.getElementById('visitorCountStat');
            let useWebSocket = false;

            function updateVisitorCount(v) {
                if (visitorCountStat) visitorCountStat.innerText = v;
            }

            function fetchFallback() {
                fetch('opac/visitor.php?ajax=stats')
                    .then(r => r.json())
                    .then(data => { updateVisitorCount(data.insideCount ?? '0'); })
                    .catch(() => updateVisitorCount('?'));
            }

            try {
                const ws = new WebSocket((location.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + location.hostname + ':8080');
                ws.onopen = () => { useWebSocket = true; };
                ws.onmessage = (e) => {
                    try {
                        const d = JSON.parse(e.data);
                        if (d.type === 'visitor_count') updateVisitorCount(d.inside);
                    } catch(e) {}
                };
                ws.onerror = () => { useWebSocket = false; fetchFallback(); };
                ws.onclose = () => { useWebSocket = false; fetchFallback(); };
            } catch(e) { fetchFallback(); }
            setInterval(() => { if (!useWebSocket) fetchFallback(); }, 30000);
            fetchFallback();

            // ============================================================
            //  TOUCH FEEDBACK
            // ============================================================
            document.querySelectorAll('.circulation-action, .quick-card, .nav-link, .btn, .navbar-btn').forEach(el => {
                el.addEventListener('touchstart', function() { this.style.opacity = '0.7'; });
                el.addEventListener('touchend', function() { this.style.opacity = '1'; });
            });
            setTimeout(() => {
                document.querySelectorAll('.alert').forEach(a => {
                    let bs = new bootstrap.Alert(a);
                    setTimeout(() => bs.close(), 5000);
                });
            }, 3000);
        </script>
    </body>
    </html>
    <?php
}
// No closing PHP tag
?>