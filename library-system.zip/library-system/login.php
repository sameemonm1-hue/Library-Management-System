<?php
/**
 * Library ERP System - Login Page
 * Version: 1.4 - Increased staff image size, 20% border-radius, GIF support
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/php_errors.log');
date_default_timezone_set(@date_default_timezone_get() ?: 'UTC');

session_start();
define('ROOT_PATH', __DIR__);

// Fix: require_once with correct path
require_once ROOT_PATH . '/config/db.php';
require_once ROOT_PATH . '/config/functions.php';

// ==================== MULTI-LANGUAGE SYSTEM ====================
$availableLanguages = ['en', 'hi', 'ar'];
$defaultLanguage = 'en';

if (isset($_GET['lang']) && in_array($_GET['lang'], $availableLanguages)) {
    $_SESSION['lang'] = $_GET['lang'];
}
$lang = $_SESSION['lang'] ?? $defaultLanguage;

// ==================== REPORT APPEARANCE SETTINGS ====================
$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

$translations = [
    'en' => [
        'welcome' => 'Welcome To',
        'subtitle' => 'Complete Library Management Solution With Ease',
        'staff_login' => 'Staff Login',
        'username' => 'Username',
        'password' => 'Password',
        'login' => 'Login',
        'secure_login' => 'Secure Login With',
        'timeout_msg' => 'Your Session Timed Out. Please Log In Again.',
        'invalid_credentials' => 'Invalid Username Or Password',
        'login_failed' => 'Login Failed: ',
        'no_staff_profiles' => 'No Staff Profiles Configured. Please Go To <strong>Admin → Staff Profiles</strong> To Add Librarians And Staff.',
        'logout' => 'Logout',
        'my_profile' => 'My Profile',
        'member_portal' => 'Member Portal',
        'footer_copyright' => 'All Rights Reserved.',
        'maintenance_title' => 'Maintenance Mode',
        'maintenance_body' => 'We Are Currently Performing Scheduled Maintenance. Please Check Back Later.',
        'greeting_morning' => 'Good Morning',
        'greeting_afternoon' => 'Good Afternoon',
        'greeting_evening' => 'Good Evening',
        'today_is' => 'Today Is',
        'time' => 'Time',
        'visitors_inside' => 'Currently Inside',
        'total_members' => 'Total Members',
        'total_books' => 'Total Books',
        'currently_issued' => 'Currently Issued',
        'overdue_books' => 'Overdue Books',
        'ebooks_available' => 'eBooks Available',
        'pending_reservations' => 'Pending Reservations',
        'upcoming_events' => 'Upcoming Events',
        'fines_today' => 'Fines Collected Today',
        'quick_actions' => 'Quick Actions',
        'no_quick_actions' => 'No Quick Actions Defined. Please Add Some In <a href="admin/quick_actions.php">Quick Actions Manager</a>.',
        'issue_book' => 'Issue Book',
        'issue_desc' => 'Scan Member & Book Barcode',
        'return_book' => 'Return Book',
        'return_desc' => 'Process Returns & Fines',
        'renew' => 'Renew',
        'renew_desc' => 'Extend Due Dates',
        'overdue' => 'Overdue',
        'overdue_desc' => 'View Overdue Items',
        'computer_access' => 'Computer Access',
        'computer_desc' => 'Manage PC Bookings',
        'ebooks' => 'eBooks',
        'ebooks_desc' => 'Digital Collection',
        'utilities' => 'Utilities Suite',
        'utilities_desc' => 'Tools & Helpers',
        'serial_control' => 'Serial Control',
        'serial_desc' => 'Manage Periodicals',
        'backup_restore' => 'Backup & Restore',
        'backup_desc' => 'Data Safety',
        'reports' => 'Reports',
        'reports_desc' => 'Generate Statistics',
        'settings' => 'Settings',
        'settings_desc' => 'System Configuration',
        'quick_access' => 'Quick Access',
        'dark' => 'Dark',
        'light' => 'Light',
        'toggle_sidebar' => 'Toggle Sidebar',
        'hide_sidebar'   => 'Hide Sidebar',
        'show_sidebar'   => 'Show Sidebar',
        'statistics'     => 'Statistics',
        'circulation' => 'Circulation',
        'card_background' => 'Card Background',
        'font_size' => 'Font Size',
        'primary_color' => 'Primary Color',
        'pay_fines' => 'Pay Fines',
        'pay_fines_desc' => 'Member Fine Payments',

        // Role‑based tool labels
        'hide_tools' => 'Hide %s Tools',
        'show_tools' => 'Show %s Tools',
        'admin_tools' => 'Admin',
        'librarian_tools' => 'Librarian',
        'staff_tools' => 'Staff',

        // Sidebar
        'Main' => 'Main',
        'Admin Dashboard' => 'Dashboard',
        'Circulation' => 'Circulation',
        'Members' => 'Members',
        'Books' => 'Books',
        'eBooks' => 'eBooks',
        'Research' => 'Research',
        'Research Databases' => 'Research Databases',
        'Acquisitions & Serials' => 'Acquisitions & Serials',
        'Acquisitions' => 'Acquisitions',
        'Serials Control' => 'Serials Control',
        'Administration' => 'Administration',
        'System Settings' => 'System Settings',
        'Quick Actions Manager' => 'Quick Actions Manager',
        'Loan Rules' => 'Loan Rules',
        'Staff Profiles' => 'Staff Profiles',
        'Manage Notices' => 'Manage Notices',
        'Suggestions' => 'Suggestions',
        'Fine Rates' => 'Fine Rates',
        'Backup & Restore' => 'Backup & Restore',
        'Utilities Suite' => 'Utilities Suite',
        'Stock Verification' => 'Stock Verification',
        'Lost & Damaged' => 'Lost & Damaged',
        'Payments' => 'Payments',
        'Reservations' => 'Reservations',
        'Library Events' => 'Library Events',
        'Member Documents' => 'Member Documents',
        'Computer Access' => 'Computer Access',
        'Data Import' => 'Data Import',
        'Entry/Exit' => 'Entry/Exit',
        'Session Logs' => 'Session Logs',
        'Communication' => 'Communication',
        'Bulk Messaging' => 'Bulk Messaging',
        'Chatbot' => 'Chatbot',
        'Reports & Analytics' => 'Reports & Analytics',
        'Reports' => 'Reports',
        'Advanced Analytics' => 'Advanced Analytics',
        'Cron' => 'Cron',
        'Public Interfaces' => 'Public Interfaces',
        'OPAC' => 'OPAC',
        'Digital Library Hub' => 'Digital Library Hub',
        'Self Kiosk' => 'Self Kiosk',
        'Member Portal' => 'Member Portal',
        'Multi‑Library' => 'Multi‑Library',
        'Institutions' => 'Institutions',
        'API' => 'API',
        'REST API' => 'REST API',
        'Account' => 'Account',
        'Pay Fines' => 'Pay Fines',
    ],
    'hi' => [
        'welcome' => 'में आपका स्वागत है',
        'subtitle' => 'सरलता के साथ संपूर्ण पुस्तकालय प्रबंधन समाधान',
        'staff_login' => 'स्टाफ लॉगिन',
        'username' => 'उपयोगकर्ता नाम',
        'password' => 'पासवर्ड',
        'login' => 'लॉगिन',
        'secure_login' => 'सुरक्षित लॉगिन',
        'timeout_msg' => 'आपका सत्र समाप्त हो गया। कृपया पुनः लॉगिन करें।',
        'invalid_credentials' => 'उपयोगकर्ता नाम या पासवर्ड गलत है',
        'login_failed' => 'लॉगिन विफल: ',
        'no_staff_profiles' => 'कोई स्टाफ प्रोफ़ाइल कॉन्फ़िगर नहीं की गई है। कृपया <strong>प्रशासन → स्टाफ प्रोफ़ाइल</strong> पर जाकर पुस्तकालयाध्यक्षों और कर्मचारियों को जोड़ें।',
        'logout' => 'लॉगआउट',
        'my_profile' => 'मेरी प्रोफ़ाइल',
        'member_portal' => 'सदस्य पोर्टल',
        'footer_copyright' => 'सर्वाधिकार सुरक्षित।',
        'maintenance_title' => 'रखरखाव मोड',
        'maintenance_body' => 'हम वर्तमान में निर्धारित रखरखाव कर रहे हैं। कृपया बाद में वापस आएँ।',
        'greeting_morning' => 'सुप्रभात',
        'greeting_afternoon' => 'शुभ अपराह्न',
        'greeting_evening' => 'शुभ संध्या',
        'today_is' => 'आज',
        'time' => 'समय',
        'visitors_inside' => 'वर्तमान में अंदर',
        'total_members' => 'कुल सदस्य',
        'total_books' => 'कुल पुस्तकें',
        'currently_issued' => 'वर्तमान में जारी',
        'overdue_books' => 'अतिदेय पुस्तकें',
        'ebooks_available' => 'उपलब्ध ई-पुस्तकें',
        'pending_reservations' => 'लंबित आरक्षण',
        'upcoming_events' => 'आगामी कार्यक्रम',
        'fines_today' => 'आज एकत्रित जुर्माना',
        'quick_actions' => 'त्वरित क्रियाएँ',
        'no_quick_actions' => 'कोई त्वरित क्रिया परिभाषित नहीं है। कृपया <a href="admin/quick_actions.php">त्वरित क्रियाएँ प्रबंधक</a> में जोड़ें।',
        'issue_book' => 'पुस्तक जारी करें',
        'issue_desc' => 'सदस्य और पुस्तक बारकोड स्कैन करें',
        'return_book' => 'पुस्तक वापस लें',
        'return_desc' => 'वापसी और जुर्माना प्रक्रिया करें',
        'renew' => 'नवीनीकरण',
        'renew_desc' => 'देय तिथि बढ़ाएँ',
        'overdue' => 'अतिदेय',
        'overdue_desc' => 'अतिदेय आइटम देखें',
        'computer_access' => 'कंप्यूटर पहुँच',
        'computer_desc' => 'पीसी बुकिंग प्रबंधित करें',
        'ebooks' => 'ई-पुस्तकें',
        'ebooks_desc' => 'डिजिटल संग्रह',
        'utilities' => 'उपयोगिता सुइट',
        'utilities_desc' => 'उपकरण और सहायक',
        'serial_control' => 'सीरियल नियंत्रण',
        'serial_desc' => 'पत्रिकाएँ प्रबंधित करें',
        'backup_restore' => 'बैकअप और पुनर्स्थापना',
        'backup_desc' => 'डेटा सुरक्षा',
        'reports' => 'रिपोर्ट',
        'reports_desc' => 'आँकड़े उत्पन्न करें',
        'settings' => 'सेटिंग्स',
        'settings_desc' => 'सिस्टम विन्यास',
        'quick_access' => 'त्वरित पहुँच',
        'dark' => 'डार्क',
        'light' => 'लाइट',
        'toggle_sidebar' => 'साइडबार टॉगल करें',
        'hide_sidebar'   => 'साइडबार छिपाएँ',
        'show_sidebar'   => 'साइडबार दिखाएँ',
        'statistics'     => 'आँकड़े',
        'circulation' => 'परिसंचरण',
        'card_background' => 'कार्ड पृष्ठभूमि',
        'font_size' => 'फ़ॉन्ट आकार',
        'primary_color' => 'प्राथमिक रंग',
        'pay_fines' => 'जुर्माना भुगतान करें',
        'pay_fines_desc' => 'सदस्य जुर्माना भुगतान',
        'hide_tools' => '%s टूल्स छिपाएँ',
        'show_tools' => '%s टूल्स दिखाएँ',
        'admin_tools' => 'एडमिन',
        'librarian_tools' => 'लाइब्रेरियन',
        'staff_tools' => 'स्टाफ',
        'Main' => 'मुख्य',
        'Admin Dashboard' => 'डैशबोर्ड',
        'Circulation' => 'परिसंचरण',
        'Members' => 'सदस्य',
        'Books' => 'पुस्तकें',
        'eBooks' => 'ई-पुस्तकें',
        'Research' => 'अनुसंधान',
        'Research Databases' => 'अनुसंधान डेटाबेस',
        'Acquisitions & Serials' => 'अधिग्रहण और सीरियल',
        'Acquisitions' => 'अधिग्रहण',
        'Serials Control' => 'सीरियल नियंत्रण',
        'Administration' => 'प्रशासन',
        'System Settings' => 'सिस्टम सेटिंग्स',
        'Quick Actions Manager' => 'त्वरित क्रियाएँ प्रबंधक',
        'Loan Rules' => 'ऋण नियम',
        'Staff Profiles' => 'स्टाफ प्रोफ़ाइल',
        'Manage Notices' => 'सूचनाएँ प्रबंधित करें',
        'Suggestions' => 'सुझाव',
        'Fine Rates' => 'जुर्माना दरें',
        'Backup & Restore' => 'बैकअप और पुनर्स्थापना',
        'Utilities Suite' => 'उपयोगिता सुइट',
        'Stock Verification' => 'स्टॉक सत्यापन',
        'Lost & Damaged' => 'खोई हुई और क्षतिग्रस्त पुस्तकें',
        'Payments' => 'भुगतान',
        'Reservations' => 'आरक्षण',
        'Library Events' => 'पुस्तकालय कार्यक्रम',
        'Member Documents' => 'सदस्य दस्तावेज़',
        'Computer Access' => 'कंप्यूटर पहुँच',
        'Data Import' => 'डेटा आयात',
        'Entry/Exit' => 'प्रवेश/निकास',
        'Session Logs' => 'सत्र लॉग',
        'Communication' => 'संचार',
        'Bulk Messaging' => 'सामूहिक SMS/WhatsApp',
        'Chatbot' => 'पुस्तकालय चैटबॉट',
        'Reports & Analytics' => 'रिपोर्ट और विश्लेषण',
        'Reports' => 'रिपोर्ट',
        'Advanced Analytics' => 'उन्नत विश्लेषण',
        'Cron' => 'Cron',
        'Public Interfaces' => 'सार्वजनिक इंटरफ़ेस',
        'OPAC' => 'OPAC',
        'Digital Library Hub' => 'डिजिटल लाइब्रेरी हब',
        'Self Kiosk' => 'सेल्फ कियोस्क',
        'Member Portal' => 'सदस्य पोर्टल',
        'Multi‑Library' => 'बहु-पुस्तकालय',
        'Institutions' => 'संस्थान',
        'API' => 'API',
        'REST API' => 'REST API',
        'Account' => 'खाता',
        'Pay Fines' => 'जुर्माना भुगतान करें',
    ],
    'ar' => [
        'welcome' => 'مرحباً بكم في',
        'subtitle' => 'حل متكامل لإدارة المكتبات بكل سهولة',
        'staff_login' => 'تسجيل دخول الموظفين',
        'username' => 'اسم المستخدم',
        'password' => 'كلمة المرور',
        'login' => 'تسجيل الدخول',
        'secure_login' => 'تسجيل دخول آمن عبر',
        'timeout_msg' => 'انتهت مدة الجلسة. يرجى تسجيل الدخول مجدداً.',
        'invalid_credentials' => 'اسم المستخدم أو كلمة المرور غير صحيحة',
        'login_failed' => 'فشل تسجيل الدخول: ',
        'no_staff_profiles' => 'لم يتم تكوين ملفات تعريف الموظفين. يرجى الانتقال إلى <strong>الإدارة ← ملفات تعريف الموظفين</strong> لإضافة أمناء المكتبات والموظفين.',
        'logout' => 'تسجيل الخروج',
        'my_profile' => 'ملفي الشخصي',
        'member_portal' => 'بوابة الأعضاء',
        'footer_copyright' => 'جميع الحقوق محفوظة.',
        'maintenance_title' => 'وضع الصيانة',
        'maintenance_body' => 'نقوم حالياً بصيانة مجدولة. يرجى العودة لاحقاً.',
        'greeting_morning' => 'صباح الخير',
        'greeting_afternoon' => 'مساء الخير',
        'greeting_evening' => 'مساء الخير',
        'today_is' => 'اليوم هو',
        'time' => 'الوقت',
        'visitors_inside' => 'المتواجدون حالياً',
        'total_members' => 'إجمالي الأعضاء',
        'total_books' => 'إجمالي الكتب',
        'currently_issued' => 'المستعارة حالياً',
        'overdue_books' => 'الكتب المتأخرة',
        'ebooks_available' => 'الكتب الإلكترونية المتاحة',
        'pending_reservations' => 'الحجوزات المعلقة',
        'upcoming_events' => 'الفعاليات القادمة',
        'fines_today' => 'الغرامات المحصلة اليوم',
        'quick_actions' => 'الإجراءات السريعة',
        'no_quick_actions' => 'لا توجد إجراءات سريعة. يرجى إضافتها في <a href="admin/quick_actions.php">مدير الإجراءات السريعة</a>.',
        'issue_book' => 'إعارة كتاب',
        'issue_desc' => 'مسح باركود العضو والكتاب',
        'return_book' => 'إرجاع كتاب',
        'return_desc' => 'معالجة الإرجاع والغرامات',
        'renew' => 'تجديد',
        'renew_desc' => 'تمديد موعد الاستحقاق',
        'overdue' => 'متأخر',
        'overdue_desc' => 'عرض المواد المتأخرة',
        'computer_access' => 'الوصول إلى الحاسوب',
        'computer_desc' => 'إدارة حجوزات الحاسوب',
        'ebooks' => 'الكتب الإلكترونية',
        'ebooks_desc' => 'المجموعة الرقمية',
        'utilities' => 'مجموعة الأدوات',
        'utilities_desc' => 'الأدوات والمساعدات',
        'serial_control' => 'التحكم في الدوريات',
        'serial_desc' => 'إدارة الدوريات',
        'backup_restore' => 'النسخ الاحتياطي والاستعادة',
        'backup_desc' => 'أمان البيانات',
        'reports' => 'التقارير',
        'reports_desc' => 'إنشاء الإحصائيات',
        'settings' => 'الإعدادات',
        'settings_desc' => 'تكوين النظام',
        'quick_access' => 'وصول سريع',
        'dark' => 'مظلم',
        'light' => 'فاتح',
        'toggle_sidebar' => 'تبديل الشريط الجانبي',
        'hide_sidebar'   => 'إخفاء الشريط الجانبي',
        'show_sidebar'   => 'إظهار الشريط الجانبي',
        'statistics'     => 'الإحصائيات',
        'circulation' => 'الإعارة والإرجاع',
        'card_background' => 'خلفية البطاقة',
        'font_size' => 'حجم الخط',
        'primary_color' => 'اللون الأساسي',
        'pay_fines' => 'دفع الغرامات',
        'pay_fines_desc' => 'مدفوعات غرامات الأعضاء',
        'hide_tools' => 'إخفاء أدوات %s',
        'show_tools' => 'إظهار أدوات %s',
        'admin_tools' => 'المشرف',
        'librarian_tools' => 'أمين المكتبة',
        'staff_tools' => 'الموظفين',
        'Main' => 'الرئيسية',
        'Admin Dashboard' => 'لوحة التحكم',
        'Circulation' => 'الإعارة والإرجاع',
        'Members' => 'الأعضاء',
        'Books' => 'الكتب',
        'eBooks' => 'الكتب الإلكترونية',
        'Research' => 'البحث العلمي',
        'Research Databases' => 'قواعد البيانات البحثية',
        'Acquisitions & Serials' => 'الاقتناء والدوريات',
        'Acquisitions' => 'الاقتناء',
        'Serials Control' => 'التحكم في الدوريات',
        'Administration' => 'الإدارة',
        'System Settings' => 'إعدادات النظام',
        'Quick Actions Manager' => 'مدير الإجراءات السريعة',
        'Loan Rules' => 'قواعد الإعارة',
        'Staff Profiles' => 'ملفات تعريف الموظفين',
        'Manage Notices' => 'إدارة الإشعارات',
        'Suggestions' => 'الاقتراحات',
        'Fine Rates' => 'أسعار الغرامات',
        'Backup & Restore' => 'النسخ الاحتياطي والاستعادة',
        'Utilities Suite' => 'مجموعة الأدوات',
        'Stock Verification' => 'جرد المخزون',
        'Lost & Damaged' => 'الكتب المفقودة والتالفة',
        'Payments' => 'المدفوعات',
        'Reservations' => 'الحجوزات',
        'Library Events' => 'فعاليات المكتبة',
        'Member Documents' => 'وثائق الأعضاء',
        'Computer Access' => 'الوصول إلى الحاسوب',
        'Data Import' => 'استيراد البيانات',
        'Entry/Exit' => 'الدخول/الخروج',
        'Session Logs' => 'سجلات الجلسات',
        'Communication' => 'التواصل',
        'Bulk Messaging' => 'رسائل جماعية SMS/WhatsApp',
        'Chatbot' => 'المساعد الآلي للمكتبة',
        'Reports & Analytics' => 'التقارير والتحليلات',
        'Reports' => 'التقارير',
        'Advanced Analytics' => 'التحليلات المتقدمة',
        'Cron' => 'المهام المجدولة Cron',
        'Public Interfaces' => 'الواجهات العامة',
        'OPAC' => 'الفهرس العام',
        'Digital Library Hub' => 'المركز الرقمي',
        'Self Kiosk' => 'الخدمة الذاتية',
        'Member Portal' => 'بوابة الأعضاء',
        'Multi‑Library' => 'المكتبات المتعددة',
        'Institutions' => 'المؤسسات',
        'API' => 'واجهة البرمجة API',
        'REST API' => 'REST API',
        'Account' => 'الحساب',
        'Pay Fines' => 'دفع الغرامات',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $key;
}

function isRTL() {
    global $lang;
    return $lang === 'ar';
}

function renderLanguageSwitcher() {
    global $lang;
    $flags = ['en' => 'English', 'hi' => 'हिन्दी', 'ar' => 'العربية'];
    $html = '<div class="dropdown d-inline-block">';
    $html .= '<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
    $html .= '<i class="fas fa-globe"></i> ' . strtoupper($lang);
    $html .= '</button>';
    $html .= '<ul class="dropdown-menu dropdown-menu-end">';
    foreach ($flags as $code => $label) {
        $active = ($code === $lang) ? ' active' : '';
        $html .= '<li><a class="dropdown-item' . $active . '" href="?lang=' . $code . '">' . $label . '</a></li>';
    }
    $html .= '</ul></div>';
    return $html;
}

// ==================== PROTECTED DESIGNER CREDIT ====================
$expectedCredit = '<div class="designer-credit">
                        <i class="fas fa-code"></i> Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer" class="designer-name">Sameermon</a>
                    </div>';

// ==================== DATABASE & SETTINGS ====================
$db = Database::getInstance()->getConnection();
$settings = getSettings();
$institution = getInstitution();

// ==================== IMPROVED LOGO HANDLING ====================
function getBase64Image($filepath) {
    if (empty($filepath)) return false;
    if (!file_exists($filepath)) return false;
    $data = @file_get_contents($filepath);
    if ($data === false) return false;
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    // Support for GIF and other image types
    $mime = match($ext) { 
        'png' => 'image/png', 
        'gif' => 'image/gif', 
        'webp' => 'image/webp', 
        'svg' => 'image/svg+xml', 
        'jpg', 'jpeg' => 'image/jpeg',
        default => 'image/jpeg' 
    };
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Enhanced staff photo function with multiple path attempts - GIF support
function getStaffPhotoBase64($photoPath) {
    if (empty($photoPath)) return '';
    
    $pathsToTry = [
        $photoPath,
        ROOT_PATH . '/' . ltrim($photoPath, '/'),
        ROOT_PATH . '/uploads/staff/' . basename($photoPath),
        ROOT_PATH . '/uploads/staff/' . $photoPath,
        str_replace('uploads/staff/', ROOT_PATH . '/uploads/staff/', $photoPath)
    ];
    
    foreach ($pathsToTry as $tryPath) {
        if (!empty($tryPath) && file_exists($tryPath)) {
            $ext = strtolower(pathinfo($tryPath, PATHINFO_EXTENSION));
            // Allow GIF, JPG, PNG, WEBP
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $data = @file_get_contents($tryPath);
                if ($data !== false) {
                    $mime = match($ext) {
                        'png' => 'image/png',
                        'gif' => 'image/gif',
                        'webp' => 'image/webp',
                        default => 'image/jpeg'
                    };
                    return 'data:' . $mime . ';base64,' . base64_encode($data);
                }
            }
        }
    }
    return '';
}

function getLogoUrl() {
    global $settings, $institution;
    
    // Priority 1: library_logo from general settings
    if (!empty($settings['library_logo'])) {
        $path = $settings['library_logo'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 2: opac_header_logo (fallback)
    if (!empty($settings['opac_header_logo'])) {
        $path = $settings['opac_header_logo'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 3: institution logo
    if (!empty($institution['logo_path'])) {
        $path = $institution['logo_path'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
        }
    }
    
    // Priority 4: common logo locations
    $commonPaths = [
        ROOT_PATH . '/SIS-logo.png',
        ROOT_PATH . '/logo.png',
        __DIR__ . '/SIS-logo.png',
        __DIR__ . '/logo.png',
        ROOT_PATH . '/uploads/logos/logo.png',
        ROOT_PATH . '/uploads/logo.png',
        ROOT_PATH . '/uploads/logos/logo.jpg',
        ROOT_PATH . '/uploads/logo.jpg',
    ];
    foreach ($commonPaths as $path) {
        if (file_exists($path)) {
            $base64 = getBase64Image($path);
            if ($base64) return $base64;
        }
    }
    
    // Priority 5: SVG fallback
    $primaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
    $colorHex = ltrim($primaryColor, '#');
    return 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="80" viewBox="0 0 200 80"%3E%3Crect width="200" height="80" fill="%23ffffff" rx="8"/%3E%3Ctext x="50%25" y="50%25" font-size="16" fill="%23' . $colorHex . '" text-anchor="middle" dy=".3em"%3E📚 Library%3C/text%3E%3C/svg%3E';
}

function getFaviconUrl() {
    global $settings;
    if (!empty($settings['favicon_path'])) {
        $path = $settings['favicon_path'];
        $cleanPath = ltrim($path, '/');
        $fullPath = ROOT_PATH . '/' . $cleanPath;
        if (file_exists($fullPath)) {
            $base64 = getBase64Image($fullPath);
            if ($base64) return $base64;
        }
        if (function_exists('getWebImageUrl')) {
            $url = getWebImageUrl($path);
            if ($url) return $url;
        }
    }
    return '';
}

$logoData = getLogoUrl();
$faviconPath = getFaviconUrl();

// ==================== STAFF PROFILES - FIXED ====================
$staffList = [];
if (!empty($settings['staff_display_enabled'])) {
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='staff_profiles'");
    if ($tableCheck->fetch()) {
        $stmt = $db->prepare("SELECT * FROM staff_profiles WHERE is_active = 1 ORDER BY sort_order ASC LIMIT 12");
        $stmt->execute();
        $staffList = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Process each staff member's photo individually
        foreach ($staffList as &$staff) {
            if (!empty($staff['photo_path'])) {
                $staff['photo_base64'] = getStaffPhotoBase64($staff['photo_path']);
            } else {
                $staff['photo_base64'] = '';
            }
        }
        unset($staff);
    }
}

// ==================== MAINTENANCE MODE ====================
$maintenanceMode = (int)($settings['site_maintenance_mode'] ?? 0);
$maintenanceMessage = $settings['maintenance_message'] ?? __('maintenance_body');
$whitelistIps = array_map('trim', explode(',', $settings['maintenance_whitelist_ips'] ?? ''));
$clientIp = $_SERVER['REMOTE_ADDR'] ?? '';
$isWhitelisted = in_array($clientIp, $whitelistIps);

if ($maintenanceMode && !isset($_SESSION['user_id']) && !$isWhitelisted) {
    header('HTTP/1.1 503 Service Unavailable');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'.__('maintenance_title').'</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f8f9fa;display:flex;align-items:center;min-height:100vh}</style></head><body><div class="container text-center"><div class="card shadow-lg mx-auto" style="max-width:500px"><div class="card-header bg-warning"><h4><i class="fas fa-tools"></i> '.__('maintenance_title').'</h4></div><div class="card-body"><p class="lead">' . htmlspecialchars($maintenanceMessage) . '</p><p class="text-muted">'.__('maintenance_body').'</p></div></div></div></body></html>';
    exit;
}

// ==================== LOGIN ====================
$authError = '';
if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $enable2fa = (int)($settings['enable_2fa'] ?? 0);
            if ($enable2fa && !empty($user['totp_secret'])) {
                $_SESSION['2fa_pending_user_id'] = $user['id'];
                $_SESSION['2fa_pending_username'] = $user['username'];
                $_SESSION['2fa_pending_fullname'] = $user['fullname'];
                $_SESSION['2fa_pending_role'] = $user['role'];
                $_SESSION['2fa_pending_secret'] = $user['totp_secret'];
                header("Location: admin/2fa_verify.php");
                exit;
            }
            // Complete login
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['login_time'] = time();
            $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?")->execute([$user['id']]);
            try {
                $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
                if ($tableCheck->fetch()) {
                    $stmtLog = $db->prepare("INSERT INTO session_logs (user_type, username, session_id, ip_address, user_agent) VALUES ('admin', ?, ?, ?, ?)");
                    $stmtLog->execute([$user['username'], session_id(), $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '']);
                }
            } catch (Exception $e) {}
            if (function_exists('logActivity')) logActivity($user['username'], 'LOGIN', 'User logged in successfully');
            header("Location: index.php");
            exit;
        } else {
            if (function_exists('logActivity')) logActivity($username, 'LOGIN_FAILED', 'Invalid credentials');
            $authError = __('invalid_credentials');
        }
    } catch (PDOException $e) { $authError = __('login_failed') . $e->getMessage(); }
}

if (isset($_GET['logout'])) {
    if (isset($_SESSION['username'])) {
        try {
            $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
            if ($tableCheck->fetch()) $db->prepare("UPDATE session_logs SET logout_time = CURRENT_TIMESTAMP WHERE session_id = ? AND logout_time IS NULL")->execute([session_id()]);
        } catch (Exception $e) {}
        if (function_exists('logActivity')) logActivity($_SESSION['username'], 'LOGOUT', 'User logged out');
    }
    session_destroy();
    header("Location: login.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?> - Login</title>
    <?php if ($faviconPath): ?>
        <link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>">
        <link rel="shortcut icon" href="<?= $faviconPath ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
            --gradient-primary: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>dd 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        html,body { height:100%; }
        body { font-family:'Inter',sans-serif; background:var(--gradient-primary); display:flex; flex-direction:column; overflow-y:auto; }
        body::before { content:''; position:fixed; width:200%; height:200%; top:-50%; left:-50%; background:radial-gradient(circle,rgba(255,255,255,0.05) 1%,transparent 1%); background-size:50px 50px; animation:shimmer 40s linear infinite; pointer-events:none; z-index:0; }
        @keyframes shimmer { 0%{transform:translate(0,0);} 100%{transform:translate(50px,50px);} }
        .main-container { flex:1 0 auto; width:100%; padding:20px 20px 0 20px; position:relative; z-index:2; display:flex; flex-direction:column; }
        .container { flex:1; display:flex; flex-direction:column; }
        .hero-section { flex-shrink:0; }
        .row { flex-shrink:0; }
        .footer { margin-top:auto; text-align:center; padding:20px; color:#f0f0f0; background:rgba(0,0,0,0.3); border-radius:40px; font-size:13px; backdrop-filter:blur(5px); flex-shrink:0; }
        .hero-title { font-size:2.5rem; font-weight:800; color:white; text-shadow:0 5px 20px rgba(0,0,0,0.25); margin-bottom:1rem; animation:zigzagZoomFade 1.2s cubic-bezier(0.2,0.9,0.4,1.1) forwards; white-space:nowrap; }
        @keyframes zigzagZoomFade { 0%{opacity:0;transform:translateX(-30px) scale(0.8) rotate(-2deg);letter-spacing:-2px;} 30%{opacity:0.7;transform:translateX(15px) scale(1.05) rotate(1deg);} 60%{opacity:0.9;transform:translateX(-8px) scale(0.98) rotate(-0.5deg);} 100%{opacity:1;transform:translateX(0) scale(1) rotate(0);letter-spacing:normal;} }
        @media (max-width:768px){ .hero-title{font-size:1.8rem;white-space:normal;} }
        .hero-subtitle { font-size:1.2rem; color:rgba(255,255,255,0.9); max-width:600px; margin:0 auto; opacity:0; animation:fadeInUp 0.8s ease 0.3s forwards; }
        @keyframes fadeInUp { from{opacity:0;transform:translateY(20px);} to{opacity:1;transform:translateY(0);} }
        .hero-logo { height:100px; width:auto; max-width:220px; object-fit:contain; margin-bottom:20px; filter:drop-shadow(0 8px 20px rgba(0,0,0,0.2)); animation:float 4s ease-in-out infinite; background:white; border-radius:20px; padding:12px; }
        @keyframes float { 0%,100%{transform:translateY(0);} 50%{transform:translateY(-10px);} }
        .login-card { background:rgba(255,255,255,0.98); border-radius:var(--radius-card); border:none; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); overflow:hidden; backdrop-filter:blur(4px); transition:transform 0.3s,box-shadow 0.3s; }
        .login-card:hover { transform:translateY(-5px); box-shadow:0 30px 60px -12px rgba(0,0,0,0.3); }
        .login-header { background:var(--gradient-primary); padding:30px; text-align:center; color:white; }
        .login-header i { font-size:48px; margin-bottom:15px; }
        .login-input { border:2px solid #e9ecef; border-radius:16px; padding:12px 18px; transition:all 0.3s; }
        .login-input:focus { border-color:var(--primary-color); box-shadow:0 0 0 3px rgba(var(--primary-rgb),0.1); }
        .login-btn { background:var(--gradient-primary); border:none; border-radius:40px; padding:12px; font-weight:600; transition:all 0.3s; }
        .login-btn:hover { transform:translateY(-2px); box-shadow:0 10px 20px -5px rgba(0,0,0,0.2); }
        
        /* ===== UPDATED STAFF CARDS - INCREASED IMAGE SIZE, 20% BORDER-RADIUS, GIF SUPPORT ===== */
        .staff-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }
        .staff-card { 
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 14px 10px 10px 10px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.2);
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            backdrop-filter: blur(4px);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 170px;
        }
        .staff-card:hover { 
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
            background: rgba(255,255,255,1);
        }
        .staff-img { 
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 20%;
            margin-bottom: 8px;
            border: 2px solid var(--primary-color);
            box-shadow: 0 3px 8px rgba(0,0,0,0.08);
            background: #f8f9fa;
            flex-shrink: 0;
        }
        .staff-name { 
            font-size: 0.85rem;
            font-weight: 600;
            color: #1a1a2e;
            line-height: 1.2;
            margin-bottom: 2px;
        }
        .staff-designation { 
            font-size: 0.7rem;
            color: #6c757d;
            line-height: 1.2;
        }
        .staff-placeholder {
            width: 80px;
            height: 80px;
            border-radius: 20%;
            margin-bottom: 8px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.4rem;
            flex-shrink: 0;
            border: 2px solid var(--primary-color);
        }
        
        /* Responsive adjustments */
        @media (max-width: 992px) {
            .staff-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 10px;
            }
            .staff-card {
                padding: 12px 8px 8px 8px;
                min-height: 150px;
                border-radius: 18px;
            }
            .staff-img, .staff-placeholder {
                width: 65px;
                height: 65px;
                font-size: 1.8rem;
            }
            .staff-name { font-size: 0.78rem; }
            .staff-designation { font-size: 0.65rem; }
        }
        
        @media (max-width: 768px) {
            .staff-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 8px;
            }
            .staff-card {
                padding: 10px 6px 6px 6px;
                min-height: 130px;
                border-radius: 16px;
            }
            .staff-img, .staff-placeholder {
                width: 55px;
                height: 55px;
                font-size: 1.5rem;
                border-width: 1.5px;
            }
            .staff-name { font-size: 0.7rem; }
            .staff-designation { font-size: 0.58rem; }
        }
        
        @media (max-width: 576px) {
            .staff-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 6px;
            }
            .staff-card {
                padding: 6px 4px 6px 4px;
                min-height: 110px;
                border-radius: 14px;
            }
            .staff-img, .staff-placeholder {
                width: 45px;
                height: 45px;
                font-size: 1.2rem;
                border-width: 1px;
                margin-bottom: 4px;
            }
            .staff-name { font-size: 0.6rem; }
            .staff-designation { font-size: 0.5rem; }
        }
        
        @media (max-width: 400px) {
            .staff-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 6px;
            }
            .staff-card {
                min-height: 95px;
                padding: 4px 3px;
                border-radius: 12px;
            }
            .staff-img, .staff-placeholder {
                width: 38px;
                height: 38px;
                font-size: 1rem;
                border-width: 1px;
            }
            .staff-name { font-size: 0.55rem; }
            .staff-designation { display: none; }
        }
        
        .designer-credit { margin-top:8px; font-size:11px; opacity:0.8; }
        .designer-name { color:#ffd966; font-weight:600; text-decoration:none; }
        .designer-name:hover { text-decoration:underline; color:#ffedaa; }
        .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--primary-dark); border-color: var(--primary-dark); }
        @media (max-width:768px){ .hero-logo{height:70px;} .hero-title{font-size:2rem;} }
        [dir="rtl"] .input-group > :not(:first-child):not(.dropdown-toggle):not(.dropdown-menu) { border-radius:0 16px 16px 0; }
        [dir="rtl"] .input-group > :not(:last-child):not(.dropdown-toggle):not(.dropdown-menu) { border-radius:16px 0 0 16px; }
        
        /* Dark mode support for staff cards */
        @media (prefers-color-scheme: dark) {
            .staff-card { background: rgba(45,45,68,0.95); border-color: rgba(58,58,90,0.5); }
            .staff-name { color: #e9ecef; }
            .staff-designation { color: #adb5bd; }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="container">
            <div class="d-flex justify-content-end mb-3">
                <?= renderLanguageSwitcher() ?>
            </div>
            <div class="hero-section text-center">
                <img src="<?= $logoData ?>" alt="Library Logo" class="hero-logo">
                <h1 class="hero-title"><?= __('welcome') ?> <?= htmlspecialchars($institution['name'] ?? $settings['software_header'] ?? 'Library ERP System') ?></h1>
                <p class="hero-subtitle"><?= __('subtitle') ?></p>
            </div>
            <div class="row g-4 mt-2">
                <div class="col-lg-6">
                    <div class="login-card">
                        <div class="login-header">
                            <i class="fas fa-lock"></i>
                            <h3><?= __('staff_login') ?></h3>
                        </div>
                        <div class="login-body p-4">
                            <?php if ($authError): ?>
                                <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($authError) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
                            <?php endif; ?>
                            <?php if (isset($_GET['timeout'])): ?>
                                <div class="alert alert-warning"><?= __('timeout_msg') ?></div>
                            <?php endif; ?>
                            <form method="post">
                                <div class="mb-3">
                                    <label class="form-label"><?= __('username') ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-transparent border-end-0"><i class="fas fa-user text-muted"></i></span>
                                        <input type="text" name="username" class="form-control login-input border-start-0" required autofocus>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><?= __('password') ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-transparent border-end-0"><i class="fas fa-lock text-muted"></i></span>
                                        <input type="password" name="password" class="form-control login-input border-start-0" required>
                                    </div>
                                </div>
                                <button type="submit" name="login" class="btn btn-primary w-100 login-btn"><i class="fas fa-sign-in-alt me-2"></i> <?= __('login') ?></button>
                            </form>
                            <div class="text-center mt-3">
                                <small class="text-muted"><i class="fas fa-shield-alt"></i> <?= __('secure_login') ?> <?= ($settings['enable_2fa'] ?? 0) ? '2FA' : __('password') ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <?php if (!empty($settings['staff_display_enabled']) && count($staffList) > 0): ?>
                        <div class="staff-grid">
                            <?php foreach ($staffList as $staff): ?>
                                <div class="staff-card">
                                    <?php if (!empty($staff['photo_base64'])): ?>
                                        <img src="<?= $staff['photo_base64'] ?>" class="staff-img" alt="<?= htmlspecialchars($staff['name']) ?>" loading="lazy">
                                    <?php else: ?>
                                        <div class="staff-placeholder">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="staff-name"><?= htmlspecialchars($staff['name']) ?></div>
                                    <div class="staff-designation"><?= htmlspecialchars($staff['designation']) ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center"><i class="fas fa-info-circle"></i> <?= __('no_staff_profiles') ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="footer">
                <div class="footer-content">
                    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. <?= __('footer_copyright') ?></p>
                    <?= $expectedCredit ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        setTimeout(function(){ 
            document.querySelectorAll('.alert').forEach(function(a){ 
                let bs = new bootstrap.Alert(a); 
                setTimeout(() => bs.close(), 5000); 
            }); 
        }, 3000);
    </script>
</body>
</html>