<?php

/**
 * Entry/Exit Log Viewer & Exporter
 * Version: 2.0 — Robust PDF export (mPDF → DomPDF → HTML fallback)
 * 
 * Features:
 * - Date range, Adm No, Category, Class/Dept, Division filters
 * - Pagination with configurable rows per page (10-500)
 * - CSV export (UTF-8 BOM for Excel)
 * - PDF export via mPDF → DomPDF → printable HTML fallback
 * - Full report settings integration (logo, watermark, signature, colors, font)
 * - CSRF protection for exports
 * - Fully compatible with existing db.php and functions.php
 */

declare(strict_types=1);

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ============================================================================
// LOAD COMPOSER AUTOLOADER — multi-path
// ============================================================================
$autoloadCandidates = [
    __DIR__ . '/../vendor/autoload.php',        // <root>/vendor/autoload.php
    __DIR__ . '/../../vendor/autoload.php',     // <docroot>/vendor/autoload.php
    __DIR__ . '/../../../vendor/autoload.php',
];
$composerLoaded = false;
foreach ($autoloadCandidates as $autoloadPath) {
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
        $composerLoaded = true;
        break;
    }
}

// ============================================================================
// CORE FALLBACKS
// ============================================================================
if (!function_exists('renderHeader')) {
    function renderHeader($title) {
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>' . htmlspecialchars($title) . '</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></head><body>';
    }
}
if (!function_exists('renderFooter')) {
    function renderFooter() {
        echo '</body></html>';
    }
}
if (!function_exists('formatDate')) {
    function formatDate($date) {
        if (empty($date)) return '';
        return date('d-m-Y', strtotime((string)$date));
    }
}
if (!function_exists('getWebImageUrl')) {
    function getWebImageUrl($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $baseUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost');
        return $baseUrl . '/' . ltrim($path, '/');
    }
}

// ============================================================================
// AUTH & DB
// ============================================================================
requireLogin();
$db = getDB();
$institution = getInstitution();
$settings = getSettings();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================================================
// REPORT APPEARANCE SETTINGS
// ============================================================================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

$reportFontSize         = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor     = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition     = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText    = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName    = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle   = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportFooterText       = $settings['report_footer_text'] ?? 'This is a system generated report';

// ============================================================================
// IMAGE HELPERS
// ============================================================================
function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    if (!defined('BASE_PATH')) {
        define('BASE_PATH', dirname(__DIR__));
    }
    $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    if (!file_exists($fullPath)) return '';
    $mime = @mime_content_type($fullPath) ?: 'image/jpeg';
    $data = @file_get_contents($fullPath);
    if ($data === false) return '';
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getReportLogo() {
    global $settings, $institution;
    $candidates = [
        $settings['report_logo']       ?? '',
        $settings['library_logo']      ?? '',
        $settings['opac_header_logo']  ?? '',
        $institution['logo_path']      ?? '',
    ];
    foreach ($candidates as $path) {
        $b64 = resolveImageToBase64($path);
        if ($b64) return $b64;
    }
    foreach (['uploads/logo.png','uploads/logo.jpg','uploads/logos/logo.png','uploads/logos/logo.jpg'] as $rel) {
        $full = BASE_PATH . '/' . $rel;
        if (file_exists($full)) {
            return resolveImageToBase64($rel);
        }
    }
    return '';
}

function getReportRightLogo() {
    global $settings;
    return resolveImageToBase64($settings['report_logo_right'] ?? '');
}

function getReportSignature() {
    global $settings;
    return resolveImageToBase64($settings['report_signature_image'] ?? '');
}

// ============================================================================
// INPUT SANITIZATION
// ============================================================================
$from     = $_GET['from']     ?? date('Y-m-d', strtotime('-7 days'));
$to       = $_GET['to']       ?? date('Y-m-d');
$admno    = trim($_GET['admno']    ?? '');
$category = $_GET['category'] ?? '';
$class    = $_GET['class']    ?? '';
$division = $_GET['division'] ?? '';
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = (int)($_GET['per_page'] ?? 50);
$validPerPage = [10, 25, 50, 100, 200, 500];
if (!in_array($perPage, $validPerPage, true)) $perPage = 50;

function validateDate(string $date, string $default): string {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return ($d && $d->format('Y-m-d') === $date) ? $date : $default;
}
$from = validateDate($from, date('Y-m-d', strtotime('-30 days')));
$to   = validateDate($to,   date('Y-m-d'));
if ($from > $to) [$from, $to] = [$to, $from];

// ============================================================================
// QUERY HELPERS
// ============================================================================
function buildFilterConditions(string $from, string $to, string $admno, string $category, string $class, string $division): array {
    $conditions = ["e.entry_date BETWEEN :from AND :to"];
    $params = [':from' => $from, ':to' => $to];
    if ($admno !== '') {
        $conditions[] = "e.admno LIKE :admno";
        $params[':admno'] = "%$admno%";
    }
    if ($category !== '' && $category !== 'all') {
        $conditions[] = "e.member_category = :category";
        $params[':category'] = $category;
    }
    if ($class !== '') {
        $conditions[] = "m.class = :class";
        $params[':class'] = $class;
    }
    if ($division !== '') {
        $conditions[] = "m.division = :division";
        $params[':division'] = $division;
    }
    return ['whereSql' => ' WHERE ' . implode(' AND ', $conditions), 'params' => $params];
}

function getTotalLogCount(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division): int {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $sql = "SELECT COUNT(*) FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno" . $filter['whereSql'];
    $stmt = $db->prepare($sql);
    $stmt->execute($filter['params']);
    return (int)$stmt->fetchColumn();
}

function fetchLogsPaginated(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division, int $page, int $perPage): array {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $offset = ($page - 1) * $perPage;
    $sql = "SELECT e.*, m.class, m.division 
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno" 
            . $filter['whereSql'] . 
            " ORDER BY e.entry_date DESC, e.entry_time DESC 
            LIMIT :limit OFFSET :offset";
    $stmt = $db->prepare($sql);
    foreach ($filter['params'] as $key => $val) {
        $stmt->bindValue($key, $val);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function fetchAllLogsForExport(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division): array {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $sql = "SELECT e.*, m.class, m.division 
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno" 
            . $filter['whereSql'] . 
            " ORDER BY e.entry_date DESC, e.entry_time DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($filter['params']);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function formatDurationHtml(?string $entryDate, string $entryTime, ?string $exitTime): string {
    if (!$exitTime) return '<span class="badge bg-success">Inside</span>';
    try {
        $entry = new DateTime($entryDate . ' ' . $entryTime);
        $exit  = new DateTime($entryDate . ' ' . $exitTime);
        $diff  = $entry->diff($exit);
        return $diff->format('%h hr %i min');
    } catch (Exception $e) {
        return 'Invalid';
    }
}

function formatDurationText(?string $entryDate, string $entryTime, ?string $exitTime): string {
    if (!$exitTime) return 'Inside';
    try {
        $entry = new DateTime($entryDate . ' ' . $entryTime);
        $exit  = new DateTime($entryDate . ' ' . $exitTime);
        $diff  = $entry->diff($exit);
        return $diff->format('%h hr %i min');
    } catch (Exception $e) {
        return 'Invalid';
    }
}

// ============================================================================
// CSV EXPORT
// ============================================================================
$exportType = $_GET['export'] ?? '';
if ($exportType === 'csv') {
    $token = $_GET['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        die('<div style="color:red;padding:20px;"><h2>Security Error</h2><p>Invalid CSRF token.</p><a href="?">Go back</a></div>');
    }
    $logs = fetchAllLogsForExport($db, $from, $to, $admno, $category, $class, $division);
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="entry_exit_log_' . date('Y-m-d') . '.csv"');
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // UTF-8 BOM
    fputcsv($output, ['Date', 'Entry Time', 'Exit Time', 'Adm No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Purpose', 'Duration']);
    foreach ($logs as $log) {
        $duration = formatDurationText($log['entry_date'], $log['entry_time'], $log['exit_time']);
        fputcsv($output, [
            $log['entry_date'], $log['entry_time'], $log['exit_time'] ?: 'Inside',
            $log['admno'], $log['member_name'], $log['member_category'],
            $log['class'] ?? '-', $log['division'] ?? '-', $log['purpose'], $duration
        ]);
    }
    fclose($output);
    exit;
}

// ============================================================================
// PDF HTML GENERATOR — full report settings integration
// ============================================================================
function generatePdfHtml(array $logs, array $institution, string $from, string $to, string $admno, string $category, string $class, string $division): string {
    global $reportFontSize, $reportPrimaryColor, $reportLogoPosition,
           $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity,
           $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle,
           $reportFooterText;

    $institutionName = htmlspecialchars($institution['name'] ?? 'Library System');
    $mainLogo        = getReportLogo();
    $rightLogo       = getReportRightLogo();

    $filterText = '';
    if ($admno)    $filterText .= ' | Adm No: '     . htmlspecialchars($admno);
    if ($category) $filterText .= ' | Category: '   . htmlspecialchars($category);
    if ($class)    $filterText .= ' | Class/Dept: ' . htmlspecialchars($class);
    if ($division) $filterText .= ' | Div/Course: ' . htmlspecialchars($division);

    $generatedDate = date('F j, Y g:i A');

    // ---- Build header block per logo position ----
    $logoImgStyle = 'height:60px; width:auto; object-fit:contain; background:white; padding:4px; border-radius:6px;';
    $headerBlock  = '<div style="text-align:center; margin-bottom:20px; border-bottom:2px solid ' . $reportPrimaryColor . '; padding-bottom:15px;">';

    if ($reportLogoPosition === 'both') {
        $headerBlock .= '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">';
        $headerBlock .= '<div>' . ($mainLogo  ? '<img src="' . $mainLogo  . '" style="' . $logoImgStyle . '">' : '') . '</div>';
        $headerBlock .= '<div style="text-align:center;">';
        $headerBlock .= '<div style="font-size:18px; font-weight:bold; color:' . $reportPrimaryColor . ';">' . $institutionName . '</div>';
        $headerBlock .= '<div style="font-size:16px; font-weight:bold;">Entry / Exit Log Report</div>';
        $headerBlock .= '</div>';
        $headerBlock .= '<div>' . ($rightLogo ? '<img src="' . $rightLogo . '" style="' . $logoImgStyle . '">' : '') . '</div>';
        $headerBlock .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $headerBlock .= '<div style="display:flex; align-items:center; justify-content:center; gap:20px;">';
        if ($mainLogo) $headerBlock .= '<img src="' . $mainLogo . '" style="' . $logoImgStyle . '">';
        $headerBlock .= '<div style="text-align:center;">';
        $headerBlock .= '<div style="font-size:18px; font-weight:bold; color:' . $reportPrimaryColor . ';">' . $institutionName . '</div>';
        $headerBlock .= '<div style="font-size:16px; font-weight:bold; margin:6px 0;">Entry / Exit Log Report</div>';
        $headerBlock .= '</div>';
        $headerBlock .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $headerBlock .= '<div style="display:flex; align-items:center; justify-content:center; gap:20px;">';
        $headerBlock .= '<div style="text-align:center;">';
        $headerBlock .= '<div style="font-size:18px; font-weight:bold; color:' . $reportPrimaryColor . ';">' . $institutionName . '</div>';
        $headerBlock .= '<div style="font-size:16px; font-weight:bold; margin:6px 0;">Entry / Exit Log Report</div>';
        $headerBlock .= '</div>';
        if ($mainLogo) $headerBlock .= '<img src="' . $mainLogo . '" style="' . $logoImgStyle . '">';
        $headerBlock .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $headerBlock .= '<img src="' . $mainLogo . '" style="' . $logoImgStyle . '; margin-bottom:10px;"><br>';
        $headerBlock .= '<div style="font-size:18px; font-weight:bold; color:' . $reportPrimaryColor . ';">' . $institutionName . '</div>';
        $headerBlock .= '<div style="font-size:16px; font-weight:bold; margin:6px 0;">Entry / Exit Log Report</div>';
    } else {
        $headerBlock .= '<div style="font-size:18px; font-weight:bold; color:' . $reportPrimaryColor . ';">' . $institutionName . '</div>';
        $headerBlock .= '<div style="font-size:16px; font-weight:bold; margin:6px 0;">Entry / Exit Log Report</div>';
    }

    $headerBlock .= '<div style="font-size:11px; margin-top:6px;"><strong>Period:</strong> ' . htmlspecialchars($from) . ' to ' . htmlspecialchars($to) . $filterText . '</div>';
    $headerBlock .= '<div style="font-size:10px; color:#666; margin-top:4px;"><strong>Generated:</strong> ' . $generatedDate . '</div>';
    $headerBlock .= '</div>';

    // ---- Build table rows ----
    $rowsHtml = '';
    $sn = 1;
    foreach ($logs as $log) {
        $duration    = formatDurationText($log['entry_date'], $log['entry_time'], $log['exit_time']);
        $exitDisplay = $log['exit_time'] ? htmlspecialchars($log['exit_time']) : '<span style="background:#28a745;color:white;padding:1px 6px;border-radius:8px;font-size:9px;">Inside</span>';
        $rowsHtml .= '<tr>'
            . '<td style="text-align:center;">' . $sn++ . '</td>'
            . '<td>' . htmlspecialchars(formatDate($log['entry_date'])) . '</td>'
            . '<td style="text-align:center;">' . htmlspecialchars($log['entry_time']) . '</td>'
            . '<td style="text-align:center;">' . $exitDisplay . '</td>'
            . '<td>' . htmlspecialchars($log['admno']) . '</td>'
            . '<td>' . htmlspecialchars($log['member_name']) . '</td>'
            . '<td>' . htmlspecialchars($log['member_category']) . '</td>'
            . '<td>' . htmlspecialchars($log['class'] ?? '-') . '</td>'
            . '<td>' . htmlspecialchars($log['division'] ?? '-') . '</td>'
            . '<td>' . htmlspecialchars($log['purpose']) . '</td>'
            . '<td style="text-align:center;">' . htmlspecialchars($duration) . '</td>'
            . '</tr>';
    }
    if (empty($rowsHtml)) {
        $rowsHtml = '<tr><td colspan="11" style="text-align:center; padding:20px; color:#999;">No records found</td></tr>';
    }

    // ---- Build signature block ----
    $signatureBlock = '';
    if ($reportSignatureEnabled) {
        $sigImg = getReportSignature();
        $signatureBlock = '<div style="margin-top:30px; text-align:right; border-top:1px solid #ddd; padding-top:15px;">';
        if ($sigImg) {
            $signatureBlock .= '<div><img src="' . $sigImg . '" style="max-height:50px;"></div>';
        }
        $signatureBlock .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $signatureBlock .= '<div style="font-size:9px; color:#777;">' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $signatureBlock .= '</div>';
    }

    // ---- Build watermark CSS ----
    $watermarkStyle = '';
    if ($reportWatermarkEnabled) {
        $wmText    = !empty($reportWatermarkText) ? $reportWatermarkText : ($institution['name'] ?? 'Library');
        $wmOpacity = $reportWatermarkOpacity / 100;
        $watermarkStyle = '<style>
            @media print {
                body:after {
                    content: "' . addslashes($wmText) . '";
                    position: fixed;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%) rotate(-45deg);
                    font-size: 60px;
                    color: rgba(0,0,0,' . $wmOpacity . ');
                    white-space: pre;
                    z-index: 9999;
                    pointer-events: none;
                    opacity: ' . $wmOpacity . ';
                }
            }
        </style>';
    }

    // ---- Assemble ----
    $html  = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Entry/Exit Log Report</title>';
    $html .= '<style>
        * { box-sizing: border-box; }
        body { font-family: "DejaVu Sans", sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; color: #212529; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #999; padding: 5px 6px; font-size: 9px; vertical-align: middle; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: left; }
        tbody tr:nth-child(even) { background-color: #f8f9fa; }
        .footer { text-align: center; margin-top: 25px; padding-top: 10px; border-top: 1px solid #ddd; font-size: 9px; color: #777; }
    </style>';
    $html .= $watermarkStyle;
    $html .= '</head><body>';

    $html .= $headerBlock;
    $html .= '<table>';
    $html .= '<thead><tr>'
           . '<th style="width:30px; text-align:center;">#</th>'
           . '<th>Date</th>'
           . '<th style="text-align:center;">Entry</th>'
           . '<th style="text-align:center;">Exit</th>'
           . '<th>Adm No</th>'
           . '<th>Name</th>'
           . '<th>Category</th>'
           . '<th>Class/Dept</th>'
           . '<th>Div/Course</th>'
           . '<th>Purpose</th>'
           . '<th style="text-align:center;">Duration</th>'
           . '</tr></thead>';
    $html .= '<tbody>' . $rowsHtml . '</tbody>';
    $html .= '<tfoot><tr>'
           . '<td colspan="10" style="text-align:right; font-weight:bold; background:#f0f0f0;">Total Records:</td>'
           . '<td style="text-align:center; font-weight:bold; background:#f0f0f0;">' . count($logs) . '</td>'
           . '</tr></tfoot>';
    $html .= '</table>';

    $html .= $signatureBlock;
    $html .= '<div class="footer">' . htmlspecialchars($reportFooterText) . '<br>&copy; ' . date('Y') . ' ' . $institutionName . '. All rights reserved.</div>';
    $html .= '</body></html>';

    return $html;
}

// ============================================================================
// PDF EXPORT — mPDF → DomPDF → printable HTML fallback
// ============================================================================
if ($exportType === 'pdf') {
    $token = $_GET['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        die('<div style="color:red;padding:20px;"><h2>Security Error</h2><p>Invalid CSRF token.</p><a href="?">Go back</a></div>');
    }

    $logs    = fetchAllLogsForExport($db, $from, $to, $admno, $category, $class, $division);
    $pdfHtml = generatePdfHtml($logs, $institution, $from, $to, $admno, $category, $class, $division);
    $filename = 'entry_exit_log_' . date('Y-m-d') . '.pdf';

    // Clean buffers
    while (ob_get_level()) ob_end_clean();

    // Attempt mPDF
    if ($composerLoaded && class_exists('Mpdf\\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode'              => 'utf-8',
                'format'            => 'A4-L',
                'default_font_size' => $reportFontSize,
                'default_font'      => 'dejavusans',
                'margin_left'       => 10,
                'margin_right'      => 10,
                'margin_top'        => 20,
                'margin_bottom'     => 15,
                'margin_header'     => 5,
                'margin_footer'     => 5,
                'tempDir'           => sys_get_temp_dir(),
            ]);
            $mpdf->SetTitle('Entry/Exit Log Report');
            $mpdf->SetAuthor($institution['name'] ?? 'Library System');
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($pdfHtml);

            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log('mPDF error in log.php: ' . $e->getMessage());
        }
    }

    // Attempt DomPDF
    if ($composerLoaded && class_exists('Dompdf\\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', 'A4');
            $options->set('defaultPaperOrientation', 'landscape');
            $options->set('fontDir', sys_get_temp_dir());
            $options->set('fontCache', sys_get_temp_dir());
            $options->set('tempDir', sys_get_temp_dir());

            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($pdfHtml);
            $dompdf->setPaper('A4', 'landscape');
            $dompdf->render();

            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $dompdf->output();
            exit;
        } catch (Exception $e) {
            error_log('DomPDF error in log.php: ' . $e->getMessage());
        }
    }

    // ---- Final fallback: printable HTML (never die()) ----
    $pathsTried = implode('<br>', array_map('htmlspecialchars', $autoloadCandidates));
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f8f9fa; }
        .toolbar { text-align: center; margin: 20px 0; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; color: white; }
        .btn-primary { background: #1e3c72; }
        .btn-secondary { background: #6c757d; }
        code { background: #e9ecef; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
        .debug { font-size: 12px; color: #6c757d; margin-top: 10px; }
    </style>';
    echo '</head><body>';
    echo '<div class="toolbar">';
    echo '<h2><i>⚠️ PDF generation libraries not available</i></h2>';
    echo '<p>Install mPDF or DomPDF via Composer:</p>';
    echo '<p><code>cd C:\\xampp\\htdocs\\library-system</code></p>';
    echo '<p><code>composer require mpdf/mpdf</code></p>';
    echo '<p><strong>Then restart Apache</strong> and reload this page.</p>';
    echo '<button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button>';
    echo '<button onclick="window.history.back()" class="btn btn-secondary">Go Back</button>';
    echo '<div class="debug"><strong>Autoload paths checked:</strong><br>' . $pathsTried . '<br>';
    echo '<strong>Composer loaded:</strong> ' . ($composerLoaded ? 'Yes' : 'No') . '<br>';
    echo '<strong>mPDF available:</strong> ' . (class_exists('Mpdf\\Mpdf') ? 'Yes' : 'No') . '<br>';
    echo '<strong>DomPDF available:</strong> ' . (class_exists('Dompdf\\Dompdf') ? 'Yes' : 'No') . '</div>';
    echo '</div>';
    echo $pdfHtml;
    echo '</body></html>';
    exit;
}

// ============================================================================
// MAIN VIEW
// ============================================================================
$totalRecords = getTotalLogCount($db, $from, $to, $admno, $category, $class, $division);
$totalPages   = ceil($totalRecords / $perPage);
$page         = min($page, $totalPages > 0 ? $totalPages : 1);
$logs         = fetchLogsPaginated($db, $from, $to, $admno, $category, $class, $division, $page, $perPage);

$categories = $db->query("SELECT DISTINCT member_category FROM entry_exit WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category")->fetchAll(PDO::FETCH_COLUMN);
$classes    = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions  = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

// Build export URLs without null keys
$baseParams = $_GET;
unset($baseParams['export'], $baseParams['csrf_token'], $baseParams['page'], $baseParams['per_page']);
$baseQuery  = http_build_query($baseParams);
$csvUrl     = '?' . ($baseQuery ? $baseQuery . '&' : '') . 'export=csv&csrf_token=' . urlencode($_SESSION['csrf_token']);
$pdfUrl     = '?' . ($baseQuery ? $baseQuery . '&' : '') . 'export=pdf&csrf_token=' . urlencode($_SESSION['csrf_token']);

renderHeader('Entry/Exit Log');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap">
        <h2><i class="fas fa-list"></i> Entry/Exit Log</h2>
        <div class="btn-group">
            <a href="<?= htmlspecialchars($csvUrl) ?>" class="btn btn-success"><i class="fas fa-file-csv"></i> Export CSV</a>
            <a href="<?= htmlspecialchars($pdfUrl) ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> Export PDF</a>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Entry/Exit</a>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Filter Logs</div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-2"><label class="form-label">From</label><input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>"></div>
                <div class="col-md-2"><label class="form-label">To</label><input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>"></div>
                <div class="col-md-2"><label class="form-label">Adm No</label><input type="text" name="admno" class="form-control" value="<?= htmlspecialchars($admno) ?>" placeholder="Search"></div>
                <div class="col-md-2"><label class="form-label">Category</label><select name="category" class="form-select"><option value="">All</option><?php foreach($categories as $cat): ?><option <?= $category===$cat?'selected':'' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><label class="form-label">Class/Dept</label><select name="class" class="form-select"><option value="">All</option><?php foreach($classes as $c): ?><option <?= $class===$c?'selected':'' ?>><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><label class="form-label">Div/Course</label><select name="division" class="form-select"><option value="">All</option><?php foreach($divisions as $d): ?><option <?= $division===$d?'selected':'' ?>><?= htmlspecialchars($d) ?></option><?php endforeach; ?></select></div>
                <div class="col-12"><button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply Filters</button> <a href="?" class="btn btn-outline-secondary"><i class="fas fa-undo"></i> Reset</a></div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
            <span><i class="fas fa-database"></i> Records (<?= $totalRecords ?> found)</span>
            <div><label class="me-2">Rows per page:</label><select class="form-select form-select-sm w-auto" id="perPageSelect"><?php foreach($validPerPage as $val): ?><option value="<?= $val ?>" <?= $perPage==$val?'selected':'' ?>><?= $val ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Date</th><th>Entry</th><th>Exit</th><th>AdmNo</th><th>Name</th>
                            <th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Purpose</th><th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($logs)): ?>
                            <tr><td colspan="10" class="text-center py-4">No records found.</td></tr>
                        <?php else: foreach($logs as $log): ?>
                            <tr>
                                <td><?= htmlspecialchars(formatDate($log['entry_date'])) ?></td>
                                <td><?= htmlspecialchars($log['entry_time']) ?></td>
                                <td><?= $log['exit_time'] ? htmlspecialchars($log['exit_time']) : '<span class="badge bg-success">Inside</span>' ?></td>
                                <td><?= htmlspecialchars($log['admno']) ?></td>
                                <td><?= htmlspecialchars($log['member_name']) ?></td>
                                <td><?= htmlspecialchars($log['member_category']) ?></td>
                                <td><?= htmlspecialchars($log['class'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($log['division'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($log['purpose']) ?></td>
                                <td><?= formatDurationHtml($log['entry_date'], $log['entry_time'], $log['exit_time']) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav><ul class="pagination justify-content-center mb-0">
                <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1, 'per_page'=>$perPage])) ?>">Previous</a></li>
                <?php for($i=max(1,$page-2); $i<=min($totalPages,$page+2); $i++): ?>
                <li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i, 'per_page'=>$perPage])) ?>"><?= $i ?></a></li>
                <?php endfor; ?>
                <li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1, 'per_page'=>$perPage])) ?>">Next</a></li>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('perPageSelect')?.addEventListener('change',function(){
    const u=new URL(window.location.href);
    u.searchParams.set('per_page',this.value);
    u.searchParams.set('page',1);
    window.location.href=u.toString();
});
</script>

<?php
$settings = getSettings();
?>
<footer class="footer mt-4 py-3 bg-light text-center border-top">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?>. All rights reserved.</p>
        <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
    </div>
</footer>
<?php renderFooter(); ?>