<?php
// entry_exit/test_pdf.php — DELETE AFTER DEBUGGING
require_once __DIR__ . '/../vendor/autoload.php';

echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>PDF Diagnostic</title>';
echo '<style>body{font-family:Consolas,monospace;margin:20px;background:#f8f9fa}table{border-collapse:collapse;max-width:1000px}h2{margin-top:20px;border-bottom:2px solid #1e3c72;padding-bottom:5px}th,td{border:1px solid #ddd;padding:6px 10px;text-align:left}code{background:#eef;padding:1px 5px}ok{color:green;font-weight:bold}bad{color:#c00;font-weight:bold}</style>';
echo '</head><body><h1>PDF Library Diagnostic</h1>';

// ============ 1. COMPOSER AUTOLOAD ============
echo '<h2>1. Composer Autoload</h2><table>';
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
echo '<tr><th>vendor/autoload.php</th><td>' . (file_exists($autoloadPath) ? '<ok>✔ exists</ok> (' . filesize($autoloadPath) . ' bytes)' : '<bad>✘ MISSING</bad>') . '</td></tr>';
echo '</table>';

// ============ 2. ACTUAL SOURCE FILES ============
echo '<h2>2. DomPDF Source Files on Disk</h2><table><tr><th>Path</th><th>Status</th></tr>';
$files = [
    'vendor/dompdf/dompdf/src/Dompdf.php',
    'vendor/dompdf/dompdf/src/Options.php',
    'vendor/dompdf/dompdf/src/Canvas.php',
    'vendor/dompdf/dompdf/lib/Cpdf.php',
    'vendor/masterminds/html5/src/HTML5.php',
    'vendor/sabberworm/php-css-parser/src/Parser.php',
];
foreach ($files as $rel) {
    $full = __DIR__ . '/../' . $rel;
    echo '<tr><td><code>' . htmlspecialchars($rel) . '</code></td><td>';
    if (file_exists($full)) {
        echo '<ok>✔ ' . number_format(filesize($full)) . ' bytes</ok>';
    } else {
        echo '<bad>✘ MISSING</bad>';
    }
    echo '</td></tr>';
}
echo '</table>';

// ============ 3. CLASS EXISTENCE ============
echo '<h2>3. Class Availability</h2><table>';
$classes = [
    'Dompdf\\Dompdf',
    'Dompdf\\Options',
    'Dompdf\\Canvas',
    'Dompdf\\Adapter\\CPDF',
    'Masterminds\\HTML5',
    'Sabberworm\\CSS\\Parser',
];
foreach ($classes as $class) {
    $found = class_exists($class);
    echo '<tr><td><code>' . htmlspecialchars($class) . '</code></td><td>' . ($found ? '<ok>✔ FOUND</ok>' : '<bad>✘ NOT FOUND</bad>') . '</td></tr>';
}
echo '</table>';

// ============ 4. REGISTERED AUTOLOADERS ============
echo '<h2>4. Registered Composer Autoloaders</h2>';
if (method_exists('Composer\\Autoload\\ClassLoader', 'getRegisteredLoaders')) {
    $loaders = \Composer\Autoload\ClassLoader::getRegisteredLoaders();
    echo '<p>Count: <strong>' . count($loaders) . '</strong></p><table><tr><th>Vendor Dir</th><th>Dompdf Prefix?</th><th>Resolved Path</th></tr>';
    foreach ($loaders as $dir => $loader) {
        $prefixes = $loader->getPrefixesPsr4();
        $hasDompdf = isset($prefixes['Dompdf\\']);
        echo '<tr><td><code>' . htmlspecialchars($dir) . '</code></td>';
        echo '<td>' . ($hasDompdf ? '<ok>✔ YES</ok>' : '<bad>✘ NO</bad>') . '</td>';
        echo '<td>';
        if ($hasDompdf) {
            foreach ($prefixes['Dompdf\\'] as $p) {
                echo '<code>' . htmlspecialchars($p) . '</code> ' . (is_dir($p) ? '<ok>(dir ✔)</ok>' : '<bad>(dir ✘)</bad>') . '<br>';
            }
        } else {
            echo '-';
        }
        echo '</td></tr>';
    }
    echo '</table>';
} else {
    echo '<p><bad>ClassLoader::getRegisteredLoaders() not available</bad></p>';
}

// ============ 5. INSTANTIATION TEST ============
echo '<h2>5. Live Instantiation Test</h2>';
if (class_exists('Dompdf\\Dompdf')) {
    try {
        $options = new \Dompdf\Options();
        $options->set('isHtml5ParserEnabled', true);
        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml('<h1>Hello from DomPDF</h1><p>If you see a PDF, it works!</p>');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        echo '<p><ok>✔ Dompdf instantiated AND rendered successfully!</ok></p>';
        echo '<p><a href="?download=1" target="_blank" style="display:inline-block;padding:10px 20px;background:#28a745;color:white;text-decoration:none;border-radius:6px;font-weight:bold;">Download Test PDF</a></p>';
        
        if (isset($_GET['download'])) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="dompdf_test.pdf"');
            echo $dompdf->output();
            exit;
        }
    } catch (Throwable $e) {
        echo '<p><bad>✘ Error: ' . htmlspecialchars($e->getMessage()) . '</bad></p>';
        echo '<p>File: <code>' . htmlspecialchars($e->getFile()) . ':' . $e->getLine() . '</code></p>';
    }
} else {
    echo '<p><bad>✘ Cannot instantiate — class not found</bad></p>';
}

// ============ 6. PHP INFO ============
echo '<h2>6. PHP Environment</h2><table>';
echo '<tr><th>PHP Version</th><td>' . PHP_VERSION . '</td></tr>';
echo '<tr><th>DOM Extension</th><td>' . (extension_loaded('dom') ? '<ok>✔ loaded</ok>' : '<bad>✘ MISSING — required by DomPDF</bad>') . '</td></tr>';
echo '<tr><th>MBString Extension</th><td>' . (extension_loaded('mbstring') ? '<ok>✔ loaded</ok>' : '<bad>✘ MISSING — required by DomPDF</bad>') . '</td></tr>';
echo '<tr><th>GD Extension</th><td>' . (extension_loaded('gd') ? '<ok>✔ loaded</ok>' : '<bad>✘ missing (images won\'t work)</bad>') . '</td></tr>';
echo '<tr><th>Iconv Extension</th><td>' . (extension_loaded('iconv') ? '<ok>✔ loaded</ok>' : '<bad>✘ MISSING — required by CSS parser</bad>') . '</td></tr>';
echo '</table>';

echo '</body></html>';