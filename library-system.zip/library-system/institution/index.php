<?php
/**
 * Institution Management - Complete Update
 * Features:
 * - Add, edit, delete institutions
 * - Set active institution
 * - Logo upload support
 * - CSRF protection
 * - Unified styling with settings bar
 * - Properly aligned report output
 * - Print-ready with clean formatting
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

$action = $_GET['action'] ?? 'list';
$editInstitution = null;

if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM institutions WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editInstitution = $stmt->fetch();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token. Please refresh and try again.", "danger");
        header("Location: index.php");
        exit;
    }

    try {
        $logoPath = '';
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logoPath = uploadFile($_FILES['logo'], LOGO_DIR, 'inst_logo');
        }
        
        if (isset($_POST['update_institution'])) {
            $sql = "UPDATE institutions SET name = ?, address = ?, contact = ?, email = ?, status = ?";
            $params = [$_POST['name'], $_POST['address'], $_POST['contact'], $_POST['email'], $_POST['status']];
            
            if ($logoPath) {
                $sql .= ", logo_path = ?";
                $params[] = $logoPath;
                // Delete old logo
                if ($editInstitution && $editInstitution['logo_path'] && file_exists($editInstitution['logo_path'])) {
                    unlink($editInstitution['logo_path']);
                }
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $_POST['id'];
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            showToast("Institution updated successfully", "success");
            // Regenerate CSRF token after successful action
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } elseif (isset($_POST['add_institution'])) {
            $stmt = $db->prepare("INSERT INTO institutions (name, address, contact, email, logo_path, status) VALUES (?, ?, ?, ?, ?, 'active')");
            $stmt->execute([$_POST['name'], $_POST['address'], $_POST['contact'], $_POST['email'], $logoPath]);
            showToast("Institution added successfully", "success");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        
        header("Location: index.php");
        exit;
        
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// Handle delete (with CSRF token check)
if (isset($_GET['delete'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: index.php");
        exit;
    }
    $stmt = $db->prepare("DELETE FROM institutions WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    showToast("Institution deleted", "success");
    header("Location: index.php");
    exit;
}

// Handle set active institution
if (isset($_GET['set_active'])) {
    $db->prepare("UPDATE settings SET current_institution_id = ? WHERE id = 1")->execute([$_GET['set_active']]);
    showToast("Active institution changed", "success");
    header("Location: index.php");
    exit;
}

$institutions = $db->query("SELECT * FROM institutions ORDER BY name")->fetchAll();
$currentInstitutionId = $settings['current_institution_id'] ?? 1;

renderHeader('Institution Management');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Institution Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        
        body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; }
        
        /* ===== SETTINGS BAR - UNIFIED ===== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        @media (max-width: 768px) {
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        /* ===== CARDS ===== */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card-header {
            border-radius: 12px 12px 0 0 !important;
            background: var(--primary-color);
            color: white;
        }
        .card-header i {
            margin-right: 8px;
        }
        
        /* ===== TABLE ===== */
        .table th {
            background: var(--primary-color);
            color: white;
            white-space: nowrap;
            padding: 10px 12px;
        }
        .table td {
            vertical-align: middle;
            padding: 10px 12px;
        }
        .table tr.table-success td {
            background: #d4edda;
        }
        .table .logo-cell img {
            height: 40px;
            width: auto;
            max-width: 60px;
            object-fit: contain;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            padding: 2px;
            background: white;
        }
        
        /* ===== MODAL ===== */
        .modal-header {
            background: var(--primary-color);
            color: white;
            border-radius: 12px 12px 0 0 !important;
        }
        .modal-header .btn-close {
            filter: invert(1);
        }
        
        /* ===== FOOTER ===== */
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 30px; 
            border-radius: 16px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .table th, .table td { padding: 6px 8px; font-size: 0.85rem; }
            .table .logo-cell img { height: 30px; max-width: 40px; }
            .btn-group-sm .btn { font-size: 0.6rem; padding: 2px 6px; }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .card-header { background: #f8f9fa !important; color: #333 !important; }
            .table th { background: #e9ecef !important; color: #333 !important; }
            .table td, .table th { border: 1px solid #ddd !important; }
            .table .logo-cell img { border: 1px solid #ddd !important; }
            .btn { display: none !important; }
            .modal { display: none !important; }
            .table-success td { background: #f8f9fa !important; }
            .badge { border: 1px solid #ddd !important; }
            .badge.bg-primary { background: #e9ecef !important; color: #333 !important; border: 1px solid #ddd !important; }
            .badge.bg-success { background: #d4edda !important; color: #155724 !important; border: 1px solid #ddd !important; }
            .badge.bg-secondary { background: #e9ecef !important; color: #333 !important; border: 1px solid #ddd !important; }
            .footer { border-top: 1px solid #ddd !important; }
            h2 { color: #333 !important; }
            .modal-backdrop { display: none !important; }
            .modal { display: none !important; }
            .btn-group { display: none !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-3">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-building me-2"></i> Institution Management</h2>
            <p class="text-muted mb-0">Manage library institutions, set active institution, and configure institution details</p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="../index.php" class="btn btn-primary btn-sm">
                <i class="fas fa-home"></i> Back to Home
            </a>
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addInstitutionModal">
                <i class="fas fa-plus"></i> Add Institution
            </button>
        </div>
    </div>

    <!-- ===== SETTINGS BAR - UNIFIED ===== -->
    <div class="settings-bar no-print">
        <div class="settings-items-wrap">
            <span class="settings-label"><i class="fas fa-sliders-h"></i> Report Settings:</span>
            <span class="settings-item"><i class="fas fa-font"></i> Font: <?= $reportFontSize ?>px</span>
            <span class="settings-item"><i class="fas fa-palette"></i> Primary: <?= $reportPrimaryColor ?></span>
            <?php if($reportWatermarkEnabled): ?>
                <span class="settings-item"><i class="fas fa-water"></i> Watermark: <?= $reportWatermarkText ?: 'Enabled' ?></span>
            <?php endif; ?>
            <?php if($reportSignatureEnabled): ?>
                <span class="settings-item"><i class="fas fa-signature"></i> Signature: <?= $reportSignatureName ?></span>
            <?php endif; ?>
            <span class="settings-item"><i class="fas fa-flag"></i> Footer: <?= $reportFooterText ?></span>
        </div>
        <a href="#" onclick="window.print();" class="no-print"><i class="fas fa-print"></i> Print Report</a>
    </div>

    <!-- ===== ALERT MESSAGES ===== -->
    <?php if (isset($_SESSION['toast'])): ?>
        <div class="alert alert-<?= $_SESSION['toast']['type'] ?> alert-dismissible fade show no-print">
            <?= $_SESSION['toast']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>

    <!-- ===== INSTITUTIONS LIST ===== -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-list"></i> Registered Institutions
                    <span class="badge bg-light text-dark ms-2"><?= count($institutions) ?></span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width:60px;">Logo</th>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>Contact</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th style="width:100px;">Active</th>
                                    <th style="width:100px;" class="no-print">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($institutions)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-building fa-2x mb-2 d-block"></i>
                                        No institutions found. Add your first institution!
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php foreach ($institutions as $inst): ?>
                                <tr class="<?= $inst['id'] == $currentInstitutionId ? 'table-success' : '' ?>">
                                    <td class="logo-cell">
                                        <?php if ($inst['logo_path'] && file_exists($inst['logo_path'])): ?>
                                            <img src="<?= htmlspecialchars($inst['logo_path']) ?>" alt="Logo">
                                        <?php else: ?>
                                            <i class="fas fa-building fa-2x text-muted"></i>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($inst['name']) ?></strong>
                                        <?php if ($inst['id'] == $currentInstitutionId): ?>
                                            <span class="badge bg-primary ms-1"><i class="fas fa-check"></i> Current</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($inst['address'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($inst['contact'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($inst['email'] ?? '-') ?></td>
                                    <td>
                                        <span class="badge <?= $inst['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= ucfirst($inst['status'] ?? 'inactive') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($inst['id'] == $currentInstitutionId): ?>
                                            <span class="badge bg-primary"><i class="fas fa-check"></i> Current</span>
                                        <?php else: ?>
                                            <a href="?set_active=<?= $inst['id'] ?>" class="btn btn-sm btn-outline-primary no-print">Set Active</a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="no-print">
                                        <div class="btn-group btn-group-sm">
                                            <a href="?edit=<?= $inst['id'] ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                                            <a href="?delete=<?= $inst['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-danger" onclick="return confirm('Delete this institution?')" title="Delete"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if (!empty($institutions)): ?>
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between small text-muted">
                        <span><i class="fas fa-check-circle text-success"></i> <?= count(array_filter($institutions, fn($i) => $i['status'] === 'active')) ?> Active</span>
                        <span><i class="fas fa-circle text-secondary"></i> <?= count(array_filter($institutions, fn($i) => $i['status'] === 'inactive')) ?> Inactive</span>
                        <span><i class="fas fa-building text-primary"></i> Total: <?= count($institutions) ?></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ===== ADD INSTITUTION MODAL ===== -->
<div class="modal fade no-print" id="addInstitutionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus"></i> Add New Institution</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="fw-semibold">Institution Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., Central Library, State University">
                    </div>
                    <div class="mb-3">
                        <label class="fw-semibold">Address</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="Full address of the institution"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Contact Number</label>
                            <input type="text" name="contact" class="form-control" placeholder="Phone number">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Email address">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="fw-semibold">Logo</label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                        <small class="text-muted">Supported: JPG, PNG, GIF, WEBP. Max size: 2MB</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_institution" class="btn btn-primary">Add Institution</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($editInstitution): ?>
<!-- ===== EDIT INSTITUTION MODAL ===== -->
<div class="modal fade show no-print" id="editInstitutionModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Institution</h5>
                <a href="index.php" class="btn-close"></a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $editInstitution['id'] ?>">
                    <div class="mb-3">
                        <label class="fw-semibold">Institution Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editInstitution['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fw-semibold">Address</label>
                        <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($editInstitution['address'] ?? '') ?></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Contact Number</label>
                            <input type="text" name="contact" class="form-control" value="<?= htmlspecialchars($editInstitution['contact'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editInstitution['email'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="fw-semibold">Status</label>
                        <select name="status" class="form-select">
                            <option value="active" <?= ($editInstitution['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= ($editInstitution['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="fw-semibold">Logo (leave empty to keep current)</label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                        <?php if ($editInstitution['logo_path'] && file_exists($editInstitution['logo_path'])): ?>
                            <div class="mt-2">
                                <img src="<?= htmlspecialchars($editInstitution['logo_path']) ?>" style="height: 50px; border: 1px solid #ddd; border-radius: 4px; padding: 2px;">
                                <br><small class="text-muted">Current logo</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_institution" class="btn btn-primary">Update Institution</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ===== FOOTER ===== -->
<div class="container-fluid px-4 mt-4">
    <div class="footer">
        <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        <p class="small text-muted mb-0"><?= htmlspecialchars($reportFooterText) ?></p>
       
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php renderFooter(); ?>