<?php
/**
 * Guest Photo Setup — one-click fixer
 * URL: /admin/guest_photo_setup.php
 * DELETE this file after use.
 */
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$results = [];

// 1. file_uploads status (report only — cannot fix in PHP)
$results[] = [
    'item'   => 'PHP extension: file_uploads',
    'status' => filter_var(ini_get('file_uploads'), FILTER_VALIDATE_BOOLEAN) ? 'ok' : 'fail',
    'note'   => 'Must be set in php.ini (file_uploads = On), then restart Apache.'
];

// 2. Create uploads/guest_photos/
$dir = UPLOAD_DIR . 'guest_photos/';
if (!is_dir($dir)) @mkdir($dir, 0777, true);
$results[] = [
    'item'   => 'Directory: uploads/guest_photos/',
    'status' => (is_dir($dir) && is_writable($dir)) ? 'ok' : 'fail',
    'note'   => is_dir($dir)
                ? ($dir . (is_writable($dir) ? ' — writable ✔' : ' — EXISTS but NOT writable'))
                : 'Could not create — check folder permissions'
];

// 3-4. Settings columns
try {
    $cols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach (['guest_photo_retention_days' => 30, 'guest_photo_max_size_kb' => 500] as $c => $v) {
        if (!in_array($c, $cols)) {
            try {
                $db->exec("ALTER TABLE settings ADD COLUMN $c INTEGER DEFAULT $v");
                $results[] = ['item' => "settings.$c", 'status' => 'fixed', 'note' => "Added with default $v"];
            } catch (Exception $e) {
                $results[] = ['item' => "settings.$c", 'status' => 'fail', 'note' => $e->getMessage()];
            }
        } else {
            $results[] = ['item' => "settings.$c", 'status' => 'ok', 'note' => 'Column already present'];
        }
        try {
            $db->exec("UPDATE settings SET $c = $v WHERE id=1 AND ($c IS NULL OR TRIM(CAST($c AS TEXT))='')");
        } catch (Exception $e) {}
    }
} catch (Exception $e) {
    $results[] = ['item' => 'settings columns', 'status' => 'fail', 'note' => $e->getMessage()];
}

// 5. entry_exit.photo_path
try {
    $eeCols = $db->query("PRAGMA table_info(entry_exit)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('photo_path', $eeCols)) {
        $db->exec("ALTER TABLE entry_exit ADD COLUMN photo_path TEXT DEFAULT NULL");
        $results[] = ['item' => 'entry_exit.photo_path', 'status' => 'fixed', 'note' => 'Column added'];
    } else {
        $results[] = ['item' => 'entry_exit.photo_path', 'status' => 'ok', 'note' => 'Column already present'];
    }
} catch (Exception $e) {
    $results[] = ['item' => 'entry_exit.photo_path', 'status' => 'fail', 'note' => $e->getMessage()];
}

if (function_exists('clearSettingsCache')) clearSettingsCache();
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Guest Photo Setup</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>body{background:#f0f2f5;padding:30px}.card{border-radius:16px;border:none;box-shadow:0 4px 20px rgba(0,0,0,.08)}</style>
</head><body>
<div class="container" style="max-width:820px;">
    <div class="card">
        <div class="card-header" style="background:linear-gradient(135deg,#193b77,#2a5298);color:#fff;border-radius:16px 16px 0 0;padding:16px 22px;">
            <h4 class="mb-0"><i class="fas fa-camera me-2"></i> Guest Photo Setup — Auto-Fix Results</h4>
        </div>
        <div class="card-body p-4">
            <table class="table align-middle">
                <thead><tr><th>Item</th><th style="width:100px;">Status</th><th>Note</th></tr></thead>
                <tbody>
                <?php foreach ($results as $r):
                    $cls = $r['status']==='ok' ? 'success' : ($r['status']==='fixed' ? 'info' : 'danger');
                    $icon = $r['status']==='ok' ? 'check-circle' : ($r['status']==='fixed' ? 'wrench' : 'times-circle');
                ?>
                    <tr>
                        <td><code><?= htmlspecialchars($r['item']) ?></code></td>
                        <td><span class="badge bg-<?= $cls ?>"><i class="fas fa-<?= $icon ?> me-1"></i><?= ucfirst($r['status']) ?></span></td>
                        <td class="small text-muted"><?= htmlspecialchars($r['note']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <?php if (!filter_var(ini_get('file_uploads'), FILTER_VALIDATE_BOOLEAN)): ?>
            <div class="alert alert-danger">
                <h6><i class="fas fa-exclamation-triangle me-2"></i>Action required: Enable <code>file_uploads</code></h6>
                <p class="mb-2">This is a <strong>PHP INI setting</strong> — it cannot be changed from PHP code.</p>
                <ol class="mb-0 small">
                    <li>Open <code>C:\xampp\php\php.ini</code> in Notepad</li>
                    <li>Find the line <code>file_uploads = Off</code> (or remove the <code>;</code> from <code>;file_uploads = On</code>)</li>
                    <li>Change it to: <code>file_uploads = On</code></li>
                    <li>Save the file</li>
                    <li><strong>Restart Apache</strong> from the XAMPP Control Panel</li>
                    <li>Reload this page — the badge should turn green</li>
                </ol>
                <hr>
                <p class="small mb-0"><strong>Note:</strong> Guest photo capture itself will work even without <code>file_uploads</code> — it uses base64 POST, not multipart uploads. But <em>admin image uploads</em> (logo, favicon, member photos) will fail until this is fixed.</p>
            </div>
            <?php endif; ?>

            <a href="settings.php" class="btn btn-primary"><i class="fas fa-arrow-left me-1"></i> Back to Settings</a>
            <a href="guest_photo_setup.php" class="btn btn-outline-secondary"><i class="fas fa-sync-alt me-1"></i> Re-run</a>
        </div>
    </div>
</div>
</body></html>