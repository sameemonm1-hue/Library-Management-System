<?php
require_once '../config/db.php';
require_once '../config/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

$db = Database::getInstance()->getConnection();
$userId = $_SESSION['user_id'];
$message = '';
$error = '';

// Fetch current user data
$stmt = $db->prepare("SELECT id, username, fullname, email, role FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // User not found, logout
    session_destroy();
    header('Location: ../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Change Username
    if (isset($_POST['change_username'])) {
        $newUsername = trim($_POST['new_username']);
        if (empty($newUsername)) {
            $error = "Username cannot be empty.";
        } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $newUsername)) {
            $error = "Username must be 3-20 characters, letters/numbers/underscore only.";
        } else {
            // Check uniqueness
            $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $check->execute([$newUsername, $userId]);
            if ($check->fetch()) {
                $error = "Username already taken. Choose another.";
            } else {
                $update = $db->prepare("UPDATE users SET username = ? WHERE id = ?");
                if ($update->execute([$newUsername, $userId])) {
                    $_SESSION['username'] = $newUsername;
                    $message = "Username changed successfully.";
                    $user['username'] = $newUsername;
                } else {
                    $error = "Database error. Please try again.";
                }
            }
        }
    }
    
    // Change Password
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'] ?? '';
        $newPass = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        // Validate inputs
        if (empty($current) || empty($newPass) || empty($confirm)) {
            $error = "All password fields are required.";
        } else {
            $passStmt = $db->prepare("SELECT password FROM users WHERE id = ?");
            $passStmt->execute([$userId]);
            $hash = $passStmt->fetchColumn();
            
            if (!password_verify($current, $hash)) {
                $error = "Current password is incorrect.";
            } elseif (strlen($newPass) < 6) {
                $error = "New password must be at least 6 characters.";
            } elseif ($newPass !== $confirm) {
                $error = "New passwords do not match.";
            } else {
                $newHash = password_hash($newPass, PASSWORD_DEFAULT);
                $update = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
                if ($update->execute([$newHash, $userId])) {
                    $message = "Password changed successfully.";
                } else {
                    $error = "Database error. Could not change password.";
                }
            }
        }
    }
    
    // Update Full Name
    if (isset($_POST['update_fullname'])) {
        $newFullname = trim($_POST['new_fullname'] ?? '');
        if (empty($newFullname)) {
            $error = "Full name cannot be empty.";
        } else {
            $update = $db->prepare("UPDATE users SET fullname = ? WHERE id = ?");
            if ($update->execute([$newFullname, $userId])) {
                $_SESSION['fullname'] = $newFullname;
                $message = "Full name updated successfully.";
                $user['fullname'] = $newFullname;
            } else {
                $error = "Database error. Please try again.";
            }
        }
    }
    
    // Update Email
    if (isset($_POST['update_email'])) {
        $newEmail = trim($_POST['new_email'] ?? '');
        if (empty($newEmail)) {
            $error = "Email cannot be empty.";
        } elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } else {
            // Check uniqueness
            $check = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ? AND email != ''");
            $check->execute([$newEmail, $userId]);
            if ($check->fetch()) {
                $error = "Email already in use by another account.";
            } else {
                $update = $db->prepare("UPDATE users SET email = ? WHERE id = ?");
                if ($update->execute([$newEmail, $userId])) {
                    $message = "Email updated successfully.";
                    $user['email'] = $newEmail;
                } else {
                    $error = "Database error. Please try again.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
            --gradient-primary: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>dd 100%);
        }
        * { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        body { background: #f4f6f9; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .profile-card { 
            max-width: 650px; 
            width: 100%;
            background: white; 
            border-radius: 24px; 
            box-shadow: 0 20px 60px rgba(0,0,0,0.12); 
            padding: 40px;
            transition: all 0.3s ease;
            border: 1px solid rgba(0,0,0,0.03);
        }
        .profile-card:hover {
            box-shadow: 0 25px 70px rgba(0,0,0,0.15);
        }
        .profile-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f2f5;
        }
        .profile-avatar {
            width: 70px;
            height: 70px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 28px;
            flex-shrink: 0;
        }
        .profile-header h2 {
            color: var(--primary-color);
            margin: 0;
            font-weight: 700;
        }
        .profile-header .subtitle {
            color: #6c757d;
            margin: 0;
            font-size: 0.9rem;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            color: white;
        }
        .btn-warning {
            background: var(--gradient-primary);
            border: none;
            color: white;
        }
        .btn-warning:hover {
            opacity: 0.9;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.3);
        }
        .btn-secondary {
            background: #e9ecef;
            border: none;
            color: #212529;
        }
        .btn-secondary:hover {
            background: #dee2e6;
            color: #212529;
        }
        .section-title { 
            color: var(--primary-color); 
            font-weight: 600;
            font-size: 1.1rem;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title i {
            font-size: 1.2rem;
        }
        .divider {
            border-top: 2px solid #f0f2f5;
            margin: 25px 0;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #f8f9fa;
        }
        .info-row .label { color: #6c757d; font-weight: 500; }
        .info-row .value { font-weight: 500; }
        .role-badge {
            background: var(--gradient-primary);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        @media (max-width: 576px) {
            .profile-card { padding: 20px; }
            .profile-header { flex-direction: column; text-align: center; }
            .profile-avatar { width: 60px; height: 60px; font-size: 24px; }
        }
        @media print {
            .settings-bar { display: none !important; }
            .profile-card { box-shadow: none; border: 1px solid #ddd; }
            .btn { display: none !important; }
        }
    </style>
</head>
<body>
<div class="profile-card">
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="profile-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div>
            <h2>My Profile</h2>
            <p class="subtitle">Manage your account settings</p>
        </div>
    </div>

    <!-- User Info -->
    <div class="info-row">
        <span class="label"><i class="fas fa-user-tag me-2"></i>Role</span>
        <span><span class="role-badge"><?= htmlspecialchars($user['role'] ?? 'Staff') ?></span></span>
    </div>
    <div class="info-row">
        <span class="label"><i class="fas fa-user me-2"></i>Full Name</span>
        <span class="value"><?= htmlspecialchars($user['fullname'] ?? 'N/A') ?></span>
    </div>
    <div class="info-row">
        <span class="label"><i class="fas fa-user me-2"></i>Username</span>
        <span class="value"><?= htmlspecialchars($user['username'] ?? 'N/A') ?></span>
    </div>
    <div class="info-row">
        <span class="label"><i class="fas fa-envelope me-2"></i>Email</span>
        <span class="value"><?= htmlspecialchars($user['email'] ?? 'Not set') ?></span>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3">
            <i class="fas fa-check-circle me-2"></i><?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show mt-3">
            <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Update Full Name -->
    <div class="divider"></div>
    <div class="section-title"><i class="fas fa-user-edit"></i> Update Full Name</div>
    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">New Full Name</label>
            <input type="text" name="new_fullname" class="form-control" 
                   value="<?= htmlspecialchars($user['fullname'] ?? '') ?>" 
                   required placeholder="Enter your full name">
        </div>
        <button type="submit" name="update_fullname" class="btn btn-primary w-100">
            <i class="fas fa-save me-2"></i>Update Full Name
        </button>
    </form>

    <!-- Change Username -->
    <div class="divider"></div>
    <div class="section-title"><i class="fas fa-user-tag"></i> Change Username</div>
    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">New Username</label>
            <input type="text" name="new_username" class="form-control" 
                   required pattern="[A-Za-z0-9_]{3,20}" 
                   title="3-20 characters, letters/numbers/underscore only"
                   placeholder="Enter new username">
            <small class="text-muted">3-20 characters, letters, numbers, and underscore only.</small>
        </div>
        <button type="submit" name="change_username" class="btn btn-primary w-100">
            <i class="fas fa-save me-2"></i>Change Username
        </button>
    </form>

    <!-- Change Password -->
    <div class="divider"></div>
    <div class="section-title"><i class="fas fa-key"></i> Change Password</div>
    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">Current Password</label>
            <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">New Password</label>
            <input type="password" name="new_password" class="form-control" required minlength="6">
            <small class="text-muted">Minimum 6 characters.</small>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">Confirm New Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" name="change_password" class="btn btn-warning w-100">
            <i class="fas fa-key me-2"></i>Change Password
        </button>
    </form>

    <!-- Update Email -->
    <div class="divider"></div>
    <div class="section-title"><i class="fas fa-envelope"></i> Update Email</div>
    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">New Email Address</label>
            <input type="email" name="new_email" class="form-control" 
                   value="<?= htmlspecialchars($user['email'] ?? '') ?>" 
                   required placeholder="Enter your email address">
            <small class="text-muted">Enter a valid email address.</small>
        </div>
        <button type="submit" name="update_email" class="btn btn-primary w-100">
            <i class="fas fa-save me-2"></i>Update Email
        </button>
    </form>

    <!-- Back Button -->
    <div class="divider"></div>
    <a href="dashboard.php" class="btn btn-secondary w-100">
        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
    </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        document.querySelectorAll('.alert').forEach(function(alert) {
            let bsAlert = new bootstrap.Alert(alert);
            setTimeout(function() {
                bsAlert.close();
            }, 5000);
        });
    }, 1000);
</script>
</body>
</html>