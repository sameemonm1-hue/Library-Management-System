<?php
/**
 * Kiosk environment diagnostic — Windows / XAMPP / PHP 8.2
 * Open in browser, delete when done.
 */
header('Content-Type: text/html; charset=utf-8');
$root = dirname(__DIR__);

echo "<!DOCTYPE html><html><head><title>Diagnostic</title>";
echo "<style>body{font-family:Consolas,monospace;margin:20px;background:#f8f9fa;font-size:14px}
table{border-collapse:collapse;width:100%;max-width:1000px;background:#fff}
th,td{border:1px solid #ddd;padding:6px 10px;text-align:left;vertical-align:top}
.ok{color:#0a7;font-weight:bold}.fail{color:#c00;font-weight:bold}.warn{color:#c70;font-weight:bold}
h2{margin-top:28px;border-bottom:2px solid #193b77;padding-bottom:4px}
code{background:#eef;padding:1px 4px}</style></head><body>";

echo "<h1>Kiosk Diagnostic — " . htmlspecialchars(php_uname('s') . ' ' . php_uname('r')) . "</h1>";
echo "<p><strong>PHP:</strong> " . PHP_VERSION . " &nbsp;|&nbsp; ";
echo "<strong>SAPI:</strong> " . php_sapi_name() . " &nbsp;|&nbsp; ";
echo "<strong>OS:</strong> " . PHP_OS . "</p>";

// ============ 1. REQUIRED EXTENSIONS ============
echo "<h2>1. Required PHP Extensions</h2>";
$required = [
    'pdo_sqlite'   => 'Database',
    'fileinfo'     => 'MIME detection (guest photo capture)',
    'gd'           => 'Image resize (logo upload)',
    'zip'          => 'Backup compression',
    'openssl'      => 'Settings encryption',
    'mbstring'     => 'Unicode',
    'json'         => 'Settings JSON',
    'session'      => 'Sessions',
    'file_uploads' => 'File uploads',
];
echo "<table><tr><th>Extension</th><th>Status</th><th>Purpose</th></tr>";
foreach ($required as $ext => $why) {
    $on = extension_loaded($ext);
    $cls = $on ? 'ok' : 'fail';
    $txt = $on ? '✔ loaded' : '✘ MISSING';
    echo "<tr><td><code>$ext</code></td><td class='$cls'>$txt</td><td>$why</td></tr>";
}
echo "</table>";
echo "<p><em>Enable missing ones in <code>php.ini</code> by removing the <code>;</code> in front of <code>extension=$ext</code> and restart Apache.</em></p>";

// ============ 2. CRITICAL FUNCTIONS ============
echo "<h2>2. Critical Functions</h2>";
$funcs = ['finfo_open','finfo_buffer','finfo_close','mime_content_type',
          'imagecreatefromjpeg','imagejpeg','imagecreatefrompng','imagepng',
          'session_start','password_hash','openssl_encrypt',
          'curl_init','file_get_contents','mkdir'];
echo "<table><tr><th>Function</th><th>Available</th></tr>";
foreach ($funcs as $f) {
    $on = function_exists($f);
    echo "<tr><td><code>$f</code></td><td class='" . ($on ? 'ok' : 'fail') . "'>" . ($on ? '✔' : '✘') . "</td></tr>";
}
echo "</table>";

// ============ 3. DIRECTORIES ============
echo "<h2>3. Directory Writable Check</h2>";
$dirs = [
    'uploads'                    => $root . '/uploads',
    'uploads/guest_photos'       => $root . '/uploads/guest_photos',
    'uploads/logos'              => $root . '/uploads/logos',
    'uploads/members'            => $root . '/uploads/members',
    'uploads/book_exit_photos'   => $root . '/uploads/book_exit_photos',
    'backups'                    => $root . '/backups',
    'cache'                      => $root . '/cache',
    'temp/reports'               => $root . '/temp/reports',
];
echo "<table><tr><th>Directory</th><th>Exists</th><th>Writable</th><th>Test Write</th><th>Path</th></tr>";
foreach ($dirs as $label => $path) {
    $exists = is_dir($path);
    $writable = $exists && is_writable($path);
    $testWrite = '—';
    if ($exists && $writable) {
        $probe = $path . DIRECTORY_SEPARATOR . '.probe_' . uniqid() . '.tmp';
        $ok = @file_put_contents($probe, 'x') !== false;
        if ($ok) @unlink($probe);
        $testWrite = $ok ? "<span class='ok'>✔ OK</span>" : "<span class='fail'>✘ FAIL</span>";
    } elseif (!$exists) {
        $testWrite = "<span class='warn'>— (missing)</span>";
    } else {
        $testWrite = "<span class='fail'>✘ NOT WRITABLE</span>";
    }
    echo "<tr><td>$label</td>";
    echo "<td class='" . ($exists ? 'ok' : 'fail') . "'>" . ($exists ? '✔' : '✘') . "</td>";
    echo "<td class='" . ($writable ? 'ok' : 'fail') . "'>" . ($writable ? '✔' : '✘') . "</td>";
    echo "<td>$testWrite</td>";
    echo "<td><code>" . htmlspecialchars($path) . "</code></td></tr>";
}
echo "</table>";
echo "<p><em>On Windows/XAMPP: right-click the <code>uploads</code> folder → Properties → Security → "
   . "give <code>SYSTEM</code> and <code>Users</code> <strong>Full control</strong>. "
   . "This is the #1 cause of guest photo failures.</em></p>";

// ============ 4. DATABASE ============
echo "<h2>4. Database</h2>";
$dbFile = $root . '/library_erp.db';
echo "<table>";
echo "<tr><th>DB file</th><td><code>" . htmlspecialchars($dbFile) . "</code></td></tr>";
echo "<tr><th>Exists</th><td class='" . (file_exists($dbFile) ? 'ok' : 'fail') . "'>" . (file_exists($dbFile) ? '✔' : '✘') . "</td></tr>";
echo "<tr><th>Writable</th><td class='" . (is_writable($dbFile) ? 'ok' : 'fail') . "'>" . (is_writable($dbFile) ? '✔' : '✘') . "</td></tr>";
if (file_exists($dbFile)) {
    echo "<tr><th>Size</th><td>" . number_format(filesize($dbFile)) . " bytes</td></tr>";
}
echo "</table>";

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $settingsCols = $pdo->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $eeCols = $pdo->query("PRAGMA table_info(entry_exit)")->fetchAll(PDO::FETCH_COLUMN, 1);

    $checks = [
        'settings.enable_webcam_capture' => in_array('enable_webcam_capture', $settingsCols),
        'settings.guest_photo_retention_days' => in_array('guest_photo_retention_days', $settingsCols),
        'settings.guest_photo_max_size_kb' => in_array('guest_photo_max_size_kb', $settingsCols),
        'entry_exit.photo_path' => in_array('photo_path', $eeCols),
    ];
    echo "<table><tr><th>Schema check</th><th>Status</th></tr>";
    foreach ($checks as $label => $ok) {
        echo "<tr><td><code>$label</code></td><td class='" . ($ok ? 'ok' : 'fail') . "'>" . ($ok ? '✔' : '✘ MISSING') . "</td></tr>";
    }
    echo "</table>";
    if (!in_array('photo_path', $eeCols)) {
        echo "<p class='fail'>Run this once:<br><code>ALTER TABLE entry_exit ADD COLUMN photo_path TEXT DEFAULT NULL;</code></p>";
    }

    $row = $pdo->query("SELECT enable_webcam_capture FROM settings WHERE id=1")->fetch(PDO::FETCH_ASSOC);
    echo "<p><strong>Webcam setting:</strong> <code>enable_webcam_capture = "
       . htmlspecialchars((string)($row['enable_webcam_capture'] ?? 'NULL'))
       . "</code> " . (!empty($row['enable_webcam_capture']) ? "<span class='ok'>(ON)</span>" : "<span class='warn'>(OFF — guests won't be photographed)</span>")
       . "</p>";
} catch (Exception $e) {
    echo "<p class='fail'>DB error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// ============ 5. GLOBAL FINFO TEST ============
echo "<h2>5. finfo_* behaviour (the PHP 8.2 killer)</h2>";
if (function_exists('finfo_open')) {
    $f = @finfo_open(FILEINFO_MIME_TYPE);
    if ($f === false) {
        echo "<p class='fail'>✘ <code>finfo_open()</code> returned <strong>false</strong>. "
           . "On PHP 8.2 any subsequent <code>finfo_buffer(false, ...)</code> call throws a <code>TypeError</code> → HTTP 500.</p>";
        echo "<p><strong>Fix:</strong> enable <code>extension=fileinfo</code> in <code>php.ini</code>, "
           . "OR keep the hardened patches below (they don't require finfo).</p>";
    } else {
        $mime = @finfo_buffer($f, "test");
        @finfo_close($f);
        echo "<p class='ok'>✔ <code>finfo_open()</code> works, sample mime = <code>" . htmlspecialchars((string)$mime) . "</code></p>";
    }
} else {
    echo "<p class='fail'>✘ <code>finfo_open()</code> not available at all.</p>";
}

// ============ 6. UPLOAD LIMITS ============
echo "<h2>6. Upload / Session Limits</h2>";
echo "<table>";
echo "<tr><th>upload_max_filesize</th><td>" . ini_get('upload_max_filesize') . "</td></tr>";
echo "<tr><th>post_max_size</th><td>" . ini_get('post_max_size') . "</td></tr>";
echo "<tr><th>max_execution_time</th><td>" . ini_get('max_execution_time') . "s</td></tr>";
echo "<tr><th>memory_limit</th><td>" . ini_get('memory_limit') . "</td></tr>";
echo "<tr><th>session.save_path</th><td><code>" . htmlspecialchars(ini_get('session.save_path') ?: '(system default)') . "</code></td></tr>";
echo "<tr><th>session writable</th><td>" . (
    (session_start() && session_status() === PHP_SESSION_ACTIVE)
    ? "<span class='ok'>✔</span>"
    : "<span class='fail'>✘</span>"
) . "</td></tr>";
echo "</table>";

// ============ 7. CAMERA / HTTPS ============
echo "<h2>7. Camera (getUserMedia) context</h2>";
$host = $_SERVER['HTTP_HOST'] ?? '';
$isLocalhost = preg_match('/^(localhost|127\.0\.0\.1|::1)(:\d+)?$/', $host);
$isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
echo "<table>";
echo "<tr><th>You are accessing</th><td><code>" . htmlspecialchars($host) . "</code></td></tr>";
echo "<tr><th>HTTPS</th><td class='" . ($isHttps ? 'ok' : 'warn') . "'>" . ($isHttps ? '✔' : '✘ (HTTP)') . "</td></tr>";
echo "<tr><th>Localhost</th><td class='" . ($isLocalhost ? 'ok' : 'warn') . "'>" . ($isLocalhost ? '✔' : '✘ (LAN IP)') . "</td></tr>";
echo "<tr><th>Camera allowed?</th><td>" .
     (($isHttps || $isLocalhost) ? "<span class='ok'>✔ browser WILL allow</span>" :
      "<span class='fail'>✘ browser WILL BLOCK (need HTTPS or localhost)</span>") . "</td></tr>";
echo "</table>";
echo "<p><em>If you need LAN access, install a self-signed cert (XAMPP ships <code>makecert.bat</code>) "
   . "or use <a href='https://ngrok.com/' target='_blank'>ngrok</a> to get an HTTPS tunnel.</em></p>";

echo "<hr><p><strong>Done.</strong> Delete this file after troubleshooting.</p>";
echo "</body></html>";