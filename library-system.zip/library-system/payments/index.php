<?php
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyCode = $settings['currency_code'] ?? 'USD';

$member_filter = $_GET['member'] ?? '';
$type_filter = $_GET['type'] ?? '';
$from_date = $_GET['from'] ?? '';
$to_date = $_GET['to'] ?? '';

$sql = "SELECT pt.*, m.name as member_name, m.admno 
        FROM payment_transactions pt
        LEFT JOIN members m ON pt.member_admno = m.admno
        WHERE 1=1";
$params = [];

if ($member_filter) {
    $sql .= " AND (pt.member_admno LIKE ? OR m.name LIKE ?)";
    $like = "%$member_filter%";
    $params[] = $like;
    $params[] = $like;
}
if ($type_filter) {
    $sql .= " AND pt.payment_type = ?";
    $params[] = $type_filter;
}
if ($from_date) {
    $sql .= " AND DATE(pt.payment_date) >= ?";
    $params[] = $from_date;
}
if ($to_date) {
    $sql .= " AND DATE(pt.payment_date) <= ?";
    $params[] = $to_date;
}
$sql .= " ORDER BY pt.payment_date DESC, pt.id DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

$total = array_sum(array_column($payments, 'amount'));

function getCurrencySymbolHelper($currencyCode, $defaultSymbol = '$') {
    $symbols = [
        'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'JPY' => '¥',
        'INR' => '₹', 'CNY' => '¥', 'CAD' => 'C$', 'AUD' => 'A$',
        'CHF' => 'Fr', 'SEK' => 'kr', 'NZD' => 'NZ$', 'MXN' => 'Mex$',
        'SGD' => 'S$', 'HKD' => 'HK$', 'NOK' => 'kr', 'KRW' => '₩',
        'TRY' => '₺', 'RUB' => '₽', 'BRL' => 'R$', 'ZAR' => 'R'
    ];
    return $symbols[strtoupper($currencyCode)] ?? $defaultSymbol;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Transactions - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; min-height: 100vh; }
        .settings-bar { display: none !important; }
        .content-wrapper { padding: 30px; }
        .filter-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .table-card { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .footer { 
            text-align: center; 
            padding: 25px 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 30px; 
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .footer .footer-divider {
            width: 60px;
            height: 2px;
            background: linear-gradient(to right, var(--primary-color), #6c757d);
            margin: 12px auto;
            border-radius: 2px;
        }
        .footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s;
        }
        .footer a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }
        .footer .footer-heart {
            color: #dc3545;
            display: inline-block;
            animation: heartPulse 1.5s ease infinite;
        }
        @keyframes heartPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }
        .btn-home { margin-left: 10px; }
        
        .stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            border: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card h6 { color: rgba(255,255,255,0.9); }
        .stat-card h3 { color: white; }
        .stat-card .opacity-50 { color: rgba(255,255,255,0.5); }
        
        .badge-type {
            font-size: 11px;
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 500;
        }
        .receipt-no {
            font-family: monospace;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .table thead th {
            background: var(--primary-color);
            color: white;
            border-bottom: none;
        }
        
        @media print { 
            .filter-card, .btn, .footer { display: none; } 
            .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .stat-card h6 { color: #555 !important; }
            .stat-card h3 { color: #333 !important; }
            .table thead th { background: #333 !important; color: white !important; }
        }
    </style>
</head>
<body>
<div class="main-content">
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 style="color: var(--primary-color);"><i class="fas fa-money-bill-wave me-2"></i> Payment Transactions</h2>
                <div class="no-print">
                    <a href="add.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Payment</a>
                    <a href="reports.php" class="btn btn-info btn-sm text-white"><i class="fas fa-chart-bar"></i> Reports</a>
                    <a href="../index.php" class="btn btn-secondary btn-sm btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0">Total Collected</h6>
                                    <h3 class="mb-0"><?= $currencySymbol ?> <?= number_format($total, 2) ?></h3>
                                </div>
                                <i class="fas fa-coins fa-2x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0">Total Transactions</h6>
                                    <h3 class="mb-0"><?= number_format(count($payments)) ?></h3>
                                </div>
                                <i class="fas fa-receipt fa-2x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0">Average Payment</h6>
                                    <h3 class="mb-0"><?= $currencySymbol ?> <?= number_format(count($payments) > 0 ? $total / count($payments) : 0, 2) ?></h3>
                                </div>
                                <i class="fas fa-chart-line fa-2x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-0">Fine Payments</h6>
                                    <h3 class="mb-0"><?= $currencySymbol ?> <?= number_format(array_sum(array_column(array_filter($payments, function($p) { return $p['payment_type'] == 'fine'; }), 'amount')), 2) ?></h3>
                                </div>
                                <i class="fas fa-exclamation-triangle fa-2x opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="filter-card no-print">
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Member (AdmNo/Name)</label>
                        <input type="text" name="member" class="form-control" value="<?= htmlspecialchars($member_filter) ?>" placeholder="Search by admission number or name...">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">Payment Type</label>
                        <select name="type" class="form-select">
                            <option value="">All</option>
                            <option value="fine" <?= $type_filter=='fine'?'selected':'' ?>>Fine</option>
                            <option value="deposit" <?= $type_filter=='deposit'?'selected':'' ?>>Security Deposit</option>
                            <option value="lost_fee" <?= $type_filter=='lost_fee'?'selected':'' ?>>Lost Book Fee</option>
                            <option value="donation" <?= $type_filter=='donation'?'selected':'' ?>>Donation</option>
                            <option value="membership_fee" <?= $type_filter=='membership_fee'?'selected':'' ?>>Membership Fee</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">From Date</label>
                        <input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from_date) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">To Date</label>
                        <input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to_date) ?>">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2"><i class="fas fa-search"></i> Filter</button>
                        <a href="index.php" class="btn btn-secondary">Reset</a>
                        <button type="button" class="btn btn-success ms-2" onclick="window.location.href='export.php?<?= http_build_query($_GET) ?>'"><i class="fas fa-file-excel"></i> Export</button>
                    </div>
                </form>
            </div>
            
            <div class="table-card">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Receipt No.</th>
                                <th>Date</th>
                                <th>Member</th>
                                <th>Type</th>
                                <th class="text-end">Amount</th>
                                <th class="text-center">Method</th>
                                <th>Reference</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($payments) == 0): ?>
                                <tr><td colspan="8" class="text-center py-5">
                                    <i class="fas fa-inbox fa-3x mb-3 d-block text-muted"></i>
                                    No payment transactions found.
                                 </td></tr>
                            <?php else: ?>
                                <?php foreach ($payments as $p): 
                                    $paymentCurrency = $p['currency'] ?? $currencyCode;
                                    $paymentSymbol = getCurrencySymbolHelper($paymentCurrency, $currencySymbol);
                                    
                                    $typeBadgeClass = [
                                        'fine' => 'danger',
                                        'deposit' => 'success',
                                        'lost_fee' => 'warning',
                                        'donation' => 'info',
                                        'membership_fee' => 'primary'
                                    ];
                                    $badgeClass = $typeBadgeClass[$p['payment_type']] ?? 'secondary';
                                ?>
                                    <tr>
                                        <td class="receipt-no"><?= htmlspecialchars($p['receipt_no'] ?? 'N/A') ?></td>
                                        <td><?= date('d-m-Y', strtotime($p['payment_date'])) ?></td>
                                        <td>
                                            <strong><?= htmlspecialchars($p['member_name'] ?? 'Deleted Member') ?></strong><br>
                                            <small class="text-muted"><?= htmlspecialchars($p['member_admno']) ?></small>
                                         </td>
                                        <td>
                                            <span class="badge bg-<?= $badgeClass ?> bg-opacity-10 text-dark px-3 py-2 rounded-pill">
                                                <?= ucfirst(str_replace('_', ' ', $p['payment_type'])) ?>
                                            </span>
                                         </td>
                                        <td class="text-end fw-bold text-success"><?= $paymentSymbol ?> <?= number_format($p['amount'], 2) ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-secondary bg-opacity-10 text-dark">
                                                <i class="fas <?= $p['payment_method'] == 'cash' ? 'fa-money-bill' : ($p['payment_method'] == 'card' ? 'fa-credit-card' : ($p['payment_method'] == 'online' ? 'fa-globe' : 'fa-building')) ?>"></i>
                                                <?= ucfirst($p['payment_method']) ?>
                                            </span>
                                         </td>
                                        <td><?= htmlspecialchars($p['reference_id'] ?? '-') ?></td>
                                        <td class="text-center">
                                            <div class="btn-group btn-group-sm">
                                                <a href="receipt.php?id=<?= $p['id'] ?>" class="btn btn-outline-secondary" target="_blank" title="Print Receipt">
                                                    <i class="fas fa-print"></i>
                                                </a>
                                                <?php if ($_SESSION['role'] == 'admin'): ?>
                                                    <a href="edit.php?id=<?= $p['id'] ?>" class="btn btn-outline-primary" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="delete.php?id=<?= $p['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-outline-danger" title="Delete" onclick="return confirm('Delete this payment? This action cannot be undone.')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                         </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <?php if (count($payments) > 0): ?>
                        <tfoot class="table-light">
                            <tr class="fw-bold">
                                <td colspan="4" class="text-end">Total:</td>
                                <td colspan="4" class="text-end"><?= $currencySymbol ?> <?= number_format($total, 2) ?> <?= $currencyCode ?></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="container">
    <div class="footer">
        <p class="mb-1">&copy; <?= date('Y') ?> <strong><?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></strong>. All rights reserved.</p>
        <div class="footer-divider"></div>
        <p class="small mt-2 mb-0 opacity-75 no-print">
            Designed with <span class="footer-heart"><i class="fas fa-heart"></i></span> by 
            <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">
                <i class="fab fa-linkedin"></i> Sameermon
            </a>
        </p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>