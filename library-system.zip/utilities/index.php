<?php
/**
 * Library Utilities Suite – Complete Functional Version
 * ID Cards | Barcodes & Labels | ISBN Metadata (Pro) | PDF Toolbox | Shelf/Spine Labels | Export/Import
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireLogin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== ENSURE REQUIRED COLUMNS EXIST ====================
$columns = $db->query("PRAGMA table_info(members)")->fetchAll(PDO::FETCH_COLUMN, 1);
$memberCols = ['designation', 'academic_year', 'phone', 'email', 'member_category', 'class', 'division'];
foreach ($memberCols as $col) {
    if (!in_array($col, $columns)) {
        try { $db->exec("ALTER TABLE members ADD COLUMN $col TEXT DEFAULT ''"); } catch (PDOException $e) {}
    }
}

$settingsColumns = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
$neededSettings = ['right_logo_path', 'isbndb_api_key', 'worldcat_api_key', 'google_books_api_key', 'openlibrary_api_key'];
foreach ($neededSettings as $col) {
    if (!in_array($col, $settingsColumns)) {
        try { $db->exec("ALTER TABLE settings ADD COLUMN $col TEXT DEFAULT ''"); } catch (PDOException $e) {}
    }
}

// ==================== HELPER FUNCTIONS ====================
if (!function_exists('getMemberPhotoUrl')) {
    function getMemberPhotoUrl($photoPath) {
        if (empty($photoPath)) return '';
        if (filter_var($photoPath, FILTER_VALIDATE_URL)) return $photoPath;
        $cleanPath = ltrim($photoPath, '/');
        if (strpos($cleanPath, 'uploads/') !== 0) {
            $cleanPath = 'uploads/members/' . basename($cleanPath);
        }
        return getWebImageUrl($cleanPath);
    }
}

if (!function_exists('autoResizeImage')) {
    function autoResizeImage($source, $dest, $maxWidth, $maxHeight, $quality = 85) {
        if (!function_exists('imagecreatefromjpeg')) return false;
        $info = getimagesize($source);
        if (!$info) return false;
        $src = null;
        switch ($info['mime']) {
            case 'image/jpeg': $src = imagecreatefromjpeg($source); break;
            case 'image/png': $src = imagecreatefrompng($source); break;
            case 'image/gif': $src = imagecreatefromgif($source); break;
            default: return false;
        }
        if (!$src) return false;
        $origW = imagesx($src);
        $origH = imagesy($src);
        $ratio = min($maxWidth / $origW, $maxHeight / $origH);
        $newW = (int)($origW * $ratio);
        $newH = (int)($origH * $ratio);
        $newImg = imagecreatetruecolor($newW, $newH);
        imagecopyresampled($newImg, $src, 0, 0, 0, 0, $newW, $newH, $origW, $origH);
        $ext = strtolower(pathinfo($dest, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') imagejpeg($newImg, $dest, $quality);
        elseif ($ext === 'png') imagepng($newImg, $dest, 9);
        elseif ($ext === 'gif') imagegif($newImg, $dest);
        imagedestroy($src); imagedestroy($newImg);
        return true;
    }
}

// ==================== AJAX ENDPOINTS ====================
// 1. Get member photo as base64
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] == 'get_photo_base64') {
    header('Content-Type: application/json');
    $admno = $_GET['admno'] ?? '';
    if (empty($admno)) { echo json_encode(['success' => false, 'error' => 'No admission number']); exit; }
    $stmt = $db->prepare("SELECT photo_path FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $photoPath = $stmt->fetchColumn();
    if (empty($photoPath)) { echo json_encode(['success' => false, 'error' => 'No photo']); exit; }
    $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
    if (!file_exists($fullPath)) { echo json_encode(['success' => false, 'error' => 'File not found']); exit; }
    $mime = mime_content_type($fullPath);
    $data = file_get_contents($fullPath);
    $base64 = 'data:' . $mime . ';base64,' . base64_encode($data);
    echo json_encode(['success' => true, 'base64' => $base64]);
    exit;
}

// 2. Books by date range
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] == 'books_by_date') {
    header('Content-Type: application/json');
    $from = $_GET['from'] ?? ''; $to = $_GET['to'] ?? '';
    if ($from && $to) {
        $stmt = $db->prepare("SELECT barcode, title, author, call_number, publisher, isbn FROM books WHERE created_at BETWEEN ? AND ? ORDER BY created_at DESC LIMIT 500");
        $stmt->execute([$from . ' 00:00:00', $to . ' 23:59:59']);
        echo json_encode(['success' => true, 'books' => $stmt->fetchAll()]);
    } else echo json_encode(['success' => false, 'error' => 'Invalid date range']);
    exit;
}

// 3. Bulk fetch books by barcodes
if (isset($_POST['ajax_action']) && $_POST['ajax_action'] == 'books_by_barcodes') {
    header('Content-Type: application/json');
    $barcodes = json_decode($_POST['barcodes'] ?? '[]', true);
    if (!empty($barcodes)) {
        $placeholders = implode(',', array_fill(0, count($barcodes), '?'));
        $stmt = $db->prepare("SELECT barcode, title, author, call_number, publisher, isbn FROM books WHERE barcode IN ($placeholders)");
        $stmt->execute($barcodes);
        echo json_encode(['success' => true, 'books' => $stmt->fetchAll()]);
    } else echo json_encode(['success' => false, 'books' => []]);
    exit;
}

// 4. All books (for selection)
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] == 'all_books') {
    header('Content-Type: application/json');
    echo json_encode($db->query("SELECT barcode, title, author FROM books ORDER BY title LIMIT 200")->fetchAll());
    exit;
}

// 5. Bulk import books
if (isset($_POST['ajax_action']) && $_POST['ajax_action'] == 'bulk_import_books') {
    header('Content-Type: application/json');
    $books = json_decode($_POST['books_data'] ?? '[]', true);
    $added = 0; $failed = 0;
    foreach ($books as $b) {
        if (empty($b['barcode']) || empty($b['title'])) continue;
        try {
            $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, isbn, call_number, category, pages, description, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([$b['barcode'], $b['title'], $b['author']??'', $b['publisher']??'', $b['isbn']??'', $b['call_number']??'', $b['category']??'', $b['pages']??null, $b['description']??'']);
            $added++;
        } catch (Exception $e) { $failed++; }
    }
    echo json_encode(['success' => true, 'added' => $added, 'failed' => $failed]);
    exit;
}

// 6. Update member photo (AJAX)
if (isset($_POST['ajax_update_photo'])) {
    header('Content-Type: application/json');
    $admno = trim($_POST['admno'] ?? '');
    if (empty($admno)) { echo json_encode(['success' => false, 'error' => 'Member admission number missing']); exit; }
    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) { echo json_encode(['success' => false, 'error' => 'Upload error']); exit; }
    $file = $_FILES['photo'];
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    if (!in_array($file['type'], $allowed)) { echo json_encode(['success' => false, 'error' => 'Invalid file type']); exit; }
    if (!is_dir(MEMBER_PHOTO_DIR)) mkdir(MEMBER_PHOTO_DIR, 0777, true);
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'member_' . $admno . '_' . time() . '.' . $ext;
    $targetPath = MEMBER_PHOTO_DIR . $filename;
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        chmod($targetPath, 0644);
        if (function_exists('imagecreatefromjpeg')) autoResizeImage($targetPath, $targetPath, 300, 300, 85);
        $relativePath = 'uploads/members/' . $filename;
        $stmt = $db->prepare("SELECT photo_path FROM members WHERE admno = ?");
        $stmt->execute([$admno]);
        $oldPath = $stmt->fetchColumn();
        if ($oldPath && file_exists(BASE_PATH . '/' . ltrim($oldPath, '/')) && $oldPath !== $targetPath) unlink(BASE_PATH . '/' . ltrim($oldPath, '/'));
        $update = $db->prepare("UPDATE members SET photo_path = ? WHERE admno = ?");
        $update->execute([$relativePath, $admno]);
        echo json_encode(['success' => true, 'path' => getWebImageUrl($relativePath), 'message' => 'Photo updated']);
    } else echo json_encode(['success' => false, 'error' => 'Failed to save file']);
    exit;
}

// 7. Export members to CSV
if (isset($_GET['export_members']) && $_GET['export_members'] == 'csv') {
    $filter_class = $_GET['class'] ?? ''; $filter_division = $_GET['division'] ?? '';
    $sql = "SELECT admno, name, member_category, class, division, phone, email, total_issued, total_fines, status, designation, academic_year FROM members WHERE 1=1";
    $params = [];
    if ($filter_class) { $sql .= " AND class = ?"; $params[] = $filter_class; }
    if ($filter_division) { $sql .= " AND division = ?"; $params[] = $filter_division; }
    $stmt = $db->prepare($sql); $stmt->execute($params);
    $data = $stmt->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="members_export_' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['AdmNo', 'Name', 'Category', 'Class', 'Division', 'Phone', 'Email', 'Total Issued', 'Total Fines', 'Status', 'Designation', 'Academic Year']);
    foreach ($data as $row) fputcsv($out, [$row['admno'], $row['name'], $row['member_category'], $row['class']??'', $row['division']??'', $row['phone']??'', $row['email']??'', $row['total_issued']??0, $row['total_fines']??0, $row['status']??'active', $row['designation']??'', $row['academic_year']??'']);
    fclose($out);
    exit;
}

// 8. Bulk import members (AJAX)
if (isset($_POST['ajax_action']) && $_POST['ajax_action'] == 'bulk_import_members') {
    header('Content-Type: application/json');
    $members = json_decode($_POST['members_data'] ?? '[]', true);
    $added = 0; $failed = 0;
    foreach ($members as $m) {
        if (empty($m['admno']) || empty($m['name'])) continue;
        try {
            $stmt = $db->prepare("INSERT INTO members (admno, name, member_category, class, division, phone, email, designation, academic_year, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([
                $m['admno'], $m['name'], $m['category']??'Student', $m['class']??'',
                $m['division']??'', $m['phone']??'', $m['email']??'', $m['designation']??'',
                $m['academic_year']??''
            ]);
            $added++;
        } catch (Exception $e) { $failed++; }
    }
    echo json_encode(['success' => true, 'added' => $added, 'failed' => $failed]);
    exit;
}

// 9. Fetch ISBN metadata (multi-source)
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] == 'fetch_isbn_metadata') {
    header('Content-Type: application/json');
    $isbn = trim($_GET['isbn'] ?? '');
    if (!$isbn) { echo json_encode(['success' => false, 'error' => 'No ISBN provided']); exit; }
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) != 10 && strlen($isbn) != 13) { echo json_encode(['success' => false, 'error' => 'Invalid ISBN']); exit; }

    $result = ['Title'=>'','Author'=>'','Collaborator'=>'','Publisher'=>'','Published Date'=>'','Pages'=>'','ISBN13'=>'','ISBN10'=>'',
               'Subjects'=>'','Category'=>'','DDC Code'=>'','Language'=>'','Cover URL'=>'','Description'=>'','Edition'=>'','Series'=>'','Volume'=>''];
    $allSources = [];

    // 1. Internal function if exists
    if (function_exists('fetchBookByISBN')) {
        $data = fetchBookByISBN($isbn);
        if (!empty($data['title'])) {
            $result['Title'] = $data['title'] ?? '';
            $result['Author'] = $data['author'] ?? '';
            $result['Publisher'] = $data['publisher'] ?? '';
            $result['Published Date'] = $data['year'] ?? '';
            $result['Pages'] = $data['pages'] ?? 0;
            $result['Subjects'] = $data['category'] ?? '';
            $result['Category'] = $data['category'] ?? '';
            $result['Cover URL'] = $data['cover_url'] ?? '';
            $result['Description'] = $data['summary'] ?? '';
            $result['ISBN13'] = (strlen($isbn)==13)?$isbn:'';
            $result['ISBN10'] = (strlen($isbn)==10)?$isbn:'';
            $allSources[] = ['source'=>'Internal','data'=>$result];
        }
    }

    // 2. Google Books
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $gResult = [
                'Title' => $info['title'] ?? '',
                'Author' => isset($info['authors'][0]) ? $info['authors'][0] : '',
                'Publisher' => $info['publisher'] ?? '',
                'Published Date' => substr($info['publishedDate'] ?? '', 0, 4),
                'Pages' => $info['pageCount'] ?? 0,
                'ISBN13' => (strlen($isbn)==13)?$isbn:'',
                'ISBN10' => (strlen($isbn)==10)?$isbn:'',
                'Subjects' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'Category' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'Language' => strtoupper($info['language'] ?? ''),
                'Cover URL' => $info['imageLinks']['thumbnail'] ?? '',
                'Description' => $info['description'] ?? '',
                'Edition' => $info['edition'] ?? '',
                'Series' => '',
                'Volume' => ''
            ];
            $allSources[] = ['source'=>'Google Books','data'=>$gResult];
            if (empty($result['Title']) && !empty($gResult['Title'])) $result = $gResult;
        }
    }

    // 3. OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $response2 = @file_get_contents($url2, false, $ctx);
    if ($response2) {
        $data2 = json_decode($response2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $olResult = [
                'Title' => $book['title'] ?? '',
                'Author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                'Publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                'Published Date' => $book['publish_date'] ?? '',
                'Pages' => $book['number_of_pages'] ?? 0,
                'ISBN13' => (strlen($isbn)==13)?$isbn:'',
                'ISBN10' => (strlen($isbn)==10)?$isbn:'',
                'Subjects' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : '',
                'Category' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : '',
                'Language' => $book['languages'][0]['name'] ?? '',
                'Cover URL' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'Description' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''),
                'Edition' => '',
                'Series' => '',
                'Volume' => ''
            ];
            $allSources[] = ['source'=>'OpenLibrary','data'=>$olResult];
            if (empty($result['Title']) && !empty($olResult['Title'])) $result = $olResult;
        }
    }

    // 4. ISBNdb if API key set
    if (!empty($settings['isbndb_api_key'])) {
        $url3 = "https://api2.isbndb.com/book/" . $isbn;
        $options = ['http' => ['method' => 'GET', 'header' => "Authorization: " . $settings['isbndb_api_key']]];
        $ctx3 = stream_context_create($options);
        $response3 = @file_get_contents($url3, false, $ctx3);
        if ($response3) {
            $data3 = json_decode($response3, true);
            if (isset($data3['book'])) {
                $b = $data3['book'];
                $idResult = [
                    'Title' => $b['title'] ?? '',
                    'Author' => $b['author'] ?? '',
                    'Publisher' => $b['publisher'] ?? '',
                    'Published Date' => $b['date_published'] ?? '',
                    'Pages' => $b['pages'] ?? 0,
                    'ISBN13' => (strlen($isbn)==13)?$isbn:'',
                    'ISBN10' => (strlen($isbn)==10)?$isbn:'',
                    'Subjects' => $b['subject'] ?? '',
                    'Category' => $b['subject'] ?? '',
                    'Language' => $b['language'] ?? '',
                    'Cover URL' => $b['image'] ?? '',
                    'Description' => $b['synopsis'] ?? '',
                    'Edition' => $b['edition'] ?? '',
                    'Series' => $b['series'] ?? '',
                    'Volume' => $b['volume'] ?? ''
                ];
                $allSources[] = ['source'=>'ISBNdb','data'=>$idResult];
                if (empty($result['Title']) && !empty($idResult['Title'])) $result = $idResult;
            }
        }
    }

    echo json_encode(['success' => true, 'data' => $result, 'sources' => $allSources]);
    exit;
}

// 10. Fetch all sources (for debug)
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] == 'fetch_all_sources') {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn'] ?? '');
    if (strlen($isbn) < 10) { echo json_encode(['success' => false, 'error' => 'Invalid ISBN']); exit; }
    $results = [];
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
    // Google
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $resp = @file_get_contents($url, false, $ctx);
    if ($resp) {
        $data = json_decode($resp, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $results[] = ['source_display' => 'Google Books', 'title' => $info['title'] ?? '', 'author' => isset($info['authors'][0]) ? $info['authors'][0] : '', 'publisher' => $info['publisher'] ?? '', 'year' => substr($info['publishedDate'] ?? '', 0, 4), 'pages' => $info['pageCount'] ?? 0, 'cover_url' => $info['imageLinks']['thumbnail'] ?? '', 'summary' => $info['description'] ?? '', 'subject' => isset($info['categories'][0]) ? $info['categories'][0] : '' ];
        }
    }
    // OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $resp2 = @file_get_contents($url2, false, $ctx);
    if ($resp2) {
        $data2 = json_decode($resp2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $results[] = ['source_display' => 'OpenLibrary', 'title' => $book['title'] ?? '', 'author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '', 'publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '', 'year' => $book['publish_date'] ?? '', 'pages' => $book['number_of_pages'] ?? 0, 'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''), 'summary' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''), 'subject' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : '' ];
        }
    }
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

// ==================== FETCH DATA FOR DISPLAY ====================
$members = $db->query("SELECT admno, name, member_category, class, division, phone, photo_path, 
    COALESCE(designation, member_category) AS designation, academic_year, email 
    FROM members WHERE status = 'active' ORDER BY name LIMIT 300")->fetchAll();
foreach ($members as &$m) {
    $m['photo_url'] = getMemberPhotoUrl($m['photo_path'] ?? '');
}
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

$allBooks = $db->query("SELECT barcode, title, author FROM books ORDER BY title LIMIT 200")->fetchAll();

// ==================== RENDER HEADER ====================
renderHeader('Library Utilities Suite');

// ==================== DISPLAY TOAST ====================
if (isset($_SESSION['toast'])) {
    $toast = $_SESSION['toast']; unset($_SESSION['toast']);
    echo "<div class='alert alert-{$toast['type']} alert-dismissible fade show m-3'>{$toast['message']}<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Utilities Suite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1e3c72;
            --primary-light: #2a5298;
            --border-radius: 16px;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        body { font-family: 'Inter', sans-serif; background: #f4f6fa; padding-bottom: 40px; }
        .nav-tabs { background: #eef2f6; border-bottom: 2px solid #dee2e6; padding: 0.5rem 0.5rem 0 0.5rem; border-radius: 16px 16px 0 0; }
        .nav-tabs .nav-link { color: #495057; border: none; border-bottom: 3px solid transparent; padding: 0.75rem 1.5rem; font-weight: 600; font-size: 0.9rem; transition: var(--transition); margin-right: 0.25rem; background: transparent; }
        .nav-tabs .nav-link:hover { color: var(--primary); border-bottom-color: var(--primary); background: rgba(30,60,114,0.08); }
        .nav-tabs .nav-link.active { color: var(--primary); border-bottom-color: var(--primary); background: white; font-weight: 700; }
        .nav-tabs .nav-link i { margin-right: 0.5rem; }
        .card-custom { border: none; border-radius: var(--border-radius); box-shadow: var(--shadow-sm); transition: var(--transition); background: #fff; overflow: hidden; margin-bottom: 1.5rem; }
        .card-custom:hover { box-shadow: var(--shadow-md); }
        .card-custom .card-header { background: transparent; border-bottom: 1px solid #e9ecef; padding: 0.9rem 1.25rem; font-weight: 600; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; }
        .card-custom .card-body { padding: 1.25rem; }
        .member-card { cursor: pointer; transition: var(--transition); border-left: 3px solid var(--primary-light); padding: 8px 12px; margin-bottom: 4px; border-radius: 8px; background: #f8f9fa; }
        .member-card:hover, .member-card.selected { background: #e3f2fd; transform: translateX(4px); }
        .id-card { width: var(--card-width); height: var(--card-height); border-radius: 12px; padding: 12px; box-shadow: 0 6px 14px rgba(0,0,0,0.1); position: relative; overflow: hidden; margin-bottom: 20px; background: white; transition: all 0.2s; }
        .id-card.front { background: linear-gradient(135deg, var(--theme-start) 0%, var(--theme-start) 30%, var(--theme-end) 30%, var(--theme-end) 100%); color: white; }
        .id-card.back { background: #f7f7f9; color: #333; border: 1px solid #e6e6e6; }
        .id-card .photo { position: absolute; right: 12px; width: 82px; height: 96px; background: rgba(255,255,255,0.2); border-radius: 8px; border: 2px solid white; display: flex; align-items: center; justify-content: center; overflow: hidden; }
        .id-card .photo i { font-size: 40px; color: rgba(255,255,255,0.7); }
        .id-card .photo img { width: 100%; height: 100%; object-fit: cover; }
        .id-card .card-logo { position: absolute; left: 12px; top: 12px; width: 45px; height: 45px; object-fit: contain; background: rgba(255,255,255,0.8); border-radius: 8px; padding: 4px; }
        .id-card .barcode-wrap, .id-card .qrcode-wrap { text-align: center; background: rgba(255,255,255,0.85); padding: 4px 8px; border-radius: 6px; position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); width: auto; max-width: 90%; }
        .id-card .barcode-wrap svg { height: 36px !important; width: auto !important; max-width: 100%; }
        .id-card .qrcode-wrap canvas, .id-card .qrcode-wrap img { max-height: 48px; width: auto; }
        .print-area { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; margin-top: 20px; background: #f8f9fa; padding: 20px; border-radius: 16px; }
        .card-pair { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; margin-bottom: 20px; page-break-inside: avoid; position: relative; }
        .card-checkbox { position: absolute; top: -8px; left: -8px; z-index: 10; width: 22px; height: 22px; cursor: pointer; }
        .selected-for-export { outline: 3px solid #28a745; outline-offset: 2px; }
        .size-preset, .layout-preset { cursor: pointer; padding: 5px 12px; border-radius: 20px; background: #e9ecef; transition: var(--transition); font-size: 0.85rem; }
        .size-preset:hover, .layout-preset:hover, .size-preset.active, .layout-preset.active { background: var(--primary); color: white; }
        .theme-btn { width: 36px; height: 36px; border-radius: 50%; cursor: pointer; margin: 2px; border: 2px solid transparent; }
        .theme-btn.active { border-color: #333; transform: scale(1.1); box-shadow: 0 0 0 2px white, 0 0 0 4px #333; }
        .log-box { background: #1a1a2e; color: #00ff88; font-family: monospace; font-size: 12px; height: 250px; overflow-y: auto; padding: 15px; border-radius: 12px; }
        .api-badge { display: inline-block; padding: 2px 8px; border-radius: 15px; font-size: 10px; margin: 2px; }
        .api-openlib { background: #1e3c72; color: white; }
        .api-google { background: #4285F4; color: white; }
        .editable-table input, .editable-table textarea { width: 100%; border: 1px solid #dee2e6; border-radius: 6px; padding: 4px 8px; font-size: 13px; }
        .drop-zone { border: 2px dashed var(--primary); border-radius: 12px; padding: 30px; text-align: center; cursor: pointer; margin-bottom: 15px; transition: var(--transition); }
        .drop-zone:hover { background: #f8f9fa; border-color: #ffc107; }
        .file-item { padding: 8px; border-bottom: 1px solid #eee; cursor: pointer; display: flex; justify-content: space-between; align-items: center; }
        .file-item:hover { background: #f8f9fa; }
        .barcode-demo-box { border: 1px solid #ddd; padding: 8px; text-align: center; border-radius: 8px; background: #fafafa; }
        .barcode-demo-box svg { max-width: 100%; height: auto; }
        .color-picker { width: 40px; height: 40px; border-radius: 8px; border: 1px solid #ddd; padding: 2px; }
        .btn-gradient-primary { background: linear-gradient(135deg, #1e3c72, #2a5298); color: #fff; border: none; }
        .btn-gradient-primary:hover { transform: scale(1.02); box-shadow: 0 4px 15px rgba(30,60,114,0.4); color: #fff; }
        .preview-stats { background: white; border-radius: 12px; padding: 12px 20px; margin-bottom: 20px; box-shadow: var(--shadow-sm); }
    </style>
</head>
<body>

<div class="container-fluid px-4 mt-3">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-toolbox text-primary"></i> Library Utilities Suite</h2>
        <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
    </div>

    <ul class="nav nav-tabs mb-3" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#idcard"><i class="fas fa-id-card"></i> ID Cards</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#barcode"><i class="fas fa-barcode"></i> Barcode & Labels</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#isbn"><i class="fas fa-search"></i> ISBN Metadata (Pro)</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#pdf"><i class="fas fa-file-pdf"></i> PDF Toolbox</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#shelflabel"><i class="fas fa-tag"></i> Shelf/Spine</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#export"><i class="fas fa-file-export"></i> Export / Import</button></li>
    </ul>

    <div class="tab-content">
        <!-- ================= ID CARD GENERATOR ================= -->
        <div class="tab-pane fade show active" id="idcard">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold"><i class="fas fa-palette me-2 text-primary"></i>Card Design</div>
                        <div class="card-body">
                            <label class="form-label fw-bold">Card Size (px)</label>
                            <div class="row g-2 mb-2">
                                <div class="col-6"><input type="number" id="cardWidth" class="form-control" step="5" value="350" onchange="resizeCards()"></div>
                                <div class="col-6"><input type="number" id="cardHeight" class="form-control" step="5" value="220" onchange="resizeCards()"></div>
                            </div>
                            <div class="d-flex gap-2 flex-wrap mb-3">
                                <span class="size-preset" onclick="setCardSize(350,220)">Standard</span>
                                <span class="size-preset" onclick="setCardSize(300,190)">Compact</span>
                                <span class="size-preset" onclick="setCardSize(400,250)">Large</span>
                                <span class="size-preset" onclick="setCardSize(480,300)">CR80</span>
                            </div>
                            <label class="form-label fw-bold">Institution</label>
                            <input type="text" id="schoolName" class="form-control mb-2" value="<?= htmlspecialchars($institution['name'] ?? 'Library System') ?>">
                            <label class="form-label fw-bold">Tagline</label>
                            <input type="text" id="tagline" class="form-control mb-2" value="<?= htmlspecialchars($institution['address'] ?? 'Knowledge Hub') ?>">
                            <label class="form-label fw-bold mt-2">Header Font Size (px)</label>
                            <input type="range" id="headerFontSize" class="form-range" min="12" max="24" value="16" step="1" oninput="document.getElementById('headerFontSizeVal').innerText=this.value; updateHeaderStyle()">
                            <span id="headerFontSizeVal">16</span> px
                            <div class="form-check form-switch mt-1">
                                <input class="form-check-input" type="checkbox" id="headerBold" checked onchange="updateHeaderStyle()">
                                <label class="form-check-label">Bold header</label>
                            </div>
                            <label class="form-label fw-bold mt-3">Theme</label>
                            <div class="d-flex gap-2 align-items-center flex-wrap">
                                <div class="theme-btn active" style="background: linear-gradient(135deg, #d32f2f, #ff6659);" onclick="applyTheme('#d32f2f','#ff6659',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #1e3a8a, #60a5fa);" onclick="applyTheme('#1e3a8a','#60a5fa',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #047857, #34d399);" onclick="applyTheme('#047857','#34d399',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #6b21a8, #a78bfa);" onclick="applyTheme('#6b21a8','#a78bfa',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #b45309, #fbbf24);" onclick="applyTheme('#b45309','#fbbf24',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #0d9488, #5eead4);" onclick="applyTheme('#0d9488','#5eead4',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #be185d, #f472b6);" onclick="applyTheme('#be185d','#f472b6',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #1e293b, #94a3b8);" onclick="applyTheme('#1e293b','#94a3b8',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #4c1d95, #8b5cf6);" onclick="applyTheme('#4c1d95','#8b5cf6',this)"></div>
                                <div class="theme-btn" style="background: linear-gradient(135deg, #7f1d1d, #ef4444);" onclick="applyTheme('#7f1d1d','#ef4444',this)"></div>
                                <input type="color" id="themeStartColor" class="color-picker" value="#d32f2f">
                                <span>→</span>
                                <input type="color" id="themeEndColor" class="color-picker" value="#ff6659">
                                <button class="btn btn-sm btn-outline-primary" onclick="applyCustomTheme()">Apply</button>
                            </div>
                            <hr>
                            <label class="form-label fw-bold">Layout Adjustments</label>
                            <div class="row g-2">
                                <div class="col-6"><label>Info Left Margin</label><input type="range" id="infoLeftMargin" class="form-range" min="0" max="50" value="10" step="1" oninput="document.getElementById('infoLeftMarginVal').innerText=this.value"><span id="infoLeftMarginVal">10</span> px</div>
                                <div class="col-6"><label>Info Top Margin</label><input type="range" id="infoTopMargin" class="form-range" min="30" max="80" value="50" step="2" oninput="document.getElementById('infoTopMarginVal').innerText=this.value"><span id="infoTopMarginVal">50</span> px</div>
                                <div class="col-6"><label>Name/ID Font Size</label><input type="range" id="infoFontSize" class="form-range" min="10" max="16" value="11" step="1" oninput="document.getElementById('infoFontSizeVal').innerText=this.value"><span id="infoFontSizeVal">11</span> px</div>
                                <div class="col-6"><label>Signature Font Size</label><input type="range" id="signatureFontSize" class="form-range" min="6" max="12" value="8" step="1" oninput="document.getElementById('signatureFontSizeVal').innerText=this.value"><span id="signatureFontSizeVal">8</span> px</div>
                            </div>
                            <hr>
                            <label class="form-label fw-bold">Optional Fields</label>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="showClassDept" checked><label class="form-check-label">Show Clas/Dept</label></div>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="showDivCourse" checked><label class="form-check-label">Show Div/Cors</label></div>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="showYear" checked><label class="form-check-label">Show Year (auto‑current if empty)</label></div>
                            <div class="row g-2 mt-2">
                                <div class="col-6"><label>Photo Top Margin</label><input type="range" id="photoTopMargin" class="form-range" min="30" max="120" value="54" step="2" oninput="document.getElementById('photoTopMarginVal').innerText=this.value; updatePhotoPosition()"><span id="photoTopMarginVal">54</span> px</div>
                                <div class="col-6"><label>ID No Top Offset</label><input type="range" id="idNoTopOffset" class="form-range" min="120" max="200" value="158" step="2" oninput="document.getElementById('idNoTopOffsetVal').innerText=this.value; updateIdNoPosition()"><span id="idNoTopOffsetVal">158</span> px</div>
                                <div class="col-6"><label>Info Block Width</label><input type="range" id="infoBlockWidth" class="form-range" min="150" max="250" value="200" step="5" oninput="document.getElementById('infoBlockWidthVal').innerText=this.value; updateInfoBlockWidth()"><span id="infoBlockWidthVal">200</span> px</div>
                                <div class="col-6"><label>Year Font Size</label><input type="range" id="yearFontSize" class="form-range" min="8" max="14" value="10" step="1" oninput="document.getElementById('yearFontSizeVal').innerText=this.value"><span id="yearFontSizeVal">10</span> px</div>
                            </div>
                            <hr>
                            <label class="form-label fw-bold">Library Rules</label>
                            <textarea id="libraryRules" rows="3" class="form-control mb-2">• Non-transferable\n• Report loss immediately\n• Show at entrance\n• Return books on time</textarea>
                            <label class="form-label fw-bold">Authorized Signature</label>
                            <input type="text" id="signatureText" class="form-control" value="Authorized Signature">
                            <hr>
                            <label class="form-label fw-bold">Custom Left Logo (ID Card)</label>
                            <input type="file" id="customLeftLogo" class="form-control" accept="image/*">
                            <button class="btn btn-sm btn-secondary mt-1" onclick="uploadCustomLogo()">Use as Left Logo</button>
                            <div id="customLogoPreview" class="mt-1"></div>
                        </div>
                    </div>

                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold"><i class="fas fa-user me-2 text-primary"></i>Member Data Source</div>
                        <div class="card-body">
                            <select id="memberDataSource" class="form-select mb-2" onchange="toggleMemberSource()">
                                <option value="db">From Database</option>
                                <option value="manual">Manual Entry</option>
                                <option value="csv">CSV Upload</option>
                            </select>
                            <div id="memberDbBox">
                                <div class="input-group mb-2">
                                    <input type="text" id="memberSearch" class="form-control" placeholder="Search members (name, admno, class, etc.)" onkeyup="filterMembers()">
                                    <button class="btn btn-outline-secondary" onclick="filterMembers()"><i class="fas fa-search"></i></button>
                                </div>
                                <div id="memberList" style="max-height:300px;overflow-y:auto;border:1px solid #ddd;border-radius:8px;padding:5px;">
                                    <?php foreach($members as $m): ?>
                                    <div class="member-card" data-admno="<?= htmlspecialchars($m['admno']) ?>" data-name="<?= htmlspecialchars($m['name']) ?>" data-class="<?= htmlspecialchars($m['class']??'') ?>" data-division="<?= htmlspecialchars($m['division']??'') ?>" data-phone="<?= htmlspecialchars($m['phone']??'') ?>" data-photo-url="<?= htmlspecialchars($m['photo_url']) ?>" data-designation="<?= htmlspecialchars($m['designation']??$m['member_category']??'') ?>" data-year="<?= htmlspecialchars($m['academic_year']??'') ?>" onclick="selectMember(this)">
                                        <strong><?= htmlspecialchars($m['name']) ?></strong> <small class="text-muted">(<?= $m['admno'] ?>)</small>
                                        <br><small><?= $m['member_category'] ?? '' ?> <?= $m['class'] ? '| '.$m['class'] : '' ?></small>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <div id="memberPhotoUploadBox" style="display: none; margin-top: 10px;">
                                    <label>Update Member Photo (save to server)</label>
                                    <input type="file" id="memberPhotoFile" class="form-control" accept="image/*">
                                    <button class="btn btn-sm btn-primary mt-2" onclick="updateMemberPhoto()">Upload & Save</button>
                                    <div id="photoUploadStatus" class="small mt-1"></div>
                                </div>
                                <div class="mt-2">
                                    <label>External Photo (card only, not saved)</label>
                                    <input type="file" id="externalPhotoFile" class="form-control" accept="image/*">
                                    <button class="btn btn-sm btn-secondary mt-2" onclick="applyExternalPhoto()">Apply to Selected Member</button>
                                </div>
                                <div class="d-grid gap-2 mt-3">
                                    <button class="btn btn-success" onclick="generateSelectedMembers()">Generate Selected</button>
                                    <button class="btn btn-info text-white" onclick="generateAllMembers()">Generate All</button>
                                </div>
                            </div>
                            <div id="memberManualBox" style="display:none;">
                                <input type="text" id="manualName" class="form-control mb-2" placeholder="Full Name">
                                <input type="text" id="manualRoll" class="form-control mb-2" placeholder="Member ID">
                                <input type="text" id="manualDesignation" class="form-control mb-2" placeholder="Designation">
                                <input type="text" id="manualClassDept" class="form-control mb-2" placeholder="Clas/Dept">
                                <input type="text" id="manualDivisionCourse" class="form-control mb-2" placeholder="Div/Cors">
                                <input type="text" id="manualPhone" class="form-control mb-2" placeholder="Contact (Phone)">
                                <input type="text" id="manualYear" class="form-control mb-2" placeholder="Year (leave empty for auto current)">
                                <input type="file" id="manualPhoto" class="form-control mb-2" accept="image/*">
                                <button class="btn btn-sm btn-primary" onclick="generateManualCard()">Add Card</button>
                            </div>
                            <div id="memberCsvBox" style="display:none;">
                                <input type="file" id="memberCsvFile" accept=".csv" class="form-control mb-2">
                                <button class="btn btn-sm btn-primary" onclick="importMemberCSV()">Import & Generate Cards</button>
                                <small class="text-muted">CSV format: Name,ID,Designation,Clas/Dept,Div/Cors,Contact,Year (year optional)</small>
                            </div>
                        </div>
                    </div>

                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold"><i class="fas fa-print me-2 text-primary"></i>Export & Print</div>
                        <div class="card-body">
                            <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" id="colorPrint" checked><label class="form-check-label">Color output</label></div>
                            <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" id="includeQR" onchange="toggleQR()"><label class="form-check-label">Use QR Code (instead of barcode)</label></div>
                            <label class="form-label fw-bold">Layout (cards per row)</label>
                            <div class="d-flex gap-2 mb-3">
                                <span class="layout-preset" data-cols="1" onclick="setPrintLayout(1)">1</span>
                                <span class="layout-preset active" data-cols="2" onclick="setPrintLayout(2)">2</span>
                                <span class="layout-preset" data-cols="3" onclick="setPrintLayout(3)">3</span>
                                <span class="layout-preset" data-cols="4" onclick="setPrintLayout(4)">4</span>
                            </div>
                            <div class="row g-2">
                                <div class="col-6"><button class="btn btn-secondary w-100" onclick="window.print()"><i class="fas fa-print"></i> Print</button></div>
                                <div class="col-6"><button class="btn btn-danger w-100" onclick="exportToPDF(false)"><i class="fas fa-file-pdf"></i> PDF All</button></div>
                                <div class="col-6"><button class="btn btn-success w-100" onclick="exportToPDF(true)"><i class="fas fa-file-pdf"></i> PDF Selected</button></div>
                                <div class="col-6"><button class="btn btn-info w-100 text-white" onclick="exportToPNG()"><i class="fas fa-image"></i> PNG</button></div>
                                <div class="col-6"><button class="btn btn-outline-danger w-100" onclick="clearCards()"><i class="fas fa-trash"></i> Clear All</button></div>
                                <div class="col-6"><button class="btn btn-outline-secondary w-100" onclick="regenerateAllCards()"><i class="fas fa-sync-alt"></i> Refresh</button></div>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-check-square"></i> Select cards:</span>
                                <div>
                                    <button class="btn btn-sm btn-outline-primary" onclick="selectAllCards()">All</button>
                                    <button class="btn btn-sm btn-outline-secondary" onclick="deselectAllCards()">None</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="preview-stats d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-id-card text-primary me-2"></i><span id="cardCount">0</span> cards</span>
                        <span class="text-muted small">Select members and click Generate</span>
                    </div>
                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold">Preview (Front & Back)</div>
                        <div class="card-body">
                            <div class="print-area" id="cardsContainer">
                                <div class="text-center text-muted py-5">Select members from left panel and click Generate</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= BARCODE & LABEL GENERATOR ================= -->
        <div class="tab-pane fade" id="barcode">
            <div class="row">
                <div class="col-md-4">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5><i class="fas fa-database"></i> Data Source</h5>
                            <select id="barcodeMode" class="form-select mb-2" onchange="toggleBarcodeMode()">
                                <option value="manual">Manual / Paste</option>
                                <option value="range">Number Range (Prefix)</option>
                                <option value="books">From Database (Books)</option>
                                <option value="daterange">📅 Database Date Range</option>
                            </select>
                            <div id="barcodeManualBox"><label>Paste Values (one per line)</label><textarea id="barcodeManualInput" rows="4" class="form-control mb-2">ABC123\nBOOK001\nSTU456</textarea></div>
                            <div id="barcodeRangeBox" style="display:none;"><label>Prefix</label><input type="text" id="barcodePrefix" class="form-control mb-1" value="LIB-"><div class="row"><div class="col"><label>Start</label><input type="number" id="barcodeStart" class="form-control" value="1"></div><div class="col"><label>End</label><input type="number" id="barcodeEnd" class="form-control" value="50"></div></div><label>Padding Digits</label><input type="number" id="barcodePad" class="form-control mb-2" value="4"></div>
                            <div id="barcodeBooksBox" style="display:none;"><label>Select Books</label><select id="bookBarcodeSelect" multiple class="form-control mb-2" size="5"></select><button type="button" class="btn btn-sm btn-secondary" onclick="loadBooksForBarcode()">Load Books</button></div>
                            <div id="barcodeDateRangeBox" style="display:none;"><label>From Date</label><input type="date" id="barcodeDateFrom" class="form-control mb-2" value="<?= date('Y-m-01') ?>"><label>To Date</label><input type="date" id="barcodeDateTo" class="form-control mb-2" value="<?= date('Y-m-d') ?>"><button type="button" class="btn btn-sm btn-secondary" onclick="loadBarcodesByDateRange()">Fetch Barcodes</button><div id="barcodeFetchedList" class="mt-2 small text-muted"></div></div>
                            <hr><h5>🖨️ Layout & Style</h5>
                            <label>Header Text</label><input type="text" id="barcodeHeader" class="form-control mb-2" value="LIBRARY SYSTEM">
                            <div class="row"><div class="col-6"><label>Rows</label><input type="number" id="barcodeRows" class="form-control" value="4"></div><div class="col-6"><label>Columns</label><input type="number" id="barcodeCols" class="form-control" value="3"></div></div>
                            <div class="row"><div class="col-6"><label>Barcode Width</label><input type="number" id="barcodeWidth" class="form-control" value="2" step="0.5"></div><div class="col-6"><label>Barcode Height</label><input type="number" id="barcodeHeight" class="form-control" value="50" step="5"></div></div>
                            <label>Margin</label><input type="number" id="barcodeMargin" class="form-control mb-2" value="5">
                            <div class="row"><div class="col-6"><label>Row Gap (px)</label><input type="number" id="barcodeRowGap" class="form-control" value="0" step="1"></div><div class="col-6"><label>Column Gap (px)</label><input type="number" id="barcodeColGap" class="form-control" value="0" step="1"></div></div>
                            <label>Header → Barcode Gap (px)</label><input type="number" id="barcodeGapHB" class="form-control mb-2" value="0">
                            <label>Barcode → Value Gap (px)</label><input type="number" id="barcodeGapBV" class="form-control mb-2" value="0">
                            <label>Show Value</label><select id="barcodeShowText" class="form-select mb-2"><option value="true">Yes</option><option value="false">No</option></select>
                            <label>Orientation</label><select id="barcodeOrientation" class="form-select mb-2"><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select>
                            <button class="btn btn-primary w-100 mt-2" onclick="generateBarcodePreview()">✨ Preview</button>
                            <button class="btn btn-success w-100 mt-2" onclick="downloadBarcodePDF()">📄 PDF</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>👁️ Live Preview</h5>
                            <div id="barcodeSheet" class="sheet" style="background:white; padding:10px;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= ISBN METADATA PRO ================= -->
        <div class="tab-pane fade" id="isbn">
            <div class="row">
                <div class="col-md-5">
                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold">Data Source <span class="float-end"><span class="api-badge api-openlib">OpenLibrary</span><span class="api-badge api-google">Google Books</span><span class="api-badge">ISBNdb</span></span></div>
                        <div class="card-body">
                            <ul class="nav nav-tabs mb-3" id="inputTabs">
                                <li class="nav-item"><button class="nav-link active" data-input="manual" onclick="switchInputMode('manual')"><i class="fas fa-keyboard"></i> Manual ISBNs</button></li>
                                <li class="nav-item"><button class="nav-link" data-input="file" onclick="switchInputMode('file')"><i class="fas fa-file-csv"></i> CSV/Excel</button></li>
                                <li class="nav-item"><button class="nav-link" data-input="single" onclick="switchInputMode('single')"><i class="fas fa-search-plus"></i> Single Search</button></li>
                            </ul>
                            <div id="manualInputDiv"><textarea id="isbnList" rows="6" class="form-control" placeholder="Enter one ISBN per line (10 or 13 digits)&#10;9780140328721&#10;9780439554930"></textarea></div>
                            <div id="fileInputDiv" style="display:none;"><input type="file" id="csvFile" accept=".csv,.xlsx,.xls" class="form-control mb-2"><button class="btn btn-sm btn-outline-primary" onclick="importFromFile()"><i class="fas fa-upload"></i> Load ISBNs</button></div>
                            <div id="singleInputDiv" style="display:none;"><div class="input-group"><input type="text" id="singleIsbn" class="form-control" placeholder="Enter ISBN"><button class="btn btn-primary" onclick="fetchSingleISBN()"><i class="fas fa-search"></i> Fetch</button></div><div id="singleResult" class="mt-3"></div></div>
                            <div class="mt-3 d-flex flex-wrap gap-2">
                                <button id="btnFetch" class="btn btn-primary"><i class="fas fa-cloud-download-alt"></i> Fetch All</button>
                                <button id="btnTest" class="btn btn-warning" onclick="testISBNFetching()"><i class="fas fa-vial"></i> Test</button>
                                <button id="btnExcel" class="btn btn-success"><i class="fas fa-file-excel"></i> Export Excel</button>
                                <button id="btnAddBooks" class="btn btn-info text-white" onclick="addSelectedToLibrary()"><i class="fas fa-plus-circle"></i> Add to Library</button>
                                <button id="btnClear" class="btn btn-secondary"><i class="fas fa-trash"></i> Clear</button>
                            </div>
                            <div id="progressContainer" style="display:none;" class="mt-3"><div class="progress"><div id="fetchProgress" class="progress-bar" style="width:0%">0%</div></div><div id="progressStatus" class="small text-muted mt-1"></div></div>
                            <div id="status" class="mt-2"></div>
                        </div>
                    </div>
                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold"><i class="fas fa-terminal"></i> Activity Log</div>
                        <div class="card-body p-2"><div class="log-box" id="isbnLog"></div></div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card-custom">
                        <div class="card-header bg-white fw-bold">Editable Results <span class="float-end"><span id="recordCount" class="badge bg-light text-dark">0 records</span><button class="btn btn-sm btn-outline-light ms-2" onclick="revertAllEdits()"><i class="fas fa-undo-alt"></i> Revert</button></span></div>
                        <div class="card-body p-0"><div class="table-container" style="max-height:550px; overflow-y:auto;"><table class="table table-bordered table-hover mb-0 editable-table" id="resultTable" style="display:none;"><thead id="headerRow"></thead><tbody id="tableBody"></tbody></table></div></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= PDF TOOLBOX (Fully functional) ================= -->
        <div class="tab-pane fade" id="pdf">
            <div class="row">
                <div class="col-md-5">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5><i class="fas fa-file-pdf"></i> PDF Files</h5>
                            <div id="pdfDropZone" class="drop-zone">📂 Drop PDFs here or click</div>
                            <input type="file" id="pdfInput" multiple accept="application/pdf" style="display:none">
                            <div id="pdfFileList"></div>
                            <button class="btn btn-primary w-100 mt-2" onclick="mergePDFs()"><i class="fas fa-object-group"></i> Merge Selected</button>
                            <button class="btn btn-info w-100 mt-2" onclick="compressPDF()"><i class="fas fa-compress-alt"></i> Compress PDF</button>
                        </div>
                    </div>
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>✂️ Split / Extract</h5>
                            <select id="pdfSelect" class="form-select mb-2"></select>
                            <input type="text" id="pageRange" class="form-control mb-2" placeholder="Page range: 1-3,5">
                            <button class="btn btn-warning" onclick="splitPDF()"><i class="fas fa-cut"></i> Split</button>
                            <button class="btn btn-info" onclick="extractPages()"><i class="fas fa-copy"></i> Extract</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>💧 Add Watermark</h5>
                            <select id="wmPDFSelect" class="form-select mb-2"></select>
                            <select id="wmType" class="form-select mb-2" onchange="toggleWatermarkType()">
                                <option value="text">Text Watermark</option>
                                <option value="image">Image Watermark</option>
                            </select>
                            <div id="wmTextDiv">
                                <input type="text" id="wmText" class="form-control mb-2" value="CONFIDENTIAL">
                                <div class="row">
                                    <div class="col"><input type="number" id="wmFontSize" class="form-control" placeholder="Size" value="50"></div>
                                    <div class="col"><input type="number" id="wmOpacity" class="form-control" step="0.1" value="0.3"></div>
                                    <div class="col"><input type="color" id="wmColor" class="form-control" value="#cccccc"></div>
                                </div>
                            </div>
                            <div id="wmImageDiv" style="display:none">
                                <input type="file" id="wmImageFile" accept="image/*" class="form-control">
                                <input type="number" id="wmImageScale" class="form-control mt-2" placeholder="Scale" value="0.3">
                            </div>
                            <button class="btn btn-primary mt-2" onclick="addWatermark()"><i class="fas fa-water"></i> Apply Watermark</button>
                            <div id="pdfProgress" class="mt-2" style="display:none"><div class="progress"><div id="pdfProgressBar" class="progress-bar" style="width:0%">0%</div></div></div>
                            <div id="pdfDownload" class="mt-2" style="display:none"><a id="pdfDownloadLink" class="btn btn-success w-100"><i class="fas fa-download"></i> Download Result</a></div>
                        </div>
                    </div>
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>🔗 Rotate & Organize</h5>
                            <select id="rotateSelect" class="form-select mb-2"></select>
                            <div class="row g-2">
                                <div class="col-4"><button class="btn btn-outline-secondary w-100" onclick="rotatePDF(90)">90°</button></div>
                                <div class="col-4"><button class="btn btn-outline-secondary w-100" onclick="rotatePDF(180)">180°</button></div>
                                <div class="col-4"><button class="btn btn-outline-secondary w-100" onclick="rotatePDF(270)">270°</button></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= SHELF & SPINE ================= -->
        <div class="tab-pane fade" id="shelflabel">
            <div class="row">
                <div class="col-md-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>🏷️ Shelf Label (Call Number)</h5>
                            <input type="text" id="callNumber" class="form-control mb-2" placeholder="Call Number e.g., QA76.73.P98">
                            <input type="text" id="shelfTitle" class="form-control mb-2" placeholder="Title (optional)">
                            <input type="number" id="labelQty" class="form-control mb-2" value="1" min="1">
                            <div class="row mt-2">
                                <div class="col-6"><label>Label Width (mm)</label><input type="number" id="shelfWidth" class="form-control" value="50"></div>
                                <div class="col-6"><label>Label Height (mm)</label><input type="number" id="shelfHeight" class="form-control" value="30"></div>
                            </div>
                            <div class="row"><div class="col-6"><label>Rows per A4</label><input type="number" id="shelfRows" class="form-control" value="10"></div><div class="col-6"><label>Cols per A4</label><input type="number" id="shelfCols" class="form-control" value="3"></div></div>
                            <button class="btn btn-primary w-100" onclick="generateShelfLabels()">Generate Shelf Labels</button>
                            <div id="shelfPreview" class="border p-3 bg-white rounded text-center mt-3" style="min-height:100px;"></div>
                        </div>
                    </div>
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>📚 Spine Label (Database Powered)</h5>
                            <label>Input Mode</label>
                            <select id="spineMode" class="form-select mb-2" onchange="toggleSpineMode()">
                                <option value="manual">Manual Entry</option>
                                <option value="daterange">📅 Database Date Range</option>
                                <option value="barcoderange">🔢 Barcode Range</option>
                            </select>
                            <div id="spineManualBox">
                                <input type="text" id="spineManualAuthor" class="form-control mb-2" placeholder="Author">
                                <input type="text" id="spineManualTitle" class="form-control mb-2" placeholder="Title">
                                <input type="text" id="spineManualCallNo" class="form-control mb-2" placeholder="Call Number">
                                <input type="text" id="spineManualBarcode" class="form-control mb-2" placeholder="Barcode">
                                <input type="number" id="spineManualQty" class="form-control mb-2" value="1" min="1">
                            </div>
                            <div id="spineDateRangeBox" style="display:none;">
                                <label>From Date</label><input type="date" id="spineDateFrom" class="form-control mb-2" value="<?= date('Y-m-01') ?>">
                                <label>To Date</label><input type="date" id="spineDateTo" class="form-control mb-2" value="<?= date('Y-m-d') ?>">
                                <button type="button" class="btn btn-sm btn-secondary mb-2" onclick="loadSpineBooksByDateRange()">Fetch Books</button>
                                <div id="spineFetchedList" class="small text-muted mb-2"></div>
                                <select id="spineBookSelect" multiple class="form-control mb-2" size="5" style="display:none;"></select>
                            </div>
                            <div id="spineBarcodeRangeBox" style="display:none;">
                                <label>Prefix</label><input type="text" id="spineBarcodePrefix" class="form-control mb-1" value="LIB-">
                                <div class="row"><div class="col"><label>Start</label><input type="number" id="spineBarcodeStart" class="form-control" value="1"></div><div class="col"><label>End</label><input type="number" id="spineBarcodeEnd" class="form-control" value="50"></div></div>
                                <label>Padding Digits</label><input type="number" id="spineBarcodePad" class="form-control mb-2" value="4">
                                <button type="button" class="btn btn-sm btn-secondary" onclick="generateSpineFromBarcodeRange()">Generate</button>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-4"><label>Width (mm)</label><input type="number" id="spineWidth" class="form-control" value="60"></div>
                                <div class="col-4"><label>Height (mm)</label><input type="number" id="spineHeight" class="form-control" value="180"></div>
                                <div class="col-4"><label>Line Spacing (mm)</label><input type="number" id="spineLineSpacing" class="form-control" value="4" step="1"></div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-6"><label>📝 Code Font Size (pt)</label><input type="number" id="spineCodeFontSize" class="form-control" value="12" min="6" max="24"></div>
                                <div class="col-6"><label>CallNo Font Size (pt)</label><input type="number" id="spineCallNoFontSize" class="form-control" value="10" min="6" max="20"></div>
                            </div>
                            <div class="row">
                                <div class="col-6"><label>Rows per A4</label><input type="number" id="spineRows" class="form-control" value="5"></div>
                                <div class="col-6"><label>Cols per A4</label><input type="number" id="spineCols" class="form-control" value="2"></div>
                            </div>
                            <div class="row">
                                <div class="col-6"><label>Orientation</label><select id="spineOrientation" class="form-select"><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></div>
                                <div class="col-6"><label>Show Barcode Image</label><select id="spineShowBarcodeImg" class="form-select"><option value="yes">Yes</option><option value="no">No</option></select></div>
                            </div>
                            <hr><h5>📐 Advanced Grid Layout</h5>
                            <div class="row">
                                <div class="col-6"><label>Rows per Page</label><input type="number" id="spineGridRows" class="form-control" value="5"></div>
                                <div class="col-6"><label>Cols per Page</label><input type="number" id="spineGridCols" class="form-control" value="2"></div>
                                <div class="col-6"><label>Horizontal Gap (mm)</label><input type="number" id="spineGridGapX" class="form-control" value="5" step="1"></div>
                                <div class="col-6"><label>Vertical Gap (mm)</label><input type="number" id="spineGridGapY" class="form-control" value="5" step="1"></div>
                                <div class="col-6"><label>Top Margin (mm)</label><input type="number" id="spineMarginTop" class="form-control" value="15"></div>
                                <div class="col-6"><label>Left Margin (mm)</label><input type="number" id="spineMarginLeft" class="form-control" value="15"></div>
                            </div>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" id="spineUseBarcodeLayout" checked>
                                <label class="form-check-label">Use grid layout (like barcode labels)</label>
                            </div>
                            <button class="btn btn-success w-100 mt-2" onclick="generateSpineLabels()">Generate Spine Labels PDF</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>📋 Spine Label List</h5>
                            <div id="spineLabelList">
                                <p class="text-muted">No labels added yet. Use controls on the left to generate.</p>
                            </div>
                            <button class="btn btn-sm btn-outline-danger mt-2" onclick="clearSpineLabels()"><i class="fas fa-trash"></i> Clear All</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= EXPORT / IMPORT ================= -->
        <div class="tab-pane fade" id="export">
            <div class="row">
                <div class="col-md-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>📋 Export Members to CSV</h5>
                            <form method="get" class="row g-3">
                                <div class="col-md-4"><label>Class</label><select name="class" class="form-select"><option value="">All</option><?php foreach($classes as $c): ?><option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select></div>
                                <div class="col-md-4"><label>Division</label><select name="division" class="form-select"><option value="">All</option><?php foreach($divisions as $d): ?><option value="<?= htmlspecialchars($d) ?>"><?= htmlspecialchars($d) ?></option><?php endforeach; ?></select></div>
                                <div class="col-md-4 align-self-end"><button type="submit" name="export_members" value="csv" class="btn btn-primary w-100"><i class="fas fa-download"></i> Download CSV</button></div>
                            </form>
                            <hr>
                            <h5>📤 Export Books to CSV</h5>
                            <button class="btn btn-primary" onclick="exportBooksCSV()"><i class="fas fa-download"></i> Export All Books</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5>📚 Bulk Import Books (CSV/Excel)</h5>
                            <input type="file" id="bulkBooksFile" class="form-control mb-2" accept=".csv,.xlsx,.xls">
                            <div class="small text-muted mb-2">Format: Barcode, Title, Author, Publisher, ISBN, Call Number, Category, Pages, Description</div>
                            <button class="btn btn-success w-100" onclick="bulkImportBooks()"><i class="fas fa-upload"></i> Import Books</button>
                            <div id="bulkImportStatus" class="mt-2 small"></div>
                            <hr>
                            <h5>📥 Import Members from CSV</h5>
                            <input type="file" id="bulkMembersFile" class="form-control mb-2" accept=".csv,.xlsx,.xls">
                            <div class="small text-muted mb-2">Format: AdmNo, Name, Category, Class, Division, Phone, Email, Designation, Academic Year</div>
                            <button class="btn btn-info w-100" onclick="bulkImportMembers()"><i class="fas fa-upload"></i> Import Members</button>
                            <div id="bulkMemberStatus" class="mt-2 small"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ================= SCRIPTS ================= -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>

<script>
// ==================== ID CARDS ====================
let cards = [];
let selectedMemberElem = null;
let currentThemeStart = '#d32f2f', currentThemeEnd = '#ff6659';
let useQR = false;
let currentLayoutCols = 2;
let customLeftLogoData = null;
const institutionLogo = "<?= !empty($institution['logo_path']) && file_exists(BASE_PATH . '/' . ltrim($institution['logo_path'], '/')) ? getWebImageUrl($institution['logo_path']) : '' ?>";

function toggleMemberSource() {
    let src = document.getElementById('memberDataSource').value;
    document.getElementById('memberDbBox').style.display = src === 'db' ? 'block' : 'none';
    document.getElementById('memberManualBox').style.display = src === 'manual' ? 'block' : 'none';
    document.getElementById('memberCsvBox').style.display = src === 'csv' ? 'block' : 'none';
}

function selectMember(el) {
    if(selectedMemberElem) selectedMemberElem.classList.remove('selected');
    selectedMemberElem = el;
    el.classList.add('selected');
    document.getElementById('memberPhotoUploadBox').style.display = 'block';
}

function filterMembers() {
    let term = document.getElementById('memberSearch')?.value.toLowerCase() || '';
    document.querySelectorAll('#memberList .member-card').forEach(m => {
        let t = (m.dataset.name + ' ' + m.dataset.admno + ' ' + (m.dataset.class || '') + ' ' + (m.dataset.division || '')).toLowerCase();
        m.style.display = t.includes(term) ? '' : 'none';
    });
}

function uploadCustomLogo() {
    let file = document.getElementById('customLeftLogo').files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = function(e) {
        customLeftLogoData = e.target.result;
        document.getElementById('customLogoPreview').innerHTML = `<img src="${customLeftLogoData}" style="height:40px;"> <small class="text-success">Logo ready</small>`;
        regenerateAllCards();
    };
    reader.readAsDataURL(file);
}

function applyExternalPhoto() {
    if(!selectedMemberElem) { alert('Please select a member first.'); return; }
    let fileInput = document.getElementById('externalPhotoFile');
    let file = fileInput.files[0];
    if(!file) { alert('Choose a photo file first.'); return; }
    let reader = new FileReader();
    reader.onload = function(e) {
        selectedMemberElem.dataset.tempPhoto = e.target.result;
        regenerateAllCards();
        alert('External photo applied to this member\'s card (not saved to database).');
    };
    reader.readAsDataURL(file);
}

function updateMemberPhoto() {
    if(!selectedMemberElem) { alert('Please select a member first.'); return; }
    let fileInput = document.getElementById('memberPhotoFile');
    let file = fileInput.files[0];
    if(!file) { alert('Choose a photo file.'); return; }
    let formData = new FormData();
    formData.append('ajax_update_photo', 1);
    formData.append('admno', selectedMemberElem.dataset.admno);
    formData.append('photo', file);
    let statusDiv = document.getElementById('photoUploadStatus');
    statusDiv.innerHTML = '<span class="text-info"><i class="fas fa-spinner fa-spin"></i> Uploading...</span>';
    fetch(window.location.href, { method: 'POST', body: formData })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                selectedMemberElem.dataset.photoUrl = data.path;
                delete selectedMemberElem.dataset.tempPhoto;
                statusDiv.innerHTML = '<span class="text-success">✅ Photo updated successfully!</span>';
                fileInput.value = '';
                regenerateAllCards();
                setTimeout(() => statusDiv.innerHTML = '', 3000);
            } else {
                statusDiv.innerHTML = '<span class="text-danger">❌ ' + (data.error || 'Update failed') + '</span>';
            }
        })
        .catch(err => {
            statusDiv.innerHTML = '<span class="text-danger">❌ Network error.</span>';
            console.error(err);
        });
}

function getSelectedMemberData() {
    if(!selectedMemberElem) { alert('Select a member from the list'); return null; }
    return {
        admno: selectedMemberElem.dataset.admno,
        name: selectedMemberElem.dataset.name,
        roll: selectedMemberElem.dataset.admno,
        classDept: selectedMemberElem.dataset.class || '',
        divisionCourse: selectedMemberElem.dataset.division || '',
        phone: selectedMemberElem.dataset.phone || '',
        designation: selectedMemberElem.dataset.designation || '',
        year: selectedMemberElem.dataset.year || '',
        photoUrl: selectedMemberElem.dataset.tempPhoto || selectedMemberElem.dataset.photoUrl || ''
    };
}

async function fetchPhotoBase64(admno) {
    let url = window.location.href + '?ajax_action=get_photo_base64&admno=' + encodeURIComponent(admno);
    try {
        let resp = await fetch(url);
        let data = await resp.json();
        if (data.success && data.base64) return data.base64;
    } catch(e) { console.error(e); }
    return '';
}

async function generateSelectedMembers() {
    let data = getSelectedMemberData();
    if(data) await generateCard(data);
}

async function generateAllMembers() {
    let members = document.querySelectorAll('#memberList .member-card');
    if(!members.length) return;
    if(confirm(`Generate ${members.length} cards?`)) {
        for(let m of members) {
            await generateCard({
                admno: m.dataset.admno,
                name: m.dataset.name,
                roll: m.dataset.admno,
                classDept: m.dataset.class || '',
                divisionCourse: m.dataset.division || '',
                phone: m.dataset.phone || '',
                designation: m.dataset.designation || '',
                year: m.dataset.year || '',
                photoUrl: m.dataset.tempPhoto || m.dataset.photoUrl || ''
            });
        }
    }
}

async function generateManualCard() {
    let name = document.getElementById('manualName').value.trim();
    let roll = document.getElementById('manualRoll').value.trim();
    if(!name || !roll) { alert('Name and ID required'); return; }
    let designation = document.getElementById('manualDesignation').value.trim();
    let classDept = document.getElementById('manualClassDept').value.trim();
    let divisionCourse = document.getElementById('manualDivisionCourse').value.trim();
    let phone = document.getElementById('manualPhone').value.trim();
    let year = document.getElementById('manualYear').value.trim();
    let photoFile = document.getElementById('manualPhoto').files[0];
    let photoUrl = photoFile ? URL.createObjectURL(photoFile) : '';
    await generateCard({
        admno: roll,
        name,
        roll,
        classDept,
        divisionCourse,
        phone,
        designation,
        year,
        photoUrl,
        tempPhoto: true
    });
}

function importMemberCSV() {
    let file = document.getElementById('memberCsvFile').files[0];
    if(!file) return;
    let reader = new FileReader();
    reader.onload = async function(e) {
        let lines = e.target.result.split('\n');
        let count = 0;
        for(let line of lines) {
            let parts = line.split(',').map(p => p.trim());
            if(parts.length >= 2 && parts[0] && parts[1]) {
                await generateCard({
                    admno: parts[1],
                    name: parts[0],
                    roll: parts[1],
                    designation: parts[2] || '',
                    classDept: parts[3] || '',
                    divisionCourse: parts[4] || '',
                    phone: parts[5] || '',
                    year: parts[6] || '',
                    photoUrl: ''
                });
                count++;
            }
        }
        alert(`Generated ${count} cards from CSV`);
    };
    reader.readAsText(file);
}

async function generateCard(data) {
    let schoolName = document.getElementById('schoolName').value || 'Library', tagline = document.getElementById('tagline').value;
    let rules = document.getElementById('libraryRules').value.replace(/\n/g, '<br>');
    let signature = document.getElementById('signatureText').value;
    let infoLeftMargin = parseInt(document.getElementById('infoLeftMargin').value);
    let infoTopMargin = parseInt(document.getElementById('infoTopMargin').value);
    let infoFontSize = parseInt(document.getElementById('infoFontSize').value);
    let signatureFontSize = parseInt(document.getElementById('signatureFontSize').value);
    let photoTopMargin = parseInt(document.getElementById('photoTopMargin').value);
    let idNoTopOffset = parseInt(document.getElementById('idNoTopOffset').value);
    let infoBlockWidth = parseInt(document.getElementById('infoBlockWidth').value);
    let yearFontSize = parseInt(document.getElementById('yearFontSize').value);
    let headerFontSize = parseInt(document.getElementById('headerFontSize').value);
    let headerBold = document.getElementById('headerBold').checked;
    let showClassDept = document.getElementById('showClassDept').checked;
    let showDivCourse = document.getElementById('showDivCourse').checked;
    let showYear = document.getElementById('showYear').checked;
    let cardId = 'card_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);
    
    let finalPhoto = '';
    if (data.photoUrl && (data.photoUrl.startsWith('blob:') || data.photoUrl.startsWith('data:'))) finalPhoto = data.photoUrl;
    else if (data.admno && !data.tempPhoto) finalPhoto = await fetchPhotoBase64(data.admno);
    let leftLogoUrl = customLeftLogoData ? customLeftLogoData : (institutionLogo ? institutionLogo : '');
    let displayYear = data.year && data.year.trim() !== '' ? data.year : new Date().getFullYear().toString();
    let headerFontWeight = headerBold ? 'bold' : 'normal';
    
    let frontHtml = `<div class="id-card front" style="width:var(--card-width);height:var(--card-height);">`;
    frontHtml += leftLogoUrl ? `<img class="card-logo" src="${leftLogoUrl}" alt="Logo">` : '';
    frontHtml += `<div class="text-center" style="margin-bottom:8px;"><div style="font-size:${headerFontSize}px;font-weight:${headerFontWeight};">${escapeHtml(schoolName)}</div><div style="font-size:9px;">${escapeHtml(tagline)}</div></div>`;
    frontHtml += `<div class="photo" style="top: ${photoTopMargin}px; right: 12px; width: 82px; height: 96px;">${finalPhoto ? `<img src="${finalPhoto}" style="width:100%;height:100%;object-fit:cover;" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-user fa-3x\\'></i>';this.parentElement.classList.add('bg-secondary');">` : '<i class="fas fa-user fa-3x"></i>'}</div>`;
    frontHtml += `<div style="position: absolute; right: 12px; top: ${idNoTopOffset}px; width: 82px; text-align: center; font-size: ${infoFontSize-2}px; color: rgba(255,255,255,0.9);"><strong>ID No:</strong><br>${escapeHtml(data.roll)}</div>`;
    // Info block with width: auto
    frontHtml += `<div style="margin-top:${infoTopMargin}px;padding-left:${infoLeftMargin}px;font-size:${infoFontSize}px; width: auto;">`;
    frontHtml += `<div><strong>Name:</strong> ${escapeHtml(data.name)}</div>`;
    frontHtml += `<div><strong>Desig:</strong> ${escapeHtml(data.designation)}</div>`;
    if (showClassDept) frontHtml += `<div><strong>Clas/Dept:</strong> ${escapeHtml(data.classDept)}</div>`;
    if (showDivCourse) frontHtml += `<div><strong>Div/Cors:</strong> ${escapeHtml(data.divisionCourse)}</div>`;
    frontHtml += `<div><strong>Contact:</strong> ${escapeHtml(data.phone)}</div>`;
    frontHtml += `</div>`;
    // Year at extreme left bottom
    if (showYear) {
        frontHtml += `<div style="position: absolute; bottom: 8px; left: 8px; font-size: ${yearFontSize}px; color: rgba(255,255,255,0.9);"><strong>Year:</strong> ${escapeHtml(displayYear)}</div>`;
    }
    // Barcode/QR centered at bottom
    frontHtml += useQR ? `<div class="qrcode-wrap" id="qrcode-${cardId}"></div>` : `<div class="barcode-wrap"><svg id="barcode-${cardId}"></svg></div>`;
    frontHtml += `</div>`;
    
    let backHtml = `<div class="id-card back" style="width:var(--card-width);height:var(--card-height);"><div style="padding:12px;height:100%;display:flex;flex-direction:column;"><div><strong>Library Rules</strong></div><div style="font-size:9px;flex-grow:1;">${rules}</div><div class="text-center mt-auto"><div style="font-size:${signatureFontSize}px;">${escapeHtml(signature)}</div><div style="border-top:1px solid #999;width:80px;margin:5px auto;"></div><div style="font-size:9px;">Issue: ${new Date().toLocaleDateString()}</div></div></div></div>`;
    
    let pair = document.createElement('div');
    pair.className = 'card-pair';
    pair.setAttribute('data-card-id', cardId);
    let frontDiv = document.createElement('div');
    frontDiv.innerHTML = frontHtml;
    let backDiv = document.createElement('div');
    backDiv.innerHTML = backHtml;
    pair.appendChild(frontDiv.firstChild);
    pair.appendChild(backDiv.firstChild);
    let cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.className = 'card-checkbox';
    cb.checked = true;
    cb.onchange = function(e) { e.stopPropagation(); pair.classList.toggle('selected-for-export', this.checked); };
    pair.appendChild(cb);
    let container = document.getElementById('cardsContainer');
    if(container.querySelector('.py-5')) container.innerHTML = '';
    container.appendChild(pair);
    if(useQR) {
        setTimeout(() => { new QRCode(document.getElementById(`qrcode-${cardId}`), { text: data.roll, width: 60, height: 60 }); }, 50);
    } else {
        setTimeout(() => { JsBarcode(`#barcode-${cardId}`, data.roll.toString(), { format: 'CODE128', width: 1.2, height: 32, displayValue: false, margin: 0 }); }, 50);
    }
    cards.push({ id: cardId, element: pair, data: data });
    updateCardCount();
}

function updatePhotoPosition() {
    let top = document.getElementById('photoTopMargin').value;
    document.querySelectorAll('.id-card.front .photo').forEach(el => el.style.top = top + 'px');
}
function updateIdNoPosition() {
    let top = document.getElementById('idNoTopOffset').value;
    document.querySelectorAll('.id-card.front div[style*="right: 12px; top:"]').forEach(el => {
        if(el.innerText.includes('ID No')) el.style.top = top + 'px';
    });
}
function updateInfoBlockWidth() {
    // This function is now unused because width is auto, but we keep it for compatibility.
    // We could remove the slider, but we'll just leave it.
}
function updateHeaderStyle() {
    let fontSize = document.getElementById('headerFontSize').value;
    let isBold = document.getElementById('headerBold').checked;
    document.querySelectorAll('.id-card.front .text-center > div:first-child').forEach(el => {
        el.style.fontSize = fontSize + 'px';
        el.style.fontWeight = isBold ? 'bold' : 'normal';
    });
}
function resizeCards() {
    let w = document.getElementById('cardWidth').value, h = document.getElementById('cardHeight').value;
    document.documentElement.style.setProperty('--card-width', w + 'px');
    document.documentElement.style.setProperty('--card-height', h + 'px');
}
function setCardSize(w, h) {
    document.getElementById('cardWidth').value = w;
    document.getElementById('cardHeight').value = h;
    resizeCards();
}
function applyTheme(start, end, btn) {
    currentThemeStart = start; currentThemeEnd = end;
    document.documentElement.style.setProperty('--theme-start', start);
    document.documentElement.style.setProperty('--theme-end', end);
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('themeStartColor').value = start;
    document.getElementById('themeEndColor').value = end;
    regenerateAllCards();
}
function applyCustomTheme() {
    let start = document.getElementById('themeStartColor').value, end = document.getElementById('themeEndColor').value;
    currentThemeStart = start; currentThemeEnd = end;
    document.documentElement.style.setProperty('--theme-start', start);
    document.documentElement.style.setProperty('--theme-end', end);
    regenerateAllCards();
}
function regenerateAllCards() {
    if(!cards.length) return;
    let container = document.getElementById('cardsContainer');
    let oldCards = [...cards];
    container.innerHTML = '';
    cards = [];
    (async () => { for(let card of oldCards) await generateCard(card.data); })();
}
function clearCards() {
    if(cards.length && confirm('Clear all cards?')) {
        document.getElementById('cardsContainer').innerHTML = '<div class="text-center text-muted py-5">Select members from left panel and click Generate</div>';
        cards = [];
        updateCardCount();
    }
}
function updateCardCount() { document.getElementById('cardCount').innerText = cards.length; }
function toggleQR() { useQR = document.getElementById('includeQR').checked; regenerateAllCards(); }
function setPrintLayout(cols) {
    currentLayoutCols = cols;
    document.querySelectorAll('.layout-preset').forEach(p => p.classList.remove('active'));
    document.querySelector(`.layout-preset[data-cols="${cols}"]`).classList.add('active');
    let container = document.getElementById('cardsContainer');
    let gap = 20;
    let widthPercent = 100 / cols;
    container.style.display = 'flex';
    container.style.flexWrap = 'wrap';
    container.style.gap = gap + 'px';
    container.style.justifyContent = 'center';
    document.querySelectorAll('.card-pair').forEach(pair => {
        pair.style.flex = `0 0 calc(${widthPercent}% - ${gap}px)`;
        pair.style.maxWidth = `calc(${widthPercent}% - ${gap}px)`;
    });
}
function selectAllCards() {
    document.querySelectorAll('.card-pair').forEach(p => {
        p.classList.add('selected-for-export');
        let cb = p.querySelector('.card-checkbox');
        if(cb) cb.checked = true;
    });
}
function deselectAllCards() {
    document.querySelectorAll('.card-pair').forEach(p => {
        p.classList.remove('selected-for-export');
        let cb = p.querySelector('.card-checkbox');
        if(cb) cb.checked = false;
    });
}
function getSelectedCards() {
    return Array.from(document.querySelectorAll('.card-pair')).filter(p => p.querySelector('.card-checkbox')?.checked);
}
async function exportToPDF(selectedOnly = false) {
    let cardsToExport = selectedOnly ? getSelectedCards() : document.querySelectorAll('.card-pair');
    if(cardsToExport.length === 0) { alert('No cards selected for export'); return; }
    const isColor = document.getElementById('colorPrint').checked;
    const { jsPDF } = window.jspdf;
    const CARD_WIDTH_MM = 85.6, CARD_HEIGHT_MM = 54, PAGE_WIDTH_MM = 210, PAGE_HEIGHT_MM = 297, LEFT_MARGIN = 12, RIGHT_MARGIN = 12, TOP_MARGIN = 15, BOTTOM_MARGIN = 12, HORIZONTAL_GAP = 8, VERTICAL_GAP = 6;
    let cardWidth = CARD_WIDTH_MM, cardHeight = CARD_HEIGHT_MM, horizontalGap = HORIZONTAL_GAP;
    const availableWidth = PAGE_WIDTH_MM - LEFT_MARGIN - RIGHT_MARGIN;
    const twoCardsWidth = (cardWidth * 2) + horizontalGap;
    if (twoCardsWidth > availableWidth) {
        const scale = availableWidth / twoCardsWidth;
        cardWidth = cardWidth * scale;
        cardHeight = cardHeight * scale;
        horizontalGap = horizontalGap * scale;
    }
    let verticalGap = VERTICAL_GAP, cardsPerPage = 5;
    const totalHeightNeeded = (5 * cardHeight) + (4 * VERTICAL_GAP);
    const availableHeight = PAGE_HEIGHT_MM - TOP_MARGIN - BOTTOM_MARGIN;
    if (totalHeightNeeded > availableHeight) {
        cardsPerPage = 4;
        const fourCardsHeight = (4 * cardHeight) + (3 * VERTICAL_GAP);
        if (fourCardsHeight > availableHeight) {
            verticalGap = (availableHeight - (4 * cardHeight)) / 3;
            if (verticalGap < 2) verticalGap = 2;
        }
    }
    async function captureCardElement(el) {
        return new Promise((resolve) => {
            setTimeout(() => {
                html2canvas(el, { scale: 3, backgroundColor: isColor ? null : '#ffffff', useCORS: false, allowTaint: true, logging: false })
                    .then(canvas => resolve(canvas.toDataURL('image/png', 1.0)))
                    .catch(err => { console.error(err); resolve(null); });
            }, 100);
        });
    }
    let cardImages = [];
    for (let i = 0; i < cardsToExport.length; i++) {
        const pair = cardsToExport[i];
        const frontEl = pair.querySelector('.id-card.front');
        const backEl = pair.querySelector('.id-card.back');
        if (frontEl && backEl) {
            const frontImg = await captureCardElement(frontEl);
            const backImg = await captureCardElement(backEl);
            if (frontImg && backImg) cardImages.push({ front: frontImg, back: backImg });
        }
    }
    if (cardImages.length === 0) { alert('Could not generate card images.'); return; }
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    let yPosition = TOP_MARGIN;
    let cardsOnCurrentPage = 0;
    for (let i = 0; i < cardImages.length; i++) {
        const card = cardImages[i];
        if (cardsOnCurrentPage >= cardsPerPage) { doc.addPage(); yPosition = TOP_MARGIN; cardsOnCurrentPage = 0; }
        const frontX = LEFT_MARGIN;
        const backX = LEFT_MARGIN + cardWidth + horizontalGap;
        doc.addImage(card.front, 'PNG', frontX, yPosition, cardWidth, cardHeight);
        doc.addImage(card.back, 'PNG', backX, yPosition, cardWidth, cardHeight);
        yPosition += cardHeight + verticalGap;
        cardsOnCurrentPage++;
    }
    doc.save(selectedOnly ? 'selected_id_cards.pdf' : 'all_id_cards.pdf');
}
async function exportToPNG() {
    let cardsToExport = getSelectedCards();
    if(cardsToExport.length === 0) { alert('Select at least one card first'); return; }
    let tempContainer = document.createElement('div');
    tempContainer.style.position = 'absolute';
    tempContainer.style.top = '-10000px';
    tempContainer.style.background = 'white';
    tempContainer.style.padding = '20px';
    for(let pair of cardsToExport) { tempContainer.appendChild(pair.cloneNode(true)); }
    document.body.appendChild(tempContainer);
    await new Promise(r => setTimeout(r, 200));
    try {
        let canvas = await html2canvas(tempContainer, { scale: 3, backgroundColor: '#ffffff', useCORS: false });
        let link = document.createElement('a');
        link.download = 'id_cards.png';
        link.href = canvas.toDataURL();
        link.click();
    } catch(e) { alert('PNG export error'); }
    finally { document.body.removeChild(tempContainer); }
}

// ==================== BARCODES ====================
let currentBarcodeValues = [];

function toggleBarcodeMode() {
    let mode = document.getElementById('barcodeMode').value;
    document.getElementById('barcodeManualBox').style.display = mode === 'manual' ? 'block' : 'none';
    document.getElementById('barcodeRangeBox').style.display = mode === 'range' ? 'block' : 'none';
    document.getElementById('barcodeBooksBox').style.display = mode === 'books' ? 'block' : 'none';
    document.getElementById('barcodeDateRangeBox').style.display = mode === 'daterange' ? 'block' : 'none';
    if (mode === 'books') loadBooksForBarcode();
}

function loadBooksForBarcode() {
    fetch(window.location.href + '?ajax_action=all_books')
        .then(r => r.json())
        .then(data => {
            let sel = document.getElementById('bookBarcodeSelect');
            sel.innerHTML = data.map(b => `<option value="${escapeHtml(b.barcode)}">${escapeHtml(b.barcode)} - ${escapeHtml(b.title)}</option>`).join('');
        })
        .catch(() => alert('Could not load books'));
}

function loadBarcodesByDateRange() {
    let from = document.getElementById('barcodeDateFrom').value, to = document.getElementById('barcodeDateTo').value;
    if(!from||!to){alert('Select date range');return;}
    fetch(`${window.location.href}?ajax_action=books_by_date&from=${from}&to=${to}`)
        .then(r=>r.json())
        .then(data=>{
            let listDiv=document.getElementById('barcodeFetchedList');
            if(data.books&&data.books.length){
                currentBarcodeValues=data.books.map(b=>b.barcode);
                listDiv.innerHTML=`<strong>${data.books.length}</strong> barcodes fetched`;
                generateBarcodePreview();
            }else{listDiv.innerHTML='No books found'; currentBarcodeValues=[]; document.getElementById('barcodeSheet').innerHTML='<div class="text-muted">No data</div>';}
        })
        .catch(()=>alert('Error'));
}

function getBarcodeValues() {
    let mode = document.getElementById('barcodeMode').value;
    if(mode==='manual') return document.getElementById('barcodeManualInput').value.split('\n').map(v=>v.trim()).filter(v=>v);
    if(mode==='range'){
        let p=document.getElementById('barcodePrefix').value,s=parseInt(document.getElementById('barcodeStart').value),e=parseInt(document.getElementById('barcodeEnd').value),pad=parseInt(document.getElementById('barcodePad').value);
        let arr=[]; for(let i=s;i<=e;i++) arr.push(p+String(i).padStart(pad,'0')); return arr;
    }
    if(mode==='books'){ let sel=document.getElementById('bookBarcodeSelect'); return Array.from(sel.selectedOptions).map(opt=>opt.value); }
    if(mode==='daterange') return currentBarcodeValues;
    return [];
}

function generateBarcodePreview() {
    let values=getBarcodeValues(), header=document.getElementById('barcodeHeader').value, rows=parseInt(document.getElementById('barcodeRows').value), cols=parseInt(document.getElementById('barcodeCols').value), width=parseFloat(document.getElementById('barcodeWidth').value), height=parseInt(document.getElementById('barcodeHeight').value), margin=parseInt(document.getElementById('barcodeMargin').value), showText=document.getElementById('barcodeShowText').value==='true', sheet=document.getElementById('barcodeSheet');
    sheet.innerHTML='';
    sheet.style.display='grid';
    sheet.style.gridTemplateColumns=`repeat(${cols},1fr)`;
    for(let i=0;i<rows*cols;i++){
        let code=values[i%values.length];
        let box=document.createElement('div');
        box.className='barcode-demo-box';
        let hDiv=document.createElement('div');
        hDiv.innerText=header;
        let svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
        box.appendChild(hDiv); box.appendChild(svg);
        if(showText){ let tDiv=document.createElement('div'); tDiv.innerText=code; box.appendChild(tDiv); }
        sheet.appendChild(box);
        JsBarcode(svg,code,{format:'CODE128',width:width,height:height,displayValue:false,margin:margin});
    }
}

async function downloadBarcodePDF() {
    const { jsPDF } = window.jspdf;
    let doc = new jsPDF();
    let values = getBarcodeValues();
    if (!values.length) { alert('No data'); return; }
    let header = document.getElementById('barcodeHeader').value;
    let rows = parseInt(document.getElementById('barcodeRows').value);
    let cols = parseInt(document.getElementById('barcodeCols').value);
    let gapHB = parseInt(document.getElementById('barcodeGapHB').value);
    let gapBV = parseInt(document.getElementById('barcodeGapBV').value);
    let showText = document.getElementById('barcodeShowText').value === 'true';
    let rowGap = parseInt(document.getElementById('barcodeRowGap').value) || 0;
    let colGap = parseInt(document.getElementById('barcodeColGap').value) || 0;
    let pageW = doc.internal.pageSize.getWidth();
    let pageH = doc.internal.pageSize.getHeight();
    let marginX = 10, marginY = 10;
    let totalWidth = pageW - 2 * marginX;
    let totalHeight = pageH - 2 * marginY;
    let cellW = (totalWidth - (cols - 1) * colGap) / cols;
    let cellH = (totalHeight - (rows - 1) * rowGap) / rows;
    let index = 0;
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            let x = marginX + c * (cellW + colGap);
            let y = marginY + r * (cellH + rowGap);
            let code = values[index % values.length];
            doc.setFontSize(10);
            doc.text(header, x + cellW / 2, y + 5, { align: 'center' });
            let barcodeY = y + 5 + gapHB;
            let canvas = document.createElement('canvas');
            let width = parseFloat(document.getElementById('barcodeWidth').value);
            let height = parseInt(document.getElementById('barcodeHeight').value);
            JsBarcode(canvas, code, { format: 'CODE128', width: width, height: height, displayValue: false });
            let img = canvas.toDataURL();
            doc.addImage(img, 'PNG', x + 5, barcodeY, cellW - 10, cellH - 18);
            if (showText) {
                doc.setFontSize(9);
                doc.text(code, x + cellW / 2, barcodeY + (cellH / 2) + gapBV, { align: 'center' });
            }
            index++;
        }
    }
    doc.save('barcode_labels.pdf');
}

// ==================== SPINE LABELS ====================
let spineBooksData = [];

function toggleSpineMode() {
    let mode=document.getElementById('spineMode').value;
    document.getElementById('spineManualBox').style.display=mode==='manual'?'block':'none';
    document.getElementById('spineDateRangeBox').style.display=mode==='daterange'?'block':'none';
    document.getElementById('spineBarcodeRangeBox').style.display=mode==='barcoderange'?'block':'none';
}

function loadSpineBooksByDateRange() {
    let from=document.getElementById('spineDateFrom').value, to=document.getElementById('spineDateTo').value;
    if(!from||!to){alert('Select date range');return;}
    fetch(`${window.location.href}?ajax_action=books_by_date&from=${from}&to=${to}`)
        .then(r=>r.json())
        .then(data=>{
            let listDiv=document.getElementById('spineFetchedList');
            if(data.books&&data.books.length){
                listDiv.innerHTML=`<strong>${data.books.length}</strong> books found. Select below:`;
                let sel=document.getElementById('spineBookSelect');
                sel.style.display='block';
                sel.innerHTML='';
                data.books.forEach(book=>{
                    let opt=document.createElement('option');
                    opt.value=JSON.stringify(book);
                    opt.text=`${book.barcode} - ${book.title} (${book.author||'Unknown'})`;
                    sel.appendChild(opt);
                });
            }else{listDiv.innerHTML='No books found'; document.getElementById('spineBookSelect').style.display='none';}
        })
        .catch(()=>alert('Error'));
}

function generateSpineFromBarcodeRange() {
    let prefix=document.getElementById('spineBarcodePrefix').value, start=parseInt(document.getElementById('spineBarcodeStart').value), end=parseInt(document.getElementById('spineBarcodeEnd').value), pad=parseInt(document.getElementById('spineBarcodePad').value);
    let barcodes=[]; for(let i=start;i<=end;i++) barcodes.push(prefix+String(i).padStart(pad,'0'));
    let fd=new FormData(); fd.append('ajax_action','books_by_barcodes'); fd.append('barcodes',JSON.stringify(barcodes));
    fetch(window.location.href,{method:'POST',body:fd})
        .then(r=>r.json())
        .then(data=>{if(data.books&&data.books.length){spineBooksData=data.books; generateSpineLabelsPDF();}else{alert('No matching books');}})
        .catch(()=>alert('Error'));
}

function generateSpineLabels() {
    let mode=document.getElementById('spineMode').value;
    if(mode==='manual'){
        let author=document.getElementById('spineManualAuthor').value.trim(), title=document.getElementById('spineManualTitle').value.trim(), callNo=document.getElementById('spineManualCallNo').value.trim(), barcode=document.getElementById('spineManualBarcode').value.trim(), qty=parseInt(document.getElementById('spineManualQty').value)||1;
        if(!author&&!title){alert('Enter author or title');return;}
        spineBooksData=[]; for(let i=0;i<qty;i++) spineBooksData.push({author,title,call_number:callNo,barcode});
        generateSpineLabelsPDF();
    }else if(mode==='daterange'){
        let sel=document.getElementById('spineBookSelect');
        let selected=Array.from(sel.selectedOptions).map(opt=>JSON.parse(opt.value));
        if(!selected.length){alert('Select at least one book');return;}
        spineBooksData=selected; generateSpineLabelsPDF();
    }else if(mode==='barcoderange'){
        generateSpineFromBarcodeRange();
    }
}

function drawSpineLabel(doc, book, x, y, cellW, cellH, labelW, labelH, lineSpacing, codeFontSize, callNoFontSize, showBarcodeImg, orientation) {
    let offX = (cellW - labelW) / 2;
    let offY = (cellH - labelH) / 2;
    let startX = x + offX;
    let startY = y + offY;
    doc.rect(startX, startY, labelW, labelH);
    let authorCode = (book.author ? book.author.substring(0, 3) : 'XXX').toUpperCase();
    let titleCode = (book.title ? book.title.charAt(0) : '?').toUpperCase();
    let codeLine = authorCode + " / " + titleCode;
    if (orientation === 'portrait') {
        let textY = startY + 10;
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(codeFontSize);
        doc.text(codeLine, startX + labelW / 2, textY, { align: 'center' });
        textY += lineSpacing + 2;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(callNoFontSize);
        doc.text(book.call_number || 'N/A', startX + labelW / 2, textY, { align: 'center' });
        textY += lineSpacing + 2;
        doc.setFontSize(callNoFontSize - 1);
        doc.text(book.barcode || '', startX + labelW / 2, textY, { align: 'center' });
        if (showBarcodeImg && book.barcode) {
            let canvas = document.createElement('canvas');
            JsBarcode(canvas, book.barcode, { format: 'CODE128', width: 1, height: 15, displayValue: false });
            let img = canvas.toDataURL();
            doc.addImage(img, 'PNG', startX + labelW / 2 - 15, textY + 3, 30, 10);
        }
    } else {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(codeFontSize);
        doc.text(codeLine, startX + 5, startY + labelH / 2 - 8);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(callNoFontSize);
        doc.text(book.call_number || 'N/A', startX + 5, startY + labelH / 2);
        doc.text(book.barcode || '', startX + 5, startY + labelH / 2 + 8);
    }
}

function generateSpineLabelsPDF() {
    if (!spineBooksData.length) { alert('No data'); return; }
    const { jsPDF } = window.jspdf;
    let orientation = document.getElementById('spineOrientation').value;
    let doc = new jsPDF({ orientation, unit: 'mm', format: 'a4' });
    let w = parseFloat(document.getElementById('spineWidth').value);
    let h = parseFloat(document.getElementById('spineHeight').value);
    let lineSpacing = parseFloat(document.getElementById('spineLineSpacing').value);
    let codeFontSize = parseInt(document.getElementById('spineCodeFontSize').value);
    let callNoFontSize = parseInt(document.getElementById('spineCallNoFontSize').value);
    let showBarcodeImg = document.getElementById('spineShowBarcodeImg').value === 'yes';
    let useGrid = document.getElementById('spineUseBarcodeLayout').checked;
    let gridRows = parseInt(document.getElementById('spineGridRows').value);
    let gridCols = parseInt(document.getElementById('spineGridCols').value);
    let gapX = parseFloat(document.getElementById('spineGridGapX').value) || 0;
    let gapY = parseFloat(document.getElementById('spineGridGapY').value) || 0;
    let marginTop = parseFloat(document.getElementById('spineMarginTop').value) || 15;
    let marginLeft = parseFloat(document.getElementById('spineMarginLeft').value) || 15;
    let pageW = doc.internal.pageSize.getWidth();
    let pageH = doc.internal.pageSize.getHeight();
    let idx = 0;
    let totalItems = spineBooksData.length;
    if (useGrid) {
        let perPage = gridRows * gridCols;
        let availableWidth = pageW - marginLeft * 2;
        let availableHeight = pageH - marginTop * 2;
        let cellW = (availableWidth - (gridCols - 1) * gapX) / gridCols;
        let cellH = (availableHeight - (gridRows - 1) * gapY) / gridRows;
        for (let page = 0; page < Math.ceil(totalItems / perPage); page++) {
            for (let r = 0; r < gridRows; r++) {
                for (let c = 0; c < gridCols; c++) {
                    if (idx >= totalItems) break;
                    let book = spineBooksData[idx++];
                    let x = marginLeft + c * (cellW + gapX);
                    let y = marginTop + r * (cellH + gapY);
                    drawSpineLabel(doc, book, x, y, cellW, cellH, w, h, lineSpacing, codeFontSize, callNoFontSize, showBarcodeImg, orientation);
                }
                if (idx >= totalItems) break;
            }
            if (idx < totalItems) doc.addPage();
        }
    } else {
        let rows = parseInt(document.getElementById('spineRows').value) || 5;
        let cols = parseInt(document.getElementById('spineCols').value) || 2;
        let marginX = marginLeft, marginY = marginTop;
        let perPage = rows * cols;
        let cellW = (pageW - marginX * 2) / cols;
        let cellH = (pageH - marginY * 2) / rows;
        for (let page = 0; page < Math.ceil(totalItems / perPage); page++) {
            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    if (idx >= totalItems) break;
                    let book = spineBooksData[idx++];
                    let x = marginX + c * cellW;
                    let y = marginY + r * cellH;
                    drawSpineLabel(doc, book, x, y, cellW, cellH, w, h, lineSpacing, codeFontSize, callNoFontSize, showBarcodeImg, orientation);
                }
                if (idx >= totalItems) break;
            }
            if (idx < totalItems) doc.addPage();
        }
    }
    doc.save('spine_labels.pdf');
}

function clearSpineLabels() {
    spineBooksData = [];
    document.getElementById('spineLabelList').innerHTML = '<p class="text-muted">No labels added yet.</p>';
}

// ==================== SHELF LABELS ====================
function generateShelfLabels() {
    let cn=document.getElementById('callNumber').value.trim(), title=document.getElementById('shelfTitle').value.trim(), qty=parseInt(document.getElementById('labelQty').value)||1, w=parseInt(document.getElementById('shelfWidth').value)||50, h=parseInt(document.getElementById('shelfHeight').value)||30, rows=parseInt(document.getElementById('shelfRows').value)||10, cols=parseInt(document.getElementById('shelfCols').value)||3;
    if(!cn){alert('Enter call number');return;}
    let previewDiv=document.getElementById('shelfPreview');
    previewDiv.innerHTML='';
    previewDiv.style.display='grid';
    previewDiv.style.gridTemplateColumns=`repeat(${cols}, minmax(100px, 1fr))`;
    previewDiv.style.gap='10px';
    for(let i=0;i<qty;i++){
        let label=document.createElement('div');
        label.style.border='1px dashed #aaa';
        label.style.borderRadius='8px';
        label.style.padding='8px';
        label.style.textAlign='center';
        label.style.background='#fff9e6';
        label.style.fontSize='12px';
        label.innerHTML=`<strong>${escapeHtml(cn)}</strong><br>${title?escapeHtml(title):''}`;
        previewDiv.appendChild(label);
    }
}

// ==================== ISBN METADATA PRO ====================
const ISBN_HEADERS = ['Title', 'Author', 'Collaborator', 'Publisher', 'Published Date', 'Pages', 'ISBN13', 'ISBN10', 'Subjects', 'Category', 'DDC Code', 'Language', 'Cover URL', 'Description', 'Edition', 'Series', 'Volume'];
let isbnAllRows = [], isbnOriginalRows = [], isbnFetching = false;
const isbnLogEl = document.getElementById('isbnLog');
const isbnStatusEl = document.getElementById('status');

function isbnLog(msg,type='info') {
    if(!isbnLogEl) return;
    const ts=new Date().toLocaleTimeString();
    const icons={ok:'✅',warn:'⚠️',err:'❌',api:'🌐',info:'📘'};
    isbnLogEl.innerHTML+=`[${ts}] ${icons[type]||'📘'} ${msg}\n`;
    isbnLogEl.scrollTop=isbnLogEl.scrollHeight;
}
function isbnSetStatus(text,type='loading') {
    if(!isbnStatusEl) return;
    if(type==='loading') isbnStatusEl.innerHTML=`<span class="spinner-border spinner-border-sm text-primary"></span> ${text}`;
    else { let cls={ok:'status-ok',warn:'status-warn',err:'status-err'}[type]||''; isbnStatusEl.innerHTML=`<span class="status-badge ${cls}">${text}</span>`; }
}
function cleanISBN(isbn) { return isbn.replace(/[^0-9X]/gi,'').toUpperCase(); }

async function fetchMetadataServerSide(isbn) {
    let url = window.location.href + '?ajax_action=fetch_isbn_metadata&isbn=' + encodeURIComponent(isbn);
    let resp = await fetch(url);
    if (!resp.ok) throw new Error('Server request failed');
    let data = await resp.json();
    if (!data.success) throw new Error(data.error || 'No metadata');
    return data.data;
}
async function fetchAllSourcesServerSide(isbn) {
    let url = window.location.href + '?ajax_action=fetch_all_sources&isbn=' + encodeURIComponent(isbn);
    let resp = await fetch(url);
    if (!resp.ok) throw new Error('Server request failed');
    let data = await resp.json();
    if (!data.success) throw new Error(data.error || 'No sources');
    return data.results;
}

async function fetchAllISBNs() {
    if(isbnFetching){ alert('Already fetching'); return; }
    let isbns = [];
    let active = document.querySelector('#inputTabs .nav-link.active')?.dataset.input || 'manual';
    if(active === 'manual') isbns = document.getElementById('isbnList').value.split('\n').map(s=>s.trim()).filter(s=>s);
    else if(active === 'file') isbns = document.getElementById('isbnList').value.split('\n').map(s=>s.trim()).filter(s=>s);
    else if(active === 'single') { let single = document.getElementById('singleIsbn').value.trim(); if(single) isbns = [single]; else { alert('Enter an ISBN'); return; } }
    if(!isbns.length) { alert('No ISBNs'); return; }
    isbnFetching = true;
    isbnAllRows = [];
    renderIsbnTable([]);
    if(isbnLogEl) isbnLogEl.innerHTML = '';
    isbnSetStatus(`Fetching ${isbns.length} ISBNs (multi‑source)...`, 'loading');
    let progDiv = document.getElementById('progressContainer');
    if(progDiv) progDiv.style.display = 'block';
    let progBar = document.getElementById('fetchProgress'), progStatus = document.getElementById('progressStatus');
    for(let i = 0; i < isbns.length; i++) {
        let isbn = isbns[i];
        if(progStatus) progStatus.innerText = `Processing ${i+1}/${isbns.length}: ${isbn}`;
        if(progBar) progBar.style.width = `${(i/isbns.length)*100}%`;
        try {
            let metadata = await fetchMetadataServerSide(isbn);
            isbnAllRows.push(metadata);
            renderIsbnTable(isbnAllRows);
            isbnLog(`[${i+1}/${isbns.length}] ${isbn} -> ${metadata.Title || 'No title'}`, metadata.Title ? 'ok' : 'warn');
        } catch(e) {
            isbnLog(`[${i+1}/${isbns.length}] ${isbn} failed: ${e.message}`, 'err');
            isbnAllRows.push({ Title: '', Author: '', Collaborator: '', Publisher: '', 'Published Date': '', Pages: '', ISBN13: (isbn.length === 13) ? isbn : '', ISBN10: (isbn.length === 10) ? isbn : '', Subjects: '', Category: '', 'DDC Code': '', Language: '', 'Cover URL': '', Description: '', Edition: '', Series: '', Volume: '', Remarks: `Error: ${e.message}` });
            renderIsbnTable(isbnAllRows);
        }
        await new Promise(r => setTimeout(r, 300));
    }
    isbnOriginalRows = JSON.parse(JSON.stringify(isbnAllRows));
    if(progBar) progBar.style.width = '100%';
    if(progStatus) progStatus.innerText = `Completed: ${isbnAllRows.filter(r=>r.Title).length}/${isbns.length} found`;
    isbnSetStatus(`Complete! ${isbnAllRows.filter(r=>r.Title).length}/${isbns.length} found`, isbnAllRows.some(r=>r.Title) ? 'ok' : 'err');
    isbnLog(`Fetch completed. ${isbnAllRows.filter(r=>r.Title).length} out of ${isbns.length} records have metadata.`, 'ok');
    if(progDiv) setTimeout(()=>progDiv.style.display='none', 1500);
    isbnFetching = false;
}

function testISBNFetching() {
    document.getElementById('isbnList').value = '9780132350884\n9780596007126\n9780201633610';
    isbnLog('Test ISBNs loaded. Click "Fetch All" to retrieve metadata.', 'ok');
    alert('Test ISBNs added. Now click "Fetch All".');
}

async function fetchSingleISBN() {
    let isbn = document.getElementById('singleIsbn').value.trim();
    if(!isbn) { alert('Enter ISBN'); return; }
    let resultDiv = document.getElementById('singleResult');
    resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Fetching...';
    try {
        let data = await fetchMetadataServerSide(isbn);
        resultDiv.innerHTML = `<div class="card p-2 mt-2"><strong>${escapeHtml(data.Title)}</strong><br>Author: ${escapeHtml(data.Author)}<br>Publisher: ${escapeHtml(data.Publisher)}<br>Pages: ${data.Pages}<br>Edition: ${data.Edition||'N/A'}<br>Cover: ${data['Cover URL'] ? `<a href="${data['Cover URL']}" target="_blank">View</a>` : 'N/A'}<br><button class="btn btn-sm btn-primary mt-2" onclick="addSingleToTable('${isbn}')">Add to List</button></div>`;
        window.singleBookData = data;
    } catch(e) {
        resultDiv.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`;
    }
}

function addSingleToTable(isbn) {
    if(window.singleBookData) {
        isbnAllRows.push(window.singleBookData);
        renderIsbnTable(isbnAllRows);
        isbnOriginalRows = JSON.parse(JSON.stringify(isbnAllRows));
        isbnLog(`Added single ISBN ${isbn} to table`, 'ok');
    } else alert('No data to add');
}

function importFromFile() {
    let file = document.getElementById('csvFile').files[0];
    if(!file) { alert('Select a CSV/Excel file'); return; }
    let reader = new FileReader();
    reader.onload = function(e) {
        let data = e.target.result;
        let wb = XLSX.read(data, { type: 'binary' });
        let sheet = wb.Sheets[wb.SheetNames[0]];
        let rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        let isbns = [];
        for(let row of rows) {
            if(row[0]) {
                let cleaned = cleanISBN(row[0].toString());
                if(cleaned) isbns.push(cleaned);
            }
        }
        document.getElementById('isbnList').value = isbns.join('\n');
        isbnLog(`Imported ${isbns.length} ISBNs from file`, 'ok');
        alert(`Imported ${isbns.length} ISBNs. Now click "Fetch All".`);
        switchInputMode('manual');
    };
    reader.readAsBinaryString(file);
}

function renderIsbnTable(rows) {
    let table = document.getElementById('resultTable'), thead = document.getElementById('headerRow'), tbody = document.getElementById('tableBody');
    if(!table) return;
    thead.innerHTML = '';
    tbody.innerHTML = '';
    ISBN_HEADERS.forEach(h => { let th = document.createElement('th'); th.textContent = h; thead.appendChild(th); });
    rows.forEach((row, idx) => {
        let tr = document.createElement('tr');
        ISBN_HEADERS.forEach(header => {
            let td = document.createElement('td');
            let val = row[header] || '';
            if(header === 'Cover URL' && val && val.startsWith('http')) {
                td.innerHTML = `<img src="${escapeHtml(val)}" style="max-width:50px; border-radius:4px;"><br><a href="${escapeHtml(val)}" target="_blank">View</a>`;
            } else if(header === 'Description') {
                td.innerHTML = `<textarea class="form-control form-control-sm" data-field="${header}" data-row="${idx}" rows="2">${escapeHtml(val)}</textarea>`;
            } else {
                td.innerHTML = `<input type="text" class="form-control form-control-sm" data-field="${header}" data-row="${idx}" value="${escapeHtml(val)}">`;
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    document.querySelectorAll('#resultTable input, #resultTable textarea').forEach(el => {
        el.removeEventListener('change', isbnEditChange);
        el.addEventListener('change', isbnEditChange);
    });
    table.style.display = rows.length ? 'table' : 'none';
    document.getElementById('recordCount').innerText = `${rows.length} records`;
}

function isbnEditChange(e) {
    let row = parseInt(e.target.dataset.row), field = e.target.dataset.field;
    if(!isNaN(row) && field && isbnAllRows[row]) isbnAllRows[row][field] = e.target.value;
}

function revertAllEdits() {
    if(isbnOriginalRows.length) {
        isbnAllRows = JSON.parse(JSON.stringify(isbnOriginalRows));
        renderIsbnTable(isbnAllRows);
        isbnLog('Reverted all edits', 'ok');
    } else isbnLog('No original data to revert', 'warn');
}

function exportIsbnToExcel() {
    if(!isbnAllRows.length) { alert('No data'); return; }
    let exportData = isbnAllRows.map(row => {
        let obj = {};
        ISBN_HEADERS.forEach(h => { obj[h] = row[h] || ''; });
        return obj;
    });
    let ws = XLSX.utils.json_to_sheet(exportData);
    let wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ISBN_Metadata');
    XLSX.writeFile(wb, `isbn_metadata_${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.xlsx`);
    isbnLog(`Exported ${isbnAllRows.length} records to Excel`, 'ok');
}

async function addSelectedToLibrary() {
    if(!isbnAllRows.length) { alert('No records'); return; }
    if(!confirm(`Add ${isbnAllRows.length} books to library catalog?`)) return;
    isbnSetStatus('Adding books...', 'loading');
    let added = 0, failed = 0;
    for(let book of isbnAllRows) {
        if(!book.Title) continue;
        let fd = new FormData();
        fd.append('action', 'add_from_isbn');
        fd.append('title', book.Title);
        fd.append('author', book.Author);
        fd.append('publisher', book.Publisher);
        fd.append('isbn', book.ISBN13 || book.ISBN10);
        fd.append('pages', book.Pages);
        fd.append('call_number', book['DDC Code'] || '');
        fd.append('category', book.Category);
        fd.append('description', book.Description || '');
        fd.append('edition', book.Edition || '');
        fd.append('series', book.Series || '');
        try {
            let resp = await fetch('../admin/ajax_books.php', { method: 'POST', body: fd });
            let result = await resp.json();
            if(result.success) added++; else failed++;
        } catch(e) { failed++; }
        await new Promise(r => setTimeout(r, 200));
    }
    isbnSetStatus(`Added ${added} books, ${failed} failed`, added ? 'ok' : 'err');
    isbnLog(`Library import complete: ${added} added, ${failed} failed`, added ? 'ok' : 'warn');
}

function clearIsbn() {
    if(isbnAllRows.length && confirm('Clear all data?')) {
        isbnAllRows = [];
        isbnOriginalRows = [];
        renderIsbnTable([]);
        document.getElementById('isbnList').value = '';
        if(isbnLogEl) isbnLogEl.innerHTML = '';
        isbnSetStatus('Ready');
        isbnLog('Cleared all data', 'info');
    }
}
function switchInputMode(mode) {
    document.getElementById('manualInputDiv').style.display = mode === 'manual' ? 'block' : 'none';
    document.getElementById('fileInputDiv').style.display = mode === 'file' ? 'block' : 'none';
    document.getElementById('singleInputDiv').style.display = mode === 'single' ? 'block' : 'none';
    document.querySelectorAll('#inputTabs .nav-link').forEach(tab => {
        if(tab.dataset.input === mode) tab.classList.add('active');
        else tab.classList.remove('active');
    });
}
document.getElementById('btnFetch')?.addEventListener('click', fetchAllISBNs);
document.getElementById('btnExcel')?.addEventListener('click', exportIsbnToExcel);
document.getElementById('btnClear')?.addEventListener('click', clearIsbn);
isbnLog('ISBN Metadata Pro ready (multi‑source: OpenLibrary, Google Books, ISBNdb, WorldCat, Z39.50 if configured).', 'info');
isbnSetStatus('Ready');

// ==================== PDF TOOLBOX (Fully functional) ====================
let pdfFiles = [];

function setupPDFDropZone() {
    let dropZone = document.getElementById('pdfDropZone');
    let fileInput = document.getElementById('pdfInput');
    dropZone.addEventListener('click', () => fileInput.click());
    dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.style.borderColor = '#1e3c72'; });
    dropZone.addEventListener('dragleave', e => { dropZone.style.borderColor = '#1e3c72'; });
    dropZone.addEventListener('drop', e => {
        e.preventDefault();
        addPDFFiles(Array.from(e.dataTransfer.files).filter(f => f.type === 'application/pdf'));
    });
    fileInput.addEventListener('change', e => addPDFFiles(Array.from(e.target.files)));
}

function addPDFFiles(files) {
    files.forEach(file => { pdfFiles.push({ name: file.name, file: file }); });
    updatePDFFileList();
    updatePDFSelects();
}

function updatePDFFileList() {
    let listDiv = document.getElementById('pdfFileList');
    listDiv.innerHTML = pdfFiles.map((f, i) =>
        `<div class="file-item">📄 ${f.name} <button class="btn btn-sm btn-danger" onclick="removePDF(${i})">×</button></div>`
    ).join('');
}

function removePDF(idx) {
    pdfFiles.splice(idx, 1);
    updatePDFFileList();
    updatePDFSelects();
}

function updatePDFSelects() {
    let select = document.getElementById('pdfSelect');
    let wmSelect = document.getElementById('wmPDFSelect');
    let rotateSelect = document.getElementById('rotateSelect');
    let options = pdfFiles.map((f, i) => `<option value="${i}">${f.name}</option>`).join('');
    select.innerHTML = options;
    wmSelect.innerHTML = options;
    rotateSelect.innerHTML = options;
}

async function mergePDFs() {
    if (pdfFiles.length < 2) { alert("Select at least 2 PDFs"); return; }
    const { PDFDocument } = PDFLib;
    const mergedPdf = await PDFDocument.create();
    for (let pdf of pdfFiles) {
        let bytes = await pdf.file.arrayBuffer();
        let pdfDoc = await PDFDocument.load(bytes);
        let pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
        pages.forEach(page => mergedPdf.addPage(page));
    }
    const pdfBytes = await mergedPdf.save();
    downloadPDF(pdfBytes, 'merged.pdf');
}

async function splitPDF() {
    let idx = document.getElementById('pdfSelect').value;
    if (idx === '') { alert("Select a PDF"); return; }
    let pdfFile = pdfFiles[parseInt(idx)];
    let range = document.getElementById('pageRange').value;
    if (!range) { alert("Enter page range"); return; }
    let pages = parsePageRange(range);
    const { PDFDocument } = PDFLib;
    let bytes = await pdfFile.file.arrayBuffer();
    let pdfDoc = await PDFDocument.load(bytes);
    let totalPages = pdfDoc.getPageCount();
    let validPages = pages.filter(p => p >= 1 && p <= totalPages);
    if (validPages.length === 0) { alert("No valid pages"); return; }
    const newPdf = await PDFDocument.create();
    let indices = validPages.map(p => p - 1);
    let copied = await newPdf.copyPages(pdfDoc, indices);
    copied.forEach(p => newPdf.addPage(p));
    let out = await newPdf.save();
    downloadPDF(out, 'extracted.pdf');
}
function extractPages() { splitPDF(); }

function parsePageRange(str) {
    let pages = [];
    str.split(',').forEach(part => {
        if (part.includes('-')) {
            let [s, e] = part.split('-').map(Number);
            for (let i = s; i <= e; i++) pages.push(i);
        } else pages.push(Number(part));
    });
    return pages;
}

function toggleWatermarkType() {
    let t = document.getElementById('wmType').value;
    document.getElementById('wmTextDiv').style.display = t === 'text' ? 'block' : 'none';
    document.getElementById('wmImageDiv').style.display = t === 'image' ? 'block' : 'none';
}

async function addWatermark() {
    let idx = document.getElementById('wmPDFSelect').value;
    if (idx === '') { alert("Select a PDF"); return; }
    let pdfFile = pdfFiles[parseInt(idx)];
    const { PDFDocument, rgb, degrees } = PDFLib;
    let bytes = await pdfFile.file.arrayBuffer();
    let pdfDoc = await PDFDocument.load(bytes);
    let type = document.getElementById('wmType').value;
    let pages = pdfDoc.getPages();
    for (let page of pages) {
        let { width, height } = page.getSize();
        if (type === 'text') {
            let text = document.getElementById('wmText').value;
            let fontSize = parseInt(document.getElementById('wmFontSize').value);
            let opacity = parseFloat(document.getElementById('wmOpacity').value);
            let color = document.getElementById('wmColor').value;
            let c = hexToRgb(color);
            page.drawText(text, {
                x: width / 2,
                y: height / 2,
                size: fontSize,
                color: rgb(c.r / 255, c.g / 255, c.b / 255),
                opacity: opacity,
                rotate: degrees(45),
                textAlign: 'center'
            });
        } else {
            let imgFile = document.getElementById('wmImageFile').files[0];
            if (!imgFile) { alert("Select an image"); return; }
            let imgBytes = await imgFile.arrayBuffer();
            let pngImage = await pdfDoc.embedPng(imgBytes);
            let scale = parseFloat(document.getElementById('wmImageScale').value);
            let imgWidth = pngImage.width * scale;
            let imgHeight = pngImage.height * scale;
            page.drawImage(pngImage, {
                x: width / 2 - imgWidth / 2,
                y: height / 2 - imgHeight / 2,
                width: imgWidth,
                height: imgHeight,
                opacity: 0.3
            });
        }
    }
    let out = await pdfDoc.save();
    downloadPDF(out, 'watermarked.pdf');
}

function hexToRgb(hex) {
    let res = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return res ? { r: parseInt(res[1], 16), g: parseInt(res[2], 16), b: parseInt(res[3], 16) } : { r: 0, g: 0, b: 0 };
}

function downloadPDF(bytes, filename) {
    let blob = new Blob([bytes], { type: 'application/pdf' });
    let link = document.getElementById('pdfDownloadLink');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.getElementById('pdfDownload').style.display = 'block';
    link.click();
}

async function rotatePDF(angle) {
    let idx = document.getElementById('rotateSelect').value;
    if (idx === '') { alert('Select a PDF'); return; }
    let pdfFile = pdfFiles[parseInt(idx)];
    const { PDFDocument, degrees } = PDFLib;
    let bytes = await pdfFile.file.arrayBuffer();
    let pdfDoc = await PDFDocument.load(bytes);
    let pages = pdfDoc.getPages();
    for (let page of pages) {
        page.setRotation(degrees(angle));
    }
    let out = await pdfDoc.save();
    downloadPDF(out, `rotated_${pdfFile.name}`);
}

async function compressPDF() {
    let idx = document.getElementById('pdfSelect').value;
    if (idx === '') { alert('Select a PDF'); return; }
    let pdfFile = pdfFiles[parseInt(idx)];
    const { PDFDocument } = PDFLib;
    let bytes = await pdfFile.file.arrayBuffer();
    let pdfDoc = await PDFDocument.load(bytes);
    let out = await pdfDoc.save({ useObjectStreams: true, compress: true });
    downloadPDF(out, `compressed_${pdfFile.name}`);
}

// ==================== EXPORT/IMPORT ====================
async function bulkImportBooks() {
    let file = document.getElementById('bulkBooksFile').files[0];
    if (!file) { alert('Select a CSV/Excel file'); return; }
    let reader = new FileReader();
    reader.onload = async function(e) {
        let data = e.target.result;
        let workbook = XLSX.read(data, { type: 'binary' });
        let sheet = workbook.Sheets[workbook.SheetNames[0]];
        let rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        let books = [];
        for (let i = 1; i < rows.length; i++) {
            let row = rows[i];
            if (!row[0] || !row[1]) continue;
            books.push({
                barcode: row[0].toString(),
                title: row[1].toString(),
                author: row[2] ? row[2].toString() : '',
                publisher: row[3] ? row[3].toString() : '',
                isbn: row[4] ? row[4].toString() : '',
                call_number: row[5] ? row[5].toString() : '',
                category: row[6] ? row[6].toString() : '',
                pages: row[7] ? parseInt(row[7]) : null,
                description: row[8] ? row[8].toString() : ''
            });
        }
        if (!books.length) { alert('No valid book records. Format: Barcode, Title, Author, Publisher, ISBN, Call Number, Category, Pages, Description'); return; }
        let statusDiv = document.getElementById('bulkImportStatus');
        statusDiv.innerHTML = '<span class="text-info"><i class="fas fa-spinner fa-spin"></i> Importing...</span>';
        let formData = new FormData();
        formData.append('ajax_action', 'bulk_import_books');
        formData.append('books_data', JSON.stringify(books));
        let response = await fetch(window.location.href, { method: 'POST', body: formData });
        let result = await response.json();
        if (result.success) {
            statusDiv.innerHTML = `<span class="text-success">✅ Imported ${result.added} books, ${result.failed} failed.</span>`;
        } else {
            statusDiv.innerHTML = `<span class="text-danger">❌ Import failed.</span>`;
        }
    };
    reader.readAsBinaryString(file);
}

async function bulkImportMembers() {
    let file = document.getElementById('bulkMembersFile').files[0];
    if (!file) { alert('Select a CSV/Excel file'); return; }
    let reader = new FileReader();
    reader.onload = async function(e) {
        let data = e.target.result;
        let workbook = XLSX.read(data, { type: 'binary' });
        let sheet = workbook.Sheets[workbook.SheetNames[0]];
        let rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        let members = [];
        for (let i = 1; i < rows.length; i++) {
            let row = rows[i];
            if (!row[0] || !row[1]) continue;
            members.push({
                admno: row[0].toString(),
                name: row[1].toString(),
                category: row[2] ? row[2].toString() : 'Student',
                class: row[3] ? row[3].toString() : '',
                division: row[4] ? row[4].toString() : '',
                phone: row[5] ? row[5].toString() : '',
                email: row[6] ? row[6].toString() : '',
                designation: row[7] ? row[7].toString() : '',
                academic_year: row[8] ? row[8].toString() : ''
            });
        }
        if (!members.length) { alert('No valid member records. Format: AdmNo, Name, Category, Class, Division, Phone, Email, Designation, Academic Year'); return; }
        let statusDiv = document.getElementById('bulkMemberStatus');
        statusDiv.innerHTML = '<span class="text-info"><i class="fas fa-spinner fa-spin"></i> Importing...</span>';
        let formData = new FormData();
        formData.append('ajax_action', 'bulk_import_members');
        formData.append('members_data', JSON.stringify(members));
        let response = await fetch(window.location.href, { method: 'POST', body: formData });
        let result = await response.json();
        if (result.success) {
            statusDiv.innerHTML = `<span class="text-success">✅ Imported ${result.added} members, ${result.failed} failed.</span>`;
        } else {
            statusDiv.innerHTML = `<span class="text-danger">❌ Import failed.</span>`;
        }
    };
    reader.readAsBinaryString(file);
}

function exportBooksCSV() {
    window.location.href = '../admin/export_books.php?format=csv';
}

// ==================== UTILITY ====================
function escapeHtml(s) {
    return String(s || '').replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]);
}

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', function() {
    toggleMemberSource();
    toggleBarcodeMode();
    toggleSpineMode();
    toggleWatermarkType();
    setupPDFDropZone();
    loadBooksForBarcode();
    document.getElementById('memberSearch')?.addEventListener('keyup', filterMembers);
    document.querySelectorAll('.size-preset').forEach(p => p.addEventListener('click', function() {
        document.querySelectorAll('.size-preset').forEach(s => s.classList.remove('active'));
        this.classList.add('active');
    }));
    document.querySelector('.size-preset')?.classList.add('active');
    resizeCards();
    setPrintLayout(2);
});
</script>

<?php renderFooter(); ?>