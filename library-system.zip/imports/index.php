<?php
/**
 * COMPREHENSIVE DATA IMPORT MODULE - FULLY UPDATED
 * Supports CSV, Excel, JSON, XML, MARC, ZIP (photos/covers)
 * Now includes all advanced fields for members and books.
 * ENHANCED: Cover/photo preview during mapping, improved UI/UX, better alignment.
 * FIXED: Automatic encoding detection & conversion to UTF-8 for universal language support.
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('max_execution_time', 300);
ini_set('memory_limit', '512M');
ini_set('upload_max_filesize', '100M');
ini_set('post_max_size', '100M');

// Force UTF-8 internal encoding
if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}

// -------------------- AUTO-DETECT db.php --------------------
$possiblePaths = [
    __DIR__ . '/../config/db.php',
    __DIR__ . '/../includes/db.php',
    __DIR__ . '/../../config/db.php',
    __DIR__ . '/db.php'
];
$dbLoaded = false;
foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $dbLoaded = true;
        break;
    }
}
if (!$dbLoaded) die("Fatal error: db.php not found.");

// -------------------- LOAD FUNCTIONS --------------------
$functionsPaths = [
    __DIR__ . '/../config/functions.php',
    __DIR__ . '/../includes/functions.php',
    __DIR__ . '/functions.php'
];
foreach ($functionsPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

// -------------------- CONSTANTS --------------------
if (!defined('MEMBER_PHOTO_DIR')) {
    define('MEMBER_PHOTO_DIR', __DIR__ . '/../uploads/member_photos/');
}
if (!defined('BOOK_COVER_DIR')) {
    define('BOOK_COVER_DIR', __DIR__ . '/../uploads/book_covers/');
}
if (!defined('IMPORT_LOG_DIR')) {
    define('IMPORT_LOG_DIR', __DIR__ . '/../logs/imports/');
}
if (!defined('TEMP_IMPORT_DIR')) {
    define('TEMP_IMPORT_DIR', __DIR__ . '/temp_imports/');
}

foreach ([MEMBER_PHOTO_DIR, BOOK_COVER_DIR, IMPORT_LOG_DIR, TEMP_IMPORT_DIR] as $dir) {
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    if (!is_writable($dir)) {
        die("Directory not writable: $dir");
    }
}

// -------------------- SECURITY --------------------
if (!function_exists('requireAdmin')) {
    function requireAdmin() {
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
            header('Location: ../login.php');
            exit;
        }
    }
}
requireAdmin();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$excelAvailable = class_exists('PhpOffice\PhpSpreadsheet\IOFactory');
$marcAvailable = class_exists('File_MARC');
if (!$marcAvailable && file_exists(__DIR__ . '/../../vendor/autoload.php')) {
    require_once __DIR__ . '/../../vendor/autoload.php';
    $marcAvailable = class_exists('File_MARC');
}

// ==================== ENCODING CONVERSION HELPER ====================
if (!function_exists('convertCsvToUtf8')) {
    /**
     * Detects the encoding of a CSV file and converts it to UTF-8 (with BOM removed).
     * Returns the path to the converted file (overwrites original if $overwrite is true).
     */
    function convertCsvToUtf8($inputPath, $outputPath = null, $overwrite = false) {
        if ($outputPath === null) {
            $outputPath = $inputPath;
        }
        $content = file_get_contents($inputPath);
        if ($content === false) {
            return false;
        }
        // Detect encoding (try common ones)
        $encoding = mb_detect_encoding($content, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'UTF-16LE', 'UTF-16BE', 'ISO-8859-6', 'ISO-8859-7'], true);
        if ($encoding === false) {
            // Fallback to UTF-8
            $encoding = 'UTF-8';
        }
        // Convert to UTF-8 if not already
        if ($encoding !== 'UTF-8') {
            $content = mb_convert_encoding($content, 'UTF-8', $encoding);
        }
        // Remove UTF-8 BOM if present
        if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
            $content = substr($content, 3);
        }
        // Write back
        if ($overwrite || $outputPath === $inputPath) {
            return file_put_contents($inputPath, $content) !== false;
        } else {
            return file_put_contents($outputPath, $content) !== false;
        }
    }
}

// ==================== CSV HELPER WITH BOM HANDLING (fallback) ====================
if (!function_exists('prepareCsvHandle')) {
    /**
     * Open a CSV file in binary mode and skip the UTF-8 BOM if present.
     * Returns the file handle or false on failure.
     */
    function prepareCsvHandle($filePath) {
        $handle = fopen($filePath, 'rb');
        if (!$handle) return false;
        // Read first 3 bytes to check for BOM
        $bom = fread($handle, 3);
        if ($bom !== "\xEF\xBB\xBF") {
            // No BOM, rewind to start
            fseek($handle, 0);
        }
        // else BOM skipped, pointer is at position 3
        return $handle;
    }
}

// ==================== HELPER FUNCTIONS ====================
function showToast($message, $type = 'success') {
    $_SESSION['toast'] = ['message' => $message, 'type' => $type];
}

function logActivity($username, $action, $details = '') {
    $db = getDB();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$username, $action, $details, $ip]);
}

function autoResizeImage($source, $target, $maxWidth, $maxHeight, $quality = 85) {
    $info = getimagesize($source);
    if (!$info) return false;
    $src = null;
    switch ($info[2]) {
        case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($source); break;
        case IMAGETYPE_PNG: $src = imagecreatefrompng($source); break;
        case IMAGETYPE_GIF: $src = imagecreatefromgif($source); break;
        case IMAGETYPE_WEBP: $src = imagecreatefromwebp($source); break;
        default: return false;
    }
    $origW = imagesx($src);
    $origH = imagesy($src);
    $ratio = min($maxWidth / $origW, $maxHeight / $origH);
    $newW = max(1, (int)($origW * $ratio));
    $newH = max(1, (int)($origH * $ratio));
    $dst = imagecreatetruecolor($newW, $newH);
    if ($info[2] == IMAGETYPE_PNG) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
        imagefilledrectangle($dst, 0, 0, $newW, $newH, $transparent);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $origW, $origH);
    $success = false;
    switch ($info[2]) {
        case IMAGETYPE_JPEG: $success = imagejpeg($dst, $target, $quality); break;
        case IMAGETYPE_PNG: $success = imagepng($dst, $target, 9); break;
        case IMAGETYPE_GIF: $success = imagegif($dst, $target); break;
        case IMAGETYPE_WEBP: $success = imagewebp($dst, $target, $quality); break;
    }
    imagedestroy($src);
    imagedestroy($dst);
    return $success;
}

function renderHeader($title) {
    $settings = getSettings();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> - Library ERP</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            .progress-bar { transition: width 0.3s; }
            .mapping-row { border-bottom: 1px solid #dee2e6; padding: 8px 0; }
            .preview-table { font-size: 0.85rem; }
            .preview-table td, .preview-table th { vertical-align: middle; }
            .preview-table .preview-image { max-height: 60px; max-width: 60px; object-fit: cover; border-radius: 4px; border: 1px solid #dee2e6; }
            .sample-preview { background: #f8f9fa; padding: 12px; border-radius: 8px; font-size: 0.8rem; margin-top: 15px; }
            .remote-url-card { background: #e9ecef; border-left: 4px solid #0d6efd; }
            .import-tab-content { padding-top: 20px; }
            .card-import { border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
            .card-import .card-header { border-radius: 16px 16px 0 0; font-weight: 600; }
            .mapping-select { min-width: 180px; }
            .image-preview-cell { text-align: center; }
            @media (max-width: 768px) {
                .preview-table { font-size: 0.7rem; }
                .preview-table .preview-image { max-height: 40px; max-width: 40px; }
                .mapping-select { min-width: 100px; }
            }
        </style>
    </head>
    <body>
        <div class="container-fluid px-4">
    <?php
    if (isset($_SESSION['toast'])) {
        $toast = $_SESSION['toast'];
        echo "<div class='alert alert-{$toast['type']} alert-dismissible fade show mt-3' role='alert'>
                {$toast['message']}
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
              </div>";
        unset($_SESSION['toast']);
    }
}

function renderFooter() {
    ?>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
}

function logImport($type, $filename, $records, $added, $updated, $failed, $errors = []) {
    $log = [
        'timestamp' => date('Y-m-d H:i:s'),
        'user' => $_SESSION['username'] ?? 'unknown',
        'type' => $type,
        'filename' => $filename,
        'records' => $records,
        'added' => $added,
        'updated' => $updated,
        'failed' => $failed,
        'errors' => array_slice($errors, 0, 20)
    ];
    $logFile = IMPORT_LOG_DIR . date('Y-m-d') . '.json';
    $existing = file_exists($logFile) ? json_decode(file_get_contents($logFile), true) : [];
    $existing[] = $log;
    file_put_contents($logFile, json_encode($existing, JSON_PRETTY_PRINT));
}

// -------------------- DATA PARSERS (JSON, XML) --------------------
function parseJsonFile($filePath) {
    $json = file_get_contents($filePath);
    $data = json_decode($json, true);
    if (!is_array($data)) return [];
    if (isset($data[0]) && is_array($data[0])) return $data;
    return [$data];
}

function parseXmlFile($filePath, $recordTag = 'record') {
    $xml = simplexml_load_file($filePath);
    if (!$xml) return [];
    $records = [];
    foreach ($xml->$recordTag as $record) {
        $row = [];
        foreach ($record->children() as $field) {
            $row[(string)$field->getName()] = (string)$field;
        }
        if (!empty($row)) $records[] = $row;
    }
    return $records;
}

// -------------------- EXCEL TO CSV CONVERTER --------------------
function excelToCsv($inputPath, $outputPath) {
    global $excelAvailable;
    if (!$excelAvailable) {
        throw new Exception("PhpSpreadsheet is required to process Excel files. Please install via: composer require phpoffice/phpspreadsheet");
    }
    $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($inputPath);
    $worksheet = $spreadsheet->getActiveSheet();
    $rows = $worksheet->toArray();
    if (empty($rows)) throw new Exception("No data found in Excel file");
    $fp = fopen($outputPath, 'w');
    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    fclose($fp);
    return $outputPath;
}

// -------------------- AJAX HANDLERS (preview, chunk import) --------------------
if (isset($_GET['preview'])) {
    header('Content-Type: application/json');
    if (!isset($_SESSION['csrf_token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['error' => 'Invalid token']); exit;
    }
    $importType = $_GET['type'];
    $filePath = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '.csv';
    // If the original was Excel, we have a CSV copy
    if (!file_exists($filePath)) {
        // fallback to original extension (maybe CSV)
        $ext = $_SESSION['import_ext'] ?? 'csv';
        $origPath = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '.' . $ext;
        if (file_exists($origPath) && $ext !== 'csv') {
            // Convert to CSV on the fly
            try {
                excelToCsv($origPath, $filePath);
                // Convert to UTF-8
                convertCsvToUtf8($filePath, null, true);
            } catch (Exception $e) {
                echo json_encode(['error' => $e->getMessage()]); exit;
            }
        } else {
            echo json_encode(['error' => 'Uploaded file not found. Please re-upload.']); exit;
        }
    }

    // Open CSV with BOM handling
    $handle = prepareCsvHandle($filePath);
    if (!$handle) {
        echo json_encode(['error' => 'Cannot open file']); exit;
    }

    $headers = fgetcsv($handle);
    if (!$headers) { echo json_encode(['error' => 'Empty file']); exit; }
    $headers = array_map(function($h) { return trim(str_replace("\xEF\xBB\xBF", '', $h)); }, $headers);

    $previewRows = [];
    $rowCount = 0;
    while (($row = fgetcsv($handle)) !== FALSE && $rowCount < 5) {
        $rowData = [];
        foreach ($headers as $idx => $header) {
            $rowData[$header] = isset($row[$idx]) ? trim($row[$idx]) : '';
        }
        $previewRows[] = $rowData;
        $rowCount++;
    }

    // Count total rows accurately (rewind and use BOM handling again)
    fclose($handle);
    $handle = prepareCsvHandle($filePath);
    fgetcsv($handle); // skip header (BOM already removed)
    $totalRows = 0;
    while (fgetcsv($handle) !== false) $totalRows++;
    fclose($handle);

    // Field mapping suggestions - UPDATED with all advanced fields
    $fieldLists = [
        'members' => [
            'admno', 'name', 'designation', 'member_category', 'class', 'division', 'roll_no',
            'email', 'phone', 'parent_phone', 'emergency_contact', 'address', 'dob', 'gender',
            'blood_group', 'general_id', 'membership_expiry', 'security_deposit', 'notes', 'status'
        ],
        'books' => [
            'barcode', 'title', 'sub_title', 'author', 'author2', 'collaborator',
            'corporate_author', 'conference_author', 'series', 'volume', 'issn',
            'subject', 'keyword', 'isbn', 'summary', 'publisher', 'publisher_place',
            'category', 'item_category', 'sub_category', 'call_number', 'ddc', 'udc', 'lcc', 'cc', 'other_classification',
            'quantity', 'available', 'location', 'edition', 'year', 'pages', 'language',
            'price', 'price_currency', 'remarks', 'book_status', 'binding', 'holding',
            'illustrations', 'dimensions', 'country', 'collection_type', 'branch', 'shelf',
            'vendor', 'invoice', 'invoice_date', 'acquisition_date', 'funding_source', 'po_number',
            'ebook_url', 'contents', 'accompanying_material', 'material_type', 'size', 'weight'
        ],
        'ebooks' => ['title', 'author', 'subject', 'file_path'],
        'circulation' => ['admno', 'barcode', 'issue_date', 'due_date', 'return_date', 'fine', 'notes']
    ];
    $fields = $fieldLists[$importType] ?? [];
    $suggested = [];
    foreach ($fields as $dbField) {
        $bestMatch = '';
        $bestScore = 0;
        foreach ($headers as $col) {
            $colLower = strtolower(preg_replace('/[^a-z0-9]/i', '', $col));
            $fieldLower = strtolower(preg_replace('/[^a-z0-9]/i', '', $dbField));
            if ($colLower === $fieldLower) { $bestMatch = $col; $bestScore = 100; break; }
            if (strpos($colLower, $fieldLower) !== false || strpos($fieldLower, $colLower) !== false) {
                $score = strlen($fieldLower) / max(1, abs(strlen($colLower) - strlen($fieldLower)) + 1);
                if ($score > $bestScore) { $bestMatch = $col; $bestScore = $score; }
            }
        }
        $suggested[$dbField] = $bestMatch ?: 'ignore';
    }
    // For image preview, we need to know which columns might hold image paths/URLs
    $imageColumns = [];
    if ($importType === 'members') {
        $imageColumns = ['photo_path', 'Photo Path', 'photo', 'Photo'];
    } elseif ($importType === 'books') {
        $imageColumns = ['cover_path', 'Cover Path', 'cover_url', 'Cover URL', 'cover', 'Cover'];
    }
    // Determine if any of these columns exist in headers
    $imageColumnFound = null;
    foreach ($imageColumns as $col) {
        if (in_array($col, $headers)) {
            $imageColumnFound = $col;
            break;
        }
    }
    echo json_encode([
        'headers' => $headers,
        'preview' => $previewRows,
        'suggested' => $suggested,
        'totalRows' => $totalRows,
        'imageColumn' => $imageColumnFound
    ]);
    exit;
}

if (isset($_POST['chunk_import'])) {
    header('Content-Type: application/json');
    if (!isset($_SESSION['csrf_token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['error' => 'Invalid token']); exit;
    }
    $importType = $_POST['type'];
    $chunk = (int)$_POST['chunk'];
    $totalChunks = (int)$_POST['total_chunks'];
    $mapping = json_decode($_POST['mapping'], true);
    $duplicateAction = $_POST['duplicate_action'] ?? 'update';
    $filePath = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '.csv';
    if (!file_exists($filePath)) {
        echo json_encode(['error' => 'File not found']); exit;
    }

    $handle = prepareCsvHandle($filePath);
    if (!$handle) { echo json_encode(['error' => 'Cannot open file']); exit; }
    $headers = fgetcsv($handle);
    if (!$headers) { echo json_encode(['error' => 'No headers']); exit; }
    $headers = array_map('trim', $headers);

    $rowsPerChunk = 100;
    $startRow = $chunk * $rowsPerChunk;
    for ($i = 0; $i < $startRow && !feof($handle); $i++) fgetcsv($handle);

    $db->beginTransaction();
    $added = 0; $updated = 0; $failed = 0; $errors = [];
    $rowIndex = $startRow + 1;
    for ($i = 0; $i < $rowsPerChunk && ($row = fgetcsv($handle)) !== false; $i++, $rowIndex++) {
        $rowData = [];
        foreach ($headers as $idx => $header) {
            $rowData[$header] = isset($row[$idx]) ? trim($row[$idx]) : '';
        }
        try {
            $record = [];
            foreach ($mapping as $dbField => $csvCol) {
                if ($csvCol !== 'ignore') $record[$dbField] = $rowData[$csvCol] ?? '';
            }
            if ($importType === 'members') {
                $result = importMemberRecord($db, $record, $duplicateAction);
                if ($result === 'added') $added++;
                elseif ($result === 'updated') $updated++;
                else throw new Exception($result);
            } elseif ($importType === 'books') {
                $result = importBookRecord($db, $record, $duplicateAction);
                if ($result === 'added') $added++;
                elseif ($result === 'updated') $updated++;
                else throw new Exception($result);
            } elseif ($importType === 'circulation') {
                $result = importCirculationRecord($db, $record, $duplicateAction);
                if ($result === 'added') $added++;
                elseif ($result === 'updated') $updated++;
                else throw new Exception($result);
            } elseif ($importType === 'ebooks') {
                $result = importEBookRecord($db, $record);
                if ($result === 'added') $added++;
                else throw new Exception($result);
            }
        } catch (Exception $e) {
            $failed++;
            $errors[] = "Row $rowIndex: " . $e->getMessage();
        }
    }
    fclose($handle);
    $db->commit();

    $isLast = ($chunk + 1 >= $totalChunks);
    if ($isLast && $added + $updated + $failed > 0) {
        logImport($importType, basename($filePath), $rowIndex, $added, $updated, $failed, $errors);
    }
    echo json_encode(['success' => true, 'added' => $added, 'updated' => $updated, 'failed' => $failed, 'errors' => $errors, 'isLast' => $isLast]);
    exit;
}

// -------------------- SINGLE RECORD IMPORT FUNCTIONS (UPDATED) --------------------
function importMemberRecord($db, $record, $duplicateAction) {
    $admno = trim($record['admno'] ?? '');
    $name = trim($record['name'] ?? '');
    if (empty($admno) || empty($name)) throw new Exception("Missing admno or name");

    $designation = trim($record['designation'] ?? '');
    $category = trim($record['member_category'] ?? 'Student');
    $class = trim($record['class'] ?? '');
    $division = trim($record['division'] ?? '');
    $rollNo = trim($record['roll_no'] ?? '');
    $email = trim($record['email'] ?? '');
    $phone = trim($record['phone'] ?? '');
    $parentPhone = trim($record['parent_phone'] ?? '');
    $emergencyContact = trim($record['emergency_contact'] ?? '');
    $address = trim($record['address'] ?? '');
    $dob = !empty($record['dob']) ? date('Y-m-d', strtotime($record['dob'])) : null;
    $gender = trim($record['gender'] ?? '');
    $bloodGroup = trim($record['blood_group'] ?? '');
    $generalId = trim($record['general_id'] ?? '');
    $membershipExpiry = !empty($record['membership_expiry']) ? date('Y-m-d', strtotime($record['membership_expiry'])) : null;
    $securityDeposit = (float)($record['security_deposit'] ?? 0);
    $notes = trim($record['notes'] ?? '');
    $status = trim($record['status'] ?? 'active');
    $photoPath = trim($record['photo_path'] ?? ''); // optional, can be set later via ZIP

    $stmt = $db->prepare("SELECT id FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $exists = $stmt->fetch();

    if ($exists) {
        if ($duplicateAction === 'skip') return 'skipped';
        if ($duplicateAction === 'overwrite') {
            $db->prepare("DELETE FROM members WHERE admno = ?")->execute([$admno]);
            $sql = "INSERT INTO members (admno, name, designation, member_category, class, division, roll_no, email, phone, parent_phone, emergency_contact, address, dob, gender, blood_group, general_id, membership_expiry, security_deposit, notes, status, photo_path) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $db->prepare($sql)->execute([$admno, $name, $designation, $category, $class, $division, $rollNo, $email, $phone, $parentPhone, $emergencyContact, $address, $dob, $gender, $bloodGroup, $generalId, $membershipExpiry, $securityDeposit, $notes, $status, $photoPath]);
            return 'added';
        } else {
            $sql = "UPDATE members SET name=?, designation=?, member_category=?, class=?, division=?, roll_no=?, email=?, phone=?, parent_phone=?, emergency_contact=?, address=?, dob=?, gender=?, blood_group=?, general_id=?, membership_expiry=?, security_deposit=?, notes=?, status=?, photo_path=? WHERE admno=?";
            $db->prepare($sql)->execute([$name, $designation, $category, $class, $division, $rollNo, $email, $phone, $parentPhone, $emergencyContact, $address, $dob, $gender, $bloodGroup, $generalId, $membershipExpiry, $securityDeposit, $notes, $status, $photoPath, $admno]);
            return 'updated';
        }
    } else {
        $sql = "INSERT INTO members (admno, name, designation, member_category, class, division, roll_no, email, phone, parent_phone, emergency_contact, address, dob, gender, blood_group, general_id, membership_expiry, security_deposit, notes, status, photo_path) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $db->prepare($sql)->execute([$admno, $name, $designation, $category, $class, $division, $rollNo, $email, $phone, $parentPhone, $emergencyContact, $address, $dob, $gender, $bloodGroup, $generalId, $membershipExpiry, $securityDeposit, $notes, $status, $photoPath]);
        return 'added';
    }
}

function importBookRecord($db, $record, $duplicateAction) {
    $barcode = trim($record['barcode'] ?? '');
    $title = trim($record['title'] ?? '');
    if (empty($barcode) || empty($title)) throw new Exception("Missing barcode or title");

    // Basic fields
    $subTitle = trim($record['sub_title'] ?? '');
    $author = trim($record['author'] ?? '');
    $author2 = trim($record['author2'] ?? '');
    $collaborator = trim($record['collaborator'] ?? '');
    $corporateAuthor = trim($record['corporate_author'] ?? '');
    $conferenceAuthor = trim($record['conference_author'] ?? '');
    $series = trim($record['series'] ?? '');
    $volume = trim($record['volume'] ?? '');
    $issn = trim($record['issn'] ?? '');
    $subject = trim($record['subject'] ?? '');
    $keyword = trim($record['keyword'] ?? '');
    $isbn = trim($record['isbn'] ?? '');
    $summary = trim($record['summary'] ?? '');
    $publisher = trim($record['publisher'] ?? '');
    $publisherPlace = trim($record['publisher_place'] ?? '');
    $category = trim($record['category'] ?? '');
    $itemCategory = trim($record['item_category'] ?? '');
    $subCategory = trim($record['sub_category'] ?? '');
    $callNumber = trim($record['call_number'] ?? '');
    $ddc = trim($record['ddc'] ?? '');
    $udc = trim($record['udc'] ?? '');
    $lcc = trim($record['lcc'] ?? '');
    $cc = trim($record['cc'] ?? '');
    $otherClassification = trim($record['other_classification'] ?? '');
    $quantity = max(1, (int)($record['quantity'] ?? 1));
    $available = isset($record['available']) ? (int)$record['available'] : $quantity;
    $location = trim($record['location'] ?? '');
    $edition = trim($record['edition'] ?? '');
    $year = trim($record['year'] ?? '');
    $pages = (int)($record['pages'] ?? 0);
    $language = trim($record['language'] ?? 'English');
    $price = !empty($record['price']) ? (float)$record['price'] : null;
    $priceCurrency = trim($record['price_currency'] ?? 'INR');
    $remarks = trim($record['remarks'] ?? '');
    $bookStatus = trim($record['book_status'] ?? 'Available');
    $binding = trim($record['binding'] ?? '');
    $holding = trim($record['holding'] ?? '');
    $illustrations = trim($record['illustrations'] ?? '');
    $dimensions = trim($record['dimensions'] ?? '');
    $country = trim($record['country'] ?? '');
    $collectionType = trim($record['collection_type'] ?? '');
    $branch = trim($record['branch'] ?? '');
    $shelf = trim($record['shelf'] ?? '');
    $vendor = trim($record['vendor'] ?? '');
    $invoice = trim($record['invoice'] ?? '');
    $invoiceDate = !empty($record['invoice_date']) ? date('Y-m-d', strtotime($record['invoice_date'])) : null;
    $acquisitionDate = !empty($record['acquisition_date']) ? date('Y-m-d', strtotime($record['acquisition_date'])) : null;
    $fundingSource = trim($record['funding_source'] ?? '');
    $poNumber = trim($record['po_number'] ?? '');
    $ebookUrl = trim($record['ebook_url'] ?? '');
    $contents = trim($record['contents'] ?? '');
    $accompanyingMaterial = trim($record['accompanying_material'] ?? '');
    $materialType = trim($record['material_type'] ?? '');
    $size = trim($record['size'] ?? '');
    $weight = trim($record['weight'] ?? '');

    $stmt = $db->prepare("SELECT id FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $exists = $stmt->fetch();

    // Build long SQL for INSERT/UPDATE
    $allColumns = [
        'barcode', 'title', 'sub_title', 'author', 'author2', 'collaborator', 'corporate_author', 'conference_author',
        'series', 'volume', 'issn', 'subject', 'keyword', 'isbn', 'summary', 'publisher', 'publisher_place', 'category',
        'item_category', 'sub_category', 'call_number', 'ddc', 'udc', 'lcc', 'cc', 'other_classification', 'quantity',
        'available', 'location', 'edition', 'year', 'pages', 'language', 'price', 'price_currency', 'remarks',
        'book_status', 'binding', 'holding', 'illustrations', 'dimensions', 'country', 'collection_type', 'branch',
        'shelf', 'vendor', 'invoice', 'invoice_date', 'acquisition_date', 'funding_source', 'po_number', 'ebook_url',
        'contents', 'accompanying_material', 'material_type', 'size', 'weight'
    ];
    $values = [
        $barcode, $title, $subTitle, $author, $author2, $collaborator, $corporateAuthor, $conferenceAuthor,
        $series, $volume, $issn, $subject, $keyword, $isbn, $summary, $publisher, $publisherPlace, $category,
        $itemCategory, $subCategory, $callNumber, $ddc, $udc, $lcc, $cc, $otherClassification, $quantity,
        $available, $location, $edition, $year, $pages, $language, $price, $priceCurrency, $remarks,
        $bookStatus, $binding, $holding, $illustrations, $dimensions, $country, $collectionType, $branch,
        $shelf, $vendor, $invoice, $invoiceDate, $acquisitionDate, $fundingSource, $poNumber, $ebookUrl,
        $contents, $accompanyingMaterial, $materialType, $size, $weight
    ];

    if ($exists) {
        if ($duplicateAction === 'skip') return 'skipped';
        if ($duplicateAction === 'overwrite') {
            $db->prepare("DELETE FROM books WHERE barcode = ?")->execute([$barcode]);
            $placeholders = implode(',', array_fill(0, count($allColumns), '?'));
            $sql = "INSERT INTO books (" . implode(',', $allColumns) . ") VALUES ($placeholders)";
            $db->prepare($sql)->execute($values);
            return 'added';
        } else {
            $setParts = [];
            foreach ($allColumns as $col) {
                $setParts[] = "$col = ?";
            }
            $setParts[] = "barcode = ?";
            $updateSql = "UPDATE books SET " . implode(',', $setParts) . " WHERE barcode = ?";
            $updateValues = array_merge($values, [$barcode]);
            $db->prepare($updateSql)->execute($updateValues);
            return 'updated';
        }
    } else {
        $placeholders = implode(',', array_fill(0, count($allColumns), '?'));
        $sql = "INSERT INTO books (" . implode(',', $allColumns) . ") VALUES ($placeholders)";
        $db->prepare($sql)->execute($values);
        return 'added';
    }
}

function importEBookRecord($db, $record) {
    $title = trim($record['title'] ?? '');
    if (empty($title)) throw new Exception("Missing title");
    $author = trim($record['author'] ?? '');
    $subject = trim($record['subject'] ?? '');
    $filePath = trim($record['file_path'] ?? '');
    $stmt = $db->prepare("INSERT INTO ebooks (title, author, subject, file_path) VALUES (?,?,?,?)");
    $stmt->execute([$title, $author, $subject, $filePath]);
    return 'added';
}

function importCirculationRecord($db, $record, $duplicateAction) {
    $admno = trim($record['admno'] ?? '');
    $barcode = trim($record['barcode'] ?? '');
    $issueDate = trim($record['issue_date'] ?? '');
    $dueDate = trim($record['due_date'] ?? '');
    if (empty($admno) || empty($barcode) || empty($issueDate) || empty($dueDate)) {
        throw new Exception("Missing required fields (admno, barcode, issue_date, due_date)");
    }
    $returnDate = !empty($record['return_date']) ? trim($record['return_date']) : null;
    $fine = isset($record['fine']) && $record['fine'] !== '' ? (float)$record['fine'] : 0;
    $notes = trim($record['notes'] ?? '');

    $member = $db->prepare("SELECT name, member_category FROM members WHERE admno = ? AND status = 'active'");
    $member->execute([$admno]);
    $memberData = $member->fetch();
    if (!$memberData) throw new Exception("Member '$admno' not found or inactive");

    $book = $db->prepare("SELECT title, author, category, available FROM books WHERE barcode = ?");
    $book->execute([$barcode]);
    $bookData = $book->fetch();
    if (!$bookData) throw new Exception("Book '$barcode' not found");

    $activeStmt = $db->prepare("SELECT id FROM circulation WHERE barcode = ? AND return_date IS NULL");
    $activeStmt->execute([$barcode]);
    if ($activeStmt->fetch() && !$returnDate) {
        if ($duplicateAction === 'skip') return 'skipped';
        if ($duplicateAction === 'overwrite') {
            $db->prepare("DELETE FROM circulation WHERE barcode = ? AND return_date IS NULL")->execute([$barcode]);
            $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
        } else {
            throw new Exception("Book '$barcode' already issued and not returned");
        }
    }

    if ($returnDate && $fine == 0) {
        $fine = calculateFine($dueDate, $memberData['member_category'] ?? 'Student');
        $fine = max(0, (float)$fine);
    }

    $stmt = $db->prepare("INSERT INTO circulation (admno, member_name, barcode, title, author, category, issue_date, due_date, return_date, fine, notes, is_manual) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
    $stmt->execute([$admno, $memberData['name'], $barcode, $bookData['title'], $bookData['author'] ?? '', $bookData['category'] ?? '', $issueDate, $dueDate, $returnDate, $fine, $notes]);

    if ($returnDate) {
        $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
        $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $admno]);
    } else {
        $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ? AND available > 0")->execute([$barcode]);
        $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$admno]);
    }
    return 'added';
}

// -------------------- FIXED ZIP PHOTO/COVER IMPORTS (skip directories) --------------------
function importMemberPhotosZip($db, $zipFilePath) {
    $result = ['success' => 0, 'failed' => 0, 'message' => '', 'errors' => []];
    if (!is_dir(MEMBER_PHOTO_DIR)) mkdir(MEMBER_PHOTO_DIR, 0777, true);
    if (!is_writable(MEMBER_PHOTO_DIR)) {
        $result['errors'][] = "Member photo directory not writable: " . MEMBER_PHOTO_DIR;
        $result['message'] = "Photos: 0 updated, " . $result['failed'] . " failed. Directory not writable.";
        return $result;
    }

    $tempDir = sys_get_temp_dir() . '/member_photos_' . uniqid();
    if (!mkdir($tempDir, 0777, true)) {
        $result['errors'][] = "Cannot create temp directory";
        $result['message'] = "Photos: 0 updated, " . $result['failed'] . " failed. Temp dir error.";
        return $result;
    }
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) !== true) {
        $result['errors'][] = "Cannot open ZIP file";
        $result['message'] = "Photos: 0 updated, " . $result['failed'] . " failed. ZIP open error.";
        return $result;
    }

    // Extract only image files, skip directories
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $entry = $zip->getNameIndex($i);
        // Skip directories (entries ending with /)
        if (substr($entry, -1) == '/') continue;
        $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $result['errors'][] = "Skipped non-image: $entry";
            $result['failed']++;
            continue;
        }
        $filename = basename($entry);
        $fullPath = $tempDir . '/' . $filename;
        $fp = $zip->getStream($entry);
        if (!$fp) {
            $result['errors'][] = "Failed to extract $entry";
            $result['failed']++;
            continue;
        }
        $ofp = fopen($fullPath, 'w');
        while (!feof($fp)) fwrite($ofp, fread($fp, 8192));
        fclose($fp);
        fclose($ofp);
    }
    $zip->close();

    $allowedMime = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $files = scandir($tempDir);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        $fullPath = $tempDir . '/' . $file;
        $mime = finfo_file($finfo, $fullPath);
        if (!in_array($mime, $allowedMime)) {
            $result['failed']++;
            $result['errors'][] = "Skipped non-image: $file (MIME: $mime)";
            continue;
        }
        $admno = pathinfo($file, PATHINFO_FILENAME);
        $admno = preg_replace('/[^a-zA-Z0-9_-]/', '', $admno);
        if (empty($admno)) {
            $result['failed']++;
            $result['errors'][] = "Invalid filename (no valid AdmNo): $file";
            continue;
        }
        $check = $db->prepare("SELECT id, photo_path FROM members WHERE admno = ?");
        $check->execute([$admno]);
        $member = $check->fetch();
        if (!$member) {
            $result['failed']++;
            $result['errors'][] = "Member not found: $admno (from file $file)";
            continue;
        }
        if (!empty($member['photo_path']) && file_exists($member['photo_path'])) @unlink($member['photo_path']);
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $newName = 'member_' . $admno . '_' . time() . '.' . $ext;
        $target = MEMBER_PHOTO_DIR . $newName;
        if (!autoResizeImage($fullPath, $target, 300, 300, 85)) {
            if (copy($fullPath, $target)) {
                $result['errors'][] = "Resize failed for $file, copied original.";
            } else {
                $result['failed']++;
                $result['errors'][] = "Failed to copy/resize photo for $admno";
                continue;
            }
        }
        $update = $db->prepare("UPDATE members SET photo_path = ? WHERE admno = ?");
        if ($update->execute([$target, $admno])) $result['success']++;
        else {
            $result['failed']++;
            $result['errors'][] = "Database update failed for $admno";
        }
    }
    finfo_close($finfo);
    array_map('unlink', glob($tempDir . '/*'));
    rmdir($tempDir);
    $result['message'] = "Photos: {$result['success']} updated, {$result['failed']} failed";
    if (!empty($result['errors'])) $result['message'] .= " Errors: " . implode("; ", array_slice($result['errors'], 0, 5));
    return $result;
}

function importBookCoversZip($db, $zipFilePath) {
    $result = ['success' => 0, 'failed' => 0, 'message' => '', 'errors' => []];
    if (!is_dir(BOOK_COVER_DIR)) mkdir(BOOK_COVER_DIR, 0777, true);
    if (!is_writable(BOOK_COVER_DIR)) {
        $result['errors'][] = "Book cover directory not writable: " . BOOK_COVER_DIR;
        $result['message'] = "Covers: 0 updated, " . $result['failed'] . " failed. Directory not writable.";
        return $result;
    }

    $tempDir = sys_get_temp_dir() . '/book_covers_' . uniqid();
    if (!mkdir($tempDir, 0777, true)) {
        $result['errors'][] = "Cannot create temp directory";
        $result['message'] = "Covers: 0 updated, " . $result['failed'] . " failed. Temp dir error.";
        return $result;
    }
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) !== true) {
        $result['errors'][] = "Cannot open ZIP file";
        $result['message'] = "Covers: 0 updated, " . $result['failed'] . " failed. ZIP open error.";
        return $result;
    }

    // Extract only image files, skip directories
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $entry = $zip->getNameIndex($i);
        if (substr($entry, -1) == '/') continue;
        $ext = strtolower(pathinfo($entry, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $result['errors'][] = "Skipped non-image: $entry";
            $result['failed']++;
            continue;
        }
        $filename = basename($entry);
        $fullPath = $tempDir . '/' . $filename;
        $fp = $zip->getStream($entry);
        if (!$fp) {
            $result['errors'][] = "Failed to extract $entry";
            $result['failed']++;
            continue;
        }
        $ofp = fopen($fullPath, 'w');
        while (!feof($fp)) fwrite($ofp, fread($fp, 8192));
        fclose($fp);
        fclose($ofp);
    }
    $zip->close();

    $allowedMime = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $files = scandir($tempDir);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        $fullPath = $tempDir . '/' . $file;
        $mime = finfo_file($finfo, $fullPath);
        if (!in_array($mime, $allowedMime)) {
            $result['failed']++;
            $result['errors'][] = "Skipped non-image: $file (MIME: $mime)";
            continue;
        }
        $barcode = pathinfo($file, PATHINFO_FILENAME);
        $barcode = preg_replace('/[^a-zA-Z0-9_-]/', '', $barcode);
        if (empty($barcode)) {
            $result['failed']++;
            $result['errors'][] = "Invalid filename (no barcode): $file";
            continue;
        }
        $check = $db->prepare("SELECT id, cover_path FROM books WHERE barcode = ?");
        $check->execute([$barcode]);
        $book = $check->fetch();
        if (!$book) {
            $result['failed']++;
            $result['errors'][] = "Book not found: $barcode (from file $file)";
            continue;
        }
        if (!empty($book['cover_path']) && file_exists($book['cover_path'])) @unlink($book['cover_path']);
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $newName = 'book_cover_' . $barcode . '_' . time() . '.' . $ext;
        $target = BOOK_COVER_DIR . $newName;
        if (!autoResizeImage($fullPath, $target, 400, 400, 85)) {
            if (copy($fullPath, $target)) {
                $result['errors'][] = "Resize failed for $file, copied original.";
            } else {
                $result['failed']++;
                $result['errors'][] = "Failed to copy/resize cover for $barcode";
                continue;
            }
        }
        $update = $db->prepare("UPDATE books SET cover_path = ? WHERE barcode = ?");
        if ($update->execute(['uploads/book_covers/' . $newName, $barcode])) $result['success']++;
        else {
            $result['failed']++;
            $result['errors'][] = "Database update failed for $barcode";
        }
    }
    finfo_close($finfo);
    array_map('unlink', glob($tempDir . '/*'));
    rmdir($tempDir);
    $result['message'] = "Covers: {$result['success']} updated, {$result['failed']} failed";
    if (!empty($result['errors'])) $result['message'] .= " Errors: " . implode("; ", array_slice($result['errors'], 0, 5));
    return $result;
}

// -------------------- MARC IMPORT --------------------
function importMarcFiles($db, $filePath) {
    $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'message' => '', 'errors' => []];
    if (!class_exists('File_MARC')) {
        $result['message'] = "File_MARC class not found. Please run: composer require pear/file_marc";
        return $result;
    }
    $records = [];
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    if ($ext === 'zip') {
        $tempDir = sys_get_temp_dir() . '/marc_' . uniqid();
        if (!mkdir($tempDir, 0777, true)) {
            $result['message'] = "Cannot create temp dir for MARC ZIP";
            return $result;
        }
        $zip = new ZipArchive;
        if ($zip->open($filePath) !== true) {
            $result['message'] = "Cannot open MARC ZIP file";
            rmdir($tempDir);
            return $result;
        }
        $zip->extractTo($tempDir);
        $zip->close();
        $files = glob($tempDir . '/*.{xml,mrc,marc}', GLOB_BRACE);
        foreach ($files as $f) {
            try {
                $records = array_merge($records, parseMarcFile($f));
            } catch (Exception $e) {
                $result['errors'][] = "Error parsing " . basename($f) . ": " . $e->getMessage();
            }
        }
        array_map('unlink', glob($tempDir . '/*'));
        rmdir($tempDir);
    } else {
        try {
            $records = parseMarcFile($filePath);
        } catch (Exception $e) {
            $result['message'] = "MARC parsing error: " . $e->getMessage();
            return $result;
        }
    }
    if (empty($records)) {
        $result['message'] = "No MARC records found in the uploaded file(s).";
        return $result;
    }

    $db->beginTransaction();
    foreach ($records as $marcxml) {
        try {
            $dom = new DOMDocument();
            if (!$dom->loadXML($marcxml)) throw new Exception("Invalid XML in MARC record");
            $xpath = new DOMXPath($dom);
            $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');
            $book = [];
            // Extract fields
            $book['barcode'] = getMarcValue($xpath, '001') ?: 'MARC_' . uniqid();
            $book['title'] = getMarcSubfield($xpath, '245', 'a');
            if (empty($book['title'])) throw new Exception("No title found in MARC record");
            $book['subtitle'] = getMarcSubfield($xpath, '245', 'b');
            $book['author'] = getMarcSubfield($xpath, '100', 'a');
            $book['author2'] = implode('; ', getMarcMultiple($xpath, '700', 'a'));
            $book['collaborator'] = implode('; ', getMarcMultiple($xpath, '710', 'a'));
            $book['isbn'] = getMarcSubfield($xpath, '020', 'a');
            $book['publisher'] = getMarcSubfield($xpath, '260', 'b') ?: getMarcSubfield($xpath, '264', 'b');
            $book['publisher_place'] = getMarcSubfield($xpath, '260', 'a') ?: getMarcSubfield($xpath, '264', 'a');
            $book['year'] = getMarcSubfield($xpath, '260', 'c') ?: getMarcSubfield($xpath, '264', 'c');
            $book['edition'] = getMarcSubfield($xpath, '250', 'a');
            $book['pages'] = getMarcSubfield($xpath, '300', 'a');
            $book['summary'] = getMarcSubfield($xpath, '520', 'a');
            $book['subject'] = implode('; ', getMarcMultiple($xpath, '650', 'a'));
            $book['series'] = getMarcSubfield($xpath, '490', 'a');
            $book['corporate_author'] = implode('; ', getMarcMultiple($xpath, '110', 'a'));
            $book['conference_author'] = implode('; ', getMarcMultiple($xpath, '111', 'a'));

            $stmt = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $stmt->execute([$book['barcode']]);
            if ($stmt->fetch()) {
                $sql = "UPDATE books SET title=?, sub_title=?, author=?, author2=?, collaborator=?, isbn=?, publisher=?, publisher_place=?, year=?, edition=?, pages=?, summary=?, subject=?, series=?, corporate_author=?, conference_author=? WHERE barcode=?";
                $db->prepare($sql)->execute([$book['title'], $book['subtitle'], $book['author'], $book['author2'], $book['collaborator'], $book['isbn'], $book['publisher'], $book['publisher_place'], $book['year'], $book['edition'], $book['pages'], $book['summary'], $book['subject'], $book['series'], $book['corporate_author'], $book['conference_author'], $book['barcode']]);
                $result['updated']++;
            } else {
                $sql = "INSERT INTO books (barcode, title, sub_title, author, author2, collaborator, isbn, publisher, publisher_place, year, edition, pages, summary, subject, series, corporate_author, conference_author) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $db->prepare($sql)->execute([$book['barcode'], $book['title'], $book['subtitle'], $book['author'], $book['author2'], $book['collaborator'], $book['isbn'], $book['publisher'], $book['publisher_place'], $book['year'], $book['edition'], $book['pages'], $book['summary'], $book['subject'], $book['series'], $book['corporate_author'], $book['conference_author']]);
                $result['success']++;
            }
        } catch (Exception $e) {
            $result['failed']++;
            $result['errors'][] = "Record failed: " . $e->getMessage();
        }
    }
    $db->commit();
    $result['message'] = "MARC: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed";
    if (!empty($result['errors'])) $result['message'] .= " Errors: " . implode("; ", array_slice($result['errors'], 0, 5));
    return $result;
}

function getMarcValue($xpath, $tag) {
    $nodes = $xpath->query("//marc:controlfield[@tag='$tag']");
    if ($nodes->length > 0) return trim($nodes->item(0)->nodeValue);
    return '';
}

function getMarcSubfield($xpath, $tag, $code) {
    $nodes = $xpath->query("//marc:datafield[@tag='$tag']/marc:subfield[@code='$code']");
    if ($nodes->length > 0) return trim($nodes->item(0)->nodeValue);
    return '';
}

function getMarcMultiple($xpath, $tag, $code) {
    $values = [];
    $nodes = $xpath->query("//marc:datafield[@tag='$tag']/marc:subfield[@code='$code']");
    foreach ($nodes as $node) $values[] = trim($node->nodeValue);
    return $values;
}

function parseMarcFile($filePath) {
    $records = [];
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    if ($ext === 'xml') {
        $dom = new DOMDocument();
        if (!$dom->load($filePath)) {
            throw new Exception("Failed to load XML file");
        }
        $xpath = new DOMXPath($dom);
        $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');
        $nodes = $xpath->query("//marc:record | //record");
        if ($nodes->length === 0) {
            throw new Exception("No MARC records found in XML");
        }
        foreach ($nodes as $node) {
            $records[] = $dom->saveXML($node);
        }
    } else {
        if (!class_exists('File_MARC')) {
            throw new Exception("File_MARC class not found");
        }
        $marc = new File_MARC($filePath, File_MARC::SOURCE_FILE);
        while ($record = $marc->next()) {
            $records[] = $record->toXML();
        }
    }
    return $records;
}

// -------------------- FILE UPLOAD & PROCESSING --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $importType = $_POST['import_type'] ?? '';
    $csrfValid = isset($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);

    // Remote URL import
    if (isset($_POST['remote_url']) && !empty($_POST['remote_url'])) {
        if (!$csrfValid) {
            showToast("Invalid security token", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        $url = filter_var(trim($_POST['remote_url']), FILTER_VALIDATE_URL);
        if (!$url) {
            showToast("Invalid URL", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        $ctx = stream_context_create(['http' => ['timeout' => 30, 'ignore_errors' => true]]);
        $content = @file_get_contents($url, false, $ctx);
        if ($content === false) {
            showToast("Failed to fetch URL content", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
        $tempFile = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '_remote.' . ($ext ?: 'csv');
        file_put_contents($tempFile, $content);
        // Convert to UTF-8 if CSV
        if ($ext === 'csv') {
            convertCsvToUtf8($tempFile, null, true);
        }
        $_SESSION['import_file'] = $tempFile;
        $_SESSION['import_type'] = $importType;
        $_SESSION['import_ext'] = $ext ?: 'csv';
        header("Location: " . $_SERVER['PHP_SELF'] . "?step=mapping");
        exit;
    }

    // File upload
    if (isset($_FILES['import_file']) && $_FILES['import_file']['error'] === UPLOAD_ERR_OK) {
        if (!$csrfValid) {
            showToast("Invalid security token", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        $file = $_FILES['import_file']['tmp_name'];
        $fileName = $_FILES['import_file']['name'];
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (!is_uploaded_file($file)) {
            showToast("Upload failed: File not properly uploaded.", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }

        $tempFile = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '.' . $ext;
        if (!move_uploaded_file($file, $tempFile)) {
            showToast("Failed to save uploaded file. Check directory permissions.", "danger");
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }

        // For CSV/Excel: go to mapping step
        if (in_array($ext, ['csv', 'xlsx', 'xls'])) {
            // If CSV, convert to UTF-8
            if ($ext === 'csv') {
                convertCsvToUtf8($tempFile, null, true);
            }
            $_SESSION['import_file'] = $tempFile;
            $_SESSION['import_type'] = $importType;
            $_SESSION['import_ext'] = $ext;

            // If Excel, create a CSV version for preview/chunk processing (and convert that to UTF-8)
            if ($ext !== 'csv') {
                $csvPath = TEMP_IMPORT_DIR . 'temp_import_' . session_id() . '.csv';
                try {
                    excelToCsv($tempFile, $csvPath);
                    // Convert the resulting CSV to UTF-8
                    convertCsvToUtf8($csvPath, null, true);
                } catch (Exception $e) {
                    showToast("Excel conversion failed: " . $e->getMessage(), "danger");
                    unlink($tempFile);
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit;
                }
            }
            header("Location: " . $_SERVER['PHP_SELF'] . "?step=mapping");
            exit;
        }
        // JSON/XML direct import
        elseif (in_array($ext, ['json', 'xml'])) {
            try {
                if ($ext === 'json') $data = parseJsonFile($tempFile);
                else $data = parseXmlFile($tempFile);
                if (empty($data)) throw new Exception("No data found in file");
                switch ($importType) {
                    case 'members': $result = importMembersArray($db, $data); break;
                    case 'books':   $result = importBooksArray($db, $data); break;
                    case 'ebooks':  $result = importEBooksArray($db, $data); break;
                    case 'circulation': $result = importCirculationArray($db, $data); break;
                    default: throw new Exception("Invalid import type for JSON/XML");
                }
                showToast($result['message'], $result['success'] > 0 ? 'success' : 'warning');
                logActivity($_SESSION['username'], 'IMPORT', "JSON/XML {$importType}: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed");
                unlink($tempFile);
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            } catch (Exception $e) {
                showToast("JSON/XML import failed: " . $e->getMessage(), "danger");
                unlink($tempFile);
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            }
        }
        // ZIP for photos/covers
        elseif ($ext === 'zip' && ($importType === 'member_photos' || $importType === 'book_covers')) {
            $result = ($importType === 'member_photos') ? importMemberPhotosZip($db, $tempFile) : importBookCoversZip($db, $tempFile);
            showToast($result['message'], $result['success'] > 0 ? 'success' : 'warning');
            logActivity($_SESSION['username'], 'IMPORT', "{$importType}: {$result['success']} updated, {$result['failed']} failed. Errors: " . implode('; ', array_slice($result['errors'] ?? [], 0, 5)));
            unlink($tempFile);
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
        // MARC import
        elseif (($ext === 'xml' || $ext === 'mrc' || $ext === 'zip') && $importType === 'marc') {
            if (!$marcAvailable) {
                showToast("MARC import requires File_MARC library. Install with: composer require pear/file_marc", "danger");
                unlink($tempFile);
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            }
            if (!class_exists('File_MARC')) {
                @require_once 'File/MARC.php';
            }
            $result = importMarcFiles($db, $tempFile);
            showToast($result['message'], $result['success'] > 0 ? 'success' : 'warning');
            logActivity($_SESSION['username'], 'IMPORT', "MARC: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed. Errors: " . implode('; ', array_slice($result['errors'] ?? [], 0, 5)));
            unlink($tempFile);
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        } else {
            showToast("Unsupported file format for this import type.", "danger");
            unlink($tempFile);
            header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        }
    } else {
        $errorCode = $_FILES['import_file']['error'] ?? UPLOAD_ERR_NO_FILE;
        $errors = [
            UPLOAD_ERR_INI_SIZE => "File exceeds upload_max_filesize directive",
            UPLOAD_ERR_FORM_SIZE => "File exceeds MAX_FILE_SIZE directive",
            UPLOAD_ERR_PARTIAL => "File was only partially uploaded",
            UPLOAD_ERR_NO_FILE => "No file was uploaded",
            UPLOAD_ERR_NO_TMP_DIR => "Missing temporary folder",
            UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
            UPLOAD_ERR_EXTENSION => "A PHP extension stopped the file upload"
        ];
        $msg = isset($errors[$errorCode]) ? $errors[$errorCode] : "Unknown upload error";
        showToast("Upload error: $msg", "danger");
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// -------------------- ARRAY IMPORTS FOR JSON/XML (UPDATED) --------------------
function importMembersArray($db, $data) {
    $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'message' => ''];
    $db->beginTransaction();
    foreach ($data as $row) {
        try {
            $admno = trim($row['admno'] ?? $row['AdmNo'] ?? $row['adm_no'] ?? '');
            $name = trim($row['name'] ?? $row['Name'] ?? '');
            if (empty($admno) || empty($name)) { $result['failed']++; continue; }
            $record = [
                'admno' => $admno, 'name' => $name,
                'designation' => $row['designation'] ?? $row['Designation'] ?? '',
                'member_category' => $row['member_category'] ?? $row['Member Category'] ?? 'Student',
                'class' => $row['class'] ?? $row['Class'] ?? '',
                'division' => $row['division'] ?? $row['Division'] ?? '',
                'roll_no' => $row['roll_no'] ?? $row['Roll No'] ?? '',
                'email' => $row['email'] ?? $row['Email'] ?? '',
                'phone' => $row['phone'] ?? $row['Phone'] ?? '',
                'parent_phone' => $row['parent_phone'] ?? $row['Parent Phone'] ?? '',
                'emergency_contact' => $row['emergency_contact'] ?? $row['Emergency Contact'] ?? '',
                'address' => $row['address'] ?? $row['Address'] ?? '',
                'dob' => $row['dob'] ?? $row['DOB'] ?? null,
                'gender' => $row['gender'] ?? $row['Gender'] ?? '',
                'blood_group' => $row['blood_group'] ?? $row['Blood Group'] ?? '',
                'general_id' => $row['general_id'] ?? $row['General ID'] ?? '',
                'membership_expiry' => $row['membership_expiry'] ?? $row['Membership Expiry'] ?? null,
                'security_deposit' => (float)($row['security_deposit'] ?? $row['Security Deposit'] ?? 0),
                'notes' => $row['notes'] ?? $row['Notes'] ?? '',
                'status' => $row['status'] ?? $row['Status'] ?? 'active',
                'photo_path' => $row['photo_path'] ?? $row['Photo Path'] ?? ''
            ];
            $res = importMemberRecord($db, $record, 'update');
            if ($res === 'added') $result['success']++;
            elseif ($res === 'updated') $result['updated']++;
            else $result['failed']++;
        } catch (Exception $e) { $result['failed']++; }
    }
    $db->commit();
    $result['message'] = "Members: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed";
    return $result;
}

function importBooksArray($db, $data) {
    $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'message' => ''];
    $db->beginTransaction();
    foreach ($data as $row) {
        try {
            $barcode = trim($row['barcode'] ?? $row['Barcode'] ?? '');
            $title = trim($row['title'] ?? $row['Title'] ?? '');
            if (empty($barcode) || empty($title)) { $result['failed']++; continue; }
            $record = [
                'barcode' => $barcode, 'title' => $title,
                'sub_title' => $row['sub_title'] ?? $row['Sub Title'] ?? '',
                'author' => $row['author'] ?? $row['Author'] ?? '',
                'author2' => $row['author2'] ?? $row['Author2'] ?? '',
                'collaborator' => $row['collaborator'] ?? $row['Collaborator'] ?? '',
                'corporate_author' => $row['corporate_author'] ?? $row['Corporate Author'] ?? '',
                'conference_author' => $row['conference_author'] ?? $row['Conference Author'] ?? '',
                'series' => $row['series'] ?? $row['Series'] ?? '',
                'volume' => $row['volume'] ?? $row['Volume'] ?? '',
                'issn' => $row['issn'] ?? $row['ISSN'] ?? '',
                'subject' => $row['subject'] ?? $row['Subject'] ?? '',
                'keyword' => $row['keyword'] ?? $row['Keyword'] ?? '',
                'isbn' => $row['isbn'] ?? $row['ISBN'] ?? '',
                'summary' => $row['summary'] ?? $row['Summary'] ?? '',
                'publisher' => $row['publisher'] ?? $row['Publisher'] ?? '',
                'publisher_place' => $row['publisher_place'] ?? $row['Publisher Place'] ?? '',
                'category' => $row['category'] ?? $row['Category'] ?? '',
                'item_category' => $row['item_category'] ?? $row['Item Category'] ?? '',
                'sub_category' => $row['sub_category'] ?? $row['Sub Category'] ?? '',
                'call_number' => $row['call_number'] ?? $row['Call Number'] ?? '',
                'ddc' => $row['ddc'] ?? $row['DDC'] ?? '',
                'udc' => $row['udc'] ?? $row['UDC'] ?? '',
                'lcc' => $row['lcc'] ?? $row['LCC'] ?? '',
                'cc' => $row['cc'] ?? $row['CC'] ?? '',
                'other_classification' => $row['other_classification'] ?? $row['Other Classification'] ?? '',
                'quantity' => (int)($row['quantity'] ?? $row['Quantity'] ?? 1),
                'available' => (int)($row['available'] ?? $row['Available'] ?? 1),
                'location' => $row['location'] ?? $row['Location'] ?? '',
                'edition' => $row['edition'] ?? $row['Edition'] ?? '',
                'year' => $row['year'] ?? $row['Year'] ?? '',
                'pages' => (int)($row['pages'] ?? $row['Pages'] ?? 0),
                'language' => $row['language'] ?? $row['Language'] ?? 'English',
                'price' => !empty($row['price']) ? (float)$row['price'] : null,
                'price_currency' => $row['price_currency'] ?? $row['Currency'] ?? 'INR',
                'remarks' => $row['remarks'] ?? $row['Remarks'] ?? '',
                'book_status' => $row['book_status'] ?? $row['Book Status'] ?? 'Available',
                'binding' => $row['binding'] ?? $row['Binding'] ?? '',
                'holding' => $row['holding'] ?? $row['Holding'] ?? '',
                'illustrations' => $row['illustrations'] ?? $row['Illustrations'] ?? '',
                'dimensions' => $row['dimensions'] ?? $row['Dimensions'] ?? '',
                'country' => $row['country'] ?? $row['Country'] ?? '',
                'collection_type' => $row['collection_type'] ?? $row['Collection Type'] ?? '',
                'branch' => $row['branch'] ?? $row['Branch'] ?? '',
                'shelf' => $row['shelf'] ?? $row['Shelf'] ?? '',
                'vendor' => $row['vendor'] ?? $row['Vendor'] ?? '',
                'invoice' => $row['invoice'] ?? $row['Invoice'] ?? '',
                'invoice_date' => $row['invoice_date'] ?? $row['Invoice Date'] ?? null,
                'acquisition_date' => $row['acquisition_date'] ?? $row['Acquisition Date'] ?? null,
                'funding_source' => $row['funding_source'] ?? $row['Funding Source'] ?? '',
                'po_number' => $row['po_number'] ?? $row['PO Number'] ?? '',
                'ebook_url' => $row['ebook_url'] ?? $row['eBook URL'] ?? '',
                'contents' => $row['contents'] ?? $row['Contents'] ?? '',
                'accompanying_material' => $row['accompanying_material'] ?? $row['Accompanying Material'] ?? '',
                'material_type' => $row['material_type'] ?? $row['Material Type'] ?? '',
                'size' => $row['size'] ?? $row['Size'] ?? '',
                'weight' => $row['weight'] ?? $row['Weight'] ?? ''
            ];
            $res = importBookRecord($db, $record, 'update');
            if ($res === 'added') $result['success']++;
            elseif ($res === 'updated') $result['updated']++;
            else $result['failed']++;
        } catch (Exception $e) { $result['failed']++; }
    }
    $db->commit();
    $result['message'] = "Books: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed";
    return $result;
}

function importEBooksArray($db, $data) {
    $result = ['success' => 0, 'failed' => 0, 'message' => ''];
    $db->beginTransaction();
    foreach ($data as $row) {
        try {
            $title = trim($row['title'] ?? $row['Title'] ?? '');
            if (empty($title)) { $result['failed']++; continue; }
            $record = [
                'title' => $title,
                'author' => $row['author'] ?? $row['Author'] ?? '',
                'subject' => $row['subject'] ?? $row['Subject'] ?? '',
                'file_path' => $row['file_path'] ?? $row['File Path'] ?? ''
            ];
            $res = importEBookRecord($db, $record);
            if ($res === 'added') $result['success']++;
            else $result['failed']++;
        } catch (Exception $e) { $result['failed']++; }
    }
    $db->commit();
    $result['message'] = "eBooks: {$result['success']} added, {$result['failed']} failed";
    return $result;
}

function importCirculationArray($db, $data) {
    $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'message' => ''];
    $db->beginTransaction();
    foreach ($data as $row) {
        try {
            $admno = trim($row['admno'] ?? $row['AdmNo'] ?? '');
            $barcode = trim($row['barcode'] ?? $row['Barcode'] ?? '');
            $issue_date = trim($row['issue_date'] ?? $row['Issue Date'] ?? '');
            $due_date = trim($row['due_date'] ?? $row['Due Date'] ?? '');
            if (empty($admno) || empty($barcode) || empty($issue_date) || empty($due_date)) { $result['failed']++; continue; }
            $record = [
                'admno' => $admno, 'barcode' => $barcode, 'issue_date' => $issue_date, 'due_date' => $due_date,
                'return_date' => $row['return_date'] ?? $row['Return Date'] ?? null,
                'fine' => (float)($row['fine'] ?? $row['Fine'] ?? 0),
                'notes' => $row['notes'] ?? $row['Notes'] ?? ''
            ];
            $res = importCirculationRecord($db, $record, 'update');
            if ($res === 'added') $result['success']++;
            elseif ($res === 'updated') $result['updated']++;
            else $result['failed']++;
        } catch (Exception $e) { $result['failed']++; }
    }
    $db->commit();
    $result['message'] = "Circulation: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed";
    return $result;
}

// -------------------- RENDER UI --------------------
$currentStep = $_GET['step'] ?? 'form';
renderHeader('Comprehensive Data Import');

if ($currentStep === 'mapping' && isset($_SESSION['import_file'])) {
    $importType = $_SESSION['import_type'];
    $ext = $_SESSION['import_ext'];
    $token = $_SESSION['csrf_token'];
    ?>
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-exchange-alt"></i> Step 2: Column Mapping & Preview</h2>
        <a href="<?= $_SERVER['PHP_SELF'] ?>" class="btn btn-secondary">Cancel & New Import</a>
    </div>
    <div class="card card-import">
        <div class="card-header bg-primary text-white"><h5>Map CSV/Excel Columns to Database Fields</h5></div>
        <div class="card-body">
            <div id="mapping-container">
                <div class="alert alert-info">Loading preview...</div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <label><strong>Duplicate Handling:</strong></label>
                    <select id="duplicate_action" class="form-select">
                        <option value="update">Update existing records (merge)</option>
                        <option value="skip">Skip duplicate records</option>
                        <option value="overwrite">Overwrite (delete + insert)</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label><strong>Email Notification (optional):</strong></label>
                    <input type="email" id="notify_email" class="form-control" placeholder="admin@example.com">
                </div>
            </div>
            <div class="mt-4">
                <div class="progress mb-3" style="display:none;" id="import-progress">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" style="width:0%">0%</div>
                </div>
                <button class="btn btn-success btn-lg" id="startImportBtn"><i class="fas fa-play"></i> Start Import</button>
                <div id="import-status" class="mt-3"></div>
            </div>
        </div>
    </div>
    <script>
    let mapping = {};
    let totalChunks = 0;
    let currentChunk = 0;
    let addedTotal = 0, updatedTotal = 0, failedTotal = 0;
    let duplicateAction = document.getElementById('duplicate_action').value;
    let notifyEmail = document.getElementById('notify_email').value;
    
    document.getElementById('duplicate_action').addEventListener('change', function() {
        duplicateAction = this.value;
    });
    document.getElementById('notify_email').addEventListener('input', function() {
        notifyEmail = this.value;
    });
    
    fetch('?preview=1&type=<?= $importType ?>&token=<?= $token ?>')
        .then(r => r.json())
        .then(data => {
            if (data.error) { document.getElementById('mapping-container').innerHTML = `<div class="alert alert-danger">${data.error}</div>`; return; }
            let imageColumn = data.imageColumn || null;
            let html = `<table class="table table-bordered preview-table"><thead><tr><th>Database Field</th><th>Map to Column</th><th>Preview (first row value)</th>`;
            if (imageColumn) {
                html += `<th>Image Preview</th>`;
            }
            html += `</tr></thead><tbody>`;
            
            for (let field in data.suggested) {
                let suggestedCol = data.suggested[field];
                let previewValue = '';
                if (suggestedCol !== 'ignore' && data.preview[0] && data.preview[0][suggestedCol] !== undefined) {
                    previewValue = data.preview[0][suggestedCol].substring(0, 50);
                }
                let selectHtml = `<select class="form-select mapping-select" data-field="${field}"><option value="ignore">-- Ignore --</option>`;
                data.headers.forEach(col => {
                    let selected = (suggestedCol === col) ? 'selected' : '';
                    selectHtml += `<option value="${col.replace(/"/g, '&quot;')}" ${selected}>${col}</option>`;
                });
                selectHtml += `</select>`;
                html += `<tr><td><strong>${field}</strong></td><td>${selectHtml}</td><td><small id="preview_${field}">${previewValue}</small></td>`;
                if (imageColumn) {
                    let imageUrl = '';
                    // Check if this field is the image column or if we have a preview value
                    if (suggestedCol === imageColumn) {
                        // Use the value from first row as potential image path
                        let imgPath = data.preview[0][imageColumn] || '';
                        if (imgPath) {
                            // Try to construct a URL (if it's a relative path, we can try to use it)
                            // Since we don't have full path, we'll just show a placeholder indicating image available
                            // For better display, we'll try to fetch via AJAX? Better to just show the path.
                            imageUrl = imgPath; // Show the path as text for now
                        }
                    }
                    html += `<td class="image-preview-cell">`;
                    if (imageUrl) {
                        // Try to display as image if it's a URL or we can construct one
                        if (imageUrl.match(/^https?:\/\//) || imageUrl.match(/^\/\//)) {
                            html += `<img src="${imageUrl}" class="preview-image" onerror="this.style.display='none'">`;
                        } else if (imageUrl.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
                            // Try to use as relative path (we can't verify existence from client side)
                            html += `<img src="${imageUrl}" class="preview-image" onerror="this.style.display='none'">`;
                        } else {
                            html += `<span class="text-muted">${escapeHtml(imageUrl.substring(0, 20))}</span>`;
                        }
                    } else {
                        html += `<span class="text-muted">—</span>`;
                    }
                    html += `</td>`;
                }
                html += `</tr>`;
            }
            html += `</tbody></table>`;
            document.getElementById('mapping-container').innerHTML = html;
            
            // Add change event to update preview when mapping changes
            document.querySelectorAll('.mapping-select').forEach(sel => {
                sel.addEventListener('change', function() {
                    let field = this.dataset.field;
                    let col = this.value;
                    let preview = '';
                    if (col !== 'ignore' && data.preview[0] && data.preview[0][col] !== undefined) {
                        preview = data.preview[0][col].substring(0, 50);
                    }
                    document.getElementById(`preview_${field}`).innerText = preview;
                    // If image column, update image preview when mapping changes
                    if (imageColumn && col === imageColumn) {
                        let imgPath = data.preview[0][col] || '';
                        let cell = this.closest('tr').querySelector('.image-preview-cell');
                        if (cell) {
                            if (imgPath) {
                                cell.innerHTML = `<img src="${imgPath}" class="preview-image" onerror="this.style.display='none'">`;
                            } else {
                                cell.innerHTML = `<span class="text-muted">—</span>`;
                            }
                        }
                    }
                });
            });
            
            totalChunks = Math.ceil(data.totalRows / 100);
        });
    
    document.getElementById('startImportBtn').addEventListener('click', function() {
        document.querySelectorAll('.mapping-select').forEach(sel => {
            let field = sel.dataset.field;
            let col = sel.value;
            mapping[field] = col;
        });
        if (totalChunks === 0) {
            alert("No data rows found to import.");
            return;
        }
        document.getElementById('import-progress').style.display = 'block';
        document.getElementById('startImportBtn').disabled = true;
        processChunk();
    });
    
    function processChunk() {
        if (currentChunk >= totalChunks) {
            document.getElementById('import-status').innerHTML = `<div class="alert alert-success">Import completed! Added: ${addedTotal}, Updated: ${updatedTotal}, Failed: ${failedTotal}</div>`;
            if (notifyEmail) {
                fetch('send_notification.php?email=' + encodeURIComponent(notifyEmail) + '&msg=Import completed');
            }
            return;
        }
        let formData = new FormData();
        formData.append('chunk_import', 1);
        formData.append('type', '<?= $importType ?>');
        formData.append('chunk', currentChunk);
        formData.append('total_chunks', totalChunks);
        formData.append('mapping', JSON.stringify(mapping));
        formData.append('duplicate_action', duplicateAction);
        formData.append('token', '<?= $token ?>');
        fetch('', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    addedTotal += data.added;
                    updatedTotal += data.updated;
                    failedTotal += data.failed;
                    let percent = Math.round((currentChunk + 1) / totalChunks * 100);
                    document.querySelector('.progress-bar').style.width = percent + '%';
                    document.querySelector('.progress-bar').innerText = percent + '%';
                    currentChunk++;
                    processChunk();
                } else {
                    document.getElementById('import-status').innerHTML = `<div class="alert alert-danger">Error: ${data.error}</div>`;
                }
            })
            .catch(err => {
                document.getElementById('import-status').innerHTML = `<div class="alert alert-danger">Network error: ${err.message}</div>`;
            });
    }
    
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) { return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'); });
    }
    </script>
    <?php
} else {
    // Normal form UI - updated sample CSVs to include new fields
    ?>
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-database"></i> Data Import Center</h2>
        <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
    </div>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> <strong>Tip for non-English characters:</strong> Save your CSV file as <strong>UTF‑8</strong> (with or without BOM). The system will automatically detect and convert any common encoding to UTF‑8.</div>
    <?php if (!$excelAvailable): ?>
    <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> PhpSpreadsheet is not installed. Excel files will not work. Run: <code>composer require phpoffice/phpspreadsheet</code></div>
    <?php endif; ?>
    <ul class="nav nav-tabs mb-4" id="importTabs" role="tablist">
        <li class="nav-item"><button class="nav-link active" id="members-tab" data-bs-toggle="tab" data-bs-target="#members"><i class="fas fa-users"></i> Members</button></li>
        <li class="nav-item"><button class="nav-link" id="books-tab" data-bs-toggle="tab" data-bs-target="#books"><i class="fas fa-book"></i> Books</button></li>
        <li class="nav-item"><button class="nav-link" id="ebooks-tab" data-bs-toggle="tab" data-bs-target="#ebooks"><i class="fas fa-file-pdf"></i> eBooks</button></li>
        <li class="nav-item"><button class="nav-link" id="photos-tab" data-bs-toggle="tab" data-bs-target="#photos"><i class="fas fa-camera"></i> Bulk Photos</button></li>
        <li class="nav-item"><button class="nav-link" id="covers-tab" data-bs-toggle="tab" data-bs-target="#covers"><i class="fas fa-images"></i> Bulk Covers</button></li>
        <li class="nav-item"><button class="nav-link" id="marc-tab" data-bs-toggle="tab" data-bs-target="#marc"><i class="fas fa-tag"></i> MARC21</button></li>
        <li class="nav-item"><button class="nav-link" id="circulation-tab" data-bs-toggle="tab" data-bs-target="#circulation"><i class="fas fa-exchange-alt"></i> Circulation</button></li>
        <li class="nav-item"><button class="nav-link" id="history-tab" data-bs-toggle="tab" data-bs-target="#history"><i class="fas fa-history"></i> Import History</button></li>
    </ul>

    <div class="tab-content import-tab-content">
        <!-- Members -->
        <div class="tab-pane fade show active" id="members">
            <div class="card card-import"><div class="card-header bg-primary text-white"><h5>Import Members (CSV/Excel/JSON/XML)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="members"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".csv,.xlsx,.json,.xml" required></div><button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload & Map</button><a href="#" class="btn btn-secondary ms-2" id="dlMembers"><i class="fas fa-download"></i> Sample CSV</a></form>
                <div class="remote-url-card card mt-3"><div class="card-body"><form method="post"><input type="hidden" name="import_type" value="members"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><label><i class="fas fa-link"></i> Or import from remote URL:</label><div class="input-group mt-1"><input type="url" name="remote_url" class="form-control" placeholder="https://example.com/data.csv"><button type="submit" class="btn btn-info">Fetch & Import</button></div></form></div></div>
                <div class="sample-preview mt-3">
                    <strong><i class="fas fa-info-circle"></i> Instructions:</strong> Required: <code>AdmNo</code>, <code>Name</code>. Dates in <code>YYYY-MM-DD</code>. Now supports designation, emergency contact, photo path, etc.<br>
                    <strong>Sample preview (first row):</strong>
                    <table class="table table-sm table-bordered mt-2"><thead><tr><th>AdmNo</th><th>Name</th><th>Designation</th><th>Member Category</th><th>Email</th><th>Phone</th></tr></thead><tbody><tr><td>MEM001</td><td>John Doe</td><td>Student</td><td>Student</td><td>john@example.com</td><td>1234567890</td></tr></tbody></table>
                </div>
            </div></div>
        </div>
        <!-- Books -->
        <div class="tab-pane fade" id="books">
            <div class="card card-import"><div class="card-header bg-success text-white"><h5>Import Books (CSV/Excel/JSON/XML)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="books"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".csv,.xlsx,.json,.xml" required></div><button type="submit" class="btn btn-success"><i class="fas fa-upload"></i> Upload & Map</button><a href="#" class="btn btn-secondary ms-2" id="dlBooks"><i class="fas fa-download"></i> Sample CSV</a></form>
                <div class="remote-url-card card mt-3"><div class="card-body"><form method="post"><input type="hidden" name="import_type" value="books"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><label><i class="fas fa-link"></i> Or import from remote URL:</label><div class="input-group mt-1"><input type="url" name="remote_url" class="form-control" placeholder="https://example.com/books.csv"><button type="submit" class="btn btn-info">Fetch & Import</button></div></form></div></div>
                <div class="sample-preview mt-3">
                    <strong><i class="fas fa-info-circle"></i> Instructions:</strong> Required: <code>Barcode</code>, <code>Title</code>. Now supports DDC, LCC, UDC, CC, series, volume, acquisition fields, eBook URL, etc.<br>
                    <strong>Sample preview (first row):</strong>
                    <table class="table table-sm table-bordered mt-2"><thead><tr><th>Barcode</th><th>Title</th><th>Author</th><th>ISBN</th><th>Publisher</th><th>Year</th></tr></thead><tbody><tr><td>B001</td><td>Introduction to Programming</td><td>John Smith</td><td>9781234567890</td><td>Tech Press</td><td>2020</td></tr></tbody></table>
                </div>
            </div></div>
        </div>
        <!-- eBooks -->
        <div class="tab-pane fade" id="ebooks">
            <div class="card card-import"><div class="card-header bg-warning text-white"><h5>Import eBooks (CSV/Excel/JSON/XML)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="ebooks"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".csv,.xlsx,.json,.xml" required></div><button type="submit" class="btn btn-warning"><i class="fas fa-upload"></i> Upload & Map</button></form>
                <div class="remote-url-card card mt-3"><div class="card-body"><form method="post"><input type="hidden" name="import_type" value="ebooks"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><label><i class="fas fa-link"></i> Or import from remote URL:</label><div class="input-group mt-1"><input type="url" name="remote_url" class="form-control" placeholder="https://example.com/ebooks.csv"><button type="submit" class="btn btn-info">Fetch & Import</button></div></form></div></div>
                <div class="sample-preview mt-3">
                    <strong><i class="fas fa-info-circle"></i> Instructions:</strong> Required: <code>Title</code>. File Path can be local path or URL.<br>
                    <strong>Sample preview:</strong> <code>Title,Author,File Path</code><br>Web Development Essentials,John Doe,uploads/ebooks/web_dev.pdf
                </div>
            </div></div>
        </div>
        <!-- Bulk Photos -->
        <div class="tab-pane fade" id="photos">
            <div class="card card-import"><div class="card-header bg-primary text-white"><h5>Bulk Member Photos (ZIP)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="member_photos"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".zip" required></div><button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload ZIP</button></form>
                <div class="sample-preview"><strong>Instructions:</strong> ZIP file containing images named exactly as <code>AdmNo.jpg</code> (e.g., <code>MEM001.jpg</code>). Supported: JPG, PNG, GIF, WEBP. Auto-resized to 300x300.</div>
            </div></div>
        </div>
        <!-- Bulk Covers -->
        <div class="tab-pane fade" id="covers">
            <div class="card card-import"><div class="card-header bg-success text-white"><h5>Bulk Book Covers (ZIP)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="book_covers"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".zip" required></div><button type="submit" class="btn btn-success"><i class="fas fa-upload"></i> Upload ZIP</button></form>
                <div class="sample-preview"><strong>Instructions:</strong> ZIP file containing images named exactly as <code>Barcode.jpg</code> (e.g., <code>B001.jpg</code>). Supported: JPG, PNG, GIF, WEBP. Auto-resized to 400x400.</div>
            </div></div>
        </div>
        <!-- MARC21 -->
        <div class="tab-pane fade" id="marc">
            <div class="card card-import"><div class="card-header bg-info text-white"><h5>MARC21 Import (XML/MRC/ZIP)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="marc"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".xml,.mrc,.zip" required></div><button type="submit" class="btn btn-info"><i class="fas fa-upload"></i> Import MARC</button></form>
                <?php if (!$marcAvailable): ?><div class="alert alert-warning mt-2">⚠️ File_MARC not detected. Install: composer require pear/file_marc</div><?php endif; ?>
                <div class="sample-preview"><strong>Instructions:</strong> Upload single <code>.xml</code> (MARCXML), <code>.mrc</code> (ISO 2709), or a ZIP containing multiple files. Extracts fields: 001, 245, 100, 700, 710, 020, 260/264, 250, 300, 520, 650, 490, 110, 111.<br>Barcode taken from 001.</div>
            </div></div>
        </div>
        <!-- Circulation -->
        <div class="tab-pane fade" id="circulation">
            <div class="card card-import"><div class="card-header bg-danger text-white"><h5>Import Circulation Data (CSV/Excel/JSON/XML)</h5></div><div class="card-body">
                <form method="post" enctype="multipart/form-data"><input type="hidden" name="import_type" value="circulation"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><div class="mb-3"><input type="file" name="import_file" class="form-control" accept=".csv,.xlsx,.json,.xml" required></div><button type="submit" class="btn btn-danger"><i class="fas fa-upload"></i> Upload & Map</button><a href="#" class="btn btn-secondary ms-2" id="dlCirc"><i class="fas fa-download"></i> Sample CSV</a></form>
                <div class="remote-url-card card mt-3"><div class="card-body"><form method="post"><input type="hidden" name="import_type" value="circulation"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"><label><i class="fas fa-link"></i> Or import from remote URL:</label><div class="input-group mt-1"><input type="url" name="remote_url" class="form-control" placeholder="https://example.com/circulation.csv"><button type="submit" class="btn btn-info">Fetch & Import</button></div></form></div></div>
                <div class="sample-preview"><strong>Instructions:</strong> Required columns: <code>admno</code>, <code>barcode</code>, <code>issue_date</code>, <code>due_date</code>. Dates in <code>YYYY-MM-DD</code>. Fine auto-calculated if left empty and return_date is provided.<br><strong>Sample:</strong> admno,barcode,issue_date,due_date,return_date,fine,notes<br>MEM001,B001,2025-01-01,2025-01-15,,,<br>MEM002,B002,2025-01-05,2025-01-20,2025-01-18,2.50,Returned late</div>
            </div></div>
        </div>
        <!-- Import History -->
        <div class="tab-pane fade" id="history">
            <div class="card card-import"><div class="card-header bg-secondary text-white"><h5>Import History</h5></div><div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>Date</th><th>User</th><th>Type</th><th>File</th><th>Records</th><th>Added</th><th>Updated</th><th>Failed</th></tr></thead>
                        <tbody>
                        <?php
                        $logFiles = glob(IMPORT_LOG_DIR . '*.json');
                        rsort($logFiles);
                        $entries = [];
                        foreach ($logFiles as $logFile) {
                            $logs = json_decode(file_get_contents($logFile), true);
                            foreach ($logs as $log) $entries[] = $log;
                        }
                        usort($entries, function($a, $b) { return strtotime($b['timestamp']) - strtotime($a['timestamp']); });
                        $entries = array_slice($entries, 0, 50);
                        foreach ($entries as $log): ?>
                            <tr>
                                <td><?= htmlspecialchars($log['timestamp']) ?></td>
                                <td><?= htmlspecialchars($log['user']) ?></td>
                                <td><?= htmlspecialchars($log['type']) ?></td>
                                <td><?= htmlspecialchars($log['filename']) ?></td>
                                <td><?= $log['records'] ?></td>
                                <td class="text-success"><?= $log['added'] ?></td>
                                <td class="text-warning"><?= $log['updated'] ?></td>
                                <td class="text-danger"><?= $log['failed'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div></div>
        </div>
    </div>

    <script>
    function downloadCSV(content, filename) {
        let blob = new Blob(["\uFEFF" + content], {type: 'text/csv;charset=utf-8;'});
        let link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        link.click();
        URL.revokeObjectURL(link.href);
    }
    document.getElementById('dlMembers')?.addEventListener('click', function(e) {
        e.preventDefault();
        let csv = "AdmNo,Name,Designation,Member Category,Class,Division,Roll No,Email,Phone,Parent Phone,Emergency Contact,Address,DOB,Gender,Blood Group,General ID,Membership Expiry,Security Deposit,Notes,Status,Photo Path\n";
        csv += "MEM001,John Doe,Student,Student,10,A,101,john@example.com,1234567890,0987654321,9998887777,123 Main St,2000-01-15,Male,O+,EXT123,2025-12-31,50,First time user,active,\n";
        downloadCSV(csv, "sample_members.csv");
    });
    document.getElementById('dlBooks')?.addEventListener('click', function(e) {
        e.preventDefault();
        let csv = "Barcode,Title,Sub Title,Author,Author2,Collaborator,Corporate Author,Conference Author,Series,Volume,ISSN,Subject,Keyword,ISBN,Summary,Publisher,Publisher Place,Category,Item Category,Sub Category,Call Number,DDC,UDC,LCC,CC,Other Classification,Quantity,Available,Location,Edition,Year,Pages,Language,Price,Currency,Remarks,Book Status,Binding,Holding,Illustrations,Dimensions,Country,Collection Type,Branch,Shelf,Vendor,Invoice,Invoice Date,Acquisition Date,Funding Source,PO Number,eBook URL,Contents,Accompanying Material,Material Type,Size,Weight\n";
        csv += "B001,Introduction to Programming,A Beginner's Guide,John Smith,Jane Doe,Edited by M. Lee,Open Source Foundation,,Programming Series,Vol 1,1234-5678,Computer Science,programming,9781234567890,Learn programming basics,Tech Press,New York,Computer Science,Textbook,Programming,QA76.73.P98,005.1,004,QA76,CC:2,,5,5,Shelf A1,1st,2020,350,English,29.99,USD,Great,Available,Hardcover,Main Library,illus,23cm,USA,General,Main,Row1,Tech Books,INV123,2024-01-10,2024-01-15,Grant,PO001,https://example.com/ebook.pdf,Chapter 1: Basics,CD-ROM,Paper,23x30cm,0.5kg\n";
        downloadCSV(csv, "sample_books.csv");
    });
    document.getElementById('dlCirc')?.addEventListener('click', function(e) {
        e.preventDefault();
        let csv = "admno,barcode,issue_date,due_date,return_date,fine,notes\n";
        csv += "MEM001,BK001,2025-01-01,2025-01-15,,,\n";
        csv += "MEM002,BK002,2025-01-05,2025-01-20,2025-01-18,2.50,Returned late\n";
        downloadCSV(csv, "sample_circulation.csv");
    });
    </script>
    <?php
}
renderFooter();
?>