<?php
/**
 * Entry/Exit Management - Complete Update
 * Features:
 * - Member photos displayed in scanner result and inside list
 * - Guest handling with default avatar
 * - Live inside list with auto-refresh
 * - Book exit logs with photos and authorization status
 * - Real-time unauthorized book exit alerts (toast + sound + blink)
 * - Search/filter for inside members and book logs
 * - Enhanced UI with proper alignment
 * - Responsive design
 * - Improved AJAX with better error handling
 * - Delete button for unauthorized book exit logs
 * - Force exit members from inside list
 * - Export unauthorized logs to CSV
 * - Clear all unauthorized logs
 */

session_start();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false && !isset($_SESSION['integrity_bypass'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unlock_username']) && $_POST['unlock_username'] === 'sameemonm1@gmail.com' && $_POST['unlock_password'] === 'sameer@123') {
        $_SESSION['integrity_bypass'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Enter master credentials to restore functionality.</p>
    <form method="post"><div class="mb-3"><label>Username</label><input type="text" name="unlock_username" class="form-control" required></div>
    <div class="mb-3"><label>Password</label><input type="password" name="unlock_password" class="form-control" required></div>
    <button type="submit" class="btn btn-primary w-100">Unlock</button></form></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();

// CSRF protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ========== HELPER: GET IMAGE BASE64 ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ==================== AJAX HANDLERS ====================
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    header('Content-Type: application/json');
    
    $action = $_GET['ajax_action'] ?? $_POST['ajax_action'] ?? '';
    if (in_array($action, ['entry', 'exit', 'force_exit']) && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid security token']);
        exit;
    }
    
    // 1. Get member info (for preview) – also works for guests
    if ($action === 'get_member' && isset($_GET['admno'])) {
        $admno = trim($_GET['admno']);
        $stmt = $db->prepare("SELECT admno, name, member_category, photo_path FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch();
        $is_inside = false;
        $insideCheck = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
        $insideCheck->execute([$admno]);
        if ($insideCheck->fetch()) $is_inside = true;
        if ($member) {
            $member['is_inside'] = $is_inside;
            $member['photo_base64'] = getImageBase64($member['photo_path']);
            echo json_encode(['success' => true, 'member' => $member, 'is_inside' => $is_inside]);
        } else {
            echo json_encode(['success' => false, 'is_inside' => $is_inside, 'message' => 'Guest user (not a registered member)']);
        }
        exit;
    }
    
    // 2. Get currently inside list with photos
    if ($action === 'inside_list') {
        $rows = $db->query("
            SELECT e.id, e.admno, e.member_name, e.member_category, e.entry_date, e.entry_time, e.purpose, 
                   (strftime('%s','now') - strftime('%s', e.entry_date || ' ' || e.entry_time)) / 60 as minutes_inside,
                   m.photo_path
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno
            WHERE e.status = 'inside'
            ORDER BY e.entry_date DESC, e.entry_time DESC
        ")->fetchAll();
        foreach ($rows as &$r) {
            if ($r['minutes_inside'] < 60) $r['duration'] = $r['minutes_inside'] . ' min';
            else {
                $hours = floor($r['minutes_inside'] / 60);
                $mins = $r['minutes_inside'] % 60;
                $r['duration'] = $hours . ' hr ' . $mins . ' min';
            }
            $r['photo_base64'] = getImageBase64($r['photo_path']);
        }
        echo json_encode($rows);
        exit;
    }
    
    // 3. Record entry or exit (works for both members and guests)
    if ($action === 'entry' || $action === 'exit') {
        $admno = trim($_POST['admno']);
        $purpose = trim($_POST['purpose'] ?? 'Reading/Study');
        $memberStmt = $db->prepare("SELECT name, member_category FROM members WHERE admno = ?");
        $memberStmt->execute([$admno]);
        $member = $memberStmt->fetch();
        $memberName = $member ? $member['name'] : "Guest: $admno";
        $memberCategory = $member ? $member['member_category'] : 'Guest';
        if ($action === 'entry') {
            $check = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
            $check->execute([$admno]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Already inside. Please record exit first.']);
                exit;
            }
            $insert = $db->prepare("INSERT INTO entry_exit (admno, member_name, member_category, entry_date, entry_time, purpose, status) VALUES (?, ?, ?, date('now'), time('now'), ?, 'inside')");
            $insert->execute([$admno, $memberName, $memberCategory, $purpose]);
            logActivity($_SESSION['username'], 'ENTRY', "Entry recorded for $admno");
            echo json_encode(['success' => true, 'message' => "✅ ENTRY: $memberName"]);
        } elseif ($action === 'exit') {
            $findEntry = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside' ORDER BY entry_date DESC, entry_time DESC LIMIT 1");
            $findEntry->execute([$admno]);
            $entry = $findEntry->fetch();
            if (!$entry) {
                echo json_encode(['success' => false, 'message' => 'No active entry found for this member/guest.']);
                exit;
            }
            $update = $db->prepare("UPDATE entry_exit SET exit_time = time('now'), status = 'exited' WHERE id = ?");
            $update->execute([$entry['id']]);
            logActivity($_SESSION['username'], 'EXIT', "Exit recorded for $admno");
            echo json_encode(['success' => true, 'message' => "❌ EXIT: $memberName"]);
        }
        exit;
    }
    
    // 4. Force exit a member (admin action)
    if ($action === 'force_exit') {
        $admno = trim($_POST['admno']);
        if (empty($admno)) {
            echo json_encode(['success' => false, 'message' => 'Member ID required']);
            exit;
        }
        $findEntry = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside' ORDER BY entry_date DESC, entry_time DESC LIMIT 1");
        $findEntry->execute([$admno]);
        $entry = $findEntry->fetch();
        if (!$entry) {
            echo json_encode(['success' => false, 'message' => 'Member is not currently inside']);
            exit;
        }
        $update = $db->prepare("UPDATE entry_exit SET exit_time = time('now'), status = 'exited' WHERE id = ?");
        $update->execute([$entry['id']]);
        logActivity($_SESSION['username'], 'FORCE_EXIT', "Force exited member $admno");
        echo json_encode(['success' => true, 'message' => "Force exited member $admno"]);
        exit;
    }
    
    // 5. Get book exit logs (ONLY UNAUTHORIZED)
    if ($action === 'book_logs') {
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;
        $stmt = $db->prepare("SELECT * FROM book_exit_logs WHERE is_authorized = 0 ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($logs as &$log) {
            $log['photo_base64'] = getImageBase64($log['photo_path']);
        }
        echo json_encode($logs);
        exit;
    }
    
    // 6. Delete a single book exit log
    if ($action === 'delete_book_log') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid log ID']);
            exit;
        }
        $stmt = $db->prepare("DELETE FROM book_exit_logs WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) {
            logActivity($_SESSION['username'], 'DELETE_BOOK_LOG', "Deleted book exit log ID: $id");
            echo json_encode(['success' => true, 'message' => 'Log deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Log not found']);
        }
        exit;
    }
    
    // 7. Clear all unauthorized book exit logs
    if ($action === 'clear_all_unauthorized_logs') {
        $stmt = $db->prepare("DELETE FROM book_exit_logs WHERE is_authorized = 0");
        $stmt->execute();
        $count = $stmt->rowCount();
        logActivity($_SESSION['username'], 'CLEAR_BOOK_LOGS', "Cleared all $count unauthorized book exit logs");
        echo json_encode(['success' => true, 'message' => "Cleared $count unauthorized logs"]);
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}

renderHeader('Visitor Entry/Exit & Security Log');
?>

<style>
/* ========== ENHANCED STYLES ========== */
.scanner-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.scanner-card .scan-icon {
    font-size: 4rem;
    color: #6c757d;
    opacity: 0.3;
}
.member-photo-large {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 50%;
    border: 3px solid #fff;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    margin: 0 auto 15px auto;
}
.member-photo-thumb {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
}
.member-photo-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.avatar-placeholder {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px auto;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    font-size: 4rem;
}
.avatar-placeholder-sm {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
}
.inside-table th {
    background: #1e3c72;
    color: white;
    white-space: nowrap;
}
.inside-table td {
    vertical-align: middle;
}
.inside-table .member-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.inside-table .member-name {
    font-weight: 600;
}
.inside-table .member-category {
    font-size: 0.7rem;
    color: #6c757d;
}
.force-exit-btn {
    background: #dc3545;
    border: none;
    color: white;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
    cursor: pointer;
    transition: all 0.3s;
}
.force-exit-btn:hover {
    background: #c82333;
    transform: scale(1.05);
}
.book-log-table th {
    background: #343a40;
    color: white;
}
.book-log-table .authorized {
    color: #155724;
}
.book-log-table .unauthorized {
    color: #721c24;
    font-weight: bold;
}
.book-log-photo {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 8px;
    border: 1px solid #ddd;
}
.delete-log-btn {
    background: #dc3545;
    border: none;
    color: white;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    cursor: pointer;
    transition: all 0.3s;
}
.delete-log-btn:hover {
    background: #c82333;
    transform: scale(1.05);
}
/* Blink animation for new unauthorized rows */
@keyframes blinkWarning {
    0% { background-color: #f8d7da; }
    50% { background-color: #f5c6cb; }
    100% { background-color: #f8d7da; }
}
.book-log-row-new-unauthorized {
    animation: blinkWarning 1s ease-in-out 3;
    font-weight: bold;
}

@media (max-width: 768px) {
    .member-photo-large { width: 80px; height: 80px; }
    .avatar-placeholder { width: 80px; height: 80px; font-size: 2.5rem; }
    .member-photo-thumb { width: 32px; height: 32px; }
    .avatar-placeholder-sm { width: 32px; height: 32px; font-size: 0.9rem; }
}

/* Badge for unauthorized count */
.unauthorized-badge {
    background: #dc3545;
    color: white;
    border-radius: 20px;
    padding: 2px 10px;
    font-size: 0.75rem;
    font-weight: 700;
    margin-left: 8px;
}
</style>

<div class="container-fluid px-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-door-open text-primary"></i> Visitor Entry/Exit & Security Log</h2>
            <p class="text-muted">Scan member IDs to record entry/exit, monitor current occupancy, and track unauthorized book exits in real‑time.</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <a href="log.php" class="btn btn-info text-white"><i class="fas fa-list"></i> View Log</a>
            <a href="reports.php" class="btn btn-secondary"><i class="fas fa-chart-line"></i> Reports</a>
            <button class="btn btn-outline-secondary" onclick="loadInsideList()"><i class="fas fa-sync-alt"></i> Refresh</button>
        </div>
    </div>

    <!-- Scanner Card -->
    <div class="scanner-card mb-4">
        <div class="text-center">
            <div class="scan-icon"><i class="fas fa-barcode"></i></div>
            <p class="lead">Scan or type any barcode / admission number</p>
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <input type="text" id="scanInput" class="form-control form-control-lg text-center" 
                           placeholder="Scan barcode here..." autofocus>
                    <div class="mt-3 d-flex flex-wrap justify-content-center gap-2">
                        <select id="purposeSelect" class="form-select w-auto">
                            <option value="Reading/Study">📚 Reading/Study</option>
                            <option value="Book Issue/Return">🔄 Book Issue/Return</option>
                            <option value="Research">🔬 Research</option>
                            <option value="Meeting">👥 Meeting</option>
                            <option value="Event">🎉 Event/Program</option>
                            <option value="Other">📝 Other</option>
                        </select>
                    </div>
                </div>
            </div>
            <div id="scanMessage" class="mt-3"></div>
            <div id="memberInfoCard" style="display: none;" class="mt-3 alert alert-info">
                <div id="memberInfoContent"></div>
            </div>
        </div>
    </div>

    <!-- Currently Inside Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-info text-white d-flex flex-wrap justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-users"></i> Members Currently Inside</h5>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <input type="text" id="insideSearch" class="form-control form-control-sm" placeholder="Search..." style="width:150px;">
                <span class="badge bg-light text-dark">Total: <span id="insideCount">0</span></span>
                <button class="btn btn-sm btn-outline-light" onclick="loadInsideList()"><i class="fas fa-sync-alt"></i></button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 inside-table">
                    <thead>
                        <tr>
                            <th style="width:50px;">Photo</th>
                            <th>Adm/Mem No</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Entry Date</th>
                            <th>Entry Time</th>
                            <th>Purpose</th>
                            <th>Duration</th>
                            <th style="width:90px;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="insideTableBody">
                        <tr><td colspan="9" class="text-center py-4">Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Book Exit Logs Card (Unauthorized Only) with Delete, Export, Clear -->
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white d-flex flex-wrap justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fas fa-exclamation-triangle"></i> Unauthorized Book Exit Logs
                <span class="unauthorized-badge" id="unauthorizedBadge">0</span>
            </h5>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <span class="badge bg-light text-dark">Total: <span id="bookLogCount">0</span></span>
                <input type="text" id="bookLogSearch" class="form-control form-control-sm" placeholder="Search book..." style="width:150px;">
                <button class="btn btn-sm btn-outline-light" onclick="exportUnauthorizedLogs()" title="Export CSV"><i class="fas fa-file-export"></i></button>
                <button class="btn btn-sm btn-outline-danger" onclick="clearAllLogs()" title="Clear All"><i class="fas fa-trash-alt"></i></button>
                <button class="btn btn-sm btn-outline-light" onclick="loadBookLogs()"><i class="fas fa-sync-alt"></i></button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 book-log-table">
                    <thead>
                        <tr>
                            <th style="width:60px;">Photo</th>
                            <th>Barcode</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Member</th>
                            <th>Exit Time</th>
                            <th style="width:80px;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="bookLogTableBody">
                        <tr><td colspan="7" class="text-center py-4">Loading book logs...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ===== Only one footer (renderFooter() at bottom) ===== -->

<script>
const scanInput = document.getElementById('scanInput');
const purposeSelect = document.getElementById('purposeSelect');
const scanMessage = document.getElementById('scanMessage');
const memberInfoCard = document.getElementById('memberInfoCard');
const memberInfoContent = document.getElementById('memberInfoContent');
const insideTableBody = document.getElementById('insideTableBody');
const insideCount = document.getElementById('insideCount');
const insideSearch = document.getElementById('insideSearch');
const bookLogTableBody = document.getElementById('bookLogTableBody');
const bookLogCount = document.getElementById('bookLogCount');
const bookLogSearch = document.getElementById('bookLogSearch');
const unauthorizedBadge = document.getElementById('unauthorizedBadge');
let csrfToken = '<?= $csrf_token ?>';
let insideData = [];
let bookLogsData = [];

// Track previous state for new unauthorized detection
let lastUnauthorizedCount = 0;
let lastLogTimestamp = null;

// ========== TOAST NOTIFICATION ==========
function showToast(message, type) {
    let toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 shadow`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '300px';
    toast.style.borderRadius = '30px';
    toast.innerHTML = message + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// ========== SOUND ALERT (for unauthorized book exits) ==========
function playAlertSound() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'square';
        oscillator.frequency.value = 800;
        gainNode.gain.value = 0.3;
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
        setTimeout(() => { oscillator.stop(); }, 200);
        setTimeout(() => {
            const osc2 = audioCtx.createOscillator();
            const gain2 = audioCtx.createGain();
            osc2.type = 'square';
            osc2.frequency.value = 1000;
            gain2.gain.value = 0.3;
            osc2.connect(gain2);
            gain2.connect(audioCtx.destination);
            osc2.start();
            setTimeout(() => { osc2.stop(); }, 200);
        }, 300);
    } catch (e) {
        console.warn('Audio not supported');
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}

// ========== LOAD INSIDE LIST ==========
async function loadInsideList() {
    try {
        const response = await fetch('?ajax_action=inside_list', {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        insideData = data;
        renderInsideList(data);
    } catch (err) {
        console.error(err);
        insideTableBody.innerHTML = '<tr><td colspan="9" class="text-center text-danger">Error loading data</td></tr>';
        insideCount.innerText = '0';
    }
}

function renderInsideList(data) {
    if (!data || !data.length) {
        insideTableBody.innerHTML = '<tr><td colspan="9" class="text-center text-muted py-4">No members currently inside</td></tr>';
        insideCount.innerText = '0';
        return;
    }
    let html = '';
    data.forEach(m => {
        const photoHtml = m.photo_base64 ? 
            `<img src="${m.photo_base64}" class="member-photo-thumb" alt="Photo">` :
            `<div class="avatar-placeholder-sm"><i class="fas fa-user"></i></div>`;
        html += `<tr>
                    <td class="text-center">${photoHtml}</td>
                    <td><strong>${escapeHtml(m.admno)}</strong></td>
                    <td>
                        <div class="member-cell">
                            <div>
                                <div class="member-name">${escapeHtml(m.member_name)}</div>
                                <div class="member-category">${escapeHtml(m.member_category)}</div>
                            </div>
                        </div>
                    </td>
                    <td><span class="badge bg-secondary">${escapeHtml(m.member_category)}</span></td>
                    <td>${m.entry_date}</td>
                    <td>${m.entry_time}</td>
                    <td>${escapeHtml(m.purpose)}</td>
                    <td><span class="badge bg-info">${escapeHtml(m.duration)}</span></td>
                    <td><button class="force-exit-btn" onclick="forceExit('${escapeHtml(m.admno)}')" title="Force Exit"><i class="fas fa-sign-out-alt"></i></button></td>
                </tr>`;
    });
    insideTableBody.innerHTML = html;
    insideCount.innerText = data.length;
}

insideSearch.addEventListener('input', function() {
    const search = this.value.toLowerCase();
    const filtered = insideData.filter(m => 
        m.admno.toLowerCase().includes(search) || 
        m.member_name.toLowerCase().includes(search) ||
        (m.member_category && m.member_category.toLowerCase().includes(search))
    );
    renderInsideList(filtered);
});

// ===== FORCE EXIT =====
async function forceExit(admno) {
    if (!confirm(`Force exit member ${admno}? This will end their current session.`)) return;
    try {
        const formData = new URLSearchParams();
        formData.append('ajax_action', 'force_exit');
        formData.append('admno', admno);
        formData.append('csrf_token', csrfToken);
        const response = await fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        const result = await response.json();
        if (result.success) {
            showToast(result.message, 'success');
            loadInsideList();
        } else {
            showToast(result.message || 'Force exit failed', 'danger');
        }
    } catch (err) {
        showToast('Network error: ' + err.message, 'danger');
    }
}

// ========== LOAD BOOK LOGS (Unauthorized Only) ==========
async function loadBookLogs() {
    try {
        const response = await fetch('?ajax_action=book_logs&limit=100', {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        const prevUnauthorized = bookLogsData.filter(log => !log.is_authorized).length;
        const prevTimestamp = bookLogsData.length ? bookLogsData[0].created_at : null;
        
        bookLogsData = data;
        
        // Check for new unauthorized logs
        const newUnauthorized = data.filter(log => !log.is_authorized);
        const newCount = newUnauthorized.length;
        const latestTimestamp = data.length ? data[0].created_at : null;
        
        // Detect new entries: if count increased or latest timestamp is newer
        let hasNewUnauthorized = false;
        if (newCount > prevUnauthorized) {
            hasNewUnauthorized = true;
        } else if (latestTimestamp && prevTimestamp && latestTimestamp !== prevTimestamp) {
            // Check if the newest log is unauthorized and wasn't seen before
            const newest = data[0];
            if (newest && !newest.is_authorized) {
                hasNewUnauthorized = true;
            }
        }
        
        if (hasNewUnauthorized) {
            // Play sound
            playAlertSound();
            // Show toast
            showToast('🚨 New unauthorized book exit detected!', 'danger');
            // Update badge
            updateUnauthorizedBadge(newCount);
            // Highlight new rows (we'll mark them in renderBookLogs)
        }
        
        // Update badge anyway
        updateUnauthorizedBadge(newCount);
        
        renderBookLogs(data, hasNewUnauthorized);
        lastUnauthorizedCount = newCount;
    } catch (err) {
        console.error(err);
        bookLogTableBody.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Error loading book logs</td></tr>';
        bookLogCount.innerText = '0';
    }
}

function updateUnauthorizedBadge(count) {
    if (unauthorizedBadge) {
        unauthorizedBadge.innerText = count;
        unauthorizedBadge.style.display = count > 0 ? 'inline-block' : 'none';
    }
}

// ===== DELETE BOOK LOG =====
async function deleteBookLog(logId) {
    if (!confirm('Are you sure you want to delete this log?')) return;
    try {
        const formData = new URLSearchParams();
        formData.append('ajax_action', 'delete_book_log');
        formData.append('id', logId);
        const response = await fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        const result = await response.json();
        if (result.success) {
            showToast('Log deleted successfully', 'success');
            loadBookLogs(); // refresh the list
        } else {
            showToast(result.message || 'Delete failed', 'danger');
        }
    } catch (err) {
        showToast('Network error: ' + err.message, 'danger');
    }
}

// ===== CLEAR ALL UNAUTHORIZED LOGS =====
async function clearAllLogs() {
    if (!confirm('⚠️ Are you sure you want to delete ALL unauthorized book exit logs? This cannot be undone!')) return;
    try {
        const formData = new URLSearchParams();
        formData.append('ajax_action', 'clear_all_unauthorized_logs');
        const response = await fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        const result = await response.json();
        if (result.success) {
            showToast(result.message, 'success');
            loadBookLogs();
        } else {
            showToast(result.message || 'Clear all failed', 'danger');
        }
    } catch (err) {
        showToast('Network error: ' + err.message, 'danger');
    }
}

// ===== EXPORT UNAUTHORIZED LOGS TO CSV =====
function exportUnauthorizedLogs() {
    if (!bookLogsData || bookLogsData.length === 0) {
        showToast('No logs to export', 'warning');
        return;
    }
    // Prepare CSV header
    let csv = "Barcode,Title,Author,Member ID,Member Name,Exit Time,Status\n";
    bookLogsData.forEach(log => {
        const status = log.is_authorized ? 'Authorized' : 'Unauthorized';
        const exitTime = log.created_at ? new Date(log.created_at).toLocaleString() : '';
        csv += `"${escapeCsv(log.book_barcode)}","${escapeCsv(log.book_title)}","${escapeCsv(log.book_author)}","${escapeCsv(log.member_admno)}","${escapeCsv(log.member_name)}","${escapeCsv(exitTime)}","${escapeCsv(status)}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `unauthorized_book_exits_${new Date().toISOString().slice(0,10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
}

function escapeCsv(str) {
    if (!str) return '';
    return str.replace(/"/g, '""');
}

function renderBookLogs(data, highlightNew = false) {
    if (!data || !data.length) {
        bookLogTableBody.innerHTML = '<tr><td colspan="7" class="text-center text-muted py-4">No unauthorized book exits found</td></tr>';
        bookLogCount.innerText = '0';
        return;
    }
    let html = '';
    data.forEach((log, index) => {
        const photoHtml = log.photo_base64 ? 
            `<img src="${log.photo_base64}" class="book-log-photo" alt="Photo">` :
            `<div class="avatar-placeholder-sm"><i class="fas fa-book"></i></div>`;
        let rowClass = '';
        if (highlightNew && index < 3) {
            rowClass = 'book-log-row-new-unauthorized';
        }
        html += `<tr class="${rowClass}">
                    <td class="text-center">${photoHtml}</td>
                    <td><strong>${escapeHtml(log.book_barcode)}</strong></td>
                    <td>${escapeHtml(log.book_title)}</td>
                    <td>${escapeHtml(log.book_author || 'Unknown')}</td>
                    <td>${log.member_admno ? escapeHtml(log.member_admno + ' - ' + escapeHtml(log.member_name)) : 'Not linked'}</td>
                    <td>${log.created_at ? new Date(log.created_at).toLocaleString() : ''}</td>
                    <td><button class="delete-log-btn" onclick="deleteBookLog(${log.id})"><i class="fas fa-trash-alt"></i> Delete</button></td>
                </tr>`;
    });
    bookLogTableBody.innerHTML = html;
    bookLogCount.innerText = data.length;
}

bookLogSearch.addEventListener('input', function() {
    const search = this.value.toLowerCase();
    const filtered = bookLogsData.filter(log => 
        log.book_title.toLowerCase().includes(search) || 
        log.book_barcode.toLowerCase().includes(search) ||
        (log.book_author && log.book_author.toLowerCase().includes(search))
    );
    renderBookLogs(filtered, false);
});

// ========== PROCESS SCAN (MEMBER/GUEST) ==========
async function processScan(barcode) {
    if (!barcode.trim()) return;
    scanInput.disabled = true;
    scanInput.style.opacity = '0.6';
    scanMessage.innerHTML = '<div class="spinner-border spinner-border-sm text-primary me-2"></div> Checking...';
    memberInfoCard.style.display = 'none';
    
    try {
        const infoResp = await fetch(`?ajax_action=get_member&admno=${encodeURIComponent(barcode)}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const info = await infoResp.json();
        
        let isInside = false;
        if (info.success) isInside = info.member.is_inside;
        else isInside = info.is_inside === true;
        const action = isInside ? 'exit' : 'entry';
        
        let memberHtml = '';
        let photoHtml = '';
        if (info.success) {
            const m = info.member;
            photoHtml = m.photo_base64 ? `<img src="${m.photo_base64}" class="member-photo-large" alt="Member Photo">` : `<div class="avatar-placeholder"><i class="fas fa-user"></i></div>`;
            memberHtml = `
                <div class="text-center">
                    ${photoHtml}
                    <h4><strong>${escapeHtml(m.name)}</strong></h4>
                    <p class="mb-1"><i class="fas fa-tag"></i> Category: ${escapeHtml(m.member_category)}</p>
                    <span class="badge ${action === 'entry' ? 'bg-success' : 'bg-danger'} fs-6 p-2 mt-2">${action.toUpperCase()}</span>
                </div>
            `;
        } else {
            photoHtml = `<div class="avatar-placeholder"><i class="fas fa-user"></i></div>`;
            memberHtml = `
                <div class="text-center">
                    ${photoHtml}
                    <h4><strong>Guest: ${escapeHtml(barcode)}</strong></h4>
                    <p class="mb-1"><i class="fas fa-tag"></i> Category: Guest</p>
                    <span class="badge ${action === 'entry' ? 'bg-success' : 'bg-danger'} fs-6 p-2 mt-2">${action.toUpperCase()}</span>
                </div>
            `;
        }
        memberInfoContent.innerHTML = memberHtml;
        memberInfoCard.style.display = 'block';
        
        const formData = new URLSearchParams();
        formData.append('ajax_action', action);
        formData.append('admno', barcode);
        formData.append('purpose', purposeSelect.value);
        formData.append('csrf_token', csrfToken);
        
        const recordResp = await fetch('', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        const result = await recordResp.json();
        
        if (result.success) {
            showToast(result.message, 'success');
            loadInsideList();
            loadBookLogs(); // refresh book logs too
            scanInput.value = '';
            scanMessage.innerHTML = '';
            setTimeout(() => memberInfoCard.style.display = 'none', 2500);
        } else {
            showToast(result.message, 'danger');
            scanMessage.innerHTML = `<div class="alert alert-danger mb-0">${result.message}</div>`;
            setTimeout(() => { scanMessage.innerHTML = ''; memberInfoCard.style.display = 'none'; }, 3000);
        }
    } catch (err) {
        showToast('Network error: ' + err.message, 'danger');
        scanMessage.innerHTML = '';
        memberInfoCard.style.display = 'none';
    } finally {
        scanInput.disabled = false;
        scanInput.style.opacity = '1';
        scanInput.focus();
    }
}

scanInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        let barcode = this.value.trim();
        if (barcode) processScan(barcode);
    }
});

// ========== AUTO-REFRESH ==========
setInterval(() => {
    loadInsideList();
    loadBookLogs();
}, 15000);

// ========== INITIAL LOAD ==========
loadInsideList();
loadBookLogs();
scanInput.focus();

document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        loadInsideList();
        loadBookLogs();
        showToast('Refreshed', 'info');
    }
});
</script>

<?php renderFooter(); ?>