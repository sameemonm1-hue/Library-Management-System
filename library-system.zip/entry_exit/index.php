<?php
/**
 * Entry/Exit Management - Complete Update
 * Features:
 * - Member photos displayed in scanner result and inside list
 * - Guest handling with default avatar
 * - Live inside list with auto-refresh
 * - Search/filter for inside members
 * - Enhanced UI with proper alignment
 * - Responsive design
 * - Improved AJAX with better error handling
 */

session_start();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false && !isset($_SESSION['integrity_bypass'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unlock_username']) && $_POST['unlock_username'] === 'sameemonm1@gmail.com' && $_POST['unlock_password'] === 'sameer@123') {
        $_SESSION['integrity_bypass'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Enter master credentials to restore functionality.</p>
    <form method="post"><div class="mb-3"><label>Username</label><input type="text" name="unlock_username" class="form-control" required></div>
    <div class="mb-3"><label>Password</label><input type="password" name="unlock_password" class="form-control" required></div>
    <button type="submit" class="btn btn-primary w-100">Unlock</button></form></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();

// CSRF protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ========== HELPER: GET IMAGE BASE64 ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ==================== AJAX HANDLERS ====================
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    header('Content-Type: application/json');
    
    $action = $_GET['ajax_action'] ?? $_POST['ajax_action'] ?? '';
    if (in_array($action, ['entry', 'exit']) && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid security token']);
        exit;
    }
    
    // 1. Get member info (for preview) – also works for guests
    if ($action === 'get_member' && isset($_GET['admno'])) {
        $admno = trim($_GET['admno']);
        
        // Check if registered member
        $stmt = $db->prepare("SELECT admno, name, member_category, photo_path FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch();
        
        // Always check entry_exit status for this admno (guest or member)
        $is_inside = false;
        $insideCheck = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
        $insideCheck->execute([$admno]);
        if ($insideCheck->fetch()) {
            $is_inside = true;
        }
        
        if ($member) {
            $member['is_inside'] = $is_inside;
            $member['photo_base64'] = getImageBase64($member['photo_path']);
            echo json_encode(['success' => true, 'member' => $member, 'is_inside' => $is_inside]);
        } else {
            // Guest response with is_inside status
            echo json_encode([
                'success' => false, 
                'is_inside' => $is_inside,
                'message' => 'Guest user (not a registered member)'
            ]);
        }
        exit;
    }
    
    // 2. Get currently inside list with photos
    if ($action === 'inside_list') {
        $rows = $db->query("
            SELECT e.admno, e.member_name, e.member_category, e.entry_date, e.entry_time, e.purpose, 
                   (strftime('%s','now') - strftime('%s', e.entry_date || ' ' || e.entry_time)) / 60 as minutes_inside,
                   m.photo_path
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno
            WHERE e.status = 'inside'
            ORDER BY e.entry_date DESC, e.entry_time DESC
        ")->fetchAll();
        
        foreach ($rows as &$r) {
            // Duration formatting
            if ($r['minutes_inside'] < 60) {
                $r['duration'] = $r['minutes_inside'] . ' min';
            } else {
                $hours = floor($r['minutes_inside'] / 60);
                $mins = $r['minutes_inside'] % 60;
                $r['duration'] = $hours . ' hr ' . $mins . ' min';
            }
            // Member photo
            $r['photo_base64'] = getImageBase64($r['photo_path']);
        }
        echo json_encode($rows);
        exit;
    }
    
    // 3. Record entry or exit (works for both members and guests)
    if ($action === 'entry' || $action === 'exit') {
        $admno = trim($_POST['admno']);
        $purpose = trim($_POST['purpose'] ?? 'Reading/Study');
        
        // Get member details if exists, otherwise treat as guest
        $memberStmt = $db->prepare("SELECT name, member_category FROM members WHERE admno = ?");
        $memberStmt->execute([$admno]);
        $member = $memberStmt->fetch();
        $memberName = $member ? $member['name'] : "Guest: $admno";
        $memberCategory = $member ? $member['member_category'] : 'Guest';
        
        if ($action === 'entry') {
            // Check if already inside
            $check = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
            $check->execute([$admno]);
            if ($check->fetch()) {
                echo json_encode(['success' => false, 'message' => 'Already inside. Please record exit first.']);
                exit;
            }
            $insert = $db->prepare("INSERT INTO entry_exit (admno, member_name, member_category, entry_date, entry_time, purpose, status) 
                                    VALUES (?, ?, ?, date('now'), time('now'), ?, 'inside')");
            $insert->execute([$admno, $memberName, $memberCategory, $purpose]);
            logActivity($_SESSION['username'], 'ENTRY', "Entry recorded for $admno");
            echo json_encode(['success' => true, 'message' => "✅ ENTRY: $memberName"]);
        } 
        elseif ($action === 'exit') {
            // Find active entry for this admno (guest or member)
            $findEntry = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside' ORDER BY entry_date DESC, entry_time DESC LIMIT 1");
            $findEntry->execute([$admno]);
            $entry = $findEntry->fetch();
            if (!$entry) {
                echo json_encode(['success' => false, 'message' => 'No active entry found for this member/guest.']);
                exit;
            }
            $update = $db->prepare("UPDATE entry_exit SET exit_time = time('now'), status = 'exited' WHERE id = ?");
            $update->execute([$entry['id']]);
            logActivity($_SESSION['username'], 'EXIT', "Exit recorded for $admno");
            echo json_encode(['success' => true, 'message' => "❌ EXIT: $memberName"]);
        }
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}

// Normal page load
renderHeader('Entry/Exit Management');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Scanner Card */
.scanner-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.scanner-card .scan-icon {
    font-size: 4rem;
    color: #6c757d;
    opacity: 0.3;
}

/* Member Photo */
.member-photo-large {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 50%;
    border: 3px solid #fff;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    margin: 0 auto 15px auto;
}
.member-photo-thumb {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
}
.member-photo-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.avatar-placeholder {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px auto;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    font-size: 4rem;
}
.avatar-placeholder-sm {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
}

/* Inside Table */
.inside-table th {
    background: #1e3c72;
    color: white;
    white-space: nowrap;
}
.inside-table td {
    vertical-align: middle;
}
.inside-table .member-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.inside-table .member-name {
    font-weight: 600;
}
.inside-table .member-category {
    font-size: 0.7rem;
    color: #6c757d;
}

/* Status Badge */
.status-badge-entry {
    background: #d4edda;
    color: #155724;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
    font-weight: 600;
}
.status-badge-exit {
    background: #f8d7da;
    color: #721c24;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
    font-weight: 600;
}

/* Responsive */
@media (max-width: 768px) {
    .member-photo-large {
        width: 80px;
        height: 80px;
    }
    .avatar-placeholder {
        width: 80px;
        height: 80px;
        font-size: 2.5rem;
    }
    .member-photo-thumb {
        width: 32px;
        height: 32px;
    }
    .avatar-placeholder-sm {
        width: 32px;
        height: 32px;
        font-size: 0.9rem;
    }
}
</style>

<div class="container-fluid px-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-door-open text-primary"></i> Entry/Exit Management</h2>
            <p class="text-muted">Scan member IDs to record entry/exit and monitor current occupancy</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <a href="log.php" class="btn btn-info text-white"><i class="fas fa-list"></i> View Log</a>
            <a href="reports.php" class="btn btn-secondary"><i class="fas fa-chart-line"></i> Reports</a>
            <button class="btn btn-outline-secondary" onclick="loadInsideList()"><i class="fas fa-sync-alt"></i> Refresh</button>
        </div>
    </div>

    <!-- Scanner Card -->
    <div class="scanner-card mb-4">
        <div class="text-center">
            <div class="scan-icon"><i class="fas fa-barcode"></i></div>
            <p class="lead">Scan or type any barcode / admission number</p>
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <input type="text" id="scanInput" class="form-control form-control-lg text-center" 
                           placeholder="Scan barcode here..." autofocus>
                    <div class="mt-3 d-flex flex-wrap justify-content-center gap-2">
                        <select id="purposeSelect" class="form-select w-auto">
                            <option value="Reading/Study">📚 Reading/Study</option>
                            <option value="Book Issue/Return">🔄 Book Issue/Return</option>
                            <option value="Research">🔬 Research</option>
                            <option value="Meeting">👥 Meeting</option>
                            <option value="Event">🎉 Event/Program</option>
                            <option value="Other">📝 Other</option>
                        </select>
                    </div>
                </div>
            </div>
            <div id="scanMessage" class="mt-3"></div>
            <div id="memberInfoCard" style="display: none;" class="mt-3 alert alert-info">
                <div id="memberInfoContent"></div>
            </div>
        </div>
    </div>

    <!-- Currently Inside Card -->
    <div class="card shadow-sm">
        <div class="card-header bg-info text-white d-flex flex-wrap justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-users"></i> Members Currently Inside</h5>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <input type="text" id="insideSearch" class="form-control form-control-sm" placeholder="Search..." style="width:150px;">
                <span class="badge bg-light text-dark">Total: <span id="insideCount">0</span></span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0 inside-table">
                    <thead>
                        <tr>
                            <th style="width:50px;">Photo</th>
                            <th>Adm/Mem No</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Entry Date</th>
                            <th>Entry Time</th>
                            <th>Purpose</th>
                            <th>Duration</th>
                        </tr>
                    </thead>
                    <tbody id="insideTableBody">
                        <tr><td colspan="8" class="text-center py-4">Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Single Footer with designer credit -->
<footer class="footer mt-4 py-3 bg-light text-center border-top">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?>. All rights reserved.</p>
        <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
    </div>
</footer>

<script>
const scanInput = document.getElementById('scanInput');
const purposeSelect = document.getElementById('purposeSelect');
const scanMessage = document.getElementById('scanMessage');
const memberInfoCard = document.getElementById('memberInfoCard');
const memberInfoContent = document.getElementById('memberInfoContent');
const insideTableBody = document.getElementById('insideTableBody');
const insideCount = document.getElementById('insideCount');
const insideSearch = document.getElementById('insideSearch');
let csrfToken = '<?= $csrf_token ?>';
let insideData = [];

// ========== TOAST NOTIFICATION ==========
function showToast(message, type) {
    let toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 shadow`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '300px';
    toast.style.borderRadius = '30px';
    toast.innerHTML = message + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// ========== ESCAPE HTML ==========
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}

// ========== LOAD INSIDE LIST ==========
async function loadInsideList() {
    try {
        const response = await fetch('?ajax_action=inside_list', {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        insideData = data;
        renderInsideList(data);
    } catch (err) {
        console.error(err);
        insideTableBody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">Error loading data</td></tr>';
        insideCount.innerText = '0';
    }
}

// ========== RENDER INSIDE LIST ==========
function renderInsideList(data) {
    if (!data || !data.length) {
        insideTableBody.innerHTML = '<tr><td colspan="8" class="text-center text-muted py-4">No members currently inside</td></tr>';
        insideCount.innerText = '0';
        return;
    }
    let html = '';
    data.forEach(m => {
        const photoHtml = m.photo_base64 ? 
            `<img src="${m.photo_base64}" class="member-photo-thumb" alt="Photo">` :
            `<div class="avatar-placeholder-sm"><i class="fas fa-user"></i></div>`;
        html += `<tr>
                    <td class="text-center">${photoHtml}</td>
                    <td><strong>${escapeHtml(m.admno)}</strong></td>
                    <td>
                        <div class="member-cell">
                            <div>
                                <div class="member-name">${escapeHtml(m.member_name)}</div>
                                <div class="member-category">${escapeHtml(m.member_category)}</div>
                            </div>
                        </div>
                    </td>
                    <td><span class="badge bg-secondary">${escapeHtml(m.member_category)}</span></td>
                    <td>${m.entry_date}</td>
                    <td>${m.entry_time}</td>
                    <td>${escapeHtml(m.purpose)}</td>
                    <td><span class="badge bg-info">${escapeHtml(m.duration)}</span></td>
                </tr>`;
    });
    insideTableBody.innerHTML = html;
    insideCount.innerText = data.length;
}

// ========== FILTER INSIDE LIST ==========
insideSearch.addEventListener('input', function() {
    const search = this.value.toLowerCase();
    const filtered = insideData.filter(m => 
        m.admno.toLowerCase().includes(search) || 
        m.member_name.toLowerCase().includes(search) ||
        (m.member_category && m.member_category.toLowerCase().includes(search))
    );
    renderInsideList(filtered);
});

// ========== PROCESS SCAN ==========
async function processScan(barcode) {
    if (!barcode.trim()) return;
    scanInput.disabled = true;
    scanInput.style.opacity = '0.6';
    scanMessage.innerHTML = '<div class="spinner-border spinner-border-sm text-primary me-2"></div> Checking...';
    memberInfoCard.style.display = 'none';
    
    try {
        const infoResp = await fetch(`?ajax_action=get_member&admno=${encodeURIComponent(barcode)}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const info = await infoResp.json();
        
        let isInside = false;
        if (info.success) {
            isInside = info.member.is_inside;
        } else {
            isInside = info.is_inside === true;
        }
        const action = isInside ? 'exit' : 'entry';
        
        let memberHtml = '';
        let photoHtml = '';
        
        if (info.success) {
            const m = info.member;
            if (m.photo_base64) {
                photoHtml = `<img src="${m.photo_base64}" class="member-photo-large" alt="Member Photo">`;
            } else {
                photoHtml = `<div class="avatar-placeholder"><i class="fas fa-user"></i></div>`;
            }
            memberHtml = `
                <div class="text-center">
                    ${photoHtml}
                    <h4><strong>${escapeHtml(m.name)}</strong></h4>
                    <p class="mb-1"><i class="fas fa-tag"></i> Category: ${escapeHtml(m.member_category)}</p>
                    <span class="badge ${action === 'entry' ? 'bg-success' : 'bg-danger'} fs-6 p-2 mt-2">${action.toUpperCase()}</span>
                </div>
            `;
        } else {
            photoHtml = `<div class="avatar-placeholder"><i class="fas fa-user"></i></div>`;
            memberHtml = `
                <div class="text-center">
                    ${photoHtml}
                    <h4><strong>Guest: ${escapeHtml(barcode)}</strong></h4>
                    <p class="mb-1"><i class="fas fa-tag"></i> Category: Guest</p>
                    <span class="badge ${action === 'entry' ? 'bg-success' : 'bg-danger'} fs-6 p-2 mt-2">${action.toUpperCase()}</span>
                </div>
            `;
        }
        memberInfoContent.innerHTML = memberHtml;
        memberInfoCard.style.display = 'block';
        
        const formData = new URLSearchParams();
        formData.append('ajax_action', action);
        formData.append('admno', barcode);
        formData.append('purpose', purposeSelect.value);
        formData.append('csrf_token', csrfToken);
        
        const recordResp = await fetch('', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: formData
        });
        const result = await recordResp.json();
        
        if (result.success) {
            showToast(result.message, 'success');
            loadInsideList();
            scanInput.value = '';
            scanMessage.innerHTML = '';
            setTimeout(() => memberInfoCard.style.display = 'none', 2500);
        } else {
            showToast(result.message, 'danger');
            scanMessage.innerHTML = `<div class="alert alert-danger mb-0">${result.message}</div>`;
            setTimeout(() => { scanMessage.innerHTML = ''; memberInfoCard.style.display = 'none'; }, 3000);
        }
    } catch (err) {
        showToast('Network error: ' + err.message, 'danger');
        scanMessage.innerHTML = '';
        memberInfoCard.style.display = 'none';
    } finally {
        scanInput.disabled = false;
        scanInput.style.opacity = '1';
        scanInput.focus();
    }
}

// ========== EVENT LISTENERS ==========
scanInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        let barcode = this.value.trim();
        if (barcode) processScan(barcode);
    }
});

// ========== AUTO-REFRESH ==========
setInterval(loadInsideList, 10000);

// ========== INITIAL LOAD ==========
loadInsideList();
scanInput.focus();

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+R to refresh inside list
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        loadInsideList();
        showToast('Refreshed', 'info');
    }
});
</script>

<?php renderFooter(); ?>