<?php
/**
 * Entry/Exit Reports - Unified with Presentation Style
 * Version: 6.0
 * 
 * FEATURES:
 * - Unified PDF generation with presentation-style layout
 * - Full report settings integration (logo, watermark, signature)
 * - Statistics dashboard with cards
 * - Charts for data visualization
 * - Multiple export formats
 * - Advanced filtering
 * - Responsive design
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== CONSTANTS ====================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function formatCurrency($amount, $withSymbol = true) {
    $settings = getSettings();
    $symbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $position = $settings['currency_position'] ?? 'left';
    $decimals = (int)($settings['currency_decimal_places'] ?? 2);
    $formatted = number_format((float)$amount, $decimals);
    if ($withSymbol) {
        return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . ($settings['currency_code'] ?? 'INR');
    }
    return $formatted;
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    if (!defined('BASE_PATH')) {
        define('BASE_PATH', dirname(__DIR__));
    }
    
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

// =============================================================================
// UNIFIED REPORT HEADER
// =============================================================================

function getReportHeaderHtml($title, $subtitle = '', $filters = []) {
    global $reportPrimaryColor;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();
    $generatedDate = date('F j, Y g:i A');

    $logoStyle = 'height: 70px; width: auto; object-fit: contain;';
    $headerStyle = 'display: flex; align-items: center; justify-content: space-between; background: linear-gradient(135deg, ' . $reportPrimaryColor . ' 0%, ' . $reportPrimaryColor . 'dd 100%); color: white; padding: 15px 25px; border-radius: 12px; margin-bottom: 20px;';

    $html = '<div style="' . $headerStyle . '">';
    
    $html .= '<div style="flex: 1; text-align: left;">';
    if ($mainLogo) {
        $html .= '<img src="' . $mainLogo['base64'] . '" style="' . $logoStyle . ' background: white; padding: 5px; border-radius: 8px;">';
    }
    $html .= '</div>';
    
    $html .= '<div style="flex: 2; text-align: center;">';
    $html .= '<h1 style="margin: 0; font-size: 24px; font-weight: 700; letter-spacing: -0.5px; text-shadow: 2px 2px 4px rgba(0,0,0,0.2);">' . htmlspecialchars($institutionName) . '</h1>';
    $html .= '<h2 style="margin: 5px 0 0; font-size: 18px; font-weight: 500; opacity: 0.95;">' . htmlspecialchars($title) . '</h2>';
    if ($subtitle) {
        $html .= '<p style="margin: 3px 0 0; font-size: 13px; opacity: 0.85;">' . htmlspecialchars($subtitle) . '</p>';
    }
    $html .= '</div>';
    
    $html .= '<div style="flex: 1; text-align: right;">';
    if ($rightLogo) {
        $html .= '<img src="' . $rightLogo['base64'] . '" style="' . $logoStyle . ' background: white; padding: 5px; border-radius: 8px;">';
    }
    $html .= '<p style="margin: 5px 0 0; font-size: 11px; opacity: 0.8;">Generated: ' . $generatedDate . '</p>';
    $html .= '</div>';
    
    $html .= '</div>';

    if (!empty($filters)) {
        $html .= '<div style="background: #f8f9fa; border-radius: 8px; padding: 10px 15px; margin-bottom: 15px; border-left: 4px solid ' . $reportPrimaryColor . ';">';
        $html .= '<div style="display: flex; flex-wrap: wrap; gap: 10px; font-size: 12px;">';
        foreach ($filters as $label => $value) {
            if (!empty($value)) {
                $html .= '<span style="background: #e9ecef; padding: 3px 10px; border-radius: 12px;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</span>';
            }
        }
        $html .= '</div></div>';
    }

    return $html;
}

// =============================================================================
// UNIFIED STATS CARDS
// =============================================================================

function getStatsCardsHtml($stats) {
    $html = '<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0 25px;">';
    
    $statItems = [
        ['total_entries' => $stats['total_entries'] ?? 0, 'label' => 'Total Entries', 'icon' => '📥', 'color' => '#28a745'],
        ['total_exits' => $stats['total_exits'] ?? 0, 'label' => 'Total Exits', 'icon' => '📤', 'color' => '#dc3545'],
        ['unique_visitors' => $stats['unique_visitors'] ?? 0, 'label' => 'Unique Visitors', 'icon' => '👤', 'color' => '#17a2b8'],
        ['current_inside' => $stats['current_inside'] ?? 0, 'label' => 'Currently Inside', 'icon' => '🏠', 'color' => '#ffc107']
    ];
    
    foreach ($statItems as $item) {
        $value = $item['total_entries'] ?? $item['total_exits'] ?? $item['unique_visitors'] ?? $item['current_inside'] ?? 0;
        $html .= '<div style="background: white; border-radius: 15px; padding: 20px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.06); border-left: 4px solid ' . $item['color'] . ';">';
        $html .= '<div style="font-size: 28px; margin-bottom: 5px;">' . $item['icon'] . '</div>';
        $html .= '<div style="font-size: 28px; font-weight: 700; color: ' . $item['color'] . ';">' . number_format($value) . '</div>';
        $html .= '<div style="font-size: 13px; color: #6c757d; font-weight: 500;">' . $item['label'] . '</div>';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    return $html;
}

// =============================================================================
// UNIFIED WATERMARK
// =============================================================================

function addWatermarkToHtml($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    
    $style = '
    <style>
        .watermark {
            position: fixed;
            bottom: 50%;
            right: 50%;
            transform: translate(50%, 50%) rotate(-30deg);
            opacity: ' . $opacity . ';
            font-size: 48px;
            font-weight: bold;
            color: #000;
            white-space: nowrap;
            z-index: 1000;
            pointer-events: none;
            text-align: center;
            width: 100%;
            font-family: "DejaVu Sans", Arial, sans-serif;
            letter-spacing: 10px;
            text-transform: uppercase;
        }
        @media print {
            .watermark { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
    </style>
    <div class="watermark">' . htmlspecialchars($watermarkText) . '</div>';
    
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// UNIFIED SIGNATURE
// =============================================================================

function addSignatureToHtml($html) {
    global $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    if (!$reportSignatureEnabled) return $html;
    
    $signature = getReportSignature();
    $signatureHtml = '
    <div style="margin-top: 30px; text-align: right; border-top: 1px solid #ddd; padding-top: 15px;">
        <div style="margin-bottom: 5px;">';
    
    if ($signature) {
        $signatureHtml .= '<img src="' . $signature['base64'] . '" style="max-height: 50px; margin-bottom: 5px;"><br>';
    }
    
    $signatureHtml .= '
            <strong>' . htmlspecialchars($reportSignatureName) . '</strong><br>
            <small style="color: #6c757d;">' . htmlspecialchars($reportSignatureTitle) . '</small>
        </div>
    </div>';
    
    return str_replace('</body>', $signatureHtml . '</body>', $html);
}

// =============================================================================
// UNIFIED FOOTER
// =============================================================================

function getReportFooterHtml() {
    global $reportFooterText;
    $html = '
    <div style="text-align: center; margin-top: 25px; padding-top: 10px; border-top: 1px solid #ddd; font-size: 9px; color: #6c757d;">
        <p style="margin: 0;">' . htmlspecialchars($reportFooterText) . '</p>
        <p style="margin: 3px 0 0;">&copy; ' . date('Y') . ' ' . htmlspecialchars(getInstitutionName()) . '. All rights reserved.</p>
        <p style="margin: 3px 0 0; font-size: 8px; opacity: 0.7;">Generated by Library ERP System</p>
    </div>';
    return $html;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

// =============================================================================
// UNIFIED PDF GENERATION
// =============================================================================

function generateEntryExitPdf($stats, $dailyTrend, $categoryStats, $classStats, $divisionStats, $filters, $range, $from_date, $to_date) {
    global $reportPrimaryColor, $reportFontSize;
    
    $title = 'Entry/Exit Report';
    $periodText = $range === 'custom' ? "$from_date to $to_date" : ucfirst($range);
    
    // Build HTML
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: "DejaVu Sans", Arial, sans-serif; 
                padding: 20px; 
                background: white;
                font-size: ' . $reportFontSize . 'px;
            }
            .page { margin-bottom: 30px; }
            
            /* Stats Cards */
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 15px;
                margin: 20px 0 25px;
            }
            .stat-card {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 18px 15px;
                text-align: center;
                box-shadow: 0 2px 8px rgba(0,0,0,0.04);
                border-left: 4px solid ' . $reportPrimaryColor . ';
            }
            .stat-card .stat-icon { font-size: 24px; margin-bottom: 4px; }
            .stat-card .stat-value {
                font-size: 28px;
                font-weight: 700;
                color: ' . $reportPrimaryColor . ';
            }
            .stat-card .stat-label {
                font-size: 12px;
                color: #6c757d;
                font-weight: 500;
            }
            
            /* Tables */
            .data-table {
                width: 100%;
                border-collapse: collapse;
                margin: 15px 0;
                font-size: 9px;
            }
            .data-table th {
                background: ' . $reportPrimaryColor . ';
                color: white;
                padding: 8px 10px;
                text-align: left;
                font-weight: 600;
            }
            .data-table td {
                padding: 6px 10px;
                border-bottom: 1px solid #e9ecef;
            }
            .data-table tr:hover { background: #f8f9fa; }
            .data-table .text-right { text-align: right; }
            .data-table .text-center { text-align: center; }
            .data-table tfoot td {
                background: #f8f9fa;
                font-weight: bold;
                border-top: 2px solid #dee2e6;
                padding: 8px 10px;
            }
            
            /* Chart containers */
            .chart-container {
                background: white;
                border-radius: 12px;
                padding: 20px;
                margin: 20px 0;
                box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            }
            .chart-container h3 {
                font-size: 14px;
                font-weight: 600;
                margin-bottom: 15px;
                color: ' . $reportPrimaryColor . ';
            }
            .chart-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            .chart-bar {
                background: #e9ecef;
                border-radius: 4px;
                height: 20px;
                margin: 4px 0;
                overflow: hidden;
            }
            .chart-bar-fill {
                height: 100%;
                border-radius: 4px;
                background: linear-gradient(90deg, ' . $reportPrimaryColor . ', ' . $reportPrimaryColor . '99);
                transition: width 0.3s;
                display: flex;
                align-items: center;
                justify-content: flex-end;
                padding-right: 6px;
                color: white;
                font-size: 8px;
                font-weight: 600;
            }
            .chart-label {
                display: flex;
                justify-content: space-between;
                font-size: 10px;
                margin: 2px 0;
            }
            
            .summary-section {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 15px 20px;
                margin: 20px 0;
                border-left: 4px solid ' . $reportPrimaryColor . ';
            }
            .summary-section p {
                margin: 2px 0;
                font-size: 11px;
            }
            
            .footer {
                text-align: center;
                margin-top: 30px;
                padding-top: 15px;
                border-top: 1px solid #ddd;
                font-size: 9px;
                color: #6c757d;
            }
            
            @page {
                margin: 1.5cm;
                @bottom-center {
                    content: "Page " counter(page) " of " counter(pages);
                    font-size: 9px;
                    color: #6c757d;
                }
            }
            @media print {
                .page-break { page-break-after: always; }
                .stat-card { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                .data-table th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                .chart-bar-fill { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            }
        </style>
    </head>
    <body>';
    
    // Header
    $filters['Period'] = $periodText;
    $html .= getReportHeaderHtml($title, 'Visitor Statistics Report', $filters);
    
    // Stats Cards
    $html .= getStatsCardsHtml($stats);
    
    // Summary Section
    $html .= '
    <div class="summary-section">
        <p><strong>📊 Summary:</strong></p>
        <p>• Total Entries: <strong>' . number_format($stats['total_entries']) . '</strong></p>
        <p>• Total Exits: <strong>' . number_format($stats['total_exits']) . '</strong></p>
        <p>• Unique Visitors: <strong>' . number_format($stats['unique_visitors']) . '</strong></p>
        <p>• Currently Inside: <strong>' . number_format($stats['current_inside']) . '</strong></p>
    </div>';
    
    // Daily Trend Table
    $html .= '<h3 style="font-size:14px;margin:15px 0 10px;color:' . $reportPrimaryColor . ';">📈 Daily Trend</h3>';
    $html .= '<table class="data-table">';
    $html .= '<thead><tr><th>Date</th><th class="text-right">Entries</th><th class="text-right">Exits</th></tr></thead><tbody>';
    
    if (!empty($dailyTrend)) {
        foreach ($dailyTrend as $row) {
            $html .= '<tr>
                <td>' . htmlspecialchars($row['entry_date']) . '</td>
                <td class="text-right"><strong>' . $row['entries'] . '</strong></td>
                <td class="text-right">' . $row['exits'] . '</td>
            </tr>';
        }
    } else {
        $html .= '<tr><td colspan="3" style="text-align:center;padding:20px;color:#6c757d;">No data available</td></tr>';
    }
    
    $html .= '</tbody></table>';
    
    // Category Breakdown
    if (!empty($categoryStats)) {
        $html .= '<h3 style="font-size:14px;margin:15px 0 10px;color:' . $reportPrimaryColor . ';">📊 By Category</h3>';
        $html .= '<div class="chart-container"><div class="chart-grid"><div>';
        $maxCat = max(array_column($categoryStats, 'count')) ?: 1;
        foreach ($categoryStats as $cat) {
            $percent = round(($cat['count'] / max(1, $stats['total_entries'])) * 100);
            $html .= '<div class="chart-label"><span>' . htmlspecialchars($cat['member_category']) . '</span><span>' . $cat['count'] . ' (' . $percent . '%)</span></div>';
            $html .= '<div class="chart-bar"><div class="chart-bar-fill" style="width:' . $percent . '%;">' . ($percent > 10 ? $percent . '%' : '') . '</div></div>';
        }
        $html .= '</div></div></div>';
    }
    
    // Class Breakdown
    if (!empty($classStats)) {
        $html .= '<h3 style="font-size:14px;margin:15px 0 10px;color:' . $reportPrimaryColor . ';">📊 By Class/Department</h3>';
        $html .= '<div class="chart-container"><div class="chart-grid"><div>';
        $maxClass = max(array_column($classStats, 'count')) ?: 1;
        foreach ($classStats as $cls) {
            $percent = round(($cls['count'] / max(1, $stats['total_entries'])) * 100);
            $html .= '<div class="chart-label"><span>' . htmlspecialchars($cls['class']) . '</span><span>' . $cls['count'] . ' (' . $percent . '%)</span></div>';
            $html .= '<div class="chart-bar"><div class="chart-bar-fill" style="width:' . $percent . '%; background: #ffc107;">' . ($percent > 10 ? $percent . '%' : '') . '</div></div>';
        }
        $html .= '</div></div></div>';
    }
    
    // Division Breakdown
    if (!empty($divisionStats)) {
        $html .= '<h3 style="font-size:14px;margin:15px 0 10px;color:' . $reportPrimaryColor . ';">📊 By Division/Course</h3>';
        $html .= '<div class="chart-container"><div class="chart-grid"><div>';
        $maxDiv = max(array_column($divisionStats, 'count')) ?: 1;
        foreach ($divisionStats as $div) {
            $percent = round(($div['count'] / max(1, $stats['total_entries'])) * 100);
            $html .= '<div class="chart-label"><span>' . htmlspecialchars($div['division']) . '</span><span>' . $div['count'] . ' (' . $percent . '%)</span></div>';
            $html .= '<div class="chart-bar"><div class="chart-bar-fill" style="width:' . $percent . '%; background: #17a2b8;">' . ($percent > 10 ? $percent . '%' : '') . '</div></div>';
        }
        $html .= '</div></div></div>';
    }
    
    // Footer
    $html .= getReportFooterHtml();
    
    // Add watermark and signature
    $html = addWatermarkToHtml($html);
    $html = addSignatureToHtml($html);
    
    $html .= '</body></html>';
    
    // Clean output buffers
    while (ob_get_level()) ob_end_clean();
    
    // Try to load Composer autoloader
    $autoloadPaths = [
        __DIR__ . '/../vendor/autoload.php',
        __DIR__ . '/../../vendor/autoload.php',
        __DIR__ . '/../../../vendor/autoload.php'
    ];
    
    foreach ($autoloadPaths as $path) {
        if (file_exists($path)) {
            require_once $path;
            break;
        }
    }
    
    // Try mPDF first
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => 'A4',
                'orientation' => 'L',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 20,
                'margin_bottom' => 20,
                'tempDir' => sys_get_temp_dir()
            ]);
            
            $mpdf->SetTitle($title);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library ERP System');
            $mpdf->SetDisplayMode('fullpage');
            
            $mpdf->WriteHTML($html);
            
            $filename = 'entry_exit_report_' . date('Y-m-d') . '.pdf';
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
            
            $mpdf->Output($filename, 'D');
            exit;
            
        } catch (Exception $e) {
            error_log("mPDF error in reports: " . $e->getMessage());
        }
    }
    
    // Try DomPDF as fallback
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', 'A4');
            $options->set('defaultPaperOrientation', 'landscape');
            $options->set('fontDir', sys_get_temp_dir());
            $options->set('fontCache', sys_get_temp_dir());
            $options->set('tempDir', sys_get_temp_dir());
            
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'landscape');
            $dompdf->render();
            
            $filename = 'entry_exit_report_' . date('Y-m-d') . '.pdf';
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
            
            echo $dompdf->output();
            exit;
            
        } catch (Exception $e) {
            error_log("DomPDF error in reports: " . $e->getMessage());
        }
    }
    
    // Ultimate fallback
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>Entry/Exit Report</title>';
    echo '<style>body{font-family:Arial;margin:20px}.no-print{display:block}@media print{.no-print{display:none}}</style>';
    echo '</head><body><div class="no-print" style="text-align:center;margin:20px;">
        <button onclick="window.print()" style="padding:10px 30px;margin:5px;background:#1e3c72;color:white;border:none;border-radius:5px;cursor:pointer;">Print / Save as PDF</button>
        <button onclick="window.history.back()" style="padding:10px 30px;margin:5px;background:#6c757d;color:white;border:none;border-radius:5px;cursor:pointer;">Go Back</button>
    </div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// =============================================================================
// GET FILTER INPUTS
// =============================================================================

$range = $_GET['range'] ?? 'month';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';
$category = $_GET['category'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';

// Build date condition
if ($range === 'today') {
    $dateCond = "e.entry_date = date('now')";
} elseif ($range === 'week') {
    $dateCond = "e.entry_date >= date('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
} elseif ($range === 'year') {
    $dateCond = "e.entry_date >= date('now', '-365 days')";
} elseif ($range === 'custom' && $from_date && $to_date) {
    $dateCond = "e.entry_date BETWEEN '$from_date' AND '$to_date'";
} else {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
}

// Build additional filters
$filterSql = "";
$params = [];
if ($category) {
    $filterSql .= " AND e.member_category = ?";
    $params[] = $category;
}
if ($class) {
    $filterSql .= " AND m.class = ?";
    $params[] = $class;
}
if ($division) {
    $filterSql .= " AND m.division = ?";
    $params[] = $division;
}

// =============================================================================
// STATISTICS
// =============================================================================

$statsSql = "SELECT 
    COUNT(*) as total_entries,
    SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as total_exits,
    COUNT(DISTINCT e.admno) as unique_visitors
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql";
$stmt = $db->prepare($statsSql);
$stmt->execute($params);
$stats = $stmt->fetch();

$totalEntries = $stats['total_entries'] ?? 0;
$totalExits = $stats['total_exits'] ?? 0;
$uniqueVisitors = $stats['unique_visitors'] ?? 0;
$currentInside = $db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'")->fetchColumn();

// Daily trend
$trendSql = "SELECT e.entry_date, 
    COUNT(*) as entries,
    SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as exits
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql
    GROUP BY e.entry_date
    ORDER BY e.entry_date";
$stmt = $db->prepare($trendSql);
$stmt->execute($params);
$dailyTrend = $stmt->fetchAll();

// Category breakdown
$catSql = "SELECT e.member_category, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql
    GROUP BY e.member_category
    ORDER BY count DESC";
$stmt = $db->prepare($catSql);
$stmt->execute($params);
$categoryStats = $stmt->fetchAll();

// Class breakdown
$classSql = "SELECT m.class, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql AND m.class IS NOT NULL AND m.class != ''
    GROUP BY m.class
    ORDER BY count DESC";
$stmt = $db->prepare($classSql);
$stmt->execute($params);
$classStats = $stmt->fetchAll();

// Division breakdown
$divSql = "SELECT m.division, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql AND m.division IS NOT NULL AND m.division != ''
    GROUP BY m.division
    ORDER BY count DESC";
$stmt = $db->prepare($divSql);
$stmt->execute($params);
$divisionStats = $stmt->fetchAll();

// Get distinct values for filters
$allCategories = $db->query("SELECT DISTINCT member_category FROM entry_exit WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
$allClasses = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$allDivisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

// Stats array for PDF
$statsArray = [
    'total_entries' => $totalEntries,
    'total_exits' => $totalExits,
    'unique_visitors' => $uniqueVisitors,
    'current_inside' => $currentInside
];

// Filters array for PDF
$filters = [];
if ($category) $filters['Category'] = $category;
if ($class) $filters['Class/Department'] = $class;
if ($division) $filters['Division/Course'] = $division;

// =============================================================================
// PDF EXPORT HANDLER - UNIFIED
// =============================================================================

if (isset($_GET['export_pdf']) && $_GET['export_pdf'] == 1) {
    generateEntryExitPdf($statsArray, $dailyTrend, $categoryStats, $classStats, $divisionStats, $filters, $range, $from_date, $to_date);
    exit;
}

// =============================================================================
// ON‑SCREEN DISPLAY
// =============================================================================

renderHeader('Entry/Exit Reports');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entry/Exit Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .stat-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 15px;
            border-left: 4px solid var(--bs-primary);
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.12); }
        .stat-card .stat-number { font-size: 2rem; font-weight: 700; }
        .stat-card .stat-label { font-size: 0.85rem; opacity: 0.9; }
        .stat-card-primary { border-left-color: #1e3c72; }
        .stat-card-success { border-left-color: #28a745; }
        .stat-card-info { border-left-color: #17a2b8; }
        .stat-card-warning { border-left-color: #ffc107; }
        .card-header { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; }
        @media print { .no-print { display: none !important; } }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-chart-line"></i> Entry/Exit Statistics</h2>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
            <a href="export_presentation.php?range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-primary" target="_blank"><i class="fas fa-file-powerpoint"></i> Presentation</a>
            <a href="export_excel.php?range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel</a>
            <a href="?export_pdf=1&range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF</a>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4 no-print">
        <div class="card-header">
            <i class="fas fa-filter"></i> Filter Reports
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-2">
                    <label>Period</label>
                    <select name="range" class="form-select" id="rangeSelect">
                        <option value="today" <?= $range === 'today' ? 'selected' : '' ?>>Today</option>
                        <option value="week" <?= $range === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                        <option value="month" <?= $range === 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                        <option value="year" <?= $range === 'year' ? 'selected' : '' ?>>Last 365 Days</option>
                        <option value="custom" <?= $range === 'custom' ? 'selected' : '' ?>>Custom Range</option>
                    </select>
                </div>
                <div id="customRange" style="display: <?= $range === 'custom' ? 'flex' : 'none' ?>;" class="col-md-4 row g-2">
                    <div class="col"><label>From</label><input type="date" name="from_date" class="form-control" value="<?= htmlspecialchars($from_date) ?>"></div>
                    <div class="col"><label>To</label><input type="date" name="to_date" class="form-control" value="<?= htmlspecialchars($to_date) ?>"></div>
                </div>
                <div class="col-md-2">
                    <label>Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php foreach($allCategories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Class/Dept</label>
                    <select name="class" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach($allClasses as $cls): ?>
                            <option value="<?= htmlspecialchars($cls) ?>" <?= $class === $cls ? 'selected' : '' ?>><?= htmlspecialchars($cls) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Div/Course</label>
                    <select name="division" class="form-select">
                        <option value="">All Divisions</option>
                        <?php foreach($allDivisions as $div): ?>
                            <option value="<?= htmlspecialchars($div) ?>" <?= $division === $div ? 'selected' : '' ?>><?= htmlspecialchars($div) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Apply</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="card stat-card stat-card-success text-white bg-success">
                <div class="card-body">
                    <div class="stat-number"><?= number_format($totalEntries) ?></div>
                    <div class="stat-label">Total Entries</div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card stat-card-danger text-white bg-danger">
                <div class="card-body">
                    <div class="stat-number"><?= number_format($totalExits) ?></div>
                    <div class="stat-label">Total Exits</div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card stat-card-info text-white bg-info">
                <div class="card-body">
                    <div class="stat-number"><?= number_format($uniqueVisitors) ?></div>
                    <div class="stat-label">Unique Visitors</div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card stat-card-warning text-white bg-warning">
                <div class="card-body">
                    <div class="stat-number"><?= number_format($currentInside) ?></div>
                    <div class="stat-label">Currently Inside</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Daily Trend (<?= ucfirst($range) ?>)</div>
                <div class="card-body">
                    <canvas id="dailyTrendChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">By Category</div>
                <div class="card-body">
                    <canvas id="categoryChart" style="height: 250px;"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">By Class/Dept</div>
                <div class="card-body">
                    <canvas id="classChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">By Div/Course</div>
                <div class="card-body">
                    <canvas id="divisionChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="text-center text-muted small mt-3 no-print">
        <i class="fas fa-info-circle"></i> Report generated on <?= date('Y-m-d H:i:s') ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Daily trend chart
const dailyData = <?= json_encode($dailyTrend) ?>;
if (dailyData.length) {
    new Chart(document.getElementById('dailyTrendChart'), {
        type: 'line',
        data: {
            labels: dailyData.map(d => d.entry_date),
            datasets: [
                { label: 'Entries', data: dailyData.map(d => d.entries), borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', fill: true, tension: 0.4 },
                { label: 'Exits', data: dailyData.map(d => d.exits), borderColor: '#dc3545', backgroundColor: 'rgba(220,53,69,0.1)', fill: true, tension: 0.4 }
            ]
        },
        options: { responsive: true, maintainAspectRatio: true }
    });
} else {
    document.getElementById('dailyTrendChart').parentElement.innerHTML = '<div class="text-center p-4">No data for selected period</div>';
}

// Category chart
const catData = <?= json_encode($categoryStats) ?>;
if (catData.length) {
    new Chart(document.getElementById('categoryChart'), {
        type: 'pie',
        data: { labels: catData.map(c => c.member_category), datasets: [{ data: catData.map(c => c.count), backgroundColor: ['#1e3c72','#2a5298','#28a745','#ffc107','#dc3545','#17a2b8','#6f42c1'] }] },
        options: { responsive: true }
    });
} else {
    document.getElementById('categoryChart').parentElement.innerHTML = '<div class="text-center p-4">No category data</div>';
}

// Class chart
const classData = <?= json_encode($classStats) ?>;
if (classData.length) {
    new Chart(document.getElementById('classChart'), {
        type: 'bar',
        data: { labels: classData.map(c => c.class), datasets: [{ label: 'Visits', data: classData.map(c => c.count), backgroundColor: '#ffc107' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
} else {
    document.getElementById('classChart').parentElement.innerHTML = '<div class="text-center p-4">No class data</div>';
}

// Division chart
const divData = <?= json_encode($divisionStats) ?>;
if (divData.length) {
    new Chart(document.getElementById('divisionChart'), {
        type: 'bar',
        data: { labels: divData.map(d => d.division), datasets: [{ label: 'Visits', data: divData.map(d => d.count), backgroundColor: '#17a2b8' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
} else {
    document.getElementById('divisionChart').parentElement.innerHTML = '<div class="text-center p-4">No division data</div>';
}

// Toggle custom date range
const rangeSelect = document.getElementById('rangeSelect');
const customDiv = document.getElementById('customRange');
rangeSelect.addEventListener('change', function() {
    customDiv.style.display = this.value === 'custom' ? 'flex' : 'none';
});
</script>

<?php renderFooter(); ?>
</body>
</html>