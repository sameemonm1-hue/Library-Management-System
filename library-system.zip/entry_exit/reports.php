<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false && !isset($_SESSION['integrity_bypass'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unlock_username']) && $_POST['unlock_username'] === 'sameemonm1@gmail.com' && $_POST['unlock_password'] === 'sameer@123') {
        $_SESSION['integrity_bypass'] = true;
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Enter master credentials to restore functionality.</p>
    <form method="post"><div class="mb-3"><label>Username</label><input type="text" name="unlock_username" class="form-control" required></div>
    <div class="mb-3"><label>Password</label><input type="password" name="unlock_password" class="form-control" required></div>
    <button type="submit" class="btn btn-primary w-100">Unlock</button></form></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

// ==================== PDF EXPORT HANDLER ====================
if (isset($_GET['export_pdf']) && $_GET['export_pdf'] == 1) {
    // Get all data for PDF (same filters as main page)
    $range = $_GET['range'] ?? 'month';
    $from_date = $_GET['from_date'] ?? '';
    $to_date = $_GET['to_date'] ?? '';
    $category = $_GET['category'] ?? '';
    $class = $_GET['class'] ?? '';
    $division = $_GET['division'] ?? '';
    
    // Build date condition
    if ($range === 'today') {
        $dateCond = "e.entry_date = date('now')";
    } elseif ($range === 'week') {
        $dateCond = "e.entry_date >= date('now', '-7 days')";
    } elseif ($range === 'month') {
        $dateCond = "e.entry_date >= date('now', '-30 days')";
    } elseif ($range === 'year') {
        $dateCond = "e.entry_date >= date('now', '-365 days')";
    } elseif ($range === 'custom' && $from_date && $to_date) {
        $dateCond = "e.entry_date BETWEEN '$from_date' AND '$to_date'";
    } else {
        $dateCond = "e.entry_date >= date('now', '-30 days')";
    }
    
    $filterSql = "";
    $params = [];
    if ($category) {
        $filterSql .= " AND e.member_category = ?";
        $params[] = $category;
    }
    if ($class) {
        $filterSql .= " AND m.class = ?";
        $params[] = $class;
    }
    if ($division) {
        $filterSql .= " AND m.division = ?";
        $params[] = $division;
    }
    
    // Get data
    $statsSql = "SELECT 
        COUNT(*) as total_entries,
        SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as total_exits,
        COUNT(DISTINCT e.admno) as unique_visitors
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql";
    $stmt = $db->prepare($statsSql);
    $stmt->execute($params);
    $stats = $stmt->fetch();
    
    $trendSql = "SELECT e.entry_date, 
        COUNT(*) as entries,
        SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as exits
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql
        GROUP BY e.entry_date
        ORDER BY e.entry_date";
    $stmt = $db->prepare($trendSql);
    $stmt->execute($params);
    $dailyTrend = $stmt->fetchAll();
    
    $catSql = "SELECT e.member_category, COUNT(*) as count
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql
        GROUP BY e.member_category
        ORDER BY count DESC";
    $stmt = $db->prepare($catSql);
    $stmt->execute($params);
    $categoryStats = $stmt->fetchAll();
    
    $classSql = "SELECT m.class, COUNT(*) as count
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql AND m.class IS NOT NULL AND m.class != ''
        GROUP BY m.class
        ORDER BY count DESC";
    $stmt = $db->prepare($classSql);
    $stmt->execute($params);
    $classStats = $stmt->fetchAll();
    
    $divSql = "SELECT m.division, COUNT(*) as count
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql AND m.division IS NOT NULL AND m.division != ''
        GROUP BY m.division
        ORDER BY count DESC";
    $stmt = $db->prepare($divSql);
    $stmt->execute($params);
    $divisionStats = $stmt->fetchAll();
    
    // Generate HTML for PDF
    $institution = getInstitution();
    $settings = getSettings();
    $title = 'Entry/Exit Report';
    $periodText = $range === 'custom' ? "$from_date to $to_date" : ucfirst($range);
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, sans-serif; margin: 20px; }
            h1, h2, h3 { text-align: center; margin: 10px 0; }
            .header { text-align: center; border-bottom: 2px solid #1e3c72; margin-bottom: 20px; }
            .stats { display: flex; justify-content: space-around; margin: 20px 0; }
            .stat-box { background: #f0f2f5; padding: 10px; border-radius: 8px; text-align: center; width: 22%; }
            .stat-value { font-size: 24px; font-weight: bold; color: #1e3c72; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background: #1e3c72; color: white; }
            .footer { text-align: center; margin-top: 30px; font-size: 10px; color: #777; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>' . htmlspecialchars($institution['name'] ?? 'Library System') . '</h1>
            <h2>' . htmlspecialchars($title) . '</h2>
            <p>Period: ' . htmlspecialchars($periodText) . '</p>
            <p>Generated: ' . date('Y-m-d H:i:s') . '</p>
        </div>
        
        <div class="stats">
            <div class="stat-box"><div class="stat-value">' . number_format($stats['total_entries'] ?? 0) . '</div><div>Total Entries</div></div>
            <div class="stat-box"><div class="stat-value">' . number_format($stats['total_exits'] ?? 0) . '</div><div>Total Exits</div></div>
            <div class="stat-box"><div class="stat-value">' . number_format($stats['unique_visitors'] ?? 0) . '</div><div>Unique Visitors</div></div>
            <div class="stat-box"><div class="stat-value">' . number_format($db->query("SELECT COUNT(*) FROM entry_exit WHERE status='inside'")->fetchColumn()) . '</div><div>Currently Inside</div></div>
        </div>
        
        <h3>Daily Trend</h3>
        <table>
            <thead><tr><th>Date</th><th>Entries</th><th>Exits</th></tr></thead>
            <tbody>';
    foreach ($dailyTrend as $row) {
        $html .= '<tr><td>' . $row['entry_date'] . '</td><td>' . $row['entries'] . '</td><td>' . $row['exits'] . '</td></tr>';
    }
    $html .= '</tbody></table>';
    
    if (!empty($categoryStats)) {
        $html .= '<h3>By Category</h3><table><thead><tr><th>Category</th><th>Visits</th></tr></thead><tbody>';
        foreach ($categoryStats as $cat) {
            $html .= '<tr><td>' . htmlspecialchars($cat['member_category']) . '</td><td>' . $cat['count'] . '</td></tr>';
        }
        $html .= '</tbody></table>';
    }
    
    if (!empty($classStats)) {
        $html .= '<h3>By Class/Dept</h3><table><thead><tr><th>Class/Dept</th><th>Visits</th></tr></thead><tbody>';
        foreach ($classStats as $cls) {
            $html .= '<tr><td>' . htmlspecialchars($cls['class']) . '</td><td>' . $cls['count'] . '</td></tr>';
        }
        $html .= '</tbody></table>';
    }
    
    if (!empty($divisionStats)) {
        $html .= '<h3>By Div/Course</h3><table><thead></td><th>Div/Course</th><th>Visits</th></tr></thead><tbody>';
        foreach ($divisionStats as $div) {
            $html .= '<tr><td>' . htmlspecialchars($div['division']) . '</td><td>' . $div['count'] . '</td></tr>';
        }
        $html .= '</tbody><table>';
    }
    
    $html .= '<div class="footer"><p>&copy; ' . date('Y') . ' ' . htmlspecialchars($institution['name'] ?? 'Library System') . '. All rights reserved.</p><p>Designed by Sameermon</p></div>';
    $html .= '</body></html>';
    
    // Check if Dompdf is available
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (!file_exists($autoloadPath)) {
        die('<div style="color:red; padding:20px;"><h2>Dompdf not installed</h2><p>Run <code>composer require dompdf/dompdf</code> to enable PDF export.</p><a href="javascript:history.back()">Go back</a></div>');
    }
    require_once $autoloadPath;
    $options = new \Dompdf\Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', true);
    $dompdf = new \Dompdf\Dompdf($options);
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'landscape');
    $dompdf->render();
    $filename = 'entry_exit_report_' . date('Y-m-d') . '.pdf';
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $dompdf->stream($filename, ['Attachment' => true]);
    exit;
}

// Get filter inputs
$range = $_GET['range'] ?? 'month';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';
$category = $_GET['category'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';

// Build date condition
if ($range === 'today') {
    $dateCond = "e.entry_date = date('now')";
} elseif ($range === 'week') {
    $dateCond = "e.entry_date >= date('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
} elseif ($range === 'year') {
    $dateCond = "e.entry_date >= date('now', '-365 days')";
} elseif ($range === 'custom' && $from_date && $to_date) {
    $dateCond = "e.entry_date BETWEEN '$from_date' AND '$to_date'";
} else {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
}

// Build additional filters (using members table for class/division)
$filterSql = "";
$params = [];
if ($category) {
    $filterSql .= " AND e.member_category = ?";
    $params[] = $category;
}
if ($class) {
    $filterSql .= " AND m.class = ?";
    $params[] = $class;
}
if ($division) {
    $filterSql .= " AND m.division = ?";
    $params[] = $division;
}

// Statistics
$statsSql = "SELECT 
    COUNT(*) as total_entries,
    SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as total_exits,
    COUNT(DISTINCT e.admno) as unique_visitors
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql";
$stmt = $db->prepare($statsSql);
$stmt->execute($params);
$stats = $stmt->fetch();

$totalEntries = $stats['total_entries'] ?? 0;
$totalExits = $stats['total_exits'] ?? 0;
$uniqueVisitors = $stats['unique_visitors'] ?? 0;
$currentInside = $db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'")->fetchColumn();

// Daily trend (last 30 days or custom range)
$trendSql = "SELECT e.entry_date, 
    COUNT(*) as entries,
    SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as exits
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql
    GROUP BY e.entry_date
    ORDER BY e.entry_date";
$stmt = $db->prepare($trendSql);
$stmt->execute($params);
$dailyTrend = $stmt->fetchAll();

// Category breakdown
$catSql = "SELECT e.member_category, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql
    GROUP BY e.member_category
    ORDER BY count DESC";
$stmt = $db->prepare($catSql);
$stmt->execute($params);
$categoryStats = $stmt->fetchAll();

// Class breakdown
$classSql = "SELECT m.class, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql AND m.class IS NOT NULL AND m.class != ''
    GROUP BY m.class
    ORDER BY count DESC";
$stmt = $db->prepare($classSql);
$stmt->execute($params);
$classStats = $stmt->fetchAll();

// Division breakdown
$divSql = "SELECT m.division, COUNT(*) as count
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql AND m.division IS NOT NULL AND m.division != ''
    GROUP BY m.division
    ORDER BY count DESC";
$stmt = $db->prepare($divSql);
$stmt->execute($params);
$divisionStats = $stmt->fetchAll();

// Get distinct categories, classes, divisions for filter dropdowns
$allCategories = $db->query("SELECT DISTINCT member_category FROM entry_exit WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
$allClasses = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$allDivisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

renderHeader('Entry/Exit Reports');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-chart-line"></i> Entry/Exit Statistics</h2>
        <div>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
            <a href="export_presentation.php?range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-primary" target="_blank"><i class="fas fa-file-powerpoint"></i> Presentation</a>
            <a href="export_excel.php?range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel</a>
            <a href="?export_pdf=1&range=<?= urlencode($range) ?>&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF</a>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Filter Reports</div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-2">
                    <label>Period</label>
                    <select name="range" class="form-select" id="rangeSelect">
                        <option value="today" <?= $range === 'today' ? 'selected' : '' ?>>Today</option>
                        <option value="week" <?= $range === 'week' ? 'selected' : '' ?>>Last 7 Days</option>
                        <option value="month" <?= $range === 'month' ? 'selected' : '' ?>>Last 30 Days</option>
                        <option value="year" <?= $range === 'year' ? 'selected' : '' ?>>Last 365 Days</option>
                        <option value="custom" <?= $range === 'custom' ? 'selected' : '' ?>>Custom Range</option>
                    </select>
                </div>
                <div id="customRange" style="display: <?= $range === 'custom' ? 'flex' : 'none' ?>;" class="col-md-4 row g-2">
                    <div class="col"><label>From</label><input type="date" name="from_date" class="form-control" value="<?= htmlspecialchars($from_date) ?>"></div>
                    <div class="col"><label>To</label><input type="date" name="to_date" class="form-control" value="<?= htmlspecialchars($to_date) ?>"></div>
                </div>
                <div class="col-md-2">
                    <label>Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php foreach($allCategories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Class/Dept</label>
                    <select name="class" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach($allClasses as $cls): ?>
                            <option value="<?= htmlspecialchars($cls) ?>" <?= $class === $cls ? 'selected' : '' ?>><?= htmlspecialchars($cls) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label>Div/Course</label>
                    <select name="division" class="form-select">
                        <option value="">All Divisions</option>
                        <?php foreach($allDivisions as $div): ?>
                            <option value="<?= htmlspecialchars($div) ?>" <?= $division === $div ? 'selected' : '' ?>><?= htmlspecialchars($div) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3"><div class="card text-center bg-primary text-white"><div class="card-body"><h3><?= number_format($totalEntries) ?></h3><p>Total Entries</p></div></div></div>
        <div class="col-md-3"><div class="card text-center bg-success text-white"><div class="card-body"><h3><?= number_format($totalExits) ?></h3><p>Total Exits</p></div></div></div>
        <div class="col-md-3"><div class="card text-center bg-info text-white"><div class="card-body"><h3><?= number_format($uniqueVisitors) ?></h3><p>Unique Visitors</p></div></div></div>
        <div class="col-md-3"><div class="card text-center bg-warning text-white"><div class="card-body"><h3><?= number_format($currentInside) ?></h3><p>Currently Inside</p></div></div></div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Daily Trend (<?= ucfirst($range) ?>)</div>
                <div class="card-body">
                    <canvas id="dailyTrendChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">By Category</div>
                <div class="card-body">
                    <canvas id="categoryChart" style="height: 250px;"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">By Class/Dept</div>
                <div class="card-body">
                    <canvas id="classChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">By Div/Course</div>
                <div class="card-body">
                    <canvas id="divisionChart" style="height: 300px;"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Daily trend chart
const dailyData = <?= json_encode($dailyTrend) ?>;
if (dailyData.length) {
    new Chart(document.getElementById('dailyTrendChart'), {
        type: 'line',
        data: {
            labels: dailyData.map(d => d.entry_date),
            datasets: [
                { label: 'Entries', data: dailyData.map(d => d.entries), borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', fill: true, tension: 0.4 },
                { label: 'Exits', data: dailyData.map(d => d.exits), borderColor: '#dc3545', backgroundColor: 'rgba(220,53,69,0.1)', fill: true, tension: 0.4 }
            ]
        },
        options: { responsive: true, maintainAspectRatio: true }
    });
} else {
    document.getElementById('dailyTrendChart').parentElement.innerHTML = '<div class="text-center p-4">No data for selected period</div>';
}

// Category chart
const catData = <?= json_encode($categoryStats) ?>;
if (catData.length) {
    new Chart(document.getElementById('categoryChart'), {
        type: 'pie',
        data: { labels: catData.map(c => c.member_category), datasets: [{ data: catData.map(c => c.count), backgroundColor: ['#1e3c72','#2a5298','#28a745','#ffc107','#dc3545','#17a2b8','#6f42c1'] }] },
        options: { responsive: true }
    });
} else {
    document.getElementById('categoryChart').parentElement.innerHTML = '<div class="text-center p-4">No category data</div>';
}

// Class chart
const classData = <?= json_encode($classStats) ?>;
if (classData.length) {
    new Chart(document.getElementById('classChart'), {
        type: 'bar',
        data: { labels: classData.map(c => c.class), datasets: [{ label: 'Visits', data: classData.map(c => c.count), backgroundColor: '#ffc107' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
} else {
    document.getElementById('classChart').parentElement.innerHTML = '<div class="text-center p-4">No class data</div>';
}

// Division chart
const divData = <?= json_encode($divisionStats) ?>;
if (divData.length) {
    new Chart(document.getElementById('divisionChart'), {
        type: 'bar',
        data: { labels: divData.map(d => d.division), datasets: [{ label: 'Visits', data: divData.map(d => d.count), backgroundColor: '#17a2b8' }] },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
} else {
    document.getElementById('divisionChart').parentElement.innerHTML = '<div class="text-center p-4">No division data</div>';
}

// Toggle custom date range
const rangeSelect = document.getElementById('rangeSelect');
const customDiv = document.getElementById('customRange');
rangeSelect.addEventListener('change', function() {
    customDiv.style.display = this.value === 'custom' ? 'flex' : 'none';
});
</script>

<?php renderFooter(); ?>