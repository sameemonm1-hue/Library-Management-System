<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

$stmt = $db->query("SELECT strftime('%H', entry_time) as hour, COUNT(*) as count 
    FROM entry_exit WHERE entry_date = date('now') 
    GROUP BY hour ORDER BY hour");
$data = $stmt->fetchAll();

header('Content-Type: application/json');
echo json_encode($data);
?>