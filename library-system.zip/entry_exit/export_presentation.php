<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$institution = getInstitution();
$settings = getSettings();

// Get filters
$range = $_GET['range'] ?? 'month';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';
$category = $_GET['category'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';

// Build date condition
if ($range === 'today') {
    $dateCond = "e.entry_date = date('now')";
} elseif ($range === 'week') {
    $dateCond = "e.entry_date >= date('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
} elseif ($range === 'year') {
    $dateCond = "e.entry_date >= date('now', '-365 days')";
} elseif ($range === 'custom' && $from_date && $to_date) {
    $dateCond = "e.entry_date BETWEEN '$from_date' AND '$to_date'";
} else {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
}

$filterSql = "";
$params = [];
if ($category) {
    $filterSql .= " AND e.member_category = ?";
    $params[] = $category;
}
if ($class) {
    $filterSql .= " AND m.class = ?";
    $params[] = $class;
}
if ($division) {
    $filterSql .= " AND m.division = ?";
    $params[] = $division;
}

// Statistics
$statsSql = "SELECT 
    COUNT(*) as total_entries,
    SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as total_exits,
    COUNT(DISTINCT e.admno) as unique_visitors
    FROM entry_exit e
    LEFT JOIN members m ON e.admno = m.admno
    WHERE $dateCond $filterSql";
$stmt = $db->prepare($statsSql);
$stmt->execute($params);
$stats = $stmt->fetch();

$totalEntries = $stats['total_entries'] ?? 0;
$totalExits = $stats['total_exits'] ?? 0;
$uniqueVisitors = $stats['unique_visitors'] ?? 0;
$peakDay = $db->query("SELECT entry_date, COUNT(*) as visits FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql GROUP BY entry_date ORDER BY visits DESC LIMIT 1")->fetch();
$peakDayVisits = $peakDay ? $peakDay['visits'] : 0;

// Daily trend
$trendSql = "SELECT e.entry_date, COUNT(*) as entries, SUM(CASE WHEN e.exit_time IS NOT NULL THEN 1 ELSE 0 END) as exits
    FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql GROUP BY e.entry_date ORDER BY e.entry_date";
$stmt = $db->prepare($trendSql);
$stmt->execute($params);
$dailyTrend = $stmt->fetchAll();

// Category breakdown
$catSql = "SELECT e.member_category, COUNT(*) as count FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql GROUP BY e.member_category";
$stmt = $db->prepare($catSql);
$stmt->execute($params);
$categoryStats = $stmt->fetchAll();

// Class breakdown
$classSql = "SELECT m.class, COUNT(*) as count FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql AND m.class IS NOT NULL GROUP BY m.class";
$stmt = $db->prepare($classSql);
$stmt->execute($params);
$classStats = $stmt->fetchAll();

// Division breakdown
$divSql = "SELECT m.division, COUNT(*) as count FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql AND m.division IS NOT NULL GROUP BY m.division";
$stmt = $db->prepare($divSql);
$stmt->execute($params);
$divisionStats = $stmt->fetchAll();

// Top visitors
$topSql = "SELECT e.admno, e.member_name, e.member_category, COUNT(*) as visits
    FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE $dateCond $filterSql
    GROUP BY e.admno ORDER BY visits DESC LIMIT 10";
$stmt = $db->prepare($topSql);
$stmt->execute($params);
$topVisitors = $stmt->fetchAll();

// ------------------------------------------------------------
// Generate the full HTML report with header on each slide
// ------------------------------------------------------------
$institutionName = htmlspecialchars($institution['name'] ?? 'Library System');
$logoHtml = '';
if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
    $logoHtml = '<img src="' . getWebImageUrl($institution['logo_path']) . '" style="height: 50px; margin-right: 15px;">';
}
$reportTitle = 'Library Visitor Report';
$periodText = $range === 'custom' ? "$from_date to $to_date" : ucfirst($range);
$generatedDate = date('F j, Y g:i A');

// Helper to output a slide header (reused on every slide)
function slideHeader($logoHtml, $institutionName, $reportTitle, $periodText, $generatedDate) {
    return <<<HTML
    <div class="slide-header" style="display: flex; align-items: center; justify-content: space-between; background: linear-gradient(135deg, #1e3c72, #2a5298); color: white; padding: 15px 20px; border-radius: 12px; margin-bottom: 20px;">
        <div style="display: flex; align-items: center;">
            {$logoHtml}
            <div>
                <h2 style="margin: 0;">{$institutionName}</h2>
                <p style="margin: 0; opacity: 0.9;">{$reportTitle}</p>
            </div>
        </div>
        <div style="text-align: right;">
            <p style="margin: 0;"><strong>Period:</strong> {$periodText}</p>
            <p style="margin: 0; font-size: 0.9em;">Generated: {$generatedDate}</p>
        </div>
    </div>
HTML;
}

$commonHeader = slideHeader($logoHtml, $institutionName, $reportTitle, $periodText, $generatedDate);

// Build the full HTML document
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $reportTitle ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', 'DejaVu Sans', sans-serif;
            padding: 20px;
            background: white;
        }
        .slide {
            margin-bottom: 40px;
            page-break-after: always;
            break-inside: avoid;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 25px 0;
        }
        .stat-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .stat-value {
            font-size: 32px;
            font-weight: bold;
            color: #1e3c72;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .data-table th, .data-table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        .data-table th {
            background: #1e3c72;
            color: white;
        }
        .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #6c757d;
            margin-top: 30px;
        }
        canvas { max-width: 100%; height: auto; margin: 20px 0; }
        
        @media print {
            body { padding: 0; margin: 0; }
            .slide-header {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                position: running(header);
            }
            @page {
                margin: 2cm;
                @top-center {
                    content: element(header);
                }
            }
            .slide {
                page-break-after: always;
                margin-top: 1.5cm;
            }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- Title Slide -->
<div class="slide">
    <?= $commonHeader ?>
    <div class="stats-grid">
        <div class="stat-card"><div class="stat-value"><?= number_format($totalEntries) ?></div><div>Total Entries</div></div>
        <div class="stat-card"><div class="stat-value"><?= number_format($totalExits) ?></div><div>Total Exits</div></div>
        <div class="stat-card"><div class="stat-value"><?= number_format($uniqueVisitors) ?></div><div>Unique Visitors</div></div>
        <div class="stat-card"><div class="stat-value"><?= number_format($peakDayVisits) ?></div><div>Peak Day Visits</div></div>
    </div>
</div>

<!-- Daily Trend -->
<div class="slide">
    <?= $commonHeader ?>
    <h2>Daily Trend</h2>
    <canvas id="dailyChart" style="height: 400px;"></canvas>
</div>

<!-- Category & Class -->
<div class="slide">
    <?= $commonHeader ?>
    <div style="display: flex; gap: 20px; flex-wrap: wrap;">
        <div style="flex:1; min-width: 250px;">
            <h2>By Category</h2>
            <canvas id="categoryChart" style="height: 300px;"></canvas>
        </div>
        <div style="flex:1; min-width: 250px;">
            <h2>By Class/Dept</h2>
            <canvas id="classChart" style="height: 300px;"></canvas>
        </div>
    </div>
</div>

<!-- Division -->
<div class="slide">
    <?= $commonHeader ?>
    <h2>By Div/Course</h2>
    <canvas id="divisionChart" style="height: 300px;"></canvas>
</div>

<!-- Top Visitors -->
<div class="slide">
    <?= $commonHeader ?>
    <h2>Top 10 Frequent Visitors</h2>
    <table class="data-table">
        <thead><tr><th>Rank</th><th>AdmNo</th><th>Name</th><th>Category</th><th>Visits</th></tr></thead>
        <tbody>
            <?php foreach($topVisitors as $idx => $v): ?>
            <tr>
                <td><?= $idx+1 ?></td>
                <td><?= htmlspecialchars($v['admno']) ?></td>
                <td><?= htmlspecialchars($v['member_name']) ?></td>
                <td><?= htmlspecialchars($v['member_category']) ?></td>
                <td><?= $v['visits'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="footer">
    <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. All rights reserved.</p>
    <p>Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank">Sameermon</a></p>
</div>

<script>
// Daily trend
new Chart(document.getElementById('dailyChart'), {
    type: 'line',
    data: { labels: <?= json_encode(array_column($dailyTrend, 'entry_date')) ?>, datasets: [
        { label: 'Entries', data: <?= json_encode(array_column($dailyTrend, 'entries')) ?>, borderColor: '#28a745', fill: true },
        { label: 'Exits', data: <?= json_encode(array_column($dailyTrend, 'exits')) ?>, borderColor: '#dc3545', fill: true }
    ] },
    options: { responsive: true }
});
// Category pie
new Chart(document.getElementById('categoryChart'), {
    type: 'pie',
    data: { labels: <?= json_encode(array_column($categoryStats, 'member_category')) ?>, datasets: [{ data: <?= json_encode(array_column($categoryStats, 'count')) ?>, backgroundColor: ['#1e3c72','#2a5298','#28a745','#ffc107','#dc3545'] }] }
});
// Class bar
new Chart(document.getElementById('classChart'), {
    type: 'bar',
    data: { labels: <?= json_encode(array_column($classStats, 'class')) ?>, datasets: [{ label: 'Visits', data: <?= json_encode(array_column($classStats, 'count')) ?>, backgroundColor: '#ffc107' }] }
});
// Division bar
new Chart(document.getElementById('divisionChart'), {
    type: 'bar',
    data: { labels: <?= json_encode(array_column($divisionStats, 'division')) ?>, datasets: [{ label: 'Visits', data: <?= json_encode(array_column($divisionStats, 'count')) ?>, backgroundColor: '#17a2b8' }] }
});
</script>
</body>
</html>