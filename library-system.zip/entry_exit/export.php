<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$institution = getInstitution();

// Get all parameters from the original request
$params = $_GET;

// Instead of redirecting, we capture the HTML report from export_presentation.php
// We'll modify export_presentation.php to return pure HTML when ?raw=1 is set.
// This avoids output buffering conflicts.
$query = http_build_query($params);
$reportUrl = "export_presentation.php?$query&raw=1";  // raw=1 returns HTML without any layout wrapper

// Fetch the report HTML (using cURL or file_get_contents with appropriate context)
$reportHtml = fetchReportHtml($reportUrl);

if (!$reportHtml) {
    die("Error: Could not generate report content.");
}

// Add the common report header (can also be done inside export_presentation.php)
// But to guarantee header appears on ALL exports, we inject it here.
$headerHtml = getReportHeader($institution, $params);
$fullHtml = $headerHtml . $reportHtml;

// Generate PDF using Dompdf
require_once __DIR__ . '/../vendor/autoload.php';  // adjust path to your autoload
use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);  // if you have images or CSS from external URLs
$dompdf = new Dompdf($options);

$dompdf->loadHtml($fullHtml);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Send PDF as download
$filename = 'report_' . date('Y-m-d') . '.pdf';
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
$dompdf->stream($filename, ['Attachment' => true]);
exit;

// ------------------------------------------------------------------
// Helper functions (place these inside export.php or a separate helper file)
// ------------------------------------------------------------------

/**
 * Fetch HTML from a local URL (e.g., export_presentation.php?raw=1)
 */
function fetchReportHtml($url)
{
    // Build full URL (assuming same host)
    $fullUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://')
               . $_SERVER['HTTP_HOST']
               . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/')
               . '/' . ltrim($url, '/');

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $fullUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIE, session_name() . '=' . session_id()); // pass session
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        error_log("Failed to fetch report HTML from $fullUrl (HTTP $httpCode)");
        return false;
    }
    return $html;
}

/**
 * Generate the common report header with institution info, title, date, etc.
 */
function getReportHeader($institution, $params)
{
    $reportTitle = isset($params['report_type']) ? htmlspecialchars($params['report_type']) : 'Student Report';
    $currentDate = date('Y-m-d H:i:s');
    $institutionName = htmlspecialchars($institution['name'] ?? 'Institution Name');
    $logo = !empty($institution['logo']) ? '<img src="' . htmlspecialchars($institution['logo']) . '" alt="Logo" style="height:60px;">' : '';

    return <<<HTML
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>$reportTitle</title>
        <style>
            body { font-family: DejaVu Sans, sans-serif; margin: 20px; }
            .report-header {
                text-align: center;
                border-bottom: 2px solid #333;
                margin-bottom: 20px;
                padding-bottom: 10px;
            }
            .report-header h1 { margin: 5px 0; }
            .report-header p { margin: 3px 0; color: #555; }
            .report-header .logo { margin-bottom: 10px; }
        </style>
    </head>
    <body>
        <div class="report-header">
            <div class="logo">$logo</div>
            <h1>$institutionName</h1>
            <h2>$reportTitle</h2>
            <p>Generated on: $currentDate</p>
        </div>
    HTML;
}
?>