<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();

$range = $_GET['range'] ?? 'month';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';
$category = $_GET['category'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';

// Build date condition
if ($range === 'today') {
    $dateCond = "e.entry_date = date('now')";
} elseif ($range === 'week') {
    $dateCond = "e.entry_date >= date('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
} elseif ($range === 'year') {
    $dateCond = "e.entry_date >= date('now', '-365 days')";
} elseif ($range === 'custom' && $from_date && $to_date) {
    $dateCond = "e.entry_date BETWEEN '$from_date' AND '$to_date'";
} else {
    $dateCond = "e.entry_date >= date('now', '-30 days')";
}

$filterSql = "";
$params = [];
if ($category) {
    $filterSql .= " AND e.member_category = ?";
    $params[] = $category;
}
if ($class) {
    $filterSql .= " AND m.class = ?";
    $params[] = $class;
}
if ($division) {
    $filterSql .= " AND m.division = ?";
    $params[] = $division;
}

$sql = "SELECT e.entry_date, e.entry_time, e.exit_time, e.admno, e.member_name, e.member_category, e.purpose,
            m.class, m.division
        FROM entry_exit e
        LEFT JOIN members m ON e.admno = m.admno
        WHERE $dateCond $filterSql
        ORDER BY e.entry_date DESC, e.entry_time DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="entry_exit_report_' . date('Y-m-d') . '.csv"');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

$output = fopen('php://output', 'w');
fputcsv($output, ['Date', 'Entry Time', 'Exit Time', 'Adm No', 'Member Name', 'Category', 'Purpose', 'Class/Dept', 'Div/Course']);
foreach ($rows as $r) {
    fputcsv($output, [
        $r['entry_date'],
        $r['entry_time'],
        $r['exit_time'] ?? '',
        $r['admno'],
        $r['member_name'],
        $r['member_category'],
        $r['purpose'],
        $r['class'] ?? '',
        $r['division'] ?? ''
    ]);
}
fclose($output);
exit;
?>