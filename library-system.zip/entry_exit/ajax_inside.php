<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
header('Content-Type: application/json');

$inside = $db->query("
    SELECT admno, member_name, member_category, entry_date, entry_time, purpose, status
    FROM entry_exit 
    WHERE status = 'inside' 
    ORDER BY entry_time DESC
")->fetchAll();

$now = new DateTime();
foreach ($inside as &$row) {
    $entryTime = new DateTime($row['entry_date'] . ' ' . $row['entry_time']);
    $diff = $entryTime->diff($now);
    $duration = '';
    if ($diff->h > 0) $duration .= $diff->h . 'h ';
    if ($diff->i > 0) $duration .= $diff->i . 'm';
    if ($duration == '') $duration = $diff->s . 's';
    $row['duration'] = $duration;
}
echo json_encode($inside);
?>