<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$admno = $_GET['admno'] ?? '';

header('Content-Type: application/json');

if ($admno) {
    // Check if there is an active entry for this barcode
    $insideStmt = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
    $insideStmt->execute([$admno]);
    $is_inside = $insideStmt->fetch() ? true : false;
    
    // Get member details if exists
    $memberStmt = $db->prepare("SELECT name, member_category, photo_path FROM members WHERE admno = ? AND status = 'active'");
    $memberStmt->execute([$admno]);
    $member = $memberStmt->fetch();
    
    $response = [
        'is_inside' => $is_inside
    ];
    
    if ($member) {
        $response['found'] = true;
        $response['name'] = $member['name'];
        $response['member_category'] = $member['member_category'];
        $response['admno'] = $admno;
        if ($member['photo_path'] && file_exists($member['photo_path'])) {
            $response['photo_base64'] = 'data:image/' . pathinfo($member['photo_path'], PATHINFO_EXTENSION) . ';base64,' . base64_encode(file_get_contents($member['photo_path']));
        }
    } else {
        $response['found'] = false;
        $response['name'] = 'Guest: ' . $admno;
        $response['member_category'] = 'Guest';
        $response['admno'] = $admno;
    }
    
    echo json_encode($response);
} else {
    echo json_encode(['error' => 'No admno provided']);
}
?>