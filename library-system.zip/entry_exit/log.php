<?php

/**
 * Entry/Exit Log Viewer & Exporter
 * 
 * Features:
 * - Date range, Adm No, Category, Class/Dept, Division filters
 * - Pagination with configurable rows per page (10-500)
 * - CSV export (UTF-8 BOM for Excel)
 * - PDF export via mPDF (now fixed)
 * - CSRF protection for exports
 * - Fully compatible with existing db.php and functions.php
 */

declare(strict_types=1);

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Load Composer autoloader for mPDF
$composerAutoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
}

// ----------------------------------------------------------------------
// Ensure required core functions exist (fallbacks)
// ----------------------------------------------------------------------
if (!function_exists('renderHeader')) {
    function renderHeader($title) {
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>' . htmlspecialchars($title) . '</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"></head><body>';
    }
}
if (!function_exists('renderFooter')) {
    function renderFooter() {
        echo '</body></html>';
    }
}
if (!function_exists('formatDate')) {
    function formatDate($date) {
        return date('d-m-Y', strtotime($date));
    }
}
if (!function_exists('getWebImageUrl')) {
    function getWebImageUrl($path) {
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $baseUrl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $relative = ltrim($path, '/');
        return $baseUrl . '/' . $relative;
    }
}
if (!function_exists('getInstitution')) {
    function getInstitution() {
        global $db;
        $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) return ['name' => 'Library System', 'logo_path' => ''];
        return ['name' => $row['software_header'] ?? 'Library System', 'logo_path' => $row['library_logo'] ?? ''];
    }
}
if (!function_exists('getSettings')) {
    function getSettings() {
        return getInstitution();
    }
}

// Ensure user is authenticated
requireLogin();
$db = getDB();
$institution = getInstitution();
$settings = getSettings();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ----------------------------------------------------------------------
// Input sanitization and defaults
// ----------------------------------------------------------------------
$from = $_GET['from'] ?? date('Y-m-d', strtotime('-7 days'));
$to = $_GET['to'] ?? date('Y-m-d');
$admno = trim($_GET['admno'] ?? '');
$category = $_GET['category'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = (int)($_GET['per_page'] ?? 50);
$validPerPage = [10, 25, 50, 100, 200, 500];
if (!in_array($perPage, $validPerPage, true)) {
    $perPage = 50;
}

// Validate date range
function validateDate(string $date, string $default): string {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return ($d && $d->format('Y-m-d') === $date) ? $date : $default;
}
$from = validateDate($from, date('Y-m-d', strtotime('-30 days')));
$to = validateDate($to, date('Y-m-d'));
if ($from > $to) {
    [$from, $to] = [$to, $from];
}

// ----------------------------------------------------------------------
// Helper functions (query builder)
// ----------------------------------------------------------------------
function buildFilterConditions(string $from, string $to, string $admno, string $category, string $class, string $division): array {
    $conditions = ["e.entry_date BETWEEN :from AND :to"];
    $params = [':from' => $from, ':to' => $to];
    if ($admno !== '') {
        $conditions[] = "e.admno LIKE :admno";
        $params[':admno'] = "%$admno%";
    }
    if ($category !== '' && $category !== 'all') {
        $conditions[] = "e.member_category = :category";
        $params[':category'] = $category;
    }
    if ($class !== '') {
        $conditions[] = "m.class = :class";
        $params[':class'] = $class;
    }
    if ($division !== '') {
        $conditions[] = "m.division = :division";
        $params[':division'] = $division;
    }
    return ['whereSql' => ' WHERE ' . implode(' AND ', $conditions), 'params' => $params];
}

function getTotalLogCount(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division): int {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $sql = "SELECT COUNT(*) FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno" . $filter['whereSql'];
    $stmt = $db->prepare($sql);
    $stmt->execute($filter['params']);
    return (int)$stmt->fetchColumn();
}

function fetchLogsPaginated(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division, int $page, int $perPage): array {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $offset = ($page - 1) * $perPage;
    $sql = "SELECT e.*, m.class, m.division 
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno" 
            . $filter['whereSql'] . 
            " ORDER BY e.entry_date DESC, e.entry_time DESC 
            LIMIT :limit OFFSET :offset";
    $stmt = $db->prepare($sql);
    foreach ($filter['params'] as $key => $val) {
        $stmt->bindValue($key, $val);
    }
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function fetchAllLogsForExport(PDO $db, string $from, string $to, string $admno, string $category, string $class, string $division): array {
    $filter = buildFilterConditions($from, $to, $admno, $category, $class, $division);
    $sql = "SELECT e.*, m.class, m.division 
            FROM entry_exit e
            LEFT JOIN members m ON e.admno = m.admno" 
            . $filter['whereSql'] . 
            " ORDER BY e.entry_date DESC, e.entry_time DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($filter['params']);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function formatDurationHtml(?string $entryDate, string $entryTime, ?string $exitTime): string {
    if (!$exitTime) return '<span class="badge bg-success">Inside</span>';
    try {
        $entry = new DateTime($entryDate . ' ' . $entryTime);
        $exit = new DateTime($entryDate . ' ' . $exitTime);
        $diff = $entry->diff($exit);
        return $diff->format('%h hr %i min');
    } catch (Exception $e) {
        return 'Invalid';
    }
}

function formatDurationText(?string $entryDate, string $entryTime, ?string $exitTime): string {
    if (!$exitTime) return 'Inside';
    try {
        $entry = new DateTime($entryDate . ' ' . $entryTime);
        $exit = new DateTime($entryDate . ' ' . $exitTime);
        $diff = $entry->diff($exit);
        return $diff->format('%h hr %i min');
    } catch (Exception $e) {
        return 'Invalid';
    }
}

// ----------------------------------------------------------------------
// Handle exports (CSV and PDF)
// ----------------------------------------------------------------------
$exportType = $_GET['export'] ?? '';
if ($exportType === 'csv' || $exportType === 'pdf') {
    $token = $_GET['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        die('<div style="color: red; padding: 20px;"><h2>Security Error</h2><p>Invalid CSRF token.</p><a href="?">Go back</a></div>');
    }
    
    $logs = fetchAllLogsForExport($db, $from, $to, $admno, $category, $class, $division);
    
    if ($exportType === 'csv') {
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="entry_exit_log_' . date('Y-m-d') . '.csv"');
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // UTF-8 BOM
        fputcsv($output, ['Date', 'Entry Time', 'Exit Time', 'Adm No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Purpose', 'Duration']);
        foreach ($logs as $log) {
            $duration = formatDurationText($log['entry_date'], $log['entry_time'], $log['exit_time']);
            fputcsv($output, [
                $log['entry_date'], $log['entry_time'], $log['exit_time'] ?: 'Inside',
                $log['admno'], $log['member_name'], $log['member_category'],
                $log['class'] ?? '-', $log['division'] ?? '-', $log['purpose'], $duration
            ]);
        }
        fclose($output);
        exit;
    }
    
    if ($exportType === 'pdf') {
        // Ensure mPDF is available
        if (!class_exists('Mpdf\Mpdf')) {
            $errorMsg = '<!DOCTYPE html><html><head><title>PDF Export Error</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body><div class="container mt-5"><div class="alert alert-danger"><h3>PDF Export Not Available</h3><p>The mPDF library is not loaded. Please run:</p><pre class="bg-light p-3">composer require mpdf/mpdf</pre><p>If already installed, check that vendor/autoload.php is correctly included.</p><hr><a href="?" class="btn btn-primary">Go Back</a></div></div></body></html>';
            die($errorMsg);
        }
        
        $html = generatePdfHtml($logs, $institution, $from, $to, $admno, $category, $class, $division);
        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => 'A4-L',  // Landscape A4
            'default_font_size' => 10,
            'default_font' => 'dejavusans',
            'margin_left' => 10,
            'margin_right' => 10,
            'margin_top' => 20,
            'margin_bottom' => 15,
            'margin_header' => 5,
            'margin_footer' => 5
        ]);
        $mpdf->SetTitle('Entry/Exit Log Report');
        $mpdf->SetAuthor($institution['name'] ?? 'Library System');
        $mpdf->SetCreator('Library Management System');
        $mpdf->WriteHTML($html);
        $filename = 'entry_exit_log_' . date('Y-m-d') . '.pdf';
        $mpdf->Output($filename, 'D');
        exit;
    }
}

// ----------------------------------------------------------------------
// Main view: fetch data for paginated display
// ----------------------------------------------------------------------
$totalRecords = getTotalLogCount($db, $from, $to, $admno, $category, $class, $division);
$totalPages = ceil($totalRecords / $perPage);
$page = min($page, $totalPages > 0 ? $totalPages : 1);
$logs = fetchLogsPaginated($db, $from, $to, $admno, $category, $class, $division, $page, $perPage);

// Get distinct filter values
$categories = $db->query("SELECT DISTINCT member_category FROM entry_exit WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category")->fetchAll(PDO::FETCH_COLUMN);
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

renderHeader('Entry/Exit Log');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap">
        <h2><i class="fas fa-list"></i> Entry/Exit Log</h2>
        <div class="btn-group">
            <a href="?export=csv&csrf_token=<?= urlencode($_SESSION['csrf_token']) ?>&<?= http_build_query(array_merge($_GET, ['export'=>null])) ?>" class="btn btn-success"><i class="fas fa-file-csv"></i> Export CSV</a>
            <a href="?export=pdf&csrf_token=<?= urlencode($_SESSION['csrf_token']) ?>&<?= http_build_query(array_merge($_GET, ['export'=>null])) ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> Export PDF</a>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Entry/Exit</a>
        </div>
    </div>
    
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Filter Logs</div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-2"><label class="form-label">From</label><input type="date" name="from" class="form-control" value="<?= htmlspecialchars($from) ?>"></div>
                <div class="col-md-2"><label class="form-label">To</label><input type="date" name="to" class="form-control" value="<?= htmlspecialchars($to) ?>"></div>
                <div class="col-md-2"><label class="form-label">Adm No</label><input type="text" name="admno" class="form-control" value="<?= htmlspecialchars($admno) ?>" placeholder="Search"></div>
                <div class="col-md-2"><label class="form-label">Category</label><select name="category" class="form-select"><option value="">All</option><?php foreach($categories as $cat): ?><option <?= $category===$cat?'selected':'' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><label class="form-label">Class/Dept</label><select name="class" class="form-select"><option value="">All</option><?php foreach($classes as $c): ?><option <?= $class===$c?'selected':'' ?>><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><label class="form-label">Div/Course</label><select name="division" class="form-select"><option value="">All</option><?php foreach($divisions as $d): ?><option <?= $division===$d?'selected':'' ?>><?= htmlspecialchars($d) ?></option><?php endforeach; ?></select></div>
                <div class="col-12"><button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply Filters</button> <a href="?" class="btn btn-outline-secondary"><i class="fas fa-undo"></i> Reset</a></div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
            <span><i class="fas fa-database"></i> Records (<?= $totalRecords ?> found)</span>
            <div><label class="me-2">Rows per page:</label><select class="form-select form-select-sm w-auto" id="perPageSelect"><?php foreach($validPerPage as $val): ?><option value="<?= $val ?>" <?= $perPage==$val?'selected':'' ?>><?= $val ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th>Date</th><th>Entry</th><th>Exit</th><th>AdmNo</th><th>Name</th>
                            <th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Purpose</th><th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($logs)): ?>
                            <tr><td colspan="10" class="text-center py-4">No records found.<?php else: foreach($logs as $log): ?>
                            <tr>
                                <td><?= htmlspecialchars(formatDate($log['entry_date'])) ?></td>
                                <td><?= htmlspecialchars($log['entry_time']) ?></td>
                                <td><?= $log['exit_time'] ? htmlspecialchars($log['exit_time']) : '<span class="badge bg-success">Inside</span>' ?></td>
                                <td><?= htmlspecialchars($log['admno']) ?></td>
                                <td><?= htmlspecialchars($log['member_name']) ?></td>
                                <td><?= htmlspecialchars($log['member_category']) ?></td>
                                <td><?= htmlspecialchars($log['class'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($log['division'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($log['purpose']) ?></td>
                                <td><?= formatDurationHtml($log['entry_date'], $log['entry_time'], $log['exit_time']) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if($totalPages > 1): ?>
        <div class="card-footer">
            <nav><ul class="pagination justify-content-center mb-0">
                <li class="page-item <?= $page<=1?'disabled':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page-1, 'per_page'=>$perPage])) ?>">Previous</a></li>
                <?php for($i=max(1,$page-2); $i<=min($totalPages,$page+2); $i++): ?>
                <li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i, 'per_page'=>$perPage])) ?>"><?= $i ?></a></li>
                <?php endfor; ?>
                <li class="page-item <?= $page>=$totalPages?'disabled':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$page+1, 'per_page'=>$perPage])) ?>">Next</a></li>
            </ul></nav>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('perPageSelect')?.addEventListener('change',function(){
    const u=new URL(window.location.href);
    u.searchParams.set('per_page',this.value);
    u.searchParams.set('page',1);
    window.location.href=u.toString();
});
</script>

<?php
// Footer with designer credit (required by integrity check)
$settings = getSettings();
?>
<footer class="footer mt-4 py-3 bg-light text-center border-top">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?>. All rights reserved.</p>
        <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
    </div>
</footer>
<?php renderFooter(); ?>

<?php
// PDF HTML generator (used only for export)
function generatePdfHtml(array $logs, array $institution, string $from, string $to, string $admno, string $category, string $class, string $division): string {
    $institutionName = htmlspecialchars($institution['name'] ?? 'Library System');
    $logoHtml = '';
    if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
        $logoHtml = '<img src="' . getWebImageUrl($institution['logo_path']) . '" style="height: 50px; margin-right: 15px;">';
    }
    $filterText = '';
    if ($admno) $filterText .= " | AdmNo: " . htmlspecialchars($admno);
    if ($category) $filterText .= " | Category: " . htmlspecialchars($category);
    if ($class) $filterText .= " | Class/Dept: " . htmlspecialchars($class);
    if ($division) $filterText .= " | Div/Course: " . htmlspecialchars($division);
    $generatedDate = date('F j, Y g:i A');
    $currentYear = date('Y');
    
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Entry/Exit Log Report</title><style>
        body { font-family: dejavusans, sans-serif; margin: 20px; font-size: 11px; }
        .header { text-align: center; border-bottom: 2px solid #1e3c72; margin-bottom: 20px; }
        .header h1 { margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #999; padding: 6px; text-align: left; }
        th { background-color: #1e3c72; color: white; }
        .footer { text-align: center; margin-top: 30px; font-size: 9px; color: #777; }
        .inside-badge { background: #28a745; color: white; padding: 2px 6px; border-radius: 10px; font-size: 9px; }
    </style></head><body>
    <div class="header">' . $logoHtml . '<h1>' . $institutionName . '</h1><h2>Entry / Exit Log Report</h2><p>Period: ' . htmlspecialchars($from) . ' to ' . htmlspecialchars($to) . htmlspecialchars($filterText) . '</p><p>Generated: ' . $generatedDate . '</p></div>
    <table><thead><tr><th>Date</th><th>Entry</th><th>Exit</th><th>AdmNo</th><th>Name</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Purpose</th><th>Duration</th></tr></thead><tbody>';
    
    foreach ($logs as $log) {
        $duration = formatDurationText($log['entry_date'], $log['entry_time'], $log['exit_time']);
        $exitDisplay = $log['exit_time'] ? htmlspecialchars($log['exit_time']) : '<span class="inside-badge">Inside</span>';
        $html .= '<tr>
            <td>' . htmlspecialchars(formatDate($log['entry_date'])) . '</td>
            <td>' . htmlspecialchars($log['entry_time']) . '</td>
            <td>' . $exitDisplay . '</td>
            <td>' . htmlspecialchars($log['admno']) . '</td>
            <td>' . htmlspecialchars($log['member_name']) . '</td>
            <td>' . htmlspecialchars($log['member_category']) . '</td>
            <td>' . htmlspecialchars($log['class'] ?? '-') . '</td>
            <td>' . htmlspecialchars($log['division'] ?? '-') . '</td>
            <td>' . htmlspecialchars($log['purpose']) . '</td>
            <td>' . htmlspecialchars($duration) . '</td>
        </tr>';
    }
    $html .= '</tbody></table><div class="footer">&copy; ' . $institutionName . ' – ' . $currentYear . ' | Generated by Library System</div></body></html>';
    return $html;
}
?>