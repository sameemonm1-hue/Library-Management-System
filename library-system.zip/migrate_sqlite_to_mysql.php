#!/usr/bin/env php
<?php
/**
 * Library ERP - SQLite to MySQL Migration Script
 * 
 * Usage: php migrate_sqlite_to_mysql.php [--force]
 * 
 * Options:
 *   --force   Continue even if tables already exist in MySQL
 * 
 * Environment variables (can be set in .env or passed):
 *   DB_HOST     MySQL host (default: localhost)
 *   DB_NAME     MySQL database name (default: library_erp)
 *   DB_USER     MySQL username (default: root)
 *   DB_PASS     MySQL password (default: empty)
 */

// ==================== CONFIGURATION ====================
$sqliteFile = __DIR__ . '/library_erp.db';
$mysqlHost = getenv('DB_HOST') ?: 'localhost';
$mysqlDb   = getenv('DB_NAME') ?: 'library_erp';
$mysqlUser = getenv('DB_USER') ?: 'root';
$mysqlPass = getenv('DB_PASS') ?: '';
$force = in_array('--force', $argv);

// ==================== HELPER FUNCTIONS ====================
function logMessage($msg, $type = 'info') {
    $prefix = match($type) {
        'error' => '❌ ERROR: ',
        'success' => '✅ ',
        'warning' => '⚠️ ',
        default => 'ℹ️ '
    };
    echo $prefix . $msg . PHP_EOL;
}

function convertSqliteValue($value, $columnType = null) {
    if ($value === null) return null;
    
    // Convert SQLite date functions
    if (is_string($value)) {
        if ($value === 'now' || $value === 'CURRENT_TIMESTAMP' || strpos($value, 'datetime(') !== false) {
            return date('Y-m-d H:i:s');
        }
        if (preg_match('/^datetime\(\'now\',\s*\'([+-]\d+)\s*days\'\)$/', $value, $matches)) {
            return date('Y-m-d H:i:s', strtotime("{$matches[1]} days"));
        }
        if (preg_match('/^strftime\(\'%Y-%m\',\s*\'now\'\)$/', $value)) {
            return date('Y-m');
        }
        if (preg_match('/^julianday\(\'now\'\)\s*-\s*julianday\((.+)\)$/', $value, $matches)) {
            // Approximate: compute days difference in PHP
            // We'll handle this by recalculating during migration with a custom query
            return null; // Will be handled per table
        }
    }
    return $value;
}

// ==================== MAIN MIGRATION ====================
try {
    logMessage("Starting migration from SQLite to MySQL...");

    // 1. Check if SQLite file exists
    if (!file_exists($sqliteFile)) {
        throw new Exception("SQLite database file not found: $sqliteFile");
    }

    // 2. Connect to SQLite
    $sqlite = new PDO("sqlite:$sqliteFile");
    $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    logMessage("Connected to SQLite database.");

    // 3. Connect to MySQL (without database, then create if needed)
    $mysql = new PDO("mysql:host=$mysqlHost;charset=utf8mb4", $mysqlUser, $mysqlPass);
    $mysql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if not exists
    $mysql->exec("CREATE DATABASE IF NOT EXISTS `$mysqlDb` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $mysql->exec("USE `$mysqlDb`");
    logMessage("Connected to MySQL, database `$mysqlDb` ready.");

    // 4. Import MySQL schema (if not already present or --force)
    $schemaFile = __DIR__ . '/schema_mysql.sql';
    if (!file_exists($schemaFile)) {
        throw new Exception("schema_mysql.sql not found in project root. Please place it there.");
    }
    
    // Check if any core table exists
    $checkTables = $mysql->query("SHOW TABLES LIKE 'users'")->fetch();
    if (!$checkTables || $force) {
        logMessage("Importing MySQL schema from schema_mysql.sql...");
        $schema = file_get_contents($schemaFile);
        // Split by semicolon, but careful with DELIMITER inside (none expected)
        $statements = array_filter(array_map('trim', explode(';', $schema)));
        foreach ($statements as $stmt) {
            if (!empty($stmt)) {
                try {
                    $mysql->exec($stmt);
                } catch (PDOException $e) {
                    // Ignore "already exists" errors if not forced
                    if (!$force || strpos($e->getMessage(), 'already exists') === false) {
                        throw $e;
                    }
                }
            }
        }
        logMessage("MySQL schema imported.", 'success');
    } else {
        logMessage("MySQL tables already exist. Use --force to re-import schema.", 'warning');
    }

    // 5. List of tables to migrate (order matters due to foreign keys)
    $tables = [
        'institutions', 'users', 'settings', 'module_permissions', 'staff_profiles',
        'quick_actions', 'login_cards', 'computer_policies', 'fine_rates', 'research_databases',
        'members', 'books', 'vendors', 'purchase_orders', 'purchase_order_items', 'ebooks',
        'circulation', 'loans', 'fine_payments', 'fine_settlements', 'payment_transactions',
        'lost_books', 'notices', 'suggestions', 'entry_exit', 'library_events', 'event_attendees',
        'book_holds', 'reservations_queue', 'serial_vendors', 'serial_subscriptions', 'serial_issues',
        'serial_reminders', 'computers', 'computer_sessions', 'computer_attendance',
        'member_documents', 'stock_verification', 'activity_logs', 'session_logs', 'user_sessions',
        'remember_tokens', 'session_audit_logs', 'rate_limits', 'export_logs', 'search_logs',
        'opac_reviews', 'daily_stats', 'weekly_reports', 'monthly_reports', 'generated_reports',
        'api_keys', 'email_queue', 'whatsapp_queue', 'email_templates', 'faq',
        'book_recommendations', 'fine_charges', 'loan_rules', 'research_database_logs',
        'user_preferences', 'report_generations', 'notification_logs', 'overdue_notifications'
    ];

    $totalMigrated = 0;
    $totalErrors = 0;

    // 6. Migrate each table
    foreach ($tables as $table) {
        // Check if table exists in SQLite
        $check = $sqlite->query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'");
        if (!$check->fetch()) {
            logMessage("Table $table does not exist in SQLite, skipping.", 'warning');
            continue;
        }

        // Get columns
        $columnsInfo = $sqlite->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_ASSOC);
        $columns = array_column($columnsInfo, 'name');
        if (empty($columns)) {
            logMessage("Table $table has no columns, skipping.", 'warning');
            continue;
        }

        // Clear existing data in MySQL (optional, but ensures fresh start)
        if ($force) {
            $mysql->exec("TRUNCATE TABLE `$table`");
        } else {
            // Check if table already has data
            $count = $mysql->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
            if ($count > 0) {
                logMessage("Table $table already has $count rows in MySQL. Use --force to overwrite.", 'warning');
                continue;
            }
        }

        // Fetch data from SQLite
        $rows = $sqlite->query("SELECT * FROM $table")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) {
            logMessage("Table $table has no data, skipping.");
            continue;
        }

        // Build INSERT query
        $placeholders = ':' . implode(', :', $columns);
        $insert = $mysql->prepare("INSERT INTO `$table` (" . implode(',', array_map(function($c) { return "`$c`"; }, $columns)) . ") VALUES ($placeholders)");

        $rowCount = 0;
        $mysql->beginTransaction();
        try {
            foreach ($rows as $row) {
                // Convert values as needed
                foreach ($row as $key => &$val) {
                    if ($val === null) continue;
                    // Convert SQLite date/time functions
                    if (is_string($val)) {
                        if ($val === 'now' || $val === 'CURRENT_TIMESTAMP' || strpos($val, 'datetime(') !== false) {
                            $val = date('Y-m-d H:i:s');
                        } elseif ($val === 'date(\'now\')') {
                            $val = date('Y-m-d');
                        } elseif (strpos($val, 'strftime') !== false) {
                            // Approximate conversion
                            $val = date('Y-m-d');
                        } elseif (strpos($val, 'julianday') !== false) {
                            // Could not convert easily; set to null (fine will be recalculated later)
                            $val = null;
                        }
                    }
                }
                $insert->execute($row);
                $rowCount++;
            }
            $mysql->commit();
            logMessage("Migrated $table: $rowCount records.", 'success');
            $totalMigrated += $rowCount;
        } catch (PDOException $e) {
            $mysql->rollBack();
            logMessage("Failed to migrate $table: " . $e->getMessage(), 'error');
            $totalErrors++;
        }
    }

    // 7. Handle foreign key specific recalculations (e.g., fines)
    // Recalculate total_fines for members based on circulation if needed
    try {
        logMessage("Recalculating member fines from circulation...");
        $mysql->exec("UPDATE members SET total_fines = (SELECT COALESCE(SUM(fine),0) FROM circulation WHERE circulation.admno = members.admno)");
        logMessage("Member fines recalculated.", 'success');
    } catch (Exception $e) {
        logMessage("Fine recalculation failed (non‑critical): " . $e->getMessage(), 'warning');
    }

    // 8. Summary
    logMessage("========================================", 'info');
    logMessage("Migration completed!", 'success');
    logMessage("Total tables processed: " . count($tables));
    logMessage("Total records migrated: $totalMigrated");
    logMessage("Total errors: $totalErrors");
    logMessage("========================================", 'info');
    logMessage("Next steps:", 'info');
    logMessage("1. Update your config/db.php to use DB_DRIVER=mysql");
    logMessage("2. Set environment variables: DB_HOST, DB_NAME, DB_USER, DB_PASS");
    logMessage("3. Test your application thoroughly.");
    
    if ($totalErrors > 0) {
        exit(1);
    }
} catch (Exception $e) {
    logMessage("Fatal error: " . $e->getMessage(), 'error');
    exit(1);
}