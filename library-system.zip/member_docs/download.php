<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) die("Unauthorized");

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid document ID.");

$db = getDB();
$stmt = $db->prepare("SELECT * FROM member_documents WHERE id = ?");
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) die("Document not found.");

$file = $doc['file_path'];
if (!file_exists($file)) die("File not found on server.");

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($file) . '"');
header('Content-Length: ' . filesize($file));
readfile($file);
exit;
?>