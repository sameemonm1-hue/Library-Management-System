<?php
require_once __DIR__ . '/../config/functions.php';
// session_start() already called inside functions.php – remove duplicate

// CSRF token for delete/verify links
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$member_admno = $_GET['member'] ?? '';
$documents = [];
$selected_member = null;

if ($member_admno) {
    // Fetch member details
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$member_admno]);
    $selected_member = $stmt->fetch();
    if ($selected_member) {
        // Fetch documents
        $stmt = $db->prepare("SELECT * FROM member_documents WHERE member_admno = ? ORDER BY uploaded_at DESC");
        $stmt->execute([$member_admno]);
        $documents = $stmt->fetchAll();
    }
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Documents - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .card-custom { background: white; border-radius: 16px; padding: 20px; margin-bottom: 25px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .doc-icon { font-size: 24px; color: #dc3545; }
        .verified-badge { font-size: 12px; padding: 3px 8px; border-radius: 20px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-id-card"></i> Member Documents</h2>
                <div>
                    <?php if ($selected_member): ?>
                        <a href="upload.php?member=<?= urlencode($member_admno) ?>" class="btn btn-primary"><i class="fas fa-upload"></i> Upload Document</a>
                    <?php endif; ?>
                    <a href="../index.php" class="btn btn-secondary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <!-- Member Selection -->
            <div class="card-custom">
                <h5>Select Member</h5>
                <form method="GET" class="row g-2">
                    <div class="col-md-6">
                        <input type="text" id="member_search" class="form-control" placeholder="Search by Admno or Name..." autocomplete="off">
                        <input type="hidden" name="member" id="selected_member" value="<?= htmlspecialchars($member_admno) ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary">Load Documents</button>
                    </div>
                </form>
                <div id="search_results" class="mt-2" style="position: absolute; z-index: 1000; background: white; width: 50%; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); display: none;"></div>
            </div>

            <?php if ($selected_member): ?>
                <div class="card-custom">
                    <h4><?= htmlspecialchars($selected_member['name']) ?></h4>
                    <p>Adm No: <?= $selected_member['admno'] ?> | Class/Dept: <?= htmlspecialchars($selected_member['class']) ?> | Div/Course: <?= htmlspecialchars($selected_member['division']) ?><br>Email: <?= $selected_member['email'] ?> | Phone: <?= $selected_member['phone'] ?></p>
                </div>

                <div class="card-custom">
                    <h5>Uploaded Documents</h5>
                    <?php if (count($documents) == 0): ?>
                        <div class="alert alert-info">No documents uploaded for this member.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr><th>File Name</th><th>Document Type</th><th>Uploaded At</th><th>Verified</th><th>Verified By</th><th>Actions</th></table>
                                </thead>
                                <tbody>
                                    <?php foreach ($documents as $doc): ?>
                                    <tr>
                                        <td><i class="fas fa-file-pdf doc-icon"></i> <?= htmlspecialchars(basename($doc['file_path'])) ?> </div>
                                        <td><?= htmlspecialchars($doc['document_type']) ?> </div>
                                        <td><?= date('d-m-Y H:i', strtotime($doc['uploaded_at'])) ?> </div>
                                        <td>
                                            <?php if ($doc['verified']): ?>
                                                <span class="badge bg-success verified-badge"><i class="fas fa-check-circle"></i> Verified</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary verified-badge"><i class="fas fa-clock"></i> Unverified</span>
                                            <?php endif; ?>
                                          </div>
                                        <td><?= $doc['verified'] ? htmlspecialchars($doc['verified_by']) : '-' ?> </div>
                                        <td>
                                            <a href="download.php?id=<?= $doc['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i></a>
                                            <?php if (!$doc['verified'] && $_SESSION['role'] == 'admin'): ?>
                                                <a href="verify.php?id=<?= $doc['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-sm btn-outline-success" onclick="return confirm('Verify this document?')"><i class="fas fa-check"></i> Verify</a>
                                            <?php endif; ?>
                                            <a href="delete.php?id=<?= $doc['id'] ?>&member=<?= urlencode($member_admno) ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this document?')"><i class="fas fa-trash"></i></a>
                                          </div>
                                      </div>
                                    <?php endforeach; ?>
                                </tbody>
                             </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="card-custom">
                    <div class="alert alert-info">Please select a member to view documents.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $('#member_search').on('input', function() {
            var query = $(this).val();
            if(query.length < 2) {
                $('#search_results').hide();
                return;
            }
            $.getJSON('ajax.php', { action: 'search_members', q: query }, function(data) {
                if(data.length && !data.error) {
                    var html = '<ul class="list-group">';
                    $.each(data, function(i, m) {
                        html += '<li class="list-group-item list-group-item-action" data-admno="'+m.admno+'" data-name="'+m.name+'">'+m.admno+' - '+m.name+'</li>';
                    });
                    html += '</ul>';
                    $('#search_results').html(html).show();
                } else {
                    $('#search_results').hide();
                }
            });
        });
        $(document).on('click', '#search_results li', function() {
            var admno = $(this).data('admno');
            var name = $(this).data('name');
            $('#member_search').val(admno + ' - ' + name);
            $('#selected_member').val(admno);
            $('#search_results').hide();
        });
        $('form').on('submit', function() {
            if(!$('#selected_member').val()) return false;
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>