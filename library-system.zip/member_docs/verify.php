<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid document ID.");

$db = getDB();
$stmt = $db->prepare("UPDATE member_documents SET verified = 1, verified_by = ? WHERE id = ? AND verified = 0");
$stmt->execute([$_SESSION['username'], $id]);
if ($stmt->rowCount() > 0) {
    logActivity($_SESSION['username'], 'DOC_VERIFY', "Verified document ID $id");
    // Regenerate CSRF token after successful action
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Redirect back to member's document list (need member admno)
$docStmt = $db->prepare("SELECT member_admno FROM member_documents WHERE id = ?");
$docStmt->execute([$id]);
$doc = $docStmt->fetch();
$member = $doc ? $doc['member_admno'] : '';
header("Location: index.php?member=" . urlencode($member));
exit;
?>