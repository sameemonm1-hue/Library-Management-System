<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = intval($_GET['id'] ?? 0);
$member_admno = $_GET['member'] ?? '';
if (!$id) die("Invalid document ID.");

$db = getDB();
$stmt = $db->prepare("SELECT * FROM member_documents WHERE id = ?");
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) die("Document not found.");

// Delete file from disk
if (file_exists($doc['file_path'])) {
    unlink($doc['file_path']);
}
// Delete database record
$db->prepare("DELETE FROM member_documents WHERE id = ?")->execute([$id]);
logActivity($_SESSION['username'], 'DOC_DELETE', "Deleted document ID $id for member {$doc['member_admno']}");

if ($member_admno) {
    header("Location: index.php?member=" . urlencode($member_admno));
} else {
    header("Location: index.php");
}
exit;
?>