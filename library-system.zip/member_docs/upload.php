<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$member_admno = $_GET['member'] ?? '';
if (!$member_admno) {
    header("Location: index.php");
    exit;
}

// Verify member exists
$stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
$stmt->execute([$member_admno]);
$member = $stmt->fetch();
if (!$member) {
    header("Location: index.php?error=member_not_found");
    exit;
}

// Define upload directory
$upload_dir = __DIR__ . '/../uploads/member_docs/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh and try again.";
    } else {
        $document_type = trim($_POST['document_type']);
        $notes = trim($_POST['notes']);
        
        if (!isset($_FILES['document']) || $_FILES['document']['error'] != UPLOAD_ERR_OK) {
            $error = "Please select a file to upload.";
        } elseif (!$document_type) {
            $error = "Document type is required.";
        } else {
            $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'doc', 'docx'];
            $ext = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) {
                $error = "Invalid file type. Allowed: " . implode(', ', $allowed);
            } else {
                // Generate unique filename
                $filename = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '', $_FILES['document']['name']);
                $filepath = $upload_dir . $filename;
                if (move_uploaded_file($_FILES['document']['tmp_name'], $filepath)) {
                    try {
                        $stmt = $db->prepare("INSERT INTO member_documents (member_admno, document_type, file_path, uploaded_at, verified, notes) VALUES (?, ?, ?, datetime('now'), 0, ?)");
                        $stmt->execute([$member_admno, $document_type, $filepath, $notes]);
                        logActivity($_SESSION['username'], 'DOC_UPLOAD', "Uploaded document for $member_admno: $document_type");
                        $success = "Document uploaded successfully.";
                        // Regenerate CSRF token after successful upload
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    } catch (PDOException $e) {
                        $error = "Database error: " . $e->getMessage();
                        // Delete uploaded file if DB fails
                        if (file_exists($filepath)) unlink($filepath);
                    }
                } else {
                    $error = "Failed to move uploaded file.";
                }
            }
        }
    }
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Upload Document for <?= htmlspecialchars($member['name']) ?> (<?= $member['admno'] ?>)</h2>
            <div>
                <a href="index.php?member=<?= urlencode($member_admno) ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>

        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= $success ?> <a href="index.php?member=<?= urlencode($member_admno) ?>">View Documents</a></div><?php endif; ?>

        <div class="form-card">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-3">
                    <label>Document Type *</label>
                    <select name="document_type" class="form-select" required>
                        <option value="">Select type</option>
                        <option value="ID Proof">ID Proof</option>
                        <option value="Address Proof">Address Proof</option>
                        <option value="Parent Consent">Parent Consent</option>
                        <option value="Photo">Photo</option>
                        <option value="Medical Certificate">Medical Certificate</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Select File * (PDF, JPG, PNG, DOC)</label>
                    <input type="file" name="document" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Notes (optional)</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>