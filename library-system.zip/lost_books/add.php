<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in db.php

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyCode = $settings['currency_code'] ?? 'USD';

$error = '';
$success = '';

// AJAX: AI suggested replacement cost based on similar books
if (isset($_GET['ajax']) && $_GET['ajax'] == 'suggest_cost') {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode'] ?? '');
    if (strlen($barcode) < 2) {
        echo json_encode(['error' => 'Invalid barcode']);
        exit;
    }
    $stmt = $db->prepare("SELECT subject, author, price FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $book = $stmt->fetch();
    if (!$book) {
        echo json_encode(['error' => 'Book not found']);
        exit;
    }
    // Find average cost of previously lost books with same subject or author
    $stmt = $db->prepare("SELECT AVG(replacement_cost) as avg_cost FROM lost_books lb 
                          JOIN books b ON lb.book_barcode = b.barcode 
                          WHERE b.subject = ? OR b.author = ?");
    $stmt->execute([$book['subject'], $book['author']]);
    $avg = $stmt->fetchColumn();
    if ($avg && $avg > 0) {
        $suggested = round($avg, 2);
    } else {
        $suggested = ($book['price'] && $book['price'] > 0) ? $book['price'] : 20.00;
    }
    echo json_encode(['suggested_cost' => $suggested, 'currency' => $currencyCode]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token.";
    } else {
        $admno = trim($_POST['admno']);
        $book_barcode = trim($_POST['book_barcode']);
        $circulation_id = $_POST['circulation_id'] ?: null;
        $loss_date = $_POST['loss_date'] ?? date('Y-m-d');
        $replacement_cost = (float) $_POST['replacement_cost'];
        $notes = trim($_POST['notes'] ?? '');
        $currency = $_POST['currency'] ?? $currencyCode;

        $member = $db->prepare("SELECT id, name, email, phone FROM members WHERE admno = ? AND status = 'active'");
        $member->execute([$admno]);
        $member = $member->fetch();
        $book = $db->prepare("SELECT id, title FROM books WHERE barcode = ?");
        $book->execute([$book_barcode]);
        $book = $book->fetch();

        if (!$member) $error = "Member not found or inactive.";
        elseif (!$book) $error = "Book not found.";
        else {
            $db->beginTransaction();
            try {
                $stmt = $db->prepare("INSERT INTO lost_books (admno, book_barcode, circulation_id, loss_date, replacement_cost, notes, status, created_at, currency) 
                                       VALUES (?, ?, ?, ?, ?, ?, 'pending', datetime('now'), ?)");
                if ($stmt->execute([$admno, $book_barcode, $circulation_id, $loss_date, $replacement_cost, $notes, $currency])) {
                    $lostId = $db->lastInsertId();
                    if ($settings['enable_notifications'] ?? false) {
                        sendNotification($member['email'], $member['phone'], 
                            "Lost/Damaged Book Reported", 
                            "A lost/damaged report has been filed for book '{$book['title']}'. Replacement cost: $currencySymbol $replacement_cost. Please contact library.");
                    }
                    logActivity($_SESSION['username'], 'LOST_BOOK_ADD', "Added lost book ID $lostId for member $admno");
                    $db->commit();
                    $success = "Report added successfully.";
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                } else {
                    throw new Exception("Database insert failed.");
                }
            } catch (Exception $e) {
                $db->rollBack();
                $error = "Error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Report Lost/Damaged - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .card { border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); margin-top: 20px; }
        .card-header { border-radius: 16px 16px 0 0 !important; }
        .form-label { font-weight: 500; }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4><i class="fas fa-book-dead text-danger"></i> Lost & Damaged Books Module</h4>
        <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Back to Home</a>
    </div>
    
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-plus-circle"></i> Report Lost/Damaged Book</h5>
        </div>
        <div class="card-body">
            <?php if($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <hr class="my-2">
                    <a href="index.php" class="alert-link"><i class="fas fa-list"></i> View All Reports</a>
                </div>
            <?php endif; ?>
            
            <?php if(!$success): ?>
            <form method="post" id="lostForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Member Admission Number <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user-graduate"></i></span>
                            <input type="text" name="admno" id="admno" class="form-control" required autofocus placeholder="Enter admission number">
                        </div>
                        <div id="memberInfo" class="small text-muted mt-1"></div>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Book Barcode <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                            <input type="text" name="book_barcode" id="book_barcode" class="form-control" required placeholder="Scan or enter barcode">
                        </div>
                        <div id="bookInfo" class="small text-muted mt-1"></div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Circulation ID (optional)</label>
                        <input type="number" name="circulation_id" class="form-control" placeholder="If known, enter circulation ID">
                        <small class="text-muted">Leave empty if not applicable</small>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Loss Date <span class="text-danger">*</span></label>
                        <input type="date" name="loss_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Currency</label>
                        <select name="currency" id="currency" class="form-select" required>
                            <option value="USD">USD ($)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="GBP">GBP (£)</option>
                            <option value="INR" selected>INR (₹)</option>
                            <option value="SAR">SAR (﷼)</option>
                            <option value="AED">AED (د.إ)</option>
                            <option value="QAR">QAR (﷼)</option>
                            <option value="KWD">KWD (د.ك)</option>
                            <option value="BHD">BHD (د.ب)</option>
                            <option value="OMR">OMR (ر.ع)</option>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Replacement Cost <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text" id="cost_symbol"><?= $currencySymbol ?></span>
                            <input type="number" step="0.01" name="replacement_cost" id="replacement_cost" class="form-control" required placeholder="Enter replacement cost">
                            <button type="button" class="btn btn-outline-secondary" id="suggestCostBtn">
                                <i class="fas fa-robot"></i> AI Suggest
                            </button>
                        </div>
                        <div id="suggestMsg" class="small text-muted mt-1"></div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Additional Notes</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Any additional information about the loss or damage..."></textarea>
                </div>
                
                <hr>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Submit Report
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(function(){
    // Fetch member info on blur
    $('#admno').on('blur', function() {
        let admno = $(this).val().trim();
        if(admno.length >= 3) {
            $.getJSON('../members/ajax_member.php?admno=' + encodeURIComponent(admno), function(res){
                if(res && res.name) {
                    $('#memberInfo').html('<i class="fas fa-check-circle text-success"></i> ' + res.name + ' (' + res.member_category + ')');
                } else {
                    $('#memberInfo').html('<i class="fas fa-exclamation-triangle text-danger"></i> Member not found');
                }
            }).fail(function() {
                $('#memberInfo').html('<i class="fas fa-exclamation-triangle text-danger"></i> Error fetching member info');
            });
        }
    });
    
    // Fetch book info on blur
    $('#book_barcode').on('blur', function() {
        let barcode = $(this).val().trim();
        if(barcode.length >= 3) {
            $.getJSON('../books/ajax_book.php?barcode=' + encodeURIComponent(barcode), function(res){
                if(res && res.title) {
                    $('#bookInfo').html('<i class="fas fa-check-circle text-success"></i> ' + res.title + ' by ' + (res.author || 'Unknown'));
                } else {
                    $('#bookInfo').html('<i class="fas fa-exclamation-triangle text-warning"></i> Book not found in database');
                }
            }).fail(function() {
                $('#bookInfo').html('<i class="fas fa-exclamation-triangle text-warning"></i> Book not found');
            });
        }
    });
    
    // AI Suggest Cost
    $('#suggestCostBtn').click(function(){
        let barcode = $('#book_barcode').val().trim();
        if(barcode.length < 2){
            alert("Please enter book barcode first");
            $('#book_barcode').focus();
            return;
        }
        $('#suggestMsg').html('<i class="fas fa-spinner fa-spin"></i> AI analyzing similar lost books...');
        $.getJSON('add.php?ajax=suggest_cost&barcode='+encodeURIComponent(barcode), function(res){
            if(res.error) {
                $('#suggestMsg').html('<span class="text-danger"><i class="fas fa-exclamation-triangle"></i> '+res.error+'</span>');
            } else {
                $('#replacement_cost').val(res.suggested_cost);
                $('#suggestMsg').html('<span class="text-success"><i class="fas fa-robot"></i> AI suggested cost: ' + res.suggested_cost + ' ' + res.currency + '</span>');
            }
        }).fail(function(){ 
            $('#suggestMsg').html('<span class="text-danger"><i class="fas fa-exclamation-triangle"></i> Error fetching AI suggestion</span>'); 
        });
    });
    
    // Auto-suggest when barcode is entered
    $('#book_barcode').on('blur', function(){ 
        if($(this).val()) $('#suggestCostBtn').click(); 
    });
    
    // Update currency symbol when currency changes
    $('#currency').on('change', function() {
        let currency = $(this).val();
        let symbols = {
            'USD': '$', 'EUR': '€', 'GBP': '£', 'INR': '₹',
            'SAR': '﷼', 'AED': 'د.إ', 'QAR': '﷼', 'KWD': 'د.ك',
            'BHD': 'د.ب', 'OMR': 'ر.ع'
        };
        $('#cost_symbol').text(symbols[currency] || '$');
    });
});
</script>
</body>
</html>