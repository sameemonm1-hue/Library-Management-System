<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = (int)$_GET['id'];
$db = getDB();
$stmt = $db->prepare("UPDATE reservations_queue SET status = 'notified', notified_at = datetime('now') WHERE id = ? AND status = 'waiting'");
$stmt->execute([$id]);
header("Location: index.php");
exit;
?>