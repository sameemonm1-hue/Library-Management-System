<?php
require_once __DIR__ . '/../config/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['exists' => false, 'error' => 'Unauthorized']);
    exit;
}

if (!isset($_GET['barcode']) || trim($_GET['barcode']) === '') {
    echo json_encode(['exists' => false]);
    exit;
}

$barcode = trim($_GET['barcode']);
$db = getDB();

$stmt = $db->prepare("SELECT title, barcode FROM books WHERE barcode = ?");
$stmt->execute([$barcode]);
$book = $stmt->fetch();

if ($book) {
    echo json_encode(['exists' => true, 'title' => $book['title']]);
} else {
    echo json_encode(['exists' => false]);
}
?>