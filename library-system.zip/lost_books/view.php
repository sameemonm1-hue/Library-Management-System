<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

$id = (int)$_GET['id'];
$db = getDB();
$stmt = $db->prepare("SELECT lb.*, m.name as member_name, m.admno, b.title as book_title, b.barcode as book_barcode 
                       FROM lost_books lb LEFT JOIN members m ON lb.admno = m.admno LEFT JOIN books b ON lb.book_barcode = b.barcode 
                       WHERE lb.id = ?");
$stmt->execute([$id]);
$r = $stmt->fetch();
if(!$r) die("Not found");

$lostCurrency = $r['currency'] ?? 'INR';
$displaySymbol = $currencySymbol;
if ($lostCurrency && function_exists('getCurrencySymbol')) $displaySymbol = getCurrencySymbol($lostCurrency);
?>
<!DOCTYPE html><html><head><title>Lost Book Details</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-5">
    <div class="d-flex justify-content-end mb-3">
        <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Back to Home</a>
        <a href="javascript:window.print()" class="btn btn-primary btn-sm ms-2"><i class="fas fa-print"></i> Print</a>
    </div>
    <div class="card shadow">
        <div class="card-header bg-secondary text-white"><h4>Incident Details</h4></div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr><th>Member</th><td><?= htmlspecialchars($r['member_name']) ?> (<?= $r['admno'] ?>)</td></tr>
                <tr><th>Book</th><td><?= htmlspecialchars($r['book_title']) ?> (Barcode: <?= $r['book_barcode'] ?>)</td></tr>
                <tr><th>Loss Date</th><td><?= $r['loss_date'] ?></td></tr>
                <tr><th>Replacement Cost</th><td><?= $displaySymbol ?> <?= number_format($r['replacement_cost'],2) ?></td></tr>
                <tr><th>Amount Paid</th><td><?= $displaySymbol ?> <?= number_format($r['amount_paid'],2) ?></td></tr>
                <tr><th>Status</th><td><span class="badge bg-<?= $r['status']=='paid'?'success':($r['status']=='waived'?'secondary':'warning') ?>"><?= ucfirst($r['status']) ?></span></td></tr>
                <tr><th>Replacement Barcode</th><td><?= $r['replacement_book_barcode'] ?? 'Not replaced yet' ?></td></tr>
                <tr><th>Notes</th><td><?= nl2br(htmlspecialchars($r['notes'] ?? '')) ?></td></tr>
            </table>
            <a href="index.php" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>
</body>
</html>