<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$id = (int)$_GET['id'];
$error = '';
$success = '';

$report = $db->prepare("SELECT * FROM lost_books WHERE id = ? AND status = 'pending'");
$report->execute([$id]);
$lost = $report->fetch();
if (!$lost) { echo "Invalid or already processed."; exit; }

$lostCurrency = $lost['currency'] ?? 'INR';
$displaySymbol = $currencySymbol;
if ($lostCurrency && function_exists('getCurrencySymbol')) $displaySymbol = getCurrencySymbol($lostCurrency);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token.";
    } else {
        $amount = (float)$_POST['amount'];
        if ($amount <= 0) $error = "Amount must be >0";
        else {
            $db->beginTransaction();
            try {
                $update = $db->prepare("UPDATE lost_books SET amount_paid = amount_paid + ?, status = CASE WHEN amount_paid + ? >= replacement_cost THEN 'paid' ELSE 'pending' END WHERE id = ?");
                $update->execute([$amount, $amount, $id]);
                $db->commit();
                $success = "Payment recorded successfully.";
                // Send notification
                $member = $db->prepare("SELECT email, phone FROM members WHERE admno = ?");
                $member->execute([$lost['admno']]);
                $m = $member->fetch();
                if ($m && ($settings['enable_notifications'] ?? false)) {
                    $remaining = max(0, $lost['replacement_cost'] - ($lost['amount_paid'] + $amount));
                    $msg = "Payment of $displaySymbol $amount received. Remaining balance: $displaySymbol $remaining.";
                    sendNotification($m['email'], $m['phone'], "Payment Received for Lost Book", $msg);
                }
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header("refresh:2;url=index.php");
            } catch(Exception $e) { $db->rollBack(); $error = "Failed: ".$e->getMessage(); }
        }
    }
}
?>
<!DOCTYPE html><html><head><title>Record Payment</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-5">
    <div class="d-flex justify-content-end mb-3"><a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Home</a></div>
    <div class="card shadow">
        <div class="card-header bg-success text-white"><h4>Record Payment for Lost/Damaged</h4></div>
        <div class="card-body">
            <p><strong>Member:</strong> <?= htmlspecialchars($lost['admno']) ?></p>
            <p><strong>Book Barcode:</strong> <?= htmlspecialchars($lost['book_barcode']) ?></p>
            <p><strong>Replacement Cost:</strong> <?= $displaySymbol ?> <?= number_format($lost['replacement_cost'],2) ?></p>
            <p><strong>Already Paid:</strong> <?= $displaySymbol ?> <?= number_format($lost['amount_paid'],2) ?></p>
            <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <?php if($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-3"><label>Amount Paying (<?= $displaySymbol ?>)</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
                <button type="submit" class="btn btn-primary">Submit Payment</button>
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>