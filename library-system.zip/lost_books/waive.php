<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if ($_SESSION['role'] != 'admin') { echo "Access denied."; exit; }

if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    echo "Invalid security token.";
    exit;
}

$id = (int)$_GET['id'];
$db = getDB();
$settings = getSettings();

// Get member details before update
$memberInfo = $db->prepare("SELECT m.email, m.phone FROM members m JOIN lost_books lb ON m.admno = lb.admno WHERE lb.id = ?");
$memberInfo->execute([$id]);
$member = $memberInfo->fetch();

$stmt = $db->prepare("UPDATE lost_books SET status = 'waived' WHERE id = ? AND status = 'pending'");
if ($stmt->execute([$id])) {
    if ($member && ($settings['enable_notifications'] ?? false)) {
        sendNotification($member['email'], $member['phone'], "Fee Waived", "Your lost book fee has been waived. No payment required.");
    }
    echo "<script>alert('Fee waived.'); window.location='index.php';</script>";
} else {
    echo "Error.";
}
?>
<!DOCTYPE html><html><head><title>Waive Fee</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-5"><a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Back to Home</a></div>
</body>
</html>