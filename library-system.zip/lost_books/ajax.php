<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if (!isset($_SESSION['user_id'])) { echo json_encode(['error' => 'Unauthorized']); exit; }

$rate_key = 'ajax_rate_' . $_SESSION['user_id'];
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
if ($_SESSION[$rate_key] > 20) { echo json_encode(['error' => 'Too many requests.']); exit; }
$_SESSION[$rate_key]++;

$db = getDB();
$action = $_GET['action'] ?? '';

if ($action == 'search_circulation') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) { echo json_encode([]); exit; }
    $stmt = $db->prepare("SELECT c.id, c.admno, m.name as member_name, c.barcode, b.title as book_title
                          FROM circulation c
                          LEFT JOIN members m ON c.admno = m.admno
                          LEFT JOIN books b ON c.barcode = b.barcode
                          WHERE c.return_date IS NULL AND (c.id LIKE ? OR c.admno LIKE ? OR c.barcode LIKE ?) LIMIT 10");
    $stmt->execute(["%$q%", "%$q%", "%$q%"]);
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($action == 'search_members') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) { echo json_encode([]); exit; }
    $stmt = $db->prepare("SELECT admno, name, member_category, class, division 
                          FROM members WHERE status = 'active' 
                          AND (admno LIKE ? OR name LIKE ? OR soundex(name) = soundex(?)) LIMIT 15");
    $like = "%$q%";
    $stmt->execute([$like, $like, $q]);
    echo json_encode($stmt->fetchAll());
    exit;
}

echo json_encode(['error' => 'Invalid action']);
?>