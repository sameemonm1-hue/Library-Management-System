<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$id = (int)$_GET['id'];
$db = getDB();
$lost = $db->prepare("SELECT lb.*, b.author, b.subject FROM lost_books lb JOIN books b ON lb.book_barcode = b.barcode WHERE lb.id = ? AND lb.status IN ('paid','waived') AND lb.replacement_book_barcode IS NULL");
$lost->execute([$id]);
$row = $lost->fetch();
if (!$row) { echo "Cannot replace this record."; exit; }

$error = '';
$success = '';

if (isset($_GET['ajax']) && $_GET['ajax'] == 'suggest_books') {
    header('Content-Type: application/json');
    $stmt = $db->prepare("SELECT barcode, title, author FROM books WHERE (author = ? OR subject = ?) AND status = 'available' LIMIT 10");
    $stmt->execute([$row['author'], $row['subject']]);
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token.";
    } else {
        $new_barcode = trim($_POST['new_barcode']);
        $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
        $check->execute([$new_barcode]);
        if (!$check->fetch()) $error = "Barcode not found.";
        else {
            $update = $db->prepare("UPDATE lost_books SET replacement_book_barcode = ? WHERE id = ?");
            if ($update->execute([$new_barcode, $id])) {
                $success = "Replacement recorded. You may now issue the new book to the member.";
                logActivity($_SESSION['username'], 'LOST_BOOK_REPLACE', "Replaced lost book ID $id with barcode $new_barcode");
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        }
    }
}
?>
<!DOCTYPE html><html><head><title>Mark Replaced</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-info text-white"><h4>Mark Lost Book as Replaced</h4></div>
        <div class="card-body">
            <p><strong>Lost Book:</strong> <?= htmlspecialchars($row['book_barcode']) ?> (<?= htmlspecialchars($row['title']) ?>)</p>
            <p><strong>Author:</strong> <?= htmlspecialchars($row['author']) ?> | <strong>Subject:</strong> <?= htmlspecialchars($row['subject']) ?></p>
            <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <?php if($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?> <a href="index.php">Back</a></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-3">
                    <label>New Replacement Book Barcode</label>
                    <input type="text" name="new_barcode" id="new_barcode" class="form-control" required autocomplete="off">
                    <div id="suggestions" class="list-group mt-2" style="max-height: 200px; overflow-y: auto;"></div>
                </div>
                <button type="submit" class="btn btn-primary">Confirm Replacement</button>
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<script>
$(function(){
    $('#new_barcode').on('input', function(){
        let val = $(this).val();
        if(val.length < 2) { $('#suggestions').empty(); return; }
        $.getJSON('replace.php?ajax=suggest_books', function(data){
            let html = '';
            data.forEach(book => {
                if(book.barcode.toLowerCase().includes(val.toLowerCase()) || book.title.toLowerCase().includes(val.toLowerCase())){
                    html += `<div class="list-group-item list-group-item-action suggestion-item" data-barcode="${book.barcode}">
                                <strong>${book.barcode}</strong> - ${book.title} (${book.author})
                            </div>`;
                }
            });
            $('#suggestions').html(html);
            $('.suggestion-item').click(function(){
                $('#new_barcode').val($(this).data('barcode'));
                $('#suggestions').empty();
            });
        });
    });
});
</script>
</body>
</html>