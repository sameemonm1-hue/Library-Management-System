<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in db.php

if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
if (!isset($_SESSION['user_id']) && !isset($_SESSION['username'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyCode = $settings['currency_code'] ?? 'USD';

// Bulk waive
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_waive']) && $_SESSION['role'] == 'admin') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) die("Invalid CSRF");
    $ids = $_POST['ids'] ?? [];
    if (!empty($ids)) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $db->prepare("UPDATE lost_books SET status = 'waived' WHERE id IN ($placeholders) AND status = 'pending'");
        $stmt->execute($ids);
        $count = $stmt->rowCount();
        logActivity($_SESSION['username'], 'LOST_BOOK_BULK_WAIVE', "Waived $count pending fees");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header("Location: index.php?msg=waived");
        exit;
    }
}

// CSV Export
if (isset($_GET['export'])) {
    $status_filter = $_GET['status'] ?? '';
    $member_search = trim($_GET['member'] ?? '');
    $sql = "SELECT lb.id, lb.admno, m.name as member_name, b.title as book_title, lb.loss_date, lb.replacement_cost, lb.amount_paid, lb.status
            FROM lost_books lb
            LEFT JOIN members m ON lb.admno = m.admno
            LEFT JOIN books b ON lb.book_barcode = b.barcode WHERE 1=1";
    $params = [];
    if ($status_filter) { $sql .= " AND lb.status = ?"; $params[] = $status_filter; }
    if ($member_search) { $sql .= " AND (m.name LIKE ? OR lb.admno LIKE ?)"; $like = "%$member_search%"; $params[] = $like; $params[] = $like; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=lost_books_export_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID', 'AdmNo', 'Member Name', 'Book Title', 'Loss Date', 'Replacement Cost', 'Amount Paid', 'Status']);
    foreach ($data as $row) {
        fputcsv($out, [
            $row['id'],
            $row['admno'],
            $row['member_name'],
            $row['book_title'],
            $row['loss_date'],
            $currencySymbol . ' ' . number_format($row['replacement_cost'], 2),
            $currencySymbol . ' ' . number_format($row['amount_paid'], 2),
            $row['status']
        ]);
    }
    fclose($out);
    exit;
}

// Filters
$status_filter = $_GET['status'] ?? '';
$member_search = trim($_GET['member'] ?? '');

$sql = "SELECT lb.*, m.name as member_name, m.admno, m.photo_path, b.title as book_title, b.barcode as book_barcode, b.cover_path
        FROM lost_books lb
        LEFT JOIN members m ON lb.admno = m.admno
        LEFT JOIN books b ON lb.book_barcode = b.barcode
        WHERE 1=1";
$params = [];
if ($status_filter) { $sql .= " AND lb.status = ?"; $params[] = $status_filter; }
if ($member_search) { $sql .= " AND (m.name LIKE ? OR lb.admno LIKE ?)"; $like = "%$member_search%"; $params[] = $like; $params[] = $like; }
$sql .= " ORDER BY lb.loss_date DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

// AI Dashboard Analytics
$totals = $db->query("SELECT SUM(replacement_cost) as total_cost, SUM(amount_paid) as total_paid, COUNT(*) as total_count FROM lost_books")->fetch();
$pendingCount = $db->query("SELECT COUNT(*) FROM lost_books WHERE status='pending'")->fetchColumn();
$paidCount = $db->query("SELECT COUNT(*) FROM lost_books WHERE status='paid'")->fetchColumn();

$trend = $db->query("SELECT strftime('%Y-%m', loss_date) as month, COUNT(*) as count 
                     FROM lost_books WHERE loss_date >= date('now', '-6 months')
                     GROUP BY month ORDER BY month")->fetchAll();
$months = array_column($trend, 'month');
$counts = array_column($trend, 'count');

$forecast = null;
if (count($counts) >= 3) {
    $n = count($counts);
    $x = range(1, $n);
    $sumX = array_sum($x); $sumY = array_sum($counts);
    $sumXY = array_sum(array_map(function($xi,$yi){return $xi*$yi;}, $x, $counts));
    $sumX2 = array_sum(array_map(function($xi){return $xi*$xi;}, $x));
    $slope = ($n*$sumXY - $sumX*$sumY) / ($n*$sumX2 - $sumX*$sumX);
    $intercept = ($sumY - $slope*$sumX)/$n;
    $forecast = max(0, round($slope*($n+1) + $intercept));
}

// Success message handling
$successMsg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == 'waived') $successMsg = '<div class="alert alert-success alert-dismissible fade show">✅ Selected pending fees have been waived successfully.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    if ($_GET['msg'] == 'paid') $successMsg = '<div class="alert alert-success alert-dismissible fade show">✅ Payment recorded successfully.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lost & Damaged Books - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Inter', sans-serif; }
        .stat-card { background: white; border-radius: 20px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-3px); }
        .table-card { background: white; border-radius: 20px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .member-photo { width: 35px; height: 35px; object-fit: cover; border-radius: 50%; margin-right: 8px; }
        .btn-home { margin-left: 10px; }
        @media print { .stat-card .btn, .filter-card, .footer, .btn-group { display: none; } }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap">
        <h2><i class="fas fa-book-dead text-danger"></i> Lost & Damaged Books</h2>
        <div>
            <a href="add.php" class="btn btn-primary"><i class="fas fa-plus"></i> Report</a>
            <a href="../index.php" class="btn btn-secondary btn-home"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <!-- Success Message -->
    <?= $successMsg ?>

    <!-- AI Analytics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <h5>📊 Total Reports</h5>
                <h2><?= number_format($totals['total_count'] ?? 0) ?></h2>
                <small>All time</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5>⚠️ Pending</h5>
                <h2><?= number_format($pendingCount) ?></h2>
                <small>Awaiting payment/waiver</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5>💰 Total Cost</h5>
                <h2><?= $currencySymbol ?> <?= number_format($totals['total_cost'] ?? 0, 2) ?></h2>
                <small>Replacement value</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card">
                <h5>📈 Forecast (next month)</h5>
                <h2><?= $forecast ?? 'N/A' ?></h2>
                <small>Predicted lost books</small>
            </div>
        </div>
    </div>

    <!-- Trend Chart -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="stat-card">
                <h5><i class="fas fa-chart-line"></i> Lost Books Trend (Last 6 Months)</h5>
                <canvas id="trendChart" height="100"></canvas>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-card">
                <h5><i class="fas fa-lightbulb"></i> AI Insight</h5>
                <p>
                    <?php if ($pendingCount > $paidCount): ?>
                        ⚠️ High number of pending reports – consider sending reminders.
                    <?php else: ?>
                        ✅ Good collection rate. Keep up!
                    <?php endif; ?>
                </p>
                <p>
                    <?php if ($forecast && $forecast > (end($counts) ?? 0)): ?>
                        📈 Forecast suggests an increase next month. Proactive measures recommended.
                    <?php endif; ?>
                </p>
                <hr>
                <small class="text-muted">Based on historical data analysis</small>
            </div>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="stat-card filter-card">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">All</option>
                    <option value="pending" <?= $status_filter=='pending'?'selected':'' ?>>Pending</option>
                    <option value="paid" <?= $status_filter=='paid'?'selected':'' ?>>Paid</option>
                    <option value="waived" <?= $status_filter=='waived'?'selected':'' ?>>Waived</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Member (Name / Adm No)</label>
                <input type="text" name="member" class="form-control" value="<?= htmlspecialchars($member_search) ?>" placeholder="Search by name or admission number...">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Filter</button>
            </div>
            <div class="col-md-1">
                <a href="index.php" class="btn btn-secondary w-100">Reset</a>
            </div>
            <div class="col-md-2">
                <a href="?export=1&<?= http_build_query($_GET) ?>" class="btn btn-success w-100"><i class="fas fa-file-csv"></i> Export CSV</a>
            </div>
        </form>
    </div>

    <!-- Reports Table -->
    <div class="table-card">
        <form method="post" id="bulkForm">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h5><i class="fas fa-list"></i> Incident Reports</h5>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin' && $pendingCount > 0): ?>
                    <button type="submit" name="bulk_waive" class="btn btn-outline-secondary btn-sm" onclick="return confirm('Waive selected pending fees? This action cannot be undone.')">
                        <i class="fas fa-hand-holding-heart"></i> Bulk Waive Selected
                    </button>
                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="30"><input type="checkbox" id="selectAll"></th>
                            <th>ID</th>
                            <th>Member</th>
                            <th>Book</th>
                            <th>Loss Date</th>
                            <th>Cost</th>
                            <th>Paid</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                            <tr><td colspan="9" class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-3x mb-3 d-block"></i>
                                No lost/damaged book reports found.
                             </div>
                        <?php else: foreach ($reports as $r): ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="ids[]" value="<?= $r['id'] ?>" class="rowCheckbox" <?= $r['status'] != 'pending' ? 'disabled' : '' ?>>
                             </div>
                            <td><?= $r['id'] ?> </div>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if(!empty($r['photo_path'])): ?>
                                        <img src="<?= getWebImageUrl($r['photo_path']) ?>" class="member-photo" alt="Member Photo">
                                    <?php else: ?>
                                        <i class="fas fa-user-circle fa-2x text-muted me-2"></i>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?= htmlspecialchars($r['member_name'] ?? 'Deleted Member') ?></strong><br>
                                        <small class="text-muted"><?= htmlspecialchars($r['admno']) ?></small>
                                    </div>
                                </div>
                             </div>
                            <td>
                                <strong><?= htmlspecialchars($r['book_title'] ?? 'Unknown Book') ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($r['book_barcode']) ?></small>
                             </div>
                            <td><?= date('d-m-Y', strtotime($r['loss_date'])) ?> </div>
                            <td><?= $currencySymbol ?> <?= number_format($r['replacement_cost'], 2) ?> </div>
                            <td><?= $currencySymbol ?> <?= number_format($r['amount_paid'], 2) ?> </div>
                            <td>
                                <?php
                                $statusClass = match($r['status']) {
                                    'paid' => 'success',
                                    'waived' => 'secondary',
                                    default => 'warning'
                                };
                                ?>
                                <span class="badge bg-<?= $statusClass ?> px-3 py-2 rounded-pill">
                                    <?= ucfirst($r['status']) ?>
                                </span>
                             </div>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <?php if ($r['status'] == 'pending'): ?>
                                        <a href="pay_fine.php?id=<?= $r['id'] ?>" class="btn btn-outline-success" title="Record Payment">
                                            <i class="fas fa-money-bill"></i> Pay
                                        </a>
                                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                                            <a href="waive.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-outline-secondary" title="Waive Fine" onclick="return confirm('Waive this fee? This action cannot be undone.')">
                                                <i class="fas fa-hand-holding-heart"></i> Waive
                                            </a>
                                        <?php endif; ?>
                                    <?php elseif ($r['status'] == 'paid' || $r['status'] == 'waived'): ?>
                                        <?php if (empty($r['replacement_book_barcode'])): ?>
                                            <a href="replace.php?id=<?= $r['id'] ?>" class="btn btn-outline-primary" title="Replace Book">
                                                <i class="fas fa-exchange-alt"></i> Replace
                                            </a>
                                        <?php else: ?>
                                            <span class="badge bg-info">Replaced</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <a href="view.php?id=<?= $r['id'] ?>" class="btn btn-outline-info" title="View Details">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </div>
                             </div>
                         </div>
                        <?php endforeach; endif; ?>
                    </tbody>
                    <?php if (!empty($reports)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="5" class="text-end">Totals: </div>
                            <td><?= $currencySymbol ?> <?= number_format(array_sum(array_column($reports, 'replacement_cost')), 2) ?> </div>
                            <td><?= $currencySymbol ?> <?= number_format(array_sum(array_column($reports, 'amount_paid')), 2) ?> </div>
                            <td colspan="2"></td>
                         </tr>
                    </tfoot>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="container">
    <div class="footer">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
    </div>
</div>

<script>
    // Trend Chart
    const ctx = document.getElementById('trendChart');
    if (ctx) {
        new Chart(ctx, { 
            type: 'line', 
            data: { 
                labels: <?= json_encode($months) ?>, 
                datasets: [{ 
                    label: 'Lost Books', 
                    data: <?= json_encode($counts) ?>, 
                    borderColor: '#dc3545', 
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    fill: true,
                    tension: 0.3
                }] 
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { position: 'top' }
                }
            }
        });
    }
    
    // Select All checkbox functionality
    document.getElementById('selectAll')?.addEventListener('change', function(e) { 
        document.querySelectorAll('.rowCheckbox').forEach(cb => { 
            if(!cb.disabled) cb.checked = e.target.checked; 
        }); 
    });
    
    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            let bsAlert = new bootstrap.Alert(alert);
            setTimeout(() => bsAlert.close(), 5000);
        });
    }, 3000);
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>