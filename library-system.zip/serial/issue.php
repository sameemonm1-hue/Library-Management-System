if (isset($_POST['send_reminder'])) {
    $vendor_email = $_POST['vendor_email'];
    $subject = "Missing / Late issue: " . $_POST['title'];
    $message = "Dear vendor,\n\nWe have not received issue {$_POST['issue_number']} of {$_POST['title']}. Please check.\n\nRegards";
    // Use your mail function (e.g., mail() or PHPMailer)
    mail($vendor_email, $subject, $message);
    // Store in reminders table
    $stmt = $db->prepare("INSERT INTO serial_reminders (subscription_id, issue_id, reminder_type, sent_to, subject, message) VALUES (?,?,?,?,?,?)");
    $stmt->execute([...]);
    showToast("Reminder sent to vendor", "success");
}