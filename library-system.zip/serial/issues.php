<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$subscription_id = $_GET['sub_id'] ?? 0;
$subscription = null;
if ($subscription_id) {
    $stmt = $db->prepare("SELECT * FROM serial_subscriptions WHERE id = ?");
    $stmt->execute([$subscription_id]);
    $subscription = $stmt->fetch();
    if (!$subscription) die("Invalid subscription");
}

// Check-in / Receive issue
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['receive_issue'])) {
    $issue_id = $_POST['issue_id'];
    $date_received = date('Y-m-d');
    $stmt = $db->prepare("UPDATE serial_issues SET date_received = ?, status = 'received' WHERE id = ?");
    $stmt->execute([$date_received, $issue_id]);
    showToast("Issue received", "success");
    logActivity($_SESSION['username'], 'SERIAL_ISSUE_RECEIVE', "Received issue ID $issue_id");
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// Mark as claimed / missing / late
if (isset($_POST['update_status'])) {
    $stmt = $db->prepare("UPDATE serial_issues SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['issue_id']]);
    showToast("Status updated", "success");
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// Add a new expected issue (manual)
if (isset($_POST['add_issue'])) {
    $stmt = $db->prepare("INSERT INTO serial_issues (subscription_id, volume, issue_number, date_published, status) VALUES (?,?,?,?,?)");
    $stmt->execute([$subscription_id, $_POST['volume'], $_POST['issue_number'], $_POST['date_published'], 'expected']);
    showToast("Issue added to expected list", "success");
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// Fetch issues for this subscription
$issues = $db->prepare("SELECT * FROM serial_issues WHERE subscription_id = ? ORDER BY date_published DESC, issue_number DESC");
$issues->execute([$subscription_id]);
$issuesList = $issues->fetchAll();

// Also fetch vendor email for reminders
$vendor = null;
if ($subscription && $subscription['vendor_id']) {
    $stmt = $db->prepare("SELECT email, name FROM serial_vendors WHERE id = ?");
    $stmt->execute([$subscription['vendor_id']]);
    $vendor = $stmt->fetch();
}

renderHeader('Serial Issues');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-boxes"></i> Issues for: <?= htmlspecialchars($subscription['title'] ?? '') ?></h2>
        <div>
            <a href="serial_subscriptions.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Subscriptions</a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addIssueModal"><i class="fas fa-plus"></i> Add Expected Issue</button>
            <?php if ($vendor && $vendor['email']): ?>
            <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#reminderModal"><i class="fas fa-envelope"></i> Send Reminder to Vendor</button>
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><i class="fas fa-list"></i> Issue List</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr><th>Vol/Issue</th><th>Published Date</th><th>Received Date</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($issuesList as $issue): ?>
                    <tr>
                        <td><?= htmlspecialchars($issue['volume'] ?: 'Vol.') ?> / <?= htmlspecialchars($issue['issue_number']) ?></td>
                        <td><?= $issue['date_published'] ?></td>
                        <td><?= $issue['date_received'] ?? '—' ?></td>
                        <td>
                            <span class="badge bg-<?= $issue['status']=='received'?'success':($issue['status']=='claimed'?'info':($issue['status']=='missing'?'danger':'warning')) ?>">
                                <?= ucfirst($issue['status']) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($issue['status'] != 'received'): ?>
                            <form method="post" style="display:inline-block">
                                <input type="hidden" name="issue_id" value="<?= $issue['id'] ?>">
                                <button type="submit" name="receive_issue" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Receive</button>
                            </form>
                            <?php endif; ?>
                            <form method="post" style="display:inline-block">
                                <input type="hidden" name="issue_id" value="<?= $issue['id'] ?>">
                                <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()">
                                    <option value="expected" <?= $issue['status']=='expected'?'selected':'' ?>>Expected</option>
                                    <option value="claimed" <?= $issue['status']=='claimed'?'selected':'' ?>>Claimed</option>
                                    <option value="missing" <?= $issue['status']=='missing'?'selected':'' ?>>Missing</option>
                                    <option value="late" <?= $issue['status']=='late'?'selected':'' ?>>Late</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($issuesList)): ?>
                    <tr><td colspan="5" class="text-center">No issues recorded. Add expected issues.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Expected Issue Modal -->
<div class="modal fade" id="addIssueModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5>Add Expected Issue</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-2"><label>Volume</label><input type="text" name="volume" class="form-control"></div>
                    <div class="mb-2"><label>Issue Number *</label><input type="text" name="issue_number" class="form-control" required></div>
                    <div class="mb-2"><label>Published Date</label><input type="date" name="date_published" class="form-control"></div>
                </div>
                <div class="modal-footer"><button type="submit" name="add_issue" class="btn btn-primary">Add Issue</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Reminder Modal (Send email to vendor) -->
<?php if ($vendor && $vendor['email']): ?>
<div class="modal fade" id="reminderModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning"><h5>Send Reminder to Vendor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form method="post" action="serial_reminders.php">
                <div class="modal-body">
                    <input type="hidden" name="subscription_id" value="<?= $subscription_id ?>">
                    <p><strong>Vendor:</strong> <?= htmlspecialchars($vendor['name']) ?> (<?= $vendor['email'] ?>)</p>
                    <div class="mb-2"><label>Subject</label><input type="text" name="subject" class="form-control" value="Missing/Late Issue for <?= htmlspecialchars($subscription['title']) ?>"></div>
                    <div class="mb-2"><label>Message</label><textarea name="message" class="form-control" rows="4">Dear Vendor,

We have not received the following issue(s) for <?= htmlspecialchars($subscription['title']) ?>. Please check and update.

Regards,
Library</textarea></div>
                </div>
                <div class="modal-footer"><button type="submit" name="send_reminder" class="btn btn-warning">Send Reminder</button></div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>