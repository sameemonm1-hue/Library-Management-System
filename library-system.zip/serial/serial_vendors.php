<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$action = $_GET['action'] ?? 'list';
$editVendor = null;

// Handle edit fetch
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM serial_vendors WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editVendor = $stmt->fetch();
}

// Add / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: serial_vendors.php");
        exit;
    }
    try {
        if (isset($_POST['add_vendor'])) {
            $stmt = $db->prepare("INSERT INTO serial_vendors (name, contact_person, email, phone, address, notes) VALUES (?,?,?,?,?,?)");
            $stmt->execute([
                $_POST['name'],
                $_POST['contact_person'],
                $_POST['email'],
                $_POST['phone'],
                $_POST['address'],
                $_POST['notes']
            ]);
            showToast("Vendor added successfully", "success");
            logActivity($_SESSION['username'], 'SERIAL_VENDOR_ADD', "Added vendor: {$_POST['name']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: serial_vendors.php");
            exit;
        }
        elseif (isset($_POST['update_vendor'])) {
            $stmt = $db->prepare("UPDATE serial_vendors SET name=?, contact_person=?, email=?, phone=?, address=?, notes=? WHERE id=?");
            $stmt->execute([
                $_POST['name'],
                $_POST['contact_person'],
                $_POST['email'],
                $_POST['phone'],
                $_POST['address'],
                $_POST['notes'],
                $_POST['id']
            ]);
            showToast("Vendor updated", "success");
            logActivity($_SESSION['username'], 'SERIAL_VENDOR_UPDATE', "Updated vendor ID {$_POST['id']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: serial_vendors.php");
            exit;
        }
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// Delete (with CSRF token check)
if (isset($_GET['delete'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        $check = $db->prepare("SELECT COUNT(*) FROM serial_subscriptions WHERE vendor_id = ?");
        $check->execute([$_GET['delete']]);
        if ($check->fetchColumn() > 0) {
            showToast("Cannot delete – vendor has active subscriptions.", "warning");
        } else {
            $stmt = $db->prepare("DELETE FROM serial_vendors WHERE id = ?");
            $stmt->execute([$_GET['delete']]);
            showToast("Vendor deleted", "success");
            logActivity($_SESSION['username'], 'SERIAL_VENDOR_DELETE', "Deleted vendor ID {$_GET['delete']}");
        }
    }
    header("Location: serial_vendors.php");
    exit;
}

// Fetch all vendors
$vendors = $db->query("SELECT * FROM serial_vendors ORDER BY name")->fetchAll();

renderHeader('Serial Vendors');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-truck"></i> Serial Vendors</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addVendorModal">
            <i class="fas fa-plus"></i> Add Vendor
        </button>
    </div>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-list"></i> Vendor List
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr><th>Name</th><th>Contact Person</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($vendors as $v): ?>
                        <tr>
                            <td><?= htmlspecialchars($v['name']) ?></td>
                            <td><?= htmlspecialchars($v['contact_person'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($v['email'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($v['phone'] ?? '-') ?></td>
                            <td>
                                <a href="?edit=<?= $v['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $v['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete vendor?')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($vendors)): ?>
                        <tr><td colspan="5" class="text-center">No vendors found.<?= ' ' ?></td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Vendor Modal -->
<div class="modal fade" id="addVendorModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Add Vendor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="mb-2"><label>Name *</label><input type="text" name="name" class="form-control" required></div>
                    <div class="mb-2"><label>Contact Person</label><input type="text" name="contact_person" class="form-control"></div>
                    <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control"></div>
                    <div class="mb-2"><label>Phone</label><input type="text" name="phone" class="form-control"></div>
                    <div class="mb-2"><label>Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
                    <div class="mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_vendor" class="btn btn-primary">Save Vendor</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($editVendor): ?>
<!-- Edit Vendor Modal -->
<div class="modal fade show" id="editVendorModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title">Edit Vendor</h5>
                <a href="serial_vendors.php" class="btn-close"></a>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $editVendor['id'] ?>">
                    <div class="mb-2"><label>Name *</label><input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editVendor['name']) ?>" required></div>
                    <div class="mb-2"><label>Contact Person</label><input type="text" name="contact_person" class="form-control" value="<?= htmlspecialchars($editVendor['contact_person'] ?? '') ?>"></div>
                    <div class="mb-2"><label>Email</label><input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editVendor['email'] ?? '') ?>"></div>
                    <div class="mb-2"><label>Phone</label><input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($editVendor['phone'] ?? '') ?>"></div>
                    <div class="mb-2"><label>Address</label><textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($editVendor['address'] ?? '') ?></textarea></div>
                    <div class="mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editVendor['notes'] ?? '') ?></textarea></div>
                </div>
                <div class="modal-footer">
                    <a href="serial_vendors.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_vendor" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>