<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

$columns = [
    'subscription_type' => "ALTER TABLE serial_subscriptions ADD COLUMN subscription_type TEXT DEFAULT 'print'",
    'access_url' => "ALTER TABLE serial_subscriptions ADD COLUMN access_url TEXT DEFAULT ''",
    'access_credentials' => "ALTER TABLE serial_subscriptions ADD COLUMN access_credentials TEXT DEFAULT ''",
    'digital_format' => "ALTER TABLE serial_subscriptions ADD COLUMN digital_format TEXT DEFAULT ''"
];

echo "<h2>Adding missing columns to serial_subscriptions table</h2>";
foreach ($columns as $col => $sql) {
    try {
        $db->exec($sql);
        echo "<p style='color:green'>✓ Added column: <strong>$col</strong></p>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'duplicate column name') !== false) {
            echo "<p style='color:orange'>⚠ Column <strong>$col</strong> already exists.</p>";
        } else {
            echo "<p style='color:red'>✗ Error adding $col: " . $e->getMessage() . "</p>";
        }
    }
}

echo "<hr><p><strong>Done.</strong> You can now <a href='index.php'>go back to Serial Dashboard</a>.</p>";
echo "<p><strong>Important:</strong> Delete this file (fix_serial_columns.php) after running.</p>";
?>