<?php
/**
 * Serial Control Module - Dashboard (Complete Update)
 * Manages periodicals, magazines, newspapers: subscriptions, issues, reminders
 * Features:
 * - Cover images for serial publications
 * - Enhanced statistics with visual indicators
 * - Subscription type badges with icons
 * - Issue status tracking with color coding
 * - Quick action cards with hover effects
 * - Responsive design
 * - Error handling
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== SAFE QUERY FUNCTION ==========
function safeQuery($db, $sql, $default = 0) {
    try {
        $result = $db->query($sql);
        return $result ? $result->fetchColumn() : $default;
    } catch (PDOException $e) {
        error_log("Query failed: " . $e->getMessage());
        return $default;
    }
}

// ========== STATISTICS WITH ERROR HANDLING ==========
$activeSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND (end_date IS NULL OR end_date >= date('now'))");

$onlineSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND subscription_type IN ('online','both') AND (end_date IS NULL OR end_date >= date('now'))");

$printSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND subscription_type IN ('print','both') AND (end_date IS NULL OR end_date >= date('now'))");

$expectedIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'expected' AND date_received IS NULL");

$lateIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'expected' AND date_published < date('now', '-7 days')");

$remindersSent = safeQuery($db, "SELECT COUNT(*) FROM serial_reminders WHERE sent_at >= date('now', '-30 days')");

// ========== ACTIVE SUBSCRIPTIONS WITH COVERS ==========
try {
    $activeSubsList = $db->query("
        SELECT s.*, v.name as vendor_name, v.logo_path as vendor_logo
        FROM serial_subscriptions s 
        LEFT JOIN serial_vendors v ON s.vendor_id = v.id 
        WHERE s.status = 'active' AND (s.end_date IS NULL OR s.end_date >= date('now'))
        ORDER BY s.title LIMIT 10
    ")->fetchAll();
    
    foreach ($activeSubsList as &$sub) {
        $sub['vendor_logo_base64'] = getImageBase64($sub['vendor_logo'] ?? '');
    }
} catch (PDOException $e) {
    error_log("Active subscriptions query failed: " . $e->getMessage());
    $activeSubsList = [];
}

// ========== RECENT EXPECTED ISSUES ==========
try {
    $expectedIssuesList = $db->query("
        SELECT i.*, s.title as subscription_title, s.frequency, s.subscription_type, 
               v.name as vendor_name, v.logo_path as vendor_logo
        FROM serial_issues i
        JOIN serial_subscriptions s ON i.subscription_id = s.id
        LEFT JOIN serial_vendors v ON s.vendor_id = v.id
        WHERE i.status = 'expected' AND i.date_received IS NULL
        ORDER BY i.date_published ASC LIMIT 10
    ")->fetchAll();
    
    foreach ($expectedIssuesList as &$issue) {
        $issue['vendor_logo_base64'] = getImageBase64($issue['vendor_logo'] ?? '');
    }
} catch (PDOException $e) {
    error_log("Expected issues query failed: " . $e->getMessage());
    $expectedIssuesList = [];
}

// ========== RECENT REMINDERS ==========
try {
    $recentReminders = $db->query("
        SELECT r.*, s.title as subscription_title
        FROM serial_reminders r
        JOIN serial_subscriptions s ON r.subscription_id = s.id
        ORDER BY r.sent_at DESC LIMIT 10
    ")->fetchAll();
} catch (PDOException $e) {
    error_log("Reminders query failed: " . $e->getMessage());
    $recentReminders = [];
}

// ========== STATUS COLOR MAP ==========
$statusColors = [
    'active' => 'success',
    'expired' => 'danger',
    'cancelled' => 'secondary'
];

$frequencyIcons = [
    'daily' => 'fa-calendar-day',
    'weekly' => 'fa-calendar-week',
    'biweekly' => 'fa-calendar-alt',
    'monthly' => 'fa-calendar-month',
    'bimonthly' => 'fa-calendar-alt',
    'quarterly' => 'fa-calendar-quarter',
    'halfyearly' => 'fa-calendar',
    'yearly' => 'fa-calendar-year'
];

$typeIcons = [
    'print' => 'fa-print',
    'online' => 'fa-globe',
    'both' => 'fa-exchange-alt'
];

$typeColors = [
    'print' => 'secondary',
    'online' => 'primary',
    'both' => 'success'
];

renderHeader('Serial Control Dashboard');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Stat Cards */
.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    height: 100%;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
.stat-card .stat-icon {
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 32px;
    opacity: 0.15;
}
.stat-card .stat-value {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 2px;
}
.stat-card .stat-label {
    font-size: 14px;
    color: #6c757d;
}
.stat-card .stat-sub {
    font-size: 11px;
    color: #adb5bd;
    margin-top: 4px;
}

/* Vendor Logo */
.vendor-logo-small {
    width: 28px;
    height: 28px;
    object-fit: contain;
    border-radius: 50%;
    border: 1px solid #e9ecef;
    background: white;
    flex-shrink: 0;
}
.vendor-logo-placeholder {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 0.6rem;
    border: 1px solid #e9ecef;
    flex-shrink: 0;
}

/* Subscription Type Badge */
.type-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.65rem;
    font-weight: 600;
}
.type-badge-print { background: #e9ecef; color: #495057; }
.type-badge-online { background: #cfe2ff; color: #084298; }
.type-badge-both { background: #d1e7dd; color: #0f5132; }

/* Frequency Badge */
.frequency-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.6rem;
    background: #f8f9fa;
    color: #495057;
    border: 1px solid #e9ecef;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 12px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
}

/* Subscription Row */
.subscription-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.subscription-info {
    flex: 1;
}
.subscription-title {
    font-weight: 600;
    font-size: 0.9rem;
}
.subscription-meta {
    font-size: 0.7rem;
    color: #6c757d;
}

/* Issue Row */
.issue-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.issue-info {
    flex: 1;
}

/* Quick Action Card */
.quick-action-card {
    padding: 20px;
    border-radius: 16px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 1px solid #e9ecef;
    background: white;
    height: 100%;
}
.quick-action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    border-color: #1e3c72;
}
.quick-action-card i {
    font-size: 28px;
    margin-bottom: 10px;
    display: block;
}
.quick-action-card .action-label {
    font-weight: 600;
    font-size: 0.85rem;
}
.quick-action-card .action-desc {
    font-size: 0.7rem;
    color: #6c757d;
}

/* Responsive */
@media (max-width: 768px) {
    .stat-card .stat-value { font-size: 22px; }
    .stat-card { padding: 15px; }
    .stat-card .stat-icon { font-size: 28px; }
    .quick-action-card { padding: 15px; }
    .quick-action-card i { font-size: 22px; }
    .vendor-logo-small { width: 22px; height: 22px; }
}

@media (max-width: 576px) {
    .table-responsive { font-size: 0.8rem; }
    .type-badge { font-size: 0.55rem; padding: 1px 6px; }
    .frequency-badge { font-size: 0.5rem; padding: 1px 6px; }
}
</style>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap gap-2">
        <h2><i class="fas fa-newspaper text-primary"></i> Serial Control Dashboard</h2>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="serial_subscriptions.php" class="btn btn-success">
                <i class="fas fa-plus"></i> New Subscription
            </a>
            <a href="serial_vendors.php" class="btn btn-outline-secondary">
                <i class="fas fa-truck"></i> Vendors
            </a>
            <a href="serial_issues.php" class="btn btn-outline-info">
                <i class="fas fa-boxes"></i> All Issues
            </a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-primary">
                <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
                <div class="stat-value text-primary"><?= $activeSubscriptions ?></div>
                <div class="stat-label">Active Subscriptions</div>
                <div class="stat-sub"><i class="fas fa-check-circle text-success"></i> Current</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-success">
                <div class="stat-icon"><i class="fas fa-globe"></i></div>
                <div class="stat-value text-success"><?= $onlineSubscriptions ?></div>
                <div class="stat-label">Online / Digital</div>
                <div class="stat-sub"><i class="fas fa-wifi"></i> Access anywhere</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-secondary">
                <div class="stat-icon"><i class="fas fa-print"></i></div>
                <div class="stat-value text-secondary"><?= $printSubscriptions ?></div>
                <div class="stat-label">Print / Offline</div>
                <div class="stat-sub"><i class="fas fa-book"></i> Physical copies</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-warning">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value text-warning"><?= $expectedIssues ?></div>
                <div class="stat-label">Expected Issues</div>
                <div class="stat-sub"><i class="fas fa-hourglass-half"></i> Awaiting arrival</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-danger">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-value text-danger"><?= $lateIssues ?></div>
                <div class="stat-label">Late Issues</div>
                <div class="stat-sub"><i class="fas fa-clock text-danger"></i> Overdue</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card border-start border-4 border-info">
                <div class="stat-icon"><i class="fas fa-envelope"></i></div>
                <div class="stat-value text-info"><?= $remindersSent ?></div>
                <div class="stat-label">Reminders (30 days)</div>
                <div class="stat-sub"><i class="fas fa-bell"></i> Notifications sent</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Active Subscriptions -->
        <div class="col-md-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-list text-primary"></i> Active Subscriptions</span>
                    <a href="serial_subscriptions.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Title & Type</th>
                                    <th>Frequency</th>
                                    <th>Vendor</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($activeSubsList)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                        No active subscriptions.
                                        <br><a href="serial_subscriptions.php" class="btn btn-sm btn-success mt-2">Add Subscription</a>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($activeSubsList as $sub): 
                                        $typeIcon = $typeIcons[$sub['subscription_type']] ?? 'fa-circle';
                                        $typeColor = $typeColors[$sub['subscription_type']] ?? 'secondary';
                                        $typeLabel = ucfirst($sub['subscription_type'] ?? 'print');
                                        $freqIcon = $frequencyIcons[$sub['frequency']] ?? 'fa-calendar';
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="subscription-cell">
                                                <div>
                                                    <div class="subscription-title"><?= htmlspecialchars($sub['title']) ?></div>
                                                    <div class="subscription-meta">
                                                        <?php if (!empty($sub['issn'])): ?>
                                                            ISSN: <?= htmlspecialchars($sub['issn']) ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <span class="type-badge type-badge-<?= $sub['subscription_type'] ?? 'print' ?>">
                                                        <i class="fas <?= $typeIcon ?>"></i> <?= $typeLabel ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="frequency-badge">
                                                <i class="fas <?= $freqIcon ?>"></i>
                                                <?= ucfirst($sub['frequency']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <?php if ($sub['vendor_logo_base64']): ?>
                                                    <img src="<?= $sub['vendor_logo_base64'] ?>" class="vendor-logo-small" alt="Vendor">
                                                <?php else: ?>
                                                    <div class="vendor-logo-placeholder"><i class="fas fa-truck"></i></div>
                                                <?php endif; ?>
                                                <span><?= htmlspecialchars($sub['vendor_name'] ?? '-') ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($sub['end_date']): ?>
                                                <span class="badge <?= strtotime($sub['end_date']) < time() ? 'bg-danger' : 'bg-secondary' ?>">
                                                    <?= date('d-m-Y', strtotime($sub['end_date'])) ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Ongoing</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="serial_issues.php?sub_id=<?= $sub['id'] ?>" class="btn btn-info" title="Issues">
                                                    <i class="fas fa-boxes"></i>
                                                </a>
                                                <a href="serial_subscriptions.php?edit=<?= $sub['id'] ?>" class="btn btn-warning" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Expected Issues -->
        <div class="col-md-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-hourglass-half text-warning"></i> Expected Issues</span>
                    <a href="serial_issues.php" class="btn btn-sm btn-primary">Manage Issues</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Publication</th>
                                    <th>Issue</th>
                                    <th>Published</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($expectedIssuesList)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-check-circle fa-2x mb-2 d-block text-success"></i>
                                        No expected issues. All issues are up to date!
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($expectedIssuesList as $issue): 
                                        $isLate = ($issue['date_published'] && strtotime($issue['date_published']) < strtotime('-7 days'));
                                        $statusClass = $isLate ? 'danger' : 'warning';
                                        $statusLabel = $isLate ? 'Late' : 'Expected';
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="issue-cell">
                                                <div>
                                                    <div class="subscription-title"><?= htmlspecialchars($issue['subscription_title']) ?></div>
                                                    <div class="subscription-meta">
                                                        <span class="frequency-badge">
                                                            <i class="fas fa-<?= $issue['frequency'] ?? 'calendar' ?>"></i>
                                                            <?= ucfirst($issue['frequency'] ?? '') ?>
                                                        </span>
                                                        <?php if ($issue['subscription_type'] == 'online'): ?>
                                                            <span class="type-badge type-badge-online">
                                                                <i class="fas fa-globe"></i> Online
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($issue['volume'] ?: 'Vol.') ?></strong>
                                            <br><small class="text-muted">Issue <?= htmlspecialchars($issue['issue_number']) ?></small>
                                        </td>
                                        <td>
                                            <?= $issue['date_published'] ? date('d-m-Y', strtotime($issue['date_published'])) : '—' ?>
                                            <?php if ($isLate): ?>
                                                <br><span class="badge bg-danger">Late!</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="status-badge bg-<?= $statusClass ?> text-white">
                                                <i class="fas fa-<?= $isLate ? 'exclamation-triangle' : 'clock' ?>"></i>
                                                <?= $statusLabel ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="serial_issues.php?sub_id=<?= $issue['subscription_id'] ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i> Check-in
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-2">
        <!-- Recent Reminders -->
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-bell text-info"></i> Recent Reminders Sent</span>
                    <a href="serial_reminders.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Subscription</th>
                                    <th>Sent To</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentReminders)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                        No reminders sent yet.
                                        <br><a href="serial_reminders.php" class="btn btn-sm btn-info mt-2">Send Reminder</a>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($recentReminders as $rem): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <i class="fas fa-envelope text-secondary"></i>
                                                <span><?= date('d-m-Y H:i', strtotime($rem['sent_at'])) ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($rem['subscription_title']) ?></strong>
                                        </td>
                                        <td><?= htmlspecialchars($rem['sent_to']) ?></td>
                                        <td><?= htmlspecialchars($rem['subject']) ?></td>
                                        <td>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> Sent
                                            </span>
                                            <?php if ($rem['opened_at']): ?>
                                                <span class="badge bg-info" title="Opened">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            <?php endif; ?>
                                            <?php if ($rem['clicked_at']): ?>
                                                <span class="badge bg-primary" title="Clicked">
                                                    <i class="fas fa-mouse-pointer"></i>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row g-3 mt-2">
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_vendors.php'">
                <i class="fas fa-truck text-primary"></i>
                <div class="action-label">Manage Vendors</div>
                <div class="action-desc">Add, edit, or remove vendors</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_subscriptions.php'">
                <i class="fas fa-calendar-alt text-success"></i>
                <div class="action-label">Add Subscription</div>
                <div class="action-desc">New periodical subscription</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_issues.php'">
                <i class="fas fa-boxes text-warning"></i>
                <div class="action-label">Check-in Issues</div>
                <div class="action-desc">Receive and process issues</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_reminders.php'">
                <i class="fas fa-envelope text-info"></i>
                <div class="action-label">Send Reminder</div>
                <div class="action-desc">Send missing issue reminders</div>
            </div>
        </div>
    </div>

    <!-- Quick Stats Footer -->
    <div class="row g-3 mt-3">
        <div class="col-12">
            <div class="card shadow-sm bg-light">
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-primary"><?= $activeSubscriptions ?></div>
                            <small class="text-muted">Active</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-warning"><?= $expectedIssues ?></div>
                            <small class="text-muted">Expected</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-danger"><?= $lateIssues ?></div>
                            <small class="text-muted">Late</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-info"><?= $remindersSent ?></div>
                            <small class="text-muted">Reminders</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ========== AUTO-REFRESH STATS ==========
setInterval(function() {
    location.reload();
}, 300000); // Refresh every 5 minutes

// ========== TOOLTIP INIT ==========
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N for new subscription
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'serial_subscriptions.php';
    }
    // Ctrl+V for vendors
    if (e.ctrlKey && e.key === 'v') {
        e.preventDefault();
        window.location.href = 'serial_vendors.php';
    }
    // Ctrl+I for issues
    if (e.ctrlKey && e.key === 'i') {
        e.preventDefault();
        window.location.href = 'serial_issues.php';
    }
});
</script>

<?php renderFooter(); ?>