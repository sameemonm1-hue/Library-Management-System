<?php
/**
 * Serial Control Module - Dashboard (Complete Update)
 * Manages periodicals, magazines, newspapers: subscriptions, issues, reminders
 * Features:
 * - Cover images for serial publications
 * - Enhanced statistics with visual indicators
 * - Subscription type badges with icons
 * - Issue status tracking with color coding
 * - Quick action cards with hover effects
 * - Responsive design
 * - Error handling
 * - UNIFIED GRADIENT COLOR SCHEME
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// ==================== REPORT APPEARANCE SETTINGS ====================
$settings = getSettings();
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

// ========== GET IMAGE BASE64 HELPER (IMPROVED) ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    
    // If it's a full URL, return it directly
    if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
    
    // Try multiple possible paths
    $possiblePaths = [
        $path,
        BASE_PATH . '/' . ltrim($path, '/'),
        BASE_PATH . '/uploads/' . ltrim($path, '/'),
        BASE_PATH . '/uploads/serials/' . ltrim($path, '/'),
        __DIR__ . '/../uploads/' . ltrim($path, '/'),
        __DIR__ . '/../uploads/serials/' . ltrim($path, '/'),
    ];
    
    foreach ($possiblePaths as $fullPath) {
        if (file_exists($fullPath)) {
            $data = @file_get_contents($fullPath);
            if ($data !== false) {
                $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($ext, $allowed)) {
                    return 'data:image/' . $ext . ';base64,' . base64_encode($data);
                }
            }
        }
    }
    
    // Fallback to web URL
    if (function_exists('getWebImageUrl')) {
        $url = getWebImageUrl($path);
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) return $url;
    }
    
    return null;
}

// ========== SAFE QUERY FUNCTION ==========
function safeQuery($db, $sql, $default = 0) {
    try {
        $result = $db->query($sql);
        return $result ? $result->fetchColumn() : $default;
    } catch (PDOException $e) {
        error_log("Query failed: " . $e->getMessage());
        return $default;
    }
}

// ========== STATISTICS WITH ERROR HANDLING ==========
$activeSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND (end_date IS NULL OR end_date >= date('now'))");

$onlineSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND subscription_type IN ('online','both') AND (end_date IS NULL OR end_date >= date('now'))");

$printSubscriptions = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active' AND subscription_type IN ('print','both') AND (end_date IS NULL OR end_date >= date('now'))");

$expectedIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'expected' AND date_received IS NULL");

$lateIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'expected' AND date_published < date('now', '-7 days')");

$remindersSent = safeQuery($db, "SELECT COUNT(*) FROM serial_reminders WHERE sent_at >= date('now', '-30 days')");

// ========== ACTIVE SUBSCRIPTIONS WITH COVERS ==========
try {
    $activeSubsList = $db->query("
        SELECT s.*, v.name as vendor_name, v.logo_path as vendor_logo
        FROM serial_subscriptions s 
        LEFT JOIN serial_vendors v ON s.vendor_id = v.id 
        WHERE s.status = 'active' AND (s.end_date IS NULL OR s.end_date >= date('now'))
        ORDER BY s.title LIMIT 10
    ")->fetchAll();
    
    foreach ($activeSubsList as &$sub) {
        $sub['cover_base64'] = getImageBase64($sub['cover_path'] ?? '');
        $sub['vendor_logo_base64'] = getImageBase64($sub['vendor_logo'] ?? '');
    }
} catch (PDOException $e) {
    error_log("Active subscriptions query failed: " . $e->getMessage());
    $activeSubsList = [];
}

// ========== RECENT EXPECTED ISSUES ==========
try {
    $expectedIssuesList = $db->query("
        SELECT i.*, s.title as subscription_title, s.frequency, s.subscription_type, 
               v.name as vendor_name, v.logo_path as vendor_logo
        FROM serial_issues i
        JOIN serial_subscriptions s ON i.subscription_id = s.id
        LEFT JOIN serial_vendors v ON s.vendor_id = v.id
        WHERE i.status = 'expected' AND i.date_received IS NULL
        ORDER BY i.date_published ASC LIMIT 10
    ")->fetchAll();
    
    foreach ($expectedIssuesList as &$issue) {
        $issue['vendor_logo_base64'] = getImageBase64($issue['vendor_logo'] ?? '');
    }
} catch (PDOException $e) {
    error_log("Expected issues query failed: " . $e->getMessage());
    $expectedIssuesList = [];
}

// ========== RECENT REMINDERS ==========
try {
    $recentReminders = $db->query("
        SELECT r.*, s.title as subscription_title
        FROM serial_reminders r
        JOIN serial_subscriptions s ON r.subscription_id = s.id
        ORDER BY r.sent_at DESC LIMIT 10
    ")->fetchAll();
} catch (PDOException $e) {
    error_log("Reminders query failed: " . $e->getMessage());
    $recentReminders = [];
}

// ========== STATUS COLOR MAP ==========
$statusColors = [
    'active' => 'success',
    'expired' => 'danger',
    'cancelled' => 'secondary'
];

$frequencyIcons = [
    'daily' => 'fa-calendar-day',
    'weekly' => 'fa-calendar-week',
    'biweekly' => 'fa-calendar-alt',
    'monthly' => 'fa-calendar-month',
    'bimonthly' => 'fa-calendar-alt',
    'quarterly' => 'fa-calendar-quarter',
    'halfyearly' => 'fa-calendar',
    'yearly' => 'fa-calendar-year'
];

$typeIcons = [
    'print' => 'fa-print',
    'online' => 'fa-globe',
    'both' => 'fa-exchange-alt'
];

$typeColors = [
    'print' => 'secondary',
    'online' => 'primary',
    'both' => 'success'
];

renderHeader('Serial Control Dashboard');
?>

<style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
    }
    
    /* ========== SETTINGS BAR - REMOVED ========== */
    .settings-bar {
        display: none !important;
    }

    /* ========== STAT CARDS - UNIFIED GRADIENT ========== */
    .stat-card {
        border: none;
        border-radius: 12px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        cursor: default;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    .stat-card .stat-icon {
        position: absolute;
        right: 15px;
        top: 15px;
        font-size: 32px;
        opacity: 0.2;
        color: white;
    }
    .stat-card .stat-value {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 2px;
        color: white;
    }
    .stat-card .stat-label {
        font-size: 14px;
        color: rgba(255,255,255,0.9);
    }
    .stat-card .stat-sub {
        font-size: 11px;
        color: rgba(255,255,255,0.7);
        margin-top: 4px;
    }
    .stat-card.border-start {
        border-left: none !important;
    }

    /* ========== CARD HEADERS ========== */
    .card-header.bg-white {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
        border-bottom: none !important;
    }
    .card-header.bg-white a {
        color: white !important;
    }
    .card-header.bg-white a.btn-primary {
        background: rgba(255,255,255,0.2);
        border-color: rgba(255,255,255,0.2);
        color: white;
    }
    .card-header.bg-white a.btn-primary:hover {
        background: rgba(255,255,255,0.3);
        border-color: rgba(255,255,255,0.3);
    }
    .card-header.bg-white span {
        color: white;
    }
    .card-header.bg-white .text-primary {
        color: white !important;
    }
    .card-header.bg-white .text-warning {
        color: #ffc107 !important;
    }
    .card-header.bg-white .text-info {
        color: #0dcaf0 !important;
    }

    /* ========== SERIAL COVER ========== */
    .serial-cover-small {
        width: 50px;
        height: 70px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #e9ecef;
        background: #f8f9fa;
    }
    .serial-cover-placeholder {
        width: 50px;
        height: 70px;
        border-radius: 6px;
        background: #f1f3f5;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #adb5bd;
        border: 1px solid #e9ecef;
    }

    /* ========== VENDOR LOGO ========== */
    .vendor-logo-small {
        width: 28px;
        height: 28px;
        object-fit: contain;
        border-radius: 50%;
        border: 1px solid #e9ecef;
        background: white;
        flex-shrink: 0;
    }
    .vendor-logo-placeholder {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.6rem;
        border: 1px solid #e9ecef;
        flex-shrink: 0;
    }

    /* ========== TYPE BADGE ========== */
    .type-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.65rem;
        font-weight: 600;
    }
    .type-badge-print { background: #e9ecef; color: #495057; }
    .type-badge-online { background: #cfe2ff; color: #084298; }
    .type-badge-both { background: #d1e7dd; color: #0f5132; }

    /* ========== FREQUENCY BADGE ========== */
    .frequency-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.6rem;
        background: #f8f9fa;
        color: #495057;
        border: 1px solid #e9ecef;
    }

    /* ========== STATUS BADGE ========== */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 12px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 600;
    }

    /* ========== SUBSCRIPTION CELL ========== */
    .subscription-cell {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .subscription-info {
        flex: 1;
    }
    .subscription-title {
        font-weight: 600;
        font-size: 0.9rem;
    }
    .subscription-meta {
        font-size: 0.7rem;
        color: #6c757d;
    }

    /* ========== ISSUE CELL ========== */
    .issue-cell {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .issue-info {
        flex: 1;
    }

    /* ========== QUICK ACTION CARD ========== */
    .quick-action-card {
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        border: 1px solid #e9ecef;
        background: white;
        height: 100%;
    }
    .quick-action-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        border-color: var(--primary-color);
    }
    .quick-action-card i {
        font-size: 28px;
        margin-bottom: 10px;
        display: block;
        color: var(--primary-color);
    }
    .quick-action-card .action-label {
        font-weight: 600;
        font-size: 0.85rem;
    }
    .quick-action-card .action-desc {
        font-size: 0.7rem;
        color: #6c757d;
    }

    /* ========== TABLE STYLES ========== */
    .table thead th {
        background: var(--primary-color);
        color: white;
        font-weight: 600;
        border-bottom: none;
        white-space: nowrap;
        padding: 10px 12px;
    }
    .table td {
        padding: 10px 12px;
        vertical-align: middle;
    }
    .table tbody tr:hover {
        background: #f8f9fa;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .stat-card .stat-value { font-size: 22px; }
        .stat-card { padding: 15px; }
        .stat-card .stat-icon { font-size: 28px; }
        .quick-action-card { padding: 15px; }
        .quick-action-card i { font-size: 22px; }
        .vendor-logo-small { width: 22px; height: 22px; }
        .serial-cover-small { width: 40px; height: 56px; }
        .table-responsive { font-size: 0.8rem; }
        .type-badge { font-size: 0.55rem; padding: 1px 6px; }
        .frequency-badge { font-size: 0.5rem; padding: 1px 6px; }
    }

    @media (max-width: 576px) {
        .table-responsive { font-size: 0.75rem; }
        .stat-card .stat-value { font-size: 18px; }
        .stat-card .stat-label { font-size: 11px; }
        .stat-card .stat-sub { font-size: 9px; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .settings-bar { display: none !important; }
        .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
        .stat-card .stat-value { color: #333 !important; }
        .stat-card .stat-label { color: #555 !important; }
        .stat-card .stat-sub { color: #777 !important; }
        .stat-card .stat-icon { display: none !important; }
        .card-header.bg-white { background: #f8f9fa !important; color: #333 !important; }
        .table thead th { background: #333 !important; color: white !important; }
        .quick-action-card { border: 1px solid #ddd !important; }
        .quick-action-card i { color: #333 !important; }
    }
</style>

<div class="container-fluid px-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color);"><i class="fas fa-newspaper"></i> Serial Control Dashboard</h2>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary btn-sm">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="serial_subscriptions.php" class="btn btn-success btn-sm">
                <i class="fas fa-plus"></i> New Subscription
            </a>
            <a href="serial_vendors.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-truck"></i> Vendors
            </a>
            <a href="serial_issues.php" class="btn btn-outline-info btn-sm">
                <i class="fas fa-boxes"></i> All Issues
            </a>
        </div>
    </div>

    <!-- ========== STATISTICS CARDS - UNIFIED GRADIENT ========== -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
                <div class="stat-value"><?= $activeSubscriptions ?></div>
                <div class="stat-label">Active Subscriptions</div>
                <div class="stat-sub"><i class="fas fa-check-circle"></i> Current</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-globe"></i></div>
                <div class="stat-value"><?= $onlineSubscriptions ?></div>
                <div class="stat-label">Online / Digital</div>
                <div class="stat-sub"><i class="fas fa-wifi"></i> Access anywhere</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-print"></i></div>
                <div class="stat-value"><?= $printSubscriptions ?></div>
                <div class="stat-label">Print / Offline</div>
                <div class="stat-sub"><i class="fas fa-book"></i> Physical copies</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= $expectedIssues ?></div>
                <div class="stat-label">Expected Issues</div>
                <div class="stat-sub"><i class="fas fa-hourglass-half"></i> Awaiting arrival</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-value"><?= $lateIssues ?></div>
                <div class="stat-label">Late Issues</div>
                <div class="stat-sub"><i class="fas fa-clock"></i> Overdue</div>
            </div>
        </div>
        <div class="col-md-2 col-6">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-envelope"></i></div>
                <div class="stat-value"><?= $remindersSent ?></div>
                <div class="stat-label">Reminders (30 days)</div>
                <div class="stat-sub"><i class="fas fa-bell"></i> Notifications sent</div>
            </div>
        </div>
    </div>

    <!-- ========== ACTIVE SUBSCRIPTIONS & EXPECTED ISSUES ========== -->
    <div class="row g-4">
        <!-- Active Subscriptions -->
        <div class="col-md-6">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-list"></i> Active Subscriptions</span>
                    <a href="serial_subscriptions.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Cover</th>
                                    <th>Title & Type</th>
                                    <th>Frequency</th>
                                    <th>Vendor</th>
                                    <th>End Date</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($activeSubsList)): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                        No active subscriptions.
                                        <br><a href="serial_subscriptions.php" class="btn btn-sm btn-success mt-2">Add Subscription</a>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($activeSubsList as $sub): 
                                        $typeIcon = $typeIcons[$sub['subscription_type']] ?? 'fa-circle';
                                        $typeColor = $typeColors[$sub['subscription_type']] ?? 'secondary';
                                        $typeLabel = ucfirst($sub['subscription_type'] ?? 'print');
                                        $freqIcon = $frequencyIcons[$sub['frequency']] ?? 'fa-calendar';
                                        $coverImg = $sub['cover_base64'] ?? null;
                                    ?>
                                    <tr>
                                        <td>
                                            <?php if ($coverImg && strpos($coverImg, 'data:image') === 0 && strlen($coverImg) > 100): ?>
                                                <img src="<?= htmlspecialchars($coverImg) ?>" class="serial-cover-small" alt="Cover">
                                            <?php else: ?>
                                                <div class="serial-cover-placeholder"><i class="fas fa-newspaper"></i></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="subscription-cell">
                                                <div>
                                                    <div class="subscription-title"><?= htmlspecialchars($sub['title']) ?></div>
                                                    <div class="subscription-meta">
                                                        <?php if (!empty($sub['issn'])): ?>
                                                            ISSN: <?= htmlspecialchars($sub['issn']) ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <span class="type-badge type-badge-<?= $sub['subscription_type'] ?? 'print' ?>">
                                                        <i class="fas <?= $typeIcon ?>"></i> <?= $typeLabel ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="frequency-badge">
                                                <i class="fas <?= $freqIcon ?>"></i>
                                                <?= ucfirst($sub['frequency']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <?php if ($sub['vendor_logo_base64']): ?>
                                                    <img src="<?= $sub['vendor_logo_base64'] ?>" class="vendor-logo-small" alt="Vendor">
                                                <?php else: ?>
                                                    <div class="vendor-logo-placeholder"><i class="fas fa-truck"></i></div>
                                                <?php endif; ?>
                                                <span><?= htmlspecialchars($sub['vendor_name'] ?? '-') ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($sub['end_date']): ?>
                                                <span class="badge <?= strtotime($sub['end_date']) < time() ? 'bg-danger' : 'bg-secondary' ?>">
                                                    <?= date('d-m-Y', strtotime($sub['end_date'])) ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Ongoing</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group btn-group-sm">
                                                <a href="serial_issues.php?sub_id=<?= $sub['id'] ?>" class="btn btn-info btn-sm" title="Issues">
                                                    <i class="fas fa-boxes"></i>
                                                </a>
                                                <a href="serial_subscriptions.php?edit=<?= $sub['id'] ?>" class="btn btn-warning btn-sm" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Expected Issues -->
        <div class="col-md-6">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-hourglass-half"></i> Expected Issues</span>
                    <a href="serial_issues.php" class="btn btn-sm btn-primary">Manage Issues</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Publication</th>
                                    <th>Issue</th>
                                    <th>Published</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($expectedIssuesList)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-check-circle fa-2x mb-2 d-block text-success"></i>
                                        No expected issues. All issues are up to date!
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($expectedIssuesList as $issue): 
                                        $isLate = ($issue['date_published'] && strtotime($issue['date_published']) < strtotime('-7 days'));
                                        $statusClass = $isLate ? 'danger' : 'warning';
                                        $statusLabel = $isLate ? 'Late' : 'Expected';
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="issue-cell">
                                                <div>
                                                    <div class="subscription-title"><?= htmlspecialchars($issue['subscription_title']) ?></div>
                                                    <div class="subscription-meta">
                                                        <span class="frequency-badge">
                                                            <i class="fas fa-<?= $issue['frequency'] ?? 'calendar' ?>"></i>
                                                            <?= ucfirst($issue['frequency'] ?? '') ?>
                                                        </span>
                                                        <?php if ($issue['subscription_type'] == 'online'): ?>
                                                            <span class="type-badge type-badge-online">
                                                                <i class="fas fa-globe"></i> Online
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($issue['volume'] ?: 'Vol.') ?></strong>
                                            <br><small class="text-muted">Issue <?= htmlspecialchars($issue['issue_number']) ?></small>
                                        </td>
                                        <td>
                                            <?= $issue['date_published'] ? date('d-m-Y', strtotime($issue['date_published'])) : '—' ?>
                                            <?php if ($isLate): ?>
                                                <br><span class="badge bg-danger">Late!</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="status-badge bg-<?= $statusClass ?> text-white">
                                                <i class="fas fa-<?= $isLate ? 'exclamation-triangle' : 'clock' ?>"></i>
                                                <?= $statusLabel ?>
                                            </span>
                                        </td>
                                        <td class="text-center">
                                            <a href="serial_issues.php?sub_id=<?= $issue['subscription_id'] ?>" class="btn btn-sm btn-success">
                                                <i class="fas fa-check"></i> Check-in
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== RECENT REMINDERS ========== -->
    <div class="row g-4 mt-2">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center flex-wrap">
                    <span><i class="fas fa-bell"></i> Recent Reminders Sent</span>
                    <a href="serial_reminders.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Subscription</th>
                                    <th>Sent To</th>
                                    <th>Subject</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentReminders)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                        No reminders sent yet.
                                        <br><a href="serial_reminders.php" class="btn btn-sm btn-info mt-2">Send Reminder</a>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($recentReminders as $rem): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <i class="fas fa-envelope text-secondary"></i>
                                                <span><?= date('d-m-Y H:i', strtotime($rem['sent_at'])) ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($rem['subscription_title']) ?></strong>
                                        </td>
                                        <td><?= htmlspecialchars($rem['sent_to']) ?></td>
                                        <td><?= htmlspecialchars($rem['subject']) ?></td>
                                        <td>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> Sent
                                            </span>
                                            <?php if ($rem['opened_at']): ?>
                                                <span class="badge bg-info" title="Opened">
                                                    <i class="fas fa-eye"></i>
                                                </span>
                                            <?php endif; ?>
                                            <?php if ($rem['clicked_at']): ?>
                                                <span class="badge bg-primary" title="Clicked">
                                                    <i class="fas fa-mouse-pointer"></i>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== QUICK ACTIONS ========== -->
    <div class="row g-3 mt-2 no-print">
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_vendors.php'">
                <i class="fas fa-truck"></i>
                <div class="action-label">Manage Vendors</div>
                <div class="action-desc">Add, edit, or remove vendors</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_subscriptions.php'">
                <i class="fas fa-calendar-alt"></i>
                <div class="action-label">Add Subscription</div>
                <div class="action-desc">New periodical subscription</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_issues.php'">
                <i class="fas fa-boxes"></i>
                <div class="action-label">Check-in Issues</div>
                <div class="action-desc">Receive and process issues</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='serial_reminders.php'">
                <i class="fas fa-envelope"></i>
                <div class="action-label">Send Reminder</div>
                <div class="action-desc">Send missing issue reminders</div>
            </div>
        </div>
    </div>

    <!-- ========== QUICK STATS FOOTER ========== -->
    <div class="row g-3 mt-3 no-print">
        <div class="col-12">
            <div class="card shadow-sm border-0 bg-light">
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3 col-6">
                            <div class="fw-bold" style="color: var(--primary-color);"><?= $activeSubscriptions ?></div>
                            <small class="text-muted">Active</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-warning"><?= $expectedIssues ?></div>
                            <small class="text-muted">Expected</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-danger"><?= $lateIssues ?></div>
                            <small class="text-muted">Late</small>
                        </div>
                        <div class="col-md-3 col-6">
                            <div class="fw-bold text-info"><?= $remindersSent ?></div>
                            <small class="text-muted">Reminders</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// ========== AUTO-REFRESH STATS ==========
setInterval(function() {
    location.reload();
}, 300000); // Refresh every 5 minutes

// ========== TOOLTIP INIT ==========
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N for new subscription
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'serial_subscriptions.php';
    }
    // Ctrl+V for vendors
    if (e.ctrlKey && e.key === 'v') {
        e.preventDefault();
        window.location.href = 'serial_vendors.php';
    }
    // Ctrl+I for issues
    if (e.ctrlKey && e.key === 'i') {
        e.preventDefault();
        window.location.href = 'serial_issues.php';
    }
});
</script>

<?php renderFooter(); ?>