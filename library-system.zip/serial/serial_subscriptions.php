<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();

// Ensure cover_path column exists
$cols = $db->query("PRAGMA table_info(serial_subscriptions)")->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('cover_path', $cols)) {
    $db->exec("ALTER TABLE serial_subscriptions ADD COLUMN cover_path TEXT DEFAULT ''");
}

// Helper function to handle cover image upload
function handleCoverUpload($file, $existingPath = null) {
    if (empty($file) || $file['error'] !== UPLOAD_ERR_OK) {
        // If no new file, keep existing path
        return $existingPath;
    }
    // Validate file type
    $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, $allowed)) {
        $_SESSION['toast'] = ['message' => 'Only JPG, PNG, GIF, WEBP images allowed.', 'type' => 'danger'];
        return $existingPath;
    }
    // Create upload directory if missing
    $uploadDir = BASE_PATH . '/uploads/serials/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    
    // Generate unique filename
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'serial_' . time() . '_' . uniqid() . '.' . $ext;
    $targetPath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        chmod($targetPath, 0644);
        // Delete old cover if exists
        if ($existingPath && file_exists(BASE_PATH . '/' . $existingPath)) {
            @unlink(BASE_PATH . '/' . $existingPath);
        }
        // Return relative path from BASE_PATH (e.g., "uploads/serials/filename.jpg")
        return 'uploads/serials/' . $filename;
    }
    $_SESSION['toast'] = ['message' => 'Failed to upload image.', 'type' => 'danger'];
    return $existingPath;
}

$editSub = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM serial_subscriptions WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editSub = $stmt->fetch();
}

// Add / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: serial_subscriptions.php");
        exit;
    }
    try {
        if (isset($_POST['add_subscription'])) {
            // Handle cover upload
            $coverPath = handleCoverUpload($_FILES['cover_image'] ?? null);
            
            $stmt = $db->prepare("INSERT INTO serial_subscriptions 
                (title, issn, frequency, vendor_id, start_date, end_date, cost, location, routing_list, notes, status, 
                 subscription_type, access_url, access_credentials, digital_format, cover_path) 
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([
                $_POST['title'], $_POST['issn'], $_POST['frequency'], $_POST['vendor_id'] ?: null,
                $_POST['start_date'], $_POST['end_date'] ?: null, $_POST['cost'] ?: null,
                $_POST['location'], $_POST['routing_list'], $_POST['notes'], $_POST['status'],
                $_POST['subscription_type'], $_POST['access_url'], $_POST['access_credentials'], $_POST['digital_format'],
                $coverPath
            ]);
            showToast("Subscription added", "success");
            logActivity($_SESSION['username'], 'SERIAL_SUB_ADD', "Added subscription: {$_POST['title']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: serial_subscriptions.php");
            exit;
        }
        elseif (isset($_POST['update_subscription'])) {
            // Handle cover upload
            $coverPath = null;
            if (isset($_POST['remove_cover']) && $_POST['remove_cover'] == '1') {
                // Delete existing cover
                if ($editSub && $editSub['cover_path'] && file_exists(BASE_PATH . '/' . $editSub['cover_path'])) {
                    @unlink(BASE_PATH . '/' . $editSub['cover_path']);
                }
                $coverPath = '';
            } else {
                $coverPath = handleCoverUpload($_FILES['cover_image'] ?? null, $editSub['cover_path'] ?? null);
            }
            
            $stmt = $db->prepare("UPDATE serial_subscriptions SET 
                title=?, issn=?, frequency=?, vendor_id=?, start_date=?, end_date=?, cost=?, 
                location=?, routing_list=?, notes=?, status=?, subscription_type=?, 
                access_url=?, access_credentials=?, digital_format=?, cover_path=? 
                WHERE id=?");
            $stmt->execute([
                $_POST['title'], $_POST['issn'], $_POST['frequency'], $_POST['vendor_id'] ?: null,
                $_POST['start_date'], $_POST['end_date'] ?: null, $_POST['cost'] ?: null,
                $_POST['location'], $_POST['routing_list'], $_POST['notes'], $_POST['status'],
                $_POST['subscription_type'], $_POST['access_url'], $_POST['access_credentials'], $_POST['digital_format'],
                $coverPath,
                $_POST['id']
            ]);
            showToast("Subscription updated", "success");
            logActivity($_SESSION['username'], 'SERIAL_SUB_UPDATE', "Updated subscription ID {$_POST['id']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: serial_subscriptions.php");
            exit;
        }
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// Delete (with CSRF token check)
if (isset($_GET['delete'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        // Get cover path before deleting
        $stmt = $db->prepare("SELECT cover_path FROM serial_subscriptions WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        $sub = $stmt->fetch();
        if ($sub && $sub['cover_path'] && file_exists(BASE_PATH . '/' . $sub['cover_path'])) {
            @unlink(BASE_PATH . '/' . $sub['cover_path']);
        }
        $stmt = $db->prepare("DELETE FROM serial_subscriptions WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        showToast("Subscription deleted", "success");
        logActivity($_SESSION['username'], 'SERIAL_SUB_DELETE', "Deleted subscription ID {$_GET['delete']}");
    }
    header("Location: serial_subscriptions.php");
    exit;
}

$subscriptions = $db->query("SELECT s.*, v.name as vendor_name FROM serial_subscriptions s LEFT JOIN serial_vendors v ON s.vendor_id = v.id ORDER BY s.title")->fetchAll();
$vendors = $db->query("SELECT id, name FROM serial_vendors ORDER BY name")->fetchAll();

renderHeader('Serial Subscriptions');
?>
<style>
/* Preview image styling */
.cover-preview {
    max-width: 120px;
    max-height: 160px;
    border-radius: 8px;
    border: 1px solid #dee2e6;
    padding: 4px;
    background: #f8f9fa;
}
.cover-preview-placeholder {
    width: 120px;
    height: 160px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f1f3f5;
    border-radius: 8px;
    color: #adb5bd;
    border: 1px dashed #ced4da;
    font-size: 0.8rem;
}
</style>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-calendar-alt"></i> Serial Subscriptions</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSubModal"><i class="fas fa-plus"></i> Add Subscription</button>
    </div>
    <div class="card">
        <div class="card-header"><i class="fas fa-list"></i> Subscriptions</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr><th>Cover</th><th>Title</th><th>Type</th><th>Frequency</th><th>Vendor</th><th>Start Date</th><th>End Date</th><th>Status</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subscriptions as $sub): ?>
                        <tr>
                            <td>
                                <?php if (!empty($sub['cover_path']) && file_exists(BASE_PATH . '/' . $sub['cover_path'])): ?>
                                    <img src="<?= htmlspecialchars(getWebImageUrl($sub['cover_path'])) ?>" class="cover-preview" alt="Cover">
                                <?php else: ?>
                                    <div class="cover-preview-placeholder"><i class="fas fa-newspaper fa-2x"></i></div>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($sub['title']) ?></td>
                            <td>
                                <?php if ($sub['subscription_type'] == 'online'): ?>
                                    <span class="badge bg-info">Online</span>
                                <?php elseif ($sub['subscription_type'] == 'both'): ?>
                                    <span class="badge bg-secondary">Print+Online</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Print</span>
                                <?php endif; ?>
                            </td>
                            <td><?= ucfirst($sub['frequency']) ?></td>
                            <td><?= htmlspecialchars($sub['vendor_name'] ?? '-') ?></td>
                            <td><?= $sub['start_date'] ?></td>
                            <td><?= $sub['end_date'] ?? 'Ongoing' ?></td>
                            <td><span class="badge bg-<?= $sub['status']=='active'?'success':'secondary' ?>"><?= ucfirst($sub['status']) ?></span></td>
                            <td>
                                <a href="serial_issues.php?sub_id=<?= $sub['id'] ?>" class="btn btn-sm btn-info"><i class="fas fa-boxes"></i> Issues</a>
                                <a href="?edit=<?= $sub['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $sub['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete subscription? All issues will be deleted.')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Subscription Modal -->
<div class="modal fade" id="addSubModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5>Add Subscription</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-2"><label>Title *</label><input type="text" name="title" class="form-control" required></div>
                        <div class="col-md-6 mb-2"><label>ISSN</label><input type="text" name="issn" class="form-control" placeholder="1234-5678"></div>
                        <div class="col-md-4 mb-2"><label>Frequency</label><select name="frequency" class="form-select" required>
                            <option>daily</option><option>weekly</option><option>biweekly</option>
                            <option>monthly</option><option>bimonthly</option><option>quarterly</option>
                            <option>halfyearly</option><option>yearly</option>
                        </select></div>
                        <div class="col-md-4 mb-2"><label>Subscription Type</label>
                            <select name="subscription_type" class="form-select" id="subType">
                                <option value="print">Print (Offline)</option>
                                <option value="online">Online (Digital)</option>
                                <option value="both">Both Print & Online</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-2"><label>Vendor</label><select name="vendor_id" class="form-select"><option value="">-- None --</option><?php foreach($vendors as $v): ?><option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['name']) ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-4 mb-2"><label>Cost</label><input type="number" step="0.01" name="cost" class="form-control" placeholder="0.00"></div>
                        <div class="col-md-3 mb-2"><label>Start Date</label><input type="date" name="start_date" class="form-control" required></div>
                        <div class="col-md-3 mb-2"><label>End Date</label><input type="date" name="end_date" class="form-control"></div>
                        <div class="col-md-6 mb-2"><label>Location (Rack/Shelf)</label><input type="text" name="location" class="form-control"></div>
                        
                        <!-- Cover image upload + Take Photo -->
                        <div class="col-md-12 mb-2">
                            <label>Cover Image</label>
                            <div class="input-group">
                                <input type="file" name="cover_image" id="coverImageAdd" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
                                <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('coverImageAdd').click();">
                                    <i class="fas fa-folder-open"></i> Browse
                                </button>
                                <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('coverImageAdd').setAttribute('capture', 'environment'); document.getElementById('coverImageAdd').click();">
                                    <i class="fas fa-camera"></i> Take Photo
                                </button>
                            </div>
                            <div class="mt-2" id="coverPreviewAdd">
                                <img id="previewAdd" style="display:none; max-width:120px; max-height:160px; border-radius:8px; border:1px solid #ddd; padding:4px;">
                            </div>
                        </div>
                        
                        <!-- Online subscription fields (hidden initially) -->
                        <div id="onlineFields" style="display:none;">
                            <div class="col-md-12 mb-2"><label>Access URL</label><input type="url" name="access_url" class="form-control" placeholder="https://..."></div>
                            <div class="col-md-12 mb-2"><label>Access Credentials</label><textarea name="access_credentials" class="form-control" rows="2" placeholder="Username: ...&#10;Password: ..."></textarea></div>
                            <div class="col-md-6 mb-2"><label>Digital Format</label><input type="text" name="digital_format" class="form-control" placeholder="PDF, EPUB, HTML"></div>
                        </div>
                        
                        <div class="col-md-12 mb-2"><label>Routing List</label><textarea name="routing_list" class="form-control" rows="2" placeholder="John, Sarah, Library Desk"></textarea></div>
                        <div class="col-md-6 mb-2"><label>Status</label><select name="status" class="form-select"><option value="active">Active</option><option value="expired">Expired</option><option value="cancelled">Cancelled</option></select></div>
                        <div class="col-md-12 mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" name="add_subscription" class="btn btn-primary">Save</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<?php if ($editSub): ?>
<div class="modal fade show" id="editSubModal" tabindex="-1" style="display:block;background:rgba(0,0,0,0.5)">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning"><h5>Edit Subscription</h5><a href="serial_subscriptions.php" class="btn-close"></a></div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $editSub['id'] ?>">
                    <div class="row">
                        <div class="col-md-6 mb-2"><label>Title *</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($editSub['title']) ?>" required></div>
                        <div class="col-md-6 mb-2"><label>ISSN</label><input type="text" name="issn" class="form-control" value="<?= htmlspecialchars($editSub['issn'] ?? '') ?>"></div>
                        <div class="col-md-4 mb-2"><label>Frequency</label><select name="frequency" class="form-select">
                            <?php $freqs = ['daily','weekly','biweekly','monthly','bimonthly','quarterly','halfyearly','yearly']; foreach($freqs as $f): ?>
                            <option <?= $editSub['frequency']==$f?'selected':'' ?>><?= $f ?></option>
                            <?php endforeach; ?>
                        </select></div>
                        <div class="col-md-4 mb-2"><label>Subscription Type</label>
                            <select name="subscription_type" class="form-select" id="editSubType">
                                <option value="print" <?= $editSub['subscription_type']=='print'?'selected':'' ?>>Print</option>
                                <option value="online" <?= $editSub['subscription_type']=='online'?'selected':'' ?>>Online</option>
                                <option value="both" <?= $editSub['subscription_type']=='both'?'selected':'' ?>>Both</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-2"><label>Vendor</label><select name="vendor_id" class="form-select"><option value="">-- None --</option><?php foreach($vendors as $v): ?><option value="<?= $v['id'] ?>" <?= $editSub['vendor_id']==$v['id']?'selected':'' ?>><?= htmlspecialchars($v['name']) ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-4 mb-2"><label>Cost</label><input type="number" step="0.01" name="cost" class="form-control" value="<?= $editSub['cost'] ?>"></div>
                        <div class="col-md-3 mb-2"><label>Start Date</label><input type="date" name="start_date" class="form-control" value="<?= $editSub['start_date'] ?>" required></div>
                        <div class="col-md-3 mb-2"><label>End Date</label><input type="date" name="end_date" class="form-control" value="<?= $editSub['end_date'] ?>"></div>
                        <div class="col-md-6 mb-2"><label>Location</label><input type="text" name="location" class="form-control" value="<?= htmlspecialchars($editSub['location'] ?? '') ?>"></div>
                        
                        <!-- Cover image preview and upload -->
                        <div class="col-md-12 mb-2">
                            <label>Cover Image</label>
                            <?php if (!empty($editSub['cover_path']) && file_exists(BASE_PATH . '/' . $editSub['cover_path'])): ?>
                                <div class="mb-2">
                                    <img src="<?= htmlspecialchars(getWebImageUrl($editSub['cover_path'])) ?>" class="cover-preview" alt="Current cover">
                                    <div class="form-check mt-1">
                                        <input type="checkbox" name="remove_cover" value="1" id="removeCoverCheck" class="form-check-input">
                                        <label for="removeCoverCheck" class="form-check-label">Remove current cover image</label>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="input-group">
                                <input type="file" name="cover_image" id="coverImageEdit" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
                                <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('coverImageEdit').click();">
                                    <i class="fas fa-folder-open"></i> Browse
                                </button>
                                <button type="button" class="btn btn-outline-primary" onclick="document.getElementById('coverImageEdit').setAttribute('capture', 'environment'); document.getElementById('coverImageEdit').click();">
                                    <i class="fas fa-camera"></i> Take Photo
                                </button>
                            </div>
                            <div class="mt-2" id="coverPreviewEdit">
                                <img id="previewEdit" style="display:none; max-width:120px; max-height:160px; border-radius:8px; border:1px solid #ddd; padding:4px;">
                            </div>
                        </div>
                        
                        <!-- Online fields -->
                        <div id="editOnlineFields" style="display:<?= ($editSub['subscription_type']!='print')?'block':'none' ?>;">
                            <div class="col-md-12 mb-2"><label>Access URL</label><input type="url" name="access_url" class="form-control" value="<?= htmlspecialchars($editSub['access_url'] ?? '') ?>"></div>
                            <div class="col-md-12 mb-2"><label>Access Credentials</label><textarea name="access_credentials" class="form-control" rows="2"><?= htmlspecialchars($editSub['access_credentials'] ?? '') ?></textarea></div>
                            <div class="col-md-6 mb-2"><label>Digital Format</label><input type="text" name="digital_format" class="form-control" value="<?= htmlspecialchars($editSub['digital_format'] ?? '') ?>"></div>
                        </div>
                        
                        <div class="col-md-12 mb-2"><label>Routing List</label><textarea name="routing_list" class="form-control" rows="2"><?= htmlspecialchars($editSub['routing_list'] ?? '') ?></textarea></div>
                        <div class="col-md-6 mb-2"><label>Status</label><select name="status" class="form-select"><option value="active" <?= $editSub['status']=='active'?'selected':'' ?>>Active</option><option value="expired" <?= $editSub['status']=='expired'?'selected':'' ?>>Expired</option><option value="cancelled" <?= $editSub['status']=='cancelled'?'selected':'' ?>>Cancelled</option></select></div>
                        <div class="col-md-12 mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editSub['notes'] ?? '') ?></textarea></div>
                    </div>
                </div>
                <div class="modal-footer"><a href="serial_subscriptions.php" class="btn btn-secondary">Cancel</a><button type="submit" name="update_subscription" class="btn btn-primary">Update</button></div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Show/hide online fields based on subscription type
document.getElementById('subType')?.addEventListener('change', function() {
    document.getElementById('onlineFields').style.display = (this.value != 'print') ? 'block' : 'none';
});
document.getElementById('editSubType')?.addEventListener('change', function() {
    document.getElementById('editOnlineFields').style.display = (this.value != 'print') ? 'block' : 'none';
});

// Preview selected image for Add modal
document.getElementById('coverImageAdd')?.addEventListener('change', function(e) {
    const preview = document.getElementById('previewAdd');
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(ev) {
            preview.src = ev.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(this.files[0]);
    } else {
        preview.style.display = 'none';
    }
});

// Preview selected image for Edit modal
document.getElementById('coverImageEdit')?.addEventListener('change', function(e) {
    const preview = document.getElementById('previewEdit');
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(ev) {
            preview.src = ev.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(this.files[0]);
    } else {
        preview.style.display = 'none';
    }
});

// Handle "Take Photo" button: set capture attribute and trigger file input
document.querySelectorAll('[onclick*="setAttribute(\'capture\'"]').forEach(btn => {
    // Already handled inline via onclick
});
</script>

<?php renderFooter(); ?>