<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();

// Send reminder (from issues page or manual)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reminder'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: serial_reminders.php");
        exit;
    }

    $subscription_id = $_POST['subscription_id'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // Get vendor email from subscription
    $stmt = $db->prepare("SELECT v.email, v.name as vendor_name, s.title 
                          FROM serial_subscriptions s 
                          LEFT JOIN serial_vendors v ON s.vendor_id = v.id 
                          WHERE s.id = ?");
    $stmt->execute([$subscription_id]);
    $sub = $stmt->fetch();
    
    if ($sub && $sub['email']) {
        $to = $sub['email'];
        $headers = "From: " . (LIBRARY_EMAIL ?? 'noreply@library.com') . "\r\n";
        // Use mail() or PHPMailer
        $mailSent = mail($to, $subject, $message, $headers);
        
        // Log reminder
        $stmt2 = $db->prepare("INSERT INTO serial_reminders (subscription_id, reminder_type, sent_to, subject, message) VALUES (?, 'missing_issue', ?, ?, ?)");
        $stmt2->execute([$subscription_id, $to, $subject, $message]);
        
        if ($mailSent) {
            showToast("Reminder sent to {$sub['vendor_name']} ({$to})", "success");
        } else {
            showToast("Failed to send email. Check server mail settings.", "danger");
        }
        logActivity($_SESSION['username'], 'SERIAL_REMINDER_SENT', "Reminder sent for subscription ID $subscription_id");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        showToast("No email address found for this vendor.", "warning");
    }
    header("Location: serial_reminders.php");
    exit;
}

// List all reminders
$reminders = $db->query("SELECT r.*, s.title as subscription_title 
                         FROM serial_reminders r 
                         LEFT JOIN serial_subscriptions s ON r.subscription_id = s.id 
                         ORDER BY r.sent_at DESC")->fetchAll();

renderHeader('Serial Reminders');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-bell"></i> Vendor Reminders Log</h2>
        <a href="serial_subscriptions.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>

    <div class="card">
        <div class="card-header"><i class="fas fa-history"></i> Sent Reminders</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr><th>Date</th><th>Subscription</th><th>Sent To</th><th>Subject</th><th>Message</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reminders as $r): ?>
                        <tr>
                            <td><?= $r['sent_at'] ?> </div>
                            <td><?= htmlspecialchars($r['subscription_title'] ?? 'Deleted') ?> </div>
                            <td><?= htmlspecialchars($r['sent_to']) ?> </div>
                            <td><?= htmlspecialchars($r['subject']) ?> </div>
                            <td><?= nl2br(htmlspecialchars(substr($r['message'],0,100))) ?>... </div>
                         </div>
                        <?php endforeach; ?>
                        <?php if (empty($reminders)): ?>
                        <tr><td colspan="5">No reminders sent yet.</div></tr>
                        <?php endif; ?>
                    </tbody>
                 </div>
            </div>
        </div>
    </div>
</div>
<?php renderFooter(); ?>