<?php
// cron_generate_daily_issues.php - Run daily to create expected issues for all active daily subscriptions
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/functions.php';

$db = getDB();

// Get all active daily subscriptions
$stmt = $db->query("SELECT id FROM serial_subscriptions WHERE frequency = 'daily' AND status = 'active' AND (end_date IS NULL OR end_date >= date('now'))");
$subscriptions = $stmt->fetchAll();

$today = date('Y-m-d');
$nextWeek = date('Y-m-d', strtotime('+7 days'));

$totalGenerated = 0;
foreach ($subscriptions as $sub) {
    $generated = generateIssuesForDateRange($db, $sub['id'], $today, $nextWeek);
    $totalGenerated += $generated;
}

error_log("Cron: Generated $totalGenerated daily issues for " . count($subscriptions) . " subscriptions");
echo "Done. Generated $totalGenerated issues.\n";

// The helper function must be available; include the same function from serial_issues.php or duplicate it here.
// For clarity, copy the generateIssuesForDateRange function here or require the file.
function generateIssuesForDateRange($db, $subscription_id, $from_date, $to_date) {
    $generated = 0;
    $current = new DateTime($from_date);
    $end = new DateTime($to_date);
    $end->modify('+1 day');
    $existingStmt = $db->prepare("SELECT date_published FROM serial_issues WHERE subscription_id = ? AND date_published IS NOT NULL");
    $existingStmt->execute([$subscription_id]);
    $existingDates = $existingStmt->fetchAll(PDO::FETCH_COLUMN);
    while ($current < $end) {
        $dateStr = $current->format('Y-m-d');
        if (!in_array($dateStr, $existingDates)) {
            $issueNumber = $current->format('Ymd');
            $stmt = $db->prepare("INSERT INTO serial_issues (subscription_id, issue_number, date_published, status) VALUES (?, ?, ?, 'expected')");
            $stmt->execute([$subscription_id, $issueNumber, $dateStr]);
            $generated++;
        }
        $current->modify('+1 day');
    }
    return $generated;
}
?>