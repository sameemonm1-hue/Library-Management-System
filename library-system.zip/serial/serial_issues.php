<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$subscription_id = $_GET['sub_id'] ?? 0;
$subscription = null;
if ($subscription_id) {
    $stmt = $db->prepare("SELECT * FROM serial_subscriptions WHERE id = ?");
    $stmt->execute([$subscription_id]);
    $subscription = $stmt->fetch();
    if (!$subscription) die("Invalid subscription");
}

// ------------------------------------------------------------
// 1. Receive an issue (check-in) – used for print or after online access
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['receive_issue'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        $issue_id = $_POST['issue_id'];
        $date_received = date('Y-m-d');
        $stmt = $db->prepare("UPDATE serial_issues SET date_received = ?, status = 'received' WHERE id = ?");
        $stmt->execute([$date_received, $issue_id]);
        showToast("Issue received", "success");
        logActivity($_SESSION['username'], 'SERIAL_ISSUE_RECEIVE', "Received issue ID $issue_id");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// ------------------------------------------------------------
// 2. Update status (claimed, missing, late)
// ------------------------------------------------------------
if (isset($_POST['update_status'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        $stmt = $db->prepare("UPDATE serial_issues SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['issue_id']]);
        showToast("Status updated", "success");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// ------------------------------------------------------------
// 3. Add a single expected issue (manual)
// ------------------------------------------------------------
if (isset($_POST['add_issue'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        $stmt = $db->prepare("INSERT INTO serial_issues (subscription_id, volume, issue_number, date_published, status) VALUES (?,?,?,?,?)");
        $stmt->execute([$subscription_id, $_POST['volume'], $_POST['issue_number'], $_POST['date_published'], 'expected']);
        showToast("Issue added to expected list", "success");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// ------------------------------------------------------------
// 4. Generate daily issues for a date range
// ------------------------------------------------------------
if (isset($_POST['generate_daily_issues'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
    } else {
        $from_date = $_POST['from_date'];
        $to_date = $_POST['to_date'];
        if (empty($from_date) || empty($to_date)) {
            showToast("Please select both from and to dates", "warning");
        } else {
            $generated = generateIssuesForDateRange($db, $subscription_id, $from_date, $to_date);
            showToast("Generated $generated new issues", "success");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }
    header("Location: serial_issues.php?sub_id=$subscription_id");
    exit;
}

// ------------------------------------------------------------
// 5. Auto‑create missing expected issues for the next 7 days (daily only)
// ------------------------------------------------------------
if ($subscription && $subscription['frequency'] == 'daily') {
    $today = date('Y-m-d');
    $oneWeekLater = date('Y-m-d', strtotime('+7 days'));
    generateIssuesForDateRange($db, $subscription_id, $today, $oneWeekLater);
}

// ------------------------------------------------------------
// Fetch issues for this subscription
// ------------------------------------------------------------
$issues = $db->prepare("SELECT * FROM serial_issues WHERE subscription_id = ? ORDER BY date_published DESC, issue_number DESC");
$issues->execute([$subscription_id]);
$issuesList = $issues->fetchAll();

// Also fetch vendor email for reminders
$vendor = null;
if ($subscription && $subscription['vendor_id']) {
    $stmt = $db->prepare("SELECT email, name FROM serial_vendors WHERE id = ?");
    $stmt->execute([$subscription['vendor_id']]);
    $vendor = $stmt->fetch();
}

renderHeader('Serial Issues');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-boxes"></i> Issues for: <?= htmlspecialchars($subscription['title'] ?? '') ?>
            <?php if ($subscription && $subscription['frequency'] == 'daily'): ?>
                <span class="badge bg-info">Daily Newspaper</span>
            <?php endif; ?>
            <?php if ($subscription && $subscription['subscription_type'] == 'online'): ?>
                <span class="badge bg-primary">Online</span>
            <?php elseif ($subscription && $subscription['subscription_type'] == 'both'): ?>
                <span class="badge bg-secondary">Print+Online</span>
            <?php endif; ?>
        </h2>
        <div>
            <a href="javascript:history.back()" class="btn btn-secondary me-2"><i class="fas fa-arrow-left"></i> Back</a>
            <a href="serial_subscriptions.php" class="btn btn-secondary me-2"><i class="fas fa-list"></i> Subscriptions</a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addIssueModal"><i class="fas fa-plus"></i> Add Expected Issue</button>
            <?php if ($subscription && $subscription['frequency'] == 'daily'): ?>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#generateModal"><i class="fas fa-calendar-week"></i> Generate Daily Issues</button>
            <?php endif; ?>
            <?php if ($vendor && $vendor['email']): ?> 
                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#reminderModal"><i class="fas fa-envelope"></i> Send Reminder to Vendor</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Today's Section (for daily subscriptions) -->
    <?php if ($subscription && $subscription['frequency'] == 'daily'): 
        $today = date('Y-m-d');
        $stmt = $db->prepare("SELECT * FROM serial_issues WHERE subscription_id = ? AND date_published = ?");
        $stmt->execute([$subscription_id, $today]);
        $todayIssue = $stmt->fetch();
    ?>
    <div class="card mb-4 border-success">
        <div class="card-header bg-success text-white">
            <i class="fas fa-newspaper"></i> Today's <?= ($subscription['subscription_type'] == 'online') ? 'Online Edition' : 'Newspaper' ?> (<?= date('d-m-Y') ?>)
        </div>
        <div class="card-body">
            <?php if ($todayIssue): ?>
                <?php if ($todayIssue['status'] == 'received'): ?>
                    <div class="alert alert-success mb-0">
                        <i class="fas fa-check-circle"></i> 
                        <?php if ($subscription['subscription_type'] == 'online'): ?>
                            Accessed on <?= $todayIssue['date_received'] ?>
                        <?php else: ?>
                            Received on <?= $todayIssue['date_received'] ?>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning mb-0">
                        <i class="fas fa-clock"></i> Expected - Not yet 
                        <?= ($subscription['subscription_type'] == 'online') ? 'accessed' : 'received' ?>
                        <?php if ($subscription['subscription_type'] == 'online' && !empty($subscription['access_url'])): ?>
                            <a href="<?= htmlspecialchars($subscription['access_url']) ?>" target="_blank" class="btn btn-sm btn-info ms-2" onclick="markAsAccessed(<?= $todayIssue['id'] ?>)">
                                <i class="fas fa-globe"></i> Access Online
                            </a>
                            <form method="post" style="display:inline-block" id="accessForm_<?= $todayIssue['id'] ?>">
                                <input type="hidden" name="issue_id" value="<?= $todayIssue['id'] ?>">
                                <input type="hidden" name="receive_issue" value="1">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            </form>
                            <script>
                            function markAsAccessed(issueId) {
                                if (confirm('Mark this issue as accessed/received?')) {
                                    document.getElementById('accessForm_' + issueId).submit();
                                }
                            }
                            </script>
                        <?php elseif ($subscription['subscription_type'] != 'online'): ?>
                            <form method="post" style="display:inline-block; margin-left:15px;">
                                <input type="hidden" name="issue_id" value="<?= $todayIssue['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <button type="submit" name="receive_issue" class="btn btn-sm btn-success">
                                    <i class="fas fa-check"></i> Mark as Received
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="alert alert-secondary">
                    No issue created for today. Click "Generate Daily Issues" to create.
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Issue List -->
    <div class="card">
        <div class="card-header"><i class="fas fa-list"></i> Issue List</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr><th>Date / Vol/Issue</th><th>Published Date</th><th>Received / Accessed Date</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($issuesList)): ?>
                    <tr class="text-center"><td colspan="5">No issues recorded. Add expected issues or generate daily issues.</td></tr>
                    <?php else: ?>
                        <?php foreach ($issuesList as $issue): ?>
                        <tr class="<?= $issue['status'] == 'late' ? 'table-danger' : ($issue['status'] == 'expected' ? 'table-warning' : '') ?>">
                            <td>
                                <?php if ($subscription['frequency'] == 'daily' && $issue['date_published']): ?>
                                    <?= date('d-m-Y', strtotime($issue['date_published'])) ?>
                                <?php else: ?>
                                    <?= htmlspecialchars($issue['volume'] ?: 'Vol.') ?> / <?= htmlspecialchars($issue['issue_number']) ?>
                                <?php endif; ?>
                            </td>
                            <td><?= $issue['date_published'] ?></td>
                            <td><?= $issue['date_received'] ?? '—' ?></td>
                            <td>
                                <span class="badge bg-<?= $issue['status']=='received'?'success':($issue['status']=='claimed'?'info':($issue['status']=='missing'?'danger':'warning')) ?>">
                                    <?= ucfirst($issue['status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($issue['status'] != 'received'): ?>
                                    <?php if ($subscription['subscription_type'] != 'print' && !empty($subscription['access_url'])): ?>
                                        <!-- Online or both: show access link -->
                                        <a href="<?= htmlspecialchars($subscription['access_url']) ?>" target="_blank" class="btn btn-sm btn-info" onclick="markAsAccessed(<?= $issue['id'] ?>)">
                                            <i class="fas fa-globe"></i> Access Online
                                        </a>
                                        <form method="post" style="display:inline-block" id="accessForm_<?= $issue['id'] ?>">
                                            <input type="hidden" name="issue_id" value="<?= $issue['id'] ?>">
                                            <input type="hidden" name="receive_issue" value="1">
                                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                        </form>
                                    <?php endif; ?>
                                    
                                    <?php if ($subscription['subscription_type'] != 'online'): ?>
                                        <!-- Print or both: show receive button -->
                                        <form method="post" style="display:inline-block">
                                            <input type="hidden" name="issue_id" value="<?= $issue['id'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                            <button type="submit" name="receive_issue" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Receive</button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <!-- Status dropdown (always visible) -->
                                <form method="post" style="display:inline-block">
                                    <input type="hidden" name="issue_id" value="<?= $issue['id'] ?>">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                    <select name="status" class="form-select form-select-sm d-inline w-auto" onchange="this.form.submit()" style="width: auto;">
                                        <option value="expected" <?= $issue['status']=='expected'?'selected':'' ?>>Expected</option>
                                        <option value="claimed" <?= $issue['status']=='claimed'?'selected':'' ?>>Claimed</option>
                                        <option value="missing" <?= $issue['status']=='missing'?'selected':'' ?>>Missing</option>
                                        <option value="late" <?= $issue['status']=='late'?'selected':'' ?>>Late</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Expected Issue Modal (manual) -->
<div class="modal fade" id="addIssueModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5>Add Expected Issue</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="mb-2"><label>Volume</label><input type="text" name="volume" class="form-control"></div>
                    <div class="mb-2"><label>Issue Number *</label><input type="text" name="issue_number" class="form-control" required></div>
                    <div class="mb-2"><label>Published Date</label><input type="date" name="date_published" class="form-control"></div>
                </div>
                <div class="modal-footer"><button type="submit" name="add_issue" class="btn btn-primary">Add Issue</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Generate Daily Issues Modal (only for daily subscriptions) -->
<?php if ($subscription && $subscription['frequency'] == 'daily'): ?>
<div class="modal fade" id="generateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5>Generate Daily Issues</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <p>Create expected issues for a date range (e.g., from today to next week).</p>
                    <div class="mb-2"><label>From Date</label><input type="date" name="from_date" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
                    <div class="mb-2"><label>To Date</label><input type="date" name="to_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" required></div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> Only dates without an existing issue will be added.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="generate_daily_issues" class="btn btn-success">Generate Issues</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Reminder Modal (Send email to vendor) -->
<?php if ($vendor && $vendor['email']): ?>
<div class="modal fade" id="reminderModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning"><h5>Send Reminder to Vendor</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <form method="post" action="serial_reminders.php">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="subscription_id" value="<?= $subscription_id ?>">
                    <p><strong>Vendor:</strong> <?= htmlspecialchars($vendor['name']) ?> (<?= $vendor['email'] ?>)</p>
                    <div class="mb-2"><label>Subject</label><input type="text" name="subject" class="form-control" value="Missing/Late Issue for <?= htmlspecialchars($subscription['title']) ?>"></div>
                    <div class="mb-2"><label>Message</label><textarea name="message" class="form-control" rows="4">Dear Vendor,

We have not received the following issue(s) for <?= htmlspecialchars($subscription['title']) ?>. Please check and update.

Regards,
Library</textarea></div>
                </div>
                <div class="modal-footer"><button type="submit" name="send_reminder" class="btn btn-warning">Send Reminder</button></div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>

<?php
// ------------------------------------------------------------
// Helper Function: Generate issues for a date range
// ------------------------------------------------------------
function generateIssuesForDateRange($db, $subscription_id, $from_date, $to_date) {
    $generated = 0;
    $current = new DateTime($from_date);
    $end = new DateTime($to_date);
    $end->modify('+1 day');

    $existingStmt = $db->prepare("SELECT date_published FROM serial_issues WHERE subscription_id = ? AND date_published IS NOT NULL");
    $existingStmt->execute([$subscription_id]);
    $existingDates = $existingStmt->fetchAll(PDO::FETCH_COLUMN);

    while ($current < $end) {
        $dateStr = $current->format('Y-m-d');
        if (!in_array($dateStr, $existingDates)) {
            $issueNumber = $current->format('Ymd');
            $stmt = $db->prepare("INSERT INTO serial_issues (subscription_id, issue_number, date_published, status) VALUES (?, ?, ?, 'expected')");
            $stmt->execute([$subscription_id, $issueNumber, $dateStr]);
            $generated++;
        }
        $current->modify('+1 day');
    }
    return $generated;
}
?>