<?php
// This loads the Composer autoloader to make all libraries available
require __DIR__ . '/vendor/autoload.php';

if (class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
    echo "✅ PHPSpreadsheet is successfully installed and loaded!<br>";
} else {
    echo "❌ PHPSpreadsheet class not found. Check if vendor/autoload.php is correctly included.<br>";
}

if (class_exists('File_MARC')) {
    echo "✅ File_MARC is successfully installed and loaded!";
} else {
    echo "❌ File_MARC class not found.";
}
?>