<?php
/**
 * Stock Verification Module - Complete Update
 * Features:
 * - Book cover display in verification and history
 * - Enhanced statistics with visual indicators
 * - Discrepancy report with book covers
 * - Improved UI with proper alignment
 * - Responsive design
 * - Real-time book lookup with cover
 * - Export capabilities (Excel, PDF)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$action = $_GET['action'] ?? 'list';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== HANDLE STOCK VERIFICATION SUBMISSION ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_stock'])) {
    try {
        $barcode = trim($_POST['barcode']);
        $actualStatus = trim($_POST['actual_status']);
        $notes = trim($_POST['notes'] ?? '');
        
        // Check if book exists in system
        $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $book = $stmt->fetch();
        
        if ($book) {
            $expectedStatus = $book['available'] > 0 ? 'present' : 'absent';
            
            $insert = $db->prepare("INSERT INTO stock_verification (book_barcode, expected_status, actual_status, verified_date, notes) VALUES (?, ?, ?, ?, ?)");
            $insert->execute([$barcode, $expectedStatus, $actualStatus, date('Y-m-d'), $notes]);
            
            showToast("Stock verified for book: " . htmlspecialchars($book['title']), "success");
            logActivity($_SESSION['username'], 'STOCK_VERIFY', "Verified: {$barcode} - {$actualStatus}");
        } else {
            // Book not in system - mark as extra
            $insert = $db->prepare("INSERT INTO stock_verification (book_barcode, expected_status, actual_status, verified_date, notes) VALUES (?, 'not_in_system', ?, ?, ?)");
            $insert->execute([$barcode, $actualStatus, date('Y-m-d'), $notes]);
            showToast("Extra book recorded: " . htmlspecialchars($barcode), "warning");
            logActivity($_SESSION['username'], 'STOCK_VERIFY_EXTRA', "Extra book: {$barcode}");
        }
        
        header("Location: index.php");
        exit;
        
    } catch (Exception $e) {
        showToast("Verification failed: " . $e->getMessage(), "danger");
    }
}

// ========== HANDLE DELETE VERIFICATION RECORD ==========
if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM stock_verification WHERE id = ?")->execute([$_GET['delete']]);
    showToast("Record deleted", "success");
    header("Location: index.php");
    exit;
}

// ========== GENERATE DISCREPANCY REPORT ==========
if (isset($_GET['generate_report'])) {
    $reportDate = $_GET['date'] ?? date('Y-m-d');
    
    // Get missing books (in system but not found) with covers
    $missing = $db->prepare("SELECT v.*, b.title, b.author, b.barcode, b.location, b.cover_path 
        FROM stock_verification v 
        LEFT JOIN books b ON v.book_barcode = b.barcode 
        WHERE v.verified_date = ? AND v.actual_status IN ('missing', 'lost')");
    $missing->execute([$reportDate]);
    $missingBooks = $missing->fetchAll();
    foreach ($missingBooks as &$book) {
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
    }
    
    // Get extra books (found but not in system)
    $extra = $db->prepare("SELECT * FROM stock_verification WHERE verified_date = ? AND expected_status = 'not_in_system'");
    $extra->execute([$reportDate]);
    $extraBooks = $extra->fetchAll();
    
    // Get damaged books with covers
    $damaged = $db->prepare("SELECT v.*, b.title, b.author, b.barcode, b.cover_path
        FROM stock_verification v 
        LEFT JOIN books b ON v.book_barcode = b.barcode 
        WHERE v.verified_date = ? AND v.actual_status = 'damaged'");
    $damaged->execute([$reportDate]);
    $damagedBooks = $damaged->fetchAll();
    foreach ($damagedBooks as &$book) {
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
    }
    
    // Handle export
    if (isset($_GET['export'])) {
        $format = $_GET['export'];
        $allDiscrepancies = array_merge($missingBooks, $extraBooks, $damagedBooks);
        
        if ($format === 'excel') {
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="stock_discrepancy_' . $reportDate . '.xls"');
            
            echo '<table border="1">';
            echo '<tr><th>Barcode</th><th>Title</th><th>Author</th><th>Expected Status</th><th>Actual Status</th><th>Notes</th></tr>';
            
            foreach ($allDiscrepancies as $item) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($item['book_barcode']) . '</td>';
                echo '<td>' . htmlspecialchars($item['title'] ?? 'N/A') . '</td>';
                echo '<td>' . htmlspecialchars($item['author'] ?? 'N/A') . '</td>';
                echo '<td>' . htmlspecialchars($item['expected_status']) . '</td>';
                echo '<td>' . htmlspecialchars($item['actual_status']) . '</td>';
                echo '<td>' . htmlspecialchars($item['notes'] ?? '-') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            exit;
        } elseif ($format === 'pdf') {
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="stock_discrepancy_' . $reportDate . '.pdf"');
            
            $html = '<!DOCTYPE html><html><head><meta charset="utf-8">';
            $html .= '<title>Stock Discrepancy Report</title>';
            $html .= '<style>
                body { font-family: Arial; margin: 20px; }
                h2 { color: #dc3545; }
                table { border-collapse: collapse; width: 100%; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #dc3545; color: white; }
                .cover-img { max-height: 40px; max-width: 30px; object-fit: contain; }
            </style></head><body>';
            $html .= '<h2>Stock Verification Discrepancy Report</h2>';
            $html .= '<p>Date: ' . formatDate($reportDate) . '</p>';
            $html .= '<p>Generated: ' . date('Y-m-d H:i:s') . '</p>';
            $html .= '<h3>Missing Books: ' . count($missingBooks) . '</h3>';
            $html .= '<h3>Extra Books: ' . count($extraBooks) . '</h3>';
            $html .= '<h3>Damaged Books: ' . count($damagedBooks) . '</h3>';
            $html .= '</body></html>';
            echo $html;
            exit;
        }
    }
    
    renderHeader('Stock Discrepancy Report');
    ?>
    <div class="container-fluid px-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
            <h2><i class="fas fa-clipboard-list text-danger"></i> Stock Discrepancy Report - <?= formatDate($reportDate) ?></h2>
            <div class="d-flex flex-wrap gap-2">
                <button onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
                <a href="?generate_report=1&date=<?= $reportDate ?>&export=excel" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel</a>
                <a href="?generate_report=1&date=<?= $reportDate ?>&export=pdf" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF</a>
                <a href="index.php" class="btn btn-primary"><i class="fas fa-chart-bar"></i> Back</a>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="row g-3 mb-4">
            <div class="col-md-4 col-6">
                <div class="card text-center bg-danger text-white stat-card">
                    <div class="card-body">
                        <h1 class="mb-0"><?= count($missingBooks) ?></h1>
                        <p><i class="fas fa-question-circle"></i> Missing Books</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6">
                <div class="card text-center bg-warning text-white stat-card">
                    <div class="card-body">
                        <h1 class="mb-0"><?= count($extraBooks) ?></h1>
                        <p><i class="fas fa-plus-circle"></i> Extra Books</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-6">
                <div class="card text-center bg-info text-white stat-card">
                    <div class="card-body">
                        <h1 class="mb-0"><?= count($damagedBooks) ?></h1>
                        <p><i class="fas fa-broken"></i> Damaged Books</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Missing Books -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="fas fa-times-circle"></i> Missing Books (In System but Not Found)</h5>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered mb-0 align-middle">
                        <thead class="table-danger">
                            <tr>
                                <th style="width:50px;">Cover</th>
                                <th>Barcode</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Location</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($missingBooks as $book): ?>
                            <tr>
                                <td class="text-center">
                                    <?php if ($book['cover_base64']): ?>
                                        <img src="<?= $book['cover_base64'] ?>" style="width:35px;height:50px;object-fit:cover;border-radius:4px;">
                                    <?php else: ?>
                                        <div style="width:35px;height:50px;background:#e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#6c757d;">
                                            <i class="fas fa-book"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><code><?= htmlspecialchars($book['book_barcode']) ?></code></td>
                                <td><?= htmlspecialchars($book['title'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($book['author'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($book['location'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($book['notes'] ?? '-') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($missingBooks)): ?>
                            <tr><td colspan="6" class="text-center text-success py-4"><i class="fas fa-check-circle"></i> No missing books found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="row g-4">
            <!-- Extra Books -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-warning text-white">
                        <h5 class="mb-0"><i class="fas fa-plus-circle"></i> Extra Books</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-0 align-middle">
                                <thead class="table-warning">
                                    <tr><th>Barcode</th><th>Actual Status</th><th>Notes</th></tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($extraBooks as $book): ?>
                                    <tr>
                                        <td><code><?= htmlspecialchars($book['book_barcode']) ?></code></td>
                                        <td><?= htmlspecialchars($book['actual_status']) ?></td>
                                        <td><?= htmlspecialchars($book['notes'] ?? '-') ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($extraBooks)): ?>
                                    <tr><td colspan="3" class="text-center text-success py-4"><i class="fas fa-check-circle"></i> No extra books found</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Damaged Books -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0"><i class="fas fa-broken"></i> Damaged Books</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-0 align-middle">
                                <thead class="table-info">
                                    <tr>
                                        <th style="width:50px;">Cover</th>
                                        <th>Barcode</th>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($damagedBooks as $book): ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php if ($book['cover_base64']): ?>
                                                <img src="<?= $book['cover_base64'] ?>" style="width:35px;height:50px;object-fit:cover;border-radius:4px;">
                                            <?php else: ?>
                                                <div style="width:35px;height:50px;background:#e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#6c757d;">
                                                    <i class="fas fa-book"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td><code><?= htmlspecialchars($book['book_barcode']) ?></code></td>
                                        <td><?= htmlspecialchars($book['title'] ?? 'N/A') ?></td>
                                        <td><?= htmlspecialchars($book['author'] ?? 'N/A') ?></td>
                                        <td><?= htmlspecialchars($book['notes'] ?? '-') ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($damagedBooks)): ?>
                                    <tr><td colspan="5" class="text-center text-success py-4"><i class="fas fa-check-circle"></i> No damaged books found</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    renderFooter();
    exit;
}

// ========== GET STATISTICS ==========
$totalScanned = $db->query("SELECT COUNT(*) FROM stock_verification")->fetchColumn();
$totalMatches = $db->query("SELECT COUNT(*) FROM stock_verification WHERE expected_status = actual_status AND expected_status != 'not_in_system'")->fetchColumn();
$totalMismatches = $totalScanned - $totalMatches;
$totalMissing = $db->query("SELECT COUNT(*) FROM stock_verification WHERE actual_status IN ('missing', 'lost')")->fetchColumn();
$totalExtra = $db->query("SELECT COUNT(*) FROM stock_verification WHERE expected_status = 'not_in_system'")->fetchColumn();
$totalDamaged = $db->query("SELECT COUNT(*) FROM stock_verification WHERE actual_status = 'damaged'")->fetchColumn();
$todayVerified = $db->query("SELECT COUNT(*) FROM stock_verification WHERE verified_date = date('now')")->fetchColumn();

// ========== GET RECENT VERIFICATIONS WITH COVERS ==========
$recent = $db->query("SELECT v.*, b.title, b.author, b.cover_path 
    FROM stock_verification v 
    LEFT JOIN books b ON v.book_barcode = b.barcode 
    ORDER BY v.created_at DESC LIMIT 50")->fetchAll();

foreach ($recent as &$record) {
    $record['cover_base64'] = getImageBase64($record['cover_path'] ?? '');
}

renderHeader('Stock Verification');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Stat Cards */
.stat-card {
    transition: all 0.3s ease;
    border: none;
    border-radius: 16px;
    cursor: default;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}

/* Book Cover */
.book-cover-thumb {
    width: 35px;
    height: 50px;
    object-fit: cover;
    border-radius: 4px;
    border: 1px solid #e9ecef;
    transition: all 0.3s ease;
}
.book-cover-thumb:hover {
    transform: scale(1.2);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10;
    position: relative;
}
.book-cover-placeholder {
    width: 35px;
    height: 50px;
    border-radius: 4px;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    border: 1px solid #e9ecef;
}
.book-cover-placeholder i {
    font-size: 1.2rem;
}

/* Scan Input */
.scan-input {
    font-size: 1.2rem;
    text-align: center;
    letter-spacing: 2px;
    font-family: monospace;
}

/* Status Badge */
.verification-status {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-weight: 600;
}
.status-match { background: #d4edda; color: #155724; }
.status-mismatch { background: #f8d7da; color: #721c24; }

/* Quick Stats Chart Container */
.chart-container {
    max-height: 200px;
}

@media (max-width: 768px) {
    .stat-card h1 { font-size: 1.8rem; }
    .book-cover-thumb { width: 28px; height: 40px; }
    .book-cover-placeholder { width: 28px; height: 40px; }
    .book-cover-placeholder i { font-size: 0.9rem; }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-clipboard-list text-primary"></i> Stock Verification</h2>
            <p class="text-muted">Scan and verify physical book stock against the system</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="?generate_report=1" class="btn btn-info text-white">
                <i class="fas fa-chart-bar"></i> Discrepancy Report
            </a>
            <button onclick="window.location.reload()" class="btn btn-secondary">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-primary text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalScanned) ?></h3>
                    <small><i class="fas fa-barcode"></i> Total Scanned</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-success text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalMatches) ?></h3>
                    <small><i class="fas fa-check-circle"></i> Matches</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-danger text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalMismatches) ?></h3>
                    <small><i class="fas fa-exclamation-triangle"></i> Mismatches</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-warning text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalMissing) ?></h3>
                    <small><i class="fas fa-question-circle"></i> Missing</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-info text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalExtra) ?></h3>
                    <small><i class="fas fa-plus-circle"></i> Extra</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="card stat-card text-center bg-secondary text-white">
                <div class="card-body">
                    <h3 class="mb-0"><?= number_format($totalDamaged) ?></h3>
                    <small><i class="fas fa-broken"></i> Damaged</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Scan Section -->
        <div class="col-lg-5">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-barcode"></i> Scan & Verify Books</h5>
                </div>
                <div class="card-body">
                    <form method="post" id="verifyForm">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Book Barcode</label>
                            <input type="text" name="barcode" id="barcode" class="form-control form-control-lg scan-input" 
                                   placeholder="Scan or enter barcode" required autofocus>
                            <small class="text-muted">Press Enter after scanning to auto-submit</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Physical Status</label>
                            <select name="actual_status" id="actual_status" class="form-select form-select-lg" required>
                                <option value="present">✓ Present on shelf</option>
                                <option value="missing">✗ Missing / Not found</option>
                                <option value="damaged">⚠ Damaged</option>
                                <option value="lost">✗ Lost</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Notes</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Any additional comments..."></textarea>
                        </div>
                        <button type="submit" name="verify_stock" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-check-circle"></i> Confirm Verification
                        </button>
                    </form>
                    <div id="bookInfo" class="mt-3"></div>
                </div>
            </div>
            
            <!-- Quick Stats Chart -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-chart-line"></i> Verification Stats</h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="statsChart"></canvas>
                    </div>
                    <div class="row text-center mt-3">
                        <div class="col-6">
                            <div class="small text-muted">Today's Verifications</div>
                            <div class="h4 fw-bold text-primary"><?= number_format($todayVerified) ?></div>
                        </div>
                        <div class="col-6">
                            <div class="small text-muted">Accuracy Rate</div>
                            <div class="h4 fw-bold <?= $totalScanned > 0 && ($totalMatches/$totalScanned) >= 0.9 ? 'text-success' : 'text-warning' ?>">
                                <?= $totalScanned > 0 ? round(($totalMatches / $totalScanned) * 100) : 0 ?>%
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Verifications -->
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white d-flex flex-wrap justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-history"></i> Recent Verifications</h5>
                    <span class="badge bg-light text-dark"><?= count($recent) ?> records</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                        <table class="table table-hover table-sm mb-0 align-middle">
                            <thead class="table-light sticky-top">
                                <tr>
                                    <th style="width:50px;">Cover</th>
                                    <th>Date</th>
                                    <th>Barcode</th>
                                    <th>Title</th>
                                    <th>Expected</th>
                                    <th>Actual</th>
                                    <th>Status</th>
                                    <th style="width:50px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent as $v): 
                                    $isMatch = ($v['expected_status'] === $v['actual_status'] && $v['expected_status'] != 'not_in_system');
                                    $statusClass = $isMatch ? 'match' : 'mismatch';
                                    $statusIcon = $isMatch ? 'fa-check-circle' : 'fa-exclamation-triangle';
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <?php if ($v['cover_base64']): ?>
                                            <img src="<?= $v['cover_base64'] ?>" class="book-cover-thumb" alt="Cover">
                                        <?php else: ?>
                                            <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><small><?= formatDate($v['verified_date']) ?></small></td>
                                    <td><code><?= htmlspecialchars($v['book_barcode']) ?></code></td>
                                    <td><?= htmlspecialchars(substr($v['title'] ?? 'N/A', 0, 25)) ?></td>
                                    <td><span class="badge bg-secondary"><?= $v['expected_status'] ?></span></td>
                                    <td><span class="badge bg-<?= $v['actual_status'] == 'present' ? 'success' : ($v['actual_status'] == 'damaged' ? 'warning' : 'danger') ?>"><?= $v['actual_status'] ?></span></td>
                                    <td>
                                        <span class="verification-status status-<?= $statusClass ?>">
                                            <i class="fas <?= $statusIcon ?>"></i> <?= $isMatch ? 'Match' : 'Mismatch' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="?delete=<?= $v['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this record?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($recent)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                                        No verifications yet. Start scanning above.
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if (!empty($recent)): ?>
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between align-items-center small text-muted">
                        <span>Showing last <?= count($recent) ?> verifications</span>
                        <span>
                            <i class="fas fa-check-circle text-success"></i> <?= array_sum(array_column($recent, function($r) { return ($r['expected_status'] === $r['actual_status'] && $r['expected_status'] != 'not_in_system') ? 1 : 0; })) ?> matches
                            <span class="ms-2">
                                <i class="fas fa-exclamation-triangle text-danger"></i> <?= array_sum(array_column($recent, function($r) { return ($r['expected_status'] !== $r['actual_status'] && $r['expected_status'] != 'not_in_system') ? 1 : 0; })) ?> mismatches
                            </span>
                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// ========== AUTO-FOCUS ==========
document.getElementById('barcode').focus();

// ========== FETCH BOOK INFO ON BLUR ==========
document.getElementById('barcode').addEventListener('blur', function() {
    let barcode = this.value.trim();
    if (barcode.length >= 3) {
        fetch('ajax_book.php?barcode=' + encodeURIComponent(barcode))
            .then(r => r.json())
            .then(data => {
                let infoDiv = document.getElementById('bookInfo');
                if (data && data.title) {
                    let coverHtml = '';
                    if (data.cover_base64) {
                        coverHtml = `<img src="${data.cover_base64}" style="width:50px;height:70px;object-fit:cover;border-radius:8px;border:1px solid #e9ecef;margin-right:15px;float:left;">`;
                    }
                    infoDiv.innerHTML = `
                        <div class="alert alert-info p-3" style="overflow:hidden;">
                            ${coverHtml}
                            <div>
                                <strong><i class="fas fa-book"></i> ${escapeHtml(data.title)}</strong><br>
                                <i class="fas fa-user-edit"></i> Author: ${escapeHtml(data.author || 'Unknown')}<br>
                                <i class="fas fa-barcode"></i> Barcode: <code>${escapeHtml(data.barcode)}</code><br>
                                <i class="fas fa-chart-line"></i> Expected Status: ${data.available > 0 ? '<span class="badge bg-success">Present</span>' : '<span class="badge bg-danger">Not Available</span>'}<br>
                                <i class="fas fa-info-circle"></i> Location: ${escapeHtml(data.location || 'Not specified')}
                            </div>
                        </div>
                    `;
                } else {
                    infoDiv.innerHTML = `
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> 
                            Book not found in system! This will be marked as an <strong>EXTRA</strong> book.
                        </div>
                    `;
                }
            })
            .catch(() => {
                document.getElementById('bookInfo').innerHTML = '<div class="alert alert-danger">Error fetching book details</div>';
            });
    }
});

// ========== AUTO-SUBMIT ON ENTER ==========
document.getElementById('barcode').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('verifyForm').submit();
    }
});

// ========== STATS CHART ==========
const statsCtx = document.getElementById('statsChart').getContext('2d');
new Chart(statsCtx, {
    type: 'doughnut',
    data: {
        labels: ['Matches', 'Mismatches', 'Missing', 'Extra', 'Damaged'],
        datasets: [{
            data: [<?= $totalMatches ?>, <?= $totalMismatches ?>, <?= $totalMissing ?>, <?= $totalExtra ?>, <?= $totalDamaged ?>],
            backgroundColor: ['#28a745', '#dc3545', '#ffc107', '#17a2b8', '#6c757d'],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { font: { size: 11 }, boxWidth: 12 }
            }
        },
        cutout: '65%'
    }
});

// ========== ESCAPE HTML ==========
function escapeHtml(s) {
    if (!s) return '';
    return s.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

// ========== AUTO-DISMISS TOASTS ==========
setTimeout(function() {
    var alerts = document.querySelectorAll('.alert:not(.alert-info):not(.alert-warning)');
    alerts.forEach(function(alert) {
        var bsAlert = new bootstrap.Alert(alert);
        setTimeout(function() { bsAlert.close(); }, 5000);
    });
}, 3000);
</script>

<?php renderFooter(); ?>