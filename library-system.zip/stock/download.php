<?php
/**
 * eBook Download Handler
 * Increments download count and serves the file to the user
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Allow access even without login (public downloads from OPAC)
// However, we can log the download activity if user is logged in

$db = getDB();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    die("Invalid request. No eBook ID specified.");
}

try {
    // Get eBook details
    $stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
    $stmt->execute([$id]);
    $ebook = $stmt->fetch();

    if (!$ebook) {
        die("eBook not found.");
    }

    // Check if file exists
    $filePath = $ebook['file_path'];
    if (empty($filePath) || !file_exists($filePath)) {
        die("File not found. The eBook file may have been deleted.");
    }

    // Increment download count
    $update = $db->prepare("UPDATE ebooks SET downloads = downloads + 1 WHERE id = ?");
    $update->execute([$id]);

    // Log download activity if user is logged in
    if (isset($_SESSION['user_id'])) {
        logActivity($_SESSION['username'], 'EBOOK_DOWNLOAD', "Downloaded eBook: {$ebook['title']} (ID: $id)");
    }

    // Get file info
    $fileName = basename($filePath);
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $fileSize = filesize($filePath);

    // Set content type based on file extension
    $contentType = 'application/octet-stream';
    switch ($fileExt) {
        case 'pdf':
            $contentType = 'application/pdf';
            break;
        case 'doc':
            $contentType = 'application/msword';
            break;
        case 'docx':
            $contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
            break;
        case 'epub':
            $contentType = 'application/epub+zip';
            break;
        case 'mobi':
            $contentType = 'application/x-mobipocket-ebook';
            break;
        case 'txt':
            $contentType = 'text/plain';
            break;
    }

    // Create a safe filename for download (remove special characters)
    $safeTitle = preg_replace('/[^a-zA-Z0-9_-]/', '_', $ebook['title']);
    $downloadFileName = $safeTitle . '.' . $fileExt;

    // Send headers
    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . $downloadFileName . '"');
    header('Content-Length: ' . $fileSize);
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');

    // Clear output buffer
    if (ob_get_level()) {
        ob_end_clean();
    }

    // Read file and output
    readfile($filePath);
    exit;

} catch (PDOException $e) {
    error_log("Download error: " . $e->getMessage());
    die("An error occurred while processing your request. Please try again later.");
}
?>