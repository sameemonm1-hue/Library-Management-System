<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

// Optional: rate limiting (using session)
session_start();
if (isset($_SESSION['user_id'])) {
    $rate_key = 'ajax_rate_' . $_SESSION['user_id'];
    if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
    if ($_SESSION[$rate_key] > 20) {
        echo json_encode(['error' => 'Too many requests']);
        exit;
    }
    $_SESSION[$rate_key]++;
}

$db = getDB();
$barcode = $_GET['barcode'] ?? '';

if ($barcode) {
    $stmt = $db->prepare("SELECT barcode, title, author, available, quantity, location FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $book = $stmt->fetch();
    echo json_encode($book ?? null);
} else {
    echo json_encode(null);
}
?>