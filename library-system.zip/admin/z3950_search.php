<?php
/**
 * Z39.50 Search and Import
 * Uses the Z3950Client class to search multiple targets and merge results.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../includes/Z3950Client.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$bookId = (int)($_GET['book_id'] ?? 0);
$message = '';
$searchResults = [];

// Handle search
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $query = trim($_POST['query']);
    $searchType = $_POST['search_type'] ?? 'title';
    
    if (empty($query)) {
        $message = '<div class="alert alert-warning">Please enter a search term.</div>';
    } else {
        try {
            $client = new Z3950Client();
            $searchResults = $client->search($query, $searchType);
            $message = '<div class="alert alert-success">Found ' . count($searchResults) . ' records across all targets.</div>';
        } catch (Exception $e) {
            $message = '<div class="alert alert-danger">Z39.50 error: ' . $e->getMessage() . '</div>';
        }
    }
}

// Handle import
if (isset($_GET['import']) && isset($_GET['record_idx'])) {
    $recordIdx = (int)$_GET['record_idx'];
    if (isset($_SESSION['last_search_results'][$recordIdx])) {
        $record = $_SESSION['last_search_results'][$recordIdx];
        $client = new Z3950Client();
        $importedId = $client->importRecord($record['marcxml'], $bookId ?: null);
        if ($importedId) {
            $message = '<div class="alert alert-success">Record imported successfully. <a href="../admin/marc_editor.php?id=' . $importedId . '">Edit MARC</a></div>';
        } else {
            $message = '<div class="alert alert-danger">Import failed.</div>';
        }
    } else {
        $message = '<div class="alert alert-danger">Record not found.</div>';
    }
    // Clear stored results to avoid re-import
    unset($_SESSION['last_search_results']);
}

// Store results in session for import links
if (!empty($searchResults)) {
    $_SESSION['last_search_results'] = $searchResults;
}

renderHeader('Z39.50 Search');
?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-search"></i> Z39.50 Copy Cataloging</h2>
        <div>
            <a href="books.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Books</a>
            <?php if ($bookId): ?>
                <a href="marc_editor.php?id=<?= $bookId ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit MARC</a>
            <?php endif; ?>
        </div>
    </div>
    
    <?= $message ?>
    
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-globe"></i> Search External Catalogs</h5>
        </div>
        <div class="card-body">
            <form method="post">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label">Search Term</label>
                        <input type="text" name="query" class="form-control form-control-lg" 
                               placeholder="e.g., 'Harry Potter' or '9780439554930'" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Search Type</label>
                        <select name="search_type" class="form-select">
                            <option value="title">Title</option>
                            <option value="author">Author</option>
                            <option value="isbn">ISBN</option>
                            <option value="keyword">Keyword</option>
                        </select>
                    </div>
                    <div class="col-md-1 align-self-end">
                        <button type="submit" name="search" class="btn btn-primary btn-lg w-100">Search</button>
                    </div>
                </div>
                <div class="form-text">
                    <i class="fas fa-info-circle"></i> Searches Library of Congress, British Library, BnF, and OCLC.
                </div>
            </form>
        </div>
    </div>
    
    <?php if (!empty($searchResults)): ?>
    <div class="card">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-list"></i> Results (<?= count($searchResults) ?> records)</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Source</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Publisher / Year</th>
                            <th>ISBN</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($searchResults as $idx => $result):
                            $marc = simplexml_load_string($result['marcxml']);
                            if (!$marc) continue;
                            $title = '';
                            $author = '';
                            $publisher = '';
                            $year = '';
                            $isbn = '';
                            
                            $xpath = new DOMXPath(dom_import_simplexml($marc)->ownerDocument);
                            $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');
                            
                            // Title (245$a)
                            $nodes = $xpath->query("//marc:datafield[@tag='245']/marc:subfield[@code='a']");
                            if ($nodes->length) $title = trim($nodes->item(0)->nodeValue);
                            // Author (100$a)
                            $nodes = $xpath->query("//marc:datafield[@tag='100']/marc:subfield[@code='a']");
                            if ($nodes->length) $author = trim($nodes->item(0)->nodeValue);
                            // ISBN (020$a)
                            $nodes = $xpath->query("//marc:datafield[@tag='020']/marc:subfield[@code='a']");
                            if ($nodes->length) $isbn = trim($nodes->item(0)->nodeValue);
                            // Publisher (260$b or 264$b)
                            $nodes = $xpath->query("//marc:datafield[@tag='260']/marc:subfield[@code='b']|//marc:datafield[@tag='264']/marc:subfield[@code='b']");
                            if ($nodes->length) $publisher = trim($nodes->item(0)->nodeValue);
                            // Year (260$c or 264$c)
                            $nodes = $xpath->query("//marc:datafield[@tag='260']/marc:subfield[@code='c']|//marc:datafield[@tag='264']/marc:subfield[@code='c']");
                            if ($nodes->length) $year = trim(preg_replace('/[^0-9]/', '', $nodes->item(0)->nodeValue));
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($result['target']) ?></td>
                            <td><strong><?= htmlspecialchars(substr($title, 0, 100)) ?></strong></td>
                            <td><?= htmlspecialchars($author) ?></td>
                            <td><?= htmlspecialchars($publisher) ?> (<?= $year ?>)</td>
                            <td><?= htmlspecialchars($isbn) ?></td>
                            <td>
                                <a href="?import=1&record_idx=<?= $idx ?><?= $bookId ? '&book_id=' . $bookId : '' ?>" 
                                   class="btn btn-sm btn-success" onclick="return confirm('Import this record? It will overwrite existing data for this book.');">
                                    <i class="fas fa-download"></i> Import
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php renderFooter(); ?>