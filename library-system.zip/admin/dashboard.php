<?php
/**
 * Library ERP System - Admin Dashboard (Enhanced)
 * Complete dashboard with statistics, charts, quick actions, and real-time data
 * Version: 4.1 - Fixed all errors
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ========== SECURITY: Ensure only admin can access ==========
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

// ========== HELPER FUNCTIONS ==========
if (!function_exists('getImageBase64')) {
    function getImageBase64($path) {
        if (empty($path)) return null;
        $fullPath = $path;
        if (strpos($path, 'uploads/') === 0) {
            $fullPath = BASE_PATH . '/' . $path;
        } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
            $fullPath = BASE_PATH . '/' . ltrim($path, '/');
        }
        if (!file_exists($fullPath)) return null;
        $data = @file_get_contents($fullPath);
        if ($data === false) return null;
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_buffer($finfo, $data);
        finfo_close($finfo);
        return 'data:' . $mime . ';base64,' . base64_encode($data);
    }
}

if (!function_exists('cacheGet')) {
    function cacheGet($key) {
        $cacheFile = __DIR__ . '/../cache/' . md5($key) . '.cache';
        if (!file_exists($cacheFile)) return null;
        $data = file_get_contents($cacheFile);
        $cached = unserialize($data);
        if ($cached['expires'] < time()) {
            @unlink($cacheFile);
            return null;
        }
        return $cached['data'];
    }
}

if (!function_exists('cacheSet')) {
    function cacheSet($key, $data, $ttl = 300) {
        $cacheDir = __DIR__ . '/../cache';
        if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
        $cacheFile = $cacheDir . '/' . md5($key) . '.cache';
        $cached = ['expires' => time() + $ttl, 'data' => $data];
        file_put_contents($cacheFile, serialize($cached));
    }
}

if (!function_exists('formatCurrency')) {
    function formatCurrency($amount) {
        $settings = getSettings();
        $symbol = $settings['currency_symbol'] ?? '$';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        return $symbol . ' ' . number_format((float)$amount, $decimals);
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date) {
        if (empty($date) || $date === '0000-00-00') return 'N/A';
        return date('d M Y', strtotime($date));
    }
}

if (!function_exists('timeAgo')) {
    function timeAgo($datetime) {
        if (empty($datetime)) return 'Never';
        $time = strtotime($datetime);
        $now = time();
        $diff = $now - $time;
        if ($diff < 60) return $diff . ' sec ago';
        if ($diff < 3600) return floor($diff / 60) . ' min ago';
        if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
        if ($diff < 604800) return floor($diff / 86400) . ' days ago';
        if ($diff < 2592000) return floor($diff / 604800) . ' weeks ago';
        return date('M d, Y', $time);
    }
}

if (!function_exists('getCategoryColor')) {
    function getCategoryColor($category) {
        $colors = [
            'Student' => '#4CAF50',
            'Teacher' => '#2196F3',
            'Staff' => '#FF9800',
            'Visitor' => '#9C27B0',
            'General' => '#607D8B',
            'Research Scholar' => '#E91E63',
            'Faculty' => '#00BCD4',
            'Alumni' => '#795548'
        ];
        return $colors[$category] ?? '#6c757d';
    }
}

if (!function_exists('getActivityIcon')) {
    function getActivityIcon($action) {
        $icons = [
            'LOGIN' => 'fa-sign-in-alt',
            'LOGOUT' => 'fa-sign-out-alt',
            'ADD_MEMBER' => 'fa-user-plus',
            'EDIT_MEMBER' => 'fa-user-edit',
            'DELETE_MEMBER' => 'fa-user-minus',
            'ADD_BOOK' => 'fa-book',
            'EDIT_BOOK' => 'fa-book-open',
            'DELETE_BOOK' => 'fa-book-dead',
            'ISSUE_BOOK' => 'fa-arrow-right',
            'RETURN_BOOK' => 'fa-arrow-left',
            'RENEW_BOOK' => 'fa-sync-alt',
            'ADD_FINE' => 'fa-coins',
            'PAY_FINE' => 'fa-money-bill-wave',
            'SETTINGS_UPDATE' => 'fa-cog',
            'BACKUP_CREATE' => 'fa-database',
            'EXPORT_DATA' => 'fa-file-export',
            'ENTRY' => 'fa-door-open',
            'EXIT' => 'fa-door-closed'
        ];
        foreach ($icons as $key => $icon) {
            if (strpos($action, $key) !== false) return $icon;
        }
        return 'fa-info-circle';
    }
}

if (!function_exists('getActivityColor')) {
    function getActivityColor($action) {
        $colors = [
            'LOGIN' => 'success',
            'LOGOUT' => 'secondary',
            'ADD' => 'success',
            'EDIT' => 'warning',
            'DELETE' => 'danger',
            'ISSUE' => 'info',
            'RETURN' => 'info',
            'PAY' => 'success',
            'SETTINGS' => 'primary',
            'BACKUP' => 'info',
            'EXPORT' => 'secondary',
            'ENTRY' => 'success',
            'EXIT' => 'danger'
        ];
        foreach ($colors as $key => $color) {
            if (strpos($action, $key) !== false) return $color;
        }
        return 'secondary';
    }
}

if (!function_exists('safeQuery')) {
    function safeQuery($db, $sql, $default = 0) {
        try {
            $result = $db->query($sql);
            return $result ? $result->fetchColumn() : $default;
        } catch(PDOException $e) {
            return $default;
        }
    }
}

// ==================== FETCH DASHBOARD STATISTICS WITH CACHING ====================
$dashboardStats = cacheGet('dashboard_stats');

if ($dashboardStats === null) {
    try {
        // Initialize all variables to 0 first
        $totalMembers = 0;
        $activeMembers = 0;
        $inactiveMembers = 0;
        $totalStaff = 0;
        $newMembersThisMonth = 0;
        $totalBooks = 0;
        $totalTitles = 0;
        $availableBooks = 0;
        $totalEbooks = 0;
        $lowStock = 0;
        $totalLost = 0;
        $booksAddedThisMonth = 0;
        $totalIssued = 0;
        $totalOverdue = 0;
        $totalReturned = 0;
        $totalCirculation = 0;
        $todayIssued = 0;
        $todayReturned = 0;
        $monthIssued = 0;
        $monthReturned = 0;
        $totalFines = 0;
        $totalFineCollected = 0;
        $pendingFines = 0;
        $finesCollectedThisMonth = 0;
        $totalHolds = 0;
        $pendingReservations = 0;
        $upcomingEvents = 0;
        $pendingSuggestions = 0;
        $currentInside = 0;
        $todayVisitors = 0;
        $monthVisitors = 0;
        $birthdayCount = 0;
        $expiringMemberships = 0;
        
        // Serials Statistics
        $totalSerials = 0;
        $activeSerials = 0;
        $expiredSerials = 0;
        $cancelledSerials = 0;
        $totalSerialIssues = 0;
        $receivedIssues = 0;
        $missingIssues = 0;
        $expectedIssues = 0;
        
        // eBooks Statistics
        $ebookDownloads = 0;
        $ebooksWithCover = 0;
        $ebooksWithoutCover = 0;
        
        // Other Statistics
        $totalResearchDatabases = 0;
        $activeResearchDatabases = 0;
        $totalNotices = 0;
        $totalSuggestions = 0;
        $pendingSuggestions = 0;
        $totalVendors = 0;
        $totalPurchaseOrders = 0;
        $pendingPurchaseOrders = 0;
        $totalLibraryEvents = 0;
        $upcomingEvents = 0;

        $memberCategories = [];
        $monthlyData = [];
        $dailyIssuedData = [];
        $popularBooks = [];
        $occupancyData = [];
        $fineTrends = [];
        $topCategories = [];
        $recentActivities = [];
        $recentMembers = [];
        $recentCirculation = [];

        // Check if members table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='members'");
            $membersTableExists = $stmt->fetch() !== false;
            
            if ($membersTableExists) {
                $totalMembers = safeQuery($db, "SELECT COUNT(*) FROM members");
                $activeMembers = safeQuery($db, "SELECT COUNT(*) FROM members WHERE status = 'active'");
                $inactiveMembers = safeQuery($db, "SELECT COUNT(*) FROM members WHERE status = 'inactive'");
                $newMembersThisMonth = safeQuery($db, "SELECT COUNT(*) FROM members WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', date('now'))");
                $birthdayCount = safeQuery($db, "SELECT COUNT(*) FROM members WHERE strftime('%m', dob) = strftime('%m', date('now'))");
                $expiringMemberships = safeQuery($db, "SELECT COUNT(*) FROM members WHERE membership_expiry IS NOT NULL AND membership_expiry BETWEEN date('now') AND date('now', '+30 days')");
            }
        } catch(PDOException $e) {}

        // Check if books table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books'");
            $booksTableExists = $stmt->fetch() !== false;
            
            if ($booksTableExists) {
                $totalBooks = safeQuery($db, "SELECT SUM(quantity) FROM books");
                $totalTitles = safeQuery($db, "SELECT COUNT(*) FROM books");
                $availableBooks = safeQuery($db, "SELECT SUM(available) FROM books");
                $booksAddedThisMonth = safeQuery($db, "SELECT COUNT(*) FROM books WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', date('now'))");
                $totalLost = safeQuery($db, "SELECT COALESCE(SUM(total_lost),0) FROM books");
                
                try {
                    $stmt = $db->query("SELECT COUNT(*) FROM (SELECT SUM(available) as avail FROM books GROUP BY title, author, publisher, isbn HAVING avail > 0 AND avail <= 2)");
                    $lowStock = $stmt ? $stmt->fetchColumn() : 0;
                } catch(PDOException $e) {}
            }
        } catch(PDOException $e) {}

        // Check if ebooks table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='ebooks'");
            $ebooksTableExists = $stmt->fetch() !== false;
            
            if ($ebooksTableExists) {
                $totalEbooks = safeQuery($db, "SELECT COUNT(*) FROM ebooks");
                $ebookDownloads = safeQuery($db, "SELECT COALESCE(SUM(downloads), 0) FROM ebooks");
                $ebooksWithCover = safeQuery($db, "SELECT COUNT(*) FROM ebooks WHERE cover_path IS NOT NULL AND cover_path != ''");
                $ebooksWithoutCover = $totalEbooks - $ebooksWithCover;
            }
        } catch(PDOException $e) {}

        // Check if users table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'");
            if ($stmt->fetch() !== false) {
                $totalStaff = safeQuery($db, "SELECT COUNT(*) FROM users WHERE role != 'admin'");
            }
        } catch(PDOException $e) {}

        // Check if circulation table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            if ($stmt->fetch() !== false) {
                $totalIssued = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE return_date IS NULL");
                $totalOverdue = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')");
                $totalReturned = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE return_date IS NOT NULL");
                $totalCirculation = safeQuery($db, "SELECT COUNT(*) FROM circulation");
                $todayIssued = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE date(issue_date) = date('now')");
                $todayReturned = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE date(return_date) = date('now')");
                $monthIssued = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE strftime('%Y-%m', issue_date) = strftime('%Y-%m', date('now'))");
                $monthReturned = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE strftime('%Y-%m', return_date) = strftime('%Y-%m', date('now'))");
                $totalFines = safeQuery($db, "SELECT COALESCE(SUM(fine), 0) FROM circulation");
            }
        } catch(PDOException $e) {}

        // Check if fine_payments table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='fine_payments'");
            if ($stmt->fetch() !== false) {
                $totalFineCollected = safeQuery($db, "SELECT COALESCE(SUM(amount), 0) FROM fine_payments");
                $finesCollectedThisMonth = safeQuery($db, "SELECT COALESCE(SUM(amount), 0) FROM fine_payments WHERE strftime('%Y-%m', payment_date) = strftime('%Y-%m', date('now'))");
            }
        } catch(PDOException $e) {}
        $pendingFines = $totalFines - $totalFineCollected;

        // Check if book_holds table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='book_holds'");
            if ($stmt->fetch() !== false) {
                $totalHolds = safeQuery($db, "SELECT COUNT(*) FROM book_holds WHERE status = 'pending'");
            }
        } catch(PDOException $e) {}

        // Check if reservations_queue table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='reservations_queue'");
            if ($stmt->fetch() !== false) {
                $pendingReservations = safeQuery($db, "SELECT COUNT(*) FROM reservations_queue WHERE status = 'waiting'");
            }
        } catch(PDOException $e) {}

        // Check if library_events table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='library_events'");
            if ($stmt->fetch() !== false) {
                $totalLibraryEvents = safeQuery($db, "SELECT COUNT(*) FROM library_events");
                $upcomingEvents = safeQuery($db, "SELECT COUNT(*) FROM library_events WHERE status = 'upcoming' AND event_date >= date('now')");
            }
        } catch(PDOException $e) {}

        // Check if suggestions table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='suggestions'");
            if ($stmt->fetch() !== false) {
                $totalSuggestions = safeQuery($db, "SELECT COUNT(*) FROM suggestions");
                $pendingSuggestions = safeQuery($db, "SELECT COUNT(*) FROM suggestions WHERE status = 'pending'");
            }
        } catch(PDOException $e) {}

        // Check if entry_exit table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='entry_exit'");
            if ($stmt->fetch() !== false) {
                $currentInside = safeQuery($db, "SELECT COUNT(*) FROM entry_exit WHERE exit_time IS NULL AND status = 'inside'");
                $todayVisitors = safeQuery($db, "SELECT COUNT(*) FROM entry_exit WHERE entry_date = date('now')");
                $monthVisitors = safeQuery($db, "SELECT COUNT(*) FROM entry_exit WHERE strftime('%Y-%m', entry_date) = strftime('%Y-%m', date('now'))");
            }
        } catch(PDOException $e) {}

        // ==================== SERIALS STATISTICS ====================
        // Check if serial_subscriptions table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='serial_subscriptions'");
            if ($stmt->fetch() !== false) {
                $totalSerials = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions");
                $activeSerials = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'active'");
                $expiredSerials = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'expired'");
                $cancelledSerials = safeQuery($db, "SELECT COUNT(*) FROM serial_subscriptions WHERE status = 'cancelled'");
            }
        } catch(PDOException $e) {}
        
        // Check if serial_issues table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='serial_issues'");
            if ($stmt->fetch() !== false) {
                $totalSerialIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues");
                $receivedIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'received'");
                $missingIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'missing'");
                $expectedIssues = safeQuery($db, "SELECT COUNT(*) FROM serial_issues WHERE status = 'expected'");
            }
        } catch(PDOException $e) {}

        // ==================== OTHER STATISTICS ====================
        // Check if research_databases table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='research_databases'");
            if ($stmt->fetch() !== false) {
                $totalResearchDatabases = safeQuery($db, "SELECT COUNT(*) FROM research_databases WHERE deleted_at IS NULL");
                $activeResearchDatabases = safeQuery($db, "SELECT COUNT(*) FROM research_databases WHERE is_active = 1 AND deleted_at IS NULL");
            }
        } catch(PDOException $e) {}
        
        // Check if notices table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='notices'");
            if ($stmt->fetch() !== false) {
                $totalNotices = safeQuery($db, "SELECT COUNT(*) FROM notices WHERE is_active = 1");
            }
        } catch(PDOException $e) {}
        
        // Check if vendors table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='vendors'");
            if ($stmt->fetch() !== false) {
                $totalVendors = safeQuery($db, "SELECT COUNT(*) FROM vendors");
            }
        } catch(PDOException $e) {}
        
        // Check if purchase_orders table exists
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='purchase_orders'");
            if ($stmt->fetch() !== false) {
                $totalPurchaseOrders = safeQuery($db, "SELECT COUNT(*) FROM purchase_orders");
                $pendingPurchaseOrders = safeQuery($db, "SELECT COUNT(*) FROM purchase_orders WHERE status IN ('pending', 'approved')");
            }
        } catch(PDOException $e) {}

        // Member Category Distribution
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='members'");
            if ($stmt->fetch() !== false) {
                $stmt = $db->query("SELECT member_category, COUNT(*) as count FROM members WHERE member_category IS NOT NULL AND member_category != '' GROUP BY member_category ORDER BY count DESC");
                $memberCategories = $stmt->fetchAll();
            }
        } catch(PDOException $e) {}

        // Monthly Circulation Data (last 12 months)
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            if ($stmt->fetch() !== false) {
                for ($i = 11; $i >= 0; $i--) {
                    $month = date('Y-m', strtotime("-$i months"));
                    $monthName = date('M', strtotime("-$i months"));
                    $issued = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE strftime('%Y-%m', issue_date) = '$month'");
                    $returned = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE strftime('%Y-%m', return_date) = '$month'");
                    $monthlyData[] = ['month' => $monthName, 'issued' => (int)$issued, 'returned' => (int)$returned];
                }
            }
        } catch(PDOException $e) {}

        // Books Issued Per Day (Last 30 days)
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            if ($stmt->fetch() !== false) {
                for ($i = 29; $i >= 0; $i--) {
                    $day = date('Y-m-d', strtotime("-$i days"));
                    $dayLabel = date('M d', strtotime($day));
                    $issued = safeQuery($db, "SELECT COUNT(*) FROM circulation WHERE date(issue_date) = '$day'");
                    $dailyIssuedData[] = ['date' => $dayLabel, 'issued' => (int)$issued];
                }
            }
        } catch(PDOException $e) {}

        // Popular Books (Top 10 most issued) with covers
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            $circulationExists = $stmt->fetch() !== false;
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books'");
            $booksExists = $stmt->fetch() !== false;
            
            if ($circulationExists && $booksExists) {
                $stmt = $db->query("SELECT b.id, b.title, b.author, b.cover_path, COUNT(c.id) as issue_count 
                                    FROM circulation c 
                                    JOIN books b ON c.barcode = b.barcode 
                                    GROUP BY b.id 
                                    ORDER BY issue_count DESC 
                                    LIMIT 10");
                $popularBooks = $stmt->fetchAll();
                foreach ($popularBooks as &$book) {
                    $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
                }
            }
        } catch(PDOException $e) {}

        // Occupancy Trends (Last 7 days)
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='entry_exit'");
            if ($stmt->fetch() !== false) {
                for ($i = 6; $i >= 0; $i--) {
                    $day = date('Y-m-d', strtotime("-$i days"));
                    $dayLabel = date('M d', strtotime($day));
                    $entries = safeQuery($db, "SELECT COUNT(*) FROM entry_exit WHERE entry_date = '$day'");
                    $exits = safeQuery($db, "SELECT COUNT(*) FROM entry_exit WHERE date(exit_time) = '$day'");
                    $occupancyData[] = ['date' => $dayLabel, 'entries' => (int)$entries, 'exits' => (int)$exits];
                }
            }
        } catch(PDOException $e) {}

        // Fine Collection Trends (Last 12 months)
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='fine_payments'");
            $finePaymentsExists = $stmt->fetch() !== false;
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            $circulationExists = $stmt->fetch() !== false;
            
            if ($finePaymentsExists && $circulationExists) {
                for ($i = 11; $i >= 0; $i--) {
                    $month = date('Y-m', strtotime("-$i months"));
                    $monthName = date('M', strtotime("-$i months"));
                    $collected = safeQuery($db, "SELECT COALESCE(SUM(amount), 0) FROM fine_payments WHERE strftime('%Y-%m', payment_date) = '$month'");
                    $finesCharged = safeQuery($db, "SELECT COALESCE(SUM(fine), 0) FROM circulation WHERE strftime('%Y-%m', return_date) = '$month'");
                    $fineTrends[] = ['month' => $monthName, 'collected' => (float)$collected, 'charged' => (float)$finesCharged];
                }
            }
        } catch(PDOException $e) {}

        // Top Categories
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books'");
            if ($stmt->fetch() !== false) {
                $stmt = $db->query("SELECT category, COUNT(*) as count FROM books WHERE category IS NOT NULL AND category != '' GROUP BY category ORDER BY count DESC LIMIT 5");
                $topCategories = $stmt->fetchAll();
            }
        } catch(PDOException $e) {}

        // Recent Activities
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='activity_logs'");
            if ($stmt->fetch() !== false) {
                $stmt = $db->query("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 10");
                $recentActivities = $stmt->fetchAll();
            }
        } catch(PDOException $e) {}

        // Recent Members with photos
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='members'");
            if ($stmt->fetch() !== false) {
                $stmt = $db->query("SELECT admno, name, member_category, photo_path, created_at FROM members ORDER BY created_at DESC LIMIT 5");
                $recentMembers = $stmt->fetchAll();
                foreach ($recentMembers as &$member) {
                    $member['photo_base64'] = getImageBase64($member['photo_path'] ?? '');
                }
            }
        } catch(PDOException $e) {}

        // Recent Circulation with member photos and book covers
        try {
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='circulation'");
            $circulationExists = $stmt->fetch() !== false;
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='members'");
            $membersExists = $stmt->fetch() !== false;
            $stmt = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books'");
            $booksExists = $stmt->fetch() !== false;
            
            if ($circulationExists && $membersExists && $booksExists) {
                $stmt = $db->query("SELECT c.*, m.name as member_name, m.photo_path as member_photo_path,
                                           b.title, b.cover_path as book_cover_path
                                    FROM circulation c 
                                    LEFT JOIN members m ON c.admno = m.admno 
                                    LEFT JOIN books b ON c.barcode = b.barcode
                                    ORDER BY c.issue_date DESC LIMIT 10");
                $recentCirculation = $stmt->fetchAll();
                foreach ($recentCirculation as &$trans) {
                    $trans['member_photo_base64'] = getImageBase64($trans['member_photo_path'] ?? '');
                    $trans['book_cover_base64'] = getImageBase64($trans['book_cover_path'] ?? '');
                }
            }
        } catch(PDOException $e) {}

        $dashboardStats = compact(
            'totalMembers', 'activeMembers', 'inactiveMembers', 'totalStaff', 'newMembersThisMonth',
            'totalBooks', 'totalTitles', 'availableBooks', 'totalEbooks', 'lowStock', 'totalLost', 'booksAddedThisMonth',
            'totalIssued', 'totalOverdue', 'totalReturned', 'totalCirculation',
            'todayIssued', 'todayReturned', 'monthIssued', 'monthReturned',
            'totalFines', 'totalFineCollected', 'pendingFines', 'finesCollectedThisMonth',
            'totalHolds', 'pendingReservations', 'upcomingEvents', 'pendingSuggestions',
            'currentInside', 'todayVisitors', 'monthVisitors', 'birthdayCount', 'expiringMemberships',
            // New stats
            'totalSerials', 'activeSerials', 'expiredSerials', 'cancelledSerials',
            'totalSerialIssues', 'receivedIssues', 'missingIssues', 'expectedIssues',
            'ebookDownloads', 'ebooksWithCover', 'ebooksWithoutCover',
            'totalResearchDatabases', 'activeResearchDatabases',
            'totalNotices', 'totalSuggestions', 'pendingSuggestions',
            'totalVendors', 'totalPurchaseOrders', 'pendingPurchaseOrders',
            'totalLibraryEvents', 'upcomingEvents',
            'memberCategories', 'monthlyData', 'dailyIssuedData', 'popularBooks',
            'occupancyData', 'fineTrends', 'topCategories', 'recentActivities',
            'recentMembers', 'recentCirculation'
        );
        cacheSet('dashboard_stats', $dashboardStats, 300);
    } catch (Exception $e) {
        error_log("Dashboard stats fetch error: " . $e->getMessage());
        $dashboardStats = [
            'totalMembers' => 0, 'activeMembers' => 0, 'inactiveMembers' => 0, 'totalStaff' => 0, 'newMembersThisMonth' => 0,
            'totalBooks' => 0, 'totalTitles' => 0, 'availableBooks' => 0, 'totalEbooks' => 0, 'lowStock' => 0, 'totalLost' => 0, 'booksAddedThisMonth' => 0,
            'totalIssued' => 0, 'totalOverdue' => 0, 'totalReturned' => 0, 'totalCirculation' => 0,
            'todayIssued' => 0, 'todayReturned' => 0, 'monthIssued' => 0, 'monthReturned' => 0,
            'totalFines' => 0, 'totalFineCollected' => 0, 'pendingFines' => 0, 'finesCollectedThisMonth' => 0,
            'totalHolds' => 0, 'pendingReservations' => 0, 'upcomingEvents' => 0, 'pendingSuggestions' => 0,
            'currentInside' => 0, 'todayVisitors' => 0, 'monthVisitors' => 0, 'birthdayCount' => 0, 'expiringMemberships' => 0,
            'totalSerials' => 0, 'activeSerials' => 0, 'expiredSerials' => 0, 'cancelledSerials' => 0,
            'totalSerialIssues' => 0, 'receivedIssues' => 0, 'missingIssues' => 0, 'expectedIssues' => 0,
            'ebookDownloads' => 0, 'ebooksWithCover' => 0, 'ebooksWithoutCover' => 0,
            'totalResearchDatabases' => 0, 'activeResearchDatabases' => 0,
            'totalNotices' => 0, 'totalSuggestions' => 0, 'pendingSuggestions' => 0,
            'totalVendors' => 0, 'totalPurchaseOrders' => 0, 'pendingPurchaseOrders' => 0,
            'totalLibraryEvents' => 0, 'upcomingEvents' => 0,
            'memberCategories' => [], 'monthlyData' => [], 'dailyIssuedData' => [], 'popularBooks' => [],
            'occupancyData' => [], 'fineTrends' => [], 'topCategories' => [], 'recentActivities' => [],
            'recentMembers' => [], 'recentCirculation' => []
        ];
        cacheSet('dashboard_stats', $dashboardStats, 300);
    }
}

extract($dashboardStats);

// Ensure all variables are defined (fallback for any missing)
$totalMembers = $totalMembers ?? 0;
$activeMembers = $activeMembers ?? 0;
$inactiveMembers = $inactiveMembers ?? 0;
$totalStaff = $totalStaff ?? 0;
$newMembersThisMonth = $newMembersThisMonth ?? 0;
$totalBooks = $totalBooks ?? 0;
$totalTitles = $totalTitles ?? 0;
$availableBooks = $availableBooks ?? 0;
$totalEbooks = $totalEbooks ?? 0;
$lowStock = $lowStock ?? 0;
$totalLost = $totalLost ?? 0;
$booksAddedThisMonth = $booksAddedThisMonth ?? 0;
$totalIssued = $totalIssued ?? 0;
$totalOverdue = $totalOverdue ?? 0;
$totalReturned = $totalReturned ?? 0;
$totalCirculation = $totalCirculation ?? 0;
$todayIssued = $todayIssued ?? 0;
$todayReturned = $todayReturned ?? 0;
$monthIssued = $monthIssued ?? 0;
$monthReturned = $monthReturned ?? 0;
$totalFines = $totalFines ?? 0;
$totalFineCollected = $totalFineCollected ?? 0;
$pendingFines = $pendingFines ?? 0;
$finesCollectedThisMonth = $finesCollectedThisMonth ?? 0;
$totalHolds = $totalHolds ?? 0;
$pendingReservations = $pendingReservations ?? 0;
$upcomingEvents = $upcomingEvents ?? 0;
$pendingSuggestions = $pendingSuggestions ?? 0;
$currentInside = $currentInside ?? 0;
$todayVisitors = $todayVisitors ?? 0;
$monthVisitors = $monthVisitors ?? 0;
$birthdayCount = $birthdayCount ?? 0;
$expiringMemberships = $expiringMemberships ?? 0;
// Serials
$totalSerials = $totalSerials ?? 0;
$activeSerials = $activeSerials ?? 0;
$expiredSerials = $expiredSerials ?? 0;
$cancelledSerials = $cancelledSerials ?? 0;
$totalSerialIssues = $totalSerialIssues ?? 0;
$receivedIssues = $receivedIssues ?? 0;
$missingIssues = $missingIssues ?? 0;
$expectedIssues = $expectedIssues ?? 0;
// eBooks
$ebookDownloads = $ebookDownloads ?? 0;
$ebooksWithCover = $ebooksWithCover ?? 0;
$ebooksWithoutCover = $ebooksWithoutCover ?? 0;
// Other
$totalResearchDatabases = $totalResearchDatabases ?? 0;
$activeResearchDatabases = $activeResearchDatabases ?? 0;
$totalNotices = $totalNotices ?? 0;
$totalSuggestions = $totalSuggestions ?? 0;
$pendingSuggestions = $pendingSuggestions ?? 0;
$totalVendors = $totalVendors ?? 0;
$totalPurchaseOrders = $totalPurchaseOrders ?? 0;
$pendingPurchaseOrders = $pendingPurchaseOrders ?? 0;
$totalLibraryEvents = $totalLibraryEvents ?? 0;
$upcomingEvents = $upcomingEvents ?? 0;
// Arrays
$memberCategories = $memberCategories ?? [];
$monthlyData = $monthlyData ?? [];
$dailyIssuedData = $dailyIssuedData ?? [];
$popularBooks = $popularBooks ?? [];
$occupancyData = $occupancyData ?? [];
$fineTrends = $fineTrends ?? [];
$topCategories = $topCategories ?? [];
$recentActivities = $recentActivities ?? [];
$recentMembers = $recentMembers ?? [];
$recentCirculation = $recentCirculation ?? [];

$memberPercentage = $totalMembers > 0 ? round(($activeMembers / $totalMembers) * 100) : 0;
$bookPercentage = $totalBooks > 0 ? round(($availableBooks / $totalBooks) * 100) : 0;
$greeting = (function() { $h = (int)date('H'); return $h < 12 ? 'Good Morning' : ($h < 17 ? 'Good Afternoon' : 'Good Evening'); })();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        
        * { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; }
        body { background: #f4f7fc; }
        
        .settings-bar { display: none !important; }
        
        .welcome-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .welcome-card .welcome-stats {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            margin-top: 15px;
        }
        .welcome-card .welcome-stat {
            background: rgba(255,255,255,0.15);
            border-radius: 12px;
            padding: 8px 15px;
            text-align: center;
        }
        .welcome-card .welcome-stat .small { opacity: 0.8; }
        
        .dashboard-stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            border-radius: 20px;
            padding: 20px;
            transition: all 0.3s ease;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: relative;
            overflow: hidden;
            height: 100%;
        }
        .dashboard-stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .dashboard-stat-card .stat-icon {
            position: absolute;
            right: 15px;
            top: 15px;
            font-size: 45px;
            opacity: 0.15;
            color: white;
        }
        .dashboard-stat-card .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
            color: white;
        }
        .dashboard-stat-card .stat-value.text-danger { color: #ff6b6b !important; }
        .dashboard-stat-card .stat-label {
            font-size: 14px;
            color: rgba(255,255,255,0.9);
            margin-bottom: 0;
        }
        .dashboard-stat-card .stat-change {
            font-size: 12px;
            margin-top: 8px;
            color: rgba(255,255,255,0.8);
        }
        .dashboard-stat-card .stat-change.positive { color: #8bc34a; }
        .dashboard-stat-card .stat-change.negative { color: #ff6b6b; }
        .dashboard-stat-card .progress {
            background: rgba(255,255,255,0.2);
        }
        .dashboard-stat-card .progress .progress-bar {
            background: rgba(255,255,255,0.8) !important;
        }
        
        .quick-action-btn {
            padding: 15px;
            border-radius: 15px;
            background: white;
            transition: all 0.3s;
            text-align: center;
            cursor: pointer;
            border: 1px solid #e9ecef;
            margin-bottom: 10px;
        }
        .quick-action-btn:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 5px 15px rgba(0,0,0,0.1); 
            border-color: var(--primary-color);
        }
        .quick-action-btn i { font-size: 24px; margin-bottom: 8px; display: block; }
        .quick-action-btn .text-primary { color: var(--primary-color) !important; }
        .quick-action-btn .text-success { color: #28a745 !important; }
        .quick-action-btn .text-warning { color: #ffc107 !important; }
        .quick-action-btn .text-info { color: #17a2b8 !important; }
        .quick-action-btn .text-danger { color: #dc3545 !important; }
        .quick-action-btn .text-secondary { color: #6c757d !important; }
        .quick-action-btn .text-dark { color: #343a40 !important; }
        
        .chart-container {
            background: white;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            height: 100%;
            margin-bottom: 20px;
        }
        .chart-container h5 { color: var(--primary-color); }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .btn-outline-primary.active {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .member-photo-small {
            width: 35px;
            height: 35px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #e9ecef;
            background: #f8f9fa;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }
        .member-photo-small:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .member-photo-placeholder {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: linear-gradient(135deg, #e9ecef, #dee2e6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 0.9rem;
            border: 2px solid #e9ecef;
            flex-shrink: 0;
        }
        
        .book-cover-small {
            width: 30px;
            height: 42px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            background: #f8f9fa;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }
        .book-cover-small:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10;
            position: relative;
        }
        .book-cover-placeholder {
            width: 30px;
            height: 42px;
            border-radius: 4px;
            background: linear-gradient(135deg, #e9ecef, #dee2e6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 0.7rem;
            border: 1px solid #e9ecef;
            flex-shrink: 0;
        }
        
        .transaction-cell { display: flex; align-items: center; gap: 10px; }
        .member-cell { display: flex; align-items: center; gap: 10px; }
        
        .activity-item {
            padding: 12px 0;
            border-bottom: 1px solid #e9ecef;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .activity-item:hover { background: #f8f9fa; padding-left: 10px; }
        .activity-icon {
            width: 35px;
            height: 35px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .status-badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 500; }
        .status-issued { background: #17a2b8; color: white; }
        .status-returned { background: #28a745; color: white; }
        .status-overdue { background: #dc3545; color: white; }
        
        .popular-book-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            border-radius: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .popular-book-item:hover {
            background: #f8f9fa;
            transform: translateX(5px);
        }
        
        [dir="rtl"] .stat-icon { right: auto; left: 15px; }
        [dir="rtl"] .welcome-stat { text-align: center; }
        [dir="rtl"] .activity-item { padding-right: 10px; padding-left: 0; }
        [dir="rtl"] .activity-item:hover { padding-right: 20px; padding-left: 0; }
        [dir="rtl"] .popular-book-item:hover { transform: translateX(-5px); }
        [dir="rtl"] .member-cell,
        [dir="rtl"] .transaction-cell { flex-direction: row-reverse; }
        
        @media (max-width: 768px) {
            .stat-value { font-size: 24px; }
            .dashboard-stat-card { padding: 15px; }
            .stat-icon { font-size: 35px; }
            .member-photo-small { width: 28px; height: 28px; }
            .book-cover-small { width: 24px; height: 34px; }
            .transaction-cell { gap: 6px; }
            .member-cell { gap: 6px; }
            .welcome-card .welcome-stats { gap: 10px; }
            .welcome-card .welcome-stat { padding: 5px 10px; }
        }
        
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .dashboard-stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .dashboard-stat-card .stat-value { color: #333 !important; }
            .dashboard-stat-card .stat-label { color: #555 !important; }
            .dashboard-stat-card .stat-change { color: #666 !important; }
            .dashboard-stat-card .stat-icon { display: none !important; }
            .welcome-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .welcome-card .welcome-stat { background: #e9ecef !important; }
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap gap-2">
        <h2 style="color: var(--primary-color);"><i class="fas fa-shield-alt"></i> Admin Dashboard</h2>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            <a href="settings.php" class="btn btn-secondary btn-sm"><i class="fas fa-cog"></i> Settings</a>
            <button class="btn btn-info btn-sm" onclick="location.reload()"><i class="fas fa-sync-alt"></i> Refresh</button>
        </div>
    </div>

    <!-- Welcome Card -->
    <div class="welcome-card">
        <div class="row align-items-center">
            <div class="col-md-7">
                <h2 class="mb-2"><i class="fas fa-chalkboard-user me-2"></i> <?= $greeting ?>, <?= htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['username']) ?>!</h2>
                <p class="mb-3 opacity-75">Today is <?= date('l, F j, Y') ?> | <?= date('g:i A') ?></p>
                <div class="welcome-stats">
                    <div class="welcome-stat"><div class="small">Today's Visitors</div><div class="fw-bold fs-4"><?= $todayVisitors ?></div></div>
                    <div class="welcome-stat"><div class="small">Currently Inside</div><div class="fw-bold fs-4"><?= $currentInside ?></div></div>
                    <div class="welcome-stat"><div class="small">Today's Issues</div><div class="fw-bold fs-4"><?= $todayIssued ?></div></div>
                    <div class="welcome-stat"><div class="small">Today's Returns</div><div class="fw-bold fs-4"><?= $todayReturned ?></div></div>
                </div>
            </div>
            <div class="col-md-5 text-center"><i class="fas fa-chart-line fa-4x opacity-50"></i></div>
        </div>
    </div>

    <!-- Statistics Cards Row 1 - Same order as books.php -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-copy"></i></div>
                <div class="stat-value"><?= number_format($totalBooks) ?></div>
                <div class="stat-label">Total Copies</div>
                <div class="stat-change positive"><i class="fas fa-book"></i> Sum of quantities</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-book-open"></i></div>
                <div class="stat-value"><?= number_format($totalTitles) ?></div>
                <div class="stat-label">Number of Titles</div>
                <div class="stat-change"><i class="fas fa-list"></i> Distinct books</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value"><?= number_format($availableBooks) ?></div>
                <div class="stat-label">Available Copies</div>
                <div class="stat-change positive"><i class="fas fa-thumbs-up"></i> Ready to issue</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                <div class="stat-value"><?= number_format($totalIssued) ?></div>
                <div class="stat-label">Issued Copies</div>
                <div class="stat-change"><i class="fas fa-book-reader"></i> Currently on loan</div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 2 - Same order as books.php -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-value <?= $lowStock > 0 ? 'text-danger' : '' ?>"><?= number_format($lowStock) ?></div>
                <div class="stat-label">Low Stock Titles</div>
                <div class="stat-change <?= $lowStock > 0 ? 'negative' : 'positive' ?>"><i class="fas fa-thermometer-half"></i> Available ≤ 2</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                <div class="stat-value"><?= formatCurrency($totalFineCollected) ?></div>
                <div class="stat-label">Total Fines</div>
                <div class="stat-change"><i class="fas fa-coins"></i> From overdue books</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-times"></i></div>
                <div class="stat-value"><?= number_format($totalLost) ?></div>
                <div class="stat-label">Lost Books</div>
                <div class="stat-change negative"><i class="fas fa-frown"></i> Marked as lost</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value"><?= number_format($totalMembers) ?></div>
                <div class="stat-label">Total Members</div>
                <div class="stat-change positive"><i class="fas fa-user-plus"></i> <?= $activeMembers ?> Active</div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 3 - Serials -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-newspaper"></i></div>
                <div class="stat-value"><?= number_format($totalSerials) ?></div>
                <div class="stat-label">Total Serials</div>
                <div class="stat-change positive"><i class="fas fa-check-circle"></i> <?= $activeSerials ?> Active</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                <div class="stat-value"><?= number_format($receivedIssues) ?></div>
                <div class="stat-label">Issues Received</div>
                <div class="stat-change"><i class="fas fa-arrow-down"></i> <?= $expectedIssues ?> Expected</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-value <?= $missingIssues > 0 ? 'text-danger' : '' ?>"><?= number_format($missingIssues) ?></div>
                <div class="stat-label">Missing Issues</div>
                <div class="stat-change <?= $missingIssues > 0 ? 'negative' : 'positive' ?>">
                    <?= $missingIssues > 0 ? '<i class="fas fa-times-circle"></i> Need attention' : '<i class="fas fa-check-circle"></i> All good' ?>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= number_format($expectedIssues) ?></div>
                <div class="stat-label">Expected Issues</div>
                <div class="stat-change"><i class="fas fa-hourglass-half"></i> Pending arrival</div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 4 - eBooks & Other -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-file-pdf"></i></div>
                <div class="stat-value"><?= number_format($totalEbooks) ?></div>
                <div class="stat-label">Total eBooks</div>
                <div class="stat-change positive"><i class="fas fa-cloud-download-alt"></i> <?= $ebookDownloads ?> Downloads</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-database"></i></div>
                <div class="stat-value"><?= number_format($totalResearchDatabases) ?></div>
                <div class="stat-label">Research Databases</div>
                <div class="stat-change positive"><i class="fas fa-check-circle"></i> <?= $activeResearchDatabases ?> Active</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-lightbulb"></i></div>
                <div class="stat-value"><?= number_format($totalSuggestions) ?></div>
                <div class="stat-label">Suggestions</div>
                <div class="stat-change <?= $pendingSuggestions > 0 ? 'negative' : 'positive' ?>">
                    <?= $pendingSuggestions > 0 ? '<i class="fas fa-clock"></i> ' . $pendingSuggestions . ' Pending' : '<i class="fas fa-check-circle"></i> All reviewed' ?>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
                <div class="stat-value"><?= number_format($upcomingEvents) ?></div>
                <div class="stat-label">Upcoming Events</div>
                <div class="stat-change"><i class="fas fa-calendar-week"></i> <?= number_format($totalLibraryEvents) ?> Total</div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards Row 5 - Additional Other Stats -->
    <div class="row g-4 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-bullhorn"></i></div>
                <div class="stat-value"><?= number_format($totalNotices) ?></div>
                <div class="stat-label">Active Notices</div>
                <div class="stat-change"><i class="fas fa-bell"></i> Published notices</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-truck"></i></div>
                <div class="stat-value"><?= number_format($totalVendors) ?></div>
                <div class="stat-label">Vendors</div>
                <div class="stat-change"><i class="fas fa-building"></i> Registered vendors</div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-value"><?= number_format($totalPurchaseOrders) ?></div>
                <div class="stat-label">Purchase Orders</div>
                <div class="stat-change <?= $pendingPurchaseOrders > 0 ? 'negative' : 'positive' ?>">
                    <?= $pendingPurchaseOrders > 0 ? '<i class="fas fa-clock"></i> ' . $pendingPurchaseOrders . ' Pending' : '<i class="fas fa-check-circle"></i> All processed' ?>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="dashboard-stat-card">
                <div class="stat-icon"><i class="fas fa-calendar-plus"></i></div>
                <div class="stat-value"><?= number_format($newMembersThisMonth) ?></div>
                <div class="stat-label">New Members (This Month)</div>
                <div class="stat-change positive"><i class="fas fa-user-plus"></i> New registrations</div>
            </div>
        </div>
    </div>

    <!-- Charts Row 1 -->
    <div class="row g-4 mb-4">
        <div class="col-xl-6">
            <div class="chart-container">
                <div class="d-flex justify-content-between flex-wrap">
                    <h5><i class="fas fa-chart-line text-primary me-2"></i> Circulation Trend (12 Months)</h5>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-outline-primary active" onclick="toggleChartType('circulationChart','line')">Line</button>
                        <button class="btn btn-outline-primary" onclick="toggleChartType('circulationChart','bar')">Bar</button>
                    </div>
                </div>
                <canvas id="circulationChart" style="height:280px"></canvas>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="chart-container">
                <h5><i class="fas fa-chart-line text-success me-2"></i> Fine Collection Trends (12 Months)</h5>
                <canvas id="fineTrendsChart" style="height:280px"></canvas>
            </div>
        </div>
    </div>

    <!-- Charts Row 2 -->
    <div class="row g-4 mb-4">
        <div class="col-xl-6">
            <div class="chart-container">
                <h5><i class="fas fa-calendar-day text-primary me-2"></i> Books Issued Per Day (Last 30 Days)</h5>
                <canvas id="dailyIssuedChart" style="height:280px"></canvas>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="chart-container">
                <h5><i class="fas fa-door-open text-warning me-2"></i> Occupancy Trends (Last 7 Days)</h5>
                <canvas id="occupancyChart" style="height:280px"></canvas>
            </div>
        </div>
    </div>

    <!-- Charts Row 3 -->
    <div class="row g-4 mb-4">
        <div class="col-xl-6">
            <div class="chart-container">
                <h5><i class="fas fa-trophy text-warning me-2"></i> Most Popular Books (Top 10)</h5>
                <canvas id="popularBooksChart" style="height:280px"></canvas>
                <?php if (!empty($popularBooks)): ?>
                <div class="mt-3">
                    <?php foreach (array_slice($popularBooks, 0, 5) as $idx => $book): ?>
                    <div class="popular-book-item">
                        <?php if ($book['cover_base64']): ?>
                            <img src="<?= $book['cover_base64'] ?>" class="book-cover-small" alt="Cover">
                        <?php else: ?>
                            <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                        <?php endif; ?>
                        <div class="flex-grow-1 small">
                            <strong><?= htmlspecialchars(substr($book['title'], 0, 35)) ?></strong>
                            <br><small class="text-muted"><?= htmlspecialchars($book['author'] ?? 'Unknown') ?></small>
                        </div>
                        <span class="badge bg-warning rounded-pill"><?= $book['issue_count'] ?>x</span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="chart-container">
                <h5><i class="fas fa-chart-pie text-info me-2"></i> Member Categories</h5>
                <canvas id="categoryChart" style="height:220px"></canvas>
                <div class="mt-3">
                    <?php foreach ($memberCategories as $cat): ?>
                    <div class="d-flex justify-content-between small mb-2">
                        <span>
                            <span class="badge me-2" style="background:<?= getCategoryColor($cat['member_category']) ?> !important;">&nbsp;</span>
                            <?= htmlspecialchars($cat['member_category'] ?: 'Uncategorized') ?>
                        </span>
                        <span class="fw-bold"><?= number_format($cat['count']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Categories & Recent Activity & Recent Members -->
    <div class="row g-4 mb-4">
        <div class="col-xl-4">
            <div class="chart-container">
                <h5><i class="fas fa-tags text-primary me-2"></i> Top Book Categories</h5>
                <?php if (!empty($topCategories)): foreach ($topCategories as $idx=>$cat): ?>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span><span class="badge bg-secondary me-2"><?= $idx+1 ?></span><strong><?= htmlspecialchars($cat['category'] ?: 'Uncategorized') ?></strong></span>
                    <span class="badge bg-primary rounded-pill"><?= number_format($cat['count']) ?> books</span>
                </div>
                <div class="progress mb-3" style="height:6px">
                    <div class="progress-bar" style="width:<?= min(100, ($cat['count']/max($topCategories[0]['count'],1))*100) ?>%; background:<?= getCategoryColor($cat['category']) ?>"></div>
                </div>
                <?php endforeach; else: ?>
                <div class="text-muted text-center py-4">No category data</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="chart-container">
                <h5><i class="fas fa-history text-primary me-2"></i> Recent Activities</h5>
                <div class="activity-list" style="max-height:350px;overflow-y:auto">
                    <?php if(!empty($recentActivities)): foreach($recentActivities as $act): ?>
                    <div class="activity-item">
                        <div class="activity-icon bg-<?= getActivityColor($act['action']) ?> bg-opacity-10">
                            <i class="fas <?= getActivityIcon($act['action']) ?> text-<?= getActivityColor($act['action']) ?>"></i>
                        </div>
                        <div>
                            <div class="small fw-semibold"><?= htmlspecialchars($act['username']) ?></div>
                            <div class="small text-muted"><?= htmlspecialchars($act['action']) ?></div>
                            <div class="small text-muted"><i class="far fa-clock"></i> <?= timeAgo($act['created_at']) ?></div>
                        </div>
                    </div>
                    <?php endforeach; else: ?>
                    <div class="text-muted text-center py-4">No recent activities</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
            <div class="chart-container">
                <h5><i class="fas fa-user-plus text-primary me-2"></i> Recent Members</h5>
                <div class="activity-list" style="max-height:350px;overflow-y:auto">
                    <?php if(!empty($recentMembers)): foreach($recentMembers as $m): ?>
                    <div class="activity-item">
                        <?php if ($m['photo_base64']): ?>
                            <img src="<?= $m['photo_base64'] ?>" class="member-photo-small" alt="Member Photo">
                        <?php else: ?>
                            <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                        <?php endif; ?>
                        <div>
                            <div class="small fw-semibold"><?= htmlspecialchars($m['name']) ?></div>
                            <div class="small text-muted">ID: <?= htmlspecialchars($m['admno']) ?> | <?= htmlspecialchars($m['member_category'] ?: 'Member') ?></div>
                            <div class="small text-muted"><i class="far fa-calendar-alt"></i> <?= formatDate($m['created_at']) ?></div>
                        </div>
                    </div>
                    <?php endforeach; else: ?>
                    <div class="text-muted text-center py-4">No recent members</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Circulation Table with Photos -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="chart-container">
                <h5><i class="fas fa-exchange-alt text-primary me-2"></i> Recent Transactions</h5>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Member</th>
                                <th>Book</th>
                                <th>Due Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($recentCirculation)): foreach($recentCirculation as $r): ?>
                            <tr>
                                <td><?= formatDate($r['issue_date']) ?></td>
                                <td>
                                    <div class="member-cell">
                                        <?php if ($r['member_photo_base64']): ?>
                                            <img src="<?= $r['member_photo_base64'] ?>" class="member-photo-small" alt="Member Photo">
                                        <?php else: ?>
                                            <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                        <?php endif; ?>
                                        <div>
                                            <strong><?= htmlspecialchars($r['member_name'] ?? 'Unknown') ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($r['admno']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="transaction-cell">
                                        <?php if ($r['book_cover_base64']): ?>
                                            <img src="<?= $r['book_cover_base64'] ?>" class="book-cover-small" alt="Book Cover">
                                        <?php else: ?>
                                            <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                        <?php endif; ?>
                                        <div>
                                            <?= htmlspecialchars(substr($r['title'] ?? 'Unknown', 0, 35)) ?>
                                            <?php if(strlen($r['title'] ?? '') > 35): ?>...<?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?= formatDate($r['due_date']) ?></td>
                                <td>
                                    <?php if($r['return_date']): ?>
                                        <span class="status-badge status-returned"><i class="fas fa-check-circle"></i> Returned</span>
                                    <?php elseif($r['due_date'] < date('Y-m-d')): ?>
                                        <span class="status-badge status-overdue"><i class="fas fa-exclamation-triangle"></i> Overdue</span>
                                    <?php else: ?>
                                        <span class="status-badge status-issued"><i class="fas fa-book"></i> Issued</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No transactions found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions & System Info -->
    <div class="row g-4 mb-4 no-print">
        <div class="col-md-8">
            <div class="chart-container">
                <h5><i class="fas fa-bolt text-primary me-2"></i> Quick Actions</h5>
                <div class="row g-3">
                    <?php 
                    $actions = [
                        ['members.php', 'Members', 'fa-users', 'primary'],
                        ['books.php', 'Books', 'fa-book', 'success'],
                        ['staff.php', 'Staff', 'fa-user-tie', 'secondary'],
                        ['../circulation/issue.php', 'Issue', 'fa-arrow-right', 'warning'],
                        ['../circulation/return.php', 'Return', 'fa-arrow-left', 'info'],
                        ['../circulation/renew.php', 'Renew', 'fa-sync-alt', 'primary'],
                        ['../entry_exit/', 'Entry/Exit', 'fa-door-open', 'danger'],
                        ['research_databases.php', 'Research DBs', 'fa-database', 'info'],
                        ['../reports/', 'Reports', 'fa-chart-bar', 'danger'],
                        ['backup.php', 'Backup', 'fa-database', 'secondary'],
                        ['settings.php', 'Settings', 'fa-cog', 'dark'],
                        ['../utilities/', 'Utilities', 'fa-toolbox', 'warning']
                    ]; 
                    foreach($actions as $a): ?>
                    <div class="col-md-3 col-6">
                        <div class="quick-action-btn" onclick="location.href='<?= $a[0] ?>'">
                            <i class="fas <?= $a[2] ?> text-<?= $a[3] ?>"></i>
                            <div class="small fw-semibold"><?= $a[1] ?></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="chart-container">
                <h5><i class="fas fa-info-circle text-primary me-2"></i> System Info</h5>
                <div class="small">
                    <div class="d-flex justify-content-between mb-2"><span>PHP Version:</span><span class="fw-semibold"><?= phpversion() ?></span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Database:</span><span class="fw-semibold">SQLite</span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Upload Limit:</span><span class="fw-semibold"><?= ini_get('upload_max_filesize') ?></span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Server Time:</span><span class="fw-semibold"><?= date('Y-m-d H:i:s') ?></span></div>
                    <div class="d-flex justify-content-between mb-2"><span>Memory Limit:</span><span class="fw-semibold"><?= ini_get('memory_limit') ?></span></div>
                    <div class="d-flex justify-content-between"><span>Max Execution:</span><span class="fw-semibold"><?= ini_get('max_execution_time') ?>s</span></div>
                </div>
                <?php if($birthdayCount>0): ?>
                <div class="alert alert-info mt-3 mb-0">
                    <i class="fas fa-birthday-cake me-2"></i>
                    <strong><?= $birthdayCount ?> member(s)</strong> celebrating birthdays this month!
                </div>
                <?php endif; ?>
                <?php if($expiringMemberships>0): ?>
                <div class="alert alert-warning mt-2 mb-0">
                    <i class="fas fa-hourglass-end me-2"></i>
                    <strong><?= $expiringMemberships ?> member(s)</strong> have memberships expiring in 30 days!
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const monthlyData = <?= json_encode($monthlyData) ?>;
const dailyIssuedData = <?= json_encode($dailyIssuedData) ?>;
const popularBooksData = <?= json_encode($popularBooks) ?>;
const occupancyData = <?= json_encode($occupancyData) ?>;
const fineTrendsData = <?= json_encode($fineTrends) ?>;
const categoryLabels = <?= json_encode(array_column($memberCategories, 'member_category')) ?>;
const categoryData = <?= json_encode(array_column($memberCategories, 'count')) ?>;
const categoryColors = categoryLabels.map(l => {
    const colors = {'Student':'#4CAF50','Teacher':'#2196F3','Staff':'#FF9800','Visitor':'#9C27B0','General':'#607D8B','Research Scholar':'#E91E63'};
    return colors[l] || '#6c757d';
});

let circulationChart = new Chart(document.getElementById('circulationChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: monthlyData.map(d=>d.month),
        datasets: [
            {
                label: 'Issued',
                data: monthlyData.map(d=>d.issued),
                borderColor: '#28a745',
                backgroundColor: 'rgba(40,167,69,0.1)',
                fill: true,
                tension: 0.4
            },
            {
                label: 'Returned',
                data: monthlyData.map(d=>d.returned),
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220,53,69,0.1)',
                fill: true,
                tension: 0.4
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        scales: { y: { beginAtZero: true, title: { display: true, text: 'Transactions' } } }
    }
});

new Chart(document.getElementById('fineTrendsChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: fineTrendsData.map(d=>d.month),
        datasets: [
            { label: 'Fines Charged (₹)', data: fineTrendsData.map(d=>d.charged), backgroundColor: 'rgba(220,53,69,0.6)' },
            { label: 'Fines Collected (₹)', data: fineTrendsData.map(d=>d.collected), backgroundColor: 'rgba(40,167,69,0.6)' }
        ]
    },
    options: {
        responsive: true,
        scales: { y: { beginAtZero: true, title: { display: true, text: 'Amount (₹)' } } }
    }
});

new Chart(document.getElementById('dailyIssuedChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: dailyIssuedData.map(d=>d.date),
        datasets: [{ label: 'Books Issued', data: dailyIssuedData.map(d=>d.issued), backgroundColor: '#17a2b8' }]
    },
    options: {
        responsive: true,
        scales: { y: { beginAtZero: true } }
    }
});

new Chart(document.getElementById('occupancyChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: occupancyData.map(d=>d.date),
        datasets: [
            { label: 'Entries', data: occupancyData.map(d=>d.entries), borderColor: '#28a745', fill: true, backgroundColor: 'rgba(40,167,69,0.1)' },
            { label: 'Exits', data: occupancyData.map(d=>d.exits), borderColor: '#dc3545', fill: true, backgroundColor: 'rgba(220,53,69,0.1)' }
        ]
    },
    options: {
        responsive: true,
        scales: { y: { beginAtZero: true } }
    }
});

if(popularBooksData.length) {
    new Chart(document.getElementById('popularBooksChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: popularBooksData.map(b => b.title.length > 25 ? b.title.substr(0,25) + '...' : b.title),
            datasets: [{ label: 'Times Issued', data: popularBooksData.map(b=>b.issue_count), backgroundColor: '#ffc107' }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            scales: { x: { beginAtZero: true } },
            plugins: {
                tooltip: {
                    callbacks: {
                        afterBody: function(context) {
                            const book = popularBooksData[context[0].dataIndex];
                            return book.author ? 'Author: ' + book.author : '';
                        }
                    }
                }
            }
        }
    });
}

if(document.getElementById('categoryChart')) {
    new Chart(document.getElementById('categoryChart').getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: categoryLabels.map(l=>l?l:'Uncategorized'),
            datasets: [{ data: categoryData, backgroundColor: categoryColors, borderWidth: 0, hoverOffset: 10 }]
        },
        options: {
            responsive: true,
            cutout: '60%',
            plugins: { legend: { position: 'bottom' } }
        }
    });
}

function toggleChartType(chartId, type) {
    if(chartId === 'circulationChart') {
        circulationChart.config.type = type;
        circulationChart.update();
    }
    document.querySelectorAll('.btn-group .btn').forEach(btn => btn.classList.remove('active'));
    if(event && event.target) event.target.classList.add('active');
}

setTimeout(function() {
    location.reload();
}, 300000);
</script>
</body>
</html>