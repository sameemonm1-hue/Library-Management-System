<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$db = getDB();
$settings = getSettings();
$currencySymbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');

$message = '';
$error = '';

// Handle add/edit/delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh.";
    } else {
        if (isset($_POST['add_rate'])) {
            $category = trim($_POST['category']);
            $rate = (float)$_POST['rate'];
            if (empty($category)) {
                $error = "Category name is required.";
            } else {
                try {
                    $stmt = $db->prepare("INSERT OR REPLACE INTO fine_rates (member_category, fine_per_day) VALUES (?, ?)");
                    $stmt->execute([$category, $rate]);
                    $message = "Fine rate added successfully.";
                    logActivity($_SESSION['username'], 'FINE_RATE_ADD', "Added rate for $category: $rate");
                } catch (PDOException $e) {
                    $error = "Database error: " . $e->getMessage();
                }
            }
        } elseif (isset($_POST['edit_rate'])) {
            $id = (int)$_POST['id'];
            $category = trim($_POST['category']);
            $rate = (float)$_POST['rate'];
            if (empty($category)) {
                $error = "Category name is required.";
            } else {
                try {
                    $stmt = $db->prepare("UPDATE fine_rates SET member_category = ?, fine_per_day = ? WHERE id = ?");
                    $stmt->execute([$category, $rate, $id]);
                    $message = "Fine rate updated successfully.";
                    logActivity($_SESSION['username'], 'FINE_RATE_EDIT', "Updated rate for $category: $rate");
                } catch (PDOException $e) {
                    $error = "Database error: " . $e->getMessage();
                }
            }
        } elseif (isset($_POST['delete_rate'])) {
            $id = (int)$_POST['id'];
            try {
                $stmt = $db->prepare("DELETE FROM fine_rates WHERE id = ?");
                $stmt->execute([$id]);
                $message = "Fine rate deleted.";
                logActivity($_SESSION['username'], 'FINE_RATE_DELETE', "Deleted fine rate ID $id");
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header("Location: fine_rates.php");
        exit;
    }
}

// Fetch all fine rates
$rates = $db->query("SELECT * FROM fine_rates ORDER BY member_category")->fetchAll();

renderHeader('Fine Rates Management');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-coins"></i> Fine Rates Management</h2>
        <div>
            <a href="settings.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRateModal"><i class="fas fa-plus"></i> Add Fine Rate</button>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header bg-primary text-white"><i class="fas fa-list"></i> Fine Rates by Member Category</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Member Category</th>
                            <th>Fine per Day (<?= htmlspecialchars($currencySymbol) ?>)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rates)): ?>
                            <tr><td colspan="4" class="text-center text-muted py-4">No fine rates defined. Add your first rate.<?php echo ' '; ?></td></tr>
                        <?php else: ?>
                            <?php foreach ($rates as $rate): ?>
                                <tr>
                                    <td class="text-center"><?= (int)$rate['id'] ?> </div>
                                    <td><?= htmlspecialchars($rate['member_category']) ?> </div>
                                    <td class="text-end"><?= number_format((float)$rate['fine_per_day'], 2) ?> </div>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-warning" onclick="editRate(<?= $rate['id'] ?>, '<?= htmlspecialchars(addslashes($rate['member_category'])) ?>', <?= (float)$rate['fine_per_day'] ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <form method="post" style="display:inline-block" onsubmit="return confirm('Delete this fine rate?')">
                                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                            <input type="hidden" name="id" value="<?= $rate['id'] ?>">
                                            <button type="submit" name="delete_rate" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                 </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Rate Modal -->
<div class="modal fade" id="addRateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Add Fine Rate</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Member Category *</label>
                        <input type="text" name="category" class="form-control" required placeholder="e.g., Student, Staff, General">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fine per Day (<?= htmlspecialchars($currencySymbol) ?>)</label>
                        <input type="number" step="0.5" name="rate" class="form-control" value="2" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_rate" class="btn btn-primary">Add Rate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Rate Modal -->
<div class="modal fade" id="editRateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title">Edit Fine Rate</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Member Category *</label>
                        <input type="text" name="category" id="edit_category" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fine per Day (<?= htmlspecialchars($currencySymbol) ?>)</label>
                        <input type="number" step="0.5" name="rate" id="edit_rate" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit_rate" class="btn btn-primary">Update Rate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editRate(id, category, rate) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_category').value = category;
    document.getElementById('edit_rate').value = rate;
    new bootstrap.Modal(document.getElementById('editRateModal')).show();
}
</script>

<?php renderFooter(); ?>