<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$settings = getSettings();
$enableReset = $settings['enable_member_password_reset'] ?? 1;
if (!$enableReset) {
    die("Password reset is currently disabled. Please contact library admin.");
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admno = trim($_POST['admno']);
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    if ($member && !empty($member['email'])) {
        // Generate reset token
        $token = bin2hex(random_bytes(32));
        $expiryHours = (int)($settings['reset_token_expiry_hours'] ?? 24);
        $expiry = date('Y-m-d H:i:s', strtotime("+$expiryHours hours"));
        $update = $db->prepare("UPDATE members SET reset_token = ?, token_expiry = ? WHERE admno = ?");
        $update->execute([$token, $expiry, $admno]);
        
        // Send email
        $resetLink = "https://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']) . "/reset_password.php?token=" . urlencode($token);
        $subject = "Password Reset Request - Library Portal";
        $body = "Dear {$member['name']},<br><br>Click the link below to reset your password:<br><a href='$resetLink'>$resetLink</a><br><br>This link will expire in $expiryHours hours.<br><br>If you did not request this, ignore this email.";
        if (sendEmail($member['email'], $subject, $body)) {
            $message = "A password reset link has been sent to your registered email address.";
        } else {
            $error = "Failed to send email. Please contact library administrator.";
        }
    } else {
        $error = "Member number not found or no email address associated with this account.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#f0f2f5;}.card{max-width:500px;margin:100px auto;border-radius:20px;}</style>
</head>
<body>
<div class="container">
    <div class="card shadow">
        <div class="card-body p-5">
            <h3 class="text-center mb-4">Reset Your Password</h3>
            <?php if($message): ?><div class="alert alert-success"><?= $message ?></div><?php endif; ?>
            <?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
            <form method="post">
                <div class="mb-3"><label>Member Number (Adm No)</label><input type="text" name="admno" class="form-control" required></div>
                <button type="submit" class="btn btn-primary w-100">Send Reset Link</button>
                <div class="text-center mt-3"><a href="login.php">Back to Login</a></div>
            </form>
        </div>
    </div>
</div>
</body>
</html>