<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

// 1. Add password column if missing
try {
    $db->exec("ALTER TABLE members ADD COLUMN password TEXT DEFAULT NULL");
    echo "✅ 'password' column added.<br>";
} catch (PDOException $e) {
    echo "ℹ️ Column already exists (or error): " . $e->getMessage() . "<br>";
}

// 2. Set a default password (123456) for member P12786 (if not already set)
$admno = 'P12786';
$plainPassword = '123456';
$hashed = password_hash($plainPassword, PASSWORD_DEFAULT);

$stmt = $db->prepare("UPDATE members SET password = ? WHERE admno = ? AND (password IS NULL OR password = '')");
$stmt->execute([$hashed, $admno]);

if ($stmt->rowCount() > 0) {
    echo "✅ Password set for member $admno.<br>";
} else {
    echo "ℹ️ Member $admno already has a password (or does not exist).<br>";
}

// Optional: Set password for ALL members who don't have one
$stmtAll = $db->prepare("UPDATE members SET password = ? WHERE password IS NULL OR password = ''");
$stmtAll->execute([$hashed]);
echo "✅ All members without a password now have default password 123456.<br>";

echo "<hr>Done. You can now log in with <strong>$admno</strong> and password <strong>123456</strong>.";