<?php
/**
 * Comprehensive Book Management Module - COMPLETE UPDATE
 * Version: 7.0 - Enhanced with Full Currency Support & Auto Cover Download
 * 
 * Features:
 * - Full and Easy cataloguing modes
 * - Auto barcode generation
 * - Auto Call Number Generation
 * - All country currency codes
 * - Auto download cover image from ISBN
 * - Auto-fetch all book details from ISBN
 * - Metadata fetching from Google Books, OpenLibrary, ISBNdb, WorldCat, Z39.50
 * - Bulk import CSV with automatic metadata & cover fetch
 * - Bulk cover upload via ZIP
 * - MARC21 import/export
 * - Export CSV/Excel/PDF/MARC21 - FULLY WORKING
 * - Export modes: Copies or Titles (grouped)
 * - Statistics dashboard
 * - Dynamic column handling
 * - API key management
 * - VISIBLE COVERS EVERYWHERE
 * - Enhanced UI with cover thumbnails
 * - Modal scrolling fixes
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/export_functions.php';
requireAdmin();

// ==================== CONFIGURATION ====================
$mode = $_GET['mode'] ?? 'full';
if (!in_array($mode, ['full', 'easy'])) $mode = 'full';

// Define upload directories
if (!defined('BOOK_COVER_DIR')) {
    define('BOOK_COVER_DIR', __DIR__ . '/../uploads/books/');
}
if (!defined('BOOK_COVER_URL')) {
    define('BOOK_COVER_URL', 'uploads/books/');
}
if (!is_dir(BOOK_COVER_DIR)) mkdir(BOOK_COVER_DIR, 0777, true);
if (!is_writable(BOOK_COVER_DIR)) @chmod(BOOK_COVER_DIR, 0777);

// Check available libraries
$marcAvailable = false;
$pdfAvailable = false;
$excelAvailable = false;

if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    
    if (class_exists('Scriptotek\Marc\MarcReader') || class_exists('File_MARC')) {
        $marcAvailable = true;
    }
    
    if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) {
        $pdfAvailable = true;
    }
    
    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        $excelAvailable = true;
    }
}

$yazAvailable = extension_loaded('yaz');
$db = getDB();

// ==================== COVER HELPER FUNCTIONS ====================

function getBookCoverBase64($coverPath) {
    if (empty($coverPath)) return '';
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) return '';
    $data = @file_get_contents($fullPath);
    if ($data === false) return '';
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getBookCoverUrl($coverPath) {
    if (empty($coverPath)) return '';
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) return $coverPath;
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (file_exists($fullPath)) {
        return getWebImageUrl($coverPath);
    }
    return '';
}

// ==================== ALL COUNTRY CURRENCIES ====================
$allCurrencies = [
    'AED' => 'AED - United Arab Emirates Dirham (د.إ)',
    'AFN' => 'AFN - Afghan Afghani (؋)',
    'ALL' => 'ALL - Albanian Lek (L)',
    'AMD' => 'AMD - Armenian Dram (֏)',
    'ANG' => 'ANG - Netherlands Antillean Guilder (ƒ)',
    'AOA' => 'AOA - Angolan Kwanza (Kz)',
    'ARS' => 'ARS - Argentine Peso ($)',
    'AUD' => 'AUD - Australian Dollar ($)',
    'AWG' => 'AWG - Aruban Florin (ƒ)',
    'AZN' => 'AZN - Azerbaijani Manat (₼)',
    'BAM' => 'BAM - Bosnia-Herzegovina Convertible Mark (KM)',
    'BBD' => 'BBD - Barbadian Dollar ($)',
    'BDT' => 'BDT - Bangladeshi Taka (৳)',
    'BGN' => 'BGN - Bulgarian Lev (лв)',
    'BHD' => 'BHD - Bahraini Dinar (.د.ب)',
    'BIF' => 'BIF - Burundian Franc (Fr)',
    'BMD' => 'BMD - Bermudian Dollar ($)',
    'BND' => 'BND - Brunei Dollar ($)',
    'BOB' => 'BOB - Bolivian Boliviano (Bs.)',
    'BRL' => 'BRL - Brazilian Real (R$)',
    'BSD' => 'BSD - Bahamian Dollar ($)',
    'BTN' => 'BTN - Bhutanese Ngultrum (Nu.)',
    'BWP' => 'BWP - Botswanan Pula (P)',
    'BYN' => 'BYN - Belarusian Ruble (Br)',
    'BZD' => 'BZD - Belize Dollar ($)',
    'CAD' => 'CAD - Canadian Dollar ($)',
    'CDF' => 'CDF - Congolese Franc (Fr)',
    'CHF' => 'CHF - Swiss Franc (Fr)',
    'CLP' => 'CLP - Chilean Peso ($)',
    'CNY' => 'CNY - Chinese Yuan (¥)',
    'COP' => 'COP - Colombian Peso ($)',
    'CRC' => 'CRC - Costa Rican Colón (₡)',
    'CUP' => 'CUP - Cuban Peso ($)',
    'CVE' => 'CVE - Cape Verdean Escudo ($)',
    'CZK' => 'CZK - Czech Koruna (Kč)',
    'DJF' => 'DJF - Djiboutian Franc (Fr)',
    'DKK' => 'DKK - Danish Krone (kr)',
    'DOP' => 'DOP - Dominican Peso ($)',
    'DZD' => 'DZD - Algerian Dinar (د.ج)',
    'EGP' => 'EGP - Egyptian Pound (E£)',
    'ERN' => 'ERN - Eritrean Nakfa (Nfk)',
    'ETB' => 'ETB - Ethiopian Birr (Br)',
    'EUR' => 'EUR - Euro (€)',
    'FJD' => 'FJD - Fijian Dollar ($)',
    'FKP' => 'FKP - Falkland Islands Pound (£)',
    'GBP' => 'GBP - British Pound (£)',
    'GEL' => 'GEL - Georgian Lari (₾)',
    'GGP' => 'GGP - Guernsey Pound (£)',
    'GHS' => 'GHS - Ghanaian Cedi (₵)',
    'GIP' => 'GIP - Gibraltar Pound (£)',
    'GMD' => 'GMD - Gambian Dalasi (D)',
    'GNF' => 'GNF - Guinean Franc (Fr)',
    'GTQ' => 'GTQ - Guatemalan Quetzal (Q)',
    'GYD' => 'GYD - Guyanese Dollar ($)',
    'HKD' => 'HKD - Hong Kong Dollar ($)',
    'HNL' => 'HNL - Honduran Lempira (L)',
    'HRK' => 'HRK - Croatian Kuna (kn)',
    'HTG' => 'HTG - Haitian Gourde (G)',
    'HUF' => 'HUF - Hungarian Forint (Ft)',
    'IDR' => 'IDR - Indonesian Rupiah (Rp)',
    'ILS' => 'ILS - Israeli New Shekel (₪)',
    'IMP' => 'IMP - Isle of Man Pound (£)',
    'INR' => 'INR - Indian Rupee (₹)',
    'IQD' => 'IQD - Iraqi Dinar (ع.د)',
    'IRR' => 'IRR - Iranian Rial (﷼)',
    'ISK' => 'ISK - Icelandic Króna (kr)',
    'JEP' => 'JEP - Jersey Pound (£)',
    'JMD' => 'JMD - Jamaican Dollar ($)',
    'JOD' => 'JOD - Jordanian Dinar (د.ا)',
    'JPY' => 'JPY - Japanese Yen (¥)',
    'KES' => 'KES - Kenyan Shilling (Sh)',
    'KGS' => 'KGS - Kyrgyzstani Som (с)',
    'KHR' => 'KHR - Cambodian Riel (៛)',
    'KMF' => 'KMF - Comorian Franc (Fr)',
    'KPW' => 'KPW - North Korean Won (₩)',
    'KRW' => 'KRW - South Korean Won (₩)',
    'KWD' => 'KWD - Kuwaiti Dinar (د.ك)',
    'KYD' => 'KYD - Cayman Islands Dollar ($)',
    'KZT' => 'KZT - Kazakhstani Tenge (₸)',
    'LAK' => 'LAK - Lao Kip (₭)',
    'LBP' => 'LBP - Lebanese Pound (ل.ل)',
    'LKR' => 'LKR - Sri Lankan Rupee (Rs)',
    'LRD' => 'LRD - Liberian Dollar ($)',
    'LSL' => 'LSL - Lesotho Loti (L)',
    'LYD' => 'LYD - Libyan Dinar (ل.د)',
    'MAD' => 'MAD - Moroccan Dirham (د.م.)',
    'MDL' => 'MDL - Moldovan Leu (L)',
    'MGA' => 'MGA - Malagasy Ariary (Ar)',
    'MKD' => 'MKD - Macedonian Denar (ден)',
    'MMK' => 'MMK - Myanmar Kyat (Ks)',
    'MNT' => 'MNT - Mongolian Tögrög (₮)',
    'MOP' => 'MOP - Macanese Pataca (MOP$)',
    'MRU' => 'MRU - Mauritanian Ouguiya (UM)',
    'MUR' => 'MUR - Mauritian Rupee (Rs)',
    'MVR' => 'MVR - Maldivian Rufiyaa (Rf)',
    'MWK' => 'MWK - Malawian Kwacha (MK)',
    'MXN' => 'MXN - Mexican Peso ($)',
    'MYR' => 'MYR - Malaysian Ringgit (RM)',
    'MZN' => 'MZN - Mozambican Metical (MT)',
    'NAD' => 'NAD - Namibian Dollar ($)',
    'NGN' => 'NGN - Nigerian Naira (₦)',
    'NIO' => 'NIO - Nicaraguan Córdoba (C$)',
    'NOK' => 'NOK - Norwegian Krone (kr)',
    'NPR' => 'NPR - Nepalese Rupee (Rs)',
    'NZD' => 'NZD - New Zealand Dollar ($)',
    'OMR' => 'OMR - Omani Rial (ر.ع.)',
    'PAB' => 'PAB - Panamanian Balboa (B/.)',
    'PEN' => 'PEN - Peruvian Sol (S/)',
    'PGK' => 'PGK - Papua New Guinean Kina (K)',
    'PHP' => 'PHP - Philippine Peso (₱)',
    'PKR' => 'PKR - Pakistani Rupee (Rs)',
    'PLN' => 'PLN - Polish Złoty (zł)',
    'PYG' => 'PYG - Paraguayan Guaraní (₲)',
    'QAR' => 'QAR - Qatari Rial (ر.ق)',
    'RON' => 'RON - Romanian Leu (lei)',
    'RSD' => 'RSD - Serbian Dinar (дин.)',
    'RUB' => 'RUB - Russian Ruble (₽)',
    'RWF' => 'RWF - Rwandan Franc (Fr)',
    'SAR' => 'SAR - Saudi Riyal (﷼)',
    'SBD' => 'SBD - Solomon Islands Dollar ($)',
    'SCR' => 'SCR - Seychellois Rupee (Rs)',
    'SDG' => 'SDG - Sudanese Pound (ج.س.)',
    'SEK' => 'SEK - Swedish Krona (kr)',
    'SGD' => 'SGD - Singapore Dollar ($)',
    'SHP' => 'SHP - Saint Helena Pound (£)',
    'SLL' => 'SLL - Sierra Leonean Leone (Le)',
    'SOS' => 'SOS - Somali Shilling (Sh)',
    'SRD' => 'SRD - Surinamese Dollar ($)',
    'SSP' => 'SSP - South Sudanese Pound (£)',
    'STN' => 'STN - São Tomé & Príncipe Dobra (Db)',
    'SYP' => 'SYP - Syrian Pound (£)',
    'SZL' => 'SZL - Swazi Lilangeni (L)',
    'THB' => 'THB - Thai Baht (฿)',
    'TJS' => 'TJS - Tajikistani Somoni (ЅМ)',
    'TMT' => 'TMT - Turkmenistani Manat (m)',
    'TND' => 'TND - Tunisian Dinar (د.ت)',
    'TOP' => 'TOP - Tongan Paʻanga (T$)',
    'TRY' => 'TRY - Turkish Lira (₺)',
    'TTD' => 'TTD - Trinidad & Tobago Dollar ($)',
    'TWD' => 'TWD - New Taiwan Dollar (NT$)',
    'TZS' => 'TZS - Tanzanian Shilling (Sh)',
    'UAH' => 'UAH - Ukrainian Hryvnia (₴)',
    'UGX' => 'UGX - Ugandan Shilling (Sh)',
    'USD' => 'USD - US Dollar ($)',
    'UYU' => 'UYU - Uruguayan Peso ($)',
    'UZS' => 'UZS - Uzbekistani Som (soʻm)',
    'VES' => 'VES - Venezuelan Bolívar (Bs.S)',
    'VND' => 'VND - Vietnamese Đồng (₫)',
    'VUV' => 'VUV - Vanuatu Vatu (Vt)',
    'WST' => 'WST - Samoan Tālā (T)',
    'XAF' => 'XAF - Central African CFA Franc (Fr)',
    'XCD' => 'XCD - East Caribbean Dollar ($)',
    'XOF' => 'XOF - West African CFA Franc (Fr)',
    'XPF' => 'XPF - CFP Franc (Fr)',
    'YER' => 'YER - Yemeni Rial (﷼)',
    'ZAR' => 'ZAR - South African Rand (R)',
    'ZMW' => 'ZMW - Zambian Kwacha (ZK)',
    'ZWL' => 'ZWL - Zimbabwean Dollar ($)'
];

// ==================== ENSURE ALL COLUMNS EXIST ====================
$driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
$columns = $driver === 'sqlite' ? $db->query("PRAGMA table_info(books)")->fetchAll(PDO::FETCH_COLUMN, 1) : $db->query("SHOW COLUMNS FROM books")->fetchAll(PDO::FETCH_COLUMN);

$newColumns = [
    'sub_title', 'author2', 'collaborator', 'subject', 'item_category', 'book_status',
    'maintenance', 'current_location', 'section', 'ddc', 'udc', 'lcc', 'cutter',
    'series', 'volume', 'corporate_author', 'conference_author', 'issn', 'illustrations',
    'dimensions', 'country', 'collection_type', 'branch', 'shelf', 'vendor', 'invoice',
    'invoice_date', 'acquisition_date', 'funding_source', 'po_number', 'ebook_url',
    'contents', 'accompanying_material', 'material_type', 'size', 'weight', 'remarks',
    'cc', 'other_classification', 'call_number', 'keyword', 'holding', 'binding',
    'accession_number', 'price_currency', 'replacement_cost', 'total_lost',
    'marcxml', 'marc_json', 'last_modified', 'circulation_count', 'hold_count',
    'rating_avg', 'rating_count', 'is_ebook', 'ebook_file_path', 'ebook_file_size',
    'ebook_downloads', 'is_digital', 'digital_access_url', 'license_type',
    'license_expiry', 'language_code', 'publication_place', 'original_title',
    'translated_title', 'awards', 'reading_level', 'interest_level', 'lexile_measure',
    'ar_level', 'ar_points', 'ar_quiz_number', 'ib_learner_profile',
    'cbse_subject_code', 'gulf_approval', 'arabic_title', 'local_publisher',
    'curriculum', 'ib_pyp_theme', 'ib_myp_subject', 'ib_dp_group',
    'cbse_grade', 'gulf_approval_number', 'local_classification',
    'date_of_entry', 'source'
];

foreach ($newColumns as $col) {
    if (!in_array($col, $columns)) {
        $type = ($driver === 'sqlite') ? 'TEXT' : 'VARCHAR(255)';
        try {
            $db->exec("ALTER TABLE books ADD COLUMN $col $type DEFAULT ''");
        } catch (PDOException $e) {
            // Column might already exist
        }
    }
}

// Settings columns for API keys
$settingsCols = $driver === 'sqlite' ? $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1) : $db->query("SHOW COLUMNS FROM settings")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('isbndb_api_key', $settingsCols)) {
    $db->exec("ALTER TABLE settings ADD COLUMN isbndb_api_key TEXT DEFAULT ''");
    $db->exec("ALTER TABLE settings ADD COLUMN worldcat_api_key TEXT DEFAULT ''");
}

// Helper to get setting value
function getSettingValue($key) {
    $settings = getSettings();
    return $settings[$key] ?? null;
}

// ==================== AUTO CALL NUMBER GENERATION ====================

function generateCallNumber($classification, $author, $title) {
    if (empty($classification) || empty($author) || empty($title)) {
        return '';
    }
    
    $class = trim($classification);
    $authorClean = preg_replace('/[^a-zA-Z]/', '', $author);
    if (strlen($authorClean) >= 3) {
        $authorParts = explode(' ', $author);
        $lastName = end($authorParts);
        $lastNameClean = preg_replace('/[^a-zA-Z]/', '', $lastName);
        if (strlen($lastNameClean) >= 3) {
            $authorInitials = strtoupper(substr($lastNameClean, 0, 3));
        } else {
            $authorInitials = strtoupper(substr($authorClean, 0, 3));
        }
    } else {
        $authorInitials = strtoupper($authorClean . str_repeat('X', 3 - strlen($authorClean)));
    }
    
    $titleClean = preg_replace('/^(the|a|an)\s+/i', '', $title);
    $titleInitial = strtoupper(substr($titleClean, 0, 1));
    if (empty($titleInitial)) {
        $titleInitial = 'X';
    }
    
    $callNumber = $class . ' (' . $authorInitials . ' / ' . $titleInitial . ')';
    return $callNumber;
}

// ==================== ENHANCED METADATA FETCH WITH AUTO COVER DOWNLOAD ====================

function fetchBookMetadata($isbn, $source = 'auto') {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return null;
    if ($source === 'google') return fetchViaGoogleBooks($isbn);
    if ($source === 'openlibrary') return fetchViaOpenLibrary($isbn);
    if ($source === 'isbndb') return fetchViaISBNdb($isbn);
    if ($source === 'worldcat') return fetchViaWorldCat($isbn);
    if ($source === 'z3950') return fetchViaZ3950($isbn);
    if ($source === 'auto') {
        $funcs = ['fetchViaGoogleBooks', 'fetchViaOpenLibrary', 'fetchViaISBNdb', 'fetchViaWorldCat'];
        if (function_exists('yaz_connect')) $funcs[] = 'fetchViaZ3950';
        foreach ($funcs as $fn) {
            $res = $fn($isbn);
            if ($res) {
                // Auto download cover image if available
                if (!empty($res['cover_url'])) {
                    $barcode = $_POST['barcode'] ?? 'temp_' . time();
                    $coverPath = downloadCoverImage($res['cover_url'], $barcode);
                    if ($coverPath) {
                        $res['cover_path'] = $coverPath;
                    }
                }
                return $res;
            }
        }
    }
    return null;
}

function fetchAllSources($isbn) {
    $results = [];
    $funcs = [
        'Google Books' => 'fetchViaGoogleBooks',
        'OpenLibrary' => 'fetchViaOpenLibrary',
        'ISBNdb' => 'fetchViaISBNdb',
        'WorldCat' => 'fetchViaWorldCat'
    ];
    if (function_exists('yaz_connect')) $funcs['Z39.50'] = 'fetchViaZ3950';
    foreach ($funcs as $name => $fn) {
        $data = $fn($isbn);
        if ($data) {
            $data['source_display'] = $name;
            // Auto download cover for each source result
            if (!empty($data['cover_url'])) {
                $barcode = $_POST['barcode'] ?? 'temp_' . time();
                $coverPath = downloadCoverImage($data['cover_url'], $barcode);
                if ($coverPath) {
                    $data['cover_path'] = $coverPath;
                }
            }
            $results[] = $data;
        }
    }
    return $results;
}

function curlGet($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Library-ERP/1.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code === 200) ? $data : false;
}

function fetchViaGoogleBooks($isbn) {
    $json = curlGet("https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn");
    if (!$json) return null;
    $data = json_decode($json, true);
    if (empty($data['items'])) return null;
    $info = $data['items'][0]['volumeInfo'];
    return [
        'title' => $info['title'] ?? '',
        'subtitle' => $info['subtitle'] ?? '',
        'author' => isset($info['authors']) ? implode(', ', $info['authors']) : '',
        'publisher' => $info['publisher'] ?? '',
        'year' => substr($info['publishedDate'] ?? '', 0, 4),
        'pages' => $info['pageCount'] ?? 0,
        'isbn' => $isbn,
        'summary' => $info['description'] ?? '',
        'subject' => isset($info['categories']) ? implode(', ', $info['categories']) : '',
        'language' => $info['language'] ?? '',
        'cover_url' => $info['imageLinks']['thumbnail'] ?? $info['imageLinks']['smallThumbnail'] ?? '',
        'source' => 'Google Books'
    ];
}

function fetchViaOpenLibrary($isbn) {
    $json = curlGet("https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data");
    if (!$json) return null;
    $data = json_decode($json, true);
    $key = "ISBN:$isbn";
    if (!isset($data[$key])) return null;
    $book = $data[$key];
    return [
        'title' => $book['title'] ?? '',
        'subtitle' => $book['subtitle'] ?? '',
        'author' => isset($book['authors']) ? implode(', ', array_column($book['authors'], 'name')) : '',
        'publisher' => $book['publishers'][0]['name'] ?? '',
        'year' => preg_replace('/[^0-9]/', '', $book['publish_date'] ?? ''),
        'pages' => $book['number_of_pages'] ?? 0,
        'isbn' => $isbn,
        'summary' => $book['notes'] ?? ($book['description'] ?? ''),
        'subject' => isset($book['subjects']) ? implode(', ', array_slice($book['subjects'], 0, 3)) : '',
        'language' => $book['languages'][0]['name'] ?? '',
        'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
        'source' => 'OpenLibrary'
    ];
}

function fetchViaISBNdb($isbn) {
    $apiKey = getSettingValue('isbndb_api_key');
    if (!$apiKey) return null;
    $ch = curl_init("https://api2.isbndb.com/book/{$isbn}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: $apiKey"]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $json = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200 || !$json) return null;
    $data = json_decode($json, true);
    if (!isset($data['book'])) return null;
    $b = $data['book'];
    return [
        'title' => $b['title'] ?? '',
        'subtitle' => $b['title_long'] ?? '',
        'author' => isset($b['authors']) ? implode(', ', $b['authors']) : '',
        'publisher' => $b['publisher'] ?? '',
        'year' => substr($b['date_published'] ?? '', 0, 4),
        'pages' => $b['pages'] ?? 0,
        'isbn' => $isbn,
        'summary' => $b['synopsis'] ?? '',
        'subject' => isset($b['subjects']) ? implode(', ', $b['subjects']) : '',
        'language' => $b['language'] ?? '',
        'cover_url' => $b['image'] ?? '',
        'source' => 'ISBNdb'
    ];
}

function fetchViaWorldCat($isbn) {
    $apiKey = getSettingValue('worldcat_api_key');
    if (!$apiKey) return null;
    $json = curlGet("https://search.worldcat.org/search?q=isbn:{$isbn}&format=json");
    if (!$json) return null;
    $data = json_decode($json, true);
    if (empty($data['records'])) return null;
    $r = $data['records'][0];
    return [
        'title' => $r['title'] ?? '',
        'subtitle' => '',
        'author' => $r['author'] ?? '',
        'publisher' => $r['publisher'] ?? '',
        'year' => substr($r['date'] ?? '', 0, 4),
        'pages' => $r['physicalExtent'] ?? 0,
        'isbn' => $isbn,
        'summary' => $r['description'] ?? '',
        'subject' => $r['subject'] ?? '',
        'language' => $r['language'] ?? '',
        'cover_url' => '',
        'source' => 'WorldCat'
    ];
}

$z39Targets = [
    'loc' => ['name' => 'Library of Congress', 'host' => 'z3950.loc.gov', 'port' => 7090, 'db' => 'voyager', 'syntax' => 'usmarc', 'attr' => 7],
    'nlm' => ['name' => 'National Library of Medicine', 'host' => 'locate.nlm.nih.gov', 'port' => 210, 'db' => 'NLM', 'syntax' => 'usmarc', 'attr' => 7],
    'dnb' => ['name' => 'Deutsche Nationalbibliothek', 'host' => 'z3950.dnb.de', 'port' => 2020, 'db' => 'DNB', 'syntax' => 'usmarc', 'attr' => 7],
    'bne' => ['name' => 'Biblioteca Nacional de España', 'host' => 'catalogo.bne.es', 'port' => 210, 'db' => 'BIBLIO', 'syntax' => 'usmarc', 'attr' => 7],
    'nla' => ['name' => 'National Library of Australia', 'host' => 'z3950.nla.gov.au', 'port' => 7090, 'db' => 'NAT', 'syntax' => 'usmarc', 'attr' => 7]
];

function fetchViaZ3950($isbn) {
    global $z39Targets;
    if (!function_exists('yaz_connect')) return null;
    foreach ($z39Targets as $t) {
        $conn = @yaz_connect($t['host'] . ':' . $t['port'] . '/' . $t['db']);
        if (!$conn) continue;
        yaz_syntax($conn, $t['syntax']);
        yaz_search($conn, 'rpn', '@attr 1=' . $t['attr'] . ' "' . yaz_escape($isbn) . '"');
        yaz_wait();
        if (!yaz_error($conn) && yaz_hits($conn) > 0) {
            $rec = yaz_record($conn, 1, 'string');
            if ($rec) {
                $data = ['source' => $t['name'], 'cover_url' => ''];
                if (preg_match('/245.{0,10}([^|]+)/', $rec, $m)) $data['title'] = trim($m[1]);
                if (preg_match('/100.{0,10}([^|]+)/', $rec, $m)) $data['author'] = trim($m[1]);
                if (preg_match('/260.{0,10}([^|]+)/', $rec, $m)) $data['publisher'] = trim($m[1]);
                if (preg_match('/260.{0,10}.{0,10}([0-9]{4})/', $rec, $m)) $data['year'] = $m[1];
                if (preg_match('/300.{0,10}([0-9]+)/', $rec, $m)) $data['pages'] = (int)$m[1];
                if (!empty($data['title'])) return $data;
            }
        }
        yaz_close($conn);
    }
    return null;
}

// ==================== COVER FUNCTIONS ====================

function downloadCoverImage($url, $barcode) {
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) return false;
    
    // Determine file extension
    $ext = 'jpg';
    $path = parse_url($url, PHP_URL_PATH);
    if ($path && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $path, $m)) {
        $ext = strtolower($m[1]);
    }
    
    // Clean barcode for filename
    $cleanBarcode = preg_replace('/[^a-zA-Z0-9_-]/', '_', $barcode);
    $filename = 'book_' . $cleanBarcode . '_' . time() . '.' . $ext;
    $target = BOOK_COVER_DIR . $filename;
    
    // Ensure directory exists
    if (!is_dir(BOOK_COVER_DIR)) {
        mkdir(BOOK_COVER_DIR, 0777, true);
    }
    
    $data = false;
    
    // Try curl first
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Library-ERP/1.0');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http !== 200) $data = false;
    }
    
    // Fallback to file_get_contents
    if (!$data && function_exists('file_get_contents')) {
        $context = stream_context_create([
            'http' => ['method' => 'GET', 'header' => "User-Agent: Library-ERP/1.0\r\n", 'timeout' => 15, 'ignore_errors' => true],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
        ]);
        $data = @file_get_contents($url, false, $context);
    }
    
    if ($data !== false && file_put_contents($target, $data)) {
        // Resize image to reasonable size
        $resizedPath = BOOK_COVER_DIR . 'book_' . $cleanBarcode . '_' . time() . '_resized.' . $ext;
        if (autoResizeImage($target, $resizedPath, 400, 600, 85)) {
            unlink($target);
            return 'uploads/books/' . basename($resizedPath);
        }
        return 'uploads/books/' . $filename;
    }
    
    return false;
}

function autoResizeImage($source, $target, $maxWidth, $maxHeight, $quality = 85) {
    $info = getimagesize($source);
    if (!$info) return false;
    $src = null;
    switch ($info[2]) {
        case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($source); break;
        case IMAGETYPE_PNG: $src = imagecreatefrompng($source); break;
        case IMAGETYPE_GIF: $src = imagecreatefromgif($source); break;
        case IMAGETYPE_WEBP: $src = imagecreatefromwebp($source); break;
        default: return false;
    }
    $origW = imagesx($src);
    $origH = imagesy($src);
    $ratio = min($maxWidth / $origW, $maxHeight / $origH);
    $newW = max(1, (int)($origW * $ratio));
    $newH = max(1, (int)($origH * $ratio));
    $dst = imagecreatetruecolor($newW, $newH);
    if ($info[2] == IMAGETYPE_PNG) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
        imagefilledrectangle($dst, 0, 0, $newW, $newH, $transparent);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $origW, $origH);
    $success = false;
    switch ($info[2]) {
        case IMAGETYPE_JPEG: $success = imagejpeg($dst, $target, $quality); break;
        case IMAGETYPE_PNG: $success = imagepng($dst, $target, 9); break;
        case IMAGETYPE_GIF: $success = imagegif($dst, $target); break;
        case IMAGETYPE_WEBP: $success = imagewebp($dst, $target, $quality); break;
    }
    imagedestroy($src);
    imagedestroy($dst);
    return $success;
}

function uploadBookCoversZip($db, $zipFilePath) {
    $result = ['success' => 0, 'failed' => 0, 'errors' => []];
    $tempDir = sys_get_temp_dir() . '/book_covers_' . uniqid();
    if (!mkdir($tempDir, 0777, true)) {
        $result['errors'][] = "Cannot create temp dir";
        return $result;
    }
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) !== true) {
        $result['errors'][] = "Cannot open ZIP";
        return $result;
    }
    $zip->extractTo($tempDir);
    $zip->close();
    $allowedMime = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $files = scandir($tempDir);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        $fullPath = $tempDir . '/' . $file;
        $mime = finfo_file($finfo, $fullPath);
        if (!in_array($mime, $allowedMime)) {
            $result['errors'][] = "Skipped non-image: $file";
            continue;
        }
        $barcode = pathinfo($file, PATHINFO_FILENAME);
        $barcode = preg_replace('/[^a-zA-Z0-9_-]/', '', $barcode);
        if (empty($barcode)) {
            $result['errors'][] = "Invalid filename (no barcode): $file";
            continue;
        }
        $check = $db->prepare("SELECT cover_path FROM books WHERE barcode = ?");
        $check->execute([$barcode]);
        $book = $check->fetch();
        if (!$book) {
            $result['errors'][] = "Book not found: $barcode";
            continue;
        }
        if (!empty($book['cover_path']) && file_exists($book['cover_path'])) unlink($book['cover_path']);
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $newName = 'book_cover_' . $barcode . '_' . time() . '.' . $ext;
        $target = BOOK_COVER_DIR . $newName;
        if (autoResizeImage($fullPath, $target, 400, 400, 85)) {
            $db->prepare("UPDATE books SET cover_path = ? WHERE barcode = ?")->execute(['uploads/books/' . $newName, $barcode]);
            $result['success']++;
        } else {
            $result['errors'][] = "Failed to resize/save cover for $barcode";
        }
    }
    finfo_close($finfo);
    array_map('unlink', glob($tempDir . '/*'));
    rmdir($tempDir);
    return $result;
}

// ==================== EXPORT HANDLERS ====================

// Handle CSV/Excel/PDF export
if (isset($_GET['export'])) {
    $exportType = $_GET['export'] ?? 'csv';
    $exportMode = $_GET['export_mode'] ?? 'copies';
    $bookIds = null;
    
    if (isset($_GET['ids']) && $_GET['ids'] !== 'all' && !empty($_GET['ids'])) {
        $bookIds = explode(',', $_GET['ids']);
        $bookIds = array_filter($bookIds, 'is_numeric');
        $bookIds = array_map('intval', $bookIds);
        if (empty($bookIds)) {
            $bookIds = null;
        }
    }
    
    if ($exportType === 'csv') {
        exportBooksCSV($db, $bookIds, $exportMode);
    } elseif ($exportType === 'excel') {
        exportBooksExcel($db, $bookIds, $exportMode);
    } elseif ($exportType === 'pdf') {
        exportBooksPDF($db, $bookIds, $exportMode);
    } else {
        exportBooksCSV($db, $bookIds, $exportMode);
    }
    exit;
}

// Handle MARC export
if (isset($_GET['export_marc'])) {
    $format = $_GET['format'] ?? 'mrc';
    $bookIds = null;
    
    if (isset($_GET['ids']) && $_GET['ids'] !== 'all' && !empty($_GET['ids'])) {
        $bookIds = explode(',', $_GET['ids']);
        $bookIds = array_filter($bookIds, 'is_numeric');
        $bookIds = array_map('intval', $bookIds);
        if (empty($bookIds)) {
            $bookIds = null;
        }
    }
    
    exportBooksMARC($db, $bookIds, $format);
    exit;
}

// ==================== AJAX HANDLERS ====================

if (isset($_GET['ajax_fetch_metadata'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) { echo json_encode(['success' => false, 'error' => 'Invalid ISBN']); exit; }
    $source = $_GET['source'] ?? 'auto';
    $result = fetchBookMetadata($isbn, $source);
    if ($result) {
        // Auto download cover if not already downloaded
        if (!empty($result['cover_url']) && empty($result['cover_path'])) {
            $barcode = $_GET['barcode'] ?? 'temp_' . time();
            $coverPath = downloadCoverImage($result['cover_url'], $barcode);
            if ($coverPath) {
                $result['cover_path'] = $coverPath;
                $result['cover_url_display'] = getWebImageUrl($coverPath);
            }
        }
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No metadata found']);
    }
    exit;
}

if (isset($_GET['ajax_fetch_all_sources'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) { echo json_encode(['success' => false, 'error' => 'Invalid ISBN']); exit; }
    $results = fetchAllSources($isbn);
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

if (isset($_GET['ajax_download_cover'])) {
    header('Content-Type: application/json');
    $url = $_GET['url'] ?? '';
    $barcode = $_GET['barcode'] ?? 'temp';
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'error' => 'Invalid URL']);
        exit;
    }
    $localPath = downloadCoverImage($url, $barcode);
    if ($localPath) {
        $webUrl = getWebImageUrl($localPath);
        echo json_encode(['success' => true, 'path' => $localPath, 'webUrl' => $webUrl]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Download failed']);
    }
    exit;
}

// ==================== MARC IMPORT ====================

function importMarcRecords($db, $filePath) {
    $result = ['success' => 0, 'updated' => 0, 'failed' => 0, 'message' => ''];
    if (!class_exists('File_MARC')) {
        $result['message'] = "File_MARC not installed. Cannot import MARC.";
        return $result;
    }
    $db->beginTransaction();
    $marc = new File_MARC($filePath, File_MARC::SOURCE_FILE);
    while ($record = $marc->next()) {
        try {
            $barcode = $record->getField('001') ? trim($record->getField('001')->getData()) : 'MARC_' . uniqid();
            $titleField = $record->getField('245');
            $title = $titleField ? $titleField->getSubfield('a')->getData() : '';
            if (empty($title)) throw new Exception("No title");
            $author = '';
            $authorField = $record->getField('100');
            if ($authorField && $authorField->getSubfield('a')) $author = $authorField->getSubfield('a')->getData();
            $publisher = '';
            $publisherField = $record->getField('260');
            if ($publisherField && $publisherField->getSubfield('b')) $publisher = $publisherField->getSubfield('b')->getData();
            $year = '';
            if ($publisherField && $publisherField->getSubfield('c')) $year = preg_replace('/[^0-9]/', '', $publisherField->getSubfield('c')->getData());
            $isbn = '';
            $isbnField = $record->getField('020');
            if ($isbnField && $isbnField->getSubfield('a')) $isbn = $isbnField->getSubfield('a')->getData();
            $call_number = '';
            $callField = $record->getField('090');
            if ($callField && $callField->getSubfield('a')) $call_number = $callField->getSubfield('a')->getData();
            $stmt = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $stmt->execute([$barcode]);
            if ($stmt->fetch()) {
                $stmt = $db->prepare("UPDATE books SET title = ?, author = ?, publisher = ?, year = ?, isbn = ?, call_number = ? WHERE barcode = ?");
                $stmt->execute([$title, $author, $publisher, $year, $isbn, $call_number, $barcode]);
                $result['updated']++;
            } else {
                $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, year, isbn, call_number, quantity, available, date_of_entry) VALUES (?,?,?,?,?,?,?,1,1,date('now'))");
                $stmt->execute([$barcode, $title, $author, $publisher, $year, $isbn, $call_number]);
                $result['success']++;
            }
        } catch (Exception $e) {
            $result['failed']++;
        }
    }
    $db->commit();
    $result['message'] = "MARC: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed";
    return $result;
}

// ==================== API KEY CONFIGURATION ====================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_api_keys'])) {
    $db->prepare("UPDATE settings SET isbndb_api_key = ?, worldcat_api_key = ? WHERE id = 1")
        ->execute([$_POST['isbndb_api_key'] ?? '', $_POST['worldcat_api_key'] ?? '']);
    showToast("API keys saved", "success");
    header("Location: books.php?mode=$mode");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_marc']) && $marcAvailable && isset($_FILES['marc_file']) && $_FILES['marc_file']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['marc_file']['tmp_name'];
    $result = importMarcRecords($db, $file);
    showToast($result['message'], $result['success'] > 0 ? 'success' : 'warning');
    logActivity($_SESSION['username'], 'IMPORT_MARC', "MARC import: {$result['success']} added, {$result['updated']} updated, {$result['failed']} failed");
    header("Location: books.php?mode=$mode");
    exit;
}

// ==================== DYNAMIC COLUMN HELPERS ====================

function getBookTableColumns($db) {
    $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        return $db->query("PRAGMA table_info(books)")->fetchAll(PDO::FETCH_COLUMN, 1);
    } else {
        return $db->query("SHOW COLUMNS FROM books")->fetchAll(PDO::FETCH_COLUMN);
    }
}

function mapPostToColumn($col, $post, $coverPath, $ddc, $udc, $lcc, $cc, $other_classification, $itemCategory, $bookStatus, $maintenance, $current_location, $section, $branch, $shelf, $callNumber) {
    switch ($col) {
        case 'cover_path': return $coverPath;
        case 'ddc': return $ddc;
        case 'udc': return $udc;
        case 'lcc': return $lcc;
        case 'cc': return $cc;
        case 'other_classification': return $other_classification;
        case 'item_category': return $itemCategory;
        case 'book_status': return $bookStatus;
        case 'maintenance': return $maintenance;
        case 'current_location': return $current_location;
        case 'section': return $section;
        case 'branch': return $branch;
        case 'shelf': return $shelf;
        case 'call_number': return $callNumber;
        case 'date_of_entry': return date('Y-m-d');
        case 'quantity': return (int)($post['quantity'] ?? 1);
        case 'available': return isset($post['available']) ? (int)$post['available'] : ((int)($post['quantity'] ?? 1));
        case 'pages': return (int)($post['pages'] ?? 0);
        case 'price': return !empty($post['price']) ? (float)$post['price'] : null;
        default:
            return $post[$col] ?? '';
    }
}

// ==================== CRUD OPERATIONS ====================

$editBook = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
    $stmt->execute([$_GET['edit']]);
    $editBook = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $allColumns = getBookTableColumns($db);
        $insertColumns = array_filter($allColumns, function($col) {
            return !in_array($col, ['id', 'created_at']);
        });

        // Process cover image
        $coverPath = $_POST['existing_cover'] ?? '';
        $preDownloaded = $_POST['pre_downloaded_cover'] ?? '';
        if (!empty($preDownloaded) && file_exists(BASE_PATH . '/' . $preDownloaded)) {
            if ($coverPath && file_exists(BASE_PATH . '/' . $coverPath) && $coverPath !== $preDownloaded) unlink(BASE_PATH . '/' . $coverPath);
            $coverPath = $preDownloaded;
        } elseif (isset($_FILES['book_cover']) && $_FILES['book_cover']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['book_cover']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
                $filename = 'book_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $_POST['barcode']) . '_' . time() . '.' . $ext;
                $target = BOOK_COVER_DIR . $filename;
                if (move_uploaded_file($_FILES['book_cover']['tmp_name'], $target)) {
                    if ($coverPath && file_exists(BASE_PATH . '/' . $coverPath)) unlink(BASE_PATH . '/' . $coverPath);
                    $coverPath = 'uploads/books/' . $filename;
                }
            }
        } elseif (!empty($_POST['cover_url']) && filter_var($_POST['cover_url'], FILTER_VALIDATE_URL)) {
            $downloaded = downloadCoverImage($_POST['cover_url'], $_POST['barcode']);
            if ($downloaded) {
                if ($coverPath && file_exists(BASE_PATH . '/' . $coverPath)) unlink(BASE_PATH . '/' . $coverPath);
                $coverPath = $downloaded;
            }
        }

        // Process custom fields
        $bookStatus = $_POST['book_status'] ?? 'Available';
        if ($bookStatus === 'Other' && !empty($_POST['book_status_other'])) $bookStatus = trim($_POST['book_status_other']);
        $maintenance = $_POST['maintenance'] ?? '';
        if ($maintenance === 'Other' && !empty($_POST['maintenance_other'])) $maintenance = trim($_POST['maintenance_other']);
        $itemCategory = $_POST['item_category'] ?? '';
        if ($itemCategory === 'Others' && !empty($_POST['item_category_other'])) $itemCategory = trim($_POST['item_category_other']);
        $current_location = $_POST['current_location'] ?? '';
        $section = $_POST['section'] ?? '';
        $branch = $_POST['branch'] ?? '';
        $shelf = $_POST['shelf'] ?? '';
        
        $ddc = $_POST['ddc'] ?? '';
        if ($ddc === 'Other' && !empty($_POST['ddc_other'])) $ddc = $_POST['ddc_other'];
        $udc = $_POST['udc'] ?? '';
        if ($udc === 'Other' && !empty($_POST['udc_other'])) $udc = $_POST['udc_other'];
        $lcc = $_POST['lcc'] ?? '';
        if ($lcc === 'Other' && !empty($_POST['lcc_other'])) $lcc = $_POST['lcc_other'];
        $cc = $_POST['cc'] ?? '';
        $other_classification = $_POST['other_classification'] ?? '';

        $barcode = trim($_POST['barcode'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $author = trim($_POST['author'] ?? '');
        
        if (empty($barcode)) throw new Exception("Barcode is required.");
        if (empty($title)) throw new Exception("Title is required.");

        // Generate Call Number
        $classification = !empty($ddc) ? $ddc : (!empty($lcc) ? $lcc : (!empty($cc) ? $cc : (!empty($other_classification) ? $other_classification : (!empty($_POST['classification']) ? $_POST['classification'] : ''))));
        $callNumber = generateCallNumber($classification, $author, $title);

        if (!isset($_POST['update_book'])) {
            $check = $db->prepare("SELECT barcode FROM books WHERE barcode = ?");
            $check->execute([$barcode]);
            if ($check->fetch()) throw new Exception("A book with barcode '{$barcode}' already exists.");
        }

        // UPDATE
        if (isset($_POST['update_book'])) {
            $updateFields = [];
            $params = [];
            foreach ($insertColumns as $col) {
                $value = mapPostToColumn($col, $_POST, $coverPath, $ddc, $udc, $lcc, $cc, $other_classification, $itemCategory, $bookStatus, $maintenance, $current_location, $section, $branch, $shelf, $callNumber);
                $updateFields[] = "$col = ?";
                $params[] = $value;
            }
            $params[] = $barcode;
            $sql = "UPDATE books SET " . implode(", ", $updateFields) . " WHERE barcode = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            showToast("Book updated successfully. Call Number: " . $callNumber, "success");
            logActivity($_SESSION['username'], 'BOOK_UPDATE', "Updated book: {$barcode}");
            header("Location: books.php?mode=$mode");
            exit;
        }
        
        // INSERT
        elseif (isset($_POST['add_book'])) {
            $columnList = implode(", ", $insertColumns);
            $placeholders = implode(", ", array_fill(0, count($insertColumns), '?'));
            $sql = "INSERT INTO books ($columnList) VALUES ($placeholders)";
            $values = [];
            foreach ($insertColumns as $col) {
                $values[] = mapPostToColumn($col, $_POST, $coverPath, $ddc, $udc, $lcc, $cc, $other_classification, $itemCategory, $bookStatus, $maintenance, $current_location, $section, $branch, $shelf, $callNumber);
            }
            $stmt = $db->prepare($sql);
            $stmt->execute($values);
            showToast("Book added successfully. Call Number: " . $callNumber, "success");
            logActivity($_SESSION['username'], 'BOOK_ADD', "Added book: {$barcode}");
            header("Location: books.php?mode=$mode");
            exit;
        }

        // Bulk import CSV - Enhanced with auto metadata fetch
        if (isset($_POST['bulk_import']) && isset($_FILES['bulk_csv']) && $_FILES['bulk_csv']['error'] === UPLOAD_ERR_OK) {
            $handle = fopen($_FILES['bulk_csv']['tmp_name'], 'r');
            if ($handle) {
                $header = fgetcsv($handle);
                $imported = 0;
                $errors = [];
                $colMap = [];
                foreach ($header as $idx => $colName) {
                    $colMap[strtolower(trim($colName))] = $idx;
                }
                if (!isset($colMap['barcode']) || !isset($colMap['title'])) {
                    $errors[] = "Missing required columns: barcode, title";
                } else {
                    $rowNum = 1;
                    while (($row = fgetcsv($handle)) !== false) {
                        $rowNum++;
                        $data = [];
                        foreach ($colMap as $key => $idx) $data[$key] = $row[$idx] ?? '';
                        $barcode = trim($data['barcode']);
                        $title = trim($data['title']);
                        if (empty($barcode) || empty($title)) {
                            $errors[] = "Row $rowNum: Missing barcode or title";
                            continue;
                        }
                        $check = $db->prepare("SELECT barcode FROM books WHERE barcode = ?");
                        $check->execute([$barcode]);
                        if ($check->fetch()) {
                            $errors[] = "Row $rowNum: Barcode $barcode already exists";
                            continue;
                        }
                        $isbn = preg_replace('/[^0-9X]/i', '', $data['isbn'] ?? '');
                        $coverPath = '';
                        $meta = null;
                        
                        // Auto fetch metadata from ISBN
                        if (!empty($isbn) && strlen($isbn) >= 10) {
                            $meta = fetchBookMetadata($isbn, 'auto');
                            if ($meta) {
                                if (empty($title) && !empty($meta['title'])) $title = $meta['title'];
                                if (empty($data['author']) && !empty($meta['author'])) $data['author'] = $meta['author'];
                                if (empty($data['publisher']) && !empty($meta['publisher'])) $data['publisher'] = $meta['publisher'];
                                if (empty($data['year']) && !empty($meta['year'])) $data['year'] = $meta['year'];
                                if (empty($data['pages']) && !empty($meta['pages'])) $data['pages'] = $meta['pages'];
                                if (empty($data['subject']) && !empty($meta['subject'])) $data['subject'] = $meta['subject'];
                                if (empty($data['summary']) && !empty($meta['summary'])) $data['summary'] = $meta['summary'];
                                if (empty($data['sub_title']) && !empty($meta['subtitle'])) $data['sub_title'] = $meta['subtitle'];
                                if (empty($data['language']) && !empty($meta['language'])) $data['language'] = $meta['language'];
                                if (!empty($meta['cover_url'])) {
                                    $coverPath = downloadCoverImage($meta['cover_url'], $barcode);
                                }
                            }
                        }
                        if (empty($coverPath) && !empty($data['cover_url'])) {
                            $coverPath = downloadCoverImage($data['cover_url'], $barcode);
                        }
                        
                        // Generate call number
                        $author = $data['author'] ?? '';
                        $classification = $data['ddc'] ?? ($data['lcc'] ?? ($data['cc'] ?? ($data['other_classification'] ?? '')));
                        $callNumber = generateCallNumber($classification, $author, $title);
                        
                        $columns = getBookTableColumns($db);
                        $insCols = array_filter($columns, function($c) { return !in_array($c, ['id', 'created_at']); });
                        $insValues = [];
                        foreach ($insCols as $col) {
                            switch ($col) {
                                case 'barcode': $insValues[] = $barcode; break;
                                case 'title': $insValues[] = $title; break;
                                case 'cover_path': $insValues[] = $coverPath; break;
                                case 'call_number': $insValues[] = $callNumber; break;
                                case 'date_of_entry': $insValues[] = date('Y-m-d'); break;
                                case 'quantity': $insValues[] = (int)($data['quantity'] ?? 1); break;
                                case 'available': $insValues[] = (int)($data['available'] ?? 1); break;
                                case 'price': $insValues[] = !empty($data['price']) ? (float)$data['price'] : null; break;
                                default:
                                    $insValues[] = $data[$col] ?? '';
                            }
                        }
                        $sql = "INSERT INTO books (" . implode(", ", $insCols) . ") VALUES (" . implode(", ", array_fill(0, count($insCols), '?')) . ")";
                        $stmt = $db->prepare($sql);
                        $stmt->execute($insValues);
                        $imported++;
                    }
                    fclose($handle);
                }
                $msg = "Imported $imported books.";
                if (!empty($errors)) {
                    $msg .= " Errors: " . implode("; ", array_slice($errors, 0, 10));
                    if (count($errors) > 10) $msg .= " ... and " . (count($errors)-10) . " more.";
                    showToast($msg, "warning");
                } else {
                    showToast($msg, "success");
                }
                header("Location: books.php?mode=$mode");
                exit;
            }
        }
        
        // Bulk Cover ZIP Upload
        if (isset($_POST['bulk_covers_upload']) && isset($_FILES['bulk_covers_zip']) && $_FILES['bulk_covers_zip']['error'] === UPLOAD_ERR_OK) {
            $tempFile = $_FILES['bulk_covers_zip']['tmp_name'];
            $result = uploadBookCoversZip($db, $tempFile);
            showToast($result['message'] ?? "Covers: {$result['success']} updated, {$result['failed']} failed", $result['success'] > 0 ? 'success' : 'warning');
            header("Location: books.php?mode=$mode");
            exit;
        }
    } catch (PDOException $e) {
        error_log("Book operation PDO Error: " . $e->getMessage());
        showToast("Database error: " . $e->getMessage(), "danger");
        header("Location: books.php?mode=$mode");
        exit;
    } catch (Exception $e) {
        error_log("Book operation Exception: " . $e->getMessage());
        showToast($e->getMessage(), "danger");
        header("Location: books.php?mode=$mode");
        exit;
    }
}

// Delete book
if (isset($_GET['delete'])) {
    $check = $db->prepare("SELECT COUNT(*) FROM circulation WHERE barcode = ? AND return_date IS NULL");
    $check->execute([$_GET['delete']]);
    if ($check->fetchColumn() > 0) {
        showToast("Cannot delete a book that is currently issued.", "warning");
    } else {
        $stmt = $db->prepare("SELECT cover_path FROM books WHERE barcode = ?");
        $stmt->execute([$_GET['delete']]);
        $book = $stmt->fetch();
        if ($book && $book['cover_path'] && file_exists(BASE_PATH . '/' . $book['cover_path'])) unlink(BASE_PATH . '/' . $book['cover_path']);
        $db->prepare("DELETE FROM books WHERE barcode = ?")->execute([$_GET['delete']]);
        showToast("Book deleted", "success");
        logActivity($_SESSION['username'], 'BOOK_DELETE', "Deleted book: {$_GET['delete']}");
    }
    header("Location: books.php?mode=$mode");
    exit;
}

// ==================== FILTERING & SORTING ====================

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$author = $_GET['author'] ?? '';
$publisher = $_GET['publisher'] ?? '';
$subject = $_GET['subject'] ?? '';
$location = $_GET['location'] ?? '';
$isbn_filter = $_GET['isbn_filter'] ?? '';
$call_number_filter = $_GET['call_number_filter'] ?? '';
$accession_filter = $_GET['accession_filter'] ?? '';
$itemCategory = $_GET['item_category'] ?? '';
$bookStatusFilter = $_GET['book_status_filter'] ?? '';
$maintenance = $_GET['maintenance'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'title';
$sort_order = $_GET['sort_order'] ?? 'ASC';
$allowed_sort = ['title','author','publisher','isbn','category','book_status','location','year','price','created_at','call_number','date_of_entry'];
if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
$sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
$next_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';

$sql = "SELECT * FROM books WHERE 1=1";
$params = [];
if ($search) {
    $sql .= " AND (title LIKE ? OR sub_title LIKE ? OR author LIKE ? OR author2 LIKE ? OR collaborator LIKE ? OR subject LIKE ? OR barcode LIKE ? OR isbn LIKE ? OR keyword LIKE ? OR publisher LIKE ? OR call_number LIKE ?)";
    $like = "%$search%";
    $params = array_fill(0, 11, $like);
}
if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
if ($author) { $sql .= " AND (author LIKE ? OR author2 LIKE ?)"; $like = "%$author%"; $params[] = $like; $params[] = $like; }
if ($publisher) { $sql .= " AND publisher LIKE ?"; $params[] = "%$publisher%"; }
if ($subject) { $sql .= " AND subject LIKE ?"; $params[] = "%$subject%"; }
if ($location) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
if ($isbn_filter) { $sql .= " AND isbn LIKE ?"; $params[] = "%$isbn_filter%"; }
if ($call_number_filter) { $sql .= " AND call_number LIKE ?"; $params[] = "%$call_number_filter%"; }
if ($accession_filter) { $sql .= " AND accession_number LIKE ?"; $params[] = "%$accession_filter%"; }
if ($itemCategory) { $sql .= " AND item_category = ?"; $params[] = $itemCategory; }
if ($bookStatusFilter) { $sql .= " AND book_status = ?"; $params[] = $bookStatusFilter; }
if ($maintenance) { $sql .= " AND maintenance = ?"; $params[] = $maintenance; }
if ($status === 'available') $sql .= " AND available > 0";
elseif ($status === 'unavailable') $sql .= " AND available = 0";
elseif ($status === 'lowstock') $sql .= " AND available > 0 AND available <= 2";
if ($year_from) { $sql .= " AND year >= ?"; $params[] = $year_from; }
if ($year_to) { $sql .= " AND year <= ?"; $params[] = $year_to; }
if ($price_min !== '') { $sql .= " AND price >= ?"; $params[] = (float)$price_min; }
if ($price_max !== '') { $sql .= " AND price <= ?"; $params[] = (float)$price_max; }
$sql .= " ORDER BY $sort_by $sort_order LIMIT 500";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Statistics
$totalBooks = $db->query("SELECT SUM(quantity) FROM books")->fetchColumn() ?: 0;
$totalTitles = $db->query("SELECT COUNT(DISTINCT title || '|' || author || '|' || publisher || '|' || isbn) FROM books")->fetchColumn();
$totalAvailable = $db->query("SELECT SUM(available) FROM books")->fetchColumn() ?: 0;
$totalIssued = $totalBooks - $totalAvailable;
$lowStock = $db->query("SELECT COUNT(*) FROM (SELECT SUM(available) as avail FROM books GROUP BY title, author, publisher, isbn HAVING avail > 0 AND avail <= 2)")->fetchColumn();

// Distinct values for filters
$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$authors = $db->query("SELECT DISTINCT author FROM books WHERE author IS NOT NULL AND author != '' ORDER BY author LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$publishers = $db->query("SELECT DISTINCT publisher FROM books WHERE publisher IS NOT NULL AND publisher != '' ORDER BY publisher LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$subjects = $db->query("SELECT DISTINCT subject FROM books WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$locations = $db->query("SELECT DISTINCT location FROM books WHERE location IS NOT NULL AND location != '' ORDER BY location")->fetchAll(PDO::FETCH_COLUMN);
$itemCategories = $db->query("SELECT DISTINCT item_category FROM books WHERE item_category IS NOT NULL AND item_category != '' ORDER BY item_category")->fetchAll(PDO::FETCH_COLUMN);
$bookStatuses = $db->query("SELECT DISTINCT book_status FROM books WHERE book_status IS NOT NULL AND book_status != '' ORDER BY book_status")->fetchAll(PDO::FETCH_COLUMN);
$maintenances = $db->query("SELECT DISTINCT maintenance FROM books WHERE maintenance IS NOT NULL AND maintenance != '' ORDER BY maintenance")->fetchAll(PDO::FETCH_COLUMN);
$allYears = $db->query("SELECT DISTINCT year FROM books WHERE year IS NOT NULL AND year != '' AND LENGTH(year) <= 4 ORDER BY year DESC LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
$years = [];
foreach ($allYears as $y) if (is_numeric($y) && $y >= 1000 && $y <= date('Y') + 5) $years[] = $y;

$isbndbKey = getSettingValue('isbndb_api_key');
$worldcatKey = getSettingValue('worldcat_api_key');

// ==================== HTML OUTPUT ====================

renderHeader('Book Management');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        body{background:#f0f2f5;font-family:'Inter',sans-serif}
        .filter-card{background:white;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1);margin-bottom:20px;transition:all 0.3s}
        .filter-card .card-header{background:linear-gradient(135deg,#1e3c72 0%,#2a5298 100%);color:white;cursor:pointer;padding:12px 20px}
        .filter-card .card-header i.fa-chevron-down{transition:transform 0.3s}
        .filter-card.collapsed .card-header i.fa-chevron-down{transform:rotate(-90deg)}
        .filter-card .card-body{transition:padding 0.3s}
        
        /* Book Cover Styles */
        .book-cover-thumb {
            width: 50px;
            height: 65px;
            object-fit: cover;
            border-radius: 6px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        .book-cover-thumb:hover {
            transform: scale(1.15);
            border-color: #1e3c72;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            z-index: 10;
            position: relative;
        }
        .book-cover-large {
            max-height: 200px;
            max-width: 150px;
            object-fit: contain;
            border-radius: 8px;
            border: 2px solid #e9ecef;
            background: #f8f9fa;
            padding: 5px;
        }
        .book-cover-modal {
            max-height: 300px;
            max-width: 200px;
            object-fit: contain;
            border-radius: 12px;
            border: 3px solid #1e3c72;
            background: #f8f9fa;
            padding: 10px;
        }
        .default-cover-thumb {
            width: 50px;
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 6px;
            color: white;
            font-size: 1.5rem;
        }
        .default-cover-large {
            width: 120px;
            height: 160px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 8px;
            color: white;
            font-size: 3rem;
        }
        
        .stat-card{transition:transform 0.2s;cursor:pointer}
        .stat-card:hover{transform:translateY(-5px)}
        .nav-tabs .nav-link{color:#1e3c72;font-weight:500}
        .nav-tabs .nav-link.active{background-color:#1e3c72;color:white;border-color:#1e3c72}
        .tab-pane{padding:15px 0}
        .mode-toggle .btn{margin:0 5px;border-radius:30px}
        .export-dropdown .btn{min-width:120px}
        @media print{.no-print{display:none!important}}
        .table-container{overflow-x:auto}
        .select2-container--bootstrap-5 .select2-selection{border-radius:8px}
        .status-badge{padding:3px 10px;border-radius:20px;font-size:12px}
        .status-available{background:#d4edda;color:#155724}
        .status-issued{background:#f8d7da;color:#721c24}
        .call-number-display{font-family:monospace;background:#f8f9fa;padding:2px 8px;border-radius:4px;font-size:12px}
        .export-dropdown .dropdown-menu { display: none; }
        .export-dropdown .dropdown-menu.show { display: block; }
        .currency-select { max-height: 200px; overflow-y: auto; }
        
        /* Modal scrolling fixes */
        .modal-dialog-scrollable {
            max-height: 95vh;
        }
        .modal-dialog-scrollable .modal-content {
            max-height: 95vh;
            display: flex;
            flex-direction: column;
        }
        .modal-dialog-scrollable .modal-body {
            flex: 1 1 auto;
            overflow-y: auto;
            padding: 1rem;
            max-height: calc(95vh - 130px);
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar {
            width: 6px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb {
            background: #1e3c72;
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb:hover {
            background: #2a5298;
        }
        
        .result-card{transition:all 0.3s}
        .result-card:hover{transform:translateY(-3px);box-shadow:0 4px 12px rgba(0,0,0,0.1)}
        .table th{background:#073b6f;color:white;white-space:nowrap}
        .table td{vertical-align:middle}
        
        @media (max-width:768px){
            .book-cover-thumb{width:35px;height:45px}
            .default-cover-thumb{width:35px;height:45px;font-size:1rem}
            .modal-dialog-scrollable .modal-body{max-height:calc(90vh - 120px)}
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 flex-wrap gap-2">
        <div>
            <h2><i class="fas fa-book"></i> Book Management</h2>
            <div class="mode-toggle mt-2">
                <a href="?mode=full" class="btn <?= $mode == 'full' ? 'btn-primary' : 'btn-outline-primary' ?>"><i class="fas fa-layer-group"></i> Full Cataloguing</a>
                <a href="?mode=easy" class="btn <?= $mode == 'easy' ? 'btn-primary' : 'btn-outline-primary' ?>"><i class="fas fa-feather-alt"></i> Easy Cataloguing</a>
            </div>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addBookModal"><i class="fas fa-plus"></i> Add Book</button>
            <button class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#bulkImportModal"><i class="fas fa-upload"></i> Bulk Import</button>
            <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#apiKeyModal"><i class="fas fa-key"></i> API Keys</button>
            
            <div class="dropdown export-dropdown">
                <button class="btn btn-success dropdown-toggle" type="button" onclick="toggleExportDropdown(event)">
                    <i class="fas fa-download"></i> Export
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="exportDropdownMenu">
                    <li class="dropdown-header">CSV</li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('csv','copies')"><i class="fas fa-file-csv"></i> Accession Register (Copies)</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('csv','titles')"><i class="fas fa-file-csv"></i> Titles (Grouped)</a></li>
                    <?php if ($excelAvailable): ?>
                    <li><hr class="dropdown-divider"></li>
                    <li class="dropdown-header">Excel</li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('excel','copies')"><i class="fas fa-file-excel"></i> Accession Register (Copies)</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('excel','titles')"><i class="fas fa-file-excel"></i> Titles (Grouped)</a></li>
                    <?php endif; ?>
                    <?php if ($pdfAvailable): ?>
                    <li><hr class="dropdown-divider"></li>
                    <li class="dropdown-header">PDF</li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('pdf','copies')"><i class="fas fa-file-pdf"></i> Accession Register (Copies)</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('pdf','titles')"><i class="fas fa-file-pdf"></i> Titles (Grouped)</a></li>
                    <?php endif; ?>
                    <?php if ($marcAvailable): ?>
                    <li><hr class="dropdown-divider"></li>
                    <li class="dropdown-header">MARC21</li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('marc','mrc')"><i class="fas fa-book"></i> MARC (.mrc)</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('marc','xml')"><i class="fas fa-file-code"></i> MARCXML (.xml)</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            
            <button class="btn btn-secondary" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            
            <div class="btn-group">
                <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-exchange-alt"></i> MARC21</button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#importMarcModal"><i class="fas fa-upload"></i> Import MARC</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('marc','mrc')"><i class="fas fa-download"></i> Export MARC (.mrc)</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportBooks('marc','xml')"><i class="fas fa-download"></i> Export MARCXML (.xml)</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-2 col-6"><div class="card text-center bg-primary text-white stat-card" onclick="filterByStatus('')"><div class="card-body"><h3><?= number_format($totalBooks) ?></h3><p>Total Copies</p><small>Sum of quantities</small></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-info text-white stat-card" onclick="filterByStatus('')"><div class="card-body"><h3><?= number_format($totalTitles) ?></h3><p>Total Titles</p><small>Distinct books</small></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-success text-white stat-card" onclick="filterByStatus('available')"><div class="card-body"><h3><?= number_format($totalAvailable) ?></h3><p>Available Copies</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-warning text-white stat-card" onclick="filterByStatus('unavailable')"><div class="card-body"><h3><?= number_format($totalIssued) ?></h3><p>Issued Copies</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center <?= $lowStock>0?'bg-danger':'bg-secondary' ?> text-white stat-card" onclick="filterByStatus('lowstock')"><div class="card-body"><h3><?= number_format($lowStock) ?></h3><p>Low Stock Titles</p><small>Available ≤ 2</small></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-dark text-white stat-card"><div class="card-body"><h3><?= number_format(count($books)) ?></h3><p>Showing</p><small>Filtered results</small></div></div></div>
    </div>

    <!-- Collapsible Filter Panel -->
    <div class="filter-card no-print" id="filterCard">
        <div class="card-header" onclick="toggleFilterPanel()">
            <i class="fas fa-filter"></i> Advanced Filters 
            <i class="fas fa-chevron-down float-end mt-1"></i>
        </div>
        <div class="card-body" id="filterBody">
            <form method="get" id="filterForm">
                <input type="hidden" name="mode" value="<?= $mode ?>">
                <div class="row g-3">
                    <div class="col-md-12">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search across title, author, publisher, ISBN, barcode, subject, keyword, call number..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><select name="category" class="form-select select2"><option value="">All Categories</option><?php foreach($categories as $c) echo "<option value=\"$c\"".($category==$c?' selected':'').">".htmlspecialchars($c)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="author" class="form-select select2"><option value="">All Authors</option><?php foreach($authors as $a) echo "<option value=\"$a\"".($author==$a?' selected':'').">".htmlspecialchars($a)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="publisher" class="form-select select2"><option value="">All Publishers</option><?php foreach($publishers as $p) echo "<option value=\"$p\"".($publisher==$p?' selected':'').">".htmlspecialchars($p)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="subject" class="form-select select2"><option value="">All Subjects</option><?php foreach($subjects as $s) echo "<option value=\"$s\"".($subject==$s?' selected':'').">".htmlspecialchars($s)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="location" class="form-select select2"><option value="">All Locations</option><?php foreach($locations as $l) echo "<option value=\"$l\"".($location==$l?' selected':'').">".htmlspecialchars($l)."</option>"; ?></select></div>
                    <div class="col-md-2"><input type="text" name="isbn_filter" class="form-control" placeholder="ISBN" value="<?= htmlspecialchars($isbn_filter) ?>"></div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><input type="text" name="call_number_filter" class="form-control" placeholder="Call Number" value="<?= htmlspecialchars($call_number_filter) ?>"></div>
                    <div class="col-md-2"><input type="text" name="accession_filter" class="form-control" placeholder="Accession No." value="<?= htmlspecialchars($accession_filter) ?>"></div>
                    <div class="col-md-2"><select name="item_category" class="form-select select2"><option value="">Item Category</option><?php foreach($itemCategories as $ic) echo "<option value=\"$ic\"".($itemCategory==$ic?' selected':'').">".htmlspecialchars($ic)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="book_status_filter" class="form-select select2"><option value="">Book Status</option><?php foreach($bookStatuses as $bs) echo "<option value=\"$bs\"".($bookStatusFilter==$bs?' selected':'').">".htmlspecialchars($bs)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="maintenance" class="form-select select2"><option value="">Maintenance</option><?php foreach($maintenances as $m) echo "<option value=\"$m\"".($maintenance==$m?' selected':'').">".htmlspecialchars($m)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="year_from" class="form-select"><option value="">Year From</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_from==$y?' selected':'').">$y</option>"; ?></select></div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><select name="year_to" class="form-select"><option value="">Year To</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_to==$y?' selected':'').">$y</option>"; ?></select></div>
                    <div class="col-md-2"><input type="number" name="price_min" class="form-control" placeholder="Min Price" value="<?= htmlspecialchars($price_min) ?>"></div>
                    <div class="col-md-2"><input type="number" name="price_max" class="form-control" placeholder="Max Price" value="<?= htmlspecialchars($price_max) ?>"></div>
                    <div class="col-md-2"><select name="status" class="form-select"><option value="">All Availability</option><option value="available" <?= $status=='available'?'selected':'' ?>>Available Only</option><option value="unavailable" <?= $status=='unavailable'?'selected':'' ?>>Not Available</option><option value="lowstock" <?= $status=='lowstock'?'selected':'' ?>>Low Stock</option></select></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Apply Filters</button></div>
                    <div class="col-md-2"><a href="books.php?mode=<?= $mode ?>" class="btn btn-secondary w-100">Clear All</a></div>
                </div>
            </form>
        </div>
    </div>

    <!-- Book Table -->
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> Book Catalog <?= $mode === 'titles' ? '(Grouped by Title)' : '(Per Copy / Accession Register)' ?></span>
            <span class="badge bg-secondary"><?= count($books) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table table-hover table-bordered mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th class="text-center" style="width:60px">Cover</th>
                            <th>Date of Entry</th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'title','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Title <?= $sort_by=='title'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'author','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Author <?= $sort_by=='author'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                            <th>Publisher</th>
                            <th>ISBN</th>
                            <th>Barcode</th>
                            <th>Accession</th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'call_number','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Call No. <?= $sort_by=='call_number'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                            <th>Category / Status</th>
                            <th>Location</th>
                            <th>Qty/Avail</th>
                            <th>Price</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($books)): ?>
                            <tr><td colspan="14" class="text-center py-4 text-muted">No books found. <?php if(!empty($search) || !empty($category) || !empty($status)) echo 'Try adjusting your filters.'; else echo 'Add your first book using the "Add Book" button.'; ?></td></tr>
                        <?php else: ?>
                            <?php foreach($books as $book): 
                                $coverBase64 = getBookCoverBase64($book['cover_path'] ?? '');
                                $coverUrl = getBookCoverUrl($book['cover_path'] ?? '');
                            ?>
                            <tr>
                                <td class="text-center">
                                    <?php if ($coverBase64): ?>
                                        <img src="<?= $coverBase64 ?>" class="book-cover-thumb" alt="Cover" 
                                             onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                        <div class="default-cover-thumb" style="display:none;">
                                            <i class="fas fa-book"></i>
                                        </div>
                                    <?php elseif ($coverUrl): ?>
                                        <img src="<?= $coverUrl ?>" class="book-cover-thumb" alt="Cover"
                                             onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                        <div class="default-cover-thumb" style="display:none;">
                                            <i class="fas fa-book"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="default-cover-thumb">
                                            <i class="fas fa-book"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?= $book['date_of_entry'] ? date('d-m-Y', strtotime($book['date_of_entry'])) : date('d-m-Y', strtotime($book['created_at'] ?? 'now')) ?></td>
                                <td><strong><?= htmlspecialchars(substr($book['title'],0,60)) ?></strong><?php if($book['sub_title']): ?><br><small class="text-muted"><?= htmlspecialchars($book['sub_title']) ?></small><?php endif; ?></td>
                                <td><?= htmlspecialchars($book['author']??'-') ?></td>
                                <td><?= htmlspecialchars($book['publisher']??'-') ?></td>
                                <td><?= htmlspecialchars($book['isbn']??'-') ?></td>
                                <td><code><?= htmlspecialchars($book['barcode']) ?></code></td>
                                <td><?= htmlspecialchars($book['accession_number']??'-') ?></td>
                                <td><span class="call-number-display"><?= htmlspecialchars($book['call_number']??'-') ?></span></td>
                                <td>
                                    <span class="badge bg-secondary"><?= htmlspecialchars($book['category']??'Uncategorized') ?></span>
                                    <br>
                                    <span class="status-badge <?= ((int)($book['available'] ?? 0) > 0) ? 'status-available' : 'status-issued' ?>">
                                        <?= ((int)($book['available'] ?? 0) > 0) ? 'Available' : 'Issued' ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($book['location']??'-') ?></td>
                                <td><span class="badge bg-primary"><?= $book['quantity'] ?></span> / <span class="badge bg-<?= $book['available']>0?'success':'danger' ?>"><?= $book['available'] ?></span></td>
                                <td><?= ($book['price'])?($book['price_currency']??'INR').' '.number_format($book['price'],2):'-' ?></td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="?edit=<?= urlencode($book['barcode']) ?>&mode=<?= $mode ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                                        <a href="?delete=<?= urlencode($book['barcode']) ?>&mode=<?= $mode ?>" class="btn btn-danger" onclick="return confirm('Delete this copy?')" title="Delete"><i class="fas fa-trash"></i></a>
                                        <button class="btn btn-secondary" onclick="generateBookBarcode('<?= $book['barcode'] ?>','<?= addslashes($book['title']) ?>')" title="Barcode"><i class="fas fa-barcode"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Book Modal - Full Mode (FIXED SCROLLING) -->
<?php if ($mode == 'full'): ?>
<div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-primary text-white sticky-top" style="z-index: 10;">
                <h5 class="modal-title" id="addBookModalLabel">Add New Book (Full Mode)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data" id="addBookForm">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" id="autoBarcodeToggle" checked>
                        <label class="form-check-label" for="autoBarcodeToggle">Auto-generate Barcode (if empty)</label>
                    </div>
                    <ul class="nav nav-tabs" id="bookTab" role="tablist">
                        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#tabBasic">Basic Information</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tabClassification">Classification</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tabHoldings">Holdings</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tabAcquisition">Acquisition</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tabDigital">Digital & Notes</a></li>
                    </ul>
                    <div class="tab-content">
                        <!-- Tab 1: Basic Information -->
                        <div class="tab-pane fade show active" id="tabBasic">
                            <div class="row g-3 mt-2">
                                <div class="col-md-6"><label>Date of Entry</label><input type="text" class="form-control" value="<?= date('d-m-Y') ?>" readonly disabled></div>
                                <div class="col-md-6"><label>Barcode * <small class="text-muted">(952$p)</small></label><input type="text" name="barcode" id="barcode" class="form-control" required></div>
                                <div class="col-md-6"><label>Call Number <small>(090$a)</small> <span class="text-info">(Auto-generated)</span></label>
                                    <div class="input-group">
                                        <input type="text" name="call_number" id="call_number" class="form-control" readonly style="background:#f8f9fa;font-family:monospace;">
                                        <button type="button" class="btn btn-secondary" onclick="generateCallNumberField()" title="Generate Call Number"><i class="fas fa-sync-alt"></i></button>
                                    </div>
                                </div>
                                <div class="col-md-6"><label>Accession Number <small>(952$a)</small></label><input type="text" name="accession_number" class="form-control"></div>
                                <div class="col-md-12">
                                    <label>ISBN <small>(020$a)</small> <span class="text-info">(Auto-fetch on blur)</span></label>
                                    <div class="input-group">
                                        <input type="text" name="isbn" id="isbn" class="form-control" autocomplete="off">
                                        <select id="fetchSourceSelect" class="form-select w-auto"><option value="auto">Auto (Try all)</option><option value="google">Google Books</option><option value="openlibrary">OpenLibrary</option><?php if($isbndbKey): ?><option value="isbndb">ISBNdb</option><?php endif; ?><?php if($worldcatKey): ?><option value="worldcat">WorldCat</option><?php endif; ?><?php if($yazAvailable): ?><option value="z3950">Z39.50</option><?php endif; ?></select>
                                        <button type="button" class="btn btn-primary" onclick="fetchFromSelectedSource(false)">Fetch</button>
                                        <button type="button" class="btn btn-info" onclick="fetchFromAllSources()">Fetch ALL Sources</button>
                                    </div>
                                    <div id="apiStatus" class="small text-muted mt-1"></div>
                                    <input type="hidden" name="cover_url" id="cover_url_hidden"><input type="hidden" name="pre_downloaded_cover" id="pre_downloaded_cover" value="">
                                </div>
                                <div class="col-md-6"><label>Title * <small>(245$a)</small></label><input type="text" name="title" id="title" class="form-control" required onchange="generateCallNumberField()"></div>
                                <div class="col-md-6"><label>Subtitle <small>(245$b)</small></label><input type="text" name="sub_title" id="sub_title" class="form-control"></div>
                                <div class="col-md-12"><label>Statement of Responsibility <small>(245$c)</small></label><input type="text" name="collaborator" class="form-control"></div>
                                <div class="col-md-4"><label>Author <small>(100$a)</small></label><input type="text" name="author" id="author" class="form-control" onchange="generateCallNumberField()"></div>
                                <div class="col-md-4"><label>Author 2 <small>(700$a)</small></label><input type="text" name="author2" class="form-control"></div>
                                <div class="col-md-4"><label>Corporate Author <small>(110$a)</small></label><input type="text" name="corporate_author" class="form-control"></div>
                                <div class="col-md-4"><label>Conference Author <small>(111$a)</small></label><input type="text" name="conference_author" class="form-control"></div>
                                <div class="col-md-4"><label>Publisher <small>(260$b/264$b)</small></label><input type="text" name="publisher" id="publisher" class="form-control"></div>
                                <div class="col-md-4"><label>Publisher Place <small>(260$a/264$a)</small></label><input type="text" name="publisher_place" class="form-control"></div>
                                <div class="col-md-3"><label>Year <small>(260$c/264$c)</small></label><input type="text" name="year" id="year" class="form-control"></div>
                                <div class="col-md-3"><label>Edition <small>(250$a)</small></label><input type="text" name="edition" class="form-control"></div>
                                <div class="col-md-3"><label>Language <small>(041$a)</small></label><input type="text" name="language" class="form-control" value="English"></div>
                                <div class="col-md-3"><label>Country <small>(044$a)</small></label><input type="text" name="country" class="form-control"></div>
                                <div class="col-md-4"><label>Series <small>(490$a)</small></label><input type="text" name="series" class="form-control"></div>
                                <div class="col-md-4"><label>Volume <small>(490$v)</small></label><input type="text" name="volume" class="form-control"></div>
                                <div class="col-md-4"><label>ISSN <small>(022$a)</small></label><input type="text" name="issn" class="form-control"></div>
                            </div>
                        </div>
                        <!-- Tab 2: Classification -->
                        <div class="tab-pane fade" id="tabClassification">
                            <div class="row g-3 mt-2">
                                <div class="col-md-3">
                                    <label>DDC <small>(082$a)</small></label>
                                    <select name="ddc" id="ddc" class="form-select classification-select" onchange="generateCallNumberField()">
                                        <option value="">-- Select or type --</option>
                                        <option value="000">000 – Computer science</option>
                                        <option value="100">100 – Philosophy</option>
                                        <option value="200">200 – Religion</option>
                                        <option value="300">300 – Social sciences</option>
                                        <option value="400">400 – Language</option>
                                        <option value="500">500 – Science</option>
                                        <option value="600">600 – Technology</option>
                                        <option value="700">700 – Arts</option>
                                        <option value="800">800 – Literature</option>
                                        <option value="900">900 – History</option>
                                        <option value="Other">Other (type below)</option>
                                    </select>
                                    <input type="text" name="ddc_other" class="form-control mt-1" placeholder="Custom DDC" style="display:none;" onchange="generateCallNumberField()">
                                </div>
                                <div class="col-md-3">
                                    <label>UDC <small>(080$a)</small></label>
                                    <select name="udc" class="form-select classification-select" onchange="generateCallNumberField()">
                                        <option value="">-- Select or type --</option>
                                        <option value="0">0 – Generalities</option>
                                        <option value="1">1 – Philosophy</option>
                                        <option value="2">2 – Religion</option>
                                        <option value="3">3 – Social Sciences</option>
                                        <option value="5">5 – Mathematics</option>
                                        <option value="6">6 – Applied sciences</option>
                                        <option value="7">7 – Arts</option>
                                        <option value="8">8 – Language</option>
                                        <option value="9">9 – Geography</option>
                                        <option value="Other">Other (type below)</option>
                                    </select>
                                    <input type="text" name="udc_other" class="form-control mt-1" placeholder="Custom UDC" style="display:none;" onchange="generateCallNumberField()">
                                </div>
                                <div class="col-md-3">
                                    <label>LCC <small>(050$a)</small></label>
                                    <select name="lcc" id="lcc" class="form-select classification-select" onchange="generateCallNumberField()">
                                        <option value="">-- Select or type --</option>
                                        <option value="A">A – General Works</option>
                                        <option value="B">B – Philosophy</option>
                                        <option value="C">C – History</option>
                                        <option value="D">D – World History</option>
                                        <option value="E">E – Americas</option>
                                        <option value="F">F – Americas Local</option>
                                        <option value="G">G – Geography</option>
                                        <option value="H">H – Social Sciences</option>
                                        <option value="J">J – Political Science</option>
                                        <option value="K">K – Law</option>
                                        <option value="L">L – Education</option>
                                        <option value="M">M – Music</option>
                                        <option value="N">N – Fine Arts</option>
                                        <option value="P">P – Language</option>
                                        <option value="Q">Q – Science</option>
                                        <option value="R">R – Medicine</option>
                                        <option value="S">S – Agriculture</option>
                                        <option value="T">T – Technology</option>
                                        <option value="U">U – Military</option>
                                        <option value="V">V – Naval</option>
                                        <option value="Z">Z – Bibliography</option>
                                        <option value="Other">Other (type below)</option>
                                    </select>
                                    <input type="text" name="lcc_other" class="form-control mt-1" placeholder="Custom LCC" style="display:none;" onchange="generateCallNumberField()">
                                </div>
                                <div class="col-md-3">
                                    <label>CC <small>(Colon Classification)</small></label>
                                    <input type="text" name="cc" id="cc" class="form-control" placeholder="e.g., X:2, Y:3" onchange="generateCallNumberField()">
                                </div>
                                <div class="col-md-3">
                                    <label>Other Classification</label>
                                    <input type="text" name="other_classification" id="other_classification" class="form-control" placeholder="e.g., NLM, BLISS" onchange="generateCallNumberField()">
                                </div>
                                <div class="col-md-3">
                                    <label>Cutter Number</label>
                                    <input type="text" name="cutter" class="form-control">
                                </div>
                                <div class="col-md-12">
                                    <label>Subjects <small>(650$a - multiple)</small></label>
                                    <input type="text" name="subject" id="subject" class="form-control" placeholder="Separate with semicolons">
                                </div>
                                <div class="col-md-12">
                                    <label>Keywords <small>(653$a)</small></label>
                                    <input type="text" name="keyword" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label>Category</label>
                                    <input type="text" name="category" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label>Sub Category</label>
                                    <input type="text" name="sub_category" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <label>Collection Type <small>(952$8)</small></label>
                                    <input type="text" name="collection_type" class="form-control">
                                </div>
                            </div>
                        </div>
                        <!-- Tab 3: Holdings -->
                        <div class="tab-pane fade" id="tabHoldings">
                            <div class="row g-3 mt-2">
                                <div class="col-md-3"><label>Quantity</label><input type="number" name="quantity" value="1" min="1" class="form-control" id="quantity" onchange="document.getElementById('available').value=this.value"></div>
                                <div class="col-md-3"><label>Available</label><input type="number" name="available" id="available" value="1" min="0" class="form-control"></div>
                                <div class="col-md-3"><label>Book Status</label><select name="book_status" class="form-select"><option value="Available">Available</option><option value="Not Available">Not Available</option><option value="Restricted">Restricted</option><option value="Removed">Removed</option><option value="Weeded Out">Weeded Out</option><option value="Reference Only">Reference Only</option><option value="Missing">Missing</option><option value="Other">Other</option></select><div id="bookStatusOtherDiv" style="display:none;"><input type="text" name="book_status_other" class="form-control mt-1" placeholder="Specify status"></div></div>
                                <div class="col-md-3"><label>Loan Type</label><select name="item_category" class="form-select"><option value="">General</option><option value="Reference">Reference</option><option value="Textbooks">Textbooks</option><option value="Restricted">Restricted</option><option value="CD">CD</option><option value="MAPS">MAPS</option><option value="Others">Others</option></select><div id="otherCategoryDiv" style="display:none;"><input type="text" name="item_category_other" class="form-control mt-1" placeholder="Specify item category"></div></div>
                                <div class="col-md-4"><label>Maintenance <small>(Binding)</small></label><select name="maintenance" class="form-select"><option value="">Not specified</option><option value="Hardcover">Hardcover</option><option value="Paperback">Paperback</option><option value="Spiral">Spiral</option><option value="Leather">Leather</option><option value="Other">Other</option></select><div id="maintenanceOtherDiv" style="display:none;"><input type="text" name="maintenance_other" class="form-control mt-1" placeholder="Specify maintenance"></div></div>
                                <div class="col-md-4"><label>Current Location <small>(Holding)</small></label><input type="text" name="current_location" class="form-control"></div>
                                <div class="col-md-4"><label>Section</label><input type="text" name="section" class="form-control"></div>
                                <div class="col-md-4"><label>Branch <small>(852$b)</small></label><input type="text" name="branch" class="form-control"></div>
                                <div class="col-md-4"><label>Rack/Location <small>(852$c)</small></label><input type="text" name="location" class="form-control"></div>
                                <div class="col-md-4"><label>Shelf Number <small>(852$h)</small></label><input type="text" name="shelf" class="form-control"></div>
                            </div>
                        </div>
                        <!-- Tab 4: Acquisition -->
                        <div class="tab-pane fade" id="tabAcquisition">
                            <div class="row g-3 mt-2">
                                <div class="col-md-4"><label>Vendor/Supplier <small>(541$a)</small></label><input type="text" name="vendor" class="form-control"></div>
                                <div class="col-md-4"><label>Invoice Number <small>(541$e)</small></label><input type="text" name="invoice" class="form-control"></div>
                                <div class="col-md-4"><label>Invoice Date</label><input type="date" name="invoice_date" class="form-control"></div>
                                <div class="col-md-4"><label>Acquisition Date</label><input type="date" name="acquisition_date" class="form-control"></div>
                                <div class="col-md-3"><label>Cost Price</label><input type="number" step="0.01" name="price" class="form-control"></div>
                                <div class="col-md-3">
                                    <label>Currency</label>
                                    <select name="price_currency" class="form-select currency-select">
                                        <?php foreach($allCurrencies as $code => $label): ?>
                                            <option value="<?= $code ?>" <?= ($code === 'INR') ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-3"><label>Funding Source <small>(536$a)</small></label><input type="text" name="funding_source" class="form-control"></div>
                                <div class="col-md-3"><label>PO Number</label><input type="text" name="po_number" class="form-control"></div>
                                <div class="col-md-12"><label>Accompanying Material <small>(300$e)</small></label><input type="text" name="accompanying_material" class="form-control" placeholder="e.g., CD, DVD, Map"></div>
                            </div>
                        </div>
                        <!-- Tab 5: Digital & Notes -->
                        <div class="tab-pane fade" id="tabDigital">
                            <div class="row g-3 mt-2">
                                <div class="col-md-12">
                                    <label>Cover Image</label>
                                    <input type="file" name="book_cover" class="form-control" accept="image/*" onchange="previewCover(this)">
                                    <div id="coverPreview" class="mt-2" style="display:none;">
                                        <img id="coverImg" style="height:100px;">
                                        <button type="button" class="btn btn-sm btn-danger" onclick="document.getElementById('coverPreview').style.display='none'; document.getElementById('cover_url_hidden').value='';">Remove</button>
                                    </div>
                                    <div id="coverDownloadStatus" class="small text-muted mt-1"></div>
                                </div>
                                <div class="col-md-12"><label>eBook URL</label><input type="url" name="ebook_url" class="form-control"></div>
                                <div class="col-md-12"><label>Summary <small>(520$a)</small></label><textarea name="summary" id="summary" class="form-control" rows="3"></textarea></div>
                                <div class="col-md-12"><label>Contents / Table of Contents</label><textarea name="contents" class="form-control" rows="3"></textarea></div>
                                <div class="col-md-6"><label>Illustrations <small>(300$b)</small></label><input type="text" name="illustrations" class="form-control"></div>
                                <div class="col-md-6"><label>Dimensions <small>(300$c)</small></label><input type="text" name="dimensions" class="form-control"></div>
                                <div class="col-md-4"><label>Material Type <small>(Leader/008)</small></label><input type="text" name="material_type" class="form-control"></div>
                                <div class="col-md-4"><label>Size</label><input type="text" name="size" class="form-control"></div>
                                <div class="col-md-4"><label>Weight</label><input type="text" name="weight" class="form-control"></div>
                                <div class="col-md-12"><label>Remarks / Notes</label><input type="text" name="remarks" class="form-control"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="submit" name="add_book" class="btn btn-primary">Add Book</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php else: ?>
<!-- Easy Mode Modal (FIXED SCROLLING) -->
<div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-primary text-white sticky-top" style="z-index: 10;">
                <h5 class="modal-title" id="addBookModalLabel">Add New Book (Easy Mode)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data" id="easyBookForm">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="row g-3">
                        <div class="col-md-6"><label>Date of Entry</label><input type="text" class="form-control" value="<?= date('d-m-Y') ?>" readonly disabled></div>
                        <div class="col-md-6"><label>Barcode *</label><input type="text" name="barcode" class="form-control" required></div>
                        <div class="col-md-12"><label>Call Number <span class="text-info">(Auto-generated)</span></label>
                            <div class="input-group">
                                <input type="text" name="call_number" id="easy_call_number" class="form-control" readonly style="background:#f8f9fa;font-family:monospace;">
                                <button type="button" class="btn btn-secondary" onclick="generateEasyCallNumber()"><i class="fas fa-sync-alt"></i></button>
                            </div>
                        </div>
                        <div class="col-md-6"><label>ISBN (Auto-fetch with cover)</label><div class="input-group"><input type="text" name="isbn" id="easyIsbn" class="form-control"><button type="button" class="btn btn-primary" onclick="fetchEasyMetadata()"><i class="fas fa-sync-alt"></i> Fetch</button></div><div id="easyFetchStatus" class="small text-muted mt-1"></div></div>
                        <div class="col-md-12"><label>Title *</label><input type="text" name="title" id="easyTitle" class="form-control" required></div>
                        <div class="col-md-6"><label>Subtitle</label><input type="text" name="sub_title" id="easySubtitle" class="form-control"></div>
                        <div class="col-md-6"><label>Author(s)</label><input type="text" name="author" id="easyAuthor" class="form-control"></div>
                        <div class="col-md-4"><label>Publisher</label><input type="text" name="publisher" id="easyPublisher" class="form-control"></div>
                        <div class="col-md-2"><label>Year</label><input type="text" name="year" id="easyYear" class="form-control"></div>
                        <div class="col-md-2"><label>Pages</label><input type="number" name="pages" id="easyPages" class="form-control"></div>
                        <div class="col-md-4"><label>Language</label><input type="text" name="language" class="form-control" value="English"></div>
                        <div class="col-md-6"><label>Subjects (Keywords)</label><input type="text" name="subject" id="easySubject" class="form-control"></div>
                        <div class="col-md-6"><label>Additional Keywords</label><input type="text" name="keyword" class="form-control"></div>
                        <div class="col-md-12"><label>Summary / Description</label><textarea name="summary" id="easySummary" class="form-control" rows="2"></textarea></div>
                        <div class="col-md-3"><label>Classification (DDC/LCC/CC)</label>
                            <select name="classification" id="easyClassification" class="form-select" onchange="generateEasyCallNumber()">
                                <option value="">-- Select --</option>
                                <option value="000">000 – Computer science</option>
                                <option value="100">100 – Philosophy</option>
                                <option value="200">200 – Religion</option>
                                <option value="300">300 – Social sciences</option>
                                <option value="400">400 – Language</option>
                                <option value="500">500 – Science</option>
                                <option value="600">600 – Technology</option>
                                <option value="700">700 – Arts</option>
                                <option value="800">800 – Literature</option>
                                <option value="900">900 – History</option>
                                <option value="A">A – General Works</option>
                                <option value="B">B – Philosophy</option>
                                <option value="C">C – History</option>
                                <option value="D">D – World History</option>
                                <option value="E">E – Americas</option>
                                <option value="F">F – Americas Local</option>
                                <option value="G">G – Geography</option>
                                <option value="H">H – Social Sciences</option>
                                <option value="J">J – Political Science</option>
                                <option value="K">K – Law</option>
                                <option value="L">L – Education</option>
                                <option value="M">M – Music</option>
                                <option value="N">N – Fine Arts</option>
                                <option value="P">P – Language</option>
                                <option value="Q">Q – Science</option>
                                <option value="R">R – Medicine</option>
                                <option value="S">S – Agriculture</option>
                                <option value="T">T – Technology</option>
                                <option value="U">U – Military</option>
                                <option value="V">V – Naval</option>
                                <option value="Z">Z – Bibliography</option>
                            </select>
                        </div>
                        <div class="col-md-3"><label>Quantity</label><input type="number" name="quantity" value="1" min="1" class="form-control"></div>
                        <div class="col-md-3"><label>Available copies</label><input type="number" name="available" value="1" min="0" class="form-control"></div>
                        <div class="col-md-3"><label>Price</label><input type="number" step="0.01" name="price" class="form-control"></div>
                        <div class="col-md-3"><label>Currency</label>
                            <select name="price_currency" class="form-select currency-select">
                                <?php foreach($allCurrencies as $code => $label): ?>
                                    <option value="<?= $code ?>" <?= ($code === 'INR') ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12"><label>Cover Image</label><input type="file" name="book_cover" class="form-control" accept="image/*" onchange="previewEasyCover(this)"><div id="easyCoverPreview" class="mt-2" style="display:none;"><img id="easyCoverImg" style="height:100px;"></div><input type="hidden" name="pre_downloaded_cover" id="easyPreDownloadedCover" value=""></div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="submit" name="add_book" class="btn btn-primary">Add Book</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Bulk Import Modal -->
<div class="modal fade" id="bulkImportModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header bg-info text-white"><h5>Bulk Import CSV</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
    <form method="post" enctype="multipart/form-data" id="bulkImportForm">
        <input type="file" name="bulk_csv" class="form-control mb-2" accept=".csv" required>
        <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="auto_fetch_metadata" id="autoFetchMeta" checked><label class="form-check-label">Automatically fetch metadata and cover images from ISBN (if available)</label></div>
        <button type="submit" name="bulk_import" class="btn btn-success" id="bulkImportBtn">Import</button>
        <div id="importProgress" class="mt-2" style="display:none;"><div class="progress"><div class="progress-bar progress-bar-striped progress-bar-animated" style="width:0%">0%</div></div><p class="small text-muted mt-1">Processing...</p></div>
    </form>
    <hr><a href="#" id="downloadSampleCsv" class="btn btn-sm btn-outline-primary">Download Sample CSV</a>
    <div class="alert alert-info small mt-2"><strong>Note:</strong> If ISBN is provided, the system will automatically fetch title, author, publisher, year, pages, subject, summary, and cover image from multiple sources.</div>
</div></div></div></div>

<!-- Bulk Cover Upload -->
<div class="modal fade" id="bulkCoverModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header bg-success text-white"><h5>Bulk Book Covers Upload (ZIP)</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="bulk_covers_zip" class="form-control mb-2" accept=".zip" required>
        <button type="submit" name="bulk_covers_upload" class="btn btn-success">Upload ZIP</button>
    </form>
    <div class="alert alert-info small mt-2">ZIP file containing images named exactly as book <code>barcode.jpg</code> (e.g., <code>B001.jpg</code>). Images will be resized to 400x400.</div>
</div></div></div></div>

<!-- API Key Modal -->
<div class="modal fade" id="apiKeyModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header bg-secondary text-white"><h5>API Keys for ISBN Services</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><form method="post"><div class="modal-body"><div class="mb-2"><label>ISBNdb API Key</label><input type="text" name="isbndb_api_key" class="form-control" value="<?= htmlspecialchars($isbndbKey) ?>"></div><div class="mb-2"><label>WorldCat API Key</label><input type="text" name="worldcat_api_key" class="form-control" value="<?= htmlspecialchars($worldcatKey) ?>"></div><div class="alert alert-info small">OpenLibrary and Google Books work without API keys. Z39.50 uses YAZ extension.</div></div><div class="modal-footer"><button type="submit" name="save_api_keys" class="btn btn-primary">Save Keys</button></div></form></div></div></div>

<!-- Import MARC Modal -->
<div class="modal fade" id="importMarcModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><div class="modal-header bg-secondary text-white"><h5>Import MARC21 File</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><form method="post" enctype="multipart/form-data"><input type="file" name="marc_file" class="form-control mb-2" accept=".mrc,.xml" required><button type="submit" name="import_marc" class="btn btn-primary" <?= !$marcAvailable ? 'disabled' : '' ?>>Import</button></form><div class="small text-muted mt-2"><?= $marcAvailable ? 'MARC import ready.' : 'MARC library not installed. Run composer require pear/file_marc.' ?></div></div></div></div></div>

<!-- Edit Book Modal (FIXED SCROLLING) -->
<?php if ($editBook): ?>
<div class="modal fade show" id="editBookModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-warning sticky-top" style="z-index: 10;">
                <h5>Edit Book</h5>
                <a href="books.php?mode=<?= $mode ?>" class="btn-close"></a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <?php if ($mode == 'full'): ?>
                    <!-- Full mode edit form -->
                    <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" id="autoBarcodeToggle" checked><label class="form-check-label">Auto-generate Barcode (if empty)</label></div>
                    <ul class="nav nav-tabs" id="editBookTab" role="tablist">
                        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#editTabBasic">Basic Information</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#editTabClassification">Classification</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#editTabHoldings">Holdings</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#editTabAcquisition">Acquisition</a></li>
                        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#editTabDigital">Digital & Notes</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="editTabBasic"><div class="row g-3 mt-2">
                            <div class="col-md-6"><label>Date of Entry</label><input type="text" class="form-control" value="<?= date('d-m-Y', strtotime($editBook['date_of_entry'] ?? $editBook['created_at'] ?? 'now')) ?>" readonly disabled></div>
                            <div class="col-md-6"><label>Barcode *</label><input type="text" name="barcode" class="form-control" value="<?= htmlspecialchars($editBook['barcode']) ?>" readonly></div>
                            <div class="col-md-6"><label>Call Number</label><input type="text" name="call_number" class="form-control" value="<?= htmlspecialchars($editBook['call_number']??'') ?>"></div>
                            <div class="col-md-6"><label>Accession Number</label><input type="text" name="accession_number" class="form-control" value="<?= htmlspecialchars($editBook['accession_number']??'') ?>"></div>
                            <div class="col-md-12"><label>ISBN</label><div class="input-group"><input type="text" name="isbn" id="edit_isbn" class="form-control" value="<?= htmlspecialchars($editBook['isbn']??'') ?>"><button type="button" class="btn btn-primary" onclick="fetchForEdit()">Fetch</button></div><div id="editApiStatus" class="small"></div></div>
                            <div class="col-md-6"><label>Title *</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($editBook['title']) ?>" required></div>
                            <div class="col-md-6"><label>Subtitle</label><input type="text" name="sub_title" class="form-control" value="<?= htmlspecialchars($editBook['sub_title']??'') ?>"></div>
                            <div class="col-md-12"><label>Statement of Responsibility</label><input type="text" name="collaborator" class="form-control" value="<?= htmlspecialchars($editBook['collaborator']??'') ?>"></div>
                            <div class="col-md-4"><label>Author</label><input type="text" name="author" class="form-control" value="<?= htmlspecialchars($editBook['author']??'') ?>"></div>
                            <div class="col-md-4"><label>Author 2</label><input type="text" name="author2" class="form-control" value="<?= htmlspecialchars($editBook['author2']??'') ?>"></div>
                            <div class="col-md-4"><label>Corporate Author</label><input type="text" name="corporate_author" class="form-control" value="<?= htmlspecialchars($editBook['corporate_author']??'') ?>"></div>
                            <div class="col-md-4"><label>Conference Author</label><input type="text" name="conference_author" class="form-control" value="<?= htmlspecialchars($editBook['conference_author']??'') ?>"></div>
                            <div class="col-md-4"><label>Publisher</label><input type="text" name="publisher" class="form-control" value="<?= htmlspecialchars($editBook['publisher']??'') ?>"></div>
                            <div class="col-md-4"><label>Publisher Place</label><input type="text" name="publisher_place" class="form-control" value="<?= htmlspecialchars($editBook['publisher_place']??'') ?>"></div>
                            <div class="col-md-3"><label>Year</label><input type="text" name="year" class="form-control" value="<?= htmlspecialchars($editBook['year']??'') ?>"></div>
                            <div class="col-md-3"><label>Edition</label><input type="text" name="edition" class="form-control" value="<?= htmlspecialchars($editBook['edition']??'') ?>"></div>
                            <div class="col-md-3"><label>Language</label><input type="text" name="language" class="form-control" value="<?= htmlspecialchars($editBook['language']??'English') ?>"></div>
                            <div class="col-md-3"><label>Country</label><input type="text" name="country" class="form-control" value="<?= htmlspecialchars($editBook['country']??'') ?>"></div>
                            <div class="col-md-4"><label>Series</label><input type="text" name="series" class="form-control" value="<?= htmlspecialchars($editBook['series']??'') ?>"></div>
                            <div class="col-md-4"><label>Volume</label><input type="text" name="volume" class="form-control" value="<?= htmlspecialchars($editBook['volume']??'') ?>"></div>
                            <div class="col-md-4"><label>ISSN</label><input type="text" name="issn" class="form-control" value="<?= htmlspecialchars($editBook['issn']??'') ?>"></div>
                        </div></div>
                        <div class="tab-pane fade" id="editTabClassification"><div class="row g-3 mt-2">
                            <div class="col-md-3"><label>DDC</label><input type="text" name="ddc" class="form-control" value="<?= htmlspecialchars($editBook['ddc']??'') ?>"></div>
                            <div class="col-md-3"><label>UDC</label><input type="text" name="udc" class="form-control" value="<?= htmlspecialchars($editBook['udc']??'') ?>"></div>
                            <div class="col-md-3"><label>LCC</label><input type="text" name="lcc" class="form-control" value="<?= htmlspecialchars($editBook['lcc']??'') ?>"></div>
                            <div class="col-md-3"><label>CC</label><input type="text" name="cc" class="form-control" value="<?= htmlspecialchars($editBook['cc']??'') ?>"></div>
                            <div class="col-md-3"><label>Other Classification</label><input type="text" name="other_classification" class="form-control" value="<?= htmlspecialchars($editBook['other_classification']??'') ?>"></div>
                            <div class="col-md-3"><label>Cutter Number</label><input type="text" name="cutter" class="form-control" value="<?= htmlspecialchars($editBook['cutter']??'') ?>"></div>
                            <div class="col-md-12"><label>Subjects</label><input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($editBook['subject']??'') ?>"></div>
                            <div class="col-md-12"><label>Keywords</label><input type="text" name="keyword" class="form-control" value="<?= htmlspecialchars($editBook['keyword']??'') ?>"></div>
                            <div class="col-md-4"><label>Category</label><input type="text" name="category" class="form-control" value="<?= htmlspecialchars($editBook['category']??'') ?>"></div>
                            <div class="col-md-4"><label>Sub Category</label><input type="text" name="sub_category" class="form-control" value="<?= htmlspecialchars($editBook['sub_category']??'') ?>"></div>
                            <div class="col-md-4"><label>Collection Type</label><input type="text" name="collection_type" class="form-control" value="<?= htmlspecialchars($editBook['collection_type']??'') ?>"></div>
                        </div></div>
                        <div class="tab-pane fade" id="editTabHoldings"><div class="row g-3 mt-2">
                            <div class="col-md-3"><label>Quantity</label><input type="number" name="quantity" class="form-control" value="<?= $editBook['quantity'] ?>"></div>
                            <div class="col-md-3"><label>Available</label><input type="number" name="available" class="form-control" value="<?= $editBook['available'] ?>"></div>
                            <div class="col-md-3"><label>Book Status</label><select name="book_status" class="form-select"><option value="Available" <?= ($editBook['book_status']??'Available')=='Available'?'selected':'' ?>>Available</option><option value="Not Available" <?= ($editBook['book_status']??'')=='Not Available'?'selected':'' ?>>Not Available</option><option value="Restricted" <?= ($editBook['book_status']??'')=='Restricted'?'selected':'' ?>>Restricted</option><option value="Removed" <?= ($editBook['book_status']??'')=='Removed'?'selected':'' ?>>Removed</option><option value="Weeded Out" <?= ($editBook['book_status']??'')=='Weeded Out'?'selected':'' ?>>Weeded Out</option><option value="Reference Only" <?= ($editBook['book_status']??'')=='Reference Only'?'selected':'' ?>>Reference Only</option><option value="Missing" <?= ($editBook['book_status']??'')=='Missing'?'selected':'' ?>>Missing</option><option value="Other" <?= ($editBook['book_status']??'')=='Other'?'selected':'' ?>>Other</option></select><div id="editBookStatusOtherDiv" style="display:none;"><input type="text" name="book_status_other" class="form-control mt-1" placeholder="Specify status" value="<?= ($editBook['book_status']??'')=='Other'?htmlspecialchars($editBook['book_status_other']??''):'' ?>"></div></div>
                            <div class="col-md-3"><label>Loan Type</label><select name="item_category" class="form-select"><option value="" <?= empty($editBook['item_category'])?'selected':'' ?>>General</option><option value="Reference" <?= ($editBook['item_category']??'')=='Reference'?'selected':'' ?>>Reference</option><option value="Textbooks" <?= ($editBook['item_category']??'')=='Textbooks'?'selected':'' ?>>Textbooks</option><option value="Restricted" <?= ($editBook['item_category']??'')=='Restricted'?'selected':'' ?>>Restricted</option><option value="CD" <?= ($editBook['item_category']??'')=='CD'?'selected':'' ?>>CD</option><option value="MAPS" <?= ($editBook['item_category']??'')=='MAPS'?'selected':'' ?>>MAPS</option><option value="Others" <?= ($editBook['item_category']??'')=='Others'?'selected':'' ?>>Others</option></select><div id="editOtherCategoryDiv" style="display:none;"><input type="text" name="item_category_other" class="form-control mt-1" placeholder="Specify item category" value="<?= ($editBook['item_category']??'')=='Others'?htmlspecialchars($editBook['item_category_other']??''):'' ?>"></div></div>
                            <div class="col-md-4"><label>Maintenance</label><select name="maintenance" class="form-select"><option value="" <?= empty($editBook['maintenance'])?'selected':'' ?>>Not specified</option><option value="Hardcover" <?= ($editBook['maintenance']??'')=='Hardcover'?'selected':'' ?>>Hardcover</option><option value="Paperback" <?= ($editBook['maintenance']??'')=='Paperback'?'selected':'' ?>>Paperback</option><option value="Spiral" <?= ($editBook['maintenance']??'')=='Spiral'?'selected':'' ?>>Spiral</option><option value="Leather" <?= ($editBook['maintenance']??'')=='Leather'?'selected':'' ?>>Leather</option><option value="Other" <?= ($editBook['maintenance']??'')=='Other'?'selected':'' ?>>Other</option></select><div id="editMaintenanceOtherDiv" style="display:none;"><input type="text" name="maintenance_other" class="form-control mt-1" placeholder="Specify maintenance" value="<?= ($editBook['maintenance']??'')=='Other'?htmlspecialchars($editBook['maintenance_other']??''):'' ?>"></div></div>
                            <div class="col-md-4"><label>Current Location</label><input type="text" name="current_location" class="form-control" value="<?= htmlspecialchars($editBook['current_location']??'') ?>"></div>
                            <div class="col-md-4"><label>Section</label><input type="text" name="section" class="form-control" value="<?= htmlspecialchars($editBook['section']??'') ?>"></div>
                            <div class="col-md-4"><label>Branch</label><input type="text" name="branch" class="form-control" value="<?= htmlspecialchars($editBook['branch']??'') ?>"></div>
                            <div class="col-md-4"><label>Rack/Location</label><input type="text" name="location" class="form-control" value="<?= htmlspecialchars($editBook['location']??'') ?>"></div>
                            <div class="col-md-4"><label>Shelf Number</label><input type="text" name="shelf" class="form-control" value="<?= htmlspecialchars($editBook['shelf']??'') ?>"></div>
                        </div></div>
                        <div class="tab-pane fade" id="editTabAcquisition"><div class="row g-3 mt-2">
                            <div class="col-md-4"><label>Vendor/Supplier</label><input type="text" name="vendor" class="form-control" value="<?= htmlspecialchars($editBook['vendor']??'') ?>"></div>
                            <div class="col-md-4"><label>Invoice Number</label><input type="text" name="invoice" class="form-control" value="<?= htmlspecialchars($editBook['invoice']??'') ?>"></div>
                            <div class="col-md-4"><label>Invoice Date</label><input type="date" name="invoice_date" class="form-control" value="<?= htmlspecialchars($editBook['invoice_date']??'') ?>"></div>
                            <div class="col-md-4"><label>Acquisition Date</label><input type="date" name="acquisition_date" class="form-control" value="<?= htmlspecialchars($editBook['acquisition_date']??'') ?>"></div>
                            <div class="col-md-3"><label>Cost Price</label><input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($editBook['price']??'') ?>"></div>
                            <div class="col-md-3">
                                <label>Currency</label>
                                <select name="price_currency" class="form-select currency-select">
                                    <?php foreach($allCurrencies as $code => $label): ?>
                                        <option value="<?= $code ?>" <?= ($editBook['price_currency'] ?? 'INR') == $code ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3"><label>Funding Source</label><input type="text" name="funding_source" class="form-control" value="<?= htmlspecialchars($editBook['funding_source']??'') ?>"></div>
                            <div class="col-md-3"><label>PO Number</label><input type="text" name="po_number" class="form-control" value="<?= htmlspecialchars($editBook['po_number']??'') ?>"></div>
                            <div class="col-md-12"><label>Accompanying Material</label><input type="text" name="accompanying_material" class="form-control" value="<?= htmlspecialchars($editBook['accompanying_material']??'') ?>"></div>
                        </div></div>
                        <div class="tab-pane fade" id="editTabDigital"><div class="row g-3 mt-2">
                            <div class="col-md-12"><label>Cover Image</label><input type="file" name="book_cover" class="form-control" accept="image/*" onchange="previewCover(this)"><div id="coverPreview" class="mt-2" style="display:none;"><img id="coverImg" style="height:100px;"></div><?php if($editBook['cover_path']): $editCoverBase64 = getBookCoverBase64($editBook['cover_path']); ?><div class="mt-2"><?php if($editCoverBase64): ?><img src="<?= $editCoverBase64 ?>" style="height:80px;border-radius:4px;"><?php else: ?><img src="<?= getWebImageUrl($editBook['cover_path']) ?>" style="height:80px;border-radius:4px;" onerror="this.onerror=null;this.style.display='none';"><?php endif; ?><input type="hidden" name="existing_cover" value="<?= htmlspecialchars($editBook['cover_path']) ?>"></div><?php endif; ?></div>
                            <div class="col-md-12"><label>eBook URL</label><input type="url" name="ebook_url" class="form-control" value="<?= htmlspecialchars($editBook['ebook_url']??'') ?>"></div>
                            <div class="col-md-12"><label>Summary</label><textarea name="summary" class="form-control" rows="3"><?= htmlspecialchars($editBook['summary']??'') ?></textarea></div>
                            <div class="col-md-12"><label>Contents</label><textarea name="contents" class="form-control" rows="3"><?= htmlspecialchars($editBook['contents']??'') ?></textarea></div>
                            <div class="col-md-6"><label>Illustrations</label><input type="text" name="illustrations" class="form-control" value="<?= htmlspecialchars($editBook['illustrations']??'') ?>"></div>
                            <div class="col-md-6"><label>Dimensions</label><input type="text" name="dimensions" class="form-control" value="<?= htmlspecialchars($editBook['dimensions']??'') ?>"></div>
                            <div class="col-md-4"><label>Material Type</label><input type="text" name="material_type" class="form-control" value="<?= htmlspecialchars($editBook['material_type']??'') ?>"></div>
                            <div class="col-md-4"><label>Size</label><input type="text" name="size" class="form-control" value="<?= htmlspecialchars($editBook['size']??'') ?>"></div>
                            <div class="col-md-4"><label>Weight</label><input type="text" name="weight" class="form-control" value="<?= htmlspecialchars($editBook['weight']??'') ?>"></div>
                            <div class="col-md-12"><label>Remarks</label><input type="text" name="remarks" class="form-control" value="<?= htmlspecialchars($editBook['remarks']??'') ?>"></div>
                        </div></div>
                    </div>
                    <?php else: ?>
                    <!-- Easy mode edit -->
                    <div class="row g-3">
                        <div class="col-md-6"><label>Date of Entry</label><input type="text" class="form-control" value="<?= date('d-m-Y', strtotime($editBook['date_of_entry'] ?? $editBook['created_at'] ?? 'now')) ?>" readonly disabled></div>
                        <div class="col-md-6"><label>Barcode</label><input type="text" name="barcode" class="form-control" value="<?= htmlspecialchars($editBook['barcode']) ?>" readonly></div>
                        <div class="col-md-12"><label>Call Number</label><input type="text" name="call_number" class="form-control" value="<?= htmlspecialchars($editBook['call_number']??'') ?>"></div>
                        <div class="col-md-12"><label>Title</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($editBook['title']) ?>" required></div>
                        <div class="col-md-6"><label>Subtitle</label><input type="text" name="sub_title" class="form-control" value="<?= htmlspecialchars($editBook['sub_title']??'') ?>"></div>
                        <div class="col-md-6"><label>Author</label><input type="text" name="author" class="form-control" value="<?= htmlspecialchars($editBook['author']??'') ?>"></div>
                        <div class="col-md-4"><label>Publisher</label><input type="text" name="publisher" class="form-control" value="<?= htmlspecialchars($editBook['publisher']??'') ?>"></div>
                        <div class="col-md-2"><label>Year</label><input type="text" name="year" class="form-control" value="<?= htmlspecialchars($editBook['year']??'') ?>"></div>
                        <div class="col-md-2"><label>Pages</label><input type="number" name="pages" class="form-control" value="<?= $editBook['pages']??0 ?>"></div>
                        <div class="col-md-4"><label>Language</label><input type="text" name="language" class="form-control" value="<?= htmlspecialchars($editBook['language']??'English') ?>"></div>
                        <div class="col-md-12"><label>Subjects</label><input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($editBook['subject']??'') ?>"></div>
                        <div class="col-md-12"><label>Summary</label><textarea name="summary" class="form-control" rows="2"><?= htmlspecialchars($editBook['summary']??'') ?></textarea></div>
                        <div class="col-md-3"><label>Classification</label><input type="text" name="classification" class="form-control" value="<?= htmlspecialchars($editBook['ddc']??$editBook['lcc']??'') ?>"></div>
                        <div class="col-md-3"><label>Quantity</label><input type="number" name="quantity" class="form-control" value="<?= $editBook['quantity'] ?>"></div>
                        <div class="col-md-3"><label>Available</label><input type="number" name="available" class="form-control" value="<?= $editBook['available'] ?>"></div>
                        <div class="col-md-3"><label>Price</label><input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($editBook['price']??'') ?>"></div>
                        <div class="col-md-3">
                            <label>Currency</label>
                            <select name="price_currency" class="form-select currency-select">
                                <?php foreach($allCurrencies as $code => $label): ?>
                                    <option value="<?= $code ?>" <?= ($editBook['price_currency'] ?? 'INR') == $code ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12"><label>Cover Image</label><input type="file" name="book_cover" class="form-control" accept="image/*" onchange="previewCover(this)"><div id="coverPreview" class="mt-2" style="display:none;"><img id="coverImg" style="height:100px;"></div><?php if($editBook['cover_path']): $editCoverBase64 = getBookCoverBase64($editBook['cover_path']); ?><div class="mt-2"><?php if($editCoverBase64): ?><img src="<?= $editCoverBase64 ?>" style="height:80px;border-radius:4px;"><?php else: ?><img src="<?= getWebImageUrl($editBook['cover_path']) ?>" style="height:80px;border-radius:4px;" onerror="this.onerror=null;this.style.display='none';"><?php endif; ?><input type="hidden" name="existing_cover" value="<?= htmlspecialchars($editBook['cover_path']) ?>"></div><?php endif; ?></div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="submit" name="update_book" class="btn btn-primary">Update Book</button>
                    <a href="books.php?mode=<?= $mode ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Barcode Modal -->
<div class="modal fade" id="barcodeModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content"><div class="modal-body text-center"><svg id="barcodeSvg"></svg><p id="barcodeText"></p></div><div class="modal-footer"><button class="btn btn-primary" onclick="printBarcode()"><i class="fas fa-print"></i> Print</button></div></div></div></div>

<!-- All Sources Modal -->
<div class="modal fade" id="allSourcesModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header bg-info text-white sticky-top"><h5>Results from All Sources</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body" id="allSourcesResults" style="max-height: 70vh; overflow-y: auto;"></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div></div></div></div>

<!-- Export Selection Modal -->
<div class="modal fade" id="exportSelectionModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header bg-success text-white"><h5>Export Options</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body">
    <div class="mb-3">
        <label class="form-label">Select Books to Export</label>
        <select id="exportBookSelect" class="form-select" size="6" multiple>
            <option value="all" selected>All Books</option>
            <?php foreach($db->query("SELECT id, barcode, title FROM books ORDER BY title LIMIT 200") as $b): ?>
            <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['barcode']) ?> - <?= htmlspecialchars(substr($b['title'],0,40)) ?></option>
            <?php endforeach; ?>
        </select>
        <small class="text-muted">Hold Ctrl/Cmd to select multiple books. "All Books" exports everything.</small>
    </div>
    <div class="row g-2">
        <div class="col-6"><button class="btn btn-outline-primary w-100" onclick="doExport('csv','copies')"><i class="fas fa-file-csv"></i> CSV (Copies)</button></div>
        <div class="col-6"><button class="btn btn-outline-primary w-100" onclick="doExport('csv','titles')"><i class="fas fa-file-csv"></i> CSV (Titles)</button></div>
        <?php if ($excelAvailable): ?>
        <div class="col-6"><button class="btn btn-outline-success w-100" onclick="doExport('excel','copies')"><i class="fas fa-file-excel"></i> Excel (Copies)</button></div>
        <div class="col-6"><button class="btn btn-outline-success w-100" onclick="doExport('excel','titles')"><i class="fas fa-file-excel"></i> Excel (Titles)</button></div>
        <?php endif; ?>
        <?php if ($pdfAvailable): ?>
        <div class="col-6"><button class="btn btn-outline-danger w-100" onclick="doExport('pdf','copies')"><i class="fas fa-file-pdf"></i> PDF (Copies)</button></div>
        <div class="col-6"><button class="btn btn-outline-danger w-100" onclick="doExport('pdf','titles')"><i class="fas fa-file-pdf"></i> PDF (Titles)</button></div>
        <?php endif; ?>
        <?php if ($marcAvailable): ?>
        <div class="col-12 mt-2"><hr></div>
        <div class="col-6"><button class="btn btn-outline-dark w-100" onclick="doExport('marc','mrc')"><i class="fas fa-book"></i> MARC (.mrc)</button></div>
        <div class="col-6"><button class="btn btn-outline-dark w-100" onclick="doExport('marc','xml')"><i class="fas fa-file-code"></i> MARCXML (.xml)</button></div>
        <?php endif; ?>
    </div>
</div></div></div></div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
$(document).ready(function() { 
    $('.select2').select2({ theme: 'bootstrap-5', width: '100%', allowClear: true }); 
});

// ==================== CUSTOM EXPORT DROPDOWN TOGGLE ====================
function toggleExportDropdown(e) {
    e.preventDefault();
    var menu = document.getElementById('exportDropdownMenu');
    if (menu.classList.contains('show')) {
        menu.classList.remove('show');
    } else {
        menu.classList.add('show');
    }
}
document.addEventListener('click', function(event) {
    var dropdown = document.querySelector('.export-dropdown');
    var menu = document.getElementById('exportDropdownMenu');
    if (!dropdown.contains(event.target)) {
        menu.classList.remove('show');
    }
});

// ==================== CALL NUMBER GENERATION ====================

function generateCallNumberField() {
    var classification = '';
    var ddc = document.getElementById('ddc');
    var lcc = document.getElementById('lcc');
    var cc = document.getElementById('cc');
    var otherClass = document.getElementById('other_classification');
    
    if (ddc && ddc.value && ddc.value !== 'Other') {
        classification = ddc.value;
    } else if (lcc && lcc.value && lcc.value !== 'Other') {
        classification = lcc.value;
    } else if (cc && cc.value) {
        classification = cc.value;
    } else if (otherClass && otherClass.value) {
        classification = otherClass.value;
    }
    
    if (ddc && ddc.value === 'Other') {
        var ddcOther = document.querySelector('input[name="ddc_other"]');
        if (ddcOther && ddcOther.value) classification = ddcOther.value;
    }
    if (lcc && lcc.value === 'Other') {
        var lccOther = document.querySelector('input[name="lcc_other"]');
        if (lccOther && lccOther.value) classification = lccOther.value;
    }
    
    var author = document.getElementById('author') ? document.getElementById('author').value : '';
    var title = document.getElementById('title') ? document.getElementById('title').value : '';
    
    var titleClean = title.replace(/^(the|a|an)\s+/i, '').trim();
    var titleInitial = titleClean.length > 0 ? titleClean.charAt(0).toUpperCase() : 'X';
    
    var authorClean = author.replace(/[^a-zA-Z]/g, '');
    var authorInitials = 'XXX';
    if (authorClean.length >= 3) {
        var authorParts = author.split(' ');
        var lastName = authorParts[authorParts.length - 1];
        var lastNameClean = lastName.replace(/[^a-zA-Z]/g, '');
        if (lastNameClean.length >= 3) {
            authorInitials = lastNameClean.substring(0, 3).toUpperCase();
        } else {
            authorInitials = authorClean.substring(0, 3).toUpperCase();
            while (authorInitials.length < 3) authorInitials += 'X';
        }
    } else if (authorClean.length > 0) {
        authorInitials = authorClean.toUpperCase();
        while (authorInitials.length < 3) authorInitials += 'X';
    }
    
    var callNumber = '';
    if (classification && authorInitials !== 'XXX') {
        callNumber = classification + ' (' + authorInitials + ' / ' + titleInitial + ')';
    } else if (classification) {
        callNumber = classification + ' (XXX / ' + titleInitial + ')';
    }
    
    var callNumberField = document.getElementById('call_number');
    if (callNumberField) {
        callNumberField.value = callNumber;
    }
}

function generateEasyCallNumber() {
    var classification = document.getElementById('easyClassification') ? document.getElementById('easyClassification').value : '';
    var author = document.getElementById('easyAuthor') ? document.getElementById('easyAuthor').value : '';
    var title = document.getElementById('easyTitle') ? document.getElementById('easyTitle').value : '';
    
    var titleClean = title.replace(/^(the|a|an)\s+/i, '').trim();
    var titleInitial = titleClean.length > 0 ? titleClean.charAt(0).toUpperCase() : 'X';
    
    var authorClean = author.replace(/[^a-zA-Z]/g, '');
    var authorInitials = 'XXX';
    if (authorClean.length >= 3) {
        var authorParts = author.split(' ');
        var lastName = authorParts[authorParts.length - 1];
        var lastNameClean = lastName.replace(/[^a-zA-Z]/g, '');
        if (lastNameClean.length >= 3) {
            authorInitials = lastNameClean.substring(0, 3).toUpperCase();
        } else {
            authorInitials = authorClean.substring(0, 3).toUpperCase();
            while (authorInitials.length < 3) authorInitials += 'X';
        }
    } else if (authorClean.length > 0) {
        authorInitials = authorClean.toUpperCase();
        while (authorInitials.length < 3) authorInitials += 'X';
    }
    
    var callNumber = '';
    if (classification && authorInitials !== 'XXX') {
        callNumber = classification + ' (' + authorInitials + ' / ' + titleInitial + ')';
    } else if (classification) {
        callNumber = classification + ' (XXX / ' + titleInitial + ')';
    }
    
    var callField = document.getElementById('easy_call_number');
    if (callField) {
        callField.value = callNumber;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    var fields = ['author', 'title', 'ddc', 'lcc', 'cc', 'other_classification'];
    fields.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', generateCallNumberField);
            el.addEventListener('keyup', generateCallNumberField);
        }
    });
    
    var easyFields = ['easyAuthor', 'easyTitle', 'easyClassification'];
    easyFields.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', generateEasyCallNumber);
            el.addEventListener('keyup', generateEasyCallNumber);
        }
    });
    
    generateCallNumberField();
    generateEasyCallNumber();
});

// ==================== ENHANCED EXPORT FUNCTIONS ====================

function exportBooks(type, mode) {
    let modal = new bootstrap.Modal(document.getElementById('exportSelectionModal'));
    modal.show();
}

function doExport(type, mode) {
    let select = document.getElementById('exportBookSelect');
    let ids = [];
    for (let opt of select.options) {
        if (opt.selected && opt.value !== 'all') ids.push(opt.value);
    }
    
    let url = '';
    if (type === 'marc') {
        url = '?export_marc=1&format=' + mode;
    } else {
        url = '?export=' + type + '&export_mode=' + mode;
    }
    
    if (ids.length > 0) {
        url += '&ids=' + ids.join(',');
    }
    window.location.href = url;
}

// ==================== ENHANCED ISBN FETCH WITH AUTO COVER ====================

function fetchFromSelectedSource(autoDownloadCover) {
    let isbn = document.getElementById('isbn').value.trim();
    let barcode = document.getElementById('barcode').value.trim() || 'temp_' + Date.now();
    if (!isbn) { showToast('Enter ISBN', 'warning'); return; }
    let source = document.getElementById('fetchSourceSelect').value;
    let statusDiv = document.getElementById('apiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching metadata...';
    
    fetch(`books.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}&source=${source}&barcode=${encodeURIComponent(barcode)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let b = data.data;
                document.getElementById('title').value = b.title || '';
                document.getElementById('sub_title').value = b.subtitle || '';
                document.getElementById('author').value = b.author || '';
                document.getElementById('publisher').value = b.publisher || '';
                document.getElementById('year').value = b.year || '';
                document.getElementById('subject').value = b.subject || '';
                document.getElementById('summary').value = b.summary || '';
                document.getElementById('language').value = b.language || 'English';
                document.getElementById('pages').value = b.pages || '';
                document.getElementById('cover_url_hidden').value = b.cover_url || '';
                
                generateCallNumberField();
                
                // Auto download and display cover
                let preview = document.getElementById('coverPreview');
                let img = document.getElementById('coverImg');
                
                if (b.cover_path) {
                    let webUrl = getWebImageUrl(b.cover_path);
                    img.src = webUrl;
                    preview.style.display = 'block';
                    document.getElementById('pre_downloaded_cover').value = b.cover_path;
                    statusDiv.innerHTML = `<span class="text-success">Fetched from ${b.source} with cover downloaded.</span>`;
                } else if (b.cover_url) {
                    img.src = b.cover_url;
                    preview.style.display = 'block';
                    
                    if (autoDownloadCover) {
                        statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Downloading cover...';
                        fetch(`books.php?ajax_download_cover=1&url=${encodeURIComponent(b.cover_url)}&barcode=${encodeURIComponent(barcode)}`)
                            .then(res => res.json())
                            .then(dlData => {
                                if (dlData.success) {
                                    document.getElementById('pre_downloaded_cover').value = dlData.path;
                                    img.src = dlData.webUrl;
                                    statusDiv.innerHTML = `<span class="text-success">Fetched from ${b.source} & cover saved.</span>`;
                                } else {
                                    statusDiv.innerHTML = `<span class="text-warning">Fetched from ${b.source}, cover download failed.</span>`;
                                }
                            })
                            .catch(() => statusDiv.innerHTML = `<span class="text-warning">Fetched from ${b.source}, cover download error.</span>`);
                    } else {
                        statusDiv.innerHTML = `<span class="text-success">Fetched from ${b.source}</span>`;
                    }
                } else {
                    statusDiv.innerHTML = `<span class="text-success">Fetched from ${b.source} (no cover)</span>`;
                }
                showToast(`Fetched from ${b.source}`, 'success');
            } else {
                statusDiv.innerHTML = `<span class="text-danger">${data.error || 'Unknown error'}</span>`;
                showToast(`Error: ${data.error}`, 'danger');
            }
        })
        .catch(err => { console.error(err); statusDiv.innerHTML = '<span class="text-danger">Network error</span>'; showToast('Network error', 'danger'); });
}

function fetchFromAllSources() {
    let isbn = document.getElementById('isbn').value.trim();
    let barcode = document.getElementById('barcode').value.trim() || 'temp_' + Date.now();
    if (!isbn) { showToast('Enter ISBN', 'warning'); return; }
    let statusDiv = document.getElementById('apiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching all sources...';
    
    fetch(`books.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}&barcode=${encodeURIComponent(barcode)}`)
        .then(r => r.json())
        .then(data => {
            statusDiv.innerHTML = '';
            if (data.success && data.results && data.results.length) {
                let html = '<div class="row g-3">';
                data.results.forEach(r => {
                    const safeData = {
                        title: r.title || '', subtitle: r.subtitle || '', author: r.author || '',
                        publisher: r.publisher || '', year: r.year || '', pages: r.pages || '',
                        summary: r.summary || '', subject: r.subject || '', cover_url: r.cover_url || '',
                        cover_path: r.cover_path || '', source: r.source_display || r.source || 'Unknown'
                    };
                    html += `<div class="col-md-6 mb-3">
                        <div class="card h-100 result-card">
                            <div class="card-header bg-light"><strong><i class="fas fa-${safeData.source === 'Google Books' ? 'google' : 'book'}"></i> ${escapeHtml(safeData.source)}</strong></div>
                            <div class="card-body">
                                <h6 class="card-title">${escapeHtml(safeData.title || 'No title')}</h6>
                                <p class="small mb-1"><strong>Author:</strong> ${escapeHtml(safeData.author || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Publisher:</strong> ${escapeHtml(safeData.publisher || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Year:</strong> ${escapeHtml(safeData.year || 'N/A')}</p>
                                <p class="small mb-1"><strong>Subject:</strong> ${escapeHtml(safeData.subject || 'N/A')}</p>
                                ${safeData.cover_path ? '<img src="'+getWebImageUrl(safeData.cover_path)+'" style="max-height:60px; max-width:100%; object-fit:contain; margin:5px 0; border-radius:4px;">' : ''}
                                <button class="btn btn-sm btn-primary mt-2" onclick=\'applySourceData(${JSON.stringify(safeData)})\'><i class="fas fa-check"></i> Use This</button>
                            </div>
                        </div>
                    </div>`;
                });
                html += '</div>';
                document.getElementById('allSourcesResults').innerHTML = html;
                new bootstrap.Modal(document.getElementById('allSourcesModal')).show();
            } else {
                statusDiv.innerHTML = '<span class="text-warning">No data from any source</span>';
            }
        })
        .catch(err => { console.error(err); statusDiv.innerHTML = '<span class="text-danger">Error</span>'; });
}

function applySourceData(data) {
    document.getElementById('title').value = data.title || '';
    document.getElementById('sub_title').value = data.subtitle || '';
    document.getElementById('author').value = data.author || '';
    document.getElementById('publisher').value = data.publisher || '';
    document.getElementById('year').value = data.year || '';
    document.getElementById('subject').value = data.subject || '';
    document.getElementById('summary').value = data.summary || '';
    document.getElementById('pages').value = data.pages || '';
    document.getElementById('cover_url_hidden').value = data.cover_url || '';
    
    generateCallNumberField();
    
    let preview = document.getElementById('coverPreview');
    let img = document.getElementById('coverImg');
    if (data.cover_path) {
        img.src = getWebImageUrl(data.cover_path);
        preview.style.display = 'block';
        document.getElementById('pre_downloaded_cover').value = data.cover_path;
    } else if (data.cover_url) {
        img.src = data.cover_url;
        preview.style.display = 'block';
        let barcode = document.getElementById('barcode').value.trim() || 'temp_' + Date.now();
        fetch(`books.php?ajax_download_cover=1&url=${encodeURIComponent(data.cover_url)}&barcode=${encodeURIComponent(barcode)}`)
            .then(res => res.json())
            .then(dlData => {
                if (dlData.success) {
                    document.getElementById('pre_downloaded_cover').value = dlData.path;
                    img.src = dlData.webUrl;
                }
            })
            .catch(err => console.error("Cover download error:", err));
    } else {
        preview.style.display = 'none';
    }
    let modal = bootstrap.Modal.getInstance(document.getElementById('allSourcesModal'));
    if (modal) modal.hide();
    showToast(`Applied data from ${data.source}`, 'success');
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]);
}

function getWebImageUrl(path) {
    if (!path) return '';
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    if (path.startsWith('/')) return path;
    return '/' + path;
}

// ==================== EASY MODE FETCH WITH AUTO COVER ====================

function fetchEasyMetadata() {
    let isbn = document.getElementById('easyIsbn').value.trim();
    let barcode = document.getElementById('barcode').value.trim() || 'temp_' + Date.now();
    if (isbn.length < 10) {
        document.getElementById('easyFetchStatus').innerHTML = '<span class="text-warning">Enter at least 10 digits</span>';
        return;
    }
    let statusDiv = document.getElementById('easyFetchStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching metadata...';
    
    fetch(`books.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}&source=auto&barcode=${encodeURIComponent(barcode)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let b = data.data;
                document.getElementById('easyTitle').value = b.title || '';
                document.getElementById('easySubtitle').value = b.subtitle || '';
                document.getElementById('easyAuthor').value = b.author || '';
                document.getElementById('easyPublisher').value = b.publisher || '';
                document.getElementById('easyYear').value = b.year || '';
                document.getElementById('easyPages').value = b.pages || '';
                document.getElementById('easySubject').value = b.subject || '';
                document.getElementById('easySummary').value = b.summary || '';
                
                generateEasyCallNumber();
                
                let previewDiv = document.getElementById('easyCoverPreview');
                let previewImg = document.getElementById('easyCoverImg');
                
                if (b.cover_path) {
                    previewImg.src = getWebImageUrl(b.cover_path);
                    previewDiv.style.display = 'block';
                    document.getElementById('easyPreDownloadedCover').value = b.cover_path;
                    statusDiv.innerHTML = '<span class="text-success">Fetched with cover downloaded.</span>';
                } else if (b.cover_url) {
                    previewImg.src = b.cover_url;
                    previewDiv.style.display = 'block';
                    fetch(`books.php?ajax_download_cover=1&url=${encodeURIComponent(b.cover_url)}&barcode=${encodeURIComponent(barcode)}`)
                        .then(res => res.json())
                        .then(dlData => {
                            if (dlData.success) {
                                document.getElementById('easyPreDownloadedCover').value = dlData.path;
                                previewImg.src = dlData.webUrl;
                            }
                        })
                        .catch(err => console.error("Cover download error", err));
                    statusDiv.innerHTML = '<span class="text-success">Fetched from ' + (b.source || 'external source') + '</span>';
                } else {
                    statusDiv.innerHTML = '<span class="text-success">Fetched from ' + (b.source || 'external source') + '</span>';
                }
            } else {
                statusDiv.innerHTML = '<span class="text-danger">' + (data.error || 'Not found') + '</span>';
            }
        })
        .catch(err => {
            console.error(err);
            statusDiv.innerHTML = '<span class="text-danger">Network error</span>';
        });
}

function fetchForEdit() {
    let isbn = document.getElementById('edit_isbn').value.trim();
    if (isbn.length < 10) return;
    let statusDiv = document.getElementById('editApiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching...';
    
    fetch(`books.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}&source=auto`)
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let b = data.data;
                document.querySelector('input[name="title"]').value = b.title || '';
                document.querySelector('input[name="author"]').value = b.author || '';
                document.querySelector('input[name="publisher"]').value = b.publisher || '';
                document.querySelector('input[name="year"]').value = b.year || '';
                document.querySelector('input[name="pages"]').value = b.pages || '';
                document.querySelector('textarea[name="summary"]').value = b.summary || '';
                document.querySelector('input[name="subject"]').value = b.subject || '';
                if (b.cover_path) {
                    let preview = document.getElementById('coverPreview');
                    let img = document.getElementById('coverImg');
                    img.src = getWebImageUrl(b.cover_path);
                    preview.style.display = 'block';
                    document.querySelector('input[name="pre_downloaded_cover"]').value = b.cover_path;
                }
                statusDiv.innerHTML = '<span class="text-success">Fetched from ' + b.source + '</span>';
            } else {
                statusDiv.innerHTML = '<span class="text-danger">' + data.error + '</span>';
            }
        })
        .catch(() => statusDiv.innerHTML = '<span class="text-danger">Error</span>');
}

// ==================== UI HELPERS ====================

function showToast(msg, type) {
    let div = document.createElement('div');
    div.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3 z-3`;
    div.innerHTML = msg;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 4000);
}

function previewCover(input) {
    let preview = document.getElementById('coverPreview');
    let img = document.getElementById('coverImg');
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = e => { img.src = e.target.result; preview.style.display = 'block'; };
        reader.readAsDataURL(input.files[0]);
    } else preview.style.display = 'none';
}

function previewEasyCover(input) {
    let preview = document.getElementById('easyCoverPreview');
    let img = document.getElementById('easyCoverImg');
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = e => { img.src = e.target.result; preview.style.display = 'block'; };
        reader.readAsDataURL(input.files[0]);
    } else preview.style.display = 'none';
}

function generateBookBarcode(barcode, title) {
    let modal = new bootstrap.Modal(document.getElementById('barcodeModal'));
    JsBarcode(document.getElementById('barcodeSvg'), barcode, { format: 'CODE128', width: 2, height: 50, displayValue: true });
    document.getElementById('barcodeText').innerHTML = barcode + ' - ' + title.substring(0, 30);
    modal.show();
}

function printBarcode() {
    let w = window.open('', '_blank');
    w.document.write('<html><head><title>Barcode</title></head><body style="text-align:center;">' + 
        document.getElementById('barcodeSvg').outerHTML + 
        '<p>' + document.getElementById('barcodeText').innerHTML + '</p>' +
        '<script>window.onload=function(){window.print();window.close();}<\/script></body></html>');
    w.document.close();
}

function filterByStatus(s) {
    let url = new URL(window.location.href);
    if (s) url.searchParams.set('status', s);
    else url.searchParams.delete('status');
    window.location.href = url.toString();
}

function toggleFilterPanel() {
    let card = document.getElementById('filterCard');
    let body = document.getElementById('filterBody');
    if (card.classList.contains('collapsed')) {
        body.style.display = 'block';
        card.classList.remove('collapsed');
        localStorage.setItem('filterPanelCollapsed', 'false');
    } else {
        body.style.display = 'none';
        card.classList.add('collapsed');
        localStorage.setItem('filterPanelCollapsed', 'true');
    }
}

let isCollapsed = localStorage.getItem('filterPanelCollapsed') === 'true';
if (isCollapsed) {
    document.getElementById('filterBody').style.display = 'none';
    document.getElementById('filterCard').classList.add('collapsed');
} else {
    document.getElementById('filterBody').style.display = 'block';
    document.getElementById('filterCard').classList.remove('collapsed');
}

// ==================== ISBN AUTO-FETCH ON BLUR ====================

let isbnInput = document.getElementById('isbn');
if (isbnInput) {
    isbnInput.addEventListener('blur', function() {
        let isbn = this.value.trim();
        if (isbn.length >= 10) setTimeout(() => fetchFromSelectedSource(true), 300);
    });
}

// ==================== CLASSIFICATION DROPDOWN ====================

$('.classification-select').on('change', function() {
    let $select = $(this);
    let $otherInput = $select.closest('.col-md-3').find('input[type="text"]');
    if ($select.val() === 'Other') {
        $otherInput.show();
    } else {
        $otherInput.hide();
        $otherInput.val('');
    }
    generateCallNumberField();
});
$('.classification-select').trigger('change');

// ==================== AUTO BARCODE ====================

<?php if ($mode == 'full'): ?>
let autoBarcodeToggle = document.getElementById('autoBarcodeToggle');
let barcodeField = document.getElementById('barcode');
if (autoBarcodeToggle && barcodeField) {
    autoBarcodeToggle.addEventListener('change', function() {
        if (this.checked && !barcodeField.value.trim()) {
            barcodeField.value = 'LIB' + Date.now();
        }
    });
    barcodeField.addEventListener('blur', function() {
        if (autoBarcodeToggle.checked && !this.value.trim()) {
            this.value = 'LIB' + Date.now();
        }
    });
}
<?php endif; ?>

// ==================== BULK IMPORT PROGRESS ====================

document.getElementById('bulkImportForm')?.addEventListener('submit', function(e) {
    let btn = document.getElementById('bulkImportBtn');
    let progressDiv = document.getElementById('importProgress');
    btn.disabled = true;
    progressDiv.style.display = 'block';
    let percent = 0;
    let interval = setInterval(() => {
        percent += 10;
        if (percent >= 90) clearInterval(interval);
        let pb = document.querySelector('#importProgress .progress-bar');
        if (pb) { pb.style.width = percent + '%'; pb.innerText = percent + '%'; }
    }, 500);
});

// ==================== SAMPLE CSV DOWNLOAD ====================

document.getElementById('downloadSampleCsv')?.addEventListener('click', function(e) {
    e.preventDefault();
    let csv = "barcode,title,sub_title,author,author2,collaborator,subject,isbn,publisher,maintenance,current_location,section,book_status,cover_url\nBK001,Sample Book,A Critical Introduction,John Doe,Jane Smith,Edited by M. Lee,Computer Science,9781234567890,Tech Press,Hardcover,Main Library,General,Available,\n";
    let blob = new Blob([csv], { type: 'text/csv' });
    let a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'sample_books.csv';
    a.click();
    URL.revokeObjectURL(a.href);
});

// ==================== MODAL SCROLLING FIX ====================
document.addEventListener('DOMContentLoaded', function() {
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        modal.addEventListener('shown.bs.modal', function() {
            document.body.style.overflow = 'hidden';
        });
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.style.overflow = '';
        });
    });
});
</script>
<?php renderFooter(); ?>