<?php
/**
 * API: Advanced Metadata Fetch from Multiple Sources
 * 
 * Endpoints:
 *   GET ?action=fetch&isbn=...&source=auto/google/openlibrary/isbndb/worldcat/z3950
 *   GET ?action=fetch_all_sources&isbn=...
 *   GET ?action=download_cover&url=...&barcode=...
 * 
 * Returns JSON.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Only allow admin access (optional, but safe)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = getDB();
$settings = getSettings();

// Helper: GET request with cURL
function curlGet($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Library-ERP/1.0');
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code === 200) ? $data : false;
}

// Google Books
function fetchGoogleBooks($isbn) {
    $json = curlGet("https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn");
    if (!$json) return null;
    $data = json_decode($json, true);
    if (empty($data['items'])) return null;
    $info = $data['items'][0]['volumeInfo'];
    return [
        'title'     => $info['title'] ?? '',
        'subtitle'  => $info['subtitle'] ?? '',
        'author'    => isset($info['authors']) ? implode(', ', $info['authors']) : '',
        'publisher' => $info['publisher'] ?? '',
        'year'      => substr($info['publishedDate'] ?? '', 0, 4),
        'pages'     => $info['pageCount'] ?? 0,
        'isbn'      => $isbn,
        'summary'   => $info['description'] ?? '',
        'subject'   => isset($info['categories']) ? implode(', ', $info['categories']) : '',
        'language'  => $info['language'] ?? '',
        'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
        'source'    => 'Google Books'
    ];
}

// OpenLibrary
function fetchOpenLibrary($isbn) {
    $json = curlGet("https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data");
    if (!$json) return null;
    $data = json_decode($json, true);
    $key = "ISBN:$isbn";
    if (!isset($data[$key])) return null;
    $book = $data[$key];
    return [
        'title'     => $book['title'] ?? '',
        'subtitle'  => $book['subtitle'] ?? '',
        'author'    => isset($book['authors']) ? implode(', ', array_column($book['authors'], 'name')) : '',
        'publisher' => $book['publishers'][0]['name'] ?? '',
        'year'      => preg_replace('/[^0-9]/', '', $book['publish_date'] ?? ''),
        'pages'     => $book['number_of_pages'] ?? 0,
        'isbn'      => $isbn,
        'summary'   => $book['notes'] ?? ($book['description'] ?? ''),
        'subject'   => isset($book['subjects']) ? implode(', ', array_slice($book['subjects'], 0, 3)) : '',
        'language'  => $book['languages'][0]['name'] ?? '',
        'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
        'source'    => 'OpenLibrary'
    ];
}

// ISBNdb (requires API key)
function fetchISBNdb($isbn, $apiKey) {
    if (!$apiKey) return null;
    $ch = curl_init("https://api2.isbndb.com/book/{$isbn}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: $apiKey"]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $json = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code !== 200 || !$json) return null;
    $data = json_decode($json, true);
    if (!isset($data['book'])) return null;
    $b = $data['book'];
    return [
        'title'     => $b['title'] ?? '',
        'subtitle'  => $b['title_long'] ?? '',
        'author'    => isset($b['authors']) ? implode(', ', $b['authors']) : '',
        'publisher' => $b['publisher'] ?? '',
        'year'      => substr($b['date_published'] ?? '', 0, 4),
        'pages'     => $b['pages'] ?? 0,
        'isbn'      => $isbn,
        'summary'   => $b['synopsis'] ?? '',
        'subject'   => isset($b['subjects']) ? implode(', ', $b['subjects']) : '',
        'language'  => $b['language'] ?? '',
        'cover_url' => $b['image'] ?? '',
        'source'    => 'ISBNdb'
    ];
}

// WorldCat (requires API key)
function fetchWorldCat($isbn, $apiKey) {
    if (!$apiKey) return null;
    $json = curlGet("https://search.worldcat.org/search?q=isbn:{$isbn}&format=json");
    if (!$json) return null;
    $data = json_decode($json, true);
    if (empty($data['records'])) return null;
    $r = $data['records'][0];
    return [
        'title'     => $r['title'] ?? '',
        'subtitle'  => '',
        'author'    => $r['author'] ?? '',
        'publisher' => $r['publisher'] ?? '',
        'year'      => substr($r['date'] ?? '', 0, 4),
        'pages'     => $r['physicalExtent'] ?? 0,
        'isbn'      => $isbn,
        'summary'   => $r['description'] ?? '',
        'subject'   => $r['subject'] ?? '',
        'language'  => $r['language'] ?? '',
        'cover_url' => '',
        'source'    => 'WorldCat'
    ];
}

// Z39.50 targets
$z39Targets = [
    'loc' => ['name' => 'Library of Congress', 'host' => 'z3950.loc.gov', 'port' => 7090, 'db' => 'voyager', 'syntax' => 'usmarc', 'attr' => 7],
    'nlm' => ['name' => 'National Library of Medicine', 'host' => 'locate.nlm.nih.gov', 'port' => 210, 'db' => 'NLM', 'syntax' => 'usmarc', 'attr' => 7],
    'dnb' => ['name' => 'Deutsche Nationalbibliothek', 'host' => 'z3950.dnb.de', 'port' => 2020, 'db' => 'DNB', 'syntax' => 'usmarc', 'attr' => 7],
];
function fetchZ3950($isbn) {
    global $z39Targets;
    if (!function_exists('yaz_connect')) return null;
    foreach ($z39Targets as $t) {
        $conn = @yaz_connect($t['host'] . ':' . $t['port'] . '/' . $t['db']);
        if (!$conn) continue;
        yaz_syntax($conn, $t['syntax']);
        yaz_search($conn, 'rpn', '@attr 1=' . $t['attr'] . ' "' . yaz_escape($isbn) . '"');
        yaz_wait();
        if (!yaz_error($conn) && yaz_hits($conn) > 0) {
            $rec = yaz_record($conn, 1, 'string');
            if ($rec) {
                // Attempt to parse MARC for basic fields
                $data = ['source' => $t['name'], 'cover_url' => ''];
                if (preg_match('/245.{0,10}([^|]+)/', $rec, $m)) $data['title'] = trim($m[1]);
                if (preg_match('/100.{0,10}([^|]+)/', $rec, $m)) $data['author'] = trim($m[1]);
                if (preg_match('/260.{0,10}([^|]+)/', $rec, $m)) $data['publisher'] = trim($m[1]);
                if (preg_match('/260.{0,10}.{0,10}([0-9]{4})/', $rec, $m)) $data['year'] = $m[1];
                if (preg_match('/300.{0,10}([0-9]+)/', $rec, $m)) $data['pages'] = (int)$m[1];
                if (!empty($data['title'])) return $data;
            }
        }
        yaz_close($conn);
    }
    return null;
}

// Main dispatcher
$action = $_GET['action'] ?? '';
if (!$action) {
    http_response_code(400);
    echo json_encode(['error' => 'No action specified']);
    exit;
}

if ($action === 'fetch') {
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn'] ?? '');
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    $source = $_GET['source'] ?? 'auto';
    $result = null;
    if ($source === 'google') $result = fetchGoogleBooks($isbn);
    elseif ($source === 'openlibrary') $result = fetchOpenLibrary($isbn);
    elseif ($source === 'isbndb') $result = fetchISBNdb($isbn, $settings['isbndb_api_key'] ?? '');
    elseif ($source === 'worldcat') $result = fetchWorldCat($isbn, $settings['worldcat_api_key'] ?? '');
    elseif ($source === 'z3950') $result = fetchZ3950($isbn);
    else {
        // auto: try each in order
        $funcs = ['fetchGoogleBooks', 'fetchOpenLibrary'];
        if (!empty($settings['isbndb_api_key'])) $funcs[] = 'fetchISBNdb';
        if (!empty($settings['worldcat_api_key'])) $funcs[] = 'fetchWorldCat';
        if (function_exists('yaz_connect')) $funcs[] = 'fetchZ3950';
        foreach ($funcs as $f) {
            if ($f === 'fetchISBNdb') $result = $f($isbn, $settings['isbndb_api_key']);
            elseif ($f === 'fetchWorldCat') $result = $f($isbn, $settings['worldcat_api_key']);
            else $result = $f($isbn);
            if ($result) break;
        }
    }
    if ($result) {
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No metadata found from any source']);
    }
    exit;
}

if ($action === 'fetch_all_sources') {
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn'] ?? '');
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    $results = [];
    $gb = fetchGoogleBooks($isbn);
    if ($gb) { $gb['source_display'] = 'Google Books'; $results[] = $gb; }
    $ol = fetchOpenLibrary($isbn);
    if ($ol) { $ol['source_display'] = 'OpenLibrary'; $results[] = $ol; }
    if (!empty($settings['isbndb_api_key'])) {
        $isbndb = fetchISBNdb($isbn, $settings['isbndb_api_key']);
        if ($isbndb) { $isbndb['source_display'] = 'ISBNdb'; $results[] = $isbndb; }
    }
    if (!empty($settings['worldcat_api_key'])) {
        $wc = fetchWorldCat($isbn, $settings['worldcat_api_key']);
        if ($wc) { $wc['source_display'] = 'WorldCat'; $results[] = $wc; }
    }
    if (function_exists('yaz_connect')) {
        $z = fetchZ3950($isbn);
        if ($z) { $z['source_display'] = 'Z39.50'; $results[] = $z; }
    }
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

if ($action === 'download_cover') {
    $url = $_GET['url'] ?? '';
    $barcode = $_GET['barcode'] ?? 'temp';
    if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'error' => 'Invalid URL']);
        exit;
    }
    $coverPath = '';
    $ext = 'jpg';
    $path = parse_url($url, PHP_URL_PATH);
    if ($path && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $path, $m)) $ext = strtolower($m[1]);
    $filename = 'book_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $barcode) . '_' . time() . '.' . $ext;
    $target = BOOK_COVER_DIR . $filename;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $data = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($http === 200 && $data && file_put_contents($target, $data)) {
        $coverPath = 'uploads/books/' . $filename;
    }
    if ($coverPath) {
        echo json_encode(['success' => true, 'path' => $coverPath]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Download failed']);
    }
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'Invalid action']);