<?php
/**
 * Automated Notifications Manager
 * Email, SMS, WhatsApp notifications for overdue books, holds, events, etc.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// ========== Send Overdue Notifications ==========
function sendOverdueNotifications($db, $settings) {
    $stmt = $db->query("SELECT c.*, m.email, m.phone, m.name as member_name, b.title as book_title 
                        FROM circulation c 
                        LEFT JOIN members m ON c.admno = m.admno 
                        LEFT JOIN books b ON c.barcode = b.barcode 
                        WHERE c.return_date IS NULL AND c.due_date < date('now')");
    $overdue = $stmt->fetchAll();
    
    $sent = 0;
    foreach ($overdue as $book) {
        $days = (new DateTime())->diff(new DateTime($book['due_date']))->days;
        $message = "Dear {$book['member_name']},\n\nThe book \"{$book['book_title']}\" is overdue by {$days} days. Please return it immediately to avoid additional fines.\n\nThank you,\nLibrary Team";
        
        // Send Email
        if (!empty($settings['enable_email']) && !empty($book['email'])) {
            sendEmail($book['email'], "Overdue Book Notice", $message);
        }
        
        // Send SMS
        if (!empty($settings['enable_sms']) && !empty($book['phone'])) {
            sendSMS($book['phone'], $message);
        }
        
        // Send WhatsApp
        if (!empty($settings['whatsapp_notify_overdue_enabled']) && !empty($book['phone'])) {
            $whatsappMsg = str_replace(
                ['{member_name}', '{book_title}', '{days_overdue}'],
                [$book['member_name'], $book['book_title'], $days],
                $settings['whatsapp_template_overdue'] ?? $message
            );
            sendWhatsApp($book['phone'], $whatsappMsg);
        }
        
        $sent++;
    }
    
    return $sent;
}

// ========== Send Hold Ready Notifications ==========
function sendHoldReadyNotifications($db, $settings) {
    $stmt = $db->prepare("SELECT * FROM reservations_queue WHERE status = 'waiting' AND expiry_date >= date('now')");
    $stmt->execute();
    $holds = $stmt->fetchAll();
    
    $sent = 0;
    foreach ($holds as $hold) {
        $message = "Dear {$hold['member_name']},\n\nThe book is now available for pickup. Please collect it by {$hold['expiry_date']}.\n\nThank you,\nLibrary Team";
        
        $member = getMemberByAdmno($hold['admno']);
        if ($member) {
            if (!empty($settings['enable_email']) && !empty($member['email'])) {
                sendEmail($member['email'], "Hold Ready for Pickup", $message);
            }
            
            if (!empty($settings['whatsapp_notify_hold_ready_enabled']) && !empty($member['phone'])) {
                $whatsappMsg = str_replace(
                    ['{member_name}', '{expiry_date}'],
                    [$hold['member_name'], $hold['expiry_date']],
                    $settings['whatsapp_template_hold_ready'] ?? $message
                );
                sendWhatsApp($member['phone'], $whatsappMsg);
            }
        }
        
        $sent++;
    }
    
    return $sent;
}

// ========== Send Event Reminders ==========
function sendEventReminders($db, $settings) {
    $stmt = $db->prepare("SELECT * FROM library_events WHERE event_date >= date('now') AND event_date <= date('now', '+2 days') AND status = 'upcoming'");
    $stmt->execute();
    $events = $stmt->fetchAll();
    
    foreach ($events as $event) {
        // Get attendees for this event
        $attendees = $db->prepare("SELECT ea.*, m.email, m.phone FROM event_attendees ea LEFT JOIN members m ON ea.member_admno = m.admno WHERE ea.event_id = ?");
        $attendees->execute([$event['id']]);
        $attendees = $attendees->fetchAll();
        
        foreach ($attendees as $attendee) {
            $message = "Reminder: \"{$event['title']}\" is on {$event['event_date']} at {$event['start_time']} - {$event['end_time']}. Venue: {$event['venue']}";
            
            if (!empty($settings['enable_email']) && !empty($attendee['email'])) {
                sendEmail($attendee['email'], "Event Reminder: {$event['title']}", $message);
            }
            
            if (!empty($settings['whatsapp_notify_overdue_enabled']) && !empty($attendee['phone'])) {
                $whatsappMsg = str_replace(
                    ['{event_title}', '{event_date}', '{event_time}', '{venue}'],
                    [$event['title'], $event['event_date'], $event['start_time'] . ' - ' . $event['end_time'], $event['venue']],
                    $settings['whatsapp_template_event'] ?? $message
                );
                sendWhatsApp($attendee['phone'], $whatsappMsg);
            }
        }
    }
}

// ========== Run Scheduled Notifications ==========
if (isset($_GET['run'])) {
    header('Content-Type: application/json');
    $action = $_GET['run'];
    
    switch ($action) {
        case 'overdue':
            $count = sendOverdueNotifications($db, $settings);
            echo json_encode(['success' => true, 'sent' => $count, 'message' => "$count overdue notifications sent"]);
            break;
        case 'holds':
            $count = sendHoldReadyNotifications($db, $settings);
            echo json_encode(['success' => true, 'sent' => $count, 'message' => "$count hold notifications sent"]);
            break;
        case 'events':
            sendEventReminders($db, $settings);
            echo json_encode(['success' => true, 'message' => 'Event reminders sent']);
            break;
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }
    exit;
}
?>