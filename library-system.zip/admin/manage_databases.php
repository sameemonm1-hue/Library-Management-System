<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$message = '';
$error = '';

// Handle Add Database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $name = trim($_POST['name'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $type = $_POST['type'] ?? 'academic';
        $icon = trim($_POST['icon'] ?? 'database');
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $sort_order = (int)($_POST['sort_order'] ?? 999);
        
        if (empty($name) || empty($url)) {
            $error = "Name and URL are required!";
        } else {
            $stmt = $db->prepare("INSERT INTO research_databases (name, description, url, category, type, icon, is_featured, sort_order, created_at, updated_at) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
            if ($stmt->execute([$name, $description, $url, $category, $type, $icon, $is_featured, $sort_order])) {
                $message = "Database added successfully!";
            } else {
                $error = "Failed to add database.";
            }
        }
    }
    
    // Handle Delete
    if ($_POST['action'] === 'delete' && isset($_POST['id'])) {
        $stmt = $db->prepare("UPDATE research_databases SET is_active = 0, updated_at = datetime('now') WHERE id = ?");
        if ($stmt->execute([$_POST['id']])) {
            $message = "Database deleted successfully!";
        } else {
            $error = "Failed to delete database.";
        }
    }
    
    // Handle Edit
    if ($_POST['action'] === 'edit' && isset($_POST['id'])) {
        $id = (int)$_POST['id'];
        $name = trim($_POST['name'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $type = $_POST['type'] ?? 'academic';
        $icon = trim($_POST['icon'] ?? 'database');
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $sort_order = (int)($_POST['sort_order'] ?? 999);
        
        if (empty($name) || empty($url)) {
            $error = "Name and URL are required!";
        } else {
            $stmt = $db->prepare("UPDATE research_databases 
                                  SET name = ?, description = ?, url = ?, category = ?, type = ?, icon = ?, is_featured = ?, sort_order = ?, updated_at = datetime('now') 
                                  WHERE id = ?");
            if ($stmt->execute([$name, $description, $url, $category, $type, $icon, $is_featured, $sort_order, $id])) {
                $message = "Database updated successfully!";
            } else {
                $error = "Failed to update database.";
            }
        }
    }
}

// Get all databases
$databases = $db->query("SELECT * FROM research_databases ORDER BY is_featured DESC, sort_order ASC, name ASC")->fetchAll();

// Get database types for filter
$types = $db->query("SELECT DISTINCT type FROM research_databases WHERE is_active = 1")->fetchAll(PDO::FETCH_COLUMN);

renderHeader('Manage Research Databases');
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-database"></i> Manage Research Databases</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDatabaseModal">
            <i class="fas fa-plus"></i> Add New Database
        </button>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Icon</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Type</th>
                            <th>URL</th>
                            <th>Featured</th>
                            <th>Order</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($databases as $dbItem): ?>
                        <tr>
                            <td><?= $dbItem['id'] ?></td>
                            <td><i class="fas fa-<?= htmlspecialchars($dbItem['icon']) ?> fa-lg text-primary"></i></td>
                            <td><strong><?= htmlspecialchars($dbItem['name']) ?></strong><br><small class="text-muted"><?= htmlspecialchars(substr($dbItem['description'], 0, 50)) ?>...</small></td>
                            <td><?= htmlspecialchars($dbItem['category'] ?: '-') ?></td>
                            <td>
                                <?php
                                $typeBadge = '';
                                if ($dbItem['type'] == 'academic') $typeBadge = 'badge bg-info';
                                elseif ($dbItem['type'] == 'open_access') $typeBadge = 'badge bg-success';
                                else $typeBadge = 'badge bg-warning';
                                ?>
                                <span class="<?= $typeBadge ?>"><?= ucfirst(str_replace('_', ' ', $dbItem['type'])) ?></span>
                            </td>
                            <td><a href="<?= htmlspecialchars($dbItem['url']) ?>" target="_blank" class="text-truncate d-inline-block" style="max-width: 200px;"><?= htmlspecialchars($dbItem['url']) ?></a></td>
                            <td><?= $dbItem['is_featured'] ? '<i class="fas fa-star text-warning"></i>' : '-' ?></td>
                            <td><?= $dbItem['sort_order'] ?></td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" onclick="editDatabase(<?= htmlspecialchars(json_encode($dbItem)) ?>)">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger" onclick="deleteDatabase(<?= $dbItem['id'] ?>, '<?= htmlspecialchars($dbItem['name']) ?>')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Database Modal -->
<div class="modal fade" id="addDatabaseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Add Research Database</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label">Database Name *</label>
                        <input type="text" name="name" class="form-control" required placeholder="e.g., Cambridge Core">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">URL *</label>
                        <input type="url" name="url" class="form-control" required placeholder="https://example.com">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Brief description of the database"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Category</label>
                            <input type="text" name="category" class="form-control" placeholder="e.g., Science, Medical, Business">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select">
                                <option value="academic">Academic Database</option>
                                <option value="open_access">Open Access</option>
                                <option value="subscription">Subscription Based</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Icon (FontAwesome)</label>
                            <input type="text" name="icon" class="form-control" value="database" placeholder="e.g., database, book, search">
                            <small class="text-muted">Visit <a href="https://fontawesome.com/icons" target="_blank">FontAwesome Icons</a></small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sort Order</label>
                            <input type="number" name="sort_order" class="form-control" value="999">
                        </div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="is_featured" class="form-check-input" id="isFeatured">
                        <label class="form-check-label" for="isFeatured">Featured Database (shows in featured section)</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Database</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Database Modal -->
<div class="modal fade" id="editDatabaseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Database</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Database Name *</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">URL *</label>
                        <input type="url" name="url" id="edit_url" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Category</label>
                            <input type="text" name="category" id="edit_category" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Type</label>
                            <select name="type" id="edit_type" class="form-select">
                                <option value="academic">Academic Database</option>
                                <option value="open_access">Open Access</option>
                                <option value="subscription">Subscription Based</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Icon</label>
                            <input type="text" name="icon" id="edit_icon" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sort Order</label>
                            <input type="number" name="sort_order" id="edit_sort_order" class="form-control">
                        </div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="is_featured" class="form-check-input" id="edit_is_featured">
                        <label class="form-check-label" for="edit_is_featured">Featured Database</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Update Database</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteDatabaseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-trash"></i> Delete Database</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <p>Are you sure you want to delete <strong id="delete_name"></strong>?</p>
                    <p class="text-muted small">This action can be undone by reactivating the database.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Database</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editDatabase(db) {
    document.getElementById('edit_id').value = db.id;
    document.getElementById('edit_name').value = db.name;
    document.getElementById('edit_url').value = db.url;
    document.getElementById('edit_description').value = db.description || '';
    document.getElementById('edit_category').value = db.category || '';
    document.getElementById('edit_type').value = db.type;
    document.getElementById('edit_icon').value = db.icon || 'database';
    document.getElementById('edit_sort_order').value = db.sort_order;
    document.getElementById('edit_is_featured').checked = db.is_featured == 1;
    new bootstrap.Modal(document.getElementById('editDatabaseModal')).show();
}

function deleteDatabase(id, name) {
    document.getElementById('delete_id').value = id;
    document.getElementById('delete_name').innerText = name;
    new bootstrap.Modal(document.getElementById('deleteDatabaseModal')).show();
}
</script>

<?php renderFooter(); ?>