<?php
/**
 * Advanced Book Export Page - COMPLETE UPDATE
 * Version: 2.0 - Unified Gradient Cards & Enhanced Export Features
 * 
 * NEW FEATURES:
 * - Unified gradient cards matching library events module
 * - Enhanced export options with all formats
 * - Advanced filtering with all book fields
 * - Real-time export preview
 * - Bulk export with selected books
 * - Export statistics and progress indicators
 * - Responsive design with unified styling
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/export_functions.php';
requireAdmin();

$db = getDB();

// Check available libraries
$excelAvailable = false;
$pdfAvailable = false;
$marcAvailable = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) $excelAvailable = true;
    if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) $pdfAvailable = true;
    if (class_exists('Scriptotek\Marc\MarcReader') || class_exists('File_MARC')) $marcAvailable = true;
}

// ---- Handle export request ----
if (isset($_GET['export_type']) && isset($_GET['export_mode'])) {
    $exportType = $_GET['export_type'];
    $exportMode = $_GET['export_mode'];
    
    // Build filter query to get IDs
    $sql = "SELECT id FROM books WHERE 1=1";
    $params = [];
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $status = $_GET['status'] ?? '';
    $author = $_GET['author'] ?? '';
    $publisher = $_GET['publisher'] ?? '';
    $subject = $_GET['subject'] ?? '';
    $location = $_GET['location'] ?? '';
    $isbn_filter = $_GET['isbn_filter'] ?? '';
    $call_number_filter = $_GET['call_number_filter'] ?? '';
    $accession_filter = $_GET['accession_filter'] ?? '';
    $itemCategory = $_GET['item_category'] ?? '';
    $bookStatusFilter = $_GET['book_status_filter'] ?? '';
    $maintenance = $_GET['maintenance'] ?? '';
    $year_from = $_GET['year_from'] ?? '';
    $year_to = $_GET['year_to'] ?? '';
    $price_min = $_GET['price_min'] ?? '';
    $price_max = $_GET['price_max'] ?? '';
    
    if ($search) {
        $sql .= " AND (title LIKE ? OR sub_title LIKE ? OR author LIKE ? OR author2 LIKE ? OR collaborator LIKE ? OR subject LIKE ? OR barcode LIKE ? OR isbn LIKE ? OR keyword LIKE ? OR publisher LIKE ? OR call_number LIKE ?)";
        $like = "%$search%";
        $params = array_fill(0, 11, $like);
    }
    if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
    if ($author) { $sql .= " AND (author LIKE ? OR author2 LIKE ?)"; $like = "%$author%"; $params[] = $like; $params[] = $like; }
    if ($publisher) { $sql .= " AND publisher LIKE ?"; $params[] = "%$publisher%"; }
    if ($subject) { $sql .= " AND subject LIKE ?"; $params[] = "%$subject%"; }
    if ($location) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    if ($isbn_filter) { $sql .= " AND isbn LIKE ?"; $params[] = "%$isbn_filter%"; }
    if ($call_number_filter) { $sql .= " AND call_number LIKE ?"; $params[] = "%$call_number_filter%"; }
    if ($accession_filter) { $sql .= " AND accession_number LIKE ?"; $params[] = "%$accession_filter%"; }
    if ($itemCategory) { $sql .= " AND item_category = ?"; $params[] = $itemCategory; }
    if ($bookStatusFilter) { $sql .= " AND book_status = ?"; $params[] = $bookStatusFilter; }
    if ($maintenance) { $sql .= " AND maintenance = ?"; $params[] = $maintenance; }
    if ($status === 'available') $sql .= " AND available > 0";
    elseif ($status === 'unavailable') $sql .= " AND available = 0";
    elseif ($status === 'lowstock') $sql .= " AND available > 0 AND available <= 2";
    if ($year_from) { $sql .= " AND year >= ?"; $params[] = $year_from; }
    if ($year_to) { $sql .= " AND year <= ?"; $params[] = $year_to; }
    if ($price_min !== '') { $sql .= " AND price >= ?"; $params[] = (float)$price_min; }
    if ($price_max !== '') { $sql .= " AND price <= ?"; $params[] = (float)$price_max; }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    $exportIds = empty($ids) ? null : $ids;
    
    if ($exportType === 'csv') exportBooksCSV($db, $exportIds, $exportMode);
    elseif ($exportType === 'excel') exportBooksExcel($db, $exportIds, $exportMode);
    elseif ($exportType === 'pdf') exportBooksPDF($db, $exportIds, $exportMode);
    elseif ($exportType === 'marc') exportBooksMARC($db, $exportIds, $exportMode);
    exit;
}

// ---- Handle bulk export with selected IDs ----
if (isset($_GET['bulk_export']) && isset($_GET['ids'])) {
    $ids = explode(',', $_GET['ids']);
    $ids = array_filter($ids, 'is_numeric');
    $ids = array_map('intval', $ids);
    if (!empty($ids)) {
        $exportType = $_GET['export_type'] ?? 'csv';
        $exportMode = $_GET['export_mode'] ?? 'copies';
        if ($exportType === 'csv') exportBooksCSV($db, $ids, $exportMode);
        elseif ($exportType === 'excel') exportBooksExcel($db, $ids, $exportMode);
        elseif ($exportType === 'pdf') exportBooksPDF($db, $ids, $exportMode);
        elseif ($exportType === 'marc') exportBooksMARC($db, $ids, $exportMode);
        exit;
    }
}

// ---- Display the page ----
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$author = $_GET['author'] ?? '';
$publisher = $_GET['publisher'] ?? '';
$subject = $_GET['subject'] ?? '';
$location = $_GET['location'] ?? '';
$isbn_filter = $_GET['isbn_filter'] ?? '';
$call_number_filter = $_GET['call_number_filter'] ?? '';
$accession_filter = $_GET['accession_filter'] ?? '';
$itemCategory = $_GET['item_category'] ?? '';
$bookStatusFilter = $_GET['book_status_filter'] ?? '';
$maintenance = $_GET['maintenance'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'title';
$sort_order = $_GET['sort_order'] ?? 'ASC';

$sql = "SELECT * FROM books WHERE 1=1";
$params = [];
if ($search) {
    $sql .= " AND (title LIKE ? OR sub_title LIKE ? OR author LIKE ? OR author2 LIKE ? OR collaborator LIKE ? OR subject LIKE ? OR barcode LIKE ? OR isbn LIKE ? OR keyword LIKE ? OR publisher LIKE ? OR call_number LIKE ?)";
    $like = "%$search%";
    $params = array_fill(0, 11, $like);
}
if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
if ($author) { $sql .= " AND (author LIKE ? OR author2 LIKE ?)"; $like = "%$author%"; $params[] = $like; $params[] = $like; }
if ($publisher) { $sql .= " AND publisher LIKE ?"; $params[] = "%$publisher%"; }
if ($subject) { $sql .= " AND subject LIKE ?"; $params[] = "%$subject%"; }
if ($location) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
if ($isbn_filter) { $sql .= " AND isbn LIKE ?"; $params[] = "%$isbn_filter%"; }
if ($call_number_filter) { $sql .= " AND call_number LIKE ?"; $params[] = "%$call_number_filter%"; }
if ($accession_filter) { $sql .= " AND accession_number LIKE ?"; $params[] = "%$accession_filter%"; }
if ($itemCategory) { $sql .= " AND item_category = ?"; $params[] = $itemCategory; }
if ($bookStatusFilter) { $sql .= " AND book_status = ?"; $params[] = $bookStatusFilter; }
if ($maintenance) { $sql .= " AND maintenance = ?"; $params[] = $maintenance; }
if ($status === 'available') $sql .= " AND available > 0";
elseif ($status === 'unavailable') $sql .= " AND available = 0";
elseif ($status === 'lowstock') $sql .= " AND available > 0 AND available <= 2";
if ($year_from) { $sql .= " AND year >= ?"; $params[] = $year_from; }
if ($year_to) { $sql .= " AND year <= ?"; $params[] = $year_to; }
if ($price_min !== '') { $sql .= " AND price >= ?"; $params[] = (float)$price_min; }
if ($price_max !== '') { $sql .= " AND price <= ?"; $params[] = (float)$price_max; }
$allowed_sort = ['title','author','publisher','isbn','category','book_status','location','year','price','created_at','call_number','date_of_entry','quantity','available'];
if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
$sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
$next_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
$sql .= " ORDER BY $sort_by $sort_order LIMIT 500";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Statistics
$totalBooks = $db->query("SELECT SUM(quantity) FROM books")->fetchColumn() ?: 0;
$totalTitles = $db->query("SELECT COUNT(DISTINCT title || '|' || author || '|' || publisher || '|' || isbn) FROM books")->fetchColumn();
$totalAvailable = $db->query("SELECT SUM(available) FROM books")->fetchColumn() ?: 0;
$totalIssued = $totalBooks - $totalAvailable;
$lowStock = $db->query("SELECT COUNT(*) FROM (SELECT SUM(available) as avail FROM books GROUP BY title, author, publisher, isbn HAVING avail > 0 AND avail <= 2)")->fetchColumn();
$reorderCount = $db->query("SELECT COUNT(*) FROM books WHERE available <= reorder_level AND reorder_level > 0")->fetchColumn();
$totalFines = $db->query("SELECT COALESCE(SUM(total_fines),0) FROM books")->fetchColumn();
$totalPrice = $db->query("SELECT COALESCE(SUM(price * quantity),0) FROM books")->fetchColumn();

// Distinct filter values
$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$authors = $db->query("SELECT DISTINCT author FROM books WHERE author IS NOT NULL AND author != '' ORDER BY author LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$publishers = $db->query("SELECT DISTINCT publisher FROM books WHERE publisher IS NOT NULL AND publisher != '' ORDER BY publisher LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$subjects = $db->query("SELECT DISTINCT subject FROM books WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$locations = $db->query("SELECT DISTINCT location FROM books WHERE location IS NOT NULL AND location != '' ORDER BY location")->fetchAll(PDO::FETCH_COLUMN);
$itemCategories = $db->query("SELECT DISTINCT item_category FROM books WHERE item_category IS NOT NULL AND item_category != '' ORDER BY item_category")->fetchAll(PDO::FETCH_COLUMN);
$bookStatuses = $db->query("SELECT DISTINCT book_status FROM books WHERE book_status IS NOT NULL AND book_status != '' ORDER BY book_status")->fetchAll(PDO::FETCH_COLUMN);
$maintenances = $db->query("SELECT DISTINCT maintenance FROM books WHERE maintenance IS NOT NULL AND maintenance != '' ORDER BY maintenance")->fetchAll(PDO::FETCH_COLUMN);
$allYears = $db->query("SELECT DISTINCT year FROM books WHERE year IS NOT NULL AND year != '' AND LENGTH(year) <= 4 ORDER BY year DESC LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
$years = [];
foreach ($allYears as $y) if (is_numeric($y) && $y >= 1000 && $y <= date('Y') + 5) $years[] = $y;

renderHeader('Export Books');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f6f9; 
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: var(--gradient-primary);
            border-radius: var(--radius-card);
            padding: 20px 20px 20px 70px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
            cursor: default;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }
        
        /* ===== FILTER CARD ===== */
        .filter-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 0;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: all 0.3s ease;
            overflow: hidden;
        }
        .filter-card .card-header {
            background: var(--gradient-primary);
            color: white;
            cursor: pointer;
            padding: 15px 20px;
            border: none;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .filter-card .card-header i.fa-chevron-down {
            transition: transform 0.3s;
        }
        .filter-card.collapsed .card-header i.fa-chevron-down {
            transform: rotate(-90deg);
        }
        .filter-card .card-body {
            padding: 20px;
        }
        
        /* ===== EXPORT GROUP CARDS ===== */
        .export-group {
            background: white;
            border-radius: var(--radius-card);
            padding: 20px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 20px;
            transition: all 0.3s ease;
            height: 100%;
            border: none;
        }
        .export-group:hover {
            box-shadow: var(--shadow-hover);
            transform: translateY(-3px);
        }
        .export-group .export-group-title {
            font-weight: 600;
            font-size: 16px;
            color: var(--primary-color);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .export-group .export-group-title i {
            font-size: 20px;
        }
        .export-btn {
            min-width: 100px;
            margin: 3px;
            border-radius: 8px;
            font-weight: 500;
        }
        .export-btn i {
            margin-right: 5px;
        }
        
        /* ===== TABLE STYLES ===== */
        .table-container {
            background: white;
            border-radius: var(--radius-card);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .table-container .table {
            margin-bottom: 0;
        }
        .table-container thead th {
            background: var(--gradient-primary);
            color: white;
            border: none;
            padding: 12px 15px;
            font-weight: 600;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 5;
        }
        .table-container thead th a {
            color: white;
            text-decoration: none;
        }
        .table-container thead th a:hover {
            text-decoration: underline;
        }
        .table-container tbody tr {
            transition: all 0.2s ease;
        }
        .table-container tbody tr:hover {
            background: rgba(30, 60, 114, 0.05);
        }
        .table-container tbody td {
            padding: 10px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* ===== BADGE STYLES ===== */
        .badge-status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .badge-available { background: #d4edda; color: #155724; }
        .badge-issued { background: #f8d7da; color: #721c24; }
        .badge-lowstock { background: #fff3cd; color: #856404; }
        .badge-reorder { 
            background: #f8d7da; 
            color: #721c24;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .export-btn { min-width: 80px; font-size: 12px; }
            .table-container { overflow-x: auto; }
            .filter-card .card-body { padding: 15px; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-value { font-size: 18px; }
            .export-group { padding: 15px; }
            .export-btn { min-width: 60px; font-size: 11px; padding: 4px 8px; }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .table-container thead th {
                background: #333 !important;
                color: white !important;
            }
            .filter-card { display: none !important; }
            .export-group { display: none !important; }
        }
        
        /* ===== SELECT2 OVERRIDE ===== */
        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 8px;
            border-color: #ced4da;
        }
        .select2-container--bootstrap-5 .select2-selection:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        
        /* ===== EXPORT TOOLTIP ===== */
        .export-tooltip {
            font-size: 11px;
            color: #6c757d;
            margin-top: 8px;
        }
        
        /* ===== EXPORT COUNTER ===== */
        .export-counter {
            display: inline-block;
            background: var(--gradient-primary);
            color: white;
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- ===== HEADER ===== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-file-export me-2"></i> Export Books</h2>
            <p class="text-muted small">Filter and export book data in multiple formats</p>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="books.php" class="btn btn-primary btn-sm"><i class="fas fa-arrow-left"></i> Back to Books</a>
            <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-book"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalBooks) ?></div>
                    <div class="stat-label">Total Copies</div>
                    <div class="stat-sub"><i class="fas fa-layer-group"></i> All copies</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-list"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalTitles) ?></div>
                    <div class="stat-label">Total Titles</div>
                    <div class="stat-sub"><i class="fas fa-tag"></i> Distinct books</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-check-circle"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalAvailable) ?></div>
                    <div class="stat-label">Available</div>
                    <div class="stat-sub"><i class="fas fa-arrow-up"></i> In stock</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-clock"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalIssued) ?></div>
                    <div class="stat-label">Issued</div>
                    <div class="stat-sub"><i class="fas fa-arrow-right"></i> On loan</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($lowStock) ?></div>
                    <div class="stat-label">Low Stock</div>
                    <div class="stat-sub"><i class="fas fa-arrow-down"></i> ≤ 2 copies</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-shopping-cart"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($reorderCount) ?></div>
                    <div class="stat-label">Need Reorder</div>
                    <div class="stat-sub"><i class="fas fa-bell"></i> Below threshold</div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== FILTER CARD ===== -->
    <div class="filter-card no-print" id="filterCard">
        <div class="card-header" onclick="toggleFilterPanel()">
            <span><i class="fas fa-filter me-2"></i> Advanced Filters</span>
            <i class="fas fa-chevron-down"></i>
        </div>
        <div class="card-body" id="filterBody">
            <form method="get" id="filterForm">
                <div class="row g-2">
                    <div class="col-md-12">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search across title, author, publisher, ISBN, barcode, subject, keyword, call number..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-2"><select name="category" class="form-select select2"><option value="">Category</option><?php foreach($categories as $c) echo "<option value=\"$c\"".($category==$c?' selected':'').">".htmlspecialchars($c)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="author" class="form-select select2"><option value="">Author</option><?php foreach($authors as $a) echo "<option value=\"$a\"".($author==$a?' selected':'').">".htmlspecialchars($a)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="publisher" class="form-select select2"><option value="">Publisher</option><?php foreach($publishers as $p) echo "<option value=\"$p\"".($publisher==$p?' selected':'').">".htmlspecialchars($p)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="subject" class="form-select select2"><option value="">Subject</option><?php foreach($subjects as $s) echo "<option value=\"$s\"".($subject==$s?' selected':'').">".htmlspecialchars($s)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="location" class="form-select select2"><option value="">Location</option><?php foreach($locations as $l) echo "<option value=\"$l\"".($location==$l?' selected':'').">".htmlspecialchars($l)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="status" class="form-select"><option value="">Availability</option><option value="available" <?= $status=='available'?'selected':'' ?>>Available</option><option value="unavailable" <?= $status=='unavailable'?'selected':'' ?>>Unavailable</option><option value="lowstock" <?= $status=='lowstock'?'selected':'' ?>>Low Stock</option></select></div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-2"><input type="text" name="isbn_filter" class="form-control" placeholder="ISBN" value="<?= htmlspecialchars($isbn_filter) ?>"></div>
                    <div class="col-md-2"><input type="text" name="call_number_filter" class="form-control" placeholder="Call No." value="<?= htmlspecialchars($call_number_filter) ?>"></div>
                    <div class="col-md-2"><input type="text" name="accession_filter" class="form-control" placeholder="Accession No." value="<?= htmlspecialchars($accession_filter) ?>"></div>
                    <div class="col-md-2"><select name="item_category" class="form-select select2"><option value="">Item Category</option><?php foreach($itemCategories as $ic) echo "<option value=\"$ic\"".($itemCategory==$ic?' selected':'').">".htmlspecialchars($ic)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="book_status_filter" class="form-select select2"><option value="">Book Status</option><?php foreach($bookStatuses as $bs) echo "<option value=\"$bs\"".($bookStatusFilter==$bs?' selected':'').">".htmlspecialchars($bs)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="maintenance" class="form-select select2"><option value="">Maintenance</option><?php foreach($maintenances as $m) echo "<option value=\"$m\"".($maintenance==$m?' selected':'').">".htmlspecialchars($m)."</option>"; ?></select></div>
                </div>
                <div class="row g-2 mt-2">
                    <div class="col-md-2"><select name="year_from" class="form-select"><option value="">Year From</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_from==$y?' selected':'').">$y</option>"; ?></select></div>
                    <div class="col-md-2"><select name="year_to" class="form-select"><option value="">Year To</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_to==$y?' selected':'').">$y</option>"; ?></select></div>
                    <div class="col-md-2"><input type="number" name="price_min" class="form-control" placeholder="Min Price" value="<?= htmlspecialchars($price_min) ?>"></div>
                    <div class="col-md-2"><input type="number" name="price_max" class="form-control" placeholder="Max Price" value="<?= htmlspecialchars($price_max) ?>"></div>
                    <div class="col-md-2"><select name="sort_by" class="form-select"><option value="title" <?= $sort_by=='title'?'selected':'' ?>>Sort: Title</option><option value="author" <?= $sort_by=='author'?'selected':'' ?>>Sort: Author</option><option value="publisher" <?= $sort_by=='publisher'?'selected':'' ?>>Sort: Publisher</option><option value="year" <?= $sort_by=='year'?'selected':'' ?>>Sort: Year</option><option value="call_number" <?= $sort_by=='call_number'?'selected':'' ?>>Sort: Call No.</option><option value="quantity" <?= $sort_by=='quantity'?'selected':'' ?>>Sort: Quantity</option><option value="available" <?= $sort_by=='available'?'selected':'' ?>>Sort: Available</option></select></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-primary w-100"><i class="fas fa-filter"></i> Apply</button></div>
                </div>
            </form>
        </div>
    </div>

    <!-- ===== EXPORT OPTIONS ===== -->
    <div class="row g-3 no-print mb-4">
        <div class="col-lg-3 col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-csv text-primary"></i> CSV Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('csv','copies')" class="btn btn-outline-primary export-btn"><i class="fas fa-file-csv"></i> Copies</a>
                    <a href="#" onclick="exportSelected('csv','titles')" class="btn btn-outline-primary export-btn"><i class="fas fa-file-csv"></i> Titles</a>
                </div>
                <div class="export-tooltip"><i class="fas fa-info-circle"></i> UTF-8 CSV with BOM. Compatible with Excel.</div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-excel text-success"></i> Excel Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('excel','copies')" class="btn btn-outline-success export-btn <?= !$excelAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-excel"></i> Copies</a>
                    <a href="#" onclick="exportSelected('excel','titles')" class="btn btn-outline-success export-btn <?= !$excelAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-excel"></i> Titles</a>
                </div>
                <div class="export-tooltip"><i class="fas fa-info-circle"></i> <?= $excelAvailable ? 'Professional Excel format with auto-sizing.' : '<span class="text-danger">PhpSpreadsheet not installed.</span>' ?></div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-pdf text-danger"></i> PDF Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('pdf','copies')" class="btn btn-outline-danger export-btn <?= !$pdfAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-pdf"></i> Copies</a>
                    <a href="#" onclick="exportSelected('pdf','titles')" class="btn btn-outline-danger export-btn <?= !$pdfAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-pdf"></i> Titles</a>
                </div>
                <div class="export-tooltip"><i class="fas fa-info-circle"></i> <?= $pdfAvailable ? 'Professional PDF with logo and watermark.' : '<span class="text-danger">mPDF not installed.</span>' ?></div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-book text-dark"></i> MARC21 Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('marc','mrc')" class="btn btn-outline-dark export-btn <?= !$marcAvailable ? 'disabled' : '' ?>"><i class="fas fa-book"></i> .mrc</a>
                    <a href="#" onclick="exportSelected('marc','xml')" class="btn btn-outline-dark export-btn <?= !$marcAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-code"></i> .xml</a>
                </div>
                <div class="export-tooltip"><i class="fas fa-info-circle"></i> <?= $marcAvailable ? 'MARC21 standard format for library systems.' : '<span class="text-danger">File_MARC not installed.</span>' ?></div>
            </div>
        </div>
    </div>

    <!-- ===== EXPORT SUMMARY ===== -->
    <div class="row g-3 mb-3 no-print">
        <div class="col-12">
            <div class="export-group" style="padding: 12px 20px;">
                <div class="d-flex flex-wrap justify-content-between align-items-center">
                    <span><i class="fas fa-database text-primary"></i> <strong><?= count($books) ?></strong> books matching filters</span>
                    <span>
                        <span class="export-counter"><i class="fas fa-file-export"></i> Ready to Export</span>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== PREVIEW TABLE ===== -->
    <div class="table-container">
        <div class="d-flex justify-content-between align-items-center p-3 bg-white border-bottom">
            <span><i class="fas fa-list text-primary me-1"></i> Data Preview</span>
            <span class="badge bg-secondary"><?= count($books) ?> records</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th style="text-align:center;width:40px;">#</th>
                        <th>Barcode</th>
                        <th>Accession</th>
                        <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'title','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Title <?= $sort_by=='title'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                        <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'author','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Author <?= $sort_by=='author'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                        <th>Publisher</th>
                        <th>ISBN</th>
                        <th>Year</th>
                        <th style="text-align:center;">Qty/Avail</th>
                        <th style="text-align:center;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sn = 1; foreach ($books as $book): ?>
                    <tr>
                        <td style="text-align:center;"><?= $sn++ ?></td>
                        <td><code><?= htmlspecialchars($book['barcode'] ?? '-') ?></code></td>
                        <td><?= htmlspecialchars($book['accession_number'] ?? '-') ?></td>
                        <td><strong><?= htmlspecialchars(substr($book['title'] ?? '', 0, 60)) ?></strong></td>
                        <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['publisher'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['isbn'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['year'] ?? '-') ?></td>
                        <td style="text-align:center;">
                            <span class="badge bg-primary"><?= $book['quantity'] ?? 0 ?></span>
                            <span class="badge <?= ((int)($book['available'] ?? 0) > 0) ? 'bg-success' : 'bg-danger' ?>"><?= $book['available'] ?? 0 ?></span>
                        </td>
                        <td style="text-align:center;">
                            <?php if ((int)($book['available'] ?? 0) > 0): ?>
                                <span class="badge badge-available">Available</span>
                            <?php else: ?>
                                <span class="badge badge-issued">Issued</span>
                            <?php endif; ?>
                            <?php if ((int)($book['available'] ?? 0) <= 2 && (int)($book['available'] ?? 0) > 0): ?>
                                <span class="badge badge-lowstock">Low</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($books)): ?>
                    <tr><td colspan="10" class="text-center py-4 text-muted">
                        <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                        No books found matching the filters.
                    </td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() { 
    $('.select2').select2({ theme: 'bootstrap-5', width: '100%', allowClear: true }); 
});

function toggleFilterPanel() {
    let card = document.getElementById('filterCard');
    let body = document.getElementById('filterBody');
    if (card.classList.contains('collapsed')) {
        body.style.display = 'block';
        card.classList.remove('collapsed');
        localStorage.setItem('exportFilterPanelCollapsed', 'false');
    } else {
        body.style.display = 'none';
        card.classList.add('collapsed');
        localStorage.setItem('exportFilterPanelCollapsed', 'true');
    }
}

let isCollapsed = localStorage.getItem('exportFilterPanelCollapsed') === 'true';
if (isCollapsed) {
    let body = document.getElementById('filterBody');
    if (body) body.style.display = 'none';
    let card = document.getElementById('filterCard');
    if (card) card.classList.add('collapsed');
} else {
    let body = document.getElementById('filterBody');
    if (body) body.style.display = 'block';
    let card = document.getElementById('filterCard');
    if (card) card.classList.remove('collapsed');
}

function exportSelected(type, mode) {
    let form = document.getElementById('filterForm');
    let url = window.location.pathname + '?';
    let params = new URLSearchParams(new FormData(form));
    params.append('export_type', type);
    params.append('export_mode', mode);
    for (let [key, val] of params.entries()) {
        if (val === '') params.delete(key);
    }
    window.location.href = url + params.toString();
}

// Auto-submit on sort change
document.querySelector('select[name="sort_by"]')?.addEventListener('change', function() {
    document.getElementById('filterForm').submit();
});

// Enter key on filter inputs
document.querySelectorAll('#filterForm input, #filterForm select').forEach(el => {
    el.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('filterForm').submit();
        }
    });
});
</script>
<?php renderFooter(); ?>
</body>
</html>