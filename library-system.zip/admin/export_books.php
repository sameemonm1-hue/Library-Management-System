<?php
/**
 * Advanced Book Export Page
 * Includes filters, statistics, and export buttons for all formats
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/export_functions.php';
requireAdmin();

$db = getDB();

// Check available libraries
$excelAvailable = false;
$pdfAvailable = false;
$marcAvailable = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) $excelAvailable = true;
    if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) $pdfAvailable = true;
    if (class_exists('Scriptotek\Marc\MarcReader') || class_exists('File_MARC')) $marcAvailable = true;
}

// ---- Handle export request ----
if (isset($_GET['export_type']) && isset($_GET['export_mode'])) {
    $exportType = $_GET['export_type'];
    $exportMode = $_GET['export_mode'];
    
    // Build filter query to get IDs
    $sql = "SELECT id FROM books WHERE 1=1";
    $params = [];
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $status = $_GET['status'] ?? '';
    $author = $_GET['author'] ?? '';
    $publisher = $_GET['publisher'] ?? '';
    $subject = $_GET['subject'] ?? '';
    $location = $_GET['location'] ?? '';
    $isbn_filter = $_GET['isbn_filter'] ?? '';
    $call_number_filter = $_GET['call_number_filter'] ?? '';
    $accession_filter = $_GET['accession_filter'] ?? '';
    $itemCategory = $_GET['item_category'] ?? '';
    $bookStatusFilter = $_GET['book_status_filter'] ?? '';
    $maintenance = $_GET['maintenance'] ?? '';
    $year_from = $_GET['year_from'] ?? '';
    $year_to = $_GET['year_to'] ?? '';
    $price_min = $_GET['price_min'] ?? '';
    $price_max = $_GET['price_max'] ?? '';
    
    if ($search) {
        $sql .= " AND (title LIKE ? OR sub_title LIKE ? OR author LIKE ? OR author2 LIKE ? OR collaborator LIKE ? OR subject LIKE ? OR barcode LIKE ? OR isbn LIKE ? OR keyword LIKE ? OR publisher LIKE ? OR call_number LIKE ?)";
        $like = "%$search%";
        $params = array_fill(0, 11, $like);
    }
    if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
    if ($author) { $sql .= " AND (author LIKE ? OR author2 LIKE ?)"; $like = "%$author%"; $params[] = $like; $params[] = $like; }
    if ($publisher) { $sql .= " AND publisher LIKE ?"; $params[] = "%$publisher%"; }
    if ($subject) { $sql .= " AND subject LIKE ?"; $params[] = "%$subject%"; }
    if ($location) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    if ($isbn_filter) { $sql .= " AND isbn LIKE ?"; $params[] = "%$isbn_filter%"; }
    if ($call_number_filter) { $sql .= " AND call_number LIKE ?"; $params[] = "%$call_number_filter%"; }
    if ($accession_filter) { $sql .= " AND accession_number LIKE ?"; $params[] = "%$accession_filter%"; }
    if ($itemCategory) { $sql .= " AND item_category = ?"; $params[] = $itemCategory; }
    if ($bookStatusFilter) { $sql .= " AND book_status = ?"; $params[] = $bookStatusFilter; }
    if ($maintenance) { $sql .= " AND maintenance = ?"; $params[] = $maintenance; }
    if ($status === 'available') $sql .= " AND available > 0";
    elseif ($status === 'unavailable') $sql .= " AND available = 0";
    elseif ($status === 'lowstock') $sql .= " AND available > 0 AND available <= 2";
    if ($year_from) { $sql .= " AND year >= ?"; $params[] = $year_from; }
    if ($year_to) { $sql .= " AND year <= ?"; $params[] = $year_to; }
    if ($price_min !== '') { $sql .= " AND price >= ?"; $params[] = (float)$price_min; }
    if ($price_max !== '') { $sql .= " AND price <= ?"; $params[] = (float)$price_max; }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
    $exportIds = empty($ids) ? null : $ids;
    
    if ($exportType === 'csv') exportBooksCSV($db, $exportIds, $exportMode);
    elseif ($exportType === 'excel') exportBooksExcel($db, $exportIds, $exportMode);
    elseif ($exportType === 'pdf') exportBooksPDF($db, $exportIds, $exportMode);
    elseif ($exportType === 'marc') exportBooksMARC($db, $exportIds, $exportMode);
    exit;
}

// ---- Display the page ----
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$author = $_GET['author'] ?? '';
$publisher = $_GET['publisher'] ?? '';
$subject = $_GET['subject'] ?? '';
$location = $_GET['location'] ?? '';
$isbn_filter = $_GET['isbn_filter'] ?? '';
$call_number_filter = $_GET['call_number_filter'] ?? '';
$accession_filter = $_GET['accession_filter'] ?? '';
$itemCategory = $_GET['item_category'] ?? '';
$bookStatusFilter = $_GET['book_status_filter'] ?? '';
$maintenance = $_GET['maintenance'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'title';
$sort_order = $_GET['sort_order'] ?? 'ASC';

$sql = "SELECT * FROM books WHERE 1=1";
$params = [];
if ($search) {
    $sql .= " AND (title LIKE ? OR sub_title LIKE ? OR author LIKE ? OR author2 LIKE ? OR collaborator LIKE ? OR subject LIKE ? OR barcode LIKE ? OR isbn LIKE ? OR keyword LIKE ? OR publisher LIKE ? OR call_number LIKE ?)";
    $like = "%$search%";
    $params = array_fill(0, 11, $like);
}
if ($category) { $sql .= " AND category = ?"; $params[] = $category; }
if ($author) { $sql .= " AND (author LIKE ? OR author2 LIKE ?)"; $like = "%$author%"; $params[] = $like; $params[] = $like; }
if ($publisher) { $sql .= " AND publisher LIKE ?"; $params[] = "%$publisher%"; }
if ($subject) { $sql .= " AND subject LIKE ?"; $params[] = "%$subject%"; }
if ($location) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
if ($isbn_filter) { $sql .= " AND isbn LIKE ?"; $params[] = "%$isbn_filter%"; }
if ($call_number_filter) { $sql .= " AND call_number LIKE ?"; $params[] = "%$call_number_filter%"; }
if ($accession_filter) { $sql .= " AND accession_number LIKE ?"; $params[] = "%$accession_filter%"; }
if ($itemCategory) { $sql .= " AND item_category = ?"; $params[] = $itemCategory; }
if ($bookStatusFilter) { $sql .= " AND book_status = ?"; $params[] = $bookStatusFilter; }
if ($maintenance) { $sql .= " AND maintenance = ?"; $params[] = $maintenance; }
if ($status === 'available') $sql .= " AND available > 0";
elseif ($status === 'unavailable') $sql .= " AND available = 0";
elseif ($status === 'lowstock') $sql .= " AND available > 0 AND available <= 2";
if ($year_from) { $sql .= " AND year >= ?"; $params[] = $year_from; }
if ($year_to) { $sql .= " AND year <= ?"; $params[] = $year_to; }
if ($price_min !== '') { $sql .= " AND price >= ?"; $params[] = (float)$price_min; }
if ($price_max !== '') { $sql .= " AND price <= ?"; $params[] = (float)$price_max; }
$allowed_sort = ['title','author','publisher','isbn','category','book_status','location','year','price','created_at','call_number','date_of_entry'];
if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
$sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
$next_order = $sort_order === 'ASC' ? 'DESC' : 'ASC';
$sql .= " ORDER BY $sort_by $sort_order LIMIT 500";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Statistics
$totalBooks = $db->query("SELECT SUM(quantity) FROM books")->fetchColumn() ?: 0;
$totalTitles = $db->query("SELECT COUNT(DISTINCT title || '|' || author || '|' || publisher || '|' || isbn) FROM books")->fetchColumn();
$totalAvailable = $db->query("SELECT SUM(available) FROM books")->fetchColumn() ?: 0;
$totalIssued = $totalBooks - $totalAvailable;
$lowStock = $db->query("SELECT COUNT(*) FROM (SELECT SUM(available) as avail FROM books GROUP BY title, author, publisher, isbn HAVING avail > 0 AND avail <= 2)")->fetchColumn();

// Distinct filter values
$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$authors = $db->query("SELECT DISTINCT author FROM books WHERE author IS NOT NULL AND author != '' ORDER BY author LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$publishers = $db->query("SELECT DISTINCT publisher FROM books WHERE publisher IS NOT NULL AND publisher != '' ORDER BY publisher LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$subjects = $db->query("SELECT DISTINCT subject FROM books WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
$locations = $db->query("SELECT DISTINCT location FROM books WHERE location IS NOT NULL AND location != '' ORDER BY location")->fetchAll(PDO::FETCH_COLUMN);
$itemCategories = $db->query("SELECT DISTINCT item_category FROM books WHERE item_category IS NOT NULL AND item_category != '' ORDER BY item_category")->fetchAll(PDO::FETCH_COLUMN);
$bookStatuses = $db->query("SELECT DISTINCT book_status FROM books WHERE book_status IS NOT NULL AND book_status != '' ORDER BY book_status")->fetchAll(PDO::FETCH_COLUMN);
$maintenances = $db->query("SELECT DISTINCT maintenance FROM books WHERE maintenance IS NOT NULL AND maintenance != '' ORDER BY maintenance")->fetchAll(PDO::FETCH_COLUMN);
$allYears = $db->query("SELECT DISTINCT year FROM books WHERE year IS NOT NULL AND year != '' AND LENGTH(year) <= 4 ORDER BY year DESC LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
$years = [];
foreach ($allYears as $y) if (is_numeric($y) && $y >= 1000 && $y <= date('Y') + 5) $years[] = $y;

renderHeader('Export Books');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        body{background:#f0f2f5}
        .stat-card{transition:transform 0.2s;cursor:pointer}
        .stat-card:hover{transform:translateY(-5px)}
        .filter-card{background:white;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,0.1);margin-bottom:20px}
        .filter-card .card-header{background:linear-gradient(135deg,#1e3c72 0%,#2a5298 100%);color:white;cursor:pointer}
        .filter-card .card-header i.fa-chevron-down{transition:transform 0.3s}
        .filter-card.collapsed .card-header i.fa-chevron-down{transform:rotate(-90deg)}
        .export-btn{min-width:120px;margin:5px}
        .export-group{border:1px solid #dee2e6;border-radius:10px;padding:15px;margin-bottom:15px;background:white}
        .export-group-title{font-weight:600;margin-bottom:10px;color:#1e3c72}
        @media print{.no-print{display:none!important}}
        .table-container{overflow-x:auto}
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-file-export"></i> Export Books</h2>
            <p class="text-muted small">Filter and export book data in multiple formats</p>
        </div>
        <div class="no-print">
            <a href="books.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Books</a>
            <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-2 col-6"><div class="card text-center bg-primary text-white stat-card"><div class="card-body"><h3><?= number_format($totalBooks) ?></h3><p>Total Copies</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-info text-white stat-card"><div class="card-body"><h3><?= number_format($totalTitles) ?></h3><p>Total Titles</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-success text-white stat-card"><div class="card-body"><h3><?= number_format($totalAvailable) ?></h3><p>Available</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-warning text-white stat-card"><div class="card-body"><h3><?= number_format($totalIssued) ?></h3><p>Issued</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center <?= $lowStock>0?'bg-danger':'bg-secondary' ?> text-white stat-card"><div class="card-body"><h3><?= number_format($lowStock) ?></h3><p>Low Stock</p></div></div></div>
        <div class="col-md-2 col-6"><div class="card text-center bg-dark text-white stat-card"><div class="card-body"><h3><?= number_format(count($books)) ?></h3><p>Filtered Results</p></div></div></div>
    </div>

    <!-- Advanced Filters -->
    <div class="filter-card no-print" id="filterCard">
        <div class="card-header" onclick="toggleFilterPanel()">
            <i class="fas fa-filter"></i> Advanced Filters
            <i class="fas fa-chevron-down float-end mt-1"></i>
        </div>
        <div class="card-body" id="filterBody">
            <form method="get" id="filterForm">
                <div class="row g-3">
                    <div class="col-md-12">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search across title, author, publisher, ISBN, barcode, subject, keyword, call number..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><select name="category" class="form-select select2"><option value="">All Categories</option><?php foreach($categories as $c) echo "<option value=\"$c\"".($category==$c?' selected':'').">".htmlspecialchars($c)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="author" class="form-select select2"><option value="">All Authors</option><?php foreach($authors as $a) echo "<option value=\"$a\"".($author==$a?' selected':'').">".htmlspecialchars($a)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="publisher" class="form-select select2"><option value="">All Publishers</option><?php foreach($publishers as $p) echo "<option value=\"$p\"".($publisher==$p?' selected':'').">".htmlspecialchars($p)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="subject" class="form-select select2"><option value="">All Subjects</option><?php foreach($subjects as $s) echo "<option value=\"$s\"".($subject==$s?' selected':'').">".htmlspecialchars($s)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="location" class="form-select select2"><option value="">All Locations</option><?php foreach($locations as $l) echo "<option value=\"$l\"".($location==$l?' selected':'').">".htmlspecialchars($l)."</option>"; ?></select></div>
                    <div class="col-md-2"><input type="text" name="isbn_filter" class="form-control" placeholder="ISBN" value="<?= htmlspecialchars($isbn_filter) ?>"></div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><input type="text" name="call_number_filter" class="form-control" placeholder="Call Number" value="<?= htmlspecialchars($call_number_filter) ?>"></div>
                    <div class="col-md-2"><input type="text" name="accession_filter" class="form-control" placeholder="Accession No." value="<?= htmlspecialchars($accession_filter) ?>"></div>
                    <div class="col-md-2"><select name="item_category" class="form-select select2"><option value="">Item Category</option><?php foreach($itemCategories as $ic) echo "<option value=\"$ic\"".($itemCategory==$ic?' selected':'').">".htmlspecialchars($ic)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="book_status_filter" class="form-select select2"><option value="">Book Status</option><?php foreach($bookStatuses as $bs) echo "<option value=\"$bs\"".($bookStatusFilter==$bs?' selected':'').">".htmlspecialchars($bs)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="maintenance" class="form-select select2"><option value="">Maintenance</option><?php foreach($maintenances as $m) echo "<option value=\"$m\"".($maintenance==$m?' selected':'').">".htmlspecialchars($m)."</option>"; ?></select></div>
                    <div class="col-md-2"><select name="year_from" class="form-select"><option value="">Year From</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_from==$y?' selected':'').">$y</option>"; ?></select></div>
                </div>
                <div class="row g-3 mt-2">
                    <div class="col-md-2"><select name="year_to" class="form-select"><option value="">Year To</option><?php foreach($years as $y) echo "<option value=\"$y\"".($year_to==$y?' selected':'').">$y</option>"; ?></select></div>
                    <div class="col-md-2"><input type="number" name="price_min" class="form-control" placeholder="Min Price" value="<?= htmlspecialchars($price_min) ?>"></div>
                    <div class="col-md-2"><input type="number" name="price_max" class="form-control" placeholder="Max Price" value="<?= htmlspecialchars($price_max) ?>"></div>
                    <div class="col-md-2"><select name="status" class="form-select"><option value="">All Availability</option><option value="available" <?= $status=='available'?'selected':'' ?>>Available Only</option><option value="unavailable" <?= $status=='unavailable'?'selected':'' ?>>Not Available</option><option value="lowstock" <?= $status=='lowstock'?'selected':'' ?>>Low Stock</option></select></div>
                    <div class="col-md-2"><select name="sort_by" class="form-select"><option value="title" <?= $sort_by=='title'?'selected':'' ?>>Sort by Title</option><option value="author" <?= $sort_by=='author'?'selected':'' ?>>Sort by Author</option><option value="publisher" <?= $sort_by=='publisher'?'selected':'' ?>>Sort by Publisher</option><option value="year" <?= $sort_by=='year'?'selected':'' ?>>Sort by Year</option><option value="call_number" <?= $sort_by=='call_number'?'selected':'' ?>>Sort by Call Number</option></select></div>
                    <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Apply Filters</button></div>
                </div>
            </form>
        </div>
    </div>

    <!-- Export Options -->
    <div class="row no-print">
        <div class="col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-csv"></i> CSV Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('csv','copies')" class="btn btn-outline-primary export-btn"><i class="fas fa-file-csv"></i> Copies</a>
                    <a href="#" onclick="exportSelected('csv','titles')" class="btn btn-outline-primary export-btn"><i class="fas fa-file-csv"></i> Titles</a>
                </div>
                <small class="text-muted">CSV with UTF-8 BOM. Compatible with Excel.</small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-excel"></i> Excel Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('excel','copies')" class="btn btn-outline-success export-btn <?= !$excelAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-excel"></i> Copies</a>
                    <a href="#" onclick="exportSelected('excel','titles')" class="btn btn-outline-success export-btn <?= !$excelAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-excel"></i> Titles</a>
                </div>
                <small class="text-muted"><?= $excelAvailable ? 'Excel format with auto-sizing.' : 'PhpSpreadsheet not installed.' ?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-file-pdf"></i> PDF Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('pdf','copies')" class="btn btn-outline-danger export-btn <?= !$pdfAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-pdf"></i> Copies</a>
                    <a href="#" onclick="exportSelected('pdf','titles')" class="btn btn-outline-danger export-btn <?= !$pdfAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-pdf"></i> Titles</a>
                </div>
                <small class="text-muted"><?= $pdfAvailable ? 'PDF with logo and watermark support.' : 'mPDF not installed.' ?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="export-group">
                <div class="export-group-title"><i class="fas fa-book"></i> MARC21 Export</div>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="exportSelected('marc','mrc')" class="btn btn-outline-dark export-btn <?= !$marcAvailable ? 'disabled' : '' ?>"><i class="fas fa-book"></i> .mrc</a>
                    <a href="#" onclick="exportSelected('marc','xml')" class="btn btn-outline-dark export-btn <?= !$marcAvailable ? 'disabled' : '' ?>"><i class="fas fa-file-code"></i> .xml</a>
                </div>
                <small class="text-muted"><?= $marcAvailable ? 'MARC21 standard format.' : 'File_MARC not installed.' ?></small>
            </div>
        </div>
    </div>

    <!-- Preview Table -->
    <div class="card mt-4">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> Data Preview</span>
            <span class="badge bg-secondary"><?= count($books) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table table-hover table-bordered mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th style="text-align:center;width:40px;">#</th>
                            <th>Barcode</th>
                            <th>Accession</th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'title','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Title <?= $sort_by=='title'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'author','sort_order'=>$next_order])) ?>" class="text-white text-decoration-none">Author <?= $sort_by=='author'?($sort_order=='ASC'?'↑':'↓'):'' ?></a></th>
                            <th>Publisher</th>
                            <th>ISBN</th>
                            <th>Year</th>
                            <th style="text-align:center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn = 1; foreach ($books as $book): ?>
                        <tr>
                            <td style="text-align:center;"><?= $sn++ ?></td>
                            <td><code><?= htmlspecialchars($book['barcode'] ?? '-') ?></code></td>
                            <td><?= htmlspecialchars($book['accession_number'] ?? '-') ?></td>
                            <td><strong><?= htmlspecialchars(substr($book['title'] ?? '', 0, 60)) ?></strong></td>
                            <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['publisher'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['isbn'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['year'] ?? '-') ?></td>
                            <td style="text-align:center;">
                                <?php if ((int)($book['available'] ?? 0) > 0): ?>
                                    <span class="badge bg-success">Available</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Issued</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($books)): ?>
                        <tr><td colspan="9" class="text-center py-4 text-muted">No books found matching the filters.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() { 
    $('.select2').select2({ theme: 'bootstrap-5', width: '100%', allowClear: true }); 
});

function toggleFilterPanel() {
    let card = document.getElementById('filterCard');
    let body = document.getElementById('filterBody');
    if (card.classList.contains('collapsed')) {
        body.style.display = 'block';
        card.classList.remove('collapsed');
        localStorage.setItem('filterPanelCollapsed', 'false');
    } else {
        body.style.display = 'none';
        card.classList.add('collapsed');
        localStorage.setItem('filterPanelCollapsed', 'true');
    }
}

let isCollapsed = localStorage.getItem('filterPanelCollapsed') === 'true';
if (isCollapsed) {
    document.getElementById('filterBody').style.display = 'none';
    document.getElementById('filterCard').classList.add('collapsed');
} else {
    document.getElementById('filterBody').style.display = 'block';
    document.getElementById('filterCard').classList.remove('collapsed');
}

function exportSelected(type, mode) {
    let form = document.getElementById('filterForm');
    let url = window.location.pathname + '?';
    let params = new URLSearchParams(new FormData(form));
    params.append('export_type', type);
    params.append('export_mode', mode);
    for (let [key, val] of params.entries()) {
        if (val === '') params.delete(key);
    }
    window.location.href = url + params.toString();
}

document.querySelector('select[name="sort_by"]')?.addEventListener('change', function() {
    document.getElementById('filterForm').submit();
});
</script>
<?php renderFooter(); ?>