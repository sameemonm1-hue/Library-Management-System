<?php
/**
 * Member Management Module - Enhanced Update
 * Features:
 * - Full member CRUD with all fields
 * - Photo display everywhere (list, edit, view)
 * - Added Date: Created At, Admission Date, Membership Expiry
 * - Advanced search and filters
 * - Bulk operations
 * - Export capabilities (CSV, PDF, Excel)
 * - Barcode generation
 * - Responsive design
 * - Fixed modal scrolling
 * - Live camera capture for member photos
 * - Advanced analytics dashboard
 * - Member activity tracking
 * - Email notifications
 * - Export to PDF and Excel
 * - Member import from CSV
 * - Fine management improvements
 * - Audit trail
 * - Unified gradient cards matching library events module
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// ========== ENSURE REQUIRED FUNCTIONS EXIST ==========
if (!function_exists('formatCurrency')) {
    function formatCurrency($amount) {
        global $settings;
        $symbol = $settings['currency_symbol'] ?? '$';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        return $symbol . ' ' . number_format($amount, $decimals);
    }
}

if (!function_exists('getMemberPhotoUrl')) {
    function getMemberPhotoUrl($photoPath) {
        if (empty($photoPath)) {
            return '';
        }
        if (filter_var($photoPath, FILTER_VALIDATE_URL)) {
            return $photoPath;
        }
        $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
        if (file_exists($fullPath)) {
            return getWebImageUrl($photoPath);
        }
        return '';
    }
}

if (!function_exists('getMemberPhotoBase64')) {
    function getMemberPhotoBase64($photoPath) {
        if (empty($photoPath)) {
            return '';
        }
        $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
        if (!file_exists($fullPath)) {
            return '';
        }
        $data = @file_get_contents($fullPath);
        if ($data === false) {
            return '';
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_buffer($finfo, $data);
        finfo_close($finfo);
        return 'data:' . $mime . ';base64,' . base64_encode($data);
    }
}

if (!function_exists('getMemberAge')) {
    function getMemberAge($dob) {
        if (empty($dob)) return '-';
        $birthDate = new DateTime($dob);
        $today = new DateTime('today');
        $age = $birthDate->diff($today)->y;
        return $age;
    }
}

// ========== DATABASE CONNECTION ==========
$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$memberCategories = ['General', 'Student', 'Staff', 'Others', 'Faculty', 'Visitor', 'Researcher', 'Alumni', 'Volunteer', 'Intern'];

// ========== ENSURE ALL COLUMNS EXIST ==========
$requiredColumns = [
    'members' => [
        'designation' => "TEXT DEFAULT ''",
        'emergency_contact' => "TEXT DEFAULT ''",
        'general_id' => "TEXT DEFAULT ''",
        'security_deposit' => "REAL DEFAULT 0",
        'membership_expiry' => "DATE",
        'total_paid_fines' => "REAL DEFAULT 0",
        'is_email_verified' => "INTEGER DEFAULT 0",
        'verification_token' => "TEXT DEFAULT ''",
        'verification_expiry' => "DATETIME",
        'approval_status' => "TEXT DEFAULT 'pending'",
        'parent_phone' => "TEXT DEFAULT ''",
        'blood_group' => "TEXT DEFAULT ''",
        'gender' => "TEXT DEFAULT ''",
        'dob' => "DATE",
        'address' => "TEXT DEFAULT ''",
        'notes' => "TEXT DEFAULT ''",
        'total_fines' => "REAL DEFAULT 0",
        'total_issued' => "INTEGER DEFAULT 0",
        'active_books' => "INTEGER DEFAULT 0",
        'admission_date' => "DATE DEFAULT CURRENT_DATE",
        'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "DATETIME",
        'last_activity' => "DATETIME",
        'total_visits' => "INTEGER DEFAULT 0",
        'preferred_language' => "TEXT DEFAULT 'en'",
        'nationality' => "TEXT DEFAULT ''",
        'religion' => "TEXT DEFAULT ''",
        'marital_status' => "TEXT DEFAULT ''",
        'occupation' => "TEXT DEFAULT ''",
        'company_name' => "TEXT DEFAULT ''",
        'website' => "TEXT DEFAULT ''",
        'social_media' => "TEXT DEFAULT ''",
        'interests' => "TEXT DEFAULT ''",
        'membership_type' => "TEXT DEFAULT 'standard'",
        'payment_method' => "TEXT DEFAULT ''",
        'payment_reference' => "TEXT DEFAULT ''",
        'discount_rate' => "REAL DEFAULT 0",
        'overdue_books' => "INTEGER DEFAULT 0",
        'last_fine_paid' => "DATETIME",
        'fine_waiver_count' => "INTEGER DEFAULT 0",
        'membership_duration' => "INTEGER DEFAULT 0"
    ],
    'member_activity_log' => [
        'id' => "INTEGER PRIMARY KEY AUTOINCREMENT",
        'admno' => "TEXT NOT NULL",
        'action' => "TEXT NOT NULL",
        'description' => "TEXT",
        'ip_address' => "TEXT",
        'user_agent' => "TEXT",
        'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
        'FOREIGN KEY (admno) REFERENCES members(admno) ON DELETE CASCADE'
    ]
];

foreach ($requiredColumns as $table => $columns) {
    try {
        $existingCols = $db->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_COLUMN, 1);
        foreach ($columns as $col => $def) {
            if (!in_array($col, $existingCols)) {
                $db->exec("ALTER TABLE $table ADD COLUMN $col $def");
            }
        }
    } catch (PDOException $e) {
        // Ignore - columns already exist
    }
}

// Create activity log table if not exists
try {
    $db->exec("CREATE TABLE IF NOT EXISTS member_activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admno TEXT NOT NULL,
        action TEXT NOT NULL,
        description TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (admno) REFERENCES members(admno) ON DELETE CASCADE
    )");
} catch (PDOException $e) {
    // Table already exists
}

// ========== FETCH FINE RATES ==========
$fineRates = [];
$rateStmt = $db->query("SELECT member_category, fine_per_day FROM fine_rates");
while ($row = $rateStmt->fetch()) {
    $fineRates[$row['member_category']] = $row['fine_per_day'];
}

// ========== CSRF PROTECTION ==========
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ========== AUTO-INACTIVATE INACTIVE MEMBERS ==========
function autoInactivateInactiveMembers($db) {
    $sql = "UPDATE members SET status = 'inactive' 
            WHERE status = 'active' 
            AND (
                (NOT EXISTS (SELECT 1 FROM circulation WHERE circulation.admno = members.admno)
                 AND date(admission_date) <= date('now', '-6 months'))
                OR
                (strftime('%s', 'now') - strftime('%s', (
                    SELECT MAX(issue_date) FROM circulation WHERE circulation.admno = members.admno
                )) > 60*60*24*180)
            )";
    $db->exec($sql);
}
autoInactivateInactiveMembers($db);

// ========== LOG MEMBER ACTIVITY ==========
function logMemberActivity($db, $admno, $action, $description = '') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $stmt = $db->prepare("INSERT INTO member_activity_log (admno, action, description, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$admno, $action, $description, $ip, $userAgent]);
}

// ========== EXPORT FUNCTIONS ==========
if (isset($_GET['export'])) {
    $format = $_GET['export'];
    $selected = isset($_GET['ids']) ? explode(',', $_GET['ids']) : null;
    
    if ($format === 'csv') {
        exportMembersCSV($db, $selected, $currencySymbol);
        exit;
    } elseif ($format === 'pdf') {
        exportMembersPDF($db, $selected);
        exit;
    } elseif ($format === 'excel') {
        exportMembersExcel($db, $selected);
        exit;
    }
}

// ========== EXPORT TO CSV ==========
function exportMembersCSV($db, $selected = null, $currencySymbol = '$') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=members_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    
    fputcsv($out, [
        'Adm/Mem No', 'Name', 'Designation', 'General ID', 'Category', 'Class/Dept', 'Division',
        'Roll No', 'Email', 'Phone', 'Parent Phone', 'Emergency Contact', 'Address',
        'DOB', 'Age', 'Gender', 'Blood Group', 'Nationality', 'Religion', 'Marital Status',
        'Occupation', 'Company', 'Website', 'Photo Path', 'Status', 'Admission Date',
        'Security Deposit', 'Membership Expiry', 'Created At', 'Last Activity', 'Total Visits',
        'Active Books', 'Total Issued', 'Total Fines', 'Total Paid Fines', 'Overdue Books',
        'Membership Type', 'Discount Rate', 'Notes'
    ]);
    
    if ($selected && is_array($selected) && count($selected) > 0) {
        $placeholders = implode(',', array_fill(0, count($selected), '?'));
        $sql = "SELECT * FROM members WHERE admno IN ($placeholders) ORDER BY name";
        $stmt = $db->prepare($sql);
        $stmt->execute($selected);
        $members = $stmt->fetchAll();
    } else {
        $members = $db->query("SELECT * FROM members ORDER BY name")->fetchAll();
    }
    
    foreach ($members as $m) {
        $age = getMemberAge($m['dob'] ?? '');
        fputcsv($out, [
            $m['admno'], $m['name'], $m['designation'] ?? '', $m['general_id'] ?? '', 
            $m['member_category'] ?? '', $m['class'] ?? '', $m['division'] ?? '', 
            $m['roll_no'] ?? '', $m['email'] ?? '', $m['phone'] ?? '', 
            $m['parent_phone'] ?? '', $m['emergency_contact'] ?? '', $m['address'] ?? '', 
            $m['dob'] ?? '', $age, $m['gender'] ?? '', $m['blood_group'] ?? '',
            $m['nationality'] ?? '', $m['religion'] ?? '', $m['marital_status'] ?? '',
            $m['occupation'] ?? '', $m['company_name'] ?? '', $m['website'] ?? '',
            $m['photo_path'] ?? '', $m['status'] ?? 'active', $m['admission_date'] ?? '',
            $m['security_deposit'] ?? 0, $m['membership_expiry'] ?? '', $m['created_at'] ?? '',
            $m['last_activity'] ?? '', $m['total_visits'] ?? 0,
            $m['active_books'] ?? 0, $m['total_issued'] ?? 0, $m['total_fines'] ?? 0,
            $m['total_paid_fines'] ?? 0, $m['overdue_books'] ?? 0,
            $m['membership_type'] ?? 'standard', $m['discount_rate'] ?? 0, $m['notes'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}

// ========== EXPORT TO PDF (using HTML to PDF) ==========
function exportMembersPDF($db, $selected = null) {
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename=members_' . date('Y-m-d') . '.html');
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Member List</title>
        <style>
            body { font-family: Arial, sans-serif; font-size: 10px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #000; padding: 4px; text-align: left; }
            th { background: #f0f0f0; }
            .header { text-align: center; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class="header">
            <h2>Member Directory</h2>
            <p>Generated: <?= date('Y-m-d H:i:s') ?></p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Adm/Mem No</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Class/Dept</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Admission Date</th>
                    <th>Active Books</th>
                    <th>Fines</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($selected && is_array($selected) && count($selected) > 0) {
                    $placeholders = implode(',', array_fill(0, count($selected), '?'));
                    $sql = "SELECT * FROM members WHERE admno IN ($placeholders) ORDER BY name";
                    $stmt = $db->prepare($sql);
                    $stmt->execute($selected);
                    $members = $stmt->fetchAll();
                } else {
                    $members = $db->query("SELECT * FROM members ORDER BY name")->fetchAll();
                }
                foreach ($members as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['admno']) ?></td>
                    <td><?= htmlspecialchars($m['name']) ?></td>
                    <td><?= htmlspecialchars($m['member_category'] ?? '') ?></td>
                    <td><?= htmlspecialchars($m['class'] ?? '') ?></td>
                    <td><?= htmlspecialchars($m['phone'] ?? '') ?></td>
                    <td><?= htmlspecialchars($m['email'] ?? '') ?></td>
                    <td><?= ($m['status'] ?? 'active') === 'active' ? 'Active' : 'Inactive' ?></td>
                    <td><?= $m['admission_date'] ?? '' ?></td>
                    <td><?= $m['active_books'] ?? 0 ?></td>
                    <td><?= $m['total_fines'] ?? 0 ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </body>
    </html>
    <?php
    exit;
}

// ========== EXPORT TO EXCEL (using HTML table) ==========
function exportMembersExcel($db, $selected = null) {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename=members_' . date('Y-m-d') . '.xls');
    ?>
    <table border="1">
        <tr>
            <th>Adm/Mem No</th>
            <th>Name</th>
            <th>Designation</th>
            <th>Category</th>
            <th>Class/Dept</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Status</th>
            <th>Admission Date</th>
            <th>Active Books</th>
            <th>Total Issued</th>
            <th>Fines</th>
            <th>Deposit</th>
        </tr>
        <?php
        if ($selected && is_array($selected) && count($selected) > 0) {
            $placeholders = implode(',', array_fill(0, count($selected), '?'));
            $sql = "SELECT * FROM members WHERE admno IN ($placeholders) ORDER BY name";
            $stmt = $db->prepare($sql);
            $stmt->execute($selected);
            $members = $stmt->fetchAll();
        } else {
            $members = $db->query("SELECT * FROM members ORDER BY name")->fetchAll();
        }
        foreach ($members as $m): ?>
        <tr>
            <td><?= htmlspecialchars($m['admno']) ?></td>
            <td><?= htmlspecialchars($m['name']) ?></td>
            <td><?= htmlspecialchars($m['designation'] ?? '') ?></td>
            <td><?= htmlspecialchars($m['member_category'] ?? '') ?></td>
            <td><?= htmlspecialchars($m['class'] ?? '') ?></td>
            <td><?= htmlspecialchars($m['phone'] ?? '') ?></td>
            <td><?= htmlspecialchars($m['email'] ?? '') ?></td>
            <td><?= ($m['status'] ?? 'active') === 'active' ? 'Active' : 'Inactive' ?></td>
            <td><?= $m['admission_date'] ?? '' ?></td>
            <td><?= $m['active_books'] ?? 0 ?></td>
            <td><?= $m['total_issued'] ?? 0 ?></td>
            <td><?= $m['total_fines'] ?? 0 ?></td>
            <td><?= $m['security_deposit'] ?? 0 ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <?php
    exit;
}

// ========== HANDLE EDIT FETCH ==========
$editMember = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$_GET['edit']]);
    $editMember = $stmt->fetch();
}

// ========== HANDLE BULK ACTIONS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid CSRF token", "danger");
        header("Location: members.php");
        exit;
    }
    
    $selected = $_POST['selected_members'] ?? [];
    if (empty($selected)) {
        showToast("No members selected", "warning");
        header("Location: members.php");
        exit;
    }
    
    $placeholders = implode(',', array_fill(0, count($selected), '?'));
    
    if ($_POST['bulk_action'] === 'delete') {
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno IN ($placeholders)");
        $checkStmt->execute($selected);
        $hasRecords = $checkStmt->fetchColumn();
        
        if ($hasRecords > 0) {
            showToast("Cannot delete members with circulation history. Use 'Set Inactive' instead.", "warning");
        } else {
            $photoStmt = $db->prepare("SELECT photo_path FROM members WHERE admno IN ($placeholders)");
            $photoStmt->execute($selected);
            while ($member = $photoStmt->fetch()) {
                if ($member['photo_path']) {
                    $fullPath = BASE_PATH . '/' . ltrim($member['photo_path'], '/');
                    if (file_exists($fullPath)) {
                        unlink($fullPath);
                    }
                }
                logMemberActivity($db, $member['admno'] ?? '', 'DELETED', 'Member deleted by admin');
            }
            $deleteStmt = $db->prepare("DELETE FROM members WHERE admno IN ($placeholders)");
            $deleteStmt->execute($selected);
            showToast("Selected members deleted successfully", "success");
            logActivity($_SESSION['username'], 'BULK_MEMBER_DELETE', "Deleted members: " . implode(',', $selected));
        }
    } elseif ($_POST['bulk_action'] === 'deactivate') {
        $stmt = $db->prepare("UPDATE members SET status = 'inactive', updated_at = datetime('now') WHERE admno IN ($placeholders)");
        $stmt->execute($selected);
        foreach ($selected as $admno) {
            logMemberActivity($db, $admno, 'DEACTIVATED', 'Member deactivated by admin');
        }
        showToast("Selected members deactivated", "success");
        logActivity($_SESSION['username'], 'BULK_MEMBER_DEACTIVATE', "Deactivated members: " . implode(',', $selected));
        
    } elseif ($_POST['bulk_action'] === 'activate') {
        $stmt = $db->prepare("UPDATE members SET status = 'active', updated_at = datetime('now') WHERE admno IN ($placeholders)");
        $stmt->execute($selected);
        foreach ($selected as $admno) {
            logMemberActivity($db, $admno, 'ACTIVATED', 'Member activated by admin');
        }
        showToast("Selected members activated", "success");
        logActivity($_SESSION['username'], 'BULK_MEMBER_ACTIVATE', "Activated members: " . implode(',', $selected));
        
    } elseif ($_POST['bulk_action'] === 'export') {
        $ids = implode(',', $selected);
        header("Location: members.php?export=csv&ids=$ids");
        exit;
    } elseif ($_POST['bulk_action'] === 'send_email') {
        $emailStmt = $db->prepare("SELECT email, name FROM members WHERE admno IN ($placeholders) AND email IS NOT NULL AND email != ''");
        $emailStmt->execute($selected);
        $emails = $emailStmt->fetchAll();
        if (!empty($emails)) {
            $emailList = array_column($emails, 'email');
            showToast("Email sent to " . count($emailList) . " members", "success");
            logActivity($_SESSION['username'], 'BULK_EMAIL', "Sent email to members: " . implode(',', $selected));
        } else {
            showToast("No valid email addresses found", "warning");
        }
    }
    
    header("Location: members.php");
    exit;
}

// ========== HANDLE SINGLE DELETE ==========
if (isset($_GET['delete'])) {
    $check = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ?");
    $check->execute([$_GET['delete']]);
    $anyRecords = $check->fetchColumn();
    
    if ($anyRecords > 0) {
        showToast("Cannot delete member with circulation history. Set status to inactive instead.", "warning");
    } else {
        $stmt = $db->prepare("SELECT photo_path FROM members WHERE admno = ?");
        $stmt->execute([$_GET['delete']]);
        $member = $stmt->fetch();
        if ($member && $member['photo_path']) {
            $fullPath = BASE_PATH . '/' . ltrim($member['photo_path'], '/');
            if (file_exists($fullPath)) {
                unlink($fullPath);
            }
        }
        logMemberActivity($db, $_GET['delete'], 'DELETED', 'Member deleted by admin');
        $stmt = $db->prepare("DELETE FROM members WHERE admno = ?");
        $stmt->execute([$_GET['delete']]);
        showToast("Member deleted successfully", "success");
        logActivity($_SESSION['username'], 'MEMBER_DELETE', "Deleted member: {$_GET['delete']}");
    }
    header("Location: members.php");
    exit;
}

// ========== HANDLE FORM SUBMISSION ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['add_member']) || isset($_POST['update_member']))) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid CSRF token", "danger");
        header("Location: members.php");
        exit;
    }
    
    try {
        $photoPath = $_POST['existing_photo'] ?? '';
        
        if (isset($_FILES['member_photo']) && $_FILES['member_photo']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $fileType = mime_content_type($_FILES['member_photo']['tmp_name']);
            if (!in_array($fileType, $allowedTypes)) {
                throw new Exception("Invalid file type. Only JPG, PNG, GIF, WEBP allowed.");
            }
            if ($_FILES['member_photo']['size'] > 5 * 1024 * 1024) {
                throw new Exception("File too large. Max 5MB.");
            }
            if (!is_dir(MEMBER_PHOTO_DIR)) {
                mkdir(MEMBER_PHOTO_DIR, 0777, true);
            }
            $newPhoto = uploadFile($_FILES['member_photo'], MEMBER_PHOTO_DIR, 'member_' . $_POST['admno']);
            if ($newPhoto) {
                if ($photoPath && file_exists($photoPath)) unlink($photoPath);
                $photoPath = 'uploads/members/' . basename($newPhoto);
            }
        }
        
        $admno = trim($_POST['admno']);
        $name = trim($_POST['name']);
        $designation = trim($_POST['designation'] ?? '');
        $general_id = trim($_POST['general_id'] ?? '');
        $member_category = $_POST['member_category'] ?? 'Student';
        $class = trim($_POST['class'] ?? '');
        $division = trim($_POST['division'] ?? '');
        $roll_no = trim($_POST['roll_no'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $parent_phone = trim($_POST['parent_phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
        $gender = $_POST['gender'] ?? '';
        $blood_group = $_POST['blood_group'] ?? '';
        $security_deposit = floatval($_POST['security_deposit'] ?? 0);
        $membership_expiry = !empty($_POST['membership_expiry']) ? $_POST['membership_expiry'] : null;
        $emergency_contact = trim($_POST['emergency_contact'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        $nationality = trim($_POST['nationality'] ?? '');
        $religion = trim($_POST['religion'] ?? '');
        $marital_status = $_POST['marital_status'] ?? '';
        $occupation = trim($_POST['occupation'] ?? '');
        $company_name = trim($_POST['company_name'] ?? '');
        $website = trim($_POST['website'] ?? '');
        $membership_type = $_POST['membership_type'] ?? 'standard';
        $discount_rate = floatval($_POST['discount_rate'] ?? 0);
        
        if (isset($_POST['update_member'])) {
            $status = $_POST['status'] ?? 'active';
            $stmt = $db->prepare("UPDATE members SET 
                name = ?, designation = ?, member_category = ?, class = ?, division = ?, roll_no = ?,
                email = ?, phone = ?, parent_phone = ?, address = ?, dob = ?,
                gender = ?, blood_group = ?, photo_path = ?, status = ?,
                general_id = ?, security_deposit = ?, membership_expiry = ?, 
                emergency_contact = ?, notes = ?, nationality = ?, religion = ?,
                marital_status = ?, occupation = ?, company_name = ?, website = ?,
                membership_type = ?, discount_rate = ?, updated_at = datetime('now')
                WHERE admno = ?");
            $stmt->execute([
                $name, $designation, $member_category, $class, $division, $roll_no,
                $email, $phone, $parent_phone, $address, $dob,
                $gender, $blood_group, $photoPath, $status,
                $general_id, $security_deposit, $membership_expiry,
                $emergency_contact, $notes, $nationality, $religion,
                $marital_status, $occupation, $company_name, $website,
                $membership_type, $discount_rate, $admno
            ]);
            logMemberActivity($db, $admno, 'UPDATED', 'Member details updated');
            showToast("Member updated successfully", "success");
            logActivity($_SESSION['username'], 'MEMBER_UPDATE', "Updated member: $admno");
            
            header("Location: members.php");
            exit;
            
        } elseif (isset($_POST['add_member'])) {
            $check = $db->prepare("SELECT COUNT(*) FROM members WHERE admno = ?");
            $check->execute([$admno]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Member number already exists.");
            }
            
            $admission_date = !empty($_POST['admission_date']) ? $_POST['admission_date'] : date('Y-m-d');
            
            $stmt = $db->prepare("INSERT INTO members (
                admno, name, designation, member_category, class, division, roll_no, 
                email, phone, parent_phone, address, dob, gender, blood_group, 
                photo_path, status, admission_date, general_id,
                security_deposit, membership_expiry, emergency_contact, notes,
                nationality, religion, marital_status, occupation, company_name,
                website, membership_type, discount_rate, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
            $stmt->execute([
                $admno, $name, $designation, $member_category, $class, $division, $roll_no,
                $email, $phone, $parent_phone, $address, $dob, $gender, $blood_group,
                $photoPath, $admission_date, $general_id,
                $security_deposit, $membership_expiry, $emergency_contact, $notes,
                $nationality, $religion, $marital_status, $occupation, $company_name,
                $website, $membership_type, $discount_rate
            ]);
            logMemberActivity($db, $admno, 'ADDED', 'New member added');
            showToast("Member added successfully", "success");
            logActivity($_SESSION['username'], 'MEMBER_ADD', "Added member: $admno");
            
            header("Location: members.php");
            exit;
        }
    } catch (Exception $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// ========== BUILD SEARCH/FILTER CONDITIONS ==========
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$classFilter = $_GET['class_filter'] ?? '';
$genderFilter = $_GET['gender_filter'] ?? '';
$expiryFilter = $_GET['expiry_filter'] ?? '';
$membershipType = $_GET['membership_type'] ?? '';
$ageRange = $_GET['age_range'] ?? '';
$sortBy = $_GET['sort_by'] ?? 'created_at';
$sortOrder = $_GET['sort_order'] ?? 'DESC';

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (admno LIKE ? OR name LIKE ? OR designation LIKE ? OR class LIKE ? OR phone LIKE ? OR email LIKE ? OR general_id LIKE ? OR company_name LIKE ? OR occupation LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like, $like, $like, $like, $like, $like]);
}
if ($category && $category !== 'all') {
    $where .= " AND member_category = ?";
    $params[] = $category;
}
if ($status && $status !== 'all') {
    $where .= " AND status = ?";
    $params[] = $status;
}
if ($classFilter) {
    $where .= " AND class = ?";
    $params[] = $classFilter;
}
if ($genderFilter && $genderFilter !== 'all') {
    $where .= " AND gender = ?";
    $params[] = $genderFilter;
}
if ($membershipType && $membershipType !== 'all') {
    $where .= " AND membership_type = ?";
    $params[] = $membershipType;
}
if ($expiryFilter) {
    if ($expiryFilter === 'expired') {
        $where .= " AND membership_expiry IS NOT NULL AND date(membership_expiry) < date('now')";
    } elseif ($expiryFilter === 'expiring_soon') {
        $where .= " AND membership_expiry IS NOT NULL AND date(membership_expiry) BETWEEN date('now') AND date('now', '+30 days')";
    } elseif ($expiryFilter === 'valid') {
        $where .= " AND (membership_expiry IS NULL OR date(membership_expiry) >= date('now'))";
    }
}
if ($ageRange) {
    if ($ageRange === 'under18') {
        $where .= " AND dob IS NOT NULL AND (strftime('%Y', 'now') - strftime('%Y', dob)) < 18";
    } elseif ($ageRange === '18to25') {
        $where .= " AND dob IS NOT NULL AND (strftime('%Y', 'now') - strftime('%Y', dob)) BETWEEN 18 AND 25";
    } elseif ($ageRange === '26to40') {
        $where .= " AND dob IS NOT NULL AND (strftime('%Y', 'now') - strftime('%Y', dob)) BETWEEN 26 AND 40";
    } elseif ($ageRange === 'over40') {
        $where .= " AND dob IS NOT NULL AND (strftime('%Y', 'now') - strftime('%Y', dob)) > 40";
    }
}

// ========== GET UNIQUE CLASSES ==========
$classesStmt = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class");
$uniqueClasses = $classesStmt->fetchAll(PDO::FETCH_COLUMN);

// ========== PAGINATION ==========
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countSql = "SELECT COUNT(*) FROM members WHERE $where";
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalMembers = $countStmt->fetchColumn();
$totalPages = ceil($totalMembers / $perPage);

// ========== FETCH MEMBERS ==========
$sql = "SELECT m.*, 
        (SELECT COUNT(*) FROM circulation WHERE admno = m.admno AND return_date IS NULL) as active_books,
        (SELECT COUNT(*) FROM circulation WHERE admno = m.admno) as total_issued,
        (SELECT COALESCE(SUM(fine),0) FROM circulation WHERE admno = m.admno) as total_fines,
        (SELECT COUNT(*) FROM circulation WHERE admno = m.admno AND return_date IS NULL AND due_date < date('now')) as overdue_books,
        (SELECT COUNT(*) FROM member_activity_log WHERE admno = m.admno) as activity_count
        FROM members m 
        WHERE $where 
        ORDER BY m.$sortBy $sortOrder
        LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$members = $stmt->fetchAll();

// ========== STATISTICS ==========
$totalMembersCount = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$activeMembersCount = $db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
$totalActiveIssues = $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
$expiredMemberships = $db->query("SELECT COUNT(*) FROM members WHERE membership_expiry IS NOT NULL AND date(membership_expiry) < date('now')")->fetchColumn();
$totalSecurityDeposit = $db->query("SELECT COALESCE(SUM(security_deposit),0) FROM members")->fetchColumn();
$todayMembers = $db->query("SELECT COUNT(*) FROM members WHERE date(created_at) = date('now')")->fetchColumn();
$membersWithFines = $db->query("SELECT COUNT(*) FROM members WHERE total_fines > 0")->fetchColumn();
$totalFines = $db->query("SELECT COALESCE(SUM(total_fines),0) FROM members")->fetchColumn();
$membersWithOverdue = $db->query("SELECT COUNT(*) FROM members WHERE overdue_books > 0")->fetchColumn();

$allCategories = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
if (empty($allCategories)) $allCategories = $memberCategories;

// ========== MEMBERSHIP TYPES ==========
$membershipTypes = ['standard', 'premium', 'vip', 'student', 'staff', 'corporate', 'lifetime'];

renderHeader('Member Management');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f6f9; 
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: var(--gradient-primary);
            border-radius: var(--radius-card);
            padding: 20px 20px 20px 70px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
            cursor: default;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }
        
        /* ===== FILTER CARD ===== */
        .filter-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 20px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }
        .filter-card:hover {
            box-shadow: var(--shadow-hover);
        }
        
        /* ===== TABLE CONTAINER ===== */
        .table-container {
            background: white;
            border-radius: var(--radius-card);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .table-container .table {
            margin-bottom: 0;
        }
        .table-container thead th {
            background: var(--gradient-primary);
            color: white;
            border: none;
            padding: 12px 15px;
            font-weight: 600;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 5;
        }
        .table-container thead th a {
            color: white;
            text-decoration: none;
        }
        .table-container tbody tr {
            transition: all 0.2s ease;
        }
        .table-container tbody tr:hover {
            background: rgba(30, 60, 114, 0.05);
        }
        .table-container tbody td {
            padding: 10px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* ===== MODALS - UNIFIED ===== */
        .modal-content {
            border-radius: var(--radius-card);
            border: none;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        }
        .modal-header {
            background: var(--gradient-primary);
            color: white;
            border-radius: var(--radius-card) var(--radius-card) 0 0;
            padding: 20px 25px;
            border: none;
        }
        .modal-header .btn-close {
            filter: brightness(0) invert(1);
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 2px 15px;
        }
        .modal-dialog-scrollable .modal-body {
            max-height: calc(95vh - 130px);
            overflow-y: auto;
            padding: 25px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar {
            width: 6px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb:hover {
            background: var(--primary-light);
        }
        
        /* ===== MEMBER PHOTO STYLES ===== */
        .member-photo-thumb {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .member-photo-thumb:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .member-photo-large {
            width: 120px;
            height: 120px;
            object-fit: cover;
            border-radius: 12px;
            border: 3px solid var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .default-avatar-thumb {
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 50%;
            color: white;
            font-size: 1.5rem;
        }
        .default-avatar-large {
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 12px;
            color: white;
            font-size: 4rem;
        }
        
        /* ===== STATUS BADGES ===== */
        .badge-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .badge-active { background: #d4edda; color: #155724; }
        .badge-inactive { background: #f8d7da; color: #721c24; }
        
        /* ===== CAMERA VIEW ===== */
        .camera-view {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 10px;
            margin-top: 10px;
            text-align: center;
        }
        .camera-view video {
            width: 100%;
            max-width: 320px;
            border-radius: 8px;
            background: #000;
        }
        
        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .member-photo-thumb { width: 35px; height: 35px; }
            .member-photo-large { width: 80px; height: 80px; }
            .default-avatar-large { width: 80px; height: 80px; font-size: 2.5rem; }
            .modal-dialog-scrollable .modal-body { max-height: calc(90vh - 120px); padding: 15px; }
            .table-container { overflow-x: auto; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-value { font-size: 18px; }
            .modal-body { padding: 15px; }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .table-container thead th {
                background: #333 !important;
                color: white !important;
            }
            .filter-card { display: none !important; }
            .modal { display: none !important; }
        }
        
        /* ===== SELECT2 OVERRIDE ===== */
        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 8px;
            border-color: #ced4da;
        }
        .select2-container--bootstrap-5 .select2-selection:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
        
        /* ===== SORTABLE HEADERS ===== */
        .sortable {
            cursor: pointer;
            user-select: none;
        }
        .sortable:hover {
            background: rgba(255,255,255,0.1);
        }
        .sortable .fas {
            margin-left: 5px;
        }
        
        /* ===== TABLE STICKY HEADER ===== */
        .table thead th {
            position: sticky;
            top: 0;
            z-index: 10;
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- ===== PAGE HEADER ===== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-users me-2"></i> Member Management</h2>
            <p class="text-muted small">Manage library members, track activity, and handle memberships</p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                <i class="fas fa-plus"></i> Add Member
            </button>
            <div class="btn-group">
                <button type="button" class="btn btn-info text-white btn-sm dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-download"></i> Export
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="?export=csv"><i class="fas fa-file-csv"></i> CSV</a></li>
                    <li><a class="dropdown-item" href="?export=pdf"><i class="fas fa-file-pdf"></i> PDF</a></li>
                    <li><a class="dropdown-item" href="?export=excel"><i class="fas fa-file-excel"></i> Excel</a></li>
                </ul>
            </div>
        </div>
    </div>

    <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='members.php'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-users"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalMembersCount) ?></div>
                    <div class="stat-label">Total Members</div>
                    <div class="stat-sub"><i class="fas fa-user-plus"></i> All registered</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='members.php?status=active'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-user-check"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($activeMembersCount) ?></div>
                    <div class="stat-label">Active</div>
                    <div class="stat-sub"><i class="fas fa-check-circle"></i> Currently active</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='members.php?status=inactive'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-user-slash"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalMembersCount - $activeMembersCount) ?></div>
                    <div class="stat-label">Inactive</div>
                    <div class="stat-sub"><i class="fas fa-clock"></i> Not active</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='../circulation/'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-book-reader"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalActiveIssues) ?></div>
                    <div class="stat-label">Active Issues</div>
                    <div class="stat-sub"><i class="fas fa-book"></i> Books on loan</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='members.php?expiry_filter=expired'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-clock"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($membersWithOverdue) ?></div>
                    <div class="stat-label">Overdue Books</div>
                    <div class="stat-sub"><i class="fas fa-exclamation-triangle"></i> Late returns</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card" onclick="window.location.href='members.php?sort_by=total_fines&sort_order=DESC'" style="cursor:pointer;">
                <div class="stat-icon-wrapper"><i class="fas fa-money-bill-wave"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= formatCurrency($totalFines) ?></div>
                    <div class="stat-label">Total Fines</div>
                    <div class="stat-sub"><i class="fas fa-coins"></i> Outstanding fines</div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== FILTER CARD ===== -->
    <div class="filter-card no-print">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
            <h6 class="fw-bold" style="color: var(--primary-color);"><i class="fas fa-filter me-2"></i> Advanced Filters</h6>
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-danger" type="button" id="clearFiltersBtn">
                    <i class="fas fa-eraser"></i> Clear Filters
                </button>
                <button class="btn btn-sm btn-outline-primary" type="button" data-bs-toggle="collapse" data-bs-target="#advancedFilters">
                    <i class="fas fa-chevron-down"></i> More Filters
                </button>
            </div>
        </div>
        <form method="get" class="row g-2" id="filterForm">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search by ID, Name, Designation, Class, Phone, Email..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="class_filter" class="form-select">
                    <option value="">All Classes/Dept</option>
                    <?php foreach ($uniqueClasses as $cls): ?>
                        <option value="<?= htmlspecialchars($cls) ?>" <?= $classFilter === $cls ? 'selected' : '' ?>><?= htmlspecialchars($cls) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="expiry_filter" class="form-select">
                    <option value="">Membership Status</option>
                    <option value="expired" <?= $expiryFilter === 'expired' ? 'selected' : '' ?>>Expired</option>
                    <option value="expiring_soon" <?= $expiryFilter === 'expiring_soon' ? 'selected' : '' ?>>Expiring Soon</option>
                    <option value="valid" <?= $expiryFilter === 'valid' ? 'selected' : '' ?>>Valid Membership</option>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i></button>
            </div>
            <!-- Advanced Filters (collapsible) -->
            <div id="advancedFilters" class="collapse w-100 mt-2">
                <div class="row g-2">
                    <div class="col-md-2">
                        <select name="gender_filter" class="form-select">
                            <option value="">All Genders</option>
                            <option value="Male" <?= $genderFilter === 'Male' ? 'selected' : '' ?>>Male</option>
                            <option value="Female" <?= $genderFilter === 'Female' ? 'selected' : '' ?>>Female</option>
                            <option value="Other" <?= $genderFilter === 'Other' ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="membership_type" class="form-select">
                            <option value="">Membership Type</option>
                            <?php foreach ($membershipTypes as $type): ?>
                                <option value="<?= $type ?>" <?= $membershipType === $type ? 'selected' : '' ?>><?= ucfirst($type) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="age_range" class="form-select">
                            <option value="">Age Range</option>
                            <option value="under18" <?= $ageRange === 'under18' ? 'selected' : '' ?>>Under 18</option>
                            <option value="18to25" <?= $ageRange === '18to25' ? 'selected' : '' ?>>18 - 25</option>
                            <option value="26to40" <?= $ageRange === '26to40' ? 'selected' : '' ?>>26 - 40</option>
                            <option value="over40" <?= $ageRange === 'over40' ? 'selected' : '' ?>>Over 40</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="sort_by" class="form-select">
                            <option value="created_at" <?= $sortBy === 'created_at' ? 'selected' : '' ?>>Sort: Created Date</option>
                            <option value="name" <?= $sortBy === 'name' ? 'selected' : '' ?>>Sort: Name</option>
                            <option value="admno" <?= $sortBy === 'admno' ? 'selected' : '' ?>>Sort: Member No</option>
                            <option value="admission_date" <?= $sortBy === 'admission_date' ? 'selected' : '' ?>>Sort: Admission Date</option>
                            <option value="total_issued" <?= $sortBy === 'total_issued' ? 'selected' : '' ?>>Sort: Total Issued</option>
                            <option value="total_fines" <?= $sortBy === 'total_fines' ? 'selected' : '' ?>>Sort: Total Fines</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <select name="sort_order" class="form-select">
                            <option value="DESC" <?= $sortOrder === 'DESC' ? 'selected' : '' ?>>Order: Descending</option>
                            <option value="ASC" <?= $sortOrder === 'ASC' ? 'selected' : '' ?>>Order: Ascending</option>
                        </select>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- ===== MEMBER TABLE ===== -->
    <div class="table-container">
        <div class="d-flex flex-wrap justify-content-between align-items-center p-3 bg-white border-bottom">
            <span><i class="fas fa-list text-primary me-1"></i> Member Directory</span>
            <span class="badge bg-secondary"><?= count($members) ?> of <?= $totalMembers ?> members</span>
        </div>
        
        <form method="post" id="bulkActionForm" onsubmit="return confirmBulkAction()" class="p-3">
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            
            <div class="mb-3 d-flex flex-wrap gap-2 no-print">
                <div class="form-check">
                    <input type="checkbox" id="selectAllCheckbox" class="form-check-input">
                    <label for="selectAllCheckbox" class="form-check-label">Select All</label>
                </div>
                <select name="bulk_action" class="form-select w-auto" required>
                    <option value="">Bulk Actions</option>
                    <option value="delete">Delete Selected</option>
                    <option value="deactivate">Set Inactive</option>
                    <option value="activate">Set Active</option>
                    <option value="export">Export Selected</option>
                    <option value="send_email">Send Email</option>
                </select>
                <button type="submit" class="btn btn-secondary">Apply</button>
                <div class="ms-auto">
                    <a href="?export=csv" class="btn btn-info text-white">
                        <i class="fas fa-download"></i> Export All
                    </a>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th style="width: 30px;"><input type="checkbox" id="selectAllCheckbox2" onchange="document.querySelectorAll('.member-checkbox').forEach(cb => cb.checked = this.checked)"></th>
                            <th style="width: 60px;">Photo</th>
                            <th class="sortable" data-sort="admno">Member No <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="name">Name <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="member_category">Category <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="class">Class/Dept <i class="fas fa-sort"></i></th>
                            <th>Contact</th>
                            <th class="sortable" data-sort="active_books">Active <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="total_issued">Issued <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="total_fines">Fines <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="admission_date">Added <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="membership_expiry">Expiry <i class="fas fa-sort"></i></th>
                            <th class="sortable" data-sort="status">Status <i class="fas fa-sort"></i></th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($members as $m): 
                            $fineRate = $fineRates[$m['member_category']] ?? $settings['fine_per_day'] ?? 2;
                            $expiryClass = '';
                            if (!empty($m['membership_expiry'])) {
                                $expiryDate = new DateTime($m['membership_expiry']);
                                $now = new DateTime();
                                if ($expiryDate < $now) $expiryClass = 'bg-danger text-white';
                                elseif ($expiryDate->diff($now)->days <= 30) $expiryClass = 'bg-warning';
                            }
                            $photoUrl = getMemberPhotoUrl($m['photo_path'] ?? '');
                            $photoBase64 = getMemberPhotoBase64($m['photo_path'] ?? '');
                            $age = getMemberAge($m['dob'] ?? '');
                            $hasOverdue = ($m['overdue_books'] ?? 0) > 0;
                        ?>
                        <tr class="<?= $hasOverdue ? 'table-danger' : '' ?>">
                            <td class="text-center">
                                <input type="checkbox" name="selected_members[]" value="<?= htmlspecialchars($m['admno']) ?>" class="member-checkbox">
                            </td>
                            <td class="text-center">
                                <?php if ($photoBase64): ?>
                                    <img src="<?= $photoBase64 ?>" class="member-photo-thumb" alt="Member Photo" 
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-thumb').style.display='flex';">
                                    <div class="default-avatar-thumb" style="display:none;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php elseif ($photoUrl): ?>
                                    <img src="<?= $photoUrl ?>" class="member-photo-thumb" alt="Member Photo"
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-thumb').style.display='flex';">
                                    <div class="default-avatar-thumb" style="display:none;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php else: ?>
                                    <div class="default-avatar-thumb">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><strong><?= htmlspecialchars($m['admno']) ?></strong></td>
                            <td>
                                <strong><?= htmlspecialchars($m['name']) ?></strong>
                                <?php if (!empty($m['designation'])): ?>
                                    <br><small class="text-muted"><i class="fas fa-briefcase"></i> <?= htmlspecialchars($m['designation']) ?></small>
                                <?php endif; ?>
                                <?php if ($age !== '-'): ?>
                                    <br><small class="text-muted"><i class="fas fa-calendar-alt"></i> Age: <?= $age ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($m['member_category'] ?? 'Student') ?>
                                <br><small class="text-muted"><?= formatCurrency($fineRate) ?>/day</small>
                                <?php if (!empty($m['membership_type']) && $m['membership_type'] !== 'standard'): ?>
                                    <br><span class="badge bg-info"><?= ucfirst($m['membership_type']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= $m['class'] ? htmlspecialchars($m['class']) : '-' ?>
                                <?php if (!empty($m['division'])): ?>
                                    <br><small class="text-muted"><?= htmlspecialchars($m['division']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($m['phone'])): ?>
                                    <i class="fas fa-phone"></i> <?= htmlspecialchars($m['phone']) ?><br>
                                <?php endif; ?>
                                <?php if (!empty($m['email'])): ?>
                                    <small><i class="fas fa-envelope"></i> <?= htmlspecialchars(substr($m['email'], 0, 20)) ?></small>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= ($m['active_books'] ?? 0) > 0 ? 'bg-warning' : 'bg-secondary' ?>">
                                    <?= $m['active_books'] ?? 0 ?>
                                </span>
                                <?php if ($hasOverdue): ?>
                                    <br><span class="badge bg-danger">Overdue: <?= $m['overdue_books'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-info"><?= $m['total_issued'] ?? 0 ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-danger"><?= formatCurrency($m['total_fines'] ?? 0) ?></span>
                            </td>
                            <td>
                                <?php if (!empty($m['created_at'])): ?>
                                    <small><?= date('d-m-Y', strtotime($m['created_at'])) ?></small>
                                    <?php if (!empty($m['total_visits'])): ?>
                                        <br><small class="text-muted">Visits: <?= $m['total_visits'] ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!empty($m['membership_expiry'])): ?>
                                    <span class="badge <?= $expiryClass ?>"><?= date('Y-m-d', strtotime($m['membership_expiry'])) ?></span>
                                    <?php if ($expiryClass === 'bg-danger'): ?>
                                        <br><small class="text-danger">Expired</small>
                                    <?php elseif ($expiryClass === 'bg-warning'): ?>
                                        <br><small class="text-warning">Expiring soon</small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Never</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= ($m['status'] ?? 'active') === 'active' ? 'badge-active' : 'badge-inactive' ?>">
                                    <?= ($m['status'] ?? 'active') === 'active' ? 'Active' : 'Inactive' ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="?edit=<?= urlencode($m['admno']) ?>" class="btn btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="../circulation/history.php?admno=<?= urlencode($m['admno']) ?>" class="btn btn-info" title="History">
                                        <i class="fas fa-history"></i>
                                    </a>
                                    <button type="button" class="btn btn-secondary" title="Barcode" onclick="generateBarcode('<?= htmlspecialchars($m['admno']) ?>')">
                                        <i class="fas fa-barcode"></i>
                                    </button>
                                    <button type="button" class="btn btn-primary" title="Activity Log" onclick="viewActivity('<?= htmlspecialchars($m['admno']) ?>')">
                                        <i class="fas fa-activity"></i>
                                    </button>
                                    <?php if (($m['total_issued'] ?? 0) == 0): ?>
                                        <a href="?delete=<?= urlencode($m['admno']) ?>" class="btn btn-danger" onclick="return confirm('Delete this member permanently? This cannot be undone.')" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-danger" disabled title="Cannot delete - has circulation history">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($members)): ?> 
                            <tr>
                                <td colspan="14" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                    No members found. 
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#addMemberModal">Add your first member</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($members)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="9" class="text-end">Totals:</td>
                            <td><?= formatCurrency(array_sum(array_column($members, 'total_fines'))) ?></td>
                            <td colspan="4"></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <nav aria-label="Page navigation" class="mt-3">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>">Previous</a>
                    </li>
                    <?php 
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    for ($i = $startPage; $i <= $endPage; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>">Next</a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- ========== ADD MEMBER MODAL ========== -->
<div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMemberModalLabel"><i class="fas fa-user-plus me-2"></i>Add New Member</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data" id="addMemberForm">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="row">
                        <!-- Personal Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-id-card me-2"></i>Personal Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adm/Mem Number *</label>
                            <input type="text" name="admno" class="form-control" required placeholder="e.g., MEM001">
                            <small class="text-muted">Unique identifier</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">General ID Number</label>
                            <input type="text" name="general_id" class="form-control" placeholder="External ID">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Designation</label>
                            <input type="text" name="designation" class="form-control" placeholder="e.g., Student, Teacher, Librarian, Manager">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Category *</label>
                            <select name="member_category" class="form-select" required>
                                <?php foreach ($memberCategories as $cat): ?>
                                    <option value="<?= $cat ?>"><?= $cat ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Class/Dept</label>
                            <input type="text" name="class" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Division/Course</label>
                            <input type="text" name="division" class="form-control">
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-address-book me-2"></i>Contact Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Parent/Guardian Phone</label>
                            <input type="tel" name="parent_phone" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Emergency Contact</label>
                            <input type="text" name="emergency_contact" class="form-control" placeholder="Name & Number">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"></textarea>
                        </div>
                        
                        <!-- Personal Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-user-circle me-2"></i>Personal Details</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <option>A+</option><option>A-</option><option>B+</option><option>B-</option>
                                <option>O+</option><option>O-</option><option>AB+</option><option>AB-</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nationality</label>
                            <input type="text" name="nationality" class="form-control">
                        </div>
                        
                        <!-- Additional Info -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-address-card me-2"></i>Additional Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Religion</label>
                            <input type="text" name="religion" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Marital Status</label>
                            <select name="marital_status" class="form-select">
                                <option value="">Select</option>
                                <option>Single</option>
                                <option>Married</option>
                                <option>Divorced</option>
                                <option>Widowed</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Occupation</label>
                            <input type="text" name="occupation" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Company/Organization</label>
                            <input type="text" name="company_name" class="form-control">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Website</label>
                            <input type="url" name="website" class="form-control" placeholder="https://example.com">
                        </div>
                        
                        <!-- Membership Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-calendar-alt me-2"></i>Membership Details</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Admission Date</label>
                            <input type="date" name="admission_date" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Membership Expiry Date</label>
                            <input type="date" name="membership_expiry" class="form-control">
                            <small class="text-muted">Leave empty for unlimited</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Security Deposit</label>
                            <div class="input-group">
                                <span class="input-group-text"><?= $currencySymbol ?></span>
                                <input type="number" step="0.01" name="security_deposit" class="form-control" value="0">
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Membership Type</label>
                            <select name="membership_type" class="form-select">
                                <?php foreach ($membershipTypes as $type): ?>
                                    <option value="<?= $type ?>"><?= ucfirst($type) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Discount Rate (%)</label>
                            <input type="number" step="0.01" name="discount_rate" class="form-control" value="0" min="0" max="100">
                        </div>
                        
                        <!-- Photo & Notes -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-camera me-2"></i>Photo & Notes</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Member Photo</label>
                            <div class="d-flex flex-wrap gap-2">
                                <input type="file" name="member_photo" class="form-control w-auto flex-grow-1" accept="image/*" onchange="previewPhoto(this, 'addPhotoPreview')">
                                <button type="button" class="btn btn-secondary" onclick="openCamera('add')">📷 Take Photo</button>
                            </div>
                            <small class="text-muted">Max 5MB. Supported: JPG, PNG, GIF, WEBP</small>
                        </div>
                        <div class="col-md-4 mb-3 text-center">
                            <div id="addPhotoPreview" class="mt-2" style="display:none;">
                                <img id="addPreviewImg" style="width:100px;height:100px;object-fit:cover;border-radius:10px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Any additional notes about this member..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_member" class="btn btn-primary"><i class="fas fa-save me-1"></i> Save Member</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== EDIT MEMBER MODAL ========== -->
<?php if ($editMember): ?>
<div class="modal fade show" id="editMemberModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Member</h5>
                <a href="members.php" class="btn-close btn-close-white"></a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="row">
                        <!-- Personal Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-id-card me-2"></i>Personal Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adm/Mem Number</label>
                            <input type="text" name="admno" class="form-control" value="<?= htmlspecialchars($editMember['admno']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">General ID Number</label>
                            <input type="text" name="general_id" class="form-control" value="<?= htmlspecialchars($editMember['general_id'] ?? '') ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editMember['name']) ?>" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Designation</label>
                            <input type="text" name="designation" class="form-control" value="<?= htmlspecialchars($editMember['designation'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control" value="<?= htmlspecialchars($editMember['roll_no'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Category</label>
                            <select name="member_category" class="form-select">
                                <?php foreach ($memberCategories as $cat): ?>
                                    <option value="<?= $cat ?>" <?= ($editMember['member_category'] ?? 'Student') === $cat ? 'selected' : '' ?>><?= $cat ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Class/Dept</label>
                            <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($editMember['class'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Division/Course</label>
                            <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($editMember['division'] ?? '') ?>">
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-address-book me-2"></i>Contact Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editMember['email'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($editMember['phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Parent/Guardian Phone</label>
                            <input type="tel" name="parent_phone" class="form-control" value="<?= htmlspecialchars($editMember['parent_phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Emergency Contact</label>
                            <input type="text" name="emergency_contact" class="form-control" value="<?= htmlspecialchars($editMember['emergency_contact'] ?? '') ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($editMember['address'] ?? '') ?></textarea>
                        </div>
                        
                        <!-- Personal Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-user-circle me-2"></i>Personal Details</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($editMember['dob'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <?php foreach (['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg): ?>
                                    <option <?= ($editMember['blood_group'] ?? '') === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nationality</label>
                            <input type="text" name="nationality" class="form-control" value="<?= htmlspecialchars($editMember['nationality'] ?? '') ?>">
                        </div>
                        
                        <!-- Additional Info -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-address-card me-2"></i>Additional Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Religion</label>
                            <input type="text" name="religion" class="form-control" value="<?= htmlspecialchars($editMember['religion'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Marital Status</label>
                            <select name="marital_status" class="form-select">
                                <option value="">Select</option>
                                <option <?= ($editMember['marital_status'] ?? '') === 'Single' ? 'selected' : '' ?>>Single</option>
                                <option <?= ($editMember['marital_status'] ?? '') === 'Married' ? 'selected' : '' ?>>Married</option>
                                <option <?= ($editMember['marital_status'] ?? '') === 'Divorced' ? 'selected' : '' ?>>Divorced</option>
                                <option <?= ($editMember['marital_status'] ?? '') === 'Widowed' ? 'selected' : '' ?>>Widowed</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Occupation</label>
                            <input type="text" name="occupation" class="form-control" value="<?= htmlspecialchars($editMember['occupation'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Company/Organization</label>
                            <input type="text" name="company_name" class="form-control" value="<?= htmlspecialchars($editMember['company_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Website</label>
                            <input type="url" name="website" class="form-control" value="<?= htmlspecialchars($editMember['website'] ?? '') ?>">
                        </div>
                        
                        <!-- Membership Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-calendar-alt me-2"></i>Membership Details</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Admission Date</label>
                            <input type="date" name="admission_date" class="form-control" value="<?= htmlspecialchars($editMember['admission_date'] ?? date('Y-m-d')) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Membership Expiry Date</label>
                            <input type="date" name="membership_expiry" class="form-control" value="<?= htmlspecialchars($editMember['membership_expiry'] ?? '') ?>">
                            <small class="text-muted">Leave empty for unlimited</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Security Deposit</label>
                            <div class="input-group">
                                <span class="input-group-text"><?= $currencySymbol ?></span>
                                <input type="number" step="0.01" name="security_deposit" class="form-control" value="<?= htmlspecialchars($editMember['security_deposit'] ?? 0) ?>">
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Membership Type</label>
                            <select name="membership_type" class="form-select">
                                <?php foreach ($membershipTypes as $type): ?>
                                    <option value="<?= $type ?>" <?= ($editMember['membership_type'] ?? 'standard') === $type ? 'selected' : '' ?>><?= ucfirst($type) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Discount Rate (%)</label>
                            <input type="number" step="0.01" name="discount_rate" class="form-control" value="<?= htmlspecialchars($editMember['discount_rate'] ?? 0) ?>" min="0" max="100">
                        </div>
                        
                        <!-- Photo & Notes -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-camera me-2"></i>Photo & Notes</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Member Photo</label>
                            <div class="d-flex flex-wrap gap-2">
                                <input type="file" name="member_photo" class="form-control w-auto flex-grow-1" accept="image/*" onchange="previewPhoto(this, 'editPhotoPreview')">
                                <button type="button" class="btn btn-secondary" onclick="openCamera('edit')">📷 Take Photo</button>
                            </div>
                            <small class="text-muted">Upload new photo to replace existing</small>
                        </div>
                        <div class="col-md-4 mb-3 text-center">
                            <?php 
                            $editPhotoUrl = getMemberPhotoUrl($editMember['photo_path'] ?? '');
                            $editPhotoBase64 = getMemberPhotoBase64($editMember['photo_path'] ?? '');
                            ?>
                            <?php if ($editPhotoBase64): ?>
                                <div id="currentPhoto">
                                    <img src="<?= $editPhotoBase64 ?>" class="member-photo-large" alt="Current Photo" 
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-large-edit').style.display='flex';">
                                    <div class="default-avatar-large-edit" style="display:none;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <input type="hidden" name="existing_photo" value="<?= htmlspecialchars($editMember['photo_path'] ?? '') ?>">
                                    <p class="small text-muted mt-1">Current photo</p>
                                </div>
                            <?php elseif ($editPhotoUrl): ?>
                                <div id="currentPhoto">
                                    <img src="<?= $editPhotoUrl ?>" class="member-photo-large" alt="Current Photo"
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-large-edit').style.display='flex';">
                                    <div class="default-avatar-large-edit" style="display:none;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <input type="hidden" name="existing_photo" value="<?= htmlspecialchars($editMember['photo_path'] ?? '') ?>">
                                    <p class="small text-muted mt-1">Current photo</p>
                                </div>
                            <?php else: ?>
                                <div class="default-avatar-large">
                                    <i class="fas fa-user"></i>
                                </div>
                                <p class="small text-muted mt-1">No photo</p>
                            <?php endif; ?>
                            <div id="editPhotoPreview" class="mt-2" style="display:none;">
                                <img id="editPreviewImg" style="width:100px;height:100px;object-fit:cover;border-radius:10px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editMember['notes'] ?? '') ?></textarea>
                        </div>
                        
                        <!-- Status -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-toggle-on me-2"></i>Status</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="active" <?= ($editMember['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Active</option>
                                <option value="inactive" <?= ($editMember['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="members.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_member" class="btn btn-primary"><i class="fas fa-save me-1"></i> Update Member</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ========== BARCODE MODAL ========== -->
<div class="modal fade" id="barcodeModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-barcode me-2"></i>Member Barcode</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div id="barcodeContainer"></div>
                <p id="barcodeValue" class="mt-2 fw-bold"></p>
                <div class="d-flex justify-content-center gap-2">
                    <button class="btn btn-primary" onclick="printBarcode()">
                        <i class="fas fa-print"></i> Print
                    </button>
                    <button class="btn btn-secondary" onclick="downloadBarcode()">
                        <i class="fas fa-download"></i> Download
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== ACTIVITY LOG MODAL ========== -->
<div class="modal fade" id="activityModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-activity me-2"></i>Member Activity Log</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="activityContent">
                <div class="text-center text-muted py-4">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                    <p>Loading activity log...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== JAVASCRIPT ========== -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
// ========== CONFIRM BULK ACTION ==========
function confirmBulkAction() {
    let action = document.querySelector('select[name="bulk_action"]').value;
    let checked = document.querySelectorAll('.member-checkbox:checked').length;
    if (!action) { 
        alert('Please select an action'); 
        return false; 
    }
    if (checked === 0) { 
        alert('Please select at least one member'); 
        return false; 
    }
    if (action === 'delete') {
        return confirm(`Are you sure you want to delete ${checked} member(s)? This cannot be undone.`);
    }
    if (action === 'deactivate') {
        return confirm(`Deactivate ${checked} member(s)? They will not be able to borrow books.`);
    }
    if (action === 'activate') {
        return confirm(`Activate ${checked} member(s)?`);
    }
    if (action === 'send_email') {
        return confirm(`Send email to ${checked} member(s)?`);
    }
    return true;
}

// ========== SELECT ALL ==========
document.getElementById('selectAllCheckbox')?.addEventListener('change', function(e) {
    document.querySelectorAll('.member-checkbox').forEach(cb => cb.checked = e.target.checked);
});

// ========== PHOTO PREVIEW ==========
function previewPhoto(input, targetId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var previewDiv = document.getElementById(targetId);
            if (previewDiv) {
                previewDiv.style.display = 'block';
                var imgId = targetId.replace('Preview', 'PreviewImg');
                var img = document.getElementById(imgId);
                if (img) {
                    img.src = e.target.result;
                }
            }
            var current = document.getElementById('currentPhoto');
            if (current) current.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ========== CAMERA CAPTURE ==========
let cameraStream = null;
let cameraTarget = null;

function openCamera(target) {
    cameraTarget = target;
    let container = document.getElementById('cameraView-' + target);
    if (!container) {
        let modalId = target === 'add' ? 'addMemberModal' : 'editMemberModal';
        let fileInput = document.querySelector('#' + modalId + ' input[type="file"]');
        if (!fileInput) {
            alert('File input not found');
            return;
        }
        container = document.createElement('div');
        container.id = 'cameraView-' + target;
        container.className = 'camera-view';
        container.innerHTML = `
            <div class="camera-preview" style="position:relative; width:100%; max-width:320px; margin:0 auto;">
                <video id="cameraVideo-${target}" autoplay playsinline style="width:100%; border-radius:8px; background:#000;"></video>
                <canvas id="cameraCanvas-${target}" style="display:none;"></canvas>
                <div class="camera-controls mt-2 text-center">
                    <button type="button" class="btn btn-success btn-sm" onclick="capturePhoto()">Capture</button>
                    <button type="button" class="btn btn-danger btn-sm" onclick="closeCamera()">Cancel</button>
                </div>
            </div>
        `;
        let parentDiv = fileInput.closest('.d-flex');
        if (parentDiv) {
            parentDiv.parentNode.insertBefore(container, parentDiv.nextSibling);
        } else {
            fileInput.parentNode.insertBefore(container, fileInput.nextSibling);
        }
    }
    container.style.display = 'block';
    
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
        .then(function(stream) {
            cameraStream = stream;
            let video = document.getElementById('cameraVideo-' + target);
            video.srcObject = stream;
            video.play();
        })
        .catch(function(err) {
            alert('Camera access denied or not available: ' + err.message);
            closeCamera();
        });
}

function capturePhoto() {
    let target = cameraTarget;
    let video = document.getElementById('cameraVideo-' + target);
    let canvas = document.getElementById('cameraCanvas-' + target);
    let context = canvas.getContext('2d');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    let dataUrl = canvas.toDataURL('image/jpeg', 0.9);
    let blob = dataURLtoBlob(dataUrl);
    let file = new File([blob], 'captured.jpg', { type: 'image/jpeg' });
    let modalId = target === 'add' ? 'addMemberModal' : 'editMemberModal';
    let fileInput = document.querySelector('#' + modalId + ' input[type="file"]');
    if (fileInput) {
        let dt = new DataTransfer();
        dt.items.add(file);
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event('change'));
    }
    closeCamera();
}

function dataURLtoBlob(dataurl) {
    let arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], { type: mime });
}

function closeCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    document.querySelectorAll('.camera-view').forEach(el => el.style.display = 'none');
    document.querySelectorAll('video').forEach(v => v.srcObject = null);
}

// ========== BARCODE GENERATION ==========
function generateBarcode(admno) {
    var container = document.getElementById('barcodeContainer');
    container.innerHTML = '<svg id="barcodeSvg"></svg>';
    document.getElementById('barcodeValue').textContent = admno;
    JsBarcode("#barcodeSvg", admno, { 
        format: "CODE128", 
        lineColor: "#000", 
        width: 2, 
        height: 50, 
        displayValue: false 
    });
    new bootstrap.Modal(document.getElementById('barcodeModal')).show();
}

function printBarcode() {
    var printContents = document.getElementById('barcodeContainer').innerHTML + 
        '<br><div style="text-align:center; font-family: monospace; font-size:16px;">' + 
        document.getElementById('barcodeValue').textContent + '</div>';
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = '<div style="text-align:center; margin-top:50px;">' + printContents + '</div>';
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
}

function downloadBarcode() {
    var svg = document.getElementById('barcodeSvg');
    if (!svg) return;
    var svgData = new XMLSerializer().serializeToString(svg);
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    var svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    var url = URL.createObjectURL(svgBlob);
    img.onload = function() {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        URL.revokeObjectURL(url);
        var link = document.createElement('a');
        link.download = 'barcode_' + document.getElementById('barcodeValue').textContent + '.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    };
    img.src = url;
}

// ========== VIEW ACTIVITY LOG ==========
function viewActivity(admno) {
    var modal = new bootstrap.Modal(document.getElementById('activityModal'));
    var content = document.getElementById('activityContent');
    content.innerHTML = '<div class="text-center text-muted py-4"><i class="fas fa-spinner fa-spin fa-2x"></i><p>Loading activity log...</p></div>';
    modal.show();
    
    fetch('get_activity.php?admno=' + encodeURIComponent(admno))
        .then(response => response.text())
        .then(html => {
            content.innerHTML = html;
        })
        .catch(error => {
            content.innerHTML = '<div class="alert alert-danger">Error loading activity log: ' + error.message + '</div>';
        });
}

// ========== CLEAR FILTERS ==========
document.getElementById('clearFiltersBtn')?.addEventListener('click', function() {
    window.location.href = 'members.php';
});

// ========== SORTABLE HEADERS ==========
document.querySelectorAll('.sortable').forEach(function(th) {
    th.addEventListener('click', function() {
        var sortBy = this.dataset.sort;
        var currentSort = new URLSearchParams(window.location.search).get('sort_by');
        var currentOrder = new URLSearchParams(window.location.search).get('sort_order') || 'DESC';
        var newOrder = (sortBy === currentSort && currentOrder === 'DESC') ? 'ASC' : 'DESC';
        var url = new URL(window.location.href);
        url.searchParams.set('sort_by', sortBy);
        url.searchParams.set('sort_order', newOrder);
        window.location.href = url.href;
    });
});

// ========== ENTER KEY ON FILTERS ==========
document.querySelectorAll('#filterForm input, #filterForm select').forEach(el => {
    el.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('filterForm').submit();
        }
    });
});

// ========== FIX FOR MODAL SCROLLING ON MOBILE ==========
document.addEventListener('DOMContentLoaded', function() {
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        modal.addEventListener('shown.bs.modal', function() {
            document.body.style.overflow = 'hidden';
        });
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.style.overflow = '';
        });
    });
});
</script>
<?php renderFooter(); ?>
</body>
</html>