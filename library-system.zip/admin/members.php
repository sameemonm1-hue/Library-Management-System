<?php
/**
 * Member Management Module - Complete Update
 * Features:
 * - Full member CRUD with all fields
 * - Photo display everywhere (list, edit, view)
 * - Added Date: Created At, Admission Date, Membership Expiry
 * - Advanced search and filters
 * - Bulk operations
 * - Export capabilities
 * - Barcode generation
 * - Responsive design
 * - Fixed modal scrolling
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// ========== ENSURE REQUIRED FUNCTIONS EXIST ==========
if (!function_exists('formatCurrency')) {
    function formatCurrency($amount) {
        global $settings;
        $symbol = $settings['currency_symbol'] ?? '$';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        return $symbol . ' ' . number_format($amount, $decimals);
    }
}

if (!function_exists('getMemberPhotoUrl')) {
    function getMemberPhotoUrl($photoPath) {
        if (empty($photoPath)) {
            return '';
        }
        if (filter_var($photoPath, FILTER_VALIDATE_URL)) {
            return $photoPath;
        }
        $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
        if (file_exists($fullPath)) {
            return getWebImageUrl($photoPath);
        }
        return '';
    }
}

if (!function_exists('getMemberPhotoBase64')) {
    function getMemberPhotoBase64($photoPath) {
        if (empty($photoPath)) {
            return '';
        }
        $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
        if (!file_exists($fullPath)) {
            return '';
        }
        $data = @file_get_contents($fullPath);
        if ($data === false) {
            return '';
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_buffer($finfo, $data);
        finfo_close($finfo);
        return 'data:' . $mime . ';base64,' . base64_encode($data);
    }
}

// ========== DATABASE CONNECTION ==========
$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$memberCategories = ['General', 'Student', 'Staff', 'Others', 'Faculty', 'Visitor', 'Researcher', 'Alumni'];

// ========== ENSURE ALL COLUMNS EXIST ==========
$requiredColumns = [
    'members' => [
        'designation' => "TEXT DEFAULT ''",
        'emergency_contact' => "TEXT DEFAULT ''",
        'general_id' => "TEXT DEFAULT ''",
        'security_deposit' => "REAL DEFAULT 0",
        'membership_expiry' => "DATE",
        'total_paid_fines' => "REAL DEFAULT 0",
        'is_email_verified' => "INTEGER DEFAULT 0",
        'verification_token' => "TEXT DEFAULT ''",
        'verification_expiry' => "DATETIME",
        'approval_status' => "TEXT DEFAULT 'pending'",
        'parent_phone' => "TEXT DEFAULT ''",
        'blood_group' => "TEXT DEFAULT ''",
        'gender' => "TEXT DEFAULT ''",
        'dob' => "DATE",
        'address' => "TEXT DEFAULT ''",
        'notes' => "TEXT DEFAULT ''",
        'total_fines' => "REAL DEFAULT 0",
        'total_issued' => "INTEGER DEFAULT 0",
        'active_books' => "INTEGER DEFAULT 0",
        'admission_date' => "DATE DEFAULT CURRENT_DATE",
        'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP"
    ]
];

foreach ($requiredColumns as $table => $columns) {
    try {
        $existingCols = $db->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_COLUMN, 1);
        foreach ($columns as $col => $def) {
            if (!in_array($col, $existingCols)) {
                $db->exec("ALTER TABLE $table ADD COLUMN $col $def");
            }
        }
    } catch (PDOException $e) {
        // Ignore - columns already exist
    }
}

// ========== FETCH FINE RATES ==========
$fineRates = [];
$rateStmt = $db->query("SELECT member_category, fine_per_day FROM fine_rates");
while ($row = $rateStmt->fetch()) {
    $fineRates[$row['member_category']] = $row['fine_per_day'];
}

// ========== CSRF PROTECTION ==========
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ========== AUTO-INACTIVATE INACTIVE MEMBERS ==========
function autoInactivateInactiveMembers($db) {
    $sql = "UPDATE members SET status = 'inactive' 
            WHERE status = 'active' 
            AND (
                (NOT EXISTS (SELECT 1 FROM circulation WHERE circulation.admno = members.admno)
                 AND date(admission_date) <= date('now', '-6 months'))
                OR
                (strftime('%s', 'now') - strftime('%s', (
                    SELECT MAX(issue_date) FROM circulation WHERE circulation.admno = members.admno
                )) > 60*60*24*180)
            )";
    $db->exec($sql);
}
autoInactivateInactiveMembers($db);

// ========== EXPORT ALL MEMBERS TO CSV ==========
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    exportMembersCSV($db, null, $currencySymbol);
    exit;
}

// ========== HANDLE EDIT FETCH ==========
$editMember = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$_GET['edit']]);
    $editMember = $stmt->fetch();
}

// ========== HANDLE BULK ACTIONS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid CSRF token", "danger");
        header("Location: members.php");
        exit;
    }
    
    $selected = $_POST['selected_members'] ?? [];
    if (empty($selected)) {
        showToast("No members selected", "warning");
        header("Location: members.php");
        exit;
    }
    
    $placeholders = implode(',', array_fill(0, count($selected), '?'));
    
    if ($_POST['bulk_action'] === 'delete') {
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno IN ($placeholders)");
        $checkStmt->execute($selected);
        $hasRecords = $checkStmt->fetchColumn();
        
        if ($hasRecords > 0) {
            showToast("Cannot delete members with circulation history. Use 'Set Inactive' instead.", "warning");
        } else {
            $photoStmt = $db->prepare("SELECT photo_path FROM members WHERE admno IN ($placeholders)");
            $photoStmt->execute($selected);
            while ($member = $photoStmt->fetch()) {
                if ($member['photo_path']) {
                    $fullPath = BASE_PATH . '/' . ltrim($member['photo_path'], '/');
                    if (file_exists($fullPath)) {
                        unlink($fullPath);
                    }
                }
            }
            $deleteStmt = $db->prepare("DELETE FROM members WHERE admno IN ($placeholders)");
            $deleteStmt->execute($selected);
            showToast("Selected members deleted successfully", "success");
            logActivity($_SESSION['username'], 'BULK_MEMBER_DELETE', "Deleted members: " . implode(',', $selected));
        }
    } elseif ($_POST['bulk_action'] === 'deactivate') {
        $stmt = $db->prepare("UPDATE members SET status = 'inactive' WHERE admno IN ($placeholders)");
        $stmt->execute($selected);
        showToast("Selected members deactivated", "success");
        logActivity($_SESSION['username'], 'BULK_MEMBER_DEACTIVATE', "Deactivated members: " . implode(',', $selected));
        
    } elseif ($_POST['bulk_action'] === 'activate') {
        $stmt = $db->prepare("UPDATE members SET status = 'active' WHERE admno IN ($placeholders)");
        $stmt->execute($selected);
        showToast("Selected members activated", "success");
        logActivity($_SESSION['username'], 'BULK_MEMBER_ACTIVATE', "Activated members: " . implode(',', $selected));
        
    } elseif ($_POST['bulk_action'] === 'export') {
        exportMembersCSV($db, $selected, $currencySymbol);
        exit;
    }
    
    header("Location: members.php");
    exit;
}

// ========== HANDLE SINGLE DELETE ==========
if (isset($_GET['delete'])) {
    $check = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ?");
    $check->execute([$_GET['delete']]);
    $anyRecords = $check->fetchColumn();
    
    if ($anyRecords > 0) {
        showToast("Cannot delete member with circulation history. Set status to inactive instead.", "warning");
    } else {
        $stmt = $db->prepare("SELECT photo_path FROM members WHERE admno = ?");
        $stmt->execute([$_GET['delete']]);
        $member = $stmt->fetch();
        if ($member && $member['photo_path']) {
            $fullPath = BASE_PATH . '/' . ltrim($member['photo_path'], '/');
            if (file_exists($fullPath)) {
                unlink($fullPath);
            }
        }
        $stmt = $db->prepare("DELETE FROM members WHERE admno = ?");
        $stmt->execute([$_GET['delete']]);
        showToast("Member deleted successfully", "success");
        logActivity($_SESSION['username'], 'MEMBER_DELETE', "Deleted member: {$_GET['delete']}");
    }
    header("Location: members.php");
    exit;
}

// ========== EXPORT MEMBERS TO CSV FUNCTION ==========
function exportMembersCSV($db, $selected = null, $currencySymbol = '$') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=members_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    
    fputcsv($out, [
        'Adm/Mem No', 'Name', 'Designation', 'General ID', 'Category', 'Class/Dept', 'Division',
        'Roll No', 'Email', 'Phone', 'Parent Phone', 'Emergency Contact', 'Address',
        'DOB', 'Gender', 'Blood Group', 'Photo Path', 'Status', 'Admission Date',
        'Security Deposit', 'Membership Expiry', 'Created At', 'Active Books', 
        'Total Issued', 'Total Fines', 'Total Paid Fines'
    ]);
    
    if ($selected && is_array($selected) && count($selected) > 0) {
        $placeholders = implode(',', array_fill(0, count($selected), '?'));
        $sql = "SELECT * FROM members WHERE admno IN ($placeholders) ORDER BY name";
        $stmt = $db->prepare($sql);
        $stmt->execute($selected);
        $members = $stmt->fetchAll();
    } else {
        $members = $db->query("SELECT * FROM members ORDER BY name")->fetchAll();
    }
    
    foreach ($members as $m) {
        fputcsv($out, [
            $m['admno'], $m['name'], $m['designation'] ?? '', $m['general_id'] ?? '', 
            $m['member_category'] ?? '', $m['class'] ?? '', $m['division'] ?? '', 
            $m['roll_no'] ?? '', $m['email'] ?? '', $m['phone'] ?? '', 
            $m['parent_phone'] ?? '', $m['emergency_contact'] ?? '', $m['address'] ?? '', 
            $m['dob'] ?? '', $m['gender'] ?? '', $m['blood_group'] ?? '', 
            $m['photo_path'] ?? '', $m['status'] ?? 'active', $m['admission_date'] ?? '',
            $m['security_deposit'] ?? 0, $m['membership_expiry'] ?? '', $m['created_at'] ?? '',
            $m['active_books'] ?? 0, $m['total_issued'] ?? 0, $m['total_fines'] ?? 0,
            $m['total_paid_fines'] ?? 0
        ]);
    }
    fclose($out);
    exit;
}

// ========== HANDLE FORM SUBMISSION ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['add_member']) || isset($_POST['update_member']))) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid CSRF token", "danger");
        header("Location: members.php");
        exit;
    }
    
    try {
        $photoPath = $_POST['existing_photo'] ?? '';
        
        if (isset($_FILES['member_photo']) && $_FILES['member_photo']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $fileType = mime_content_type($_FILES['member_photo']['tmp_name']);
            if (!in_array($fileType, $allowedTypes)) {
                throw new Exception("Invalid file type. Only JPG, PNG, GIF, WEBP allowed.");
            }
            if ($_FILES['member_photo']['size'] > 5 * 1024 * 1024) {
                throw new Exception("File too large. Max 5MB.");
            }
            if (!is_dir(MEMBER_PHOTO_DIR)) {
                mkdir(MEMBER_PHOTO_DIR, 0777, true);
            }
            $newPhoto = uploadFile($_FILES['member_photo'], MEMBER_PHOTO_DIR, 'member_' . $_POST['admno']);
            if ($newPhoto) {
                if ($photoPath && file_exists($photoPath)) unlink($photoPath);
                $photoPath = 'uploads/members/' . basename($newPhoto);
            }
        }
        
        $admno = trim($_POST['admno']);
        $name = trim($_POST['name']);
        $designation = trim($_POST['designation'] ?? '');
        $general_id = trim($_POST['general_id'] ?? '');
        $member_category = $_POST['member_category'] ?? 'Student';
        $class = trim($_POST['class'] ?? '');
        $division = trim($_POST['division'] ?? '');
        $roll_no = trim($_POST['roll_no'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $parent_phone = trim($_POST['parent_phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $dob = !empty($_POST['dob']) ? $_POST['dob'] : null;
        $gender = $_POST['gender'] ?? '';
        $blood_group = $_POST['blood_group'] ?? '';
        $security_deposit = floatval($_POST['security_deposit'] ?? 0);
        $membership_expiry = !empty($_POST['membership_expiry']) ? $_POST['membership_expiry'] : null;
        $emergency_contact = trim($_POST['emergency_contact'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        
        if (isset($_POST['update_member'])) {
            $status = $_POST['status'] ?? 'active';
            $stmt = $db->prepare("UPDATE members SET 
                name = ?, designation = ?, member_category = ?, class = ?, division = ?, roll_no = ?,
                email = ?, phone = ?, parent_phone = ?, address = ?, dob = ?,
                gender = ?, blood_group = ?, photo_path = ?, status = ?,
                general_id = ?, security_deposit = ?, membership_expiry = ?, 
                emergency_contact = ?, notes = ?
                WHERE admno = ?");
            $stmt->execute([
                $name, $designation, $member_category, $class, $division, $roll_no,
                $email, $phone, $parent_phone, $address, $dob,
                $gender, $blood_group, $photoPath, $status,
                $general_id, $security_deposit, $membership_expiry,
                $emergency_contact, $notes, $admno
            ]);
            showToast("Member updated successfully", "success");
            logActivity($_SESSION['username'], 'MEMBER_UPDATE', "Updated member: $admno");
            
            header("Location: members.php");
            exit;
            
        } elseif (isset($_POST['add_member'])) {
            $check = $db->prepare("SELECT COUNT(*) FROM members WHERE admno = ?");
            $check->execute([$admno]);
            if ($check->fetchColumn() > 0) {
                throw new Exception("Member number already exists.");
            }
            
            $admission_date = !empty($_POST['admission_date']) ? $_POST['admission_date'] : date('Y-m-d');
            
            $stmt = $db->prepare("INSERT INTO members (
                admno, name, designation, member_category, class, division, roll_no, 
                email, phone, parent_phone, address, dob, gender, blood_group, 
                photo_path, status, admission_date, general_id,
                security_deposit, membership_expiry, emergency_contact, notes,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([
                $admno, $name, $designation, $member_category, $class, $division, $roll_no,
                $email, $phone, $parent_phone, $address, $dob, $gender, $blood_group,
                $photoPath, $admission_date, $general_id,
                $security_deposit, $membership_expiry, $emergency_contact, $notes
            ]);
            showToast("Member added successfully", "success");
            logActivity($_SESSION['username'], 'MEMBER_ADD', "Added member: $admno");
            
            header("Location: members.php");
            exit;
        }
    } catch (Exception $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// ========== BUILD SEARCH/FILTER CONDITIONS ==========
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$classFilter = $_GET['class_filter'] ?? '';
$genderFilter = $_GET['gender_filter'] ?? '';
$expiryFilter = $_GET['expiry_filter'] ?? '';

$where = "1=1";
$params = [];

if ($search) {
    $where .= " AND (admno LIKE ? OR name LIKE ? OR designation LIKE ? OR class LIKE ? OR phone LIKE ? OR email LIKE ? OR general_id LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like, $like, $like, $like]);
}
if ($category && $category !== 'all') {
    $where .= " AND member_category = ?";
    $params[] = $category;
}
if ($status && $status !== 'all') {
    $where .= " AND status = ?";
    $params[] = $status;
}
if ($classFilter) {
    $where .= " AND class = ?";
    $params[] = $classFilter;
}
if ($genderFilter && $genderFilter !== 'all') {
    $where .= " AND gender = ?";
    $params[] = $genderFilter;
}
if ($expiryFilter) {
    if ($expiryFilter === 'expired') {
        $where .= " AND membership_expiry IS NOT NULL AND date(membership_expiry) < date('now')";
    } elseif ($expiryFilter === 'expiring_soon') {
        $where .= " AND membership_expiry IS NOT NULL AND date(membership_expiry) BETWEEN date('now') AND date('now', '+30 days')";
    } elseif ($expiryFilter === 'valid') {
        $where .= " AND (membership_expiry IS NULL OR date(membership_expiry) >= date('now'))";
    }
}

// ========== GET UNIQUE CLASSES ==========
$classesStmt = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class");
$uniqueClasses = $classesStmt->fetchAll(PDO::FETCH_COLUMN);

// ========== PAGINATION ==========
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countSql = "SELECT COUNT(*) FROM members WHERE $where";
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalMembers = $countStmt->fetchColumn();
$totalPages = ceil($totalMembers / $perPage);

// ========== FETCH MEMBERS ==========
$sql = "SELECT m.*, 
        (SELECT COUNT(*) FROM circulation WHERE admno = m.admno AND return_date IS NULL) as active_books,
        (SELECT COUNT(*) FROM circulation WHERE admno = m.admno) as total_issued,
        (SELECT COALESCE(SUM(fine),0) FROM circulation WHERE admno = m.admno) as total_fines
        FROM members m 
        WHERE $where 
        ORDER BY m.created_at DESC, m.name 
        LIMIT $perPage OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$members = $stmt->fetchAll();

// ========== STATISTICS ==========
$totalMembersCount = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$activeMembersCount = $db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
$totalActiveIssues = $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
$expiredMemberships = $db->query("SELECT COUNT(*) FROM members WHERE membership_expiry IS NOT NULL AND date(membership_expiry) < date('now')")->fetchColumn();
$totalSecurityDeposit = $db->query("SELECT COALESCE(SUM(security_deposit),0) FROM members")->fetchColumn();
$todayMembers = $db->query("SELECT COUNT(*) FROM members WHERE date(created_at) = date('now')")->fetchColumn();

$allCategories = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
if (empty($allCategories)) $allCategories = $memberCategories;

renderHeader('Member Management');
?>

<style>
/* Enhanced styling for member management */
.member-photo-thumb {
    width: 50px;
    height: 50px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
}
.member-photo-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.member-photo-large {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 12px;
    border: 3px solid #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
.default-avatar-thumb {
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 50%;
    color: white;
    font-size: 1.5rem;
}
.default-avatar-large {
    width: 120px;
    height: 120px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 12px;
    color: white;
    font-size: 4rem;
}
.stat-card {
    transition: all 0.3s ease;
    border: none;
    border-radius: 15px;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
.filter-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.table th {
    background: #073b6f;
    border-bottom: 2px solid #dee2e6;
    white-space: nowrap;
}
.table td {
    vertical-align: middle;
}
.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

/* ========== FIXED MODAL SCROLLING ========== */
.modal-dialog-scrollable {
    max-height: 95vh;
}
.modal-dialog-scrollable .modal-content {
    max-height: 95vh;
    display: flex;
    flex-direction: column;
}
.modal-dialog-scrollable .modal-body {
    flex: 1 1 auto;
    overflow-y: auto;
    padding: 1rem;
    max-height: calc(95vh - 130px);
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar {
    width: 6px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb {
    background: #1e3c72;
    border-radius: 10px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb:hover {
    background: #2a5298;
}

.modal-lg {
    max-width: 800px;
}
@media (max-width: 768px) {
    .modal-lg {
        max-width: 95%;
        margin: 10px auto;
    }
    .member-photo-large {
        width: 80px;
        height: 80px;
    }
    .default-avatar-large {
        width: 80px;
        height: 80px;
        font-size: 2.5rem;
    }
    .modal-dialog-scrollable .modal-body {
        max-height: calc(90vh - 120px);
    }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-users text-primary"></i> Member Management</h2>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                <i class="fas fa-plus"></i> Add Member
            </button>
            <a href="../imports/" class="btn btn-info text-white">
                <i class="fas fa-upload"></i> Bulk Import
            </a>
            <a href="?export=csv" class="btn btn-secondary">
                <i class="fas fa-download"></i> Export CSV
            </a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-primary text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($totalMembersCount) ?></h3>
                    <small><i class="fas fa-users"></i> Total Members</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-success text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($activeMembersCount) ?></h3>
                    <small><i class="fas fa-user-check"></i> Active</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-warning text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($totalMembersCount - $activeMembersCount) ?></h3>
                    <small><i class="fas fa-user-slash"></i> Inactive</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-info text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($totalActiveIssues) ?></h3>
                    <small><i class="fas fa-book-reader"></i> Active Issues</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-danger text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($expiredMemberships) ?></h3>
                    <small><i class="fas fa-calendar-times"></i> Expired</small>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-secondary text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= formatCurrency($totalSecurityDeposit) ?></h3>
                    <small><i class="fas fa-hand-holding-usd"></i> Total Deposit</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Advanced Filter Form -->
    <div class="filter-card mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6><i class="fas fa-filter"></i> Advanced Filters</h6>
            <button class="btn btn-sm btn-outline-danger" type="button" id="clearFiltersBtn">
                <i class="fas fa-eraser"></i> Clear Filters
            </button>
        </div>
        <form method="get" class="row g-2" id="filterForm">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search by ID, Name, Designation, Class, Phone, Email, General ID..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($allCategories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="class_filter" class="form-select">
                    <option value="">All Classes/Dept</option>
                    <?php foreach ($uniqueClasses as $cls): ?>
                        <option value="<?= htmlspecialchars($cls) ?>" <?= $classFilter === $cls ? 'selected' : '' ?>><?= htmlspecialchars($cls) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="gender_filter" class="form-select">
                    <option value="">All Genders</option>
                    <option value="Male" <?= $genderFilter === 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= $genderFilter === 'Female' ? 'selected' : '' ?>>Female</option>
                    <option value="Other" <?= $genderFilter === 'Other' ? 'selected' : '' ?>>Other</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="expiry_filter" class="form-select">
                    <option value="">Membership Status</option>
                    <option value="expired" <?= $expiryFilter === 'expired' ? 'selected' : '' ?>>Expired</option>
                    <option value="expiring_soon" <?= $expiryFilter === 'expiring_soon' ? 'selected' : '' ?>>Expiring Soon (30 days)</option>
                    <option value="valid" <?= $expiryFilter === 'valid' ? 'selected' : '' ?>>Valid Membership</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i></button>
            </div>
        </form>
    </div>

    <!-- Bulk Action Form -->
    <form method="post" id="bulkActionForm" onsubmit="return confirmBulkAction()">
        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
        <div class="card mt-3">
            <div class="card-header bg-light d-flex flex-wrap justify-content-between align-items-center">
                <span><i class="fas fa-list"></i> Member Directory</span>
                <span class="text-muted small">Showing <?= count($members) ?> of <?= $totalMembers ?> members</span>
            </div>
            <div class="card-body">
                <div class="mb-3 d-flex flex-wrap gap-2">
                    <div class="form-check">
                        <input type="checkbox" id="selectAll" class="form-check-input">
                        <label for="selectAll" class="form-check-label">Select All</label>
                    </div>
                    <select name="bulk_action" class="form-select w-auto" required>
                        <option value="">Bulk Actions</option>
                        <option value="delete">Delete Selected</option>
                        <option value="deactivate">Set Inactive</option>
                        <option value="activate">Set Active</option>
                        <option value="export">Export Selected</option>
                    </select>
                    <button type="submit" class="btn btn-secondary">Apply</button>
                    <a href="?export=csv" class="btn btn-info ms-auto text-white">
                        <i class="fas fa-download"></i> Export All to CSV
                    </a>
                </div>
                
                <!-- Responsive Table -->
                <div class="table-responsive">
                    <table class="table table-hover table-bordered align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th style="width: 30px;"><input type="checkbox" id="selectAllCheckbox"></th>
                                <th style="width: 60px;">Photo</th>
                                <th>Adm/Mem No</th>
                                <th>Name / Designation</th>
                                <th>General ID</th>
                                <th>Category</th>
                                <th>Class/Dept</th>
                                <th>Division/Course</th>
                                <th>Contact</th>
                                <th>Active Books</th>
                                <th>Total Issued</th>
                                <th>Fines</th>
                                <th>Deposit</th>
                                <th>Added</th>
                                <th>Expiry</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($members as $m): 
                                $fineRate = $fineRates[$m['member_category']] ?? $settings['fine_per_day'] ?? 2;
                                $expiryClass = '';
                                if (!empty($m['membership_expiry'])) {
                                    $expiryDate = new DateTime($m['membership_expiry']);
                                    $now = new DateTime();
                                    if ($expiryDate < $now) $expiryClass = 'bg-danger text-white';
                                    elseif ($expiryDate->diff($now)->days <= 30) $expiryClass = 'bg-warning';
                                }
                                $photoUrl = getMemberPhotoUrl($m['photo_path'] ?? '');
                                $photoBase64 = getMemberPhotoBase64($m['photo_path'] ?? '');
                            ?>
                            <tr>
                                <td class="text-center">
                                    <input type="checkbox" name="selected_members[]" value="<?= htmlspecialchars($m['admno']) ?>" class="member-checkbox">
                                </td>
                                <td class="text-center">
                                    <?php if ($photoUrl || $photoBase64): ?>
                                        <img src="<?= $photoBase64 ?: $photoUrl ?>" class="member-photo-thumb" alt="Member Photo" 
                                             onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-thumb').style.display='flex';">
                                        <div class="default-avatar-thumb" style="display:none;">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="default-avatar-thumb">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?= htmlspecialchars($m['admno']) ?></strong></td>
                                <td>
                                    <strong><?= htmlspecialchars($m['name']) ?></strong>
                                    <?php if (!empty($m['designation'])): ?>
                                        <br><small class="text-muted"><i class="fas fa-briefcase"></i> <?= htmlspecialchars($m['designation']) ?></small>
                                    <?php endif; ?>
                                    <?php if (!empty($m['roll_no'])): ?>
                                        <br><small class="text-muted">Roll: <?= htmlspecialchars($m['roll_no']) ?></small>
                                    <?php endif; ?>
                                    <?php if (!empty($m['gender'])): ?>
                                        <br><small><i class="fas fa-<?= $m['gender'] === 'Male' ? 'mars' : ($m['gender'] === 'Female' ? 'venus' : 'genderless') ?>"></i> <?= $m['gender'] ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($m['general_id'] ?? '-') ?></td>
                                <td>
                                    <?= htmlspecialchars($m['member_category'] ?? 'Student') ?>
                                    <br><small class="text-muted" title="Fine per day"><?= formatCurrency($fineRate) ?>/day</small>
                                </td>
                                <td><?= $m['class'] ? htmlspecialchars($m['class']) : '-' ?></td>
                                <td><?= $m['division'] ? htmlspecialchars($m['division']) : '-' ?></td>
                                <td>
                                    <?php if (!empty($m['phone'])): ?>
                                        <i class="fas fa-phone"></i> <?= htmlspecialchars($m['phone']) ?><br>
                                    <?php endif; ?>
                                    <?php if (!empty($m['email'])): ?>
                                        <small><i class="fas fa-envelope"></i> <?= htmlspecialchars(substr($m['email'], 0, 20)) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?= ($m['active_books'] ?? 0) > 0 ? 'bg-warning' : 'bg-secondary' ?>">
                                        <?= $m['active_books'] ?? 0 ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-info"><?= $m['total_issued'] ?? 0 ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-danger"><?= formatCurrency($m['total_fines'] ?? 0) ?></span>
                                </td>
                                <td class="text-center"><?= formatCurrency($m['security_deposit'] ?? 0) ?></td>
                                <td class="text-center">
                                    <?php if (!empty($m['created_at'])): ?>
                                        <small><?= date('d-m-Y', strtotime($m['created_at'])) ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if (!empty($m['membership_expiry'])): ?>
                                        <span class="badge <?= $expiryClass ?>"><?= date('Y-m-d', strtotime($m['membership_expiry'])) ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Never</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?= ($m['status'] ?? 'active') === 'active' ? 'bg-success' : 'bg-danger' ?> status-badge">
                                        <?= ($m['status'] ?? 'active') === 'active' ? 'Active' : 'Inactive' ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="?edit=<?= urlencode($m['admno']) ?>" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="../circulation/history.php?admno=<?= urlencode($m['admno']) ?>" class="btn btn-info" title="History">
                                            <i class="fas fa-history"></i>
                                        </a>
                                        <button type="button" class="btn btn-secondary" title="Barcode" onclick="generateBarcode('<?= htmlspecialchars($m['admno']) ?>')">
                                            <i class="fas fa-barcode"></i>
                                        </button>
                                        <?php if (($m['total_issued'] ?? 0) == 0): ?>
                                            <a href="?delete=<?= urlencode($m['admno']) ?>" class="btn btn-danger" onclick="return confirm('Delete this member permanently? This cannot be undone.')" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        <?php else: ?>
                                            <button class="btn btn-danger" disabled title="Cannot delete - has circulation history">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($members)): ?> 
                                <tr>
                                    <td colspan="17" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                        No members found. 
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#addMemberModal">Add your first member</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <?php if (!empty($members)): ?>
                        <tfoot class="table-light">
                            <tr class="fw-bold">
                                <td colspan="12" class="text-end">Totals:</td>
                                <td><?= formatCurrency(array_sum(array_column($members, 'total_fines'))) ?></td>
                                <td><?= formatCurrency(array_sum(array_column($members, 'security_deposit'))) ?></td>
                                <td colspan="3"></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                <nav aria-label="Page navigation" class="mt-3">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>">Previous</a>
                        </li>
                        <?php 
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);
                        for ($i = $startPage; $i <= $endPage; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>">Next</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>

<!-- ========== ADD MEMBER MODAL (FIXED SCROLLING) ========== -->
<div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-primary text-white sticky-top" style="z-index: 10;">
                <h5 class="modal-title" id="addMemberModalLabel"><i class="fas fa-user-plus"></i> Add New Member</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="row">
                        <!-- Personal Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-id-card"></i> Personal Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adm/Mem Number *</label>
                            <input type="text" name="admno" class="form-control" required placeholder="e.g., MEM001">
                            <small class="text-muted">Unique identifier</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">General ID Number</label>
                            <input type="text" name="general_id" class="form-control" placeholder="External ID">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Designation</label>
                            <input type="text" name="designation" class="form-control" placeholder="e.g., Student, Teacher, Librarian, Manager">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Category *</label>
                            <select name="member_category" class="form-select" required>
                                <?php foreach ($memberCategories as $cat): ?>
                                    <option value="<?= $cat ?>"><?= $cat ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Class/Dept</label>
                            <input type="text" name="class" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Division/Course</label>
                            <input type="text" name="division" class="form-control">
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-address-book"></i> Contact Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Parent/Guardian Phone</label>
                            <input type="tel" name="parent_phone" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Emergency Contact</label>
                            <input type="text" name="emergency_contact" class="form-control" placeholder="Name & Number">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"></textarea>
                        </div>
                        
                        <!-- Personal Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-user-circle"></i> Personal Details</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <option>A+</option><option>A-</option><option>B+</option><option>B-</option>
                                <option>O+</option><option>O-</option><option>AB+</option><option>AB-</option>
                            </select>
                        </div>
                        
                        <!-- Membership Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-calendar-alt"></i> Membership Details</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Admission Date</label>
                            <input type="date" name="admission_date" class="form-control" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Membership Expiry Date</label>
                            <input type="date" name="membership_expiry" class="form-control">
                            <small class="text-muted">Leave empty for unlimited</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Security Deposit</label>
                            <div class="input-group">
                                <span class="input-group-text"><?= $currencySymbol ?></span>
                                <input type="number" step="0.01" name="security_deposit" class="form-control" value="0">
                            </div>
                        </div>
                        
                        <!-- Photo & Notes -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-camera"></i> Photo & Notes</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Member Photo</label>
                            <input type="file" name="member_photo" class="form-control" accept="image/*" onchange="previewPhoto(this, 'addPhotoPreview')">
                            <small class="text-muted">Max 5MB. Supported: JPG, PNG, GIF, WEBP</small>
                        </div>
                        <div class="col-md-4 mb-3 text-center">
                            <div id="addPhotoPreview" class="mt-2" style="display:none;">
                                <img id="addPreviewImg" style="width:100px;height:100px;object-fit:cover;border-radius:10px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Any additional notes about this member..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_member" class="btn btn-primary">Save Member</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($editMember): ?>
<!-- ========== EDIT MEMBER MODAL (FIXED SCROLLING) ========== -->
<div class="modal fade show" id="editMemberModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-warning sticky-top" style="z-index: 10;">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Member</h5>
                <a href="members.php" class="btn-close"></a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="row">
                        <!-- Personal Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-id-card"></i> Personal Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adm/Mem Number</label>
                            <input type="text" name="admno" class="form-control" value="<?= htmlspecialchars($editMember['admno']) ?>" readonly>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">General ID Number</label>
                            <input type="text" name="general_id" class="form-control" value="<?= htmlspecialchars($editMember['general_id'] ?? '') ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editMember['name']) ?>" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Designation</label>
                            <input type="text" name="designation" class="form-control" value="<?= htmlspecialchars($editMember['designation'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Roll Number</label>
                            <input type="text" name="roll_no" class="form-control" value="<?= htmlspecialchars($editMember['roll_no'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Category</label>
                            <select name="member_category" class="form-select">
                                <?php foreach ($memberCategories as $cat): ?>
                                    <option value="<?= $cat ?>" <?= ($editMember['member_category'] ?? 'Student') === $cat ? 'selected' : '' ?>><?= $cat ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Class/Dept</label>
                            <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($editMember['class'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Division/Course</label>
                            <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($editMember['division'] ?? '') ?>">
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-address-book"></i> Contact Information</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editMember['email'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone</label>
                            <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($editMember['phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Parent/Guardian Phone</label>
                            <input type="tel" name="parent_phone" class="form-control" value="<?= htmlspecialchars($editMember['parent_phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Emergency Contact</label>
                            <input type="text" name="emergency_contact" class="form-control" value="<?= htmlspecialchars($editMember['emergency_contact'] ?? '') ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Address</label>
                            <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($editMember['address'] ?? '') ?></textarea>
                        </div>
                        
                        <!-- Personal Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-user-circle"></i> Personal Details</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($editMember['dob'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="">Select</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
                                <option <?= ($editMember['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="">Select</option>
                                <?php foreach (['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg): ?>
                                    <option <?= ($editMember['blood_group'] ?? '') === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Membership Details -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-calendar-alt"></i> Membership Details</h6>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Admission Date</label>
                            <input type="date" name="admission_date" class="form-control" value="<?= htmlspecialchars($editMember['admission_date'] ?? date('Y-m-d')) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Membership Expiry Date</label>
                            <input type="date" name="membership_expiry" class="form-control" value="<?= htmlspecialchars($editMember['membership_expiry'] ?? '') ?>">
                            <small class="text-muted">Leave empty for unlimited</small>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Security Deposit</label>
                            <div class="input-group">
                                <span class="input-group-text"><?= $currencySymbol ?></span>
                                <input type="number" step="0.01" name="security_deposit" class="form-control" value="<?= htmlspecialchars($editMember['security_deposit'] ?? 0) ?>">
                            </div>
                        </div>
                        
                        <!-- Photo & Notes -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-camera"></i> Photo & Notes</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Member Photo</label>
                            <input type="file" name="member_photo" class="form-control" accept="image/*" onchange="previewPhoto(this, 'editPhotoPreview')">
                            <small class="text-muted">Upload new photo to replace existing</small>
                        </div>
                        <div class="col-md-4 mb-3 text-center">
                            <?php 
                            $editPhotoUrl = getMemberPhotoUrl($editMember['photo_path'] ?? '');
                            $editPhotoBase64 = getMemberPhotoBase64($editMember['photo_path'] ?? '');
                            ?>
                            <?php if ($editPhotoBase64 || $editPhotoUrl): ?>
                                <div id="currentPhoto">
                                    <img src="<?= $editPhotoBase64 ?: $editPhotoUrl ?>" class="member-photo-large" alt="Current Photo" 
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-avatar-large-edit').style.display='flex';">
                                    <div class="default-avatar-large-edit" style="display:none;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <input type="hidden" name="existing_photo" value="<?= htmlspecialchars($editMember['photo_path'] ?? '') ?>">
                                    <p class="small text-muted mt-1">Current photo</p>
                                </div>
                            <?php else: ?>
                                <div class="default-avatar-large">
                                    <i class="fas fa-user"></i>
                                </div>
                                <p class="small text-muted mt-1">No photo</p>
                            <?php endif; ?>
                            <div id="editPhotoPreview" class="mt-2" style="display:none;">
                                <img id="editPreviewImg" style="width:100px;height:100px;object-fit:cover;border-radius:10px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editMember['notes'] ?? '') ?></textarea>
                        </div>
                        
                        <!-- Status -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-primary"><i class="fas fa-toggle-on"></i> Status</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="active" <?= ($editMember['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Active</option>
                                <option value="inactive" <?= ($editMember['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <a href="members.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_member" class="btn btn-primary">Update Member</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ========== BARCODE MODAL ========== -->
<div class="modal fade" id="barcodeModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-barcode"></i> Member Barcode</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <div id="barcodeContainer"></div>
                <p id="barcodeValue" class="mt-2 fw-bold"></p>
                <button class="btn btn-primary mt-2" onclick="printBarcode()">
                    <i class="fas fa-print"></i> Print
                </button>
                <button class="btn btn-secondary mt-2" onclick="downloadBarcode()">
                    <i class="fas fa-download"></i> Download
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ========== JAVASCRIPT ========== -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
// ========== CONFIRM BULK ACTION ==========
function confirmBulkAction() {
    let action = document.querySelector('select[name="bulk_action"]').value;
    let checked = document.querySelectorAll('.member-checkbox:checked').length;
    if (!action) { 
        alert('Please select an action'); 
        return false; 
    }
    if (checked === 0) { 
        alert('Please select at least one member'); 
        return false; 
    }
    if (action === 'delete') {
        return confirm(`Are you sure you want to delete ${checked} member(s)? This cannot be undone.`);
    }
    if (action === 'deactivate') {
        return confirm(`Deactivate ${checked} member(s)? They will not be able to borrow books.`);
    }
    if (action === 'activate') {
        return confirm(`Activate ${checked} member(s)?`);
    }
    return true;
}

// ========== SELECT ALL ==========
document.getElementById('selectAllCheckbox')?.addEventListener('change', function(e) {
    document.querySelectorAll('.member-checkbox').forEach(cb => cb.checked = e.target.checked);
});

// ========== PHOTO PREVIEW ==========
function previewPhoto(input, targetId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var previewDiv = document.getElementById(targetId);
            if (previewDiv) {
                previewDiv.style.display = 'block';
                var imgId = targetId.replace('Preview', 'PreviewImg');
                var img = document.getElementById(imgId);
                if (img) {
                    img.src = e.target.result;
                }
            }
            var current = document.getElementById('currentPhoto');
            if (current) current.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ========== BARCODE GENERATION ==========
function generateBarcode(admno) {
    var container = document.getElementById('barcodeContainer');
    container.innerHTML = '<svg id="barcodeSvg"></svg>';
    document.getElementById('barcodeValue').textContent = admno;
    JsBarcode("#barcodeSvg", admno, { 
        format: "CODE128", 
        lineColor: "#000", 
        width: 2, 
        height: 50, 
        displayValue: false 
    });
    new bootstrap.Modal(document.getElementById('barcodeModal')).show();
}

function printBarcode() {
    var printContents = document.getElementById('barcodeContainer').innerHTML + 
        '<br><div style="text-align:center; font-family: monospace; font-size:16px;">' + 
        document.getElementById('barcodeValue').textContent + '</div>';
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = '<div style="text-align:center; margin-top:50px;">' + printContents + '</div>';
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
}

function downloadBarcode() {
    var svg = document.getElementById('barcodeSvg');
    if (!svg) return;
    var svgData = new XMLSerializer().serializeToString(svg);
    var canvas = document.createElement('canvas');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    var svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    var url = URL.createObjectURL(svgBlob);
    img.onload = function() {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        URL.revokeObjectURL(url);
        var link = document.createElement('a');
        link.download = 'barcode_' + document.getElementById('barcodeValue').textContent + '.png';
        link.href = canvas.toDataURL('image/png');
        link.click();
    };
    img.src = url;
}

// ========== CLEAR FILTERS ==========
document.getElementById('clearFiltersBtn')?.addEventListener('click', function() {
    window.location.href = 'members.php';
});

// ========== AUTO-DISMISS ALERTS ==========
setTimeout(function() { 
    var alerts = document.querySelectorAll('.alert'); 
    alerts.forEach(function(alert) { 
        var bsAlert = new bootstrap.Alert(alert); 
        setTimeout(function() { bsAlert.close(); }, 5000); 
    }); 
}, 3000);

// ========== ENTER KEY ON FILTERS ==========
document.querySelectorAll('#filterForm input, #filterForm select').forEach(el => {
    el.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            document.getElementById('filterForm').submit();
        }
    });
});

// ========== FIX FOR MODAL SCROLLING ON MOBILE ==========
document.addEventListener('DOMContentLoaded', function() {
    // Ensure modal backdrop doesn't interfere with scrolling
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        modal.addEventListener('shown.bs.modal', function() {
            document.body.style.overflow = 'hidden';
        });
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.style.overflow = '';
        });
    });
});
</script>

<style>
/* Additional responsive styles */
@media (max-width: 768px) {
    .stat-card h3 {
        font-size: 1.2rem;
    }
    .btn-group-sm .btn {
        padding: 0.2rem 0.4rem;
        font-size: 0.7rem;
    }
}
@media print {
    .no-print, .btn, .modal, .card-header .float-end, form, .btn-group, .pagination {
        display: none !important;
    }
    .member-photo-thumb {
        width: 30px;
        height: 30px;
    }
    table {
        font-size: 10px;
    }
}
</style>

<?php renderFooter(); ?>