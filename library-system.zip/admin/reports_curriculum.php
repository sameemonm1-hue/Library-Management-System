<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();

// Statistics by curriculum
$curriculumStats = $db->query("
    SELECT curriculum, COUNT(*) as total_books, SUM(quantity) as copies, SUM(available) as available
    FROM books GROUP BY curriculum
")->fetchAll();

$ibProfileStats = $db->query("
    SELECT ib_learner_profile, COUNT(*) as count FROM books 
    WHERE ib_learner_profile IS NOT NULL AND ib_learner_profile != '' 
    GROUP BY ib_learner_profile
")->fetchAll();

$cbseSubjectStats = $db->query("
    SELECT cbse_subject_code, COUNT(*) as count FROM books 
    WHERE cbse_subject_code IS NOT NULL AND cbse_subject_code != '' 
    GROUP BY cbse_subject_code
")->fetchAll();

$gulfBooks = $db->query("SELECT COUNT(*) as total FROM books WHERE gulf_approval = 1")->fetchColumn();

renderHeader('Curriculum Reports');
?>
<div class="container-fluid px-4">
    <h2><i class="fas fa-chalkboard-teacher"></i> Curriculum & Gulf Region Reports</h2>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">Books by Curriculum</div>
                <div class="card-body">
                    <canvas id="curriculumChart" height="200"></canvas>
                    <table class="table table-sm mt-3">
                        <thead><tr><th>Curriculum</th><th>Titles</th><th>Copies</th><th>Available</th></tr></thead>
                        <tbody>
                            <?php foreach($curriculumStats as $stat): ?>
                            <tr>
                                <td><?= $stat['curriculum'] ?></td>
                                <td><?= $stat['total_books'] ?></td>
                                <td><?= $stat['copies'] ?></td>
                                <td><?= $stat['available'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">IB Learner Profile Distribution</div>
                <div class="card-body">
                    <canvas id="ibChart" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-warning">CBSE Subject Codes</div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead><tr><th>Subject Code</th><th>Books</th></tr></thead>
                        <tbody>
                            <?php foreach($cbseSubjectStats as $stat): ?>
                            <tr><td><?= $stat['cbse_subject_code'] ?></td><td><?= $stat['count'] ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-info text-white">Gulf Region Compliance</div>
                <div class="card-body">
                    <p><strong>Gulf‑approved books:</strong> <?= $gulfBooks ?></p>
                    <p><strong>Books with Arabic titles:</strong> <?= $db->query("SELECT COUNT(*) FROM books WHERE arabic_title IS NOT NULL AND arabic_title != ''")->fetchColumn() ?></p>
                    <p><strong>Local publishers:</strong> <?= $db->query("SELECT COUNT(DISTINCT local_publisher) FROM books WHERE local_publisher IS NOT NULL AND local_publisher != ''")->fetchColumn() ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    new Chart(document.getElementById('curriculumChart'), {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_column($curriculumStats, 'curriculum')) ?>,
            datasets: [{
                label: 'Number of Titles',
                data: <?= json_encode(array_column($curriculumStats, 'total_books')) ?>,
                backgroundColor: '#0d6efd'
            }]
        }
    });
    new Chart(document.getElementById('ibChart'), {
        type: 'pie',
        data: {
            labels: <?= json_encode(array_column($ibProfileStats, 'ib_learner_profile')) ?>,
            datasets: [{
                data: <?= json_encode(array_column($ibProfileStats, 'count')) ?>,
                backgroundColor: ['#0d6efd','#6f42c1','#198754','#dc3545','#fd7e14','#0dcaf0','#d63384','#20c997','#ffc107','#adb5bd']
            }]
        }
    });
</script>
<?php renderFooter(); ?>