<?php
/**
 * Loan Rules Management - Complete Update
 * Features:
 * - Full CRUD for loan rules
 * - Patron category and item category management
 * - Wildcard support (*)
 * - Active/Inactive toggling
 * - Responsive design
 * - Enhanced UI with statistics
 * - Audit logging
 */

// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Admin authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

// ========== GET STATISTICS ==========
$totalRules = $db->query("SELECT COUNT(*) FROM loan_rules")->fetchColumn();
$activeRules = $db->query("SELECT COUNT(*) FROM loan_rules WHERE is_active = 1")->fetchColumn();
$inactiveRules = $totalRules - $activeRules;

// ========== HANDLE CRUD OPERATIONS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();
        
        if (isset($_POST['add'])) {
            $stmt = $db->prepare("INSERT INTO loan_rules (patron_category, item_category, max_loans, loan_period, renewals_allowed, fine_per_day, grace_period, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))");
            $stmt->execute([
                trim($_POST['patron_category']), 
                trim($_POST['item_category']), 
                (int)$_POST['max_loans'], 
                (int)$_POST['loan_period'], 
                (int)$_POST['renewals_allowed'], 
                (float)$_POST['fine_per_day'], 
                (int)$_POST['grace_period']
            ]);
            $success = "Rule added successfully.";
            logActivity($_SESSION['username'], 'LOAN_RULE_ADD', "Added rule for {$_POST['patron_category']} / {$_POST['item_category']}");
            
        } elseif (isset($_POST['edit'])) {
            $stmt = $db->prepare("UPDATE loan_rules SET patron_category = ?, item_category = ?, max_loans = ?, loan_period = ?, renewals_allowed = ?, fine_per_day = ?, grace_period = ?, updated_at = datetime('now') WHERE id = ?");
            $stmt->execute([
                trim($_POST['patron_category']), 
                trim($_POST['item_category']), 
                (int)$_POST['max_loans'], 
                (int)$_POST['loan_period'], 
                (int)$_POST['renewals_allowed'], 
                (float)$_POST['fine_per_day'], 
                (int)$_POST['grace_period'], 
                (int)$_POST['id']
            ]);
            $success = "Rule updated successfully.";
            logActivity($_SESSION['username'], 'LOAN_RULE_EDIT', "Updated rule ID {$_POST['id']}");
            
        } elseif (isset($_POST['toggle_status'])) {
            $stmt = $db->prepare("UPDATE loan_rules SET is_active = NOT is_active, updated_at = datetime('now') WHERE id = ?");
            $stmt->execute([(int)$_POST['id']]);
            $success = "Rule status toggled.";
            logActivity($_SESSION['username'], 'LOAN_RULE_TOGGLE', "Toggled rule ID {$_POST['id']}");
            
        } elseif (isset($_POST['delete'])) {
            $stmt = $db->prepare("DELETE FROM loan_rules WHERE id = ?");
            $stmt->execute([(int)$_POST['id']]);
            $success = "Rule deleted successfully.";
            logActivity($_SESSION['username'], 'LOAN_RULE_DELETE', "Deleted rule ID {$_POST['id']}");
        }
        
        $db->commit();
        
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        $error = "Operation failed: " . $e->getMessage();
    }
    
    // Redirect to avoid form resubmission
    if (isset($success)) {
        header('Location: loan_rules.php?msg=' . urlencode($success));
    } elseif (isset($error)) {
        header('Location: loan_rules.php?error=' . urlencode($error));
    }
    exit;
}

// ========== FETCH ALL RULES ==========
$rules = $db->query("SELECT * FROM loan_rules ORDER BY 
    CASE WHEN patron_category = '*' THEN 0 ELSE 1 END, 
    patron_category, 
    CASE WHEN item_category = '*' THEN 0 ELSE 1 END, 
    item_category")->fetchAll();

// ========== GET DISTINCT CATEGORIES ==========
$patronCategories = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category")->fetchAll(PDO::FETCH_COLUMN);
$itemCategories = $db->query("SELECT DISTINCT item_category FROM books WHERE item_category IS NOT NULL AND item_category != '' ORDER BY item_category")->fetchAll(PDO::FETCH_COLUMN);

// Always include wildcard options
array_unshift($patronCategories, '*');
array_unshift($itemCategories, '*');

// Remove duplicates if any
$patronCategories = array_unique($patronCategories);
$itemCategories = array_unique($itemCategories);

// ========== MESSAGES ==========
$msg = $_GET['msg'] ?? '';
$error = $_GET['error'] ?? '';

renderHeader('Loan Rules Management');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Stat Cards */
.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    height: 100%;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
.stat-card .stat-icon {
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 32px;
    opacity: 0.15;
}
.stat-card .stat-value {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 2px;
}
.stat-card .stat-label {
    font-size: 14px;
    color: #6c757d;
}

/* Rule Table */
.rule-table th {
    background: #073b6f;
    color: white;
    white-space: nowrap;
    font-weight: 600;
}
.rule-table td {
    vertical-align: middle;
}
.rule-table .wildcard-badge {
    background: #fff3cd;
    color: #856404;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.7rem;
}

/* Action Buttons */
.btn-group-actions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
}
.btn-group-actions .btn {
    padding: 4px 8px;
    font-size: 0.75rem;
}

/* Category Input Group */
.category-input-group {
    display: flex;
    gap: 6px;
    align-items: center;
}
.category-input-group .form-control {
    flex: 1;
}

/* Responsive */
@media (max-width: 768px) {
    .stat-card .stat-value { font-size: 22px; }
    .stat-card { padding: 15px; }
    .stat-card .stat-icon { font-size: 28px; }
    .rule-table { font-size: 0.8rem; }
    .btn-group-actions .btn { padding: 3px 6px; font-size: 0.7rem; }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-gavel text-primary"></i> Loan Rules (Circulation Policies)</h2>
            <p class="text-muted">Define borrowing policies based on patron and item categories. Rules override global settings.</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary">
                <i class="fas fa-home"></i> Home
            </a>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="fas fa-plus"></i> Add Rule
            </button>
            <button class="btn btn-secondary" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Messages -->
    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?= htmlspecialchars($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4 col-6">
            <div class="stat-card border-start border-4 border-primary">
                <div class="stat-icon"><i class="fas fa-list"></i></div>
                <div class="stat-value text-primary"><?= number_format($totalRules) ?></div>
                <div class="stat-label">Total Rules</div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-card border-start border-4 border-success">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value text-success"><?= number_format($activeRules) ?></div>
                <div class="stat-label">Active Rules</div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-card border-start border-4 border-secondary">
                <div class="stat-icon"><i class="fas fa-pause-circle"></i></div>
                <div class="stat-value text-secondary"><?= number_format($inactiveRules) ?></div>
                <div class="stat-label">Inactive Rules</div>
            </div>
        </div>
    </div>

    <!-- Info Alert -->
    <div class="alert alert-info alert-dismissible fade show mb-4">
        <i class="fas fa-info-circle"></i>
        <strong>Rule Priority:</strong> The most specific match (patron + item) applies first.
        Use <code class="bg-light px-2 py-1 rounded">*</code> as a wildcard for any category.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>

    <!-- Rules Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
            <span><i class="fas fa-list text-primary"></i> Current Loan Rules</span>
            <span class="badge bg-secondary"><?= count($rules) ?> rules</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-bordered rule-table mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Patron Category</th>
                            <th>Item Category</th>
                            <th class="text-center">Max Loans</th>
                            <th class="text-center">Loan Days</th>
                            <th class="text-center">Renewals</th>
                            <th class="text-center">Fine/Day</th>
                            <th class="text-center">Grace</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rules)): ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                    No loan rules defined. 
                                    <button class="btn btn-sm btn-success mt-2" data-bs-toggle="modal" data-bs-target="#addModal">
                                        <i class="fas fa-plus"></i> Add your first rule
                                    </button>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($rules as $index => $r): 
                                $isWildcardPatron = $r['patron_category'] === '*';
                                $isWildcardItem = $r['item_category'] === '*';
                            ?>
                            <tr>
                                <td class="text-center"><?= $index + 1 ?></td>
                                <td>
                                    <?php if ($isWildcardPatron): ?>
                                        <span class="wildcard-badge"><i class="fas fa-asterisk"></i> Any</span>
                                    <?php else: ?>
                                        <?= htmlspecialchars($r['patron_category']) ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($isWildcardItem): ?>
                                        <span class="wildcard-badge"><i class="fas fa-asterisk"></i> Any</span>
                                    <?php else: ?>
                                        <?= htmlspecialchars($r['item_category']) ?>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><strong><?= (int)$r['max_loans'] ?></strong></td>
                                <td class="text-center"><?= (int)$r['loan_period'] ?></td>
                                <td class="text-center"><?= (int)$r['renewals_allowed'] ?></td>
                                <td class="text-center">
                                    <span class="badge bg-warning text-dark">
                                        <?= $currencySymbol ?> <?= number_format((float)$r['fine_per_day'], 2) ?>
                                    </span>
                                </td>
                                <td class="text-center"><?= (int)$r['grace_period'] ?></td>
                                <td class="text-center">
                                    <?php if ($r['is_active']): ?>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check-circle"></i> Active
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">
                                            <i class="fas fa-pause-circle"></i> Inactive
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group-actions justify-content-center">
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal" 
                                                data-id="<?= $r['id'] ?>"
                                                data-patron="<?= htmlspecialchars($r['patron_category']) ?>"
                                                data-item="<?= htmlspecialchars($r['item_category']) ?>"
                                                data-maxloans="<?= $r['max_loans'] ?>"
                                                data-period="<?= $r['loan_period'] ?>"
                                                data-renewals="<?= $r['renewals_allowed'] ?>"
                                                data-fine="<?= $r['fine_per_day'] ?>"
                                                data-grace="<?= $r['grace_period'] ?>"
                                                title="Edit Rule">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="post" style="display:inline-block;">
                                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                            <button type="submit" name="toggle_status" class="btn btn-sm btn-<?= $r['is_active'] ? 'warning' : 'success' ?>" 
                                                    title="<?= $r['is_active'] ? 'Deactivate' : 'Activate' ?>">
                                                <i class="fas fa-<?= $r['is_active'] ? 'pause' : 'play' ?>"></i>
                                            </button>
                                        </form>
                                        <form method="post" style="display:inline-block;" onsubmit="return confirm('Delete this rule permanently? This action cannot be undone.');">
                                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                            <button type="submit" name="delete" class="btn btn-sm btn-danger" title="Delete Rule">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($rules)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="10" class="text-end">Total Rules: <?= count($rules) ?> | Active: <?= $activeRules ?> | Inactive: <?= $inactiveRules ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick Reference -->
    <div class="row g-3 mt-2">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h6 class="mb-0"><i class="fas fa-info-circle text-primary"></i> How Rules Work</h6>
                </div>
                <div class="card-body small">
                    <ol class="mb-0">
                        <li><strong>Specific Match:</strong> Exact patron + exact item category</li>
                        <li><strong>Patron Wildcard:</strong> <code>*</code> + exact item category</li>
                        <li><strong>Item Wildcard:</strong> Exact patron + <code>*</code></li>
                        <li><strong>Global Wildcard:</strong> <code>*</code> + <code>*</code> (fallback)</li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-light">
                    <h6 class="mb-0"><i class="fas fa-tags text-primary"></i> Categories</h6>
                </div>
                <div class="card-body small">
                    <div class="row">
                        <div class="col-6">
                            <strong>Patron Categories:</strong>
                            <ul class="list-unstyled mb-0">
                                <?php foreach (array_slice($patronCategories, 0, 10) as $cat): ?>
                                    <li><span class="badge bg-secondary"><?= htmlspecialchars($cat) ?></span></li>
                                <?php endforeach; ?>
                                <?php if (count($patronCategories) > 10): ?>
                                    <li><span class="text-muted">+<?= count($patronCategories) - 10 ?> more</span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="col-6">
                            <strong>Item Categories:</strong>
                            <ul class="list-unstyled mb-0">
                                <?php foreach (array_slice($itemCategories, 0, 10) as $cat): ?>
                                    <li><span class="badge bg-info"><?= htmlspecialchars($cat) ?></span></li>
                                <?php endforeach; ?>
                                <?php if (count($itemCategories) > 10): ?>
                                    <li><span class="text-muted">+<?= count($itemCategories) - 10 ?> more</span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== ADD RULE MODAL ========== -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="fas fa-plus"></i> Add New Loan Rule</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Patron Category <span class="text-muted">(* = any)</span></label>
                            <input type="text" name="patron_category" class="form-control" value="*" required>
                            <small class="text-muted">Type a category or use * for wildcard</small>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Item Category <span class="text-muted">(* = any)</span></label>
                            <input type="text" name="item_category" class="form-control" value="*" required>
                            <small class="text-muted">Type a category or use * for wildcard</small>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Max Loans</label>
                            <input type="number" name="max_loans" class="form-control" value="5" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Loan Period (days)</label>
                            <input type="number" name="loan_period" class="form-control" value="14" min="1" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Renewals Allowed</label>
                            <input type="number" name="renewals_allowed" class="form-control" value="1" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Fine per Day (<?= $currencySymbol ?>)</label>
                            <input type="number" step="0.01" name="fine_per_day" class="form-control" value="1.00" min="0" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Grace Period (days)</label>
                            <input type="number" name="grace_period" class="form-control" value="0" min="0" required>
                            <small class="text-muted">Days after due date before fines apply</small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add" class="btn btn-success">Add Rule</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== EDIT RULE MODAL ========== -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Loan Rule</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Patron Category</label>
                            <input type="text" name="patron_category" id="edit_patron" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Item Category</label>
                            <input type="text" name="item_category" id="edit_item" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Max Loans</label>
                            <input type="number" name="max_loans" id="edit_maxloans" class="form-control" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Loan Period (days)</label>
                            <input type="number" name="loan_period" id="edit_period" class="form-control" min="1" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Renewals Allowed</label>
                            <input type="number" name="renewals_allowed" id="edit_renewals" class="form-control" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold">Fine per Day (<?= $currencySymbol ?>)</label>
                            <input type="number" step="0.01" name="fine_per_day" id="edit_fine" class="form-control" min="0" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Grace Period (days)</label>
                            <input type="number" name="grace_period" id="edit_grace" class="form-control" min="0" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== EDIT MODAL DATA POPULATION ==========
const editModal = document.getElementById('editModal');
editModal.addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    document.getElementById('edit_id').value = button.getAttribute('data-id');
    document.getElementById('edit_patron').value = button.getAttribute('data-patron');
    document.getElementById('edit_item').value = button.getAttribute('data-item');
    document.getElementById('edit_maxloans').value = button.getAttribute('data-maxloans');
    document.getElementById('edit_period').value = button.getAttribute('data-period');
    document.getElementById('edit_renewals').value = button.getAttribute('data-renewals');
    document.getElementById('edit_fine').value = button.getAttribute('data-fine');
    document.getElementById('edit_grace').value = button.getAttribute('data-grace');
});

// ========== AUTO-DISMISS ALERTS ==========
setTimeout(function() { 
    var alerts = document.querySelectorAll('.alert'); 
    alerts.forEach(function(alert) { 
        var bsAlert = new bootstrap.Alert(alert); 
        setTimeout(function() { bsAlert.close(); }, 5000); 
    }); 
}, 3000);

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N for new rule
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        document.querySelector('[data-bs-target="#addModal"]').click();
    }
});
</script>

<?php renderFooter(); ?>