<?php
/**
 * Manage Book Holds
 * Version: 3.0 - Fully Integrated with Library ERP System
 * Uses SQLite database with proper session handling, caching, and book exit logging
 */

// ============================================================================
// BOOTSTRAP
// ============================================================================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Check if session is already started before starting it
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$settings = getSettings();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$currencySymbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');

// ==================== FILTER & SEARCH ====================
$filterStatus = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');
$msg = $_GET['msg'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// ==================== BUILD QUERY ====================
$sql = "SELECT h.*, b.title, b.author, b.available as book_available, b.cover_path 
        FROM book_holds h 
        JOIN books b ON h.book_barcode = b.barcode 
        WHERE 1=1";
$params = [];

if ($filterStatus !== 'all') {
    $sql .= " AND h.status = ?";
    $params[] = $filterStatus;
}

if (!empty($search)) {
    $sql .= " AND (h.book_barcode LIKE ? OR h.member_name LIKE ? OR h.admno LIKE ? OR b.title LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}

// Count total for pagination
$countSql = str_replace("SELECT h.*, b.title, b.author, b.available as book_available, b.cover_path", "SELECT COUNT(*) as total", $sql);
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalHolds = (int)$countStmt->fetchColumn();

$sql .= " ORDER BY 
            CASE h.status 
                WHEN 'pending' THEN 1 
                WHEN 'available' THEN 2 
                WHEN 'picked_up' THEN 3 
                WHEN 'cancelled' THEN 4 
            END ASC, 
            h.hold_date ASC";
$sql .= " LIMIT ? OFFSET ?";
$params[] = $perPage;
$params[] = $offset;

$stmt = $db->prepare($sql);
$stmt->execute($params);
$holds = $stmt->fetchAll();

// ==================== HANDLE ACTIONS ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $action = $_POST['action'] ?? '';
    $msg = '';
    $hold = null;
    
    // Get hold details first
    $stmt = $db->prepare("SELECT * FROM book_holds WHERE id = ?");
    $stmt->execute([$id]);
    $hold = $stmt->fetch();
    
    if ($action === 'cancel') {
        if ($hold) {
            $stmt = $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ?");
            $stmt->execute([$id]);
            $msg = "Hold cancelled successfully.";
            if (function_exists('logActivity')) {
                logActivity($_SESSION['username'] ?? 'admin', 'Cancel Hold', "Hold ID: $id, Book: {$hold['book_barcode']}, Member: {$hold['member_name']}");
            }
        }
        
    } elseif ($action === 'mark_picked') {
        if ($hold && $hold['status'] == 'available') {
            $db->prepare("UPDATE book_holds SET status = 'picked_up' WHERE id = ?")->execute([$id]);
            $msg = "Hold marked as picked up.";
            
            // Log book exit with authorization
            if (function_exists('logBookExit')) {
                logBookExit(
                    $hold['book_barcode'],
                    true, // Authorized exit
                    $hold['admno'],
                    $hold['member_name'],
                    null,
                    "Picked up from hold shelf"
                );
            }
            if (function_exists('logActivity')) {
                logActivity($_SESSION['username'] ?? 'admin', 'Pick Up Hold', "Hold ID: $id, Book: {$hold['book_barcode']}, Member: {$hold['member_name']}");
            }
        } else {
            $msg = "Hold is not available for pickup.";
        }
        
    } elseif ($action === 'send_reminder') {
        if ($hold && $hold['status'] == 'available') {
            $stmt = $db->prepare("SELECT email, name FROM members WHERE admno = ?");
            $stmt->execute([$hold['admno']]);
            $member = $stmt->fetch();
            
            $stmt = $db->prepare("SELECT title FROM books WHERE barcode = ?");
            $stmt->execute([$hold['book_barcode']]);
            $book = $stmt->fetch();
            
            if ($member && $book) {
                $subject = "Reminder: Hold Available - {$book['title']}";
                $body = "Dear {$member['name']},\n\nThis is a reminder that the book \"{$book['title']}\" is still waiting for you at the library. Please pick it up before {$hold['expiry_date']}.\n\nThank you.";
                
                // Queue email using the system's email queue
                if (function_exists('queueEmail')) {
                    queueEmail($member['email'], $subject, $body);
                } else {
                    // Fallback: direct insert
                    $stmt = $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')");
                    $stmt->execute([$member['email'], $subject, $body]);
                }
                $msg = "Reminder email queued.";
                if (function_exists('logActivity')) {
                    logActivity($_SESSION['username'] ?? 'admin', 'Send Hold Reminder', "Hold ID: $id, Member: {$member['name']}");
                }
            } else {
                $msg = "Member or book not found.";
            }
        } else {
            $msg = "Hold is not available for pickup.";
        }
    } else {
        $msg = "Invalid action.";
    }
    
    header("Location: holds.php?status=$filterStatus&search=" . urlencode($search) . "&page=$page&msg=" . urlencode($msg));
    exit;
}

// ==================== STATISTICS ====================
// Get all holds for stats (uncached)
$allStmt = $db->query("SELECT status FROM book_holds");
$allHolds = $allStmt->fetchAll();
$pendingCount = 0;
$availableCount = 0;
$pickedUpCount = 0;
$cancelledCount = 0;

foreach ($allHolds as $h) {
    if ($h['status'] == 'pending') $pendingCount++;
    elseif ($h['status'] == 'available') $availableCount++;
    elseif ($h['status'] == 'picked_up') $pickedUpCount++;
    elseif ($h['status'] == 'cancelled') $cancelledCount++;
}

// ==================== GET USERNAME ====================
$username = $_SESSION['username'] ?? ($_SESSION['fullname'] ?? 'Admin');

// ==================== PAGE RENDER ====================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Manage Holds - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
            --border-radius: 16px;
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
            --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
            --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        body { 
            background: #f4f6fa; 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            padding-bottom: 2rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .btn-gradient-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: #fff;
            border: none;
        }
        .btn-gradient-primary:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
            color: #fff;
        }
        
        .card {
            border: none;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            overflow: hidden;
        }
        .card:hover {
            box-shadow: var(--shadow-md);
        }
        .card-header {
            background: var(--primary-color);
            color: white;
            border-bottom: none;
            padding: 0.9rem 1.25rem;
            font-weight: 600;
            border-radius: var(--border-radius) var(--border-radius) 0 0;
        }
        .card-header .badge {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        .table thead th {
            background: var(--primary-color);
            color: white;
            border-bottom: none;
            font-weight: 600;
            font-size: 0.85rem;
            padding: 0.75rem 0.5rem;
        }
        .table td {
            vertical-align: middle;
            padding: 0.6rem 0.5rem;
        }
        .table tbody tr {
            transition: var(--transition);
        }
        .table tbody tr:hover {
            background-color: rgba(var(--primary-rgb), 0.05);
        }
        
        .stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            padding: 1.25rem 1.5rem;
            transition: var(--transition);
            height: 100%;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        .stat-card::after {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255,255,255,0.08);
            pointer-events: none;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }
        .stat-card .stat-value {
            font-size: 1.9rem;
            font-weight: 700;
            line-height: 1.2;
        }
        .stat-card .stat-label {
            font-size: 0.85rem;
            opacity: 0.9;
            font-weight: 500;
        }
        .stat-card .stat-icon {
            font-size: 2rem;
            opacity: 0.25;
        }
        
        .badge-status {
            font-size: 0.7rem;
            padding: 0.35rem 0.75rem;
            border-radius: 30px;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        
        .action-btn {
            transition: var(--transition);
            border-radius: 8px;
            padding: 0.25rem 0.5rem;
        }
        .action-btn:hover {
            transform: scale(1.1);
        }
        
        .book-cover-small {
            width: 35px;
            height: 47px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #e9ecef;
            background: #f8f9fa;
            flex-shrink: 0;
        }
        .book-cover-placeholder {
            width: 35px;
            height: 47px;
            border-radius: 4px;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 0.8rem;
            border: 1px solid #dee2e6;
            flex-shrink: 0;
        }
        
        .pagination .page-link {
            color: var(--primary-color);
        }
        .pagination .page-item.active .page-link {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .settings-bar { display: none !important; }
        
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-icon { display: none !important; }
            .card-header { background: #f8f9fa !important; color: #333 !important; border-bottom: 1px solid #ddd !important; }
            .table thead th { background: #333 !important; color: white !important; }
        }
        
        @media (max-width: 768px) {
            .stat-card .stat-value { font-size: 1.4rem; }
            .stat-card { padding: 0.8rem 1rem; min-height: 70px; }
            .stat-card .stat-label { font-size: 0.7rem; }
            .stat-card .stat-icon { font-size: 1.4rem; }
            .table { font-size: 0.8rem; }
            .table td, .table th { padding: 0.4rem 0.3rem; }
            .btn-sm { font-size: 0.7rem; padding: 0.2rem 0.4rem; }
            .action-btn { padding: 0.15rem 0.3rem; }
            .card-header { font-size: 0.9rem; padding: 0.6rem 1rem; }
            .book-cover-small { width: 28px; height: 38px; }
            .book-cover-placeholder { width: 28px; height: 38px; font-size: 0.6rem; }
        }
        
        @media (max-width: 480px) {
            .stat-card .stat-value { font-size: 1.1rem; }
            .stat-card { padding: 0.6rem 0.8rem; min-height: 60px; }
            .table { font-size: 0.7rem; }
            .badge-status { font-size: 0.6rem; padding: 0.2rem 0.5rem; }
        }
    </style>
</head>
<body>

<?php 
// ==================== NAVIGATION ====================
// Try to include nav.php from multiple locations
$navPaths = [
    __DIR__ . '/nav.php',
    __DIR__ . '/../nav.php',
    __DIR__ . '/../admin/nav.php',
];

$navLoaded = false;
foreach ($navPaths as $navPath) {
    if (file_exists($navPath)) {
        include $navPath;
        $navLoaded = true;
        break;
    }
}

// Fallback navigation if nav.php not found
if (!$navLoaded) {
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); box-shadow: 0 2px 10px rgba(0,0,0,0.3);">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-book-open"></i> Library ERP
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="holds.php">
                            <i class="fas fa-hand-paper"></i> Holds
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-cog"></i> <?= htmlspecialchars($username) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="../admin/settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php
}
?>

<div class="container-fluid px-3 px-md-4 mt-3">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h2 style="color: var(--primary-color);" class="fw-bold mb-1">
                <i class="fas fa-hand-paper me-2" style="color: var(--primary-color);"></i> Hold Queue Management
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> 
                <span class="ms-2"><i class="fas fa-user"></i> <?= htmlspecialchars($username) ?></span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="../index.php" class="btn btn-primary btn-sm">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="?status=all" class="btn btn-outline-primary btn-sm">
                <i class="fas fa-sync"></i> Refresh
            </a>
            <button onclick="window.print()" class="btn btn-outline-secondary btn-sm" title="Print">
                <i class="fas fa-print"></i>
            </button>
        </div>
    </div>

    <!-- ========== ALERT MESSAGES ========== -->
    <?php if ($msg): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="fas fa-info-circle me-2"></i> <?= htmlspecialchars($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <!-- ========== STATISTICS CARDS ========== -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card text-center" onclick="window.location.href='?status=all'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="stat-value"><?= number_format($totalHolds) ?></div>
                        <div class="stat-label">Total Holds</div>
                    </div>
                    <div class="stat-icon"><i class="fas fa-list"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center" onclick="window.location.href='?status=pending'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="stat-value"><?= number_format($pendingCount) ?></div>
                        <div class="stat-label">Pending</div>
                    </div>
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center" onclick="window.location.href='?status=available'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="stat-value"><?= number_format($availableCount) ?></div>
                        <div class="stat-label">Available</div>
                    </div>
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center" onclick="window.location.href='?status=picked_up'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="stat-value"><?= number_format($pickedUpCount) ?></div>
                        <div class="stat-label">Picked Up</div>
                    </div>
                    <div class="stat-icon"><i class="fas fa-arrow-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== FILTER / SEARCH ========== -->
    <div class="card mb-4 no-print">
        <div class="card-body p-3">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-semibold small text-muted">Status Filter</label>
                    <select name="status" class="form-select form-select-sm">
                        <option value="all" <?= $filterStatus == 'all' ? 'selected' : '' ?>>All</option>
                        <option value="pending" <?= $filterStatus == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="available" <?= $filterStatus == 'available' ? 'selected' : '' ?>>Available (on hold shelf)</option>
                        <option value="picked_up" <?= $filterStatus == 'picked_up' ? 'selected' : '' ?>>Picked Up</option>
                        <option value="cancelled" <?= $filterStatus == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <label class="form-label fw-semibold small text-muted">Search</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control form-control-sm" 
                               value="<?= htmlspecialchars($search) ?>" 
                               placeholder="Barcode, Member Name, Adm No, Book Title">
                    </div>
                </div>
                <div class="col-md-4 d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-sm flex-grow-1">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="holds.php" class="btn btn-secondary btn-sm flex-grow-1">
                        <i class="fas fa-undo"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- ========== HOLDS TABLE ========== -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list me-2"></i> Holds List</span>
            <div>
                <span class="badge me-2"><?= number_format($totalHolds) ?> holds</span>
                <span class="badge">Page <?= $page ?> of <?= max(1, ceil($totalHolds / $perPage)) ?></span>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 45px;">#</th>
                            <th>Book</th>
                            <th>Member</th>
                            <th class="text-center">Adm No</th>
                            <th class="text-center">Hold Date</th>
                            <th class="text-center">Expiry</th>
                            <th class="text-center">Status</th>
                            <th class="text-center no-print" style="min-width: 140px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($holds)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x d-block mb-3" style="color: #dee2e6;"></i>
                                    <p class="mb-0">No holds found</p>
                                    <small class="text-muted">Try adjusting your filters or search</small>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $counter = $offset + 1; foreach ($holds as $hold): ?>
                            <tr>
                                <td class="text-center fw-semibold text-muted"><?= $counter++ ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <?php 
                                        $coverPath = $hold['cover_path'] ?? '';
                                        if (!empty($coverPath) && file_exists(BASE_PATH . '/' . $coverPath)): 
                                            $coverData = getCoverBase64($coverPath);
                                        ?>
                                            <img src="<?= $coverData ?>" class="book-cover-small" alt="Cover">
                                        <?php else: ?>
                                            <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                        <?php endif; ?>
                                        <div>
                                            <div class="fw-semibold small"><?= htmlspecialchars($hold['title']) ?></div>
                                            <small class="text-muted">
                                                <i class="fas fa-barcode"></i> <?= htmlspecialchars($hold['book_barcode']) ?>
                                            </small>
                                            <?php if (isset($hold['author']) && $hold['author']): ?>
                                                <br><small class="text-muted">by <?= htmlspecialchars($hold['author']) ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-semibold small"><?= htmlspecialchars($hold['member_name']) ?></div>
                                    <?php if (isset($hold['member_category']) && $hold['member_category']): ?>
                                        <small class="text-muted"><?= htmlspecialchars($hold['member_category']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <code><?= htmlspecialchars($hold['admno']) ?></code>
                                </td>
                                <td class="text-center">
                                    <?= date('M d, Y', strtotime($hold['hold_date'])) ?>
                                    <br><small class="text-muted"><?= date('H:i', strtotime($hold['created_at'] ?? $hold['hold_date'])) ?></small>
                                </td>
                                <td class="text-center <?= strtotime($hold['expiry_date']) < time() && $hold['status'] != 'cancelled' && $hold['status'] != 'picked_up' ? 'text-danger fw-bold' : '' ?>">
                                    <?= date('M d, Y', strtotime($hold['expiry_date'])) ?>
                                    <?php if (strtotime($hold['expiry_date']) < time() && $hold['status'] != 'cancelled' && $hold['status'] != 'picked_up'): ?>
                                        <br><span class="badge bg-danger">EXPIRED</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php
                                    $statusClass = 'secondary';
                                    $statusIcon = 'fa-circle';
                                    if ($hold['status'] == 'pending') { 
                                        $statusClass = 'warning'; 
                                        $statusIcon = 'fa-clock';
                                    } elseif ($hold['status'] == 'available') { 
                                        $statusClass = 'success'; 
                                        $statusIcon = 'fa-check-circle';
                                    } elseif ($hold['status'] == 'picked_up') { 
                                        $statusClass = 'info'; 
                                        $statusIcon = 'fa-arrow-right';
                                    } elseif ($hold['status'] == 'cancelled') { 
                                        $statusClass = 'danger'; 
                                        $statusIcon = 'fa-times-circle';
                                    }
                                    ?>
                                    <span class="badge bg-<?= $statusClass ?> badge-status">
                                        <i class="fas <?= $statusIcon ?>"></i>
                                        <?= ucfirst(str_replace('_', ' ', $hold['status'])) ?>
                                    </span>
                                </td>
                                <td class="text-center no-print">
                                    <?php if ($hold['status'] == 'pending'): ?>
                                        <form method="post" style="display:inline-block;" 
                                              onsubmit="return confirm('Are you sure you want to cancel this hold?');">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <button type="submit" class="btn btn-sm btn-danger action-btn" title="Cancel Hold">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </form>
                                    <?php elseif ($hold['status'] == 'available'): ?>
                                        <form method="post" style="display:inline-block;" 
                                              onsubmit="return confirm('Mark this hold as picked up? This will log a book exit.');">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="mark_picked">
                                            <button type="submit" class="btn btn-sm btn-success action-btn" title="Mark Picked Up">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                        <form method="post" style="display:inline-block;">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="send_reminder">
                                            <button type="submit" class="btn btn-sm btn-info action-btn text-white" title="Send Reminder">
                                                <i class="fas fa-bell"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ========== PAGINATION ========== -->
    <?php 
    $totalPages = max(1, ceil($totalHolds / $perPage));
    if ($totalPages > 1): 
    ?>
    <div class="d-flex justify-content-between align-items-center mt-3 no-print">
        <small class="text-muted">
            Showing <?= $offset + 1 ?> - <?= min($offset + $perPage, $totalHolds) ?> of <?= number_format($totalHolds) ?> holds
        </small>
        <nav aria-label="Holds pagination">
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?status=<?= urlencode($filterStatus) ?>&search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                </li>
                <?php 
                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);
                if ($startPage > 1): ?>
                    <li class="page-item"><a class="page-link" href="?status=<?= urlencode($filterStatus) ?>&search=<?= urlencode($search) ?>&page=1">1</a></li>
                    <?php if ($startPage > 2): ?>
                        <li class="page-item disabled"><span class="page-link">…</span></li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?status=<?= urlencode($filterStatus) ?>&search=<?= urlencode($search) ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <?php if ($endPage < $totalPages): ?>
                    <?php if ($endPage < $totalPages - 1): ?>
                        <li class="page-item disabled"><span class="page-link">…</span></li>
                    <?php endif; ?>
                    <li class="page-item"><a class="page-link" href="?status=<?= urlencode($filterStatus) ?>&search=<?= urlencode($search) ?>&page=<?= $totalPages ?>"><?= $totalPages ?></a></li>
                <?php endif; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?status=<?= urlencode($filterStatus) ?>&search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <!-- ========== FOOTER INFO ========== -->
    <div class="mt-3 text-center text-muted small">
        <i class="fas fa-info-circle"></i> 
        Holds expire after <?= $settings['hold_days'] ?? 7 ?> days if not picked up.
        <?php if ($settings['allow_holds'] ?? 1): ?>
            <span class="text-success"><i class="fas fa-check-circle"></i> Holds enabled</span>
        <?php else: ?>
            <span class="text-danger"><i class="fas fa-times-circle"></i> Holds disabled</span>
        <?php endif; ?>
        <span class="mx-2">|</span>
        <i class="fas fa-clock"></i> <?= date('H:i:s') ?>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Alt+F to focus search
    if (e.altKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) searchInput.focus();
    }
    // Alt+R to reset
    if (e.altKey && e.key === 'r') {
        e.preventDefault();
        window.location.href = 'holds.php';
    }
});
</script>

</body>
</html>