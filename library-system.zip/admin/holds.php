<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$filterStatus = $_GET['status'] ?? 'all';
$search = trim($_GET['search'] ?? '');

// Build query
$sql = "SELECT h.*, b.title, b.author, b.available as book_available 
        FROM book_holds h 
        JOIN books b ON h.book_barcode = b.barcode 
        WHERE 1=1";
$params = [];
if ($filterStatus !== 'all') {
    $sql .= " AND h.status = ?";
    $params[] = $filterStatus;
}
if (!empty($search)) {
    $sql .= " AND (h.book_barcode LIKE ? OR h.member_name LIKE ? OR h.admno LIKE ? OR b.title LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}
$sql .= " ORDER BY h.hold_date ASC, h.status ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$holds = $stmt->fetchAll();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $action = $_POST['action'] ?? '';
    $msg = '';
    
    if ($action === 'cancel') {
        $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ?")->execute([$id]);
        $msg = "Hold cancelled.";
    } elseif ($action === 'mark_picked') {
        $db->prepare("UPDATE book_holds SET status = 'picked_up' WHERE id = ?")->execute([$id]);
        $msg = "Hold marked as picked up.";
    } elseif ($action === 'send_reminder') {
        $hold = $db->prepare("SELECT * FROM book_holds WHERE id = ?")->execute([$id])->fetch();
        if ($hold && $hold['status'] == 'available') {
            $member = $db->prepare("SELECT email, name FROM members WHERE admno = ?")->execute([$hold['admno']])->fetch();
            $book = $db->prepare("SELECT title FROM books WHERE barcode = ?")->execute([$hold['book_barcode']])->fetch();
            if ($member && $book) {
                $subject = "Reminder: Hold Available - {$book['title']}";
                $body = "Dear {$member['name']},\n\nThis is a reminder that the book \"{$book['title']}\" is still waiting for you at the library. Please pick it up before {$hold['expiry_date']}.\n\nThank you.";
                $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$member['email'], $subject, $body]);
                $msg = "Reminder email queued.";
            } else {
                $msg = "Member or book not found.";
            }
        } else {
            $msg = "Hold is not available for pickup.";
        }
    } else {
        $msg = "Invalid action.";
    }
    header("Location: holds.php?status=$filterStatus&search=" . urlencode($search) . "&msg=" . urlencode($msg));
    exit;
}

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Holds</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include 'nav.php'; ?>
<div class="container mt-4">
    <h2><i class="fas fa-hand-paper"></i> Hold Queue Management (Admin)</h2>
    <?php if ($msg): ?>
        <div class="alert alert-info alert-dismissible fade show"><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label>Status Filter</label>
                    <select name="status" class="form-select">
                        <option value="all" <?= $filterStatus == 'all' ? 'selected' : '' ?>>All</option>
                        <option value="pending" <?= $filterStatus == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="available" <?= $filterStatus == 'available' ? 'selected' : '' ?>>Available (on hold shelf)</option>
                        <option value="picked_up" <?= $filterStatus == 'picked_up' ? 'selected' : '' ?>>Picked Up</option>
                        <option value="cancelled" <?= $filterStatus == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label>Search (barcode, member name, adm no, book title)</label>
                    <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($search) ?>" placeholder="Search...">
                </div>
                <div class="col-md-3 align-self-end">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-list"></i> Holds List</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>ID</th><th>Book (Barcode)</th><th>Member</th><th>Adm No</th><th>Hold Date</th><th>Expiry Date</th><th>Status</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($holds)): ?>
                            <tr><td colspan="8" class="text-center text-muted py-4">No holds found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($holds as $hold): ?>
                            <tr>
                                <td><?= $hold['id'] ?></td>
                                <td>
                                    <?= htmlspecialchars($hold['title']) ?><br>
                                    <small class="text-muted"><?= htmlspecialchars($hold['book_barcode']) ?></small>
                                 </td>
                                 <td><?= htmlspecialchars($hold['member_name']) ?></td>
                                 <td><?= htmlspecialchars($hold['admno']) ?></td>
                                 <td><?= $hold['hold_date'] ?></td>
                                 <td><?= $hold['expiry_date'] ?></td>
                                 <td>
                                    <?php
                                    $badgeClass = 'secondary';
                                    if ($hold['status'] == 'pending') $badgeClass = 'warning';
                                    elseif ($hold['status'] == 'available') $badgeClass = 'success';
                                    elseif ($hold['status'] == 'picked_up') $badgeClass = 'info';
                                    elseif ($hold['status'] == 'cancelled') $badgeClass = 'danger';
                                    ?>
                                    <span class="badge bg-<?= $badgeClass ?>"><?= $hold['status'] ?></span>
                                 </td>
                                 <td>
                                    <?php if ($hold['status'] == 'pending'): ?>
                                        <form method="post" style="display:inline-block;" onsubmit="return confirm('Cancel this hold?');">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-times"></i> Cancel</button>
                                        </form>
                                    <?php elseif ($hold['status'] == 'available'): ?>
                                        <form method="post" style="display:inline-block;" onsubmit="return confirm('Mark as picked up?');">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="mark_picked">
                                            <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Picked Up</button>
                                        </form>
                                        <form method="post" style="display:inline-block;">
                                            <input type="hidden" name="id" value="<?= $hold['id'] ?>">
                                            <input type="hidden" name="action" value="send_reminder">
                                            <button type="submit" class="btn btn-sm btn-info"><i class="fas fa-bell"></i> Reminder</button>
                                        </form>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                             </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>