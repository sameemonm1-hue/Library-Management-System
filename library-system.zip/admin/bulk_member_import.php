
```php
<?php
/**
 * admin/bulk_member_import.php
 * 
 * Bulk import members from CSV file.
 * CSV format: admno, name, member_category, class, division, email, phone, password
 * 
 * Access: Admin only
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$error = '';
$success = '';
$imported = 0;
$skipped = 0;
$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "File upload failed. Error code: " . $file['error'];
    } else {
        $handle = fopen($file['tmp_name'], 'r');
        if ($handle === false) {
            $error = "Cannot read uploaded file.";
        } else {
            // Get headers (first row)
            $headers = fgetcsv($handle);
            if (!$headers) {
                $error = "Empty CSV file.";
            } else {
                // Normalise headers
                $headers = array_map(function($h) {
                    return strtolower(trim(str_replace(' ', '_', $h)));
                }, $headers);
                
                // Required columns
                $required = ['admno', 'name'];
                $missing = array_diff($required, $headers);
                if (!empty($missing)) {
                    $error = "Missing required columns: " . implode(', ', $missing);
                } else {
                    $idx_admno = array_search('admno', $headers);
                    $idx_name = array_search('name', $headers);
                    $idx_category = array_search('member_category', $headers);
                    $idx_class = array_search('class', $headers);
                    $idx_division = array_search('division', $headers);
                    $idx_email = array_search('email', $headers);
                    $idx_phone = array_search('phone', $headers);
                    $idx_password = array_search('password', $headers);
                    
                    $db->beginTransaction();
                    try {
                        $rowNum = 1;
                        while (($row = fgetcsv($handle)) !== false) {
                            $rowNum++;
                            $admno = trim($row[$idx_admno] ?? '');
                            $name = trim($row[$idx_name] ?? '');
                            
                            if (empty($admno) || empty($name)) {
                                $errors[] = "Row $rowNum: Missing admno or name";
                                $skipped++;
                                continue;
                            }
                            
                            // Check if member already exists
                            $check = $db->prepare("SELECT id FROM members WHERE admno = ?");
                            $check->execute([$admno]);
                            if ($check->fetch()) {
                                $errors[] = "Row $rowNum: Member $admno already exists";
                                $skipped++;
                                continue;
                            }
                            
                            $member_category = $row[$idx_category] ?? 'Student';
                            $class = $row[$idx_class] ?? '';
                            $division = $row[$idx_division] ?? '';
                            $email = $row[$idx_email] ?? '';
                            $phone = $row[$idx_phone] ?? '';
                            $password = !empty($row[$idx_password]) ? password_hash($row[$idx_password], PASSWORD_DEFAULT) : password_hash('123456', PASSWORD_DEFAULT);
                            
                            $stmt = $db->prepare("INSERT INTO members (admno, name, member_category, class, division, email, phone, password, status, admission_date, created_at) 
                                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', date('now'), datetime('now'))");
                            $stmt->execute([$admno, $name, $member_category, $class, $division, $email, $phone, $password]);
                            $imported++;
                        }
                        $db->commit();
                        $success = "Imported $imported members. Skipped $skipped.";
                        if (!empty($errors)) {
                            $success .= "<br>Errors:<br>" . implode('<br>', array_slice($errors, 0, 20));
                            if (count($errors) > 20) $success .= "<br>... and " . (count($errors) - 20) . " more.";
                        }
                        logActivity($_SESSION['username'], 'BULK_MEMBER_IMPORT', "Imported $imported members from CSV");
                    } catch (PDOException $e) {
                        $db->rollBack();
                        $error = "Database error: " . $e->getMessage();
                    }
                }
            }
            fclose($handle);
        }
    }
}

renderHeader('Bulk Member Import');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-upload"></i> Bulk Import Members (CSV)</h2>
        <div>
            <a href="members.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Members</a>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-file-csv"></i> Upload CSV File</h5>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">CSV File</label>
                    <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                    <div class="form-text">Required columns: <code>admno, name</code>. Optional: <code>member_category, class, division, email, phone, password</code></div>
                </div>
                <button type="submit" class="btn btn-primary">Import Members</button>
                <a href="#" id="downloadSample" class="btn btn-secondary">Download Sample CSV</a>
            </form>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-info-circle"></i> CSV Format Guide</h5>
        </div>
        <div class="card-body">
            <p><strong>Required columns:</strong></p>
            <ul>
                <li><code>admno</code> – Unique member admission number (e.g., MEM001)</li>
                <li><code>name</code> – Full name</li>
            </ul>
            <p><strong>Optional columns:</strong></p>
            <ul>
                <li><code>member_category</code> – Student, Staff, Teacher, General, Visitor (default: Student)</li>
                <li><code>class</code> – Class / Department</li>
                <li><code>division</code> – Division / Course</li>
                <li><code>email</code> – Email address</li>
                <li><code>phone</code> – Phone number</li>
                <li><code>password</code> – Plain text password (will be hashed). If empty, default '123456' is used.</li>
            </ul>
            <p><strong>Sample CSV:</strong></p>
            <pre>admno,name,member_category,class,division,email,phone,password
MEM001,John Doe,Student,Grade 10,A,john@example.com,1234567890,
MEM002,Jane Smith,Teacher,Science Dept,,jane@example.com,0987654321,secret123</pre>
        </div>
    </div>
</div>

<script>
document.getElementById('downloadSample')?.addEventListener('click', function(e) {
    e.preventDefault();
    let csv = "admno,name,member_category,class,division,email,phone,password\n";
    csv += "MEM001,John Doe,Student,Grade 10,A,john@example.com,1234567890,\n";
    csv += "MEM002,Jane Smith,Teacher,Science Dept,,jane@example.com,0987654321,secret123\n";
    let blob = new Blob(["\uFEFF" + csv], {type: 'text/csv;charset=utf-8;'});
    let link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'sample_members.csv';
    link.click();
    URL.revokeObjectURL(link.href);
});
</script>

<?php renderFooter(); ?>