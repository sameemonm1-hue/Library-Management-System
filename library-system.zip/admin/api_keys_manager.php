<?php
/**
 * API Keys Manager
 * Manage external API keys (ISBNdb, WorldCat, OpenAI) separately.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$message = '';
$error = '';

// CSRF token
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf_token = $_SESSION['csrf_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_keys'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid CSRF token";
    } else {
        $isbndb = trim($_POST['isbndb_api_key'] ?? '');
        $worldcat = trim($_POST['worldcat_api_key'] ?? '');
        $openai = trim($_POST['openai_api_key'] ?? '');
        $stmt = $db->prepare("UPDATE settings SET isbndb_api_key = ?, worldcat_api_key = ?, openai_api_key = ? WHERE id = 1");
        if ($stmt->execute([$isbndb, $worldcat, $openai])) {
            $message = "API keys saved successfully.";
            logActivity($_SESSION['username'], 'API_KEYS_UPDATE', 'Updated external API keys');
        } else {
            $error = "Failed to save API keys.";
        }
    }
}

$settings = getSettings();
renderHeader('API Keys Manager');
?>
<div class="container-fluid px-4">
    <h2><i class="fas fa-key"></i> External API Keys Manager</h2>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="mb-3">
                    <label>ISBNdb API Key</label>
                    <input type="text" name="isbndb_api_key" class="form-control" value="<?= htmlspecialchars($settings['isbndb_api_key'] ?? '') ?>">
                    <small class="text-muted">Get it from <a href="https://isbndb.com/" target="_blank">ISBNdb</a></small>
                </div>
                <div class="mb-3">
                    <label>WorldCat API Key</label>
                    <input type="text" name="worldcat_api_key" class="form-control" value="<?= htmlspecialchars($settings['worldcat_api_key'] ?? '') ?>">
                    <small class="text-muted">Requires OCLC subscription</small>
                </div>
                <div class="mb-3">
                    <label>OpenAI API Key (for semantic search)</label>
                    <input type="password" name="openai_api_key" class="form-control" value="<?= htmlspecialchars($settings['openai_api_key'] ?? '') ?>">
                    <small class="text-muted">Get from <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI</a></small>
                </div>
                <button type="submit" name="save_keys" class="btn btn-primary">Save Keys</button>
            </form>
        </div>
    </div>
    <div class="mt-3">
        <a href="books.php" class="btn btn-secondary">Back to Books</a>
    </div>
</div>
<?php renderFooter(); ?>