<?php
/**
 * Advanced Bulk Import with Metadata Fetch
 * 
 * Processes a CSV file and for each row with an ISBN, automatically fetches
 * metadata (title, author, publisher, year, pages, subject, summary, cover)
 * from external sources (Google Books, OpenLibrary, etc.)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$message = '';
$error = '';

// Helper: fetch metadata using the API we created
function fetchBookMetadataAdvanced($isbn) {
    $url = "api_metadata_fetch.php?action=fetch&isbn=" . urlencode($isbn) . "&source=auto";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    if ($data && $data['success']) {
        return $data['data'];
    }
    return null;
}

// Process upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['bulk_csv']) && $_FILES['bulk_csv']['error'] === UPLOAD_ERR_OK) {
    $handle = fopen($_FILES['bulk_csv']['tmp_name'], 'r');
    if ($handle) {
        $header = fgetcsv($handle);
        $requiredCols = ['barcode', 'title'];
        $colMap = [];
        foreach ($header as $idx => $col) $colMap[strtolower(trim($col))] = $idx;
        $missing = array_diff($requiredCols, array_keys($colMap));
        if (!empty($missing)) {
            $error = "Missing required columns: " . implode(', ', $missing);
        } else {
            $imported = 0;
            $errors = [];
            $autoFetch = isset($_POST['auto_fetch_metadata']);
            while (($row = fgetcsv($handle)) !== false) {
                $data = [];
                foreach ($colMap as $key => $idx) $data[$key] = $row[$idx] ?? '';
                $barcode = trim($data['barcode']);
                $title = trim($data['title']);
                if (empty($barcode) || empty($title)) {
                    $errors[] = "Row " . ($imported+2) . ": missing barcode or title";
                    continue;
                }
                $check = $db->prepare("SELECT barcode FROM books WHERE barcode = ?");
                $check->execute([$barcode]);
                if ($check->fetch()) {
                    $errors[] = "Barcode $barcode already exists";
                    continue;
                }
                $isbn = preg_replace('/[^0-9X]/i', '', $data['isbn'] ?? '');
                $coverPath = '';
                if ($autoFetch && !empty($isbn) && strlen($isbn) >= 10) {
                    $meta = fetchBookMetadataAdvanced($isbn);
                    if ($meta) {
                        if (empty($title)) $title = $meta['title'];
                        if (empty($data['author'])) $data['author'] = $meta['author'];
                        if (empty($data['publisher'])) $data['publisher'] = $meta['publisher'];
                        if (empty($data['year'])) $data['year'] = $meta['year'];
                        if (empty($data['pages'])) $data['pages'] = $meta['pages'];
                        if (empty($data['subject'])) $data['subject'] = $meta['subject'];
                        if (empty($data['summary'])) $data['summary'] = $meta['summary'];
                        if (!empty($meta['cover_url'])) {
                            // Download cover
                            $coverFileName = BOOK_COVER_DIR . 'bulk_' . $barcode . '_' . time() . '.jpg';
                            $imgData = @file_get_contents($meta['cover_url']);
                            if ($imgData && file_put_contents($coverFileName, $imgData)) {
                                $coverPath = $coverFileName;
                            }
                        }
                    }
                }
                // If cover URL present in CSV
                if (empty($coverPath) && !empty($data['cover_url'])) {
                    $coverFileName = BOOK_COVER_DIR . 'bulk_' . $barcode . '_' . time() . '.jpg';
                    $imgData = @file_get_contents($data['cover_url']);
                    if ($imgData && file_put_contents($coverFileName, $imgData)) $coverPath = $coverFileName;
                }
                $stmt = $db->prepare("INSERT INTO books (barcode, title, sub_title, author, author2, collaborator, subject, isbn, publisher, year, pages, cover_path, quantity, available, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1,1,datetime('now'))");
                $stmt->execute([
                    $barcode, $title, $data['sub_title'] ?? '', $data['author'] ?? '',
                    $data['author2'] ?? '', $data['collaborator'] ?? '', $data['subject'] ?? '',
                    $isbn, $data['publisher'] ?? '', $data['year'] ?? '', (int)($data['pages'] ?? 0),
                    $coverPath
                ]);
                $imported++;
            }
            fclose($handle);
            $msg = "Imported $imported books.";
            if ($errors) $msg .= " Errors: " . implode('; ', array_slice($errors, 0, 10));
            showToast($msg, $errors ? 'warning' : 'success');
            header("Location: bulk_import_advanced.php");
            exit;
        }
    } else {
        $error = "Cannot read uploaded file.";
    }
}

renderHeader('Advanced Bulk Import');
?>
<div class="container-fluid px-4">
    <h2><i class="fas fa-upload"></i> Advanced Bulk Import (with Metadata Fetch)</h2>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="card">
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">CSV File</label>
                    <input type="file" name="bulk_csv" class="form-control" accept=".csv" required>
                    <small>Must contain at least <code>barcode</code> and <code>title</code> columns.</small>
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" name="auto_fetch_metadata" id="autoFetch" checked>
                    <label class="form-check-label" for="autoFetch">Automatically fetch metadata and cover images from ISBN (if available)</label>
                </div>
                <button type="submit" class="btn btn-primary">Start Import</button>
                <a href="books.php" class="btn btn-secondary">Cancel</a>
            </form>
            <hr>
            <h6>Sample CSV structure</h6>
            <pre>barcode,title,sub_title,author,isbn,publisher,year,pages,cover_url
BK001,The Great Gatsby,,F. Scott Fitzgerald,9780743273565,Scribner,2004,180,https://example.com/cover.jpg</pre>
            <a href="#" id="downloadSample" class="btn btn-sm btn-outline-info">Download Sample CSV</a>
        </div>
    </div>
</div>
<script>
document.getElementById('downloadSample')?.addEventListener('click', function(e) {
    e.preventDefault();
    let sample = "barcode,title,sub_title,author,isbn,publisher,year,pages,cover_url\nBK001,The Great Gatsby,,F. Scott Fitzgerald,9780743273565,Scribner,2004,180,";
    let blob = new Blob([sample], {type: 'text/csv'});
    let a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'sample_books_advanced.csv';
    a.click();
    URL.revokeObjectURL(a.href);
});
</script>
<?php renderFooter(); ?>