<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$input = json_decode(file_get_contents('php://input'), true);
if ($input && $input['action'] === 'import_from_z3950') {
    $rec = $input['record'];
    $barcode = 'Z3950_' . time() . '_' . rand(100, 999);
    $title = substr($rec['title'] ?? '', 0, 255);
    $author = substr($rec['author'] ?? '', 0, 255);
    $isbn = substr($rec['isbn'] ?? '', 0, 20);
    $publisher = substr($rec['publisher'] ?? '', 0, 255);
    $year = substr($rec['year'] ?? '', 0, 20);
    $call_number = substr($rec['call_number'] ?? '', 0, 50);
    $pages = (int)($rec['pages'] ?? 0);
    
    if (empty($title)) {
        echo json_encode(['success' => false, 'error' => 'No title found']);
        exit;
    }
    
    $stmt = $db->prepare("INSERT INTO books (barcode, title, author, isbn, publisher, year, call_number, pages, quantity, available, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, datetime('now'))");
    $stmt->execute([$barcode, $title, $author, $isbn, $publisher, $year, $call_number, $pages]);
    echo json_encode(['success' => true]);
    exit;
}
echo json_encode(['success' => false, 'error' => 'Invalid request']);