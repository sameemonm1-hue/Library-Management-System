<?php
/**
 * Email Template Manager
 * 
 * Features:
 * - List, add, edit, delete email templates
 * - Preview templates with sample data
 * - Support for placeholders (e.g., {member_name}, {book_title}, {days_overdue})
 * - Integration with email_queue system
 * 
 * Table: email_templates
 *   - id INTEGER PRIMARY KEY
 *   - template_key VARCHAR(50) UNIQUE
 *   - subject VARCHAR(255)
 *   - body TEXT
 *   - created_at DATETIME
 *   - updated_at DATETIME
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// Ensure email_templates table exists with correct schema
$db->exec("CREATE TABLE IF NOT EXISTS email_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_key VARCHAR(50) NOT NULL UNIQUE,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
)");

// Add sample templates if table is empty
$check = $db->query("SELECT COUNT(*) FROM email_templates")->fetchColumn();
if ($check == 0) {
    $defaults = [
        [
            'key' => 'overdue',
            'subject' => 'Overdue Book Notice',
            'body' => '<p>Dear {member_name},</p><p>The book "{book_title}" is overdue by {days_overdue} days. Fine accrued: {fine_amount}.</p><p>Please return it as soon as possible to avoid additional charges.</p><p>Regards,<br>Library Staff</p>'
        ],
        [
            'key' => 'hold_ready',
            'subject' => 'Hold Available for Pickup',
            'body' => '<p>Dear {member_name},</p><p>The book "{book_title}" is now available for you at the library. Please collect it by {expiry_date}.</p><p>Thank you,<br>Library Staff</p>'
        ],
        [
            'key' => 'membership_expiry',
            'subject' => 'Library Membership Expiry Reminder',
            'body' => '<p>Dear {member_name},</p><p>Your library membership expires on {expiry_date}. Please renew your membership to continue enjoying library services.</p><p>Regards,<br>Library Staff</p>'
        ],
        [
            'key' => 'return_receipt',
            'subject' => 'Book Return Receipt',
            'body' => '<p>Dear {member_name},</p><p>The following book has been returned: "{book_title}" (Barcode: {barcode}).</p><p>If you had any fines, they have been updated in your account.</p><p>Thank you,<br>Library Staff</p>'
        ],
        [
            'key' => 'fine_payment',
            'subject' => 'Fine Payment Receipt',
            'body' => '<p>Dear {member_name},</p><p>We have received your payment of {amount} towards your library fines. Your current outstanding fine is {outstanding_fine}.</p><p>Receipt No: {receipt_no}</p><p>Thank you,<br>Library Staff</p>'
        ]
    ];
    $insert = $db->prepare("INSERT INTO email_templates (template_key, subject, body) VALUES (?, ?, ?)");
    foreach ($defaults as $tpl) {
        $insert->execute([$tpl['key'], $tpl['subject'], $tpl['body']]);
    }
}

// Handle AJAX preview request
if (isset($_GET['preview']) && isset($_GET['key'])) {
    header('Content-Type: text/html');
    $key = $_GET['key'];
    $sampleData = [
        '{member_name}' => 'John Doe',
        '{member_admno}' => 'MEM001',
        '{book_title}' => 'The Great Gatsby',
        '{book_barcode}' => 'BK001',
        '{days_overdue}' => '5',
        '{fine_amount}' => '$10.00',
        '{expiry_date}' => date('Y-m-d', strtotime('+7 days')),
        '{amount}' => '$15.00',
        '{outstanding_fine}' => '$5.00',
        '{receipt_no}' => 'RCPT-20240101-001',
        '{barcode}' => 'BK001',
        '{due_date}' => date('Y-m-d', strtotime('+14 days')),
        '{institution}' => 'Library Name'
    ];
    $stmt = $db->prepare("SELECT subject, body FROM email_templates WHERE template_key = ?");
    $stmt->execute([$key]);
    $template = $stmt->fetch();
    if ($template) {
        $subject = str_replace(array_keys($sampleData), array_values($sampleData), $template['subject']);
        $body = str_replace(array_keys($sampleData), array_values($sampleData), $template['body']);
        echo "<div class='card'><div class='card-header bg-info text-white'><strong>Subject:</strong> " . htmlspecialchars($subject) . "</div><div class='card-body'>" . $body . "</div></div>";
    } else {
        echo "<div class='alert alert-danger'>Template not found</div>";
    }
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $key = trim($_POST['template_key']);
        $subject = trim($_POST['subject']);
        $body = trim($_POST['body']);
        if (empty($key) || empty($subject) || empty($body)) {
            showToast("All fields are required", "danger");
        } else {
            // Check if key exists
            $check = $db->prepare("SELECT id FROM email_templates WHERE template_key = ?");
            $check->execute([$key]);
            if ($check->fetch()) {
                showToast("Template key already exists", "danger");
            } else {
                $stmt = $db->prepare("INSERT INTO email_templates (template_key, subject, body, created_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)");
                $stmt->execute([$key, $subject, $body]);
                showToast("Template added successfully", "success");
                logActivity($_SESSION['username'], 'EMAIL_TEMPLATE_ADD', "Added template: $key");
            }
        }
    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $key = trim($_POST['template_key']);
        $subject = trim($_POST['subject']);
        $body = trim($_POST['body']);
        if (empty($key) || empty($subject) || empty($body)) {
            showToast("All fields are required", "danger");
        } else {
            // Check uniqueness excluding current ID
            $check = $db->prepare("SELECT id FROM email_templates WHERE template_key = ? AND id != ?");
            $check->execute([$key, $id]);
            if ($check->fetch()) {
                showToast("Template key already exists", "danger");
            } else {
                $stmt = $db->prepare("UPDATE email_templates SET template_key = ?, subject = ?, body = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmt->execute([$key, $subject, $body, $id]);
                showToast("Template updated successfully", "success");
                logActivity($_SESSION['username'], 'EMAIL_TEMPLATE_EDIT', "Edited template: $key");
            }
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $db->prepare("DELETE FROM email_templates WHERE id = ?");
        $stmt->execute([$id]);
        showToast("Template deleted", "success");
        logActivity($_SESSION['username'], 'EMAIL_TEMPLATE_DELETE', "Deleted template ID: $id");
    }
    
    // Redirect to avoid form resubmission
    header("Location: email_templates.php");
    exit;
}

// Fetch all templates
$templates = $db->query("SELECT * FROM email_templates ORDER BY template_key")->fetchAll();

$institution = getInstitution();

renderHeader('Email Template Manager');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-envelope"></i> Email Template Manager</h2>
        <div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="fas fa-plus"></i> Add Template
            </button>
            <a href="settings.php" class="btn btn-secondary"><i class="fas fa-cog"></i> SMTP Settings</a>
            <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>
    
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> 
        <strong>Placeholders:</strong> Use <code>{member_name}</code>, <code>{book_title}</code>, <code>{days_overdue}</code>, <code>{fine_amount}</code>, <code>{expiry_date}</code>, <code>{amount}</code>, <code>{receipt_no}</code>, <code>{barcode}</code>, <code>{due_date}</code>, <code>{institution}</code>. 
        These will be replaced with actual values when sending emails.
    </div>
    
    <div class="card">
        <div class="card-header bg-white fw-bold">
            <i class="fas fa-list"></i> Email Templates
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 15%">Template Key</th>
                            <th style="width: 35%">Subject</th>
                            <th style="width: 30%">Body Preview</th>
                            <th style="width: 20%">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($templates)): ?>
                            <tr><td colspan="4" class="text-center py-4">No templates found. Click "Add Template" to create one.</div></tr>
                        <?php else: ?>
                            <?php foreach ($templates as $tpl): ?>
                            <tr>
                                <td><code><?= htmlspecialchars($tpl['template_key']) ?></code></td>
                                <td><?= htmlspecialchars($tpl['subject']) ?></div>
                                <td>
                                    <?= htmlspecialchars(substr(strip_tags($tpl['body']), 0, 100)) ?>...
                                 </div>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-info" onclick="previewTemplate('<?= htmlspecialchars($tpl['template_key']) ?>')">
                                            <i class="fas fa-eye"></i> Preview
                                        </button>
                                        <button class="btn btn-warning" onclick="editTemplate(<?= $tpl['id'] ?>, '<?= addslashes($tpl['template_key']) ?>', '<?= addslashes($tpl['subject']) ?>', '<?= addslashes($tpl['body']) ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="post" style="display:inline-block" onsubmit="return confirm('Delete this template?')">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= $tpl['id'] ?>">
                                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                 </div>
                             </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Template Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-plus"></i> Add Email Template</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label">Template Key *</label>
                        <input type="text" name="template_key" class="form-control" required pattern="[a-z_]+" title="Lowercase letters and underscores only">
                        <small class="text-muted">e.g., overdue, hold_ready, membership_expiry</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject *</label>
                        <input type="text" name="subject" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Body (HTML) *</label>
                        <textarea name="body" rows="8" class="form-control" required></textarea>
                        <small class="text-muted">You can use HTML tags. Placeholders: {member_name}, {book_title}, {days_overdue}, {fine_amount}, etc.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Template</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Template Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Email Template</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Template Key *</label>
                        <input type="text" name="template_key" id="edit_key" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject *</label>
                        <input type="text" name="subject" id="edit_subject" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Body (HTML) *</label>
                        <textarea name="body" id="edit_body" rows="8" class="form-control" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Template</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-eye"></i> Template Preview</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="previewContent">
                <div class="text-center py-4">Loading...</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function previewTemplate(key) {
    let modal = new bootstrap.Modal(document.getElementById('previewModal'));
    let contentDiv = document.getElementById('previewContent');
    contentDiv.innerHTML = '<div class="text-center py-4"><div class="spinner-border"></div> Loading preview...</div>';
    modal.show();
    
    fetch('email_templates.php?preview=1&key=' + encodeURIComponent(key))
        .then(response => response.text())
        .then(html => {
            contentDiv.innerHTML = html;
        })
        .catch(err => {
            contentDiv.innerHTML = '<div class="alert alert-danger">Error loading preview</div>';
        });
}

function editTemplate(id, key, subject, body) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_key').value = key;
    document.getElementById('edit_subject').value = subject;
    document.getElementById('edit_body').value = body;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

// Auto-dismiss alerts
setTimeout(function() {
    let alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        let bsAlert = new bootstrap.Alert(alert);
        setTimeout(() => bsAlert.close(), 5000);
    });
}, 3000);
</script>

<?php renderFooter(); ?>