<?php
/**
 * Research Databases Management Module
 * 
 * Features:
 * - Search & filter by name, category, type, status
 * - Pagination
 * - Export to CSV
 * - Bulk actions (delete, activate, deactivate, featured)
 * - Visit counter (track clicks)
 * - Logo upload (image)
 * - Multiple subjects/tags
 * - Subscription expiry date
 * - Last verified date
 * - Restore soft-deleted databases
 * - Statistics with total visits
 * - Full audit logging
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// Ensure upload directory exists
$logoDir = __DIR__ . '/../uploads/database_logos/';
if (!is_dir($logoDir)) mkdir($logoDir, 0777, true);

// ========== ENSURE TABLE HAS ALL COLUMNS ==========
$driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
$existingCols = ($driver === 'sqlite') ? $db->query("PRAGMA table_info(research_databases)")->fetchAll(PDO::FETCH_COLUMN, 1) : $db->query("SHOW COLUMNS FROM research_databases")->fetchAll(PDO::FETCH_COLUMN);

$newColumns = [
    'logo_path' => "TEXT DEFAULT ''",
    'subjects' => "TEXT DEFAULT ''",
    'expiry_date' => "DATE",
    'last_verified' => "DATE",
    'visits' => "INTEGER DEFAULT 0",
    'proxy_url' => "TEXT DEFAULT ''",
    'access_notes' => "TEXT DEFAULT ''",
    'contact_email' => "TEXT DEFAULT ''",
    'deleted_at' => "DATETIME"
];

foreach ($newColumns as $col => $def) {
    if (!in_array($col, $existingCols)) {
        try {
            $db->exec("ALTER TABLE research_databases ADD COLUMN $col $def");
        } catch (PDOException $e) { /* ignore */ }
    }
}

// Set default for visits if null
$db->exec("UPDATE research_databases SET visits = 0 WHERE visits IS NULL");

// ========== HELPER: LOGO UPLOAD ==========
function uploadDatabaseLogo($file, $dbName) {
    if ($file['error'] !== UPLOAD_ERR_OK) return '';
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp','svg'])) return '';
    $filename = 'db_' . preg_replace('/[^a-z0-9_-]/i', '_', $dbName) . '_' . time() . '.' . $ext;
    $target = __DIR__ . '/../uploads/database_logos/' . $filename;
    if (move_uploaded_file($file['tmp_name'], $target)) {
        return 'uploads/database_logos/' . $filename;
    }
    return '';
}

// ========== HANDLE CLICK TRACKING (for external redirects) ==========
if (isset($_GET['goto']) && is_numeric($_GET['goto'])) {
    $id = (int)$_GET['goto'];
    $stmt = $db->prepare("UPDATE research_databases SET visits = visits + 1 WHERE id = ?");
    $stmt->execute([$id]);
    $urlStmt = $db->prepare("SELECT url FROM research_databases WHERE id = ?");
    $urlStmt->execute([$id]);
    $url = $urlStmt->fetchColumn();
    if ($url) {
        header("Location: " . $url);
        exit;
    }
}

// ========== PROCESS BULK ACTIONS ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    $ids = $_POST['ids'] ?? [];
    if (empty($ids)) {
        $error = "No items selected.";
    } else {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        switch ($_POST['bulk_action']) {
            case 'delete':
                $db->prepare("UPDATE research_databases SET is_active = 0, deleted_at = datetime('now') WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) deleted.";
                logActivity($_SESSION['username'], 'BULK_DELETE_DATABASES', "Deleted IDs: " . implode(',', $ids));
                break;
            case 'activate':
                $db->prepare("UPDATE research_databases SET is_active = 1, deleted_at = NULL WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) activated.";
                logActivity($_SESSION['username'], 'BULK_ACTIVATE_DATABASES', "Activated IDs: " . implode(',', $ids));
                break;
            case 'deactivate':
                $db->prepare("UPDATE research_databases SET is_active = 0 WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) deactivated.";
                logActivity($_SESSION['username'], 'BULK_DEACTIVATE_DATABASES', "Deactivated IDs: " . implode(',', $ids));
                break;
            case 'featured':
                $db->prepare("UPDATE research_databases SET is_featured = 1 WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) marked as featured.";
                logActivity($_SESSION['username'], 'BULK_FEATURED_DATABASES', "Featured IDs: " . implode(',', $ids));
                break;
            case 'unfeatured':
                $db->prepare("UPDATE research_databases SET is_featured = 0 WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) unmarked as featured.";
                logActivity($_SESSION['username'], 'BULK_UNFEATURED_DATABASES', "Unfeatured IDs: " . implode(',', $ids));
                break;
            case 'restore':
                $db->prepare("UPDATE research_databases SET is_active = 1, deleted_at = NULL WHERE id IN ($placeholders)")->execute($ids);
                $message = count($ids) . " database(s) restored.";
                logActivity($_SESSION['username'], 'BULK_RESTORE_DATABASES', "Restored IDs: " . implode(',', $ids));
                break;
        }
        header("Location: research_databases.php?msg=" . urlencode($message));
        exit;
    }
}

// ========== EXPORT TO CSV ==========
if (isset($_GET['export_csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=research_databases_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['ID', 'Name', 'Description', 'URL', 'Category', 'Type', 'Subjects', 'Featured', 'Status', 'Visits', 'Expiry Date', 'Last Verified', 'Created']);
    $stmt = $db->query("SELECT id, name, description, url, category, type, subjects, is_featured, is_active, visits, expiry_date, last_verified, created_at FROM research_databases ORDER BY name");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($out, [
            $row['id'], $row['name'], $row['description'], $row['url'], $row['category'],
            $row['type'], $row['subjects'], $row['is_featured'] ? 'Yes' : 'No',
            $row['is_active'] ? 'Active' : 'Inactive', $row['visits'] ?? 0,
            $row['expiry_date'], $row['last_verified'], $row['created_at']
        ]);
    }
    fclose($out);
    exit;
}

// ========== HANDLE ADD/EDIT/DELETE/TOGGLE ==========
$message = '';
$error = '';

// Add Database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = trim($_POST['name'] ?? '');
    $url = trim($_POST['url'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $type = $_POST['type'] ?? 'academic';
    $icon = trim($_POST['icon'] ?? 'database');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    $sort_order = (int)($_POST['sort_order'] ?? 999);
    $subjects = trim($_POST['subjects'] ?? '');
    $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
    $proxy_url = trim($_POST['proxy_url'] ?? '');
    $access_notes = trim($_POST['access_notes'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');
    
    $logoPath = '';
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $logoPath = uploadDatabaseLogo($_FILES['logo'], $name);
    }
    
    if (empty($name) || empty($url)) {
        $error = "Database Name and URL are required!";
    } else {
        try {
            $stmt = $db->prepare("INSERT INTO research_databases 
                (name, description, url, category, type, icon, is_featured, sort_order, subjects, expiry_date, proxy_url, access_notes, contact_email, logo_path, visits, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, datetime('now'), datetime('now'))");
            $stmt->execute([$name, $description, $url, $category, $type, $icon, $is_featured, $sort_order, $subjects, $expiry_date, $proxy_url, $access_notes, $contact_email, $logoPath]);
            $message = "Database added successfully!";
            logActivity($_SESSION['username'], 'ADD_RESEARCH_DATABASE', "Added database: $name");
        } catch (PDOException $e) {
            $error = "Failed to add database: " . $e->getMessage();
        }
    }
}

// Edit Database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = (int)$_POST['id'];
    $name = trim($_POST['name'] ?? '');
    $url = trim($_POST['url'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $type = $_POST['type'] ?? 'academic';
    $icon = trim($_POST['icon'] ?? 'database');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    $sort_order = (int)($_POST['sort_order'] ?? 999);
    $subjects = trim($_POST['subjects'] ?? '');
    $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
    $proxy_url = trim($_POST['proxy_url'] ?? '');
    $access_notes = trim($_POST['access_notes'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');
    
    $logoPath = $_POST['existing_logo'] ?? '';
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $newLogo = uploadDatabaseLogo($_FILES['logo'], $name);
        if ($newLogo) {
            if ($logoPath && file_exists($logoPath)) unlink($logoPath);
            $logoPath = $newLogo;
        }
    }
    
    if (empty($name) || empty($url)) {
        $error = "Database Name and URL are required!";
    } else {
        try {
            $stmt = $db->prepare("UPDATE research_databases 
                SET name = ?, description = ?, url = ?, category = ?, type = ?, icon = ?, 
                    is_featured = ?, sort_order = ?, subjects = ?, expiry_date = ?, proxy_url = ?, 
                    access_notes = ?, contact_email = ?, logo_path = ?, updated_at = datetime('now')
                WHERE id = ?");
            $stmt->execute([$name, $description, $url, $category, $type, $icon, $is_featured, $sort_order,
                $subjects, $expiry_date, $proxy_url, $access_notes, $contact_email, $logoPath, $id]);
            $message = "Database updated successfully!";
            logActivity($_SESSION['username'], 'EDIT_RESEARCH_DATABASE', "Updated database: $name");
        } catch (PDOException $e) {
            $error = "Failed to update database: " . $e->getMessage();
        }
    }
}

// Soft Delete
if (isset($_GET['delete']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->prepare("UPDATE research_databases SET is_active = 0, deleted_at = datetime('now') WHERE id = ?")->execute([$id]);
    $message = "Database deleted (soft delete).";
    logActivity($_SESSION['username'], 'DELETE_RESEARCH_DATABASE', "Deleted database ID: $id");
    header("Location: research_databases.php?msg=" . urlencode($message));
    exit;
}

// Restore
if (isset($_GET['restore']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $db->prepare("UPDATE research_databases SET is_active = 1, deleted_at = NULL WHERE id = ?")->execute([$id]);
    $message = "Database restored.";
    logActivity($_SESSION['username'], 'RESTORE_RESEARCH_DATABASE', "Restored database ID: $id");
    header("Location: research_databases.php?msg=" . urlencode($message));
    exit;
}

// Toggle Featured
if (isset($_GET['toggle_featured']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $current = $db->prepare("SELECT is_featured FROM research_databases WHERE id = ?");
    $current->execute([$id]);
    $new = $current->fetchColumn() ? 0 : 1;
    $db->prepare("UPDATE research_databases SET is_featured = ?, updated_at = datetime('now') WHERE id = ?")->execute([$new, $id]);
    $message = "Featured status updated.";
    logActivity($_SESSION['username'], 'TOGGLE_FEATURED', "ID: $id -> $new");
    header("Location: research_databases.php?msg=" . urlencode($message));
    exit;
}

// Toggle Active
if (isset($_GET['toggle_active']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $current = $db->prepare("SELECT is_active FROM research_databases WHERE id = ?");
    $current->execute([$id]);
    $new = $current->fetchColumn() ? 0 : 1;
    $db->prepare("UPDATE research_databases SET is_active = ?, deleted_at = " . ($new ? "NULL" : "datetime('now')") . " WHERE id = ?")->execute([$new, $id]);
    $message = "Status updated.";
    logActivity($_SESSION['username'], 'TOGGLE_ACTIVE', "ID: $id -> " . ($new ? 'active' : 'inactive'));
    header("Location: research_databases.php?msg=" . urlencode($message));
    exit;
}

// Update last verified date
if (isset($_GET['verify']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $today = date('Y-m-d');
    $db->prepare("UPDATE research_databases SET last_verified = ? WHERE id = ?")->execute([$today, $id]);
    $message = "Last verified date updated to today.";
    logActivity($_SESSION['username'], 'VERIFY_DATABASE', "Verified database ID: $id");
    header("Location: research_databases.php?msg=" . urlencode($message));
    exit;
}

// ========== FILTERING & PAGINATION ==========
$search = $_GET['search'] ?? '';
$filter_type = $_GET['filter_type'] ?? '';
$filter_category = $_GET['filter_category'] ?? '';
$show_deleted = isset($_GET['show_deleted']) && $_GET['show_deleted'] == '1';
$per_page = (int)($_GET['per_page'] ?? 25);
$per_page = in_array($per_page, [10,25,50,100]) ? $per_page : 25;
$page = (int)($_GET['page'] ?? 1);
$offset = ($page - 1) * $per_page;

$sql = "SELECT * FROM research_databases WHERE 1=1";
$params = [];
if (!$show_deleted) {
    $sql .= " AND (is_active = 1 OR is_active IS NULL)";
}
if ($search) {
    $sql .= " AND (name LIKE ? OR description LIKE ? OR category LIKE ? OR subjects LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}
if ($filter_type) {
    $sql .= " AND type = ?";
    $params[] = $filter_type;
}
if ($filter_category) {
    $sql .= " AND category LIKE ?";
    $params[] = "%$filter_category%";
}

// Count total
$countSql = str_replace("SELECT *", "SELECT COUNT(*)", $sql);
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalRows = $countStmt->fetchColumn();

$sql .= " ORDER BY is_featured DESC, sort_order ASC, name ASC LIMIT $per_page OFFSET $offset";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$databases = $stmt->fetchAll();

// Get distinct categories for filter
$categories = $db->query("SELECT DISTINCT category FROM research_databases WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

// Statistics
$totalActive = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 1")->fetchColumn();
$totalFeatured = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 1 AND is_featured = 1")->fetchColumn();
$totalAcademic = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 1 AND type = 'academic'")->fetchColumn();
$totalOpenAccess = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 1 AND type = 'open_access'")->fetchColumn();
$totalVisits = $db->query("SELECT SUM(visits) FROM research_databases")->fetchColumn() ?: 0;
$totalDeleted = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 0")->fetchColumn();

// Message from URL
if (isset($_GET['msg'])) {
    $message = htmlspecialchars($_GET['msg']);
}

renderHeader('Manage Research Databases');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-database"></i> Research Databases Management</h2>
        <div>
            <a href="../opac/" target="_blank" class="btn btn-info"><i class="fas fa-globe"></i> View OPAC</a>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($message) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-database fa-3x text-primary"></i><h3 class="mb-0 mt-2"><?= $totalActive ?></h3><small>Active</small></div></div></div>
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-star fa-3x text-warning"></i><h3 class="mb-0 mt-2"><?= $totalFeatured ?></h3><small>Featured</small></div></div></div>
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-graduation-cap fa-3x text-info"></i><h3 class="mb-0 mt-2"><?= $totalAcademic ?></h3><small>Academic</small></div></div></div>
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-lock-open fa-3x text-success"></i><h3 class="mb-0 mt-2"><?= $totalOpenAccess ?></h3><small>Open Access</small></div></div></div>
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-chart-line fa-3x text-secondary"></i><h3 class="mb-0 mt-2"><?= number_format($totalVisits) ?></h3><small>Total Visits</small></div></div></div>
        <div class="col-md-2"><div class="card border-0 shadow-sm rounded-4"><div class="card-body text-center"><i class="fas fa-trash fa-3x text-danger"></i><h3 class="mb-0 mt-2"><?= $totalDeleted ?></h3><small>Deleted</small></div></div></div>
    </div>
    
    <!-- Filter Bar -->
    <div class="card shadow-sm rounded-4 border-0 mb-4">
        <div class="card-header bg-white py-3"><h5><i class="fas fa-filter"></i> Filter & Search</h5></div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3"><input type="text" name="search" class="form-control" placeholder="Search name, description, subjects..." value="<?= htmlspecialchars($search) ?>"></div>
                <div class="col-md-2"><select name="filter_type" class="form-select"><option value="">All Types</option><option value="academic" <?= $filter_type=='academic'?'selected':'' ?>>Academic</option><option value="open_access" <?= $filter_type=='open_access'?'selected':'' ?>>Open Access</option><option value="subscription" <?= $filter_type=='subscription'?'selected':'' ?>>Subscription</option></select></div>
                <div class="col-md-2"><select name="filter_category" class="form-select"><option value="">All Categories</option><?php foreach($categories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $filter_category==$cat?'selected':'' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-md-2"><select name="per_page" class="form-select"><option value="10" <?= $per_page==10?'selected':'' ?>>10 per page</option><option value="25" <?= $per_page==25?'selected':'' ?>>25 per page</option><option value="50" <?= $per_page==50?'selected':'' ?>>50 per page</option><option value="100" <?= $per_page==100?'selected':'' ?>>100 per page</option></select></div>
                <div class="col-md-1"><div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="show_deleted" value="1" id="showDeleted" <?= $show_deleted?'checked':'' ?>><label class="form-check-label" for="showDeleted">Show deleted</label></div></div>
                <div class="col-md-2"><button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Apply</button></div>
            </form>
        </div>
    </div>
    
    <!-- Bulk Actions Form -->
    <form method="post" id="bulkForm">
    <div class="card shadow-sm rounded-4 border-0">
        <div class="card-header bg-primary text-white rounded-top-4 py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-list"></i> Database List</h5>
            <div>
                <button type="button" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#addDatabaseModal"><i class="fas fa-plus"></i> Add New</button>
                <a href="?export_csv=1" class="btn btn-light btn-sm ms-2"><i class="fas fa-file-excel"></i> Export CSV</a>
                <div class="btn-group ms-2">
                    <button type="button" class="btn btn-light btn-sm dropdown-toggle" data-bs-toggle="dropdown">Bulk Actions</button>
                    <ul class="dropdown-menu">
                        <li><button type="submit" name="bulk_action" value="delete" class="dropdown-item" onclick="return confirmBulk('delete')"><i class="fas fa-trash text-danger"></i> Delete Selected</button></li>
                        <li><button type="submit" name="bulk_action" value="activate" class="dropdown-item" onclick="return confirmBulk('activate')"><i class="fas fa-check-circle text-success"></i> Activate</button></li>
                        <li><button type="submit" name="bulk_action" value="deactivate" class="dropdown-item" onclick="return confirmBulk('deactivate')"><i class="fas fa-ban text-warning"></i> Deactivate</button></li>
                        <li><button type="submit" name="bulk_action" value="featured" class="dropdown-item" onclick="return confirmBulk('featured')"><i class="fas fa-star text-warning"></i> Mark Featured</button></li>
                        <li><button type="submit" name="bulk_action" value="unfeatured" class="dropdown-item" onclick="return confirmBulk('unfeatured')"><i class="fas fa-star-o"></i> Unmark Featured</button></li>
                        <?php if ($show_deleted): ?>
                        <li><button type="submit" name="bulk_action" value="restore" class="dropdown-item" onclick="return confirmBulk('restore')"><i class="fas fa-undo text-info"></i> Restore</button></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="30"><input type="checkbox" id="selectAll"></th>
                            <th>Logo</th>
                            <th>Name / Description</th>
                            <th>Category / Subjects</th>
                            <th>Type</th>
                            <th>Visits</th>
                            <th>Expiry</th>
                            <th>Featured</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($databases)): ?>
                            <tr><td colspan="10" class="text-center py-5 text-muted">No databases found.<?php if($show_deleted): ?> <a href="?show_deleted=0">Show active only</a><?php endif; ?></td></tr>
                        <?php else: ?>
                            <?php foreach ($databases as $dbItem): ?>
                            <tr>
                                <td class="text-center"><input type="checkbox" name="ids[]" value="<?= $dbItem['id'] ?>" class="rowCheckbox"></td>
                                <td class="text-center">
                                    <?php if (!empty($dbItem['logo_path']) && file_exists($dbItem['logo_path'])): ?>
                                        <img src="<?= getWebImageUrl($dbItem['logo_path']) ?>" style="height:40px; width:40px; object-fit:contain;" alt="logo">
                                    <?php else: ?>
                                        <i class="fas fa-<?= htmlspecialchars($dbItem['icon'] ?: 'database') ?> fa-2x text-secondary"></i>
                                    <?php endif; ?>
                                 </td>
                                <td>
                                    <strong><a href="?goto=<?= $dbItem['id'] ?>" target="_blank"><?= htmlspecialchars($dbItem['name']) ?></a></strong>
                                    <?php if (!empty($dbItem['description'])): ?>
                                        <br><small class="text-muted"><?= htmlspecialchars(substr($dbItem['description'], 0, 80)) ?>...</small>
                                    <?php endif; ?>
                                    <?php if (!empty($dbItem['subjects'])): ?>
                                        <br><small class="text-muted"><i class="fas fa-tags"></i> <?= htmlspecialchars($dbItem['subjects']) ?></small>
                                    <?php endif; ?>
                                 </div>
                                <td>
                                    <?= htmlspecialchars($dbItem['category'] ?: '-') ?>
                                    <?php if (!empty($dbItem['expiry_date']) && strtotime($dbItem['expiry_date']) < time()): ?>
                                        <span class="badge bg-danger">Expired</span>
                                    <?php endif; ?>
                                 </div>
                                <td>
                                    <?php
                                    $typeBadge = $dbItem['type'] == 'academic' ? 'bg-info' : ($dbItem['type'] == 'open_access' ? 'bg-success' : 'bg-warning');
                                    $typeIcon = $dbItem['type'] == 'academic' ? 'fa-graduation-cap' : ($dbItem['type'] == 'open_access' ? 'fa-lock-open' : 'fa-credit-card');
                                    ?>
                                    <span class="badge <?= $typeBadge ?>"><i class="fas <?= $typeIcon ?>"></i> <?= ucfirst(str_replace('_',' ', $dbItem['type'])) ?></span>
                                 </div>
                                <td><span class="badge bg-secondary"><?= (int)($dbItem['visits'] ?? 0) ?></span></div>
                                <td>
                                    <?php if (!empty($dbItem['expiry_date'])): ?>
                                        <span class="small <?= strtotime($dbItem['expiry_date']) < time() ? 'text-danger' : '' ?>"><?= date('d/m/Y', strtotime($dbItem['expiry_date'])) ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                 </div>
                                <td class="text-center">
                                    <a href="?toggle_featured=1&id=<?= $dbItem['id'] ?>" class="btn btn-sm <?= $dbItem['is_featured'] ? 'btn-warning' : 'btn-outline-secondary' ?>"><i class="fas fa-star"></i></a>
                                </td>
                                <td class="text-center">
                                    <?php if ($dbItem['is_active']): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Deleted</span>
                                        <a href="?restore=1&id=<?= $dbItem['id'] ?>" class="btn btn-sm btn-outline-info ms-1"><i class="fas fa-undo"></i> Restore</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" onclick='editDatabase(<?= json_encode($dbItem) ?>)'><i class="fas fa-edit"></i></button>
                                        <a href="?verify=1&id=<?= $dbItem['id'] ?>" class="btn btn-outline-info" title="Verify link"><i class="fas fa-check-double"></i></a>
                                        <?php if ($dbItem['is_active']): ?>
                                            <a href="?delete=1&id=<?= $dbItem['id'] ?>" class="btn btn-outline-danger" onclick="return confirm('Delete this database?')"><i class="fas fa-trash"></i></a>
                                        <?php endif; ?>
                                    </div>
                                 </div>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </form>
    
    <!-- Pagination -->
    <?php if ($totalRows > $per_page): ?>
    <div class="mt-3 d-flex justify-content-between align-items-center">
        <small>Showing <?= $offset+1 ?> to <?= min($offset+$per_page, $totalRows) ?> of <?= $totalRows ?></small>
        <nav><ul class="pagination pagination-sm">
            <?php $totalPages = ceil($totalRows / $per_page); for($i=1; $i<=$totalPages; $i++): ?>
                <li class="page-item <?= $i==$page?'active':'' ?>"><a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page'=>$i])) ?>"><?= $i ?></a></li>
            <?php endfor; ?>
        </ul></nav>
    </div>
    <?php endif; ?>
    
    <!-- Help Section -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card shadow-sm rounded-4 border-0">
                <div class="card-header bg-secondary text-white rounded-top-4 py-2"><h6><i class="fas fa-question-circle"></i> Help & Tips</h6></div>
                <div class="card-body small">
                    <ul class="mb-0">
                        <li><strong>Logo upload:</strong> Supports JPG, PNG, GIF, WebP, SVG. Max size 2MB.</li>
                        <li><strong>Subjects/Tags:</strong> Comma-separated subject terms for better discovery.</li>
                        <li><strong>Expiry date:</strong> Only relevant for subscription databases; expired ones will be highlighted.</li>
                        <li><strong>Visit counter:</strong> Automatically increments when a user clicks the database name from OPAC.</li>
                        <li><strong>Last verified:</strong> Click the <i class="fas fa-check-double"></i> button to mark today as last verification date.</li>
                        <li><strong>Proxy URL:</strong> If your institution uses a proxy (e.g., EZproxy), enter the proxied URL template.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Database Modal -->
<div class="modal fade" id="addDatabaseModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4">
    <div class="modal-header bg-primary text-white"><h5><i class="fas fa-plus"></i> Add Research Database</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
    <form method="post" enctype="multipart/form-data">
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="row">
                <div class="col-md-8 mb-3"><label class="fw-bold">Database Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g., JSTOR, Google Scholar"></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Icon (FA) / Logo</label><input type="file" name="logo" class="form-control" accept="image/*"><small class="text-muted">Or use FontAwesome icon below</small><input type="text" name="icon" class="form-control mt-1" placeholder="database"></div>
            </div>
            <div class="mb-3"><label class="fw-bold">URL *</label><input type="url" name="url" class="form-control" required placeholder="https://"></div>
            <div class="mb-3"><label class="fw-bold">Proxy URL (optional)</label><input type="url" name="proxy_url" class="form-control" placeholder="https://proxy.yourlib.edu/login?url="></div>
            <div class="mb-3"><label class="fw-bold">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="fw-bold">Category</label><input type="text" name="category" class="form-control" placeholder="e.g., Science, Humanities"></div>
                <div class="col-md-6 mb-3"><label class="fw-bold">Subjects (comma separated)</label><input type="text" name="subjects" class="form-control" placeholder="Biology, Chemistry, Medicine"></div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3"><label class="fw-bold">Type</label><select name="type" class="form-select"><option value="academic">Academic</option><option value="open_access">Open Access</option><option value="subscription">Subscription</option></select></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Expiry Date</label><input type="date" name="expiry_date" class="form-control"></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Sort Order</label><input type="number" name="sort_order" class="form-control" value="999"></div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="fw-bold">Access Notes</label><textarea name="access_notes" class="form-control" rows="2" placeholder="Username/password hints, IP restrictions..."></textarea></div>
                <div class="col-md-6 mb-3"><label class="fw-bold">Contact Email</label><input type="email" name="contact_email" class="form-control" placeholder="libsupport@example.com"></div>
            </div>
            <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_featured" id="add_featured"><label class="form-check-label" for="add_featured"> Featured Database</label></div>
        </div>
        <div class="modal-footer"><button type="submit" class="btn btn-primary">Add Database</button><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button></div>
    </form>
</div></div></div>

<!-- Edit Database Modal -->
<div class="modal fade" id="editDatabaseModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4">
    <div class="modal-header bg-warning text-dark"><h5><i class="fas fa-edit"></i> Edit Database</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <form method="post" enctype="multipart/form-data">
        <div class="modal-body">
            <input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="existing_logo" id="edit_existing_logo">
            <div class="row">
                <div class="col-md-8 mb-3"><label class="fw-bold">Database Name *</label><input type="text" name="name" id="edit_name" class="form-control" required></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Change Logo</label><input type="file" name="logo" class="form-control" accept="image/*"><div id="edit_logo_preview" class="mt-1"></div><input type="text" name="icon" id="edit_icon" class="form-control mt-1" placeholder="FontAwesome icon"></div>
            </div>
            <div class="mb-3"><label class="fw-bold">URL *</label><input type="url" name="url" id="edit_url" class="form-control" required></div>
            <div class="mb-3"><label class="fw-bold">Proxy URL</label><input type="url" name="proxy_url" id="edit_proxy_url" class="form-control"></div>
            <div class="mb-3"><label class="fw-bold">Description</label><textarea name="description" id="edit_description" class="form-control" rows="2"></textarea></div>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="fw-bold">Category</label><input type="text" name="category" id="edit_category" class="form-control"></div>
                <div class="col-md-6 mb-3"><label class="fw-bold">Subjects</label><input type="text" name="subjects" id="edit_subjects" class="form-control"></div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3"><label class="fw-bold">Type</label><select name="type" id="edit_type" class="form-select"><option value="academic">Academic</option><option value="open_access">Open Access</option><option value="subscription">Subscription</option></select></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Expiry Date</label><input type="date" name="expiry_date" id="edit_expiry_date" class="form-control"></div>
                <div class="col-md-4 mb-3"><label class="fw-bold">Sort Order</label><input type="number" name="sort_order" id="edit_sort_order" class="form-control"></div>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="fw-bold">Access Notes</label><textarea name="access_notes" id="edit_access_notes" class="form-control" rows="2"></textarea></div>
                <div class="col-md-6 mb-3"><label class="fw-bold">Contact Email</label><input type="email" name="contact_email" id="edit_contact_email" class="form-control"></div>
            </div>
            <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_featured" id="edit_is_featured"><label class="form-check-label" for="edit_is_featured"> Featured Database</label></div>
        </div>
        <div class="modal-footer"><button type="submit" class="btn btn-warning">Update Database</button><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button></div>
    </form>
</div></div></div>

<script>
function editDatabase(db) {
    document.getElementById('edit_id').value = db.id;
    document.getElementById('edit_name').value = db.name;
    document.getElementById('edit_url').value = db.url;
    document.getElementById('edit_description').value = db.description || '';
    document.getElementById('edit_category').value = db.category || '';
    document.getElementById('edit_subjects').value = db.subjects || '';
    document.getElementById('edit_type').value = db.type;
    document.getElementById('edit_icon').value = db.icon || 'database';
    document.getElementById('edit_sort_order').value = db.sort_order;
    document.getElementById('edit_is_featured').checked = db.is_featured == 1;
    document.getElementById('edit_proxy_url').value = db.proxy_url || '';
    document.getElementById('edit_access_notes').value = db.access_notes || '';
    document.getElementById('edit_contact_email').value = db.contact_email || '';
    document.getElementById('edit_expiry_date').value = db.expiry_date || '';
    document.getElementById('edit_existing_logo').value = db.logo_path || '';
    if (db.logo_path) {
        let url = getWebImageUrl(db.logo_path);
        document.getElementById('edit_logo_preview').innerHTML = `<img src="${url}" style="height:50px;"><br><small>Current logo</small>`;
    } else {
        document.getElementById('edit_logo_preview').innerHTML = '';
    }
    new bootstrap.Modal(document.getElementById('editDatabaseModal')).show();
}

function getWebImageUrl(path) {
    if (!path) return '';
    if (path.match(/^https?:\/\//)) return path;
    return '/' + path.replace(/^\/+/, '');
}

function confirmBulk(action) {
    let checked = document.querySelectorAll('.rowCheckbox:checked').length;
    if (checked === 0) { alert('Please select at least one database.'); return false; }
    return confirm(`Are you sure you want to ${action} ${checked} database(s)?`);
}

document.getElementById('selectAll')?.addEventListener('change', function(e) {
    document.querySelectorAll('.rowCheckbox').forEach(cb => cb.checked = e.target.checked);
});
</script>

<style>
.table td, .table th { vertical-align: middle; }
.badge { font-weight: 500; padding: 5px 10px; }
.btn-sm { padding: 0.25rem 0.5rem; margin: 0 2px; }
.card { transition: all 0.3s ease; }
.card:hover { transform: translateY(-2px); }
</style>

<?php renderFooter(); ?>