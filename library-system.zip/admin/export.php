<?php
/**
 * Export Functions Library
 * Comprehensive export functionality for Library Management System
 * 
 * Features:
 * - CSV Export (Copies & Titles modes)
 * - Excel Export (Copies & Titles modes) with PhpSpreadsheet
 * - PDF Export (Copies & Titles modes) with mPDF/DOMPDF
 * - MARC21 Export (.mrc & .xml)
 * - Accession Register export
 * - Grouped Titles export
 * 
 * Usage:
 *   require_once 'export_functions.php';
 *   exportBooksCSV($db, $data, 'copies', 'Books Report');
 *   exportBooksExcel($db, $data, 'titles', 'Books Report');
 *   exportBooksPDF($db, $data, 'copies', 'Books Report', 'A4', 'landscape');
 *   exportBooksMARC($db, $data, 'mrc');
 * 
 * @author Library ERP System
 * @version 2.0
 */

// ==================== CONFIGURATION ====================

// Define BASE_PATH if not defined
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(dirname(__DIR__)));
}

// Define upload directories if not defined
if (!defined('BOOK_COVER_DIR')) {
    define('BOOK_COVER_DIR', BASE_PATH . '/uploads/books/');
}
if (!defined('REPORT_TEMP_DIR')) {
    define('REPORT_TEMP_DIR', BASE_PATH . '/temp/reports/');
}

// Create temp directory if it doesn't exist
if (!is_dir(REPORT_TEMP_DIR)) {
    mkdir(REPORT_TEMP_DIR, 0777, true);
}

// ==================== HELPER FUNCTIONS ====================

if (!function_exists('getInstitutionName')) {
    function getInstitutionName() {
        $institution = getInstitution();
        return $institution['name'] ?? 'Library';
    }
}

if (!function_exists('getCurrencySymbol')) {
    function getCurrencySymbol($code = null) {
        if ($code === null) {
            $settings = getSettings();
            $code = $settings['currency_code'] ?? 'INR';
        }
        $symbols = [
            'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
            'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
            'BHD' => '.د.ب', 'OMR' => '﷼'
        ];
        return $symbols[$code] ?? $code;
    }
}

if (!function_exists('formatCurrency')) {
    function formatCurrency($amount, $withSymbol = true) {
        $settings = getSettings();
        $symbol = getCurrencySymbol();
        $code = $settings['currency_code'] ?? 'INR';
        $position = $settings['currency_position'] ?? 'left';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        $formatted = number_format((float)$amount, $decimals);
        if ($withSymbol) {
            return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . $code;
        }
        return $formatted;
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd-m-Y') {
        if (empty($date) || $date === '0000-00-00') return '';
        try {
            return date($format, strtotime($date));
        } catch (Exception $e) {
            return $date;
        }
    }
}

if (!function_exists('resolveImageToBase64')) {
    function resolveImageToBase64($path) {
        if (empty($path)) return '';
        if (strpos($path, 'data:image') === 0) return $path;
        $fullPath = '';
        if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
            $fullPath = BASE_PATH . '/' . ltrim($path, '/');
        } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
            return '';
        } else {
            $fullPath = BASE_PATH . '/' . ltrim($path, '/');
        }
        if ($fullPath && file_exists($fullPath)) {
            $mime = mime_content_type($fullPath);
            $data = file_get_contents($fullPath);
            if ($data !== false) {
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    }
}

if (!function_exists('getLogoForExport')) {
    function getLogoForExport() {
        $settings = getSettings();
        $institution = getInstitution();
        
        $logoPaths = [
            $settings['library_logo'] ?? '',
            $settings['opac_header_logo'] ?? '',
            $settings['right_logo_path'] ?? '',
            $institution['logo_path'] ?? ''
        ];
        
        foreach ($logoPaths as $path) {
            if (!empty($path)) {
                $base64 = resolveImageToBase64($path);
                if ($base64) return $base64;
            }
        }
        return '';
    }
}

if (!function_exists('getReportRightLogo')) {
    function getReportRightLogo() {
        $settings = getSettings();
        $path = $settings['report_logo_right'] ?? '';
        return resolveImageToBase64($path);
    }
}

if (!function_exists('getSignatureImageForExport')) {
    function getSignatureImageForExport() {
        $settings = getSettings();
        $path = $settings['report_signature_image'] ?? '';
        return resolveImageToBase64($path);
    }
}

// ==================== CHECK AVAILABLE LIBRARIES ====================

function checkExportLibraries() {
    $result = [
        'excel' => false,
        'pdf' => false,
        'marc' => false,
        'zip' => false
    ];
    
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
        if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
            $result['excel'] = true;
        }
        if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) {
            $result['pdf'] = true;
        }
        if (class_exists('Scriptotek\Marc\MarcReader') || class_exists('File_MARC')) {
            $result['marc'] = true;
        }
    }
    if (extension_loaded('zip')) {
        $result['zip'] = true;
    }
    return $result;
}

// ==================== CSV EXPORT FUNCTIONS ====================

/**
 * Export books to CSV
 * 
 * @param PDO $db Database connection
 * @param array $data Array of book data
 * @param string $mode 'copies' or 'titles'
 * @param string $title Report title
 */
function exportBooksCSV($db, $data, $mode = 'copies', $title = 'Books Report') {
    // Clear any output buffers
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF"); // UTF-8 BOM
    
    if ($mode === 'titles') {
        $headers = [
            'Sl No', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator', 
            'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition', 
            'Pages', 'Language', 'Country', 'Category', 'Sub Category', 
            'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC', 
            'Other Classification', 'Cutter', 'Call Number', 'Subjects', 
            'Keywords', 'Summary', 'Total Copies', 'Available', 'Price', 
            'Currency', 'Book Status', 'Item Category', 'Maintenance', 
            'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor', 
            'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number', 
            'eBook URL', 'Remarks'
        ];
        fputcsv($out, $headers);
        
        // Group by title, author, publisher, isbn
        $grouped = [];
        foreach ($data as $book) {
            $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
            if (!isset($grouped[$key])) {
                $book['_quantity'] = (int)($book['quantity'] ?? 0);
                $book['_available'] = (int)($book['available'] ?? 0);
                $grouped[$key] = $book;
            } else {
                $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
            }
        }
        
        $sn = 1;
        foreach ($grouped as $book) {
            fputcsv($out, [
                $sn++,
                $book['title'] ?? '',
                $book['sub_title'] ?? '',
                $book['author'] ?? '',
                $book['author2'] ?? '',
                $book['collaborator'] ?? '',
                $book['publisher'] ?? '',
                $book['publisher_place'] ?? '',
                $book['isbn'] ?? '',
                $book['issn'] ?? '',
                $book['year'] ?? '',
                $book['edition'] ?? '',
                (int)($book['pages'] ?? 0),
                $book['language'] ?? 'English',
                $book['country'] ?? '',
                $book['category'] ?? '',
                $book['sub_category'] ?? '',
                $book['collection_type'] ?? '',
                $book['series'] ?? '',
                $book['volume'] ?? '',
                $book['ddc'] ?? '',
                $book['udc'] ?? '',
                $book['lcc'] ?? '',
                $book['cc'] ?? '',
                $book['other_classification'] ?? '',
                $book['cutter'] ?? '',
                $book['call_number'] ?? '',
                $book['subject'] ?? '',
                $book['keyword'] ?? '',
                $book['summary'] ?? '',
                $book['_quantity'] ?? 0,
                $book['_available'] ?? 0,
                $book['price'] ?? '',
                $book['price_currency'] ?? 'INR',
                $book['book_status'] ?? 'Available',
                $book['item_category'] ?? '',
                $book['maintenance'] ?? '',
                $book['current_location'] ?? '',
                $book['section'] ?? '',
                $book['branch'] ?? '',
                $book['shelf'] ?? '',
                $book['vendor'] ?? '',
                $book['invoice'] ?? '',
                $book['acquisition_date'] ?? '',
                $book['funding_source'] ?? '',
                $book['po_number'] ?? '',
                $book['ebook_url'] ?? '',
                $book['remarks'] ?? ''
            ]);
        }
    } else {
        // Accession Register / Copies mode
        $headers = [
            'Sl No', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2', 
            'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 
            'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
            'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
            'Other Classification', 'Cutter', 'Call Number', 'Subjects',
            'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
            'Currency', 'Book Status', 'Item Category', 'Maintenance',
            'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
            'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
            'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
            'Material Type', 'Size', 'Weight', 'Remarks'
        ];
        fputcsv($out, $headers);
        
        $sn = 1;
        foreach ($data as $book) {
            fputcsv($out, [
                $sn++,
                $book['barcode'] ?? '',
                $book['accession_number'] ?? '',
                $book['title'] ?? '',
                $book['sub_title'] ?? '',
                $book['author'] ?? '',
                $book['author2'] ?? '',
                $book['collaborator'] ?? '',
                $book['publisher'] ?? '',
                $book['publisher_place'] ?? '',
                $book['isbn'] ?? '',
                $book['issn'] ?? '',
                $book['year'] ?? '',
                $book['edition'] ?? '',
                (int)($book['pages'] ?? 0),
                $book['language'] ?? 'English',
                $book['country'] ?? '',
                $book['category'] ?? '',
                $book['sub_category'] ?? '',
                $book['collection_type'] ?? '',
                $book['series'] ?? '',
                $book['volume'] ?? '',
                $book['ddc'] ?? '',
                $book['udc'] ?? '',
                $book['lcc'] ?? '',
                $book['cc'] ?? '',
                $book['other_classification'] ?? '',
                $book['cutter'] ?? '',
                $book['call_number'] ?? '',
                $book['subject'] ?? '',
                $book['keyword'] ?? '',
                $book['summary'] ?? '',
                (int)($book['quantity'] ?? 0),
                (int)($book['available'] ?? 0),
                $book['price'] ?? '',
                $book['price_currency'] ?? 'INR',
                $book['book_status'] ?? 'Available',
                $book['item_category'] ?? '',
                $book['maintenance'] ?? '',
                $book['current_location'] ?? '',
                $book['section'] ?? '',
                $book['branch'] ?? '',
                $book['shelf'] ?? '',
                $book['vendor'] ?? '',
                $book['invoice'] ?? '',
                $book['invoice_date'] ?? '',
                $book['acquisition_date'] ?? '',
                $book['funding_source'] ?? '',
                $book['po_number'] ?? '',
                $book['ebook_url'] ?? '',
                $book['contents'] ?? '',
                $book['accompanying_material'] ?? '',
                $book['material_type'] ?? '',
                $book['size'] ?? '',
                $book['weight'] ?? '',
                $book['remarks'] ?? ''
            ]);
        }
    }
    
    fclose($out);
    exit;
}

/**
 * Export members to CSV
 * 
 * @param PDO $db Database connection
 * @param array $data Array of member data
 * @param string $title Report title
 */
function exportMembersCSV($db, $data, $title = 'Members Report') {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="members_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = [
        'Sl No', 'Adm/Mem No', 'Name', 'Designation', 'General ID', 'Category', 
        'Class/Dept', 'Division', 'Roll No', 'Email', 'Phone', 'Parent Phone',
        'Emergency Contact', 'Address', 'DOB', 'Gender', 'Blood Group',
        'Status', 'Admission Date', 'Security Deposit', 'Membership Expiry',
        'Active Books', 'Total Issued', 'Total Fines', 'Created At'
    ];
    fputcsv($out, $headers);
    
    $sn = 1;
    foreach ($data as $member) {
        fputcsv($out, [
            $sn++,
            $member['admno'] ?? '',
            $member['name'] ?? '',
            $member['designation'] ?? '',
            $member['general_id'] ?? '',
            $member['member_category'] ?? '',
            $member['class'] ?? '',
            $member['division'] ?? '',
            $member['roll_no'] ?? '',
            $member['email'] ?? '',
            $member['phone'] ?? '',
            $member['parent_phone'] ?? '',
            $member['emergency_contact'] ?? '',
            $member['address'] ?? '',
            $member['dob'] ?? '',
            $member['gender'] ?? '',
            $member['blood_group'] ?? '',
            $member['status'] ?? 'active',
            $member['admission_date'] ?? '',
            $member['security_deposit'] ?? 0,
            $member['membership_expiry'] ?? '',
            (int)($member['active_books'] ?? 0),
            (int)($member['total_issued'] ?? 0),
            (float)($member['total_fines'] ?? 0),
            $member['created_at'] ?? ''
        ]);
    }
    
    fclose($out);
    exit;
}

/**
 * Export circulation to CSV
 * 
 * @param PDO $db Database connection
 * @param array $data Array of circulation data
 * @param string $title Report title
 */
function exportCirculationCSV($db, $data, $title = 'Circulation Report') {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="circulation_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = [
        'Sl No', 'Issue Date', 'Return Date', 'Adm No', 'Member Name', 
        'Class/Dept', 'Div/Course', 'Book Title', 'Author', 'Barcode', 
        'Due Date', 'Fine', 'Status'
    ];
    fputcsv($out, $headers);
    
    $sn = 1;
    foreach ($data as $row) {
        $status = $row['return_date'] ? 'Returned' : 
                  (strtotime($row['due_date'] ?? 'now') < time() ? 'Overdue' : 'Issued');
        fputcsv($out, [
            $sn++,
            $row['issue_date'] ?? '',
            $row['return_date'] ?? '',
            $row['admno'] ?? '',
            $row['member_name'] ?? 'N/A',
            $row['class'] ?? '',
            $row['division'] ?? '',
            $row['book_title'] ?? 'N/A',
            $row['author'] ?? '',
            $row['barcode'] ?? '',
            $row['due_date'] ?? '',
            formatCurrency($row['fine'] ?? 0),
            $status
        ]);
    }
    
    fclose($out);
    exit;
}

/**
 * Export overdue books to CSV
 * 
 * @param PDO $db Database connection
 * @param array $data Array of overdue data
 * @param string $title Report title
 */
function exportOverdueCSV($db, $data, $title = 'Overdue Books Report') {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="overdue_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = [
        'Sl No', 'Adm No', 'Member Name', 'Class/Dept', 'Div/Course',
        'Book Title', 'Author', 'Barcode', 'Issue Date', 'Due Date',
        'Days Overdue', 'Fine Amount'
    ];
    fputcsv($out, $headers);
    
    $sn = 1;
    foreach ($data as $row) {
        fputcsv($out, [
            $sn++,
            $row['admno'] ?? '',
            $row['member_name'] ?? '',
            $row['class'] ?? '',
            $row['division'] ?? '',
            $row['title'] ?? 'N/A',
            $row['author'] ?? '',
            $row['barcode'] ?? '',
            $row['issue_date'] ?? '',
            $row['due_date'] ?? '',
            $row['days_overdue'] ?? 0,
            formatCurrency($row['fine_amount'] ?? 0)
        ]);
    }
    
    fclose($out);
    exit;
}

// ==================== EXCEL EXPORT FUNCTIONS ====================

/**
 * Export books to Excel using PhpSpreadsheet or fallback to CSV
 * 
 * @param PDO $db Database connection
 * @param array $data Array of book data
 * @param string $mode 'copies' or 'titles'
 * @param string $title Report title
 */
function exportBooksExcel($db, $data, $mode = 'copies', $title = 'Books Report') {
    $libraries = checkExportLibraries();
    
    while (ob_get_level()) ob_end_clean();
    
    if ($libraries['excel']) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Books');
            
            // Set headers
            if ($mode === 'titles') {
                $headers = [
                    'Sl No', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator', 
                    'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition', 
                    'Pages', 'Language', 'Country', 'Category', 'Sub Category', 
                    'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC', 
                    'Other Classification', 'Cutter', 'Call Number', 'Subjects', 
                    'Keywords', 'Summary', 'Total Copies', 'Available', 'Price', 
                    'Currency', 'Book Status', 'Item Category', 'Maintenance', 
                    'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor', 
                    'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number', 
                    'eBook URL', 'Remarks'
                ];
            } else {
                $headers = [
                    'Sl No', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2', 
                    'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 
                    'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
                    'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
                    'Other Classification', 'Cutter', 'Call Number', 'Subjects',
                    'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
                    'Currency', 'Book Status', 'Item Category', 'Maintenance',
                    'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
                    'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
                    'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
                    'Material Type', 'Size', 'Weight', 'Remarks'
                ];
            }
            
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . '1', $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            
            $sheet->getStyle('A1:' . $col . '1')->getFont()->setBold(true);
            
            // Add data
            $row = 2;
            $sn = 1;
            
            if ($mode === 'titles') {
                $grouped = [];
                foreach ($data as $book) {
                    $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
                    if (!isset($grouped[$key])) {
                        $book['_quantity'] = (int)($book['quantity'] ?? 0);
                        $book['_available'] = (int)($book['available'] ?? 0);
                        $grouped[$key] = $book;
                    } else {
                        $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                        $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
                    }
                }
                
                foreach ($grouped as $book) {
                    $col = 'A';
                    $values = [
                        $sn++,
                        $book['title'] ?? '',
                        $book['sub_title'] ?? '',
                        $book['author'] ?? '',
                        $book['author2'] ?? '',
                        $book['collaborator'] ?? '',
                        $book['publisher'] ?? '',
                        $book['publisher_place'] ?? '',
                        $book['isbn'] ?? '',
                        $book['issn'] ?? '',
                        $book['year'] ?? '',
                        $book['edition'] ?? '',
                        (int)($book['pages'] ?? 0),
                        $book['language'] ?? 'English',
                        $book['country'] ?? '',
                        $book['category'] ?? '',
                        $book['sub_category'] ?? '',
                        $book['collection_type'] ?? '',
                        $book['series'] ?? '',
                        $book['volume'] ?? '',
                        $book['ddc'] ?? '',
                        $book['udc'] ?? '',
                        $book['lcc'] ?? '',
                        $book['cc'] ?? '',
                        $book['other_classification'] ?? '',
                        $book['cutter'] ?? '',
                        $book['call_number'] ?? '',
                        $book['subject'] ?? '',
                        $book['keyword'] ?? '',
                        $book['summary'] ?? '',
                        $book['_quantity'] ?? 0,
                        $book['_available'] ?? 0,
                        $book['price'] ?? '',
                        $book['price_currency'] ?? 'INR',
                        $book['book_status'] ?? 'Available',
                        $book['item_category'] ?? '',
                        $book['maintenance'] ?? '',
                        $book['current_location'] ?? '',
                        $book['section'] ?? '',
                        $book['branch'] ?? '',
                        $book['shelf'] ?? '',
                        $book['vendor'] ?? '',
                        $book['invoice'] ?? '',
                        $book['acquisition_date'] ?? '',
                        $book['funding_source'] ?? '',
                        $book['po_number'] ?? '',
                        $book['ebook_url'] ?? '',
                        $book['remarks'] ?? ''
                    ];
                    foreach ($values as $value) {
                        $sheet->setCellValue($col . $row, $value);
                        $col++;
                    }
                    $row++;
                }
            } else {
                foreach ($data as $book) {
                    $col = 'A';
                    $values = [
                        $sn++,
                        $book['barcode'] ?? '',
                        $book['accession_number'] ?? '',
                        $book['title'] ?? '',
                        $book['sub_title'] ?? '',
                        $book['author'] ?? '',
                        $book['author2'] ?? '',
                        $book['collaborator'] ?? '',
                        $book['publisher'] ?? '',
                        $book['publisher_place'] ?? '',
                        $book['isbn'] ?? '',
                        $book['issn'] ?? '',
                        $book['year'] ?? '',
                        $book['edition'] ?? '',
                        (int)($book['pages'] ?? 0),
                        $book['language'] ?? 'English',
                        $book['country'] ?? '',
                        $book['category'] ?? '',
                        $book['sub_category'] ?? '',
                        $book['collection_type'] ?? '',
                        $book['series'] ?? '',
                        $book['volume'] ?? '',
                        $book['ddc'] ?? '',
                        $book['udc'] ?? '',
                        $book['lcc'] ?? '',
                        $book['cc'] ?? '',
                        $book['other_classification'] ?? '',
                        $book['cutter'] ?? '',
                        $book['call_number'] ?? '',
                        $book['subject'] ?? '',
                        $book['keyword'] ?? '',
                        $book['summary'] ?? '',
                        (int)($book['quantity'] ?? 0),
                        (int)($book['available'] ?? 0),
                        $book['price'] ?? '',
                        $book['price_currency'] ?? 'INR',
                        $book['book_status'] ?? 'Available',
                        $book['item_category'] ?? '',
                        $book['maintenance'] ?? '',
                        $book['current_location'] ?? '',
                        $book['section'] ?? '',
                        $book['branch'] ?? '',
                        $book['shelf'] ?? '',
                        $book['vendor'] ?? '',
                        $book['invoice'] ?? '',
                        $book['invoice_date'] ?? '',
                        $book['acquisition_date'] ?? '',
                        $book['funding_source'] ?? '',
                        $book['po_number'] ?? '',
                        $book['ebook_url'] ?? '',
                        $book['contents'] ?? '',
                        $book['accompanying_material'] ?? '',
                        $book['material_type'] ?? '',
                        $book['size'] ?? '',
                        $book['weight'] ?? '',
                        $book['remarks'] ?? ''
                    ];
                    foreach ($values as $value) {
                        $sheet->setCellValue($col . $row, $value);
                        $col++;
                    }
                    $row++;
                }
            }
            
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
            
        } catch (Exception $e) {
            error_log("Excel export error: " . $e->getMessage());
        }
    }
    
    // Fallback to CSV
    exportBooksCSV($db, $data, $mode, $title);
}

// ==================== PDF EXPORT FUNCTIONS ====================

/**
 * Export books to PDF
 * 
 * @param PDO $db Database connection
 * @param array $data Array of book data
 * @param string $mode 'copies' or 'titles'
 * @param string $title Report title
 * @param string $paperSize A4, Letter, Legal, A3
 * @param string $orientation landscape or portrait
 */
function exportBooksPDF($db, $data, $mode = 'copies', $title = 'Books Report', 
                        $paperSize = 'A4', $orientation = 'landscape') {
    $libraries = checkExportLibraries();
    
    while (ob_get_level()) ob_end_clean();
    
    $institutionName = getInstitutionName();
    $logoBase64 = getLogoForExport();
    $settings = getSettings();
    
    // Build HTML
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>
        @page { margin: 1.5cm; }
        body { font-family: "DejaVu Sans", "Arial", sans-serif; font-size: 9px; margin: 0; padding: 10px; }
        .header { text-align: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #1e3c72; }
        .institution-name { font-size: 18px; font-weight: bold; color: #1e3c72; }
        .report-title { font-size: 16px; font-weight: bold; margin: 8px 0; }
        .report-meta { font-size: 9px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 8px; }
        th, td { border: 1px solid #000; padding: 4px; text-align: left; vertical-align: top; }
        th { background-color: #1e3c72; color: white; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { margin-top: 15px; text-align: center; font-size: 8px; color: #777; border-top: 1px solid #ddd; padding-top: 8px; }
        .summary { margin: 10px 0; padding: 8px; background: #f5f5f5; border-left: 4px solid #1e3c72; font-size: 9px; }
        .watermark { position: fixed; bottom: 50%; right: 50%; transform: translate(50%, 50%) rotate(-45deg); font-size: 48px; color: rgba(0,0,0,0.05); white-space: nowrap; z-index: 9999; pointer-events: none; }
    </style>';
    
    // Add watermark if enabled
    if ($settings['report_watermark_enabled'] ?? 0) {
        $watermarkText = $settings['report_watermark_text'] ?? 'Library';
        $html .= '<div class="watermark">' . htmlspecialchars($watermarkText) . '</div>';
    }
    
    $html .= '</head><body>';
    
    // Header
    $html .= '<div class="header">';
    if ($logoBase64) {
        $html .= '<img src="' . $logoBase64 . '" style="height:50px; width:auto; margin-bottom:5px;"><br>';
    }
    $html .= '<div class="institution-name">' . htmlspecialchars($institutionName) . '</div>';
    $html .= '<div class="report-title">' . htmlspecialchars($title) . '</div>';
    $html .= '<div class="report-meta">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    
    // Table
    if ($mode === 'titles') {
        $html .= '<table>
            <thead><tr>
                <th style="text-align:center;">#</th>
                <th>Title</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>ISBN</th>
                <th>Year</th>
                <th style="text-align:center;">Copies</th>
                <th style="text-align:center;">Available</th>
                <th style="text-align:right;">Price</th>
            </tr></thead><tbody>';
        
        $grouped = [];
        foreach ($data as $book) {
            $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
            if (!isset($grouped[$key])) {
                $book['_quantity'] = (int)($book['quantity'] ?? 0);
                $book['_available'] = (int)($book['available'] ?? 0);
                $grouped[$key] = $book;
            } else {
                $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
            }
        }
        
        $sn = 1;
        foreach ($grouped as $book) {
            $html .= '<tr>
                <td style="text-align:center;">' . $sn++ . '</td>
                <td>' . htmlspecialchars(substr($book['title'] ?? '', 0, 60)) . '</td>
                <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['publisher'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                <td style="text-align:center;">' . ($book['_quantity'] ?? 0) . '</td>
                <td style="text-align:center;">' . ($book['_available'] ?? 0) . '</td>
                <td style="text-align:right;">' . formatCurrency($book['price'] ?? 0) . '</td>
            </tr>';
        }
    } else {
        $html .= '<table>
            <thead><tr>
                <th style="text-align:center;">#</th>
                <th>Barcode</th>
                <th>Accession No</th>
                <th>Title</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>ISBN</th>
                <th>Year</th>
                <th style="text-align:center;">Status</th>
            </tr></thead><tbody>';
        
        $sn = 1;
        foreach ($data as $book) {
            $status = ((int)($book['available'] ?? 0) > 0) ? 'Available' : 'Issued';
            $html .= '<tr>
                <td style="text-align:center;">' . $sn++ . '</td>
                <td>' . htmlspecialchars($book['barcode'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['accession_number'] ?? '') . '</td>
                <td>' . htmlspecialchars(substr($book['title'] ?? '', 0, 60)) . '</td>
                <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['publisher'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                <td style="text-align:center;">' . $status . '</td>
            </tr>';
        }
    }
    
    $html .= '</tbody></table>';
    
    // Summary
    $totalBooks = count($data);
    $totalQuantity = array_sum(array_column($data, 'quantity'));
    $totalAvailable = array_sum(array_column($data, 'available'));
    
    $html .= '<div class="summary">
        <strong>Summary:</strong> 
        Total Records: ' . $totalBooks . ' | 
        Total Copies: ' . $totalQuantity . ' | 
        Available: ' . $totalAvailable . ' | 
        Issued: ' . ($totalQuantity - $totalAvailable) . '
    </div>';
    
    // Footer
    $html .= '<div class="footer">' . htmlspecialchars($settings['report_footer_text'] ?? 'This is a system generated report') . '<br>&copy; ' . date('Y') . ' All rights reserved.</div>';
    
    $html .= '</body></html>';
    
    // Try mPDF
    if ($libraries['pdf'] && class_exists('Mpdf\Mpdf')) {
        try {
            $paperSizeMap = ['A4' => 'A4', 'Letter' => 'Letter', 'Legal' => 'Legal', 'A3' => 'A3'];
            $pdfPaperSize = $paperSizeMap[$paperSize] ?? 'A4';
            $pdfOrientation = ($orientation === 'landscape') ? 'L' : 'P';
            
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $pdfPaperSize,
                'orientation' => $pdfOrientation,
                'default_font_size' => 9,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($title);
            $mpdf->SetAuthor($institutionName);
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.pdf"');
            $mpdf->Output('books_' . date('Y-m-d') . '.pdf', 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF export error: " . $e->getMessage());
        }
    }
    
    // Try DOMPDF
    if ($libraries['pdf'] && class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.pdf"');
            echo $dompdf->output();
            exit;
        } catch (Exception $e) {
            error_log("DOMPDF export error: " . $e->getMessage());
        }
    }
    
    // Fallback: Show HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($title) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:5px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo $html;
    echo '<div style="text-align:center;margin-top:20px;">
        <button onclick="window.print()" style="padding:10px 20px;background:#1e3c72;color:white;border:none;border-radius:5px;cursor:pointer;">Print PDF</button>
        <button onclick="window.history.back()" style="padding:10px 20px;background:#6c757d;color:white;border:none;border-radius:5px;cursor:pointer;">Go Back</button>
    </div>';
    echo '</body></html>';
    exit;
}

// ==================== MARC21 EXPORT FUNCTIONS ====================

/**
 * Export books to MARC21
 * 
 * @param PDO $db Database connection
 * @param array $data Array of book data
 * @param string $format 'mrc' or 'xml'
 */
function exportBooksMARC($db, $data, $format = 'mrc') {
    $libraries = checkExportLibraries();
    
    while (ob_get_level()) ob_end_clean();
    
    if (!$libraries['marc']) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>MARC Export Error</h2>';
        echo '<p>MARC library not installed. Please run: <code>composer require pear/file_marc</code></p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
    
    if (empty($data)) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>No Books Selected</h2>';
        echo '<p>Please select at least one book to export.</p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
    
    // MARC field mapping
    $marcMapping = [
        'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
        'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
        'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
        'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
        'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
        'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
        'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
        'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'call_number' => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
        'category'    => ['tag' => '084', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
        'price'       => ['tag' => '020', 'subfield' => 'c', 'indicators' => [' ', ' ']],
        'series'      => ['tag' => '490', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'volume'      => ['tag' => '490', 'subfield' => 'v', 'indicators' => [' ', ' ']],
        'language'    => ['tag' => '008', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'summary'     => ['tag' => '520', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'contents'    => ['tag' => '505', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'issn'        => ['tag' => '022', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'ddc'         => ['tag' => '082', 'subfield' => 'a', 'indicators' => ['0', ' ']],
        'lcc'         => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'accession_number' => ['tag' => '952', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    ];
    
    function dbToMarc($book, $mapping) {
        if (class_exists('Scriptotek\Marc\Record')) {
            $record = new \Scriptotek\Marc\Record();
            $record->leader = "     nam a22     i 4500";
            foreach ($mapping as $dbField => $marc) {
                if (empty($book[$dbField])) continue;
                $tag = $marc['tag'];
                $subfield = $marc['subfield'];
                $indicators = $marc['indicators'] ?? [' ', ' '];
                $field = $record->getField($tag);
                if (!$field) {
                    $field = $record->addField($tag, $indicators);
                }
                $field->addSubfield($subfield, $book[$dbField]);
            }
            return $record;
        } elseif (class_exists('File_MARC_Record')) {
            $record = new \File_MARC_Record();
            $record->setLeader("     nam a22     i 4500");
            foreach ($mapping as $dbField => $marc) {
                if (empty($book[$dbField])) continue;
                $tag = $marc['tag'];
                $subfield = $marc['subfield'];
                $indicators = $marc['indicators'] ?? [' ', ' '];
                $field = $record->getField($tag);
                if (!$field) {
                    $field = new \File_MARC_Data_Field($tag, $indicators);
                    $record->appendField($field);
                }
                $field->appendSubfield(new \File_MARC_Subfield($subfield, $book[$dbField]));
            }
            return $record;
        }
        throw new Exception("MARC library not available");
    }
    
    try {
        if (class_exists('Scriptotek\Marc\MarcCollection')) {
            $collection = new \Scriptotek\Marc\MarcCollection();
            foreach ($data as $book) {
                $record = dbToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXml();
                $filename = "books_export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "books_export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/marc";
            }
        } elseif (class_exists('File_MARC_Collection')) {
            $collection = new \File_MARC_Collection();
            foreach ($data as $book) {
                $record = dbToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXML();
                $filename = "books_export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "books_export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/octet-stream";
            }
        } else {
            throw new Exception("MARC collection class not found");
        }
        
        header("Content-Type: $contentType");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Length: " . strlen($content));
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        echo $content;
        exit;
        
    } catch (Exception $e) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>MARC Export Error</h2>';
        echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
}

// ==================== GENERIC EXPORT WRAPPER FUNCTIONS ====================

/**
 * Generic export function that determines the export type
 * 
 * @param PDO $db Database connection
 * @param array $data Array of data to export
 * @param string $type 'csv', 'excel', 'pdf', 'marc'
 * @param string $mode 'copies' or 'titles'
 * @param string $title Report title
 * @param array $options Additional options (paperSize, orientation, marcFormat)
 */
function exportData($db, $data, $type = 'csv', $mode = 'copies', $title = 'Report', $options = []) {
    switch ($type) {
        case 'csv':
            exportBooksCSV($db, $data, $mode, $title);
            break;
        case 'excel':
            exportBooksExcel($db, $data, $mode, $title);
            break;
        case 'pdf':
            $paperSize = $options['paperSize'] ?? 'A4';
            $orientation = $options['orientation'] ?? 'landscape';
            exportBooksPDF($db, $data, $mode, $title, $paperSize, $orientation);
            break;
        case 'marc':
            $format = $options['marcFormat'] ?? 'mrc';
            exportBooksMARC($db, $data, $format);
            break;
        default:
            exportBooksCSV($db, $data, $mode, $title);
    }
}

// ==================== EXPORT INITIALIZATION ====================

// Auto-detect if this file is being included or run directly
if (isset($_GET['export']) && isset($_GET['type'])) {
    // This file is being called directly for export
    require_once __DIR__ . '/../config/db.php';
    require_once __DIR__ . '/../config/functions.php';
    require_once __DIR__ . '/../config/auth.php';
    
    requireLogin();
    
    $db = getDB();
    $type = $_GET['type'] ?? 'csv';
    $mode = $_GET['export_mode'] ?? 'copies';
    $title = $_GET['title'] ?? 'Export';
    
    // Get data based on report type
    $reportType = $_GET['report_type'] ?? 'books';
    $data = [];
    
    switch ($reportType) {
        case 'books':
            $category = $_GET['category'] ?? 'all';
            $status = $_GET['status'] ?? 'all';
            $location = $_GET['location'] ?? '';
            $year_from = $_GET['year_from'] ?? '';
            $year_to = $_GET['year_to'] ?? '';
            $price_min = $_GET['price_min'] ?? '';
            $price_max = $_GET['price_max'] ?? '';
            $sort_by = $_GET['sort_by'] ?? 'title';
            $sort_order = $_GET['sort_order'] ?? 'ASC';
            
            $sql = "SELECT * FROM books WHERE 1=1";
            $params = [];
            if ($category !== 'all') {
                $sql .= " AND category = ?";
                $params[] = $category;
            }
            if ($status === 'available') {
                $sql .= " AND available > 0";
            } elseif ($status === 'unavailable') {
                $sql .= " AND available = 0";
            } elseif ($status === 'lowstock') {
                $sql .= " AND available > 0 AND available <= 2";
            }
            if (!empty($location)) {
                $sql .= " AND (location LIKE ? OR current_location LIKE ? OR shelf LIKE ? OR branch LIKE ?)";
                $like = "%$location%";
                $params = array_merge($params, [$like, $like, $like, $like]);
            }
            if (!empty($year_from)) {
                $sql .= " AND year >= ?";
                $params[] = $year_from;
            }
            if (!empty($year_to)) {
                $sql .= " AND year <= ?";
                $params[] = $year_to;
            }
            if ($price_min !== '') {
                $sql .= " AND price >= ?";
                $params[] = (float)$price_min;
            }
            if ($price_max !== '') {
                $sql .= " AND price <= ?";
                $params[] = (float)$price_max;
            }
            $allowed_sort = ['title','author','publisher','category','year','price','barcode','available','quantity'];
            if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
            $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
            $sql .= " ORDER BY $sort_by $sort_order";
            
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $data = $stmt->fetchAll();
            $title = 'Books Report';
            break;
            
        case 'members':
            $data = $db->query("SELECT * FROM members ORDER BY name")->fetchAll();
            $title = 'Members Report';
            exportMembersCSV($db, $data, $title);
            break;
            
        default:
            exportBooksCSV($db, [], $mode, 'No Data');
    }
    
    $options = [
        'paperSize' => $_GET['paper_size'] ?? 'A4',
        'orientation' => $_GET['orientation'] ?? 'landscape',
        'marcFormat' => $_GET['marc_format'] ?? 'mrc'
    ];
    
    exportData($db, $data, $type, $mode, $title, $options);
}
?>