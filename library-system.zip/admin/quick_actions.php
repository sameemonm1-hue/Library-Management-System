<?php
/**
 * Quick Actions Manager
 * Allows admins to add, edit, delete, and reorder dashboard quick action cards.
 * 
 * Access: Only users with role 'admin'
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = Database::getInstance()->getConnection();
$message = '';
$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add new quick action
    if (isset($_POST['add'])) {
        $title = trim($_POST['title']);
        $icon = trim($_POST['icon_class']);
        $link = trim($_POST['link_url']);
        $order = (int)($_POST['sort_order'] ?? 999);
        $active = isset($_POST['is_active']) ? 1 : 0;
        
        if (empty($title) || empty($icon) || empty($link)) {
            $error = "Title, Icon class, and Link URL are required.";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$title, $icon, $link, $order, $active]);
                $message = "Quick action added successfully.";
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
    
    // Edit existing quick action
    elseif (isset($_POST['edit'])) {
        $id = (int)$_POST['id'];
        $title = trim($_POST['title']);
        $icon = trim($_POST['icon_class']);
        $link = trim($_POST['link_url']);
        $order = (int)($_POST['sort_order'] ?? 0);
        $active = isset($_POST['is_active']) ? 1 : 0;
        
        if (empty($title) || empty($icon) || empty($link)) {
            $error = "Title, Icon class, and Link URL are required.";
        } else {
            try {
                $stmt = $db->prepare("UPDATE quick_actions SET title = ?, icon_class = ?, link_url = ?, sort_order = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$title, $icon, $link, $order, $active, $id]);
                $message = "Quick action updated successfully.";
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
    
    // Delete quick action
    elseif (isset($_POST['delete'])) {
        $id = (int)$_POST['id'];
        try {
            $stmt = $db->prepare("DELETE FROM quick_actions WHERE id = ?");
            $stmt->execute([$id]);
            $message = "Quick action deleted.";
        } catch (PDOException $e) {
            $error = "Delete failed: " . $e->getMessage();
        }
    }
    
    // Reorder (AJAX from drag & drop)
    elseif (isset($_POST['reorder'])) {
        if (isset($_POST['order']) && is_string($_POST['order'])) {
            $orderArray = json_decode($_POST['order'], true);
            if (is_array($orderArray)) {
                $db->beginTransaction();
                try {
                    foreach ($orderArray as $idx => $id) {
                        $newOrder = $idx + 1;
                        $stmt = $db->prepare("UPDATE quick_actions SET sort_order = ? WHERE id = ?");
                        $stmt->execute([$newOrder, (int)$id]);
                    }
                    $db->commit();
                    $message = "Order updated successfully.";
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = "Reorder failed: " . $e->getMessage();
                }
            } else {
                $error = "Invalid order data.";
            }
        } else {
            $error = "No order data received.";
        }
    }
}

// Fetch all quick actions (including inactive ones for management)
$actions = $db->query("SELECT * FROM quick_actions ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quick Actions Manager | Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <style>
        body {
            background: #f4f6f9;
            font-family: 'Inter', sans-serif;
            padding-bottom: 40px;
        }
        .container {
            max-width: 1400px;
            margin-top: 30px;
        }
        .card {
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            border: none;
            margin-bottom: 30px;
        }
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            padding: 18px 25px;
            font-weight: 600;
            border-radius: 20px 20px 0 0;
        }
        .table th {
            font-weight: 600;
            background: #f8f9fa;
        }
        .sortable-row {
            cursor: move;
            transition: background 0.2s;
        }
        .sortable-row:hover {
            background-color: #fff3cd !important;
        }
        .btn-icon {
            padding: 5px 12px;
            border-radius: 40px;
        }
        .drag-handle {
            cursor: grab;
            color: #adb5bd;
        }
        .drag-handle:active {
            cursor: grabbing;
        }
        .badge-status {
            font-size: 11px;
            padding: 5px 10px;
        }
        .form-label {
            font-weight: 500;
            font-size: 14px;
        }
        .icon-preview {
            font-size: 24px;
            width: 40px;
            text-align: center;
            display: inline-block;
        }
        @media (max-width: 768px) {
            .table-responsive {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h1 class="display-6 fw-bold"><i class="fas fa-th-large text-primary me-2"></i> Quick Actions Manager</h1>
            <p class="text-muted">Manage the dashboard shortcut cards – add, edit, reorder, enable/disable.</p>
        </div>
        <a href="../index.php" class="btn btn-outline-secondary mt-2 mt-sm-0"><i class="fas fa-arrow-left me-1"></i> Back to Dashboard</a>
    </div>

    <!-- Alert Messages -->
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- LEFT COLUMN: Add New Action Form -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-plus-circle me-2"></i> Add New Quick Action
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" class="form-control" placeholder="e.g., Digital Library" required>
                            <small class="text-muted">Display name on the card.</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Icon Class <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="fas fa-icons"></i></span>
                                <input type="text" name="icon_class" class="form-control" placeholder="fa-book" value="fa-link" required>
                            </div>
                            <small class="text-muted">FontAwesome 6 class (e.g., <code>fa-users</code>, <code>fa-chart-line</code>). <a href="https://fontawesome.com/v6/search" target="_blank">Browse icons</a></small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Link URL <span class="text-danger">*</span></label>
                            <input type="text" name="link_url" class="form-control" placeholder="admin/settings.php" required>
                            <small class="text-muted">Relative path from the root (e.g., <code>circulation/issue.php</code>).</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Sort Order</label>
                            <input type="number" name="sort_order" class="form-control" value="999" step="1">
                            <small class="text-muted">Lower numbers appear first. You can also drag & drop to reorder.</small>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="is_active" class="form-check-input" id="newActive" checked>
                            <label class="form-check-label" for="newActive">Active (visible on dashboard)</label>
                        </div>
                        <button type="submit" name="add" class="btn btn-primary w-100"><i class="fas fa-save me-2"></i> Add Module</button>
                    </form>
                </div>
            </div>

            <!-- Info Card -->
            <div class="card mt-4">
                <div class="card-header bg-secondary text-white">
                    <i class="fas fa-info-circle me-2"></i> Tips
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-2"><i class="fas fa-arrows-alt text-primary me-2"></i> <strong>Reorder</strong> – Drag any row by the handle <i class="fas fa-grip-vertical"></i> to change order.</li>
                        <li class="mb-2"><i class="fas fa-eye-slash text-warning me-2"></i> <strong>Disable</strong> – Set active to "No" to hide a module without deleting.</li>
                        <li class="mb-2"><i class="fas fa-trash-alt text-danger me-2"></i> <strong>Delete</strong> – Permanently removes the module.</li>
                        <li><i class="fas fa-magic text-info me-2"></i> <strong>Icon classes</strong> – Use exact FontAwesome 6 class (without "fas" prefix? Actually include both – e.g., <code>fa-users</code>; the system adds <code>fas</code> automatically).</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN: List of Actions with Drag & Drop -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-list me-2"></i> Current Quick Actions</span>
                    <span class="badge bg-light text-dark"><?= count($actions) ?> module(s)</span>
                </div>
                <div class="card-body p-0">
                    <form id="reorderForm" method="post" style="display:none;">
                        <input type="hidden" name="reorder" value="1">
                        <input type="hidden" name="order" id="orderInput">
                    </form>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 40px"><i class="fas fa-grip-vertical"></i></th>
                                    <th>Title</th>
                                    <th>Icon</th>
                                    <th>Link URL</th>
                                    <th>Order</th>
                                    <th>Status</th>
                                    <th style="width: 120px">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="sortable">
                                <?php foreach ($actions as $act): ?>
                                <tr class="sortable-row" data-id="<?= $act['id'] ?>">
                                    <td class="drag-handle text-center"><i class="fas fa-grip-vertical"></i></td>
                                    <td class="fw-semibold"><?= htmlspecialchars($act['title']) ?></td>
                                    <td><i class="fas <?= htmlspecialchars($act['icon_class']) ?> fa-fw"></i> <?= htmlspecialchars($act['icon_class']) ?></td>
                                    <td><code><?= htmlspecialchars($act['link_url']) ?></code></td>
                                    <td><?= $act['sort_order'] ?></td>
                                    <td>
                                        <?php if ($act['is_active']): ?>
                                            <span class="badge bg-success badge-status"><i class="fas fa-check-circle me-1"></i> Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary badge-status"><i class="fas fa-eye-slash me-1"></i> Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-warning edit-btn" data-bs-toggle="modal" data-bs-target="#editModal"
                                                data-id="<?= $act['id'] ?>"
                                                data-title="<?= htmlspecialchars($act['title']) ?>"
                                                data-icon="<?= htmlspecialchars($act['icon_class']) ?>"
                                                data-link="<?= htmlspecialchars($act['link_url']) ?>"
                                                data-order="<?= $act['sort_order'] ?>"
                                                data-active="<?= $act['is_active'] ?>">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <form method="post" style="display:inline-block" class="d-inline" onsubmit="return confirm('Delete this quick action permanently?')">
                                            <input type="hidden" name="id" value="<?= $act['id'] ?>">
                                            <button type="submit" name="delete" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash-alt"></i> Del</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($actions)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">No quick actions found. Add your first module using the form.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-light">
                    <small class="text-muted"><i class="fas fa-info-circle me-1"></i> Drag any row to reorder. Changes are saved automatically.</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg border-0">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title" id="editModalLabel"><i class="fas fa-pen-alt me-2"></i> Edit Quick Action</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" id="edit_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Icon Class</label>
                        <div class="input-group">
                            <span class="input-group-text" id="icon_preview"><i class="fas fa-cog"></i></span>
                            <input type="text" name="icon_class" id="edit_icon" class="form-control" required>
                        </div>
                        <small class="text-muted">FontAwesome class only (e.g., <code>fa-book</code>) – the "fas" prefix is added automatically.</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Link URL</label>
                        <input type="text" name="link_url" id="edit_link" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sort Order</label>
                        <input type="number" name="sort_order" id="edit_order" class="form-control">
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="is_active" id="edit_active" class="form-check-input">
                        <label class="form-check-label" for="edit_active">Active (visible on dashboard)</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="edit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-ui-dist/jquery-ui.min.js"></script>
<script>
$(function() {
    // Enable drag & drop sorting
    $("#sortable").sortable({
        handle: ".drag-handle",
        update: function() {
            var order = [];
            $("#sortable .sortable-row").each(function() {
                order.push($(this).data("id"));
            });
            $("#orderInput").val(JSON.stringify(order));
            $("#reorderForm").submit();
        }
    });
    
    // Populate edit modal with data
    $('.edit-btn').on('click', function() {
        var btn = $(this);
        $('#edit_id').val(btn.data('id'));
        $('#edit_title').val(btn.data('title'));
        $('#edit_icon').val(btn.data('icon'));
        $('#edit_link').val(btn.data('link'));
        $('#edit_order').val(btn.data('order'));
        $('#edit_active').prop('checked', btn.data('active') == 1);
        // Update icon preview
        var iconClass = btn.data('icon');
        $('#icon_preview').html('<i class="fas ' + iconClass + '"></i>');
    });
    
    // Update icon preview when typing in edit modal icon field
    $('#edit_icon').on('input', function() {
        var val = $(this).val();
        $('#icon_preview').html('<i class="fas ' + val + '"></i>');
    });
});
</script>
</body>
</html>