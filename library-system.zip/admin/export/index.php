<?php
/**
 * Export Module Index - Dashboard
 */

require_once __DIR__ . '/config.php';

if (function_exists('renderHeader')) {
    renderHeader('Export Module');
} else {
    $headerPath = BASE_PATH . '/admin/includes/header.php';
    if (file_exists($headerPath)) {
        include $headerPath;
    } else {
        echo '<!DOCTYPE html><html><head><title>Export Module</title>';
        echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">';
        echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">';
        echo '</head><body>';
    }
}
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-file-export"></i> Export Module</h2>
        <div>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-book"></i> Books Export
                </div>
                <div class="card-body">
                    <p>Export book catalog in multiple formats with advanced filtering.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV (Copies & Titles)</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel (Copies & Titles)</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF (Copies & Titles)</li>
                        <li><i class="fas fa-book text-dark"></i> MARC21 (.mrc & .xml)</li>
                    </ul>
                    <a href="books.php" class="btn btn-primary">Export Books →</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-users"></i> Members Export
                </div>
                <div class="card-body">
                    <p>Export member directory with all details.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV Format</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel Format</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF Format</li>
                    </ul>
                    <a href="members.php" class="btn btn-success">Export Members →</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-warning text-white">
                    <i class="fas fa-exchange-alt"></i> Circulation Export
                </div>
                <div class="card-body">
                    <p>Export circulation transactions with filters.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV Format</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel Format</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF Format</li>
                    </ul>
                    <a href="circulation.php" class="btn btn-warning">Export Circulation →</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-triangle"></i> Overdue Export
                </div>
                <div class="card-body">
                    <p>Export overdue books list with fines.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV Format</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel Format</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF Format</li>
                    </ul>
                    <a href="overdue.php" class="btn btn-danger">Export Overdue →</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-door-open"></i> Entry/Exit Export
                </div>
                <div class="card-body">
                    <p>Export entry/exit logs with filters.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV Format</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel Format</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF Format</li>
                    </ul>
                    <a href="entry_exit.php" class="btn btn-info">Export Entry/Exit →</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <i class="fas fa-desktop"></i> Computer Usage Export
                </div>
                <div class="card-body">
                    <p>Export computer usage sessions.</p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-file-csv text-success"></i> CSV Format</li>
                        <li><i class="fas fa-file-excel text-success"></i> Excel Format</li>
                        <li><i class="fas fa-file-pdf text-danger"></i> PDF Format</li>
                    </ul>
                    <a href="computer.php" class="btn btn-secondary">Export Computer Usage →</a>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header bg-dark text-white">
            <i class="fas fa-info-circle"></i> Export Information
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <h6>Available Libraries:</h6>
                    <ul>
                        <li><i class="fas fa-<?= $excelAvailable ? 'check-circle text-success' : 'times-circle text-danger' ?>"></i> PhpSpreadsheet (Excel) <?= $excelAvailable ? '✅' : '❌' ?></li>
                        <li><i class="fas fa-<?= $pdfAvailable ? 'check-circle text-success' : 'times-circle text-danger' ?>"></i> mPDF/DOMPDF (PDF) <?= $pdfAvailable ? '✅' : '❌' ?></li>
                        <li><i class="fas fa-<?= $marcAvailable ? 'check-circle text-success' : 'times-circle text-danger' ?>"></i> File_MARC (MARC21) <?= $marcAvailable ? '✅' : '❌' ?></li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6>Install Missing Libraries:</h6>
                    <code class="d-block bg-light p-2 rounded">
                        composer require phpoffice/phpspreadsheet<br>
                        composer require mpdf/mpdf<br>
                        composer require pear/file_marc
                    </code>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if (function_exists('renderFooter')) {
    renderFooter();
} else {
    $footerPath = BASE_PATH . '/admin/includes/footer.php';
    if (file_exists($footerPath)) {
        include $footerPath;
    } else {
        echo '</body></html>';
    }
}
?>