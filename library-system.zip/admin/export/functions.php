<?php
/**
 * Export Functions - Complete Library
 */

require_once __DIR__ . '/config.php';

// ==================== CSV EXPORT ====================

/**
 * Export books to CSV
 */
function exportBooksCSV($db, $data, $mode = 'copies', $title = 'Books Report') {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    if ($mode === 'titles') {
        $headers = [
            'Sl No', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator',
            'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition',
            'Pages', 'Language', 'Country', 'Category', 'Sub Category',
            'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
            'Other Classification', 'Cutter', 'Call Number', 'Subjects',
            'Keywords', 'Summary', 'Total Copies', 'Available', 'Price',
            'Currency', 'Book Status', 'Item Category', 'Maintenance',
            'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
            'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number',
            'eBook URL', 'Remarks'
        ];
        fputcsv($out, $headers);
        
        $grouped = [];
        foreach ($data as $book) {
            $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
            if (!isset($grouped[$key])) {
                $book['_quantity'] = (int)($book['quantity'] ?? 0);
                $book['_available'] = (int)($book['available'] ?? 0);
                $grouped[$key] = $book;
            } else {
                $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
            }
        }
        
        $sn = 1;
        foreach ($grouped as $book) {
            fputcsv($out, [
                $sn++,
                $book['title'] ?? '',
                $book['sub_title'] ?? '',
                $book['author'] ?? '',
                $book['author2'] ?? '',
                $book['collaborator'] ?? '',
                $book['publisher'] ?? '',
                $book['publisher_place'] ?? '',
                $book['isbn'] ?? '',
                $book['issn'] ?? '',
                $book['year'] ?? '',
                $book['edition'] ?? '',
                (int)($book['pages'] ?? 0),
                $book['language'] ?? 'English',
                $book['country'] ?? '',
                $book['category'] ?? '',
                $book['sub_category'] ?? '',
                $book['collection_type'] ?? '',
                $book['series'] ?? '',
                $book['volume'] ?? '',
                $book['ddc'] ?? '',
                $book['udc'] ?? '',
                $book['lcc'] ?? '',
                $book['cc'] ?? '',
                $book['other_classification'] ?? '',
                $book['cutter'] ?? '',
                $book['call_number'] ?? '',
                $book['subject'] ?? '',
                $book['keyword'] ?? '',
                $book['summary'] ?? '',
                $book['_quantity'] ?? 0,
                $book['_available'] ?? 0,
                $book['price'] ?? '',
                $book['price_currency'] ?? 'INR',
                $book['book_status'] ?? 'Available',
                $book['item_category'] ?? '',
                $book['maintenance'] ?? '',
                $book['current_location'] ?? '',
                $book['section'] ?? '',
                $book['branch'] ?? '',
                $book['shelf'] ?? '',
                $book['vendor'] ?? '',
                $book['invoice'] ?? '',
                $book['acquisition_date'] ?? '',
                $book['funding_source'] ?? '',
                $book['po_number'] ?? '',
                $book['ebook_url'] ?? '',
                $book['remarks'] ?? ''
            ]);
        }
    } else {
        $headers = [
            'Sl No', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2',
            'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year',
            'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
            'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
            'Other Classification', 'Cutter', 'Call Number', 'Subjects',
            'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
            'Currency', 'Book Status', 'Item Category', 'Maintenance',
            'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
            'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
            'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
            'Material Type', 'Size', 'Weight', 'Remarks'
        ];
        fputcsv($out, $headers);
        
        $sn = 1;
        foreach ($data as $book) {
            fputcsv($out, [
                $sn++,
                $book['barcode'] ?? '',
                $book['accession_number'] ?? '',
                $book['title'] ?? '',
                $book['sub_title'] ?? '',
                $book['author'] ?? '',
                $book['author2'] ?? '',
                $book['collaborator'] ?? '',
                $book['publisher'] ?? '',
                $book['publisher_place'] ?? '',
                $book['isbn'] ?? '',
                $book['issn'] ?? '',
                $book['year'] ?? '',
                $book['edition'] ?? '',
                (int)($book['pages'] ?? 0),
                $book['language'] ?? 'English',
                $book['country'] ?? '',
                $book['category'] ?? '',
                $book['sub_category'] ?? '',
                $book['collection_type'] ?? '',
                $book['series'] ?? '',
                $book['volume'] ?? '',
                $book['ddc'] ?? '',
                $book['udc'] ?? '',
                $book['lcc'] ?? '',
                $book['cc'] ?? '',
                $book['other_classification'] ?? '',
                $book['cutter'] ?? '',
                $book['call_number'] ?? '',
                $book['subject'] ?? '',
                $book['keyword'] ?? '',
                $book['summary'] ?? '',
                (int)($book['quantity'] ?? 0),
                (int)($book['available'] ?? 0),
                $book['price'] ?? '',
                $book['price_currency'] ?? 'INR',
                $book['book_status'] ?? 'Available',
                $book['item_category'] ?? '',
                $book['maintenance'] ?? '',
                $book['current_location'] ?? '',
                $book['section'] ?? '',
                $book['branch'] ?? '',
                $book['shelf'] ?? '',
                $book['vendor'] ?? '',
                $book['invoice'] ?? '',
                $book['invoice_date'] ?? '',
                $book['acquisition_date'] ?? '',
                $book['funding_source'] ?? '',
                $book['po_number'] ?? '',
                $book['ebook_url'] ?? '',
                $book['contents'] ?? '',
                $book['accompanying_material'] ?? '',
                $book['material_type'] ?? '',
                $book['size'] ?? '',
                $book['weight'] ?? '',
                $book['remarks'] ?? ''
            ]);
        }
    }
    
    fclose($out);
    exit;
}

// ==================== EXCEL EXPORT ====================

function exportBooksExcel($db, $data, $mode = 'copies', $title = 'Books Report') {
    global $excelAvailable;
    
    while (ob_get_level()) ob_end_clean();
    
    if ($excelAvailable) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Books');
            
            if ($mode === 'titles') {
                $headers = [
                    'Sl No', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator',
                    'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition',
                    'Pages', 'Language', 'Country', 'Category', 'Sub Category',
                    'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
                    'Other Classification', 'Cutter', 'Call Number', 'Subjects',
                    'Keywords', 'Summary', 'Total Copies', 'Available', 'Price',
                    'Currency', 'Book Status', 'Item Category', 'Maintenance',
                    'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
                    'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number',
                    'eBook URL', 'Remarks'
                ];
            } else {
                $headers = [
                    'Sl No', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2',
                    'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year',
                    'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
                    'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
                    'Other Classification', 'Cutter', 'Call Number', 'Subjects',
                    'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
                    'Currency', 'Book Status', 'Item Category', 'Maintenance',
                    'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
                    'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
                    'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
                    'Material Type', 'Size', 'Weight', 'Remarks'
                ];
            }
            
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . '1', $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A1:' . $col . '1')->getFont()->setBold(true);
            
            $row = 2;
            $sn = 1;
            
            if ($mode === 'titles') {
                $grouped = [];
                foreach ($data as $book) {
                    $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
                    if (!isset($grouped[$key])) {
                        $book['_quantity'] = (int)($book['quantity'] ?? 0);
                        $book['_available'] = (int)($book['available'] ?? 0);
                        $grouped[$key] = $book;
                    } else {
                        $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                        $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
                    }
                }
                foreach ($grouped as $book) {
                    $col = 'A';
                    $values = [
                        $sn++,
                        $book['title'] ?? '',
                        $book['sub_title'] ?? '',
                        $book['author'] ?? '',
                        $book['author2'] ?? '',
                        $book['collaborator'] ?? '',
                        $book['publisher'] ?? '',
                        $book['publisher_place'] ?? '',
                        $book['isbn'] ?? '',
                        $book['issn'] ?? '',
                        $book['year'] ?? '',
                        $book['edition'] ?? '',
                        (int)($book['pages'] ?? 0),
                        $book['language'] ?? 'English',
                        $book['country'] ?? '',
                        $book['category'] ?? '',
                        $book['sub_category'] ?? '',
                        $book['collection_type'] ?? '',
                        $book['series'] ?? '',
                        $book['volume'] ?? '',
                        $book['ddc'] ?? '',
                        $book['udc'] ?? '',
                        $book['lcc'] ?? '',
                        $book['cc'] ?? '',
                        $book['other_classification'] ?? '',
                        $book['cutter'] ?? '',
                        $book['call_number'] ?? '',
                        $book['subject'] ?? '',
                        $book['keyword'] ?? '',
                        $book['summary'] ?? '',
                        $book['_quantity'] ?? 0,
                        $book['_available'] ?? 0,
                        $book['price'] ?? '',
                        $book['price_currency'] ?? 'INR',
                        $book['book_status'] ?? 'Available',
                        $book['item_category'] ?? '',
                        $book['maintenance'] ?? '',
                        $book['current_location'] ?? '',
                        $book['section'] ?? '',
                        $book['branch'] ?? '',
                        $book['shelf'] ?? '',
                        $book['vendor'] ?? '',
                        $book['invoice'] ?? '',
                        $book['acquisition_date'] ?? '',
                        $book['funding_source'] ?? '',
                        $book['po_number'] ?? '',
                        $book['ebook_url'] ?? '',
                        $book['remarks'] ?? ''
                    ];
                    foreach ($values as $value) {
                        $sheet->setCellValue($col . $row, $value);
                        $col++;
                    }
                    $row++;
                }
            } else {
                foreach ($data as $book) {
                    $col = 'A';
                    $values = [
                        $sn++,
                        $book['barcode'] ?? '',
                        $book['accession_number'] ?? '',
                        $book['title'] ?? '',
                        $book['sub_title'] ?? '',
                        $book['author'] ?? '',
                        $book['author2'] ?? '',
                        $book['collaborator'] ?? '',
                        $book['publisher'] ?? '',
                        $book['publisher_place'] ?? '',
                        $book['isbn'] ?? '',
                        $book['issn'] ?? '',
                        $book['year'] ?? '',
                        $book['edition'] ?? '',
                        (int)($book['pages'] ?? 0),
                        $book['language'] ?? 'English',
                        $book['country'] ?? '',
                        $book['category'] ?? '',
                        $book['sub_category'] ?? '',
                        $book['collection_type'] ?? '',
                        $book['series'] ?? '',
                        $book['volume'] ?? '',
                        $book['ddc'] ?? '',
                        $book['udc'] ?? '',
                        $book['lcc'] ?? '',
                        $book['cc'] ?? '',
                        $book['other_classification'] ?? '',
                        $book['cutter'] ?? '',
                        $book['call_number'] ?? '',
                        $book['subject'] ?? '',
                        $book['keyword'] ?? '',
                        $book['summary'] ?? '',
                        (int)($book['quantity'] ?? 0),
                        (int)($book['available'] ?? 0),
                        $book['price'] ?? '',
                        $book['price_currency'] ?? 'INR',
                        $book['book_status'] ?? 'Available',
                        $book['item_category'] ?? '',
                        $book['maintenance'] ?? '',
                        $book['current_location'] ?? '',
                        $book['section'] ?? '',
                        $book['branch'] ?? '',
                        $book['shelf'] ?? '',
                        $book['vendor'] ?? '',
                        $book['invoice'] ?? '',
                        $book['invoice_date'] ?? '',
                        $book['acquisition_date'] ?? '',
                        $book['funding_source'] ?? '',
                        $book['po_number'] ?? '',
                        $book['ebook_url'] ?? '',
                        $book['contents'] ?? '',
                        $book['accompanying_material'] ?? '',
                        $book['material_type'] ?? '',
                        $book['size'] ?? '',
                        $book['weight'] ?? '',
                        $book['remarks'] ?? ''
                    ];
                    foreach ($values as $value) {
                        $sheet->setCellValue($col . $row, $value);
                        $col++;
                    }
                    $row++;
                }
            }
            
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
            
        } catch (Exception $e) {
            error_log("Excel export error: " . $e->getMessage());
        }
    }
    
    exportBooksCSV($db, $data, $mode, $title);
}

// ==================== PDF EXPORT ====================

function exportBooksPDF($db, $data, $mode = 'copies', $title = 'Books Report',
                        $paperSize = 'A4', $orientation = 'landscape') {
    global $pdfAvailable;
    
    while (ob_get_level()) ob_end_clean();
    
    $institutionName = getInstitutionName();
    $logoBase64 = getLogoForExport();
    $settings = getSettings();
    
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>
        @page { margin: 1.5cm; }
        body { font-family: "DejaVu Sans", "Arial", sans-serif; font-size: 9px; margin: 0; padding: 10px; }
        .header { text-align: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #1e3c72; }
        .institution-name { font-size: 18px; font-weight: bold; color: #1e3c72; }
        .report-title { font-size: 16px; font-weight: bold; margin: 8px 0; }
        .report-meta { font-size: 9px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 8px; }
        th, td { border: 1px solid #000; padding: 4px; text-align: left; vertical-align: top; }
        th { background-color: #1e3c72; color: white; font-weight: bold; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .footer { margin-top: 15px; text-align: center; font-size: 8px; color: #777; border-top: 1px solid #ddd; padding-top: 8px; }
        .summary { margin: 10px 0; padding: 8px; background: #f5f5f5; border-left: 4px solid #1e3c72; font-size: 9px; }
        .watermark { position: fixed; bottom: 50%; right: 50%; transform: translate(50%, 50%) rotate(-45deg); font-size: 48px; color: rgba(0,0,0,0.05); white-space: nowrap; z-index: 9999; pointer-events: none; }
    </style>';
    
    if ($settings['report_watermark_enabled'] ?? 0) {
        $watermarkText = $settings['report_watermark_text'] ?? 'Library';
        $html .= '<div class="watermark">' . htmlspecialchars($watermarkText) . '</div>';
    }
    
    $html .= '</head><body>';
    
    $html .= '<div class="header">';
    if ($logoBase64) {
        $html .= '<img src="' . $logoBase64 . '" style="height:50px; width:auto; margin-bottom:5px;"><br>';
    }
    $html .= '<div class="institution-name">' . htmlspecialchars($institutionName) . '</div>';
    $html .= '<div class="report-title">' . htmlspecialchars($title) . '</div>';
    $html .= '<div class="report-meta">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    
    if ($mode === 'titles') {
        $html .= '<table>
            <thead><tr>
                <th style="text-align:center;">#</th>
                <th>Title</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>ISBN</th>
                <th>Year</th>
                <th style="text-align:center;">Copies</th>
                <th style="text-align:center;">Available</th>
                <th style="text-align:right;">Price</th>
            </tr></thead><tbody>';
        
        $grouped = [];
        foreach ($data as $book) {
            $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
            if (!isset($grouped[$key])) {
                $book['_quantity'] = (int)($book['quantity'] ?? 0);
                $book['_available'] = (int)($book['available'] ?? 0);
                $grouped[$key] = $book;
            } else {
                $grouped[$key]['_quantity'] += (int)($book['quantity'] ?? 0);
                $grouped[$key]['_available'] += (int)($book['available'] ?? 0);
            }
        }
        
        $sn = 1;
        foreach ($grouped as $book) {
            $html .= '<tr>
                <td style="text-align:center;">' . $sn++ . '</td>
                <td>' . htmlspecialchars(substr($book['title'] ?? '', 0, 60)) . '</td>
                <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['publisher'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                <td style="text-align:center;">' . ($book['_quantity'] ?? 0) . '</td>
                <td style="text-align:center;">' . ($book['_available'] ?? 0) . '</td>
                <td style="text-align:right;">' . formatCurrency($book['price'] ?? 0) . '</td>
            </tr>';
        }
    } else {
        $html .= '<table>
            <thead><tr>
                <th style="text-align:center;">#</th>
                <th>Barcode</th>
                <th>Accession No</th>
                <th>Title</th>
                <th>Author</th>
                <th>Publisher</th>
                <th>ISBN</th>
                <th>Year</th>
                <th style="text-align:center;">Status</th>
            </tr></thead><tbody>';
        
        $sn = 1;
        foreach ($data as $book) {
            $status = ((int)($book['available'] ?? 0) > 0) ? 'Available' : 'Issued';
            $html .= '<tr>
                <td style="text-align:center;">' . $sn++ . '</td>
                <td>' . htmlspecialchars($book['barcode'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['accession_number'] ?? '') . '</td>
                <td>' . htmlspecialchars(substr($book['title'] ?? '', 0, 60)) . '</td>
                <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['publisher'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                <td style="text-align:center;">' . $status . '</td>
            </tr>';
        }
    }
    
    $html .= '</tbody></table>';
    
    $totalBooks = count($data);
    $totalQuantity = array_sum(array_column($data, 'quantity'));
    $totalAvailable = array_sum(array_column($data, 'available'));
    
    $html .= '<div class="summary">
        <strong>Summary:</strong> 
        Total Records: ' . $totalBooks . ' | 
        Total Copies: ' . $totalQuantity . ' | 
        Available: ' . $totalAvailable . ' | 
        Issued: ' . ($totalQuantity - $totalAvailable) . '
    </div>';
    
    $html .= '<div class="footer">' . htmlspecialchars($settings['report_footer_text'] ?? 'This is a system generated report') . '<br>&copy; ' . date('Y') . ' All rights reserved.</div>';
    $html .= '</body></html>';
    
    if ($pdfAvailable && class_exists('Mpdf\Mpdf')) {
        try {
            $paperSizeMap = ['A4' => 'A4', 'Letter' => 'Letter', 'Legal' => 'Legal', 'A3' => 'A3'];
            $pdfPaperSize = $paperSizeMap[$paperSize] ?? 'A4';
            $pdfOrientation = ($orientation === 'landscape') ? 'L' : 'P';
            
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $pdfPaperSize,
                'orientation' => $pdfOrientation,
                'default_font_size' => 9,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($title);
            $mpdf->SetAuthor($institutionName);
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.pdf"');
            $mpdf->Output('books_' . date('Y-m-d') . '.pdf', 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF export error: " . $e->getMessage());
        }
    }
    
    if ($pdfAvailable && class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.pdf"');
            echo $dompdf->output();
            exit;
        } catch (Exception $e) {
            error_log("DOMPDF export error: " . $e->getMessage());
        }
    }
    
    header('Content-Type: text/html');
    echo $html;
    echo '<div style="text-align:center;margin-top:20px;">
        <button onclick="window.print()" style="padding:10px 20px;background:#1e3c72;color:white;border:none;border-radius:5px;cursor:pointer;">Print PDF</button>
    </div>';
    exit;
}

// ==================== MARC21 EXPORT ====================

function exportBooksMARC($db, $data, $format = 'mrc') {
    global $marcAvailable;
    
    while (ob_get_level()) ob_end_clean();
    
    if (!$marcAvailable) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>MARC Export Error</h2>';
        echo '<p>MARC library not installed. Please run: <code>composer require pear/file_marc</code></p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
    
    if (empty($data)) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>No Books Selected</h2>';
        echo '<p>Please select at least one book to export.</p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
    
    $marcMapping = [
        'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
        'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
        'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
        'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
        'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
        'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
        'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
        'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'call_number' => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
        'category'    => ['tag' => '084', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
        'price'       => ['tag' => '020', 'subfield' => 'c', 'indicators' => [' ', ' ']],
        'series'      => ['tag' => '490', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'volume'      => ['tag' => '490', 'subfield' => 'v', 'indicators' => [' ', ' ']],
        'language'    => ['tag' => '008', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'summary'     => ['tag' => '520', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'contents'    => ['tag' => '505', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'issn'        => ['tag' => '022', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'ddc'         => ['tag' => '082', 'subfield' => 'a', 'indicators' => ['0', ' ']],
        'lcc'         => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        'accession_number' => ['tag' => '952', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    ];
    
    function dbToMarc($book, $mapping) {
        if (class_exists('Scriptotek\Marc\Record')) {
            $record = new \Scriptotek\Marc\Record();
            $record->leader = "     nam a22     i 4500";
            foreach ($mapping as $dbField => $marc) {
                if (empty($book[$dbField])) continue;
                $tag = $marc['tag'];
                $subfield = $marc['subfield'];
                $indicators = $marc['indicators'] ?? [' ', ' '];
                $field = $record->getField($tag);
                if (!$field) {
                    $field = $record->addField($tag, $indicators);
                }
                $field->addSubfield($subfield, $book[$dbField]);
            }
            return $record;
        } elseif (class_exists('File_MARC_Record')) {
            $record = new \File_MARC_Record();
            $record->setLeader("     nam a22     i 4500");
            foreach ($mapping as $dbField => $marc) {
                if (empty($book[$dbField])) continue;
                $tag = $marc['tag'];
                $subfield = $marc['subfield'];
                $indicators = $marc['indicators'] ?? [' ', ' '];
                $field = $record->getField($tag);
                if (!$field) {
                    $field = new \File_MARC_Data_Field($tag, $indicators);
                    $record->appendField($field);
                }
                $field->appendSubfield(new \File_MARC_Subfield($subfield, $book[$dbField]));
            }
            return $record;
        }
        throw new Exception("MARC library not available");
    }
    
    try {
        if (class_exists('Scriptotek\Marc\MarcCollection')) {
            $collection = new \Scriptotek\Marc\MarcCollection();
            foreach ($data as $book) {
                $record = dbToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXml();
                $filename = "books_export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "books_export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/marc";
            }
        } elseif (class_exists('File_MARC_Collection')) {
            $collection = new \File_MARC_Collection();
            foreach ($data as $book) {
                $record = dbToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXML();
                $filename = "books_export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "books_export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/octet-stream";
            }
        } else {
            throw new Exception("MARC collection class not found");
        }
        
        header("Content-Type: $contentType");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Length: " . strlen($content));
        header('Cache-Control: private, max-age=0, must-revalidate');
        echo $content;
        exit;
        
    } catch (Exception $e) {
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
        echo '<h2>MARC Export Error</h2>';
        echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '<p><a href="javascript:history.back()">Go Back</a></p>';
        echo '</body></html>';
        exit;
    }
}
?>