<?php
/**
 * Export Module Configuration
 * FIXED: Using hardcoded absolute path
 */

// Define BASE_PATH - HARDCODED for your setup
if (!defined('BASE_PATH')) {
    define('BASE_PATH', 'E:/xampp/htdocs/library-system');
}

// For debugging - uncomment to see the path
// echo "BASE_PATH: " . BASE_PATH . "<br>";
// exit;

// Include required files
require_once BASE_PATH . '/config/db.php';
require_once BASE_PATH . '/config/functions.php';
require_once BASE_PATH . '/config/auth.php';

// Require login for all export operations
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . '/index.php');
    exit;
}

// Define export directories
if (!defined('EXPORT_DIR')) {
    define('EXPORT_DIR', BASE_PATH . '/temp/exports/');
}
if (!is_dir(EXPORT_DIR)) {
    mkdir(EXPORT_DIR, 0777, true);
}

// Get database connection
$db = getDB();

// Check available libraries
$excelAvailable = false;
$pdfAvailable = false;
$marcAvailable = false;

$autoloadPath = BASE_PATH . '/vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        $excelAvailable = true;
    }
    if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) {
        $pdfAvailable = true;
    }
    if (class_exists('Scriptotek\Marc\MarcReader') || class_exists('File_MARC')) {
        $marcAvailable = true;
    }
}

// Helper functions
if (!function_exists('getInstitutionName')) {
    function getInstitutionName() {
        $institution = getInstitution();
        return $institution['name'] ?? 'Library';
    }
}

if (!function_exists('getCurrencySymbol')) {
    function getCurrencySymbol($code = null) {
        if ($code === null) {
            $settings = getSettings();
            $code = $settings['currency_code'] ?? 'INR';
        }
        $symbols = [
            'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
            'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
            'BHD' => '.د.ب', 'OMR' => '﷼'
        ];
        return $symbols[$code] ?? $code;
    }
}

if (!function_exists('formatCurrency')) {
    function formatCurrency($amount, $withSymbol = true) {
        $settings = getSettings();
        $symbol = getCurrencySymbol();
        $code = $settings['currency_code'] ?? 'INR';
        $position = $settings['currency_position'] ?? 'left';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        $formatted = number_format((float)$amount, $decimals);
        if ($withSymbol) {
            return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . $code;
        }
        return $formatted;
    }
}

if (!function_exists('formatDate')) {
    function formatDate($date, $format = 'd-m-Y') {
        if (empty($date) || $date === '0000-00-00') return '';
        try {
            return date($format, strtotime($date));
        } catch (Exception $e) {
            return $date;
        }
    }
}

if (!function_exists('resolveImageToBase64')) {
    function resolveImageToBase64($path) {
        if (empty($path)) return '';
        if (strpos($path, 'data:image') === 0) return $path;
        $fullPath = '';
        if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
            $fullPath = BASE_PATH . '/' . ltrim($path, '/');
        } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
            return '';
        } else {
            $fullPath = BASE_PATH . '/' . ltrim($path, '/');
        }
        if ($fullPath && file_exists($fullPath)) {
            $mime = mime_content_type($fullPath);
            $data = file_get_contents($fullPath);
            if ($data !== false) {
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    }
}

if (!function_exists('getLogoForExport')) {
    function getLogoForExport() {
        $settings = getSettings();
        $institution = getInstitution();
        
        $logoPaths = [
            $settings['library_logo'] ?? '',
            $settings['opac_header_logo'] ?? '',
            $settings['right_logo_path'] ?? '',
            $institution['logo_path'] ?? ''
        ];
        
        foreach ($logoPaths as $path) {
            if (!empty($path)) {
                $base64 = resolveImageToBase64($path);
                if ($base64) return $base64;
            }
        }
        return '';
    }
}
?>