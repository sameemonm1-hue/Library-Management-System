<?php
/**
 * Excel Export Handler
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$db = getDB();

// Get parameters
$mode = $_GET['export_mode'] ?? 'copies';
$category = $_GET['category'] ?? 'all';
$status = $_GET['status'] ?? 'all';
$location = $_GET['location'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'title';
$sort_order = $_GET['sort_order'] ?? 'ASC';

// Build query
$sql = "SELECT * FROM books WHERE 1=1";
$params = [];

if ($category !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
}
if ($status === 'available') {
    $sql .= " AND available > 0";
} elseif ($status === 'unavailable') {
    $sql .= " AND available = 0";
} elseif ($status === 'lowstock') {
    $sql .= " AND available > 0 AND available <= 2";
}
if (!empty($location)) {
    $sql .= " AND (location LIKE ? OR current_location LIKE ? OR shelf LIKE ? OR branch LIKE ?)";
    $like = "%$location%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}
if (!empty($year_from)) {
    $sql .= " AND year >= ?";
    $params[] = $year_from;
}
if (!empty($year_to)) {
    $sql .= " AND year <= ?";
    $params[] = $year_to;
}
if ($price_min !== '') {
    $sql .= " AND price >= ?";
    $params[] = (float)$price_min;
}
if ($price_max !== '') {
    $sql .= " AND price <= ?";
    $params[] = (float)$price_max;
}

$allowed_sort = ['title','author','publisher','category','year','price','barcode','available','quantity'];
if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
$sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
$sql .= " ORDER BY $sort_by $sort_order";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$data = $stmt->fetchAll();

exportBooksExcel($db, $data, $mode, 'Books Export');
?>