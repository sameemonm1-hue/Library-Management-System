<?php
/**
 * MARC Authority Control
 * 
 * Features:
 * - Manage authorities (personal names, corporate names, subjects, genre/form)
 * - Search local authorities
 * - Fetch from LCNAF (id.loc.gov) via JSON API
 * - Import authority records from LCNAF
 * - Link authorities to MARC fields (100, 700, 600, 610, 650, 710, etc.)
 * - Show which books use an authority
 * - Export as MARCXML
 * 
 * Tables:
 * - authorities (id, authority_type, heading, authorized_form, variant_forms, lccn, source, created_at, updated_at)
 * - book_authorities (book_id, authority_id, marc_tag, marc_ind1, marc_ind2, subfield_code)
 * 
 * Dependencies:
 * - config/db.php, config/functions.php
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// Ensure authorities table exists
$db->exec("CREATE TABLE IF NOT EXISTS authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    authority_type TEXT NOT NULL CHECK(authority_type IN ('personal','corporate','subject','genre','uniform_title')),
    heading TEXT NOT NULL,
    authorized_form TEXT,
    variant_forms TEXT,
    lccn TEXT,
    source TEXT DEFAULT 'local',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
)");

$db->exec("CREATE TABLE IF NOT EXISTS book_authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    authority_id INTEGER NOT NULL,
    marc_tag TEXT NOT NULL,
    marc_ind1 TEXT DEFAULT ' ',
    marc_ind2 TEXT DEFAULT ' ',
    subfield_code TEXT DEFAULT 'a',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (authority_id) REFERENCES authorities(id) ON DELETE CASCADE
)");

// Add indexes
$db->exec("CREATE INDEX IF NOT EXISTS idx_authorities_heading ON authorities(heading)");
$db->exec("CREATE INDEX IF NOT EXISTS idx_authorities_type ON authorities(authority_type)");
$db->exec("CREATE INDEX IF NOT EXISTS idx_book_authorities_book ON book_authorities(book_id)");
$db->exec("CREATE INDEX IF NOT EXISTS idx_book_authorities_authority ON book_authorities(authority_id)");

// ==================== AJAX HANDLERS ====================
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    $action = $_GET['ajax'];
    
    // Search local authorities
    if ($action === 'search') {
        $q = trim($_GET['q'] ?? '');
        $type = $_GET['type'] ?? '';
        if (strlen($q) < 2) {
            echo json_encode([]);
            exit;
        }
        $sql = "SELECT * FROM authorities WHERE heading LIKE ?";
        $params = ["%$q%"];
        if ($type && $type !== 'all') {
            $sql .= " AND authority_type = ?";
            $params[] = $type;
        }
        $sql .= " ORDER BY heading LIMIT 20";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        echo json_encode($results);
        exit;
    }
    
    // Fetch from LCNAF (id.loc.gov)
    if ($action === 'lcnaf') {
        $q = trim($_GET['q'] ?? '');
        $type = $_GET['type'] ?? 'personal';
        if (strlen($q) < 2) {
            echo json_encode([]);
            exit;
        }
        // Map authority type to LCNAF format
        $lcType = [
            'personal' => 'names',
            'corporate' => 'names',
            'subject' => 'subjects',
            'genre' => 'genreForm',
            'uniform_title' => 'titles'
        ];
        $format = $lcType[$type] ?? 'names';
        $url = "https://id.loc.gov/search/?q=" . urlencode($q) . "&format=application/json&q=scheme:http%3A%2F%2Fid.loc.gov%2Fauthorities%2F{$format}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || !$response) {
            echo json_encode(['error' => 'Failed to fetch from LCNAF']);
            exit;
        }
        
        $data = json_decode($response, true);
        $results = [];
        if (isset($data['results'])) {
            foreach ($data['results'] as $item) {
                $heading = $item['title'] ?? '';
                $lccn = '';
                if (preg_match('/\/(\d+)$/', $item['id'] ?? '', $matches)) {
                    $lccn = $matches[1];
                }
                $results[] = [
                    'heading' => $heading,
                    'lccn' => $lccn,
                    'uri' => $item['id'] ?? '',
                    'type' => $type
                ];
            }
        }
        echo json_encode($results);
        exit;
    }
    
    // Import from LCNAF (create local authority)
    if ($action === 'import') {
        $heading = trim($_POST['heading'] ?? '');
        $lccn = trim($_POST['lccn'] ?? '');
        $type = $_POST['type'] ?? 'personal';
        $uri = trim($_POST['uri'] ?? '');
        
        if (empty($heading)) {
            echo json_encode(['error' => 'Heading is required']);
            exit;
        }
        
        // Check if already exists
        $check = $db->prepare("SELECT id FROM authorities WHERE heading = ?");
        $check->execute([$heading]);
        if ($check->fetch()) {
            echo json_encode(['error' => 'Authority already exists locally']);
            exit;
        }
        
        $stmt = $db->prepare("INSERT INTO authorities (authority_type, heading, lccn, source) VALUES (?, ?, ?, 'lcnaf')");
        $stmt->execute([$type, $heading, $lccn]);
        $id = $db->lastInsertId();
        echo json_encode(['success' => true, 'id' => $id, 'heading' => $heading]);
        exit;
    }
    
    // Add new authority manually
    if ($action === 'add') {
        $type = $_POST['type'] ?? '';
        $heading = trim($_POST['heading'] ?? '');
        $authorizedForm = trim($_POST['authorized_form'] ?? '');
        $variantForms = trim($_POST['variant_forms'] ?? '');
        $lccn = trim($_POST['lccn'] ?? '');
        
        if (!$type || !$heading) {
            echo json_encode(['error' => 'Type and heading are required']);
            exit;
        }
        
        $stmt = $db->prepare("INSERT INTO authorities (authority_type, heading, authorized_form, variant_forms, lccn, source) VALUES (?, ?, ?, ?, ?, 'local')");
        $stmt->execute([$type, $heading, $authorizedForm, $variantForms, $lccn]);
        echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
        exit;
    }
    
    // Update authority
    if ($action === 'update') {
        $id = (int)$_POST['id'];
        $type = $_POST['type'] ?? '';
        $heading = trim($_POST['heading'] ?? '');
        $authorizedForm = trim($_POST['authorized_form'] ?? '');
        $variantForms = trim($_POST['variant_forms'] ?? '');
        $lccn = trim($_POST['lccn'] ?? '');
        
        if (!$id || !$type || !$heading) {
            echo json_encode(['error' => 'Invalid data']);
            exit;
        }
        
        $stmt = $db->prepare("UPDATE authorities SET authority_type = ?, heading = ?, authorized_form = ?, variant_forms = ?, lccn = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$type, $heading, $authorizedForm, $variantForms, $lccn, $id]);
        echo json_encode(['success' => true]);
        exit;
    }
    
    // Delete authority
    if ($action === 'delete') {
        $id = (int)$_GET['id'];
        // Check if linked to any books
        $check = $db->prepare("SELECT COUNT(*) FROM book_authorities WHERE authority_id = ?");
        $check->execute([$id]);
        $count = $check->fetchColumn();
        if ($count > 0) {
            echo json_encode(['error' => "Cannot delete: linked to $count book(s)"]);
            exit;
        }
        $db->prepare("DELETE FROM authorities WHERE id = ?")->execute([$id]);
        echo json_encode(['success' => true]);
        exit;
    }
    
    // Get books linked to an authority
    if ($action === 'books') {
        $id = (int)$_GET['id'];
        $stmt = $db->prepare("SELECT b.*, ba.marc_tag FROM book_authorities ba JOIN books b ON ba.book_id = b.id WHERE ba.authority_id = ? LIMIT 50");
        $stmt->execute([$id]);
        $books = $stmt->fetchAll();
        echo json_encode($books);
        exit;
    }
    
    echo json_encode(['error' => 'Invalid action']);
    exit;
}

// ==================== MAIN PAGE ====================
// Get all authorities (paginated)
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 30;
$offset = ($page - 1) * $limit;
$typeFilter = $_GET['type'] ?? '';
$search = trim($_GET['search'] ?? '');

$sql = "SELECT * FROM authorities WHERE 1=1";
$params = [];
if ($typeFilter && $typeFilter !== 'all') {
    $sql .= " AND authority_type = ?";
    $params[] = $typeFilter;
}
if ($search) {
    $sql .= " AND (heading LIKE ? OR authorized_form LIKE ? OR lccn LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}
$countStmt = $db->prepare($sql);
$countStmt->execute($params);
$total = $countStmt->rowCount();

$sql .= " ORDER BY heading LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$stmt = $db->prepare($sql);
$stmt->execute($params);
$authorities = $stmt->fetchAll();

$totalPages = ceil($total / $limit);

renderHeader('MARC Authority Control');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MARC Authority Control</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .authority-row:hover { background-color: #f8f9fa; cursor: pointer; }
        .modal-lg { max-width: 800px; }
        .lcnaf-result { cursor: pointer; transition: background 0.2s; }
        .lcnaf-result:hover { background: #e9ecef; }
        .badge-type { font-size: 11px; padding: 4px 8px; }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-tag"></i> MARC Authority Control</h2>
        <div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="fas fa-plus"></i> New Authority
            </button>
            <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#lcnafModal">
                <i class="fas fa-cloud-download-alt"></i> Import from LCNAF
            </button>
            <a href="../admin/books.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Books</a>
        </div>
    </div>
    
    <!-- Filter Bar -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Authority Type</label>
                    <select name="type" class="form-select" onchange="this.form.submit()">
                        <option value="all">All Types</option>
                        <option value="personal" <?= $typeFilter === 'personal' ? 'selected' : '' ?>>Personal Name</option>
                        <option value="corporate" <?= $typeFilter === 'corporate' ? 'selected' : '' ?>>Corporate Name</option>
                        <option value="subject" <?= $typeFilter === 'subject' ? 'selected' : '' ?>>Subject Heading</option>
                        <option value="genre" <?= $typeFilter === 'genre' ? 'selected' : '' ?>>Genre/Form</option>
                        <option value="uniform_title" <?= $typeFilter === 'uniform_title' ? 'selected' : '' ?>>Uniform Title</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($search) ?>" placeholder="Heading, authorized form, LCCN...">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">Filter</button>
                    <a href="authority_control.php" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Authorities Table -->
    <div class="card">
        <div class="card-header bg-white fw-bold">
            <i class="fas fa-list"></i> Authorities (<?= $total ?>)
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Type</th>
                            <th>Heading</th>
                            <th>Authorized Form</th>
                            <th>LCCN</th>
                            <th>Source</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($authorities)): ?>
                            <tr><td colspan="6" class="text-center py-4">No authorities found. Create one or import from LCNAF.</div></tr>
                        <?php else: ?>
                            <?php foreach ($authorities as $auth): ?>
                            <tr class="authority-row" data-id="<?= $auth['id'] ?>" onclick="showDetails(<?= $auth['id'] ?>)">
                                <td>
                                    <?php
                                    $typeLabels = [
                                        'personal' => '<span class="badge bg-primary badge-type"><i class="fas fa-user"></i> Personal</span>',
                                        'corporate' => '<span class="badge bg-secondary badge-type"><i class="fas fa-building"></i> Corporate</span>',
                                        'subject' => '<span class="badge bg-success badge-type"><i class="fas fa-tag"></i> Subject</span>',
                                        'genre' => '<span class="badge bg-warning badge-type"><i class="fas fa-film"></i> Genre</span>',
                                        'uniform_title' => '<span class="badge bg-info badge-type"><i class="fas fa-book"></i> Uniform Title</span>',
                                    ];
                                    echo $typeLabels[$auth['authority_type']] ?? $auth['authority_type'];
                                    ?>
                                </td>
                                <td><strong><?= htmlspecialchars($auth['heading']) ?></strong></td>
                                <td><?= htmlspecialchars($auth['authorized_form'] ?? '-') ?></td>
                                <td><code><?= htmlspecialchars($auth['lccn'] ?? '-') ?></code></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($auth['source']) ?></span></td>
                                <td>
                                    <div class="btn-group btn-group-sm" onclick="event.stopPropagation()">
                                        <button class="btn btn-warning" onclick="editAuthority(<?= $auth['id'] ?>, '<?= addslashes($auth['authority_type']) ?>', '<?= addslashes($auth['heading']) ?>', '<?= addslashes($auth['authorized_form'] ?? '') ?>', '<?= addslashes($auth['variant_forms'] ?? '') ?>', '<?= addslashes($auth['lccn'] ?? '') ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-danger" onclick="deleteAuthority(<?= $auth['id'] ?>, '<?= addslashes($auth['heading']) ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                <a class="page-link" href="?page=<?= $page-1 ?>&type=<?= urlencode($typeFilter) ?>&search=<?= urlencode($search) ?>">«</a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>&type=<?= urlencode($typeFilter) ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                <a class="page-link" href="?page=<?= $page+1 ?>&type=<?= urlencode($typeFilter) ?>&search=<?= urlencode($search) ?>">»</a>
            </li>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="authorityModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalTitle">Add Authority</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="authorityForm">
                    <input type="hidden" id="auth_id" name="id" value="0">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Authority Type *</label>
                            <select id="auth_type" name="type" class="form-select" required>
                                <option value="personal">Personal Name</option>
                                <option value="corporate">Corporate Name</option>
                                <option value="subject">Subject Heading</option>
                                <option value="genre">Genre/Form</option>
                                <option value="uniform_title">Uniform Title</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">LCCN (optional)</label>
                            <input type="text" id="auth_lccn" name="lccn" class="form-control" placeholder="e.g., n79006904">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Heading (authorized form) *</label>
                            <input type="text" id="auth_heading" name="heading" class="form-control" required>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Authorized Form (display)</label>
                            <input type="text" id="auth_authorized" name="authorized_form" class="form-control" placeholder="Same as heading if not different">
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Variant Forms (separated by |)</label>
                            <input type="text" id="auth_variant" name="variant_forms" class="form-control" placeholder="e.g., Smith, John|John Smith">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveAuthorityBtn">Save Authority</button>
            </div>
        </div>
    </div>
</div>

<!-- LCNAF Import Modal -->
<div class="modal fade" id="lcnafModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-cloud-download-alt"></i> Import from LCNAF (Library of Congress)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Authority Type</label>
                        <select id="lcnaf_type" class="form-select">
                            <option value="personal">Personal Name</option>
                            <option value="corporate">Corporate Name</option>
                            <option value="subject">Subject Heading</option>
                            <option value="genre">Genre/Form</option>
                            <option value="uniform_title">Uniform Title</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Search Term</label>
                        <div class="input-group">
                            <input type="text" id="lcnaf_query" class="form-control" placeholder="Enter name or subject...">
                            <button class="btn btn-primary" onclick="searchLCNAF()">Search</button>
                        </div>
                    </div>
                </div>
                <div id="lcnaf_results" style="max-height: 400px; overflow-y: auto;">
                    <div class="text-center text-muted py-4">Enter a search term above</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Authority Details Modal -->
<div class="modal fade" id="detailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title">Authority Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailsContent">
                <div class="text-center py-4">Loading...</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ==================== CRUD Functions ====================
function editAuthority(id, type, heading, authorized, variant, lccn) {
    document.getElementById('modalTitle').innerText = 'Edit Authority';
    document.getElementById('auth_id').value = id;
    document.getElementById('auth_type').value = type;
    document.getElementById('auth_heading').value = heading;
    document.getElementById('auth_authorized').value = authorized;
    document.getElementById('auth_variant').value = variant;
    document.getElementById('auth_lccn').value = lccn;
    new bootstrap.Modal(document.getElementById('authorityModal')).show();
}

function resetForm() {
    document.getElementById('modalTitle').innerText = 'Add Authority';
    document.getElementById('auth_id').value = '0';
    document.getElementById('auth_type').value = 'personal';
    document.getElementById('auth_heading').value = '';
    document.getElementById('auth_authorized').value = '';
    document.getElementById('auth_variant').value = '';
    document.getElementById('auth_lccn').value = '';
}

document.getElementById('saveAuthorityBtn').onclick = function() {
    let id = document.getElementById('auth_id').value;
    let type = document.getElementById('auth_type').value;
    let heading = document.getElementById('auth_heading').value.trim();
    let authorized = document.getElementById('auth_authorized').value.trim();
    let variant = document.getElementById('auth_variant').value.trim();
    let lccn = document.getElementById('auth_lccn').value.trim();
    
    if (!heading) { alert('Heading is required'); return; }
    
    let formData = new FormData();
    if (id && id !== '0') {
        formData.append('ajax', 'update');
        formData.append('id', id);
    } else {
        formData.append('ajax', 'add');
    }
    formData.append('type', type);
    formData.append('heading', heading);
    formData.append('authorized_form', authorized);
    formData.append('variant_forms', variant);
    formData.append('lccn', lccn);
    
    fetch(window.location.href, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.error || 'Error saving authority');
            }
        })
        .catch(err => alert('Network error: ' + err.message));
};

function deleteAuthority(id, heading) {
    if (confirm(`Delete authority "${heading}"? This action cannot be undone.`)) {
        fetch(window.location.href + '?ajax=delete&id=' + id)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.error || 'Cannot delete authority');
                }
            })
            .catch(err => alert('Network error'));
    }
}

// ==================== Show Authority Details ====================
function showDetails(id) {
    let modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    let content = document.getElementById('detailsContent');
    content.innerHTML = '<div class="text-center py-4"><div class="spinner-border"></div> Loading...</div>';
    modal.show();
    
    // Fetch authority details
    fetch(`authority_control.php?ajax=get&id=${id}`)
        .then(r => r.json())
        .then(auth => {
            if (auth.error) {
                content.innerHTML = '<div class="alert alert-danger">' + auth.error + '</div>';
                return;
            }
            // Fetch linked books
            fetch(`authority_control.php?ajax=books&id=${id}`)
                .then(r => r.json())
                .then(books => {
                    let booksHtml = '';
                    if (books.length) {
                        booksHtml = '<h6>Linked Books:</h6><ul class="list-group">';
                        books.forEach(book => {
                            booksHtml += `<li class="list-group-item d-flex justify-content-between align-items-center">
                                ${escapeHtml(book.title)} (${book.barcode})
                                <span class="badge bg-secondary">MARC ${book.marc_tag}</span>
                            </li>`;
                        });
                        booksHtml += '</ul>';
                    } else {
                        booksHtml = '<p class="text-muted">No books linked to this authority.</p>';
                    }
                    
                    content.innerHTML = `
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Type:</strong> ${auth.authority_type}</p>
                                <p><strong>Heading:</strong> ${escapeHtml(auth.heading)}</p>
                                <p><strong>Authorized Form:</strong> ${escapeHtml(auth.authorized_form || '-')}</p>
                                <p><strong>Variant Forms:</strong> ${escapeHtml(auth.variant_forms || '-')}</p>
                                <p><strong>LCCN:</strong> <code>${escapeHtml(auth.lccn || '-')}</code></p>
                                <p><strong>Source:</strong> ${escapeHtml(auth.source)}</p>
                                <p><strong>Created:</strong> ${auth.created_at}</p>
                            </div>
                            <div class="col-md-6">
                                ${booksHtml}
                            </div>
                        </div>
                    `;
                });
        })
        .catch(err => {
            content.innerHTML = '<div class="alert alert-danger">Error loading details</div>';
        });
}

// ==================== LCNAF Search ====================
function searchLCNAF() {
    let query = document.getElementById('lcnaf_query').value.trim();
    let type = document.getElementById('lcnaf_type').value;
    if (query.length < 2) {
        alert('Please enter at least 2 characters');
        return;
    }
    let resultsDiv = document.getElementById('lcnaf_results');
    resultsDiv.innerHTML = '<div class="text-center py-4"><div class="spinner-border"></div> Searching...</div>';
    
    fetch(`authority_control.php?ajax=lcnaf&q=${encodeURIComponent(query)}&type=${type}`)
        .then(r => r.json())
        .then(data => {
            if (data.error) {
                resultsDiv.innerHTML = '<div class="alert alert-danger">' + data.error + '</div>';
                return;
            }
            if (!data.length) {
                resultsDiv.innerHTML = '<div class="text-center text-muted py-4">No results found</div>';
                return;
            }
            let html = '<div class="list-group">';
            data.forEach(item => {
                html += `
                    <div class="list-group-item list-group-item-action lcnaf-result" onclick="importFromLCNAF('${escapeHtml(item.heading)}', '${escapeHtml(item.lccn)}', '${type}', '${escapeHtml(item.uri)}')">
                        <strong>${escapeHtml(item.heading)}</strong>
                        ${item.lccn ? `<br><small class="text-muted">LCCN: ${escapeHtml(item.lccn)}</small>` : ''}
                    </div>
                `;
            });
            html += '</div>';
            resultsDiv.innerHTML = html;
        })
        .catch(err => {
            resultsDiv.innerHTML = '<div class="alert alert-danger">Network error</div>';
        });
}

function importFromLCNAF(heading, lccn, type, uri) {
    if (!confirm(`Import "${heading}" as a new authority?`)) return;
    let formData = new FormData();
    formData.append('ajax', 'import');
    formData.append('heading', heading);
    formData.append('lccn', lccn);
    formData.append('type', type);
    formData.append('uri', uri);
    
    fetch(window.location.href, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert(`Imported: ${data.heading}`);
                location.reload();
            } else {
                alert(data.error || 'Import failed');
            }
        })
        .catch(err => alert('Network error'));
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}

// Reset form when modal is closed
document.getElementById('authorityModal').addEventListener('hidden.bs.modal', resetForm);
</script>

<?php renderFooter(); ?>