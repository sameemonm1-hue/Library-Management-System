<?php
/**
 * MARC21 Editor for Books – Full Featured
 * 
 * Features:
 * - Edit all MARC fields (001-999) including leader and control fields
 * - Add/delete fields and subfields dynamically
 * - Validate MARC structure against basic rules
 * - Preview MARC as JSON and formatted XML
 * - Fetch metadata from external Z39.50 targets
 * - Store marcxml and marc_json in database
 * 
 * Dependencies:
 * - config/MarcConverter.php
 * - includes/Z3950ClientImproved.php (optional)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/MarcConverter.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$bookId = (int)($_GET['id'] ?? 0);
$message = '';
$error = '';

// Fetch book details
$stmt = $db->prepare("SELECT id, barcode, title, marcxml, marc_json FROM books WHERE id = ?");
$stmt->execute([$bookId]);
$book = $stmt->fetch();

if (!$book) {
    header('Location: ../admin/books.php');
    exit;
}

// Initialize MarcConverter (already loaded)
MarcConverter::init();

// Parse existing MARCXML
$currentFields = [];
$leader = '00000nam a2200000 a 4500';
if (!empty($book['marcxml'])) {
    $parsed = MarcConverter::marcXmlToArray($book['marcxml']);
    if (isset($parsed['LEADER'])) {
        $leader = $parsed['LEADER'][0]['subfields']['a'] ?? $leader;
        unset($parsed['LEADER']);
    }
    $currentFields = $parsed;
}

// Handle Z39.50 fetch (AJAX)
if (isset($_GET['z3950_fetch']) && isset($_GET['isbn'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['error' => 'Invalid ISBN']);
        exit;
    }
    require_once __DIR__ . '/../includes/Z3950ClientImproved.php';
    $client = new Z3950ClientImproved();
    $result = $client->fetchByIsbn($isbn);
    if ($result && !empty($result['marcxml'])) {
        // Convert to array and merge with existing fields? Or replace?
        $newFields = MarcConverter::marcXmlToArray($result['marcxml']);
        $newLeader = $newFields['LEADER'][0]['subfields']['a'] ?? $leader;
        unset($newFields['LEADER']);
        
        echo json_encode([
            'success' => true,
            'leader' => $newLeader,
            'fields' => $newFields,
            'marcxml' => $result['marcxml'],
            'title' => $result['title']
        ]);
    } else {
        echo json_encode(['error' => 'No record found for this ISBN']);
    }
    exit;
}

// Handle form submission (update MARC)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_marc'])) {
    // Get leader
    $leader = trim($_POST['leader'] ?? '00000nam a2200000 a 4500');
    
    // Process control fields (001-009)
    $controlFields = [];
    for ($i = 1; $i <= 9; $i++) {
        $tag = '00' . $i;
        $value = trim($_POST["control_{$tag}"] ?? '');
        if ($value !== '') {
            $controlFields[$tag] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $value]]];
        }
    }
    
    // Process data fields
    $updatedFields = [];
    if (isset($_POST['field_tag'])) {
        foreach ($_POST['field_tag'] as $idx => $tag) {
            $tag = strtoupper(trim($tag));
            if (empty($tag) || $tag < '010') continue; // skip control fields handled above
            $ind1 = $_POST['field_ind1'][$idx] ?? ' ';
            $ind2 = $_POST['field_ind2'][$idx] ?? ' ';
            $subfields = [];
            $codes = $_POST["subfield_code_{$idx}"] ?? [];
            $values = $_POST["subfield_value_{$idx}"] ?? [];
            foreach ($codes as $sfIdx => $code) {
                $code = trim($code);
                $value = trim($values[$sfIdx] ?? '');
                if ($code !== '' && $value !== '') {
                    $subfields[$code] = $value;
                }
            }
            if (!empty($subfields)) {
                $updatedFields[$tag][] = ['ind1' => $ind1, 'ind2' => $ind2, 'subfields' => $subfields];
            }
        }
    }
    
    // Process new fields added dynamically
    if (isset($_POST['new_tag']) && !empty($_POST['new_tag'][0])) {
        foreach ($_POST['new_tag'] as $idx => $tag) {
            $tag = strtoupper(trim($tag));
            if (empty($tag) || $tag < '010') continue;
            $ind1 = $_POST['new_ind1'][$idx] ?? ' ';
            $ind2 = $_POST['new_ind2'][$idx] ?? ' ';
            $subfields = [];
            $codes = $_POST["new_subfield_code_{$idx}"] ?? [];
            $values = $_POST["new_subfield_value_{$idx}"] ?? [];
            foreach ($codes as $sfIdx => $code) {
                $code = trim($code);
                $value = trim($values[$sfIdx] ?? '');
                if ($code !== '' && $value !== '') {
                    $subfields[$code] = $value;
                }
            }
            if (!empty($subfields)) {
                $updatedFields[$tag][] = ['ind1' => $ind1, 'ind2' => $ind2, 'subfields' => $subfields];
            }
        }
    }
    
    // Merge control fields and data fields
    $allFields = array_merge($controlFields, $updatedFields);
    
    // Convert to MARCXML
    $marcxml = MarcConverter::arrayToMarcXml($allFields, $leader);
    
    // Validate
    $validationErrors = MarcConverter::validate($marcxml);
    if (!empty($validationErrors)) {
        $error = '<div class="alert alert-warning"><strong>Validation Warnings:</strong><ul>';
        foreach ($validationErrors as $err) {
            $error .= '<li>' . htmlspecialchars($err) . '</li>';
        }
        $error .= '</ul></div>';
    }
    
    // Save to database
    $updateStmt = $db->prepare("UPDATE books SET marcxml = ?, marc_json = ?, title = ? WHERE id = ?");
    $updateStmt->execute([$marcxml, json_encode($allFields), $_POST['title'] ?? $book['title'], $bookId]);
    $message = '<div class="alert alert-success">MARC record updated successfully.</div>';
    
    // Refresh data
    $book['marcxml'] = $marcxml;
    $book['marc_json'] = json_encode($allFields);
    $book['title'] = $_POST['title'] ?? $book['title'];
    $currentFields = $allFields;
}

// Delete a field via GET
if (isset($_GET['delete_field']) && isset($_GET['tag']) && isset($_GET['idx'])) {
    $delTag = $_GET['tag'];
    $delIdx = (int)$_GET['idx'];
    if (isset($currentFields[$delTag][$delIdx])) {
        unset($currentFields[$delTag][$delIdx]);
        $currentFields[$delTag] = array_values($currentFields[$delTag]);
        if (empty($currentFields[$delTag])) unset($currentFields[$delTag]);
        $marcxml = MarcConverter::arrayToMarcXml($currentFields, $leader);
        $db->prepare("UPDATE books SET marcxml = ?, marc_json = ? WHERE id = ?")->execute([$marcxml, json_encode($currentFields), $bookId]);
        $message = '<div class="alert alert-success">Field deleted.</div>';
        header("Location: marc_editor.php?id=$bookId");
        exit;
    }
}

// Generate JSON preview
$jsonPreview = !empty($book['marc_json']) ? $book['marc_json'] : json_encode($currentFields, JSON_PRETTY_PRINT);
$xmlPreview = !empty($book['marcxml']) ? htmlspecialchars($book['marcxml']) : '';

renderHeader('MARC21 Editor');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MARC21 Editor: <?= htmlspecialchars($book['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .field-group {
            border: 1px solid #dee2e6;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
        }
        .card-header {
            background-color: #f8f9fa;
        }
        .subfield-row {
            margin-bottom: 8px;
        }
        .control-field-group {
            background: #f0f2f5;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .json-preview, .xml-preview {
            max-height: 400px;
            overflow-y: auto;
            background: #f8f9fa;
            padding: 10px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 12px;
        }
        .nav-tabs .nav-link {
            color: #495057;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            color: #0d6efd;
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-tag"></i> MARC21 Editor: <?= htmlspecialchars($book['title']) ?></h2>
        <div>
            <a href="../admin/books.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Books</a>
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#z3950Modal">
                <i class="fas fa-search"></i> Z39.50 Fetch
            </button>
        </div>
    </div>
    
    <?= $message ?>
    <?= $error ?>
    
    <div class="row">
        <div class="col-md-8">
            <form method="post" id="marcForm">
                <!-- Basic Book Info -->
                <div class="card mb-3">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-book"></i> Basic Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label class="form-label">Title (will be updated from MARC)</label>
                                <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>">
                            </div>
                            <div class="col-md-6 mb-2">
                                <label class="form-label">Barcode (readonly)</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($book['barcode']) ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Leader -->
                <div class="card mb-3">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0"><i class="fas fa-cog"></i> Leader (008)</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" name="leader" class="form-control font-monospace" value="<?= htmlspecialchars($leader) ?>" maxlength="24">
                        <small class="text-muted">24‑character leader (e.g., 00000nam a2200000 a 4500)</small>
                    </div>
                </div>
                
                <!-- Control Fields (001-009) -->
                <div class="card mb-3">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0"><i class="fas fa-barcode"></i> Control Fields (001-009)</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php for ($i = 1; $i <= 9; $i++): 
                                $tag = '00' . $i;
                                $value = '';
                                if (isset($currentFields[$tag][0]['subfields']['a'])) {
                                    $value = $currentFields[$tag][0]['subfields']['a'];
                                }
                            ?>
                            <div class="col-md-4 mb-2">
                                <label class="form-label">Field <?= $tag ?></label>
                                <input type="text" name="control_<?= $tag ?>" class="form-control" value="<?= htmlspecialchars($value) ?>">
                            </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Data Fields -->
                <div class="card mb-3">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <span><i class="fas fa-table"></i> Data Fields (010-999)</span>
                        <button type="button" class="btn btn-sm btn-light" onclick="addNewField()"><i class="fas fa-plus"></i> Add Field</button>
                    </div>
                    <div class="card-body">
                        <div id="fieldsContainer">
                            <?php 
                            $fieldIdx = 0;
                            foreach ($currentFields as $tag => $occurrences):
                                foreach ($occurrences as $occIdx => $field):
                                    if ($tag < '010') continue; // skip control fields
                            ?>
                            <div class="field-group card mb-3" data-field-index="<?= $fieldIdx ?>">
                                <div class="card-header bg-light">
                                    <div class="row g-2 align-items-end">
                                        <div class="col-md-2">
                                            <label class="form-label small">Tag</label>
                                            <input type="text" name="field_tag[<?= $fieldIdx ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($tag) ?>" placeholder="e.g., 245" required>
                                        </div>
                                        <div class="col-md-1">
                                            <label class="form-label small">Ind1</label>
                                            <input type="text" name="field_ind1[<?= $fieldIdx ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($field['ind1'] ?? ' ') ?>" maxlength="1">
                                        </div>
                                        <div class="col-md-1">
                                            <label class="form-label small">Ind2</label>
                                            <input type="text" name="field_ind2[<?= $fieldIdx ?>]" class="form-control form-control-sm" value="<?= htmlspecialchars($field['ind2'] ?? ' ') ?>" maxlength="1">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label small">Subfields</label>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <button type="button" class="btn btn-sm btn-danger" onclick="deleteField(this)"><i class="fas fa-trash"></i> Delete Field</button>
                                            <button type="button" class="btn btn-sm btn-success" onclick="addSubfield(this)"><i class="fas fa-plus"></i> Add Subfield</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="subfields-container">
                                        <?php foreach ($field['subfields'] as $code => $value): ?>
                                        <div class="row g-2 mb-2 subfield-row">
                                            <div class="col-md-2">
                                                <input type="text" name="subfield_code_<?= $fieldIdx ?>[]" class="form-control form-control-sm" placeholder="Code" value="<?= htmlspecialchars($code) ?>" required>
                                            </div>
                                            <div class="col-md-9">
                                                <input type="text" name="subfield_value_<?= $fieldIdx ?>[]" class="form-control form-control-sm" placeholder="Value" value="<?= htmlspecialchars($value) ?>" required>
                                            </div>
                                            <div class="col-md-1">
                                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeSubfield(this)"><i class="fas fa-minus-circle"></i></button>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            <?php 
                                    $fieldIdx++;
                                endforeach;
                            endforeach; 
                            ?>
                        </div>
                        
                        <div id="newFieldsContainer"></div>
                    </div>
                </div>
                
                <div class="text-center mt-3">
                    <button type="submit" name="update_marc" class="btn btn-primary btn-lg px-5"><i class="fas fa-save"></i> Save MARC Record</button>
                    <a href="../admin/books.php" class="btn btn-secondary btn-lg px-5">Cancel</a>
                </div>
            </form>
        </div>
        
        <!-- Right Column: Preview -->
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-eye"></i> Preview</h5>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="previewTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="json-tab" data-bs-toggle="tab" data-bs-target="#json" type="button" role="tab">JSON</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="xml-tab" data-bs-toggle="tab" data-bs-target="#xml" type="button" role="tab">MARCXML</button>
                        </li>
                    </ul>
                    <div class="tab-content mt-3">
                        <div class="tab-pane fade show active" id="json" role="tabpanel">
                            <pre class="json-preview" id="jsonPreview"><?= htmlspecialchars($jsonPreview) ?></pre>
                        </div>
                        <div class="tab-pane fade" id="xml" role="tabpanel">
                            <pre class="xml-preview" id="xmlPreview"><?= $xmlPreview ?></pre>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> MARC Field Help</h5>
                </div>
                <div class="card-body small">
                    <ul class="list-unstyled">
                        <li><strong>020</strong> – ISBN</li>
                        <li><strong>100</strong> – Main Author</li>
                        <li><strong>245</strong> – Title (a = title, b = subtitle)</li>
                        <li><strong>250</strong> – Edition</li>
                        <li><strong>260/264</strong> – Publisher (b = name, c = year)</li>
                        <li><strong>300</strong> – Physical description (pages)</li>
                        <li><strong>490</strong> – Series statement</li>
                        <li><strong>520</strong> – Summary/abstract</li>
                        <li><strong>650</strong> – Subject heading</li>
                        <li><strong>700</strong> – Added author</li>
                        <li><strong>856</strong> – Electronic location (URL)</li>
                    </ul>
                    <hr>
                    <a href="https://www.loc.gov/marc/bibliographic/" target="_blank" class="btn btn-sm btn-outline-secondary w-100">MARC21 Reference →</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Z39.50 Fetch Modal -->
<div class="modal fade" id="z3950Modal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-search"></i> Fetch from Z39.50 by ISBN</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">ISBN</label>
                    <div class="input-group">
                        <input type="text" id="z3950_isbn" class="form-control" placeholder="978..." required>
                        <button class="btn btn-primary" id="z3950_fetch_btn" onclick="fetchZ3950()">Fetch</button>
                    </div>
                </div>
                <div id="z3950_status" class="small text-muted"></div>
                <div id="z3950_result" style="display:none;" class="mt-3">
                    <div class="alert alert-info">
                        <strong>Title:</strong> <span id="z3950_title"></span>
                    </div>
                    <button class="btn btn-success w-100" onclick="applyZ3950Data()"><i class="fas fa-arrow-down"></i> Apply to Current Record</button>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ==================== DYNAMIC FIELD HANDLERS ====================
let newFieldCounter = <?= $fieldIdx ?>;

function addSubfield(btn) {
    let fieldDiv = btn.closest('.field-group');
    let fieldIndex = fieldDiv.getAttribute('data-field-index');
    let subfieldsContainer = fieldDiv.querySelector('.subfields-container');
    let newRow = document.createElement('div');
    newRow.className = 'row g-2 mb-2 subfield-row';
    newRow.innerHTML = `
        <div class="col-md-2">
            <input type="text" name="subfield_code_${fieldIndex}[]" class="form-control form-control-sm" placeholder="Code" required>
        </div>
        <div class="col-md-9">
            <input type="text" name="subfield_value_${fieldIndex}[]" class="form-control form-control-sm" placeholder="Value" required>
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeSubfield(this)"><i class="fas fa-minus-circle"></i></button>
        </div>
    `;
    subfieldsContainer.appendChild(newRow);
}

function removeSubfield(btn) {
    btn.closest('.subfield-row').remove();
}

function deleteField(btn) {
    if (confirm('Delete this entire field?')) {
        btn.closest('.field-group').remove();
    }
}

function addNewField() {
    let container = document.getElementById('newFieldsContainer');
    let idx = newFieldCounter++;
    let newDiv = document.createElement('div');
    newDiv.className = 'field-group card mb-3';
    newDiv.setAttribute('data-field-index', idx);
    newDiv.innerHTML = `
        <div class="card-header bg-light">
            <div class="row g-2 align-items-end">
                <div class="col-md-2">
                    <label class="form-label small">Tag</label>
                    <input type="text" name="new_tag[${idx}]" class="form-control form-control-sm" placeholder="e.g., 245" required>
                </div>
                <div class="col-md-1">
                    <label class="form-label small">Ind1</label>
                    <input type="text" name="new_ind1[${idx}]" class="form-control form-control-sm" value=" " maxlength="1">
                </div>
                <div class="col-md-1">
                    <label class="form-label small">Ind2</label>
                    <input type="text" name="new_ind2[${idx}]" class="form-control form-control-sm" value=" " maxlength="1">
                </div>
                <div class="col-md-4">
                    <label class="form-label small">Subfields</label>
                </div>
                <div class="col-md-4 text-end">
                    <button type="button" class="btn btn-sm btn-danger" onclick="deleteNewField(this)"><i class="fas fa-trash"></i> Remove</button>
                    <button type="button" class="btn btn-sm btn-success" onclick="addNewSubfield(this, ${idx})"><i class="fas fa-plus"></i> Add Subfield</button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="subfields-container"></div>
        </div>
    `;
    container.appendChild(newDiv);
    // Add one empty subfield row
    addNewSubfield(newDiv.querySelector('.btn-success'), idx);
}

function addNewSubfield(btn, idx) {
    let fieldDiv = btn.closest('.field-group');
    let subfieldsContainer = fieldDiv.querySelector('.subfields-container');
    let subRow = document.createElement('div');
    subRow.className = 'row g-2 mb-2 subfield-row';
    subRow.innerHTML = `
        <div class="col-md-2">
            <input type="text" name="new_subfield_code_${idx}[]" class="form-control form-control-sm" placeholder="Code" required>
        </div>
        <div class="col-md-9">
            <input type="text" name="new_subfield_value_${idx}[]" class="form-control form-control-sm" placeholder="Value" required>
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeNewSubfield(this, ${idx})"><i class="fas fa-minus-circle"></i></button>
        </div>
    `;
    subfieldsContainer.appendChild(subRow);
}

function removeNewSubfield(btn, idx) {
    btn.closest('.subfield-row').remove();
}

function deleteNewField(btn) {
    if (confirm('Remove this new field?')) {
        btn.closest('.field-group').remove();
    }
}

// ==================== Z39.50 FETCH ====================
let z3950Data = null;

function fetchZ3950() {
    let isbn = document.getElementById('z3950_isbn').value.trim();
    if (isbn.length < 10) {
        alert('Please enter a valid ISBN (10 or 13 digits)');
        return;
    }
    let statusDiv = document.getElementById('z3950_status');
    let resultDiv = document.getElementById('z3950_result');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching Z39.50 targets...';
    resultDiv.style.display = 'none';
    
    fetch(window.location.href + '?z3950_fetch=1&isbn=' + encodeURIComponent(isbn))
        .then(r => r.json())
        .then(data => {
            statusDiv.innerHTML = '';
            if (data.success) {
                z3950Data = data;
                document.getElementById('z3950_title').innerText = data.title || 'Unknown Title';
                resultDiv.style.display = 'block';
            } else {
                statusDiv.innerHTML = '<span class="text-danger">' + (data.error || 'Not found') + '</span>';
            }
        })
        .catch(err => {
            statusDiv.innerHTML = '<span class="text-danger">Network error: ' + err.message + '</span>';
        });
}

function applyZ3950Data() {
    if (!z3950Data || !z3950Data.fields) return;
    // Replace leader
    if (z3950Data.leader) {
        document.querySelector('input[name="leader"]').value = z3950Data.leader;
    }
    // Clear existing data fields (optional)
    if (confirm('This will replace all existing MARC fields (except control fields). Continue?')) {
        // Remove all existing field groups
        let container = document.getElementById('fieldsContainer');
        while (container.firstChild) {
            container.removeChild(container.firstChild);
        }
        // Reset new fields container
        document.getElementById('newFieldsContainer').innerHTML = '';
        newFieldCounter = 0;
        
        // Rebuild fields from Z39.50 data
        let fields = z3950Data.fields;
        for (let tag in fields) {
            if (tag < '010') continue;
            for (let occ of fields[tag]) {
                let fieldIdx = newFieldCounter++;
                let fieldDiv = document.createElement('div');
                fieldDiv.className = 'field-group card mb-3';
                fieldDiv.setAttribute('data-field-index', fieldIdx);
                
                let subfieldsHtml = '';
                for (let code in occ.subfields) {
                    let value = occ.subfields[code];
                    subfieldsHtml += `
                        <div class="row g-2 mb-2 subfield-row">
                            <div class="col-md-2"><input type="text" name="subfield_code_${fieldIdx}[]" class="form-control form-control-sm" value="${escapeHtml(code)}" required></div>
                            <div class="col-md-9"><input type="text" name="subfield_value_${fieldIdx}[]" class="form-control form-control-sm" value="${escapeHtml(value)}" required></div>
                            <div class="col-md-1"><button type="button" class="btn btn-sm btn-outline-danger" onclick="removeSubfield(this)"><i class="fas fa-minus-circle"></i></button></div>
                        </div>
                    `;
                }
                
                fieldDiv.innerHTML = `
                    <div class="card-header bg-light">
                        <div class="row g-2 align-items-end">
                            <div class="col-md-2"><label class="form-label small">Tag</label><input type="text" name="field_tag[${fieldIdx}]" class="form-control form-control-sm" value="${escapeHtml(tag)}" required></div>
                            <div class="col-md-1"><label class="form-label small">Ind1</label><input type="text" name="field_ind1[${fieldIdx}]" class="form-control form-control-sm" value="${escapeHtml(occ.ind1)}" maxlength="1"></div>
                            <div class="col-md-1"><label class="form-label small">Ind2</label><input type="text" name="field_ind2[${fieldIdx}]" class="form-control form-control-sm" value="${escapeHtml(occ.ind2)}" maxlength="1"></div>
                            <div class="col-md-4"><label class="form-label small">Subfields</label></div>
                            <div class="col-md-4 text-end"><button type="button" class="btn btn-sm btn-danger" onclick="deleteField(this)"><i class="fas fa-trash"></i> Delete Field</button><button type="button" class="btn btn-sm btn-success" onclick="addSubfield(this)"><i class="fas fa-plus"></i> Add Subfield</button></div>
                        </div>
                    </div>
                    <div class="card-body"><div class="subfields-container">${subfieldsHtml}</div></div>
                `;
                document.getElementById('fieldsContainer').appendChild(fieldDiv);
            }
        }
        
        // Update title field
        if (z3950Data.title) {
            document.querySelector('input[name="title"]').value = z3950Data.title;
        }
        
        // Close modal and show success
        bootstrap.Modal.getInstance(document.getElementById('z3950Modal')).hide();
        alert('Z39.50 data applied. Click "Save MARC Record" to persist.');
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

// Update preview on form changes (optional)
document.getElementById('marcForm').addEventListener('input', function() {
    // Could auto-refresh preview, but not necessary
});
</script>

<?php renderFooter(); ?>