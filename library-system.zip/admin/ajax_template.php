// At the very top of bulk_messaging.php, after session_start, add:
if (isset($_GET['get']) || isset($_POST['save_template']) || isset($_GET['delete'])) {
    require_once __DIR__ . '/../config/db.php';
    require_once __DIR__ . '/../config/functions.php';
    requireAdmin();
    $db = getDB();
    if (isset($_GET['get'])) {
        $id = (int)$_GET['get'];
        $stmt = $db->prepare("SELECT subject, body FROM message_templates WHERE id = ?");
        $stmt->execute([$id]);
        $tpl = $stmt->fetch();
        header('Content-Type: application/json');
        echo json_encode($tpl ?: []);
        exit;
    }
    if (isset($_POST['save_template']) && isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $name = trim($_POST['name']);
        $subject = trim($_POST['subject']);
        $body = trim($_POST['body']);
        if ($name && $body) {
            $db->prepare("INSERT INTO message_templates (name, subject, body) VALUES (?,?,?)")->execute([$name, $subject, $body]);
        }
        header("Location: bulk_messaging.php");
        exit;
    }
    if (isset($_GET['delete'])) {
        $id = (int)$_GET['delete'];
        $db->prepare("DELETE FROM message_templates WHERE id = ?")->execute([$id]);
        header("Location: bulk_messaging.php");
        exit;
    }
}