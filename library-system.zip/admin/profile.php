
<?php
require_once '../config/db.php';
require_once '../config/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}



$db = Database::getInstance()->getConnection();
$userId = $_SESSION['user_id'];
$message = '';
$error = '';



// Fetch current user data
$stmt = $db->prepare("SELECT username, fullname, email, role FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Change Username
    if (isset($_POST['change_username'])) {
        $newUsername = trim($_POST['new_username']);
        if (empty($newUsername)) {
            $error = "Username cannot be empty.";
        } elseif (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $newUsername)) {
            $error = "Username must be 3-20 characters, letters/numbers/underscore only.";
        } else {
            // Check uniqueness
            $check = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $check->execute([$newUsername, $userId]);
            if ($check->fetch()) {
                $error = "Username already taken. Choose another.";
            } else {
                $update = $db->prepare("UPDATE users SET username = ? WHERE id = ?");
                if ($update->execute([$newUsername, $userId])) {
                    $_SESSION['username'] = $newUsername;
                    $message = "Username changed successfully.";
                    $user['username'] = $newUsername;
                } else {
                    $error = "Database error. Please try again.";
                }
            }
        }
    }
    
    // Change Password
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'];
        $newPass = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];
        
        $passStmt = $db->prepare("SELECT password FROM users WHERE id = ?");
        $passStmt->execute([$userId]);
        $hash = $passStmt->fetchColumn();
        
        if (!password_verify($current, $hash)) {
            $error = "Current password is incorrect.";
        } elseif (strlen($newPass) < 6) {
            $error = "New password must be at least 6 characters.";
        } elseif ($newPass !== $confirm) {
            $error = "New passwords do not match.";
        } else {
            $newHash = password_hash($newPass, PASSWORD_DEFAULT);
            $update = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($update->execute([$newHash, $userId])) {
                $message = "Password changed successfully.";
            } else {
                $error = "Database error. Could not change password.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; font-family: 'Inter', sans-serif; }
        .profile-card { max-width: 600px; margin: 50px auto; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); padding: 30px; }
    </style>
</head>
<body>
<div class="container">
    <div class="profile-card">
        <h2><i class="fas fa-user-circle"></i> My Profile</h2>
        <p><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></p>
        <p><strong>Full Name:</strong> <?= htmlspecialchars($user['fullname']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email'] ?? 'Not set') ?></p>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <hr>
        <h4>Change Username</h4>
        <form method="post">
            <div class="mb-3">
                <label>Current Username</label>
                <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
            </div>
            <div class="mb-3">
                <label>New Username</label>
                <input type="text" name="new_username" class="form-control" required pattern="[A-Za-z0-9_]{3,20}" title="3-20 letters, numbers, underscore">
            </div>
            <button type="submit" name="change_username" class="btn btn-primary">Update Username</button>
        </form>
        
        <hr>
        <h4>Change Password</h4>
        <form method="post">
            <div class="mb-3">
                <label>Current Password</label>
                <input type="password" name="current_password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>New Password (min. 6 characters)</label>
                <input type="password" name="new_password" class="form-control" required minlength="6">
            </div>
            <div class="mb-3">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" name="change_password" class="btn btn-warning">Change Password</button>
        </form>
        
        <div class="mt-4">
            <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
        </div>
    </div>
</div>
</body>
</html>