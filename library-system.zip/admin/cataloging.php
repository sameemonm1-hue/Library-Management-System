<?php
/**
 * Comprehensive Cataloging Module
 * Features:
 *   - Fetch book metadata from OpenLibrary, Google Books, Z39.50 (multiple targets)
 *   - Add/Edit books directly from fetched data
 *   - Import MARC21 files (.mrc, .xml)
 *   - Export selected books to MARC21 (.mrc) and MARCXML (.xml)
 *   - View and edit raw MARC records (advanced users)
 * 
 * Dependencies:
 *   - Composer: require scriptotek/marc
 *   - PHP YAZ extension (optional, for Z39.50)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// ==================== DEPENDENCY CHECKS ====================
$marcAvailable = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    if (class_exists('Scriptotek\Marc\MarcReader')) {
        $marcAvailable = true;
    } elseif (class_exists('File_MARC')) {
        $marcAvailable = true;
    }
}

$yazAvailable = extension_loaded('yaz');

// ==================== Z39.50 TARGETS ====================
$z39Targets = [
    'loc' => [
        'name' => 'Library of Congress (LoC)',
        'host' => 'z3950.loc.gov',
        'port' => 7090,
        'db'   => 'voyager',
        'syntax' => 'usmarc',
        'attr' => ['isbn' => 7, 'title' => 4, 'author' => 1]
    ],
    'nlm' => [
        'name' => 'National Library of Medicine (NLM)',
        'host' => 'locate.nlm.nih.gov',
        'port' => 210,
        'db'   => 'NLM',
        'syntax' => 'usmarc',
        'attr' => ['isbn' => 7, 'title' => 4, 'author' => 1]
    ],
    'dnb' => [
        'name' => 'Deutsche Nationalbibliothek (DNB)',
        'host' => 'z3950.dnb.de',
        'port' => 2020,
        'db'   => 'DNB',
        'syntax' => 'usmarc',
        'attr' => ['isbn' => 7, 'title' => 4, 'author' => 1]
    ],
    'bne' => [
        'name' => 'Biblioteca Nacional de España (BNE)',
        'host' => 'catalogo.bne.es',
        'port' => 210,
        'db'   => 'BIBLIO',
        'syntax' => 'usmarc',
        'attr' => ['isbn' => 7, 'title' => 4, 'author' => 1]
    ],
    'nla' => [
        'name' => 'National Library of Australia (NLA)',
        'host' => 'z3950.nla.gov.au',
        'port' => 7090,
        'db'   => 'NAT',
        'syntax' => 'usmarc',
        'attr' => ['isbn' => 7, 'title' => 4, 'author' => 1]
    ]
];

// ==================== MAPPING: MARC21 <-> Database Fields ====================
$marcMapping = [
    'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
    'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
    'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
    'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
    'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
    'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
    'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
    'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'call_number' => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
    'category'    => ['tag' => '084', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
    'price'       => ['tag' => '020', 'subfield' => 'c', 'indicators' => [' ', ' ']],
];

// ==================== HELPER: Convert Database Record to MARC ====================
function dbRecordToMarc($book, $mapping) {
    if (class_exists('Scriptotek\Marc\Record')) {
        $record = new \Scriptotek\Marc\Record();
        $record->leader = "     nam a22     i 4500";
        foreach ($mapping as $dbField => $marc) {
            if (empty($book[$dbField])) continue;
            $value = $book[$dbField];
            $tag = $marc['tag'];
            $subfield = $marc['subfield'];
            $indicators = $marc['indicators'] ?? [' ', ' '];
            $field = $record->getField($tag);
            if (!$field) {
                $field = $record->addField($tag, $indicators);
            }
            $field->addSubfield($subfield, $value);
        }
        return $record;
    } elseif (class_exists('File_MARC_Record')) {
        $record = new \File_MARC_Record();
        $record->setLeader("     nam a22     i 4500");
        foreach ($mapping as $dbField => $marc) {
            if (empty($book[$dbField])) continue;
            $tag = $marc['tag'];
            $subfield = $marc['subfield'];
            $indicators = $marc['indicators'] ?? [' ', ' '];
            $field = $record->getField($tag);
            if (!$field) {
                $field = new \File_MARC_Data_Field($tag, $indicators);
                $record->appendField($field);
            }
            $field->appendSubfield(new \File_MARC_Subfield($subfield, $book[$dbField]));
        }
        return $record;
    }
    throw new Exception("MARC library not available");
}

// ==================== HELPER: Convert MARC Record to Database Array ====================
function marcToDbArray($record, $mapping) {
    $data = [];
    // Extract fields from MARC record
    $recordData = [];
    if (class_exists('Scriptotek\Marc\Record')) {
        foreach ($record->getFields() as $field) {
            $tag = $field->getTag();
            $subfields = [];
            foreach ($field->getSubfields() as $sf) {
                $subfields[$sf->getCode()] = $sf->getData();
            }
            $recordData[$tag] = $subfields;
        }
    } elseif (class_exists('File_MARC_Record')) {
        $fields = $record->getFields();
        while ($field = $fields->next()) {
            $tag = $field->getTag();
            $subfields = [];
            $subs = $field->getSubfields();
            while ($sub = $subs->next()) {
                $subfields[$sub->getCode()] = $sub->getData();
            }
            $recordData[$tag] = $subfields;
        }
    }
    foreach ($mapping as $dbField => $marc) {
        $tag = $marc['tag'];
        $subfield = $marc['subfield'];
        $data[$dbField] = $recordData[$tag][$subfield] ?? '';
    }
    return $data;
}

// ==================== METADATA FETCHERS ====================
function fetchViaOpenLibrary($isbn) {
    $url = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $json = @file_get_contents($url);
    if (!$json) return null;
    $data = json_decode($json, true);
    $key = "ISBN:$isbn";
    if (!isset($data[$key])) return null;
    $book = $data[$key];
    return [
        'title'      => $book['title'] ?? '',
        'subtitle'   => $book['subtitle'] ?? '',
        'author'     => isset($book['authors']) ? implode(', ', array_column($book['authors'], 'name')) : '',
        'publisher'  => $book['publishers'][0]['name'] ?? '',
        'year'       => preg_replace('/[^0-9]/', '', $book['publish_date'] ?? ''),
        'pages'      => $book['number_of_pages'] ?? 0,
        'isbn'       => $isbn,
        'summary'    => $book['notes'] ?? ($book['description'] ?? ''),
        'subject'    => isset($book['subjects']) ? implode(', ', array_slice($book['subjects'], 0, 3)) : '',
        'language'   => $book['languages'][0]['name'] ?? '',
        'cover_url'  => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
        'source'     => 'OpenLibrary'
    ];
}

function fetchViaGoogleBooks($isbn) {
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $json = @file_get_contents($url);
    if (!$json) return null;
    $data = json_decode($json, true);
    if (empty($data['items'])) return null;
    $item = $data['items'][0]['volumeInfo'];
    return [
        'title'      => $item['title'] ?? '',
        'subtitle'   => $item['subtitle'] ?? '',
        'author'     => isset($item['authors']) ? implode(', ', $item['authors']) : '',
        'publisher'  => $item['publisher'] ?? '',
        'year'       => substr($item['publishedDate'] ?? '', 0, 4),
        'pages'      => $item['pageCount'] ?? 0,
        'isbn'       => $isbn,
        'summary'    => $item['description'] ?? '',
        'subject'    => isset($item['categories']) ? implode(', ', $item['categories']) : '',
        'language'   => $item['language'] ?? '',
        'cover_url'  => $item['imageLinks']['thumbnail'] ?? ($item['imageLinks']['smallThumbnail'] ?? ''),
        'source'     => 'Google Books'
    ];
}

function fetchViaZ3950($isbn) {
    global $z39Targets;
    if (!function_exists('yaz_connect')) return null;
    foreach ($z39Targets as $target) {
        $conn = @yaz_connect($target['host'] . ':' . $target['port'] . '/' . $target['db']);
        if (!$conn) continue;
        yaz_syntax($conn, $target['syntax']);
        yaz_search($conn, 'rpn', '@attr 1=' . $target['attr']['isbn'] . ' "' . yaz_escape($isbn) . '"');
        yaz_wait();
        if (!yaz_error($conn) && yaz_hits($conn) > 0) {
            $rec = yaz_record($conn, 1, 'string');
            if ($rec) {
                if (class_exists('File_MARC')) {
                    $reader = new File_MARC($rec, File_MARC::SOURCE_STRING);
                    if ($record = $reader->next()) {
                        global $marcMapping;
                        $dbData = marcToDbArray($record, $marcMapping);
                        $dbData['source'] = $target['name'];
                        $dbData['cover_url'] = '';
                        return $dbData;
                    }
                }
            }
        }
        yaz_close($conn);
    }
    return null;
}

function fetchBookMetadata($isbn, $source = 'auto') {
    if ($source === 'openlibrary') return fetchViaOpenLibrary($isbn);
    if ($source === 'google') return fetchViaGoogleBooks($isbn);
    if ($source === 'z3950') return fetchViaZ3950($isbn);
    if ($source === 'auto') {
        $funcs = ['fetchViaOpenLibrary', 'fetchViaGoogleBooks'];
        if (function_exists('yaz_connect')) $funcs[] = 'fetchViaZ3950';
        foreach ($funcs as $func) {
            $res = $func($isbn);
            if ($res) return $res;
        }
    }
    return null;
}

// ==================== AJAX HANDLERS ====================
if (isset($_GET['ajax_fetch_metadata'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    $source = $_GET['source'] ?? 'auto';
    $result = fetchBookMetadata($isbn, $source);
    if ($result) {
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No metadata found']);
    }
    exit;
}

if (isset($_GET['ajax_fetch_all_sources'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    $results = [];
    $funcs = ['OpenLibrary', 'GoogleBooks'];
    if (function_exists('yaz_connect')) $funcs[] = 'Z3950';
    foreach ($funcs as $func) {
        $f = "fetchVia$func";
        $data = $f($isbn);
        if ($data) $results[] = $data;
    }
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

// ==================== EXPORT MARC ====================
if (isset($_GET['export_marc'])) {
    $format = $_GET['format'] ?? 'mrc';
    $bookIds = $_GET['ids'] ?? [];
    if (is_string($bookIds)) $bookIds = explode(',', $bookIds);
    $db = getDB();
    $sql = "SELECT * FROM books";
    $params = [];
    if (!empty($bookIds)) {
        $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
        $sql .= " WHERE id IN ($placeholders)";
        $params = $bookIds;
    }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();
    if (empty($books)) {
        showToast("No books selected", "warning");
        header("Location: cataloging.php");
        exit;
    }
    if (!$marcAvailable) {
        showToast("MARC library not installed. Run: composer require scriptotek/marc", "danger");
        header("Location: cataloging.php");
        exit;
    }
    if (class_exists('Scriptotek\Marc\MarcCollection')) {
        $collection = new \Scriptotek\Marc\MarcCollection();
        foreach ($books as $book) {
            $record = dbRecordToMarc($book, $marcMapping);
            $collection->addRecord($record);
        }
        if ($format === 'xml') {
            $content = $collection->toXml();
            $filename = "export_" . date('Ymd_His') . ".xml";
            $contentType = "application/xml";
        } else {
            $content = $collection->toRaw();
            $filename = "export_" . date('Ymd_His') . ".mrc";
            $contentType = "application/marc";
        }
    } else {
        $collection = new \File_MARC_Collection();
        foreach ($books as $book) {
            $record = dbRecordToMarc($book, $marcMapping);
            $collection->addRecord($record);
        }
        if ($format === 'xml') {
            $content = $collection->toXML();
            $filename = "export_" . date('Ymd_His') . ".xml";
            $contentType = "application/xml";
        } else {
            $content = $collection->toRaw();
            $filename = "export_" . date('Ymd_His') . ".mrc";
            $contentType = "application/octet-stream";
        }
    }
    header("Content-Type: $contentType");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header("Content-Length: " . strlen($content));
    echo $content;
    exit;
}

// ==================== IMPORT MARC ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_marc'])) {
    if (!isset($_FILES['marc_file']) || $_FILES['marc_file']['error'] !== UPLOAD_ERR_OK) {
        showToast("Please select a valid MARC file", "danger");
        header("Location: cataloging.php?tab=import");
        exit;
    }
    $file = $_FILES['marc_file']['tmp_name'];
    $ext = strtolower(pathinfo($_FILES['marc_file']['name'], PATHINFO_EXTENSION));
    if (!$marcAvailable) {
        showToast("MARC library not installed", "danger");
        header("Location: cataloging.php?tab=import");
        exit;
    }
    try {
        if ($ext === 'xml') {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARCXML(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        } else {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARC(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        }
        $db = getDB();
        $imported = 0;
        $errors = 0;
        $records = ($reader instanceof \File_MARC_Collection) ? $reader : $reader->getRecords();
        foreach ($records as $record) {
            $data = marcToDbArray($record, $marcMapping);
            if (empty($data['barcode']) || empty($data['title'])) {
                $errors++;
                continue;
            }
            $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $check->execute([$data['barcode']]);
            if ($check->fetch()) {
                // Update
                $stmt = $db->prepare("UPDATE books SET title=?, author=?, publisher=?, isbn=?, year=?, pages=?, subject=?, call_number=? WHERE barcode=?");
                $stmt->execute([$data['title'], $data['author'], $data['publisher'], $data['isbn'], $data['year'], $data['pages'], $data['subject'], $data['call_number'], $data['barcode']]);
            } else {
                // Insert
                $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, isbn, year, pages, subject, call_number, quantity, available, created_at) VALUES (?,?,?,?,?,?,?,?,?,1,1,datetime('now'))");
                $stmt->execute([$data['barcode'], $data['title'], $data['author'], $data['publisher'], $data['isbn'], $data['year'], $data['pages'], $data['subject'], $data['call_number']]);
            }
            $imported++;
        }
        showToast("Import completed: $imported records, $errors errors", $imported ? 'success' : 'warning');
    } catch (Exception $e) {
        showToast("Import failed: " . $e->getMessage(), "danger");
    }
    header("Location: cataloging.php?tab=import");
    exit;
}

// ==================== ADD/UPDATE BOOKS VIA FORM ====================
$db = getDB();
$editBook = null;
if (isset($_GET['edit_book'])) {
    $stmt = $db->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$_GET['edit_book']]);
    $editBook = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_book'])) {
    $barcode = $_POST['barcode'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $isbn = $_POST['isbn'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $subject = $_POST['subject'];
    $call_number = $_POST['call_number'];
    $quantity = (int)($_POST['quantity'] ?? 1);
    $available = (int)($_POST['available'] ?? $quantity);
    $price = !empty($_POST['price']) ? (float)$_POST['price'] : null;
    $cover_url = $_POST['cover_url'] ?? '';
    $coverPath = '';
    if (!empty($cover_url) && filter_var($cover_url, FILTER_VALIDATE_URL)) {
        $coverFileName = BOOK_COVER_DIR . 'book_' . $barcode . '_' . time() . '.jpg';
        $imgData = @file_get_contents($cover_url);
        if ($imgData && file_put_contents($coverFileName, $imgData)) {
            $coverPath = $coverFileName;
        }
    }
    if (isset($_FILES['book_cover']) && $_FILES['book_cover']['error'] === UPLOAD_ERR_OK) {
        $newCover = uploadFile($_FILES['book_cover'], BOOK_COVER_DIR, 'book_' . $barcode);
        if ($newCover) $coverPath = $newCover;
    }
    $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
    $check->execute([$barcode]);
    if ($check->fetch()) {
        showToast("Barcode already exists", "danger");
    } else {
        $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, isbn, year, pages, subject, call_number, quantity, available, price, cover_path, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))");
        $stmt->execute([$barcode, $title, $author, $publisher, $isbn, $year, $pages, $subject, $call_number, $quantity, $available, $price, $coverPath]);
        showToast("Book added successfully", "success");
    }
    header("Location: cataloging.php");
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_book'])) {
    $id = (int)$_POST['book_id'];
    $barcode = $_POST['barcode'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $isbn = $_POST['isbn'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $subject = $_POST['subject'];
    $call_number = $_POST['call_number'];
    $quantity = (int)($_POST['quantity'] ?? 1);
    $available = (int)($_POST['available'] ?? $quantity);
    $price = !empty($_POST['price']) ? (float)$_POST['price'] : null;
    $cover_url = $_POST['cover_url'] ?? '';
    $coverPath = $_POST['existing_cover'] ?? '';
    if (!empty($cover_url) && filter_var($cover_url, FILTER_VALIDATE_URL)) {
        $coverFileName = BOOK_COVER_DIR . 'book_' . $barcode . '_' . time() . '.jpg';
        $imgData = @file_get_contents($cover_url);
        if ($imgData && file_put_contents($coverFileName, $imgData)) {
            if ($coverPath && file_exists($coverPath)) unlink($coverPath);
            $coverPath = $coverFileName;
        }
    }
    if (isset($_FILES['book_cover']) && $_FILES['book_cover']['error'] === UPLOAD_ERR_OK) {
        $newCover = uploadFile($_FILES['book_cover'], BOOK_COVER_DIR, 'book_' . $barcode);
        if ($newCover) {
            if ($coverPath && file_exists($coverPath)) unlink($coverPath);
            $coverPath = $newCover;
        }
    }
    $stmt = $db->prepare("UPDATE books SET barcode=?, title=?, author=?, publisher=?, isbn=?, year=?, pages=?, subject=?, call_number=?, quantity=?, available=?, price=?, cover_path=? WHERE id=?");
    $stmt->execute([$barcode, $title, $author, $publisher, $isbn, $year, $pages, $subject, $call_number, $quantity, $available, $price, $coverPath, $id]);
    showToast("Book updated successfully", "success");
    header("Location: cataloging.php");
    exit;
}

// ==================== LIST BOOKS ====================
$books = $db->query("SELECT id, barcode, title, author, publisher, isbn, year, pages, subject, call_number, quantity, available, price, cover_path FROM books ORDER BY title LIMIT 200")->fetchAll();

renderHeader('Cataloging Module');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Comprehensive Cataloging</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body{background:#f0f2f5}
        .nav-tabs .nav-link{color:#1e3c72;font-weight:600}
        .nav-tabs .nav-link.active{background:#1e3c72;color:white;border-color:#1e3c72}
        .card-header{background:linear-gradient(135deg,#1e3c72 0%,#2a5298 100%);color:white}
        .book-cover{width:50px;height:65px;object-fit:cover;border-radius:4px}
        .result-card{border-left:4px solid #0d6efd;margin-bottom:15px}
        .pre{background:#f8f9fa;padding:10px;border-radius:6px;font-family:monospace;font-size:12px;max-height:300px;overflow:auto}
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-book"></i> Comprehensive Cataloging</h2>
        <div>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <?php if (!$marcAvailable): ?>
    <div class="alert alert-warning">⚠️ MARC library not installed. Run <code>composer require scriptotek/marc</code> to enable MARC import/export.</div>
    <?php endif; ?>
    <?php if (!$yazAvailable): ?>
    <div class="alert alert-info">ℹ️ PHP YAZ extension not installed. Z39.50 search disabled. Install via PECL for advanced cataloging.</div>
    <?php endif; ?>

    <ul class="nav nav-tabs mb-3" id="catalogTabs">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#fetch"><i class="fas fa-cloud-download-alt"></i> Fetch Metadata</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#import"><i class="fas fa-upload"></i> Import MARC</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#export"><i class="fas fa-download"></i> Export MARC</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#list"><i class="fas fa-list"></i> Book List</a></li>
    </ul>

    <div class="tab-content">
        <!-- ================= FETCH METADATA TAB ================= -->
        <div class="tab-pane fade show active" id="fetch">
            <div class="card">
                <div class="card-header"><i class="fas fa-search"></i> Fetch Book Metadata</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <label>ISBN (10 or 13 digits)</label>
                            <div class="input-group mb-3">
                                <input type="text" id="isbn_fetch" class="form-control" placeholder="e.g., 9780132350884">
                                <select id="source_select" class="form-select w-auto">
                                    <option value="auto">Auto (Try all)</option>
                                    <option value="openlibrary">OpenLibrary</option>
                                    <option value="google">Google Books</option>
                                    <?php if($yazAvailable): ?><option value="z3950">Z39.50 (Libraries)</option><?php endif; ?>
                                </select>
                                <button class="btn btn-primary" onclick="fetchMetadata()">Fetch</button>
                                <button class="btn btn-info" onclick="fetchAllSources()">Fetch ALL Sources</button>
                            </div>
                            <div id="fetchStatus" class="small text-muted"></div>
                        </div>
                        <div class="col-md-6">
                            <div id="fetchResult" class="alert alert-info d-none"></div>
                        </div>
                    </div>
                    <div id="metadataForm" style="display:none;">
                        <hr>
                        <h5>Add to Library</h5>
                        <form method="post" enctype="multipart/form-data" id="addBookForm">
                            <div class="row">
                                <div class="col-md-6 mb-2"><label>Barcode *</label><input type="text" name="barcode" id="m_barcode" class="form-control" required></div>
                                <div class="col-md-6 mb-2"><label>Call Number</label><input type="text" name="call_number" id="m_call_number" class="form-control"></div>
                                <div class="col-md-12 mb-2"><label>Title *</label><input type="text" name="title" id="m_title" class="form-control" required></div>
                                <div class="col-md-6 mb-2"><label>Author</label><input type="text" name="author" id="m_author" class="form-control"></div>
                                <div class="col-md-6 mb-2"><label>Publisher</label><input type="text" name="publisher" id="m_publisher" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>ISBN</label><input type="text" name="isbn" id="m_isbn" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>Year</label><input type="text" name="year" id="m_year" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>Pages</label><input type="number" name="pages" id="m_pages" class="form-control"></div>
                                <div class="col-md-12 mb-2"><label>Subject</label><input type="text" name="subject" id="m_subject" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>Quantity</label><input type="number" name="quantity" value="1" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>Available</label><input type="number" name="available" value="1" class="form-control"></div>
                                <div class="col-md-4 mb-2"><label>Price</label><input type="number" step="0.01" name="price" class="form-control"></div>
                                <div class="col-md-12 mb-2"><label>Summary</label><textarea name="summary" id="m_summary" class="form-control" rows="2"></textarea></div>
                                <div class="col-md-12 mb-2"><label>Cover URL</label><input type="text" name="cover_url" id="m_cover_url" class="form-control"><small>Will be downloaded automatically on save</small></div>
                                <div class="col-md-12 mb-2"><label>Or upload cover</label><input type="file" name="book_cover" class="form-control" accept="image/*"></div>
                            </div>
                            <button type="submit" name="add_book" class="btn btn-success mt-2">Add Book to Library</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- ================= IMPORT MARC TAB ================= -->
        <div class="tab-pane fade" id="import">
            <div class="card">
                <div class="card-header"><i class="fas fa-upload"></i> Import MARC21 File</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3"><label>MARC File (.mrc or .xml)</label><input type="file" name="marc_file" class="form-control" accept=".mrc,.xml" required></div>
                        <button type="submit" name="import_marc" class="btn btn-primary" <?= !$marcAvailable ? 'disabled' : '' ?>>Import</button>
                    </form>
                    <hr>
                    <p class="text-muted">The system matches records by barcode (field 952$p). If barcode exists, the record is updated; otherwise a new book is created.</p>
                </div>
            </div>
        </div>

        <!-- ================= EXPORT MARC TAB ================= -->
        <div class="tab-pane fade" id="export">
            <div class="card">
                <div class="card-header"><i class="fas fa-download"></i> Export Books to MARC21</div>
                <div class="card-body">
                    <form method="get" action="">
                        <div class="mb-3"><label>Select Books (Ctrl+click for multiple)</label>
                            <select name="ids[]" multiple class="form-select" size="10">
                                <?php foreach($books as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['barcode']) ?> - <?= htmlspecialchars(substr($b['title'],0,60)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3"><label>Format</label>
                            <select name="format" class="form-select"><option value="mrc">MARC Binary (.mrc)</option><option value="xml">MARCXML (.xml)</option></select>
                        </div>
                        <button type="submit" name="export_marc" class="btn btn-success" <?= !$marcAvailable ? 'disabled' : '' ?>>Export Selected</button>
                        <button type="submit" name="export_marc" value="1" class="btn btn-secondary" onclick="this.form.querySelector('select[name=ids]').selectedIndex = -1; return true;">Export All</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ================= BOOK LIST TAB ================= -->
        <div class="tab-pane fade" id="list">
            <div class="card">
                <div class="card-header"><i class="fas fa-list"></i> Book Catalog</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark"><tr><th>Cover</th><th>Barcode</th><th>Title</th><th>Author</th><th>Publisher</th><th>ISBN</th><th>Year</th><th>Pages</th><th>Qty/Avail</th><th>Actions</th></tr></thead>
                            <tbody>
                                <?php foreach($books as $book): ?>
                                <tr>
                                    <td class="text-center"><?php if(!empty($book['cover_path']) && file_exists($book['cover_path'])) echo '<img src="'.getWebImageUrl($book['cover_path']).'" class="book-cover">'; else echo '<i class="fas fa-book fa-2x text-muted"></i>'; ?></td>
                                    <td><?= htmlspecialchars($book['barcode']) ?></td>
                                    <td><strong><?= htmlspecialchars(substr($book['title'],0,60)) ?></strong></td>
                                    <td><?= htmlspecialchars($book['author'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($book['publisher'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($book['isbn'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($book['year'] ?? '') ?></td>
                                    <td><?= $book['pages'] ?? '' ?></td>
                                    <td><span class="badge bg-primary"><?= $book['quantity'] ?></span> / <span class="badge bg-<?= $book['available']>0?'success':'danger' ?>"><?= $book['available'] ?></span></td>
                                    <td><a href="?edit_book=<?= $book['id'] ?>" class="btn btn-sm btn-warning">Edit</a></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for "Fetch All Sources" results -->
<div class="modal fade" id="allSourcesModal" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header bg-info text-white"><h5>Results from All Sources</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body" id="allSourcesResults"></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div></div></div></div>

<!-- Edit Book Modal -->
<?php if($editBook): ?>
<div class="modal fade show" id="editModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header bg-warning"><h5>Edit Book</h5><a href="cataloging.php" class="btn-close"></a></div>
<form method="post" enctype="multipart/form-data"><div class="modal-body"><div class="row">
    <input type="hidden" name="book_id" value="<?= $editBook['id'] ?>">
    <div class="col-md-6 mb-2"><label>Barcode</label><input type="text" name="barcode" value="<?= htmlspecialchars($editBook['barcode']) ?>" class="form-control" required></div>
    <div class="col-md-6 mb-2"><label>Call Number</label><input type="text" name="call_number" value="<?= htmlspecialchars($editBook['call_number'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-12 mb-2"><label>Title</label><input type="text" name="title" value="<?= htmlspecialchars($editBook['title']) ?>" class="form-control" required></div>
    <div class="col-md-6 mb-2"><label>Author</label><input type="text" name="author" value="<?= htmlspecialchars($editBook['author'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-6 mb-2"><label>Publisher</label><input type="text" name="publisher" value="<?= htmlspecialchars($editBook['publisher'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-4 mb-2"><label>ISBN</label><input type="text" name="isbn" value="<?= htmlspecialchars($editBook['isbn'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-4 mb-2"><label>Year</label><input type="text" name="year" value="<?= htmlspecialchars($editBook['year'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-4 mb-2"><label>Pages</label><input type="number" name="pages" value="<?= $editBook['pages'] ?? '' ?>" class="form-control"></div>
    <div class="col-md-12 mb-2"><label>Subject</label><input type="text" name="subject" value="<?= htmlspecialchars($editBook['subject'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-4 mb-2"><label>Quantity</label><input type="number" name="quantity" value="<?= $editBook['quantity'] ?>" class="form-control" min="1"></div>
    <div class="col-md-4 mb-2"><label>Available</label><input type="number" name="available" value="<?= $editBook['available'] ?>" class="form-control" min="0"></div>
    <div class="col-md-4 mb-2"><label>Price</label><input type="number" step="0.01" name="price" value="<?= htmlspecialchars($editBook['price'] ?? '') ?>" class="form-control"></div>
    <div class="col-md-12 mb-2"><label>Summary</label><textarea name="summary" class="form-control" rows="2"><?= htmlspecialchars($editBook['summary'] ?? '') ?></textarea></div>
    <div class="col-md-12 mb-2"><label>Cover Image</label><input type="file" name="book_cover" class="form-control" accept="image/*"><?php if(!empty($editBook['cover_path']) && file_exists($editBook['cover_path'])): ?><div class="mt-2"><img src="<?= getWebImageUrl($editBook['cover_path']) ?>" style="height:80px;"><input type="hidden" name="existing_cover" value="<?= htmlspecialchars($editBook['cover_path']) ?>"></div><?php endif; ?></div>
</div></div><div class="modal-footer"><button type="submit" name="update_book" class="btn btn-primary">Update</button><a href="cataloging.php" class="btn btn-secondary">Cancel</a></div></form></div></div></div>
<?php endif; ?>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function escapeHtml(str){if(!str)return '';return str.replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'})[m]);}
function showToast(msg,type){let div=document.createElement('div');div.className=`alert alert-${type} position-fixed top-0 end-0 m-3`;div.innerHTML=msg;document.body.appendChild(div);setTimeout(()=>div.remove(),4000);}
function fetchMetadata(){
    let isbn=document.getElementById('isbn_fetch').value.trim();
    if(!isbn){showToast('Enter ISBN','warning');return;}
    let source=document.getElementById('source_select').value;
    let statusDiv=document.getElementById('fetchStatus');
    statusDiv.innerHTML='<i class="fas fa-spinner fa-spin"></i> Fetching...';
    fetch(`cataloging.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}&source=${source}`)
        .then(r=>r.json())
        .then(data=>{
            statusDiv.innerHTML='';
            if(data.success){
                let b=data.data;
                document.getElementById('m_barcode').value=b.isbn || isbn;
                document.getElementById('m_title').value=b.title;
                document.getElementById('m_author').value=b.author;
                document.getElementById('m_publisher').value=b.publisher;
                document.getElementById('m_isbn').value=b.isbn;
                document.getElementById('m_year').value=b.year;
                document.getElementById('m_pages').value=b.pages;
                document.getElementById('m_subject').value=b.subject;
                document.getElementById('m_summary').value=b.summary;
                document.getElementById('m_cover_url').value=b.cover_url;
                document.getElementById('m_call_number').value=b.call_number||'';
                document.getElementById('metadataForm').style.display='block';
                document.getElementById('fetchResult').innerHTML=`<i class="fas fa-check-circle"></i> Fetched from ${b.source}. Fill barcode and save.`;
                document.getElementById('fetchResult').className='alert alert-success';
            }else{
                document.getElementById('fetchResult').innerHTML=`<i class="fas fa-exclamation-triangle"></i> ${data.error}`;
                document.getElementById('fetchResult').className='alert alert-danger';
                document.getElementById('fetchResult').style.display='block';
            }
        }).catch(()=>{statusDiv.innerHTML='<span class="text-danger">Network error</span>';});
}
function fetchAllSources(){
    let isbn=document.getElementById('isbn_fetch').value.trim();
    if(!isbn){showToast('Enter ISBN','warning');return;}
    fetch(`cataloging.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r=>r.json())
        .then(data=>{
            if(data.success && data.results.length){
                let html='<div class="row">';
                data.results.forEach(r=>{
                    html+=`<div class="col-md-6 mb-3"><div class="card result-card"><div class="card-header"><strong>${escapeHtml(r.source)}</strong></div><div class="card-body"><p><strong>Title:</strong> ${escapeHtml(r.title)}<br><strong>Author:</strong> ${escapeHtml(r.author)}<br><strong>Publisher:</strong> ${escapeHtml(r.publisher)}<br><strong>Year:</strong> ${r.year}<br><strong>Pages:</strong> ${r.pages}<br><strong>ISBN:</strong> ${r.isbn}</p><button class="btn btn-sm btn-primary" onclick="applySourceData(${JSON.stringify(r).replace(/"/g, '&quot;')})">Use This</button></div></div></div>`;
                });
                html+='</div>';
                document.getElementById('allSourcesResults').innerHTML=html;
                new bootstrap.Modal(document.getElementById('allSourcesModal')).show();
            }else{
                showToast('No results from any source','warning');
            }
        }).catch(()=>showToast('Error fetching','danger'));
}
function applySourceData(data){
    document.getElementById('m_barcode').value=data.isbn;
    document.getElementById('m_title').value=data.title;
    document.getElementById('m_author').value=data.author;
    document.getElementById('m_publisher').value=data.publisher;
    document.getElementById('m_isbn').value=data.isbn;
    document.getElementById('m_year').value=data.year;
    document.getElementById('m_pages').value=data.pages;
    document.getElementById('m_subject').value=data.subject;
    document.getElementById('m_summary').value=data.summary;
    document.getElementById('m_cover_url').value=data.cover_url;
    document.getElementById('m_call_number').value=data.call_number||'';
    document.getElementById('metadataForm').style.display='block';
    bootstrap.Modal.getInstance(document.getElementById('allSourcesModal')).hide();
    showToast(`Applied data from ${data.source}`,'success');
}
</script>
<?php renderFooter(); ?>