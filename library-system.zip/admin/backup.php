<?php
/**
 * Backup & Restore Module – Comprehensive, Error‑Free
 * Version: 4.2 – Fixed file lock issues during restore.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$zipAvailable = class_exists('ZipArchive');

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function recursiveCopy($src, $dst, $overwrite = true) {
    if (!is_dir($src)) return;
    if (!is_dir($dst)) mkdir($dst, 0777, true);
    $dir = opendir($src);
    while (($file = readdir($dir)) !== false) {
        if ($file == '.' || $file == '..') continue;
        $srcFile = $src . '/' . $file;
        $dstFile = $dst . '/' . $file;
        if (is_dir($srcFile)) {
            recursiveCopy($srcFile, $dstFile, $overwrite);
        } else {
            if (!file_exists($dstFile) || $overwrite) {
                copy($srcFile, $dstFile);
            }
        }
    }
    closedir($dir);
}

function deleteDirectory($dir) {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        is_dir($path) ? deleteDirectory($path) : unlink($path);
    }
    rmdir($dir);
}

function getDirectorySize($dir) {
    $size = 0;
    $files = scandir($dir);
    foreach ($files as $file) {
        if ($file == '.' || $file == '..') continue;
        $path = $dir . '/' . $file;
        $size += is_file($path) ? filesize($path) : getDirectorySize($path);
    }
    return $size;
}

function formatSize($bytes) {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function uploadBackupToCloud($localPath) {
    $settings = getSettings();
    $provider = $settings['cloud_storage_provider'] ?? 'local';
    if ($provider === 'local') return false;
    logActivity($_SESSION['username'], 'BACKUP_CLOUD_UPLOAD', "Attempted upload to $provider");
    return true;
}

// =============================================================================
// CREATE BACKUP
// =============================================================================

if (isset($_POST['create_backup'])) {
    $timestamp = date('Y-m-d_H-i-s');
    $backupName = 'backup_' . $timestamp;
    $backupFolder = BACKUP_DIR . $backupName . '/';
    mkdir($backupFolder, 0777, true);

    if (file_exists(DB_FILE)) {
        copy(DB_FILE, $backupFolder . 'database.sqlite');
    } else {
        showToast('Database file not found!', 'danger');
        header('Location: backup.php');
        exit;
    }

    $dirsToBackup = [
        MEMBER_PHOTO_DIR  => 'members',
        BOOK_COVER_DIR    => 'books',
        LOGO_DIR          => 'logos',
        EBOOK_DIR         => 'ebooks',
        SIGNATURE_DIR     => 'signatures',
        REPORT_TEMP_DIR   => 'reports',
        IMPORT_LOG_DIR    => 'logs/imports',
        CACHE_DIR         => 'cache',
    ];

    foreach ($dirsToBackup as $src => $dest) {
        if (is_dir($src)) {
            $targetDir = $backupFolder . $dest;
            recursiveCopy($src, $targetDir);
        }
    }

    $backupFile = null;
    if ($zipAvailable) {
        $zipFile = BACKUP_DIR . $backupName . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($backupFolder, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($files as $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($backupFolder));
                    $zip->addFile($filePath, $relativePath);
                }
            }
            $zip->close();
            $backupFile = $zipFile;
            deleteDirectory($backupFolder);
        } else {
            showToast('Failed to create ZIP backup. Backup saved as folder.', 'warning');
            $backupFile = $backupFolder;
        }
    } else {
        showToast('ZipArchive not available. Backup saved as folder: ' . basename($backupFolder), 'warning');
        $backupFile = $backupFolder;
    }

    if ($backupFile) {
        $size = is_dir($backupFile) ? getDirectorySize($backupFile) : filesize($backupFile);
        $sizeStr = formatSize($size);
        showToast("Backup created successfully: " . basename($backupFile) . " ($sizeStr)", 'success');
        logActivity($_SESSION['username'], 'BACKUP_CREATE', "Created backup: " . basename($backupFile));

        if (!empty($settings['cloud_storage_provider']) && $settings['cloud_storage_provider'] !== 'local') {
            $uploaded = uploadBackupToCloud($backupFile);
            if ($uploaded) {
                showToast('Backup also uploaded to cloud storage.', 'info');
                logActivity($_SESSION['username'], 'BACKUP_CLOUD_UPLOAD', "Uploaded backup to " . $settings['cloud_storage_provider']);
            }
        }
    } else {
        showToast('Backup creation failed.', 'danger');
    }

    header('Location: backup.php');
    exit;
}

// =============================================================================
// RESTORE BACKUP (ROBUST + SCHEMA UPGRADE)
// =============================================================================

if (isset($_POST['restore_backup']) && isset($_FILES['restore_file'])) {
    $error = null;
    $success = null;

    if ($_FILES['restore_file']['error'] !== UPLOAD_ERR_OK) {
        $uploadErrors = [
            UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the upload_max_filesize directive.',
            UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the MAX_FILE_SIZE directive.',
            UPLOAD_ERR_PARTIAL    => 'The uploaded file was only partially uploaded.',
            UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
            UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.',
        ];
        $error = 'File upload error: ' . ($uploadErrors[$_FILES['restore_file']['error']] ?? 'Unknown error');
    } else {
        $file = $_FILES['restore_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $tempFile = BACKUP_DIR . 'restore_' . time() . '.' . $ext;

        if (!move_uploaded_file($file['tmp_name'], $tempFile)) {
            $error = 'Failed to move uploaded file. Check directory permissions for ' . BACKUP_DIR;
        } else {
            $extractDir = BACKUP_DIR . 'restore_' . time() . '/';
            mkdir($extractDir, 0777, true);
            $restored = false;

            // Extract ZIP or copy SQLite
            if ($ext === 'zip' && $zipAvailable) {
                $zip = new ZipArchive();
                if ($zip->open($tempFile) === true) {
                    if ($zip->extractTo($extractDir)) {
                        $restored = true;
                    } else {
                        $error = 'Failed to extract ZIP file. The archive may be corrupted.';
                    }
                    $zip->close();
                } else {
                    $error = 'Failed to open ZIP file. The file may be corrupted or not a valid ZIP.';
                }
            } elseif ($ext === 'sqlite') {
                copy($tempFile, $extractDir . 'database.sqlite');
                $restored = true;
            } elseif (is_dir($tempFile)) {
                recursiveCopy($tempFile, $extractDir);
                $restored = true;
            } else {
                $error = 'Unsupported file format. Please upload a ZIP or SQLite file.';
            }

            if ($restored) {
                // --- Pre-restore safety backup ---
                $preRestoreBackup = BACKUP_DIR . 'pre_restore_backup_' . date('Y-m-d_H-i-s') . '.sqlite';
                if (file_exists(DB_FILE)) {
                    copy(DB_FILE, $preRestoreBackup);
                }

                // --- Close ALL database connections and release locks ---
                // 1. Close the main PDO connection
                Database::getInstance()->closeConnection();
                // 2. Unset any global $db variables that might hold a reference
                global $db;
                if (isset($db)) {
                    $db = null;
                    unset($db);
                }
                // 3. Force garbage collection
                gc_collect_cycles();
                // 4. Clear PHP's stat cache
                clearstatcache();

                // 5. Delete any lingering WAL or SHM files (they may be holding locks)
                $walFile = DB_FILE . '-wal';
                $shmFile = DB_FILE . '-shm';
                if (file_exists($walFile)) @unlink($walFile);
                if (file_exists($shmFile)) @unlink($shmFile);

                // 6. Sleep to allow the OS to release file handles
                usleep(3000000); // 3 seconds

                $dbBackup = $extractDir . 'database.sqlite';
                if (!file_exists($dbBackup)) {
                    $error = 'Database file not found in backup.';
                    // Reconnect so the user can see the error page
                    Database::getInstance()->reconnect();
                } else {
                    $targetDir = dirname(DB_FILE);
                    $restoreSuccess = false;
                    $lastError = null;

                    // ========== METHOD 1: sqlite3 .restore (most reliable) ==========
                    if (function_exists('exec') && !ini_get('safe_mode')) {
                        $output = [];
                        $returnCode = 0;
                        exec('sqlite3 --version 2>&1', $output, $returnCode);
                        if ($returnCode === 0 && strpos($output[0] ?? '', 'sqlite3') !== false) {
                            $cmd = 'sqlite3 ' . escapeshellarg(DB_FILE) . ' ".restore ' . escapeshellarg($dbBackup) . '" 2>&1';
                            exec($cmd, $cmdOutput, $cmdReturn);
                            if ($cmdReturn === 0) {
                                $restoreSuccess = true;
                            } else {
                                $lastError = "sqlite3 restore failed: " . implode("\n", $cmdOutput);
                                error_log($lastError);
                            }
                        }
                    }

                    // ========== METHOD 2: PHP SQLite3 backup API (suppress warnings) ==========
                    if (!$restoreSuccess && class_exists('SQLite3')) {
                        try {
                            $source = new SQLite3($dbBackup, SQLITE3_OPEN_READONLY);
                            $dest = new SQLite3(DB_FILE, SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE);
                            // Suppress warnings from backup() – they may be false positives
                            $backupResult = @$dest->backup($source);
                            if ($backupResult) {
                                $restoreSuccess = true;
                            } else {
                                $lastError = "SQLite3 backup API failed (returned false).";
                            }
                            $source->close();
                            $dest->close();
                            // Unset objects to release resources
                            unset($source, $dest);
                        } catch (Exception $e) {
                            $lastError = "SQLite3 backup API exception: " . $e->getMessage();
                            error_log($lastError);
                        }
                    }

                    // ========== METHOD 3: Direct copy (with retry) ==========
                    if (!$restoreSuccess) {
                        $maxAttempts = 3;
                        $attempt = 0;
                        while ($attempt < $maxAttempts && !$restoreSuccess) {
                            $attempt++;
                            if (copy($dbBackup, DB_FILE)) {
                                $restoreSuccess = true;
                                break;
                            }
                            usleep(1000000); // wait 1 second between attempts
                        }
                        if (!$restoreSuccess) {
                            $lastError = "Failed to copy database file after $maxAttempts attempts. The file may be locked.";
                        }
                    }

                    // ========== METHOD 4: Rename + copy (if all else fails) ==========
                    if (!$restoreSuccess) {
                        if (!is_writable($targetDir)) {
                            $lastError = "Target directory is not writable: $targetDir. Please set permissions.";
                        } else {
                            $oldDb = DB_FILE . '.old_' . time();
                            $renameSuccess = false;
                            $maxRenameAttempts = 5;
                            $renameAttempt = 0;
                            // Try to rename with retries
                            while ($renameAttempt < $maxRenameAttempts && !$renameSuccess) {
                                $renameAttempt++;
                                if (file_exists(DB_FILE)) {
                                    if (rename(DB_FILE, $oldDb)) {
                                        $renameSuccess = true;
                                    } else {
                                        // Wait longer between attempts (exponential backoff)
                                        usleep($renameAttempt * 1000000); // 1s, 2s, 3s, 4s, 5s
                                    }
                                } else {
                                    // File doesn't exist – we can proceed
                                    $renameSuccess = true;
                                }
                            }

                            if (!$renameSuccess) {
                                $lastError = "Failed to rename existing database after $maxRenameAttempts attempts. The file is locked. Try restarting the web server.";
                            } else {
                                // Now copy the backup to the target
                                if (copy($dbBackup, DB_FILE)) {
                                    $restoreSuccess = true;
                                    if (file_exists($oldDb)) unlink($oldDb);
                                } else {
                                    // Copy failed – attempt to restore the old file if it was renamed
                                    if (file_exists($oldDb)) {
                                        rename($oldDb, DB_FILE);
                                    }
                                    $lastError = "Failed to copy database file to $targetDir. Check permissions.";
                                }
                            }
                        }
                    }

                    if ($restoreSuccess) {
                        // --- Restore directories ---
                        $dirsToRestore = [
                            'members'   => MEMBER_PHOTO_DIR,
                            'books'     => BOOK_COVER_DIR,
                            'logos'     => LOGO_DIR,
                            'ebooks'    => EBOOK_DIR,
                            'signatures'=> SIGNATURE_DIR,
                            'reports'   => REPORT_TEMP_DIR,
                            'logs/imports' => IMPORT_LOG_DIR,
                            'cache'     => CACHE_DIR,
                        ];
                        foreach ($dirsToRestore as $subDir => $target) {
                            $source = $extractDir . $subDir;
                            if (is_dir($source)) {
                                if (!is_dir($target)) mkdir($target, 0777, true);
                                recursiveCopy($source, $target, true);
                            }
                        }

                        // --- Reconnect and UPGRADE SCHEMA ---
                        try {
                            Database::getInstance()->reconnect();
                            Database::getInstance()->upgradeSchemaIfNeeded();
                            $success = 'Restore completed successfully! A pre‑restore backup was saved and the database schema was upgraded.';
                            logActivity($_SESSION['username'], 'BACKUP_RESTORE', "Restored from backup: " . basename($file['name']));
                        } catch (Exception $e) {
                            $error = "Restore succeeded but schema upgrade failed: " . $e->getMessage();
                            error_log($error);
                        }
                    } else {
                        // If restore failed, try to reconnect anyway
                        try { Database::getInstance()->reconnect(); } catch (Exception $e) {}
                        $error = $lastError ?? 'Restore failed for unknown reason.';
                    }
                }

                // Cleanup
                deleteDirectory($extractDir);
                unlink($tempFile);
            } else {
                if (!$error) $error = 'Restore failed.';
                if (file_exists($tempFile)) unlink($tempFile);
                if (is_dir($extractDir)) deleteDirectory($extractDir);
            }
        }
    }

    if ($success) {
        showToast($success, 'success');
    } elseif ($error) {
        showToast($error, 'danger');
    } else {
        showToast('Restore completed with no status.', 'info');
    }

    header('Location: backup.php');
    exit;
}

// =============================================================================
// DELETE BACKUP
// =============================================================================

if (isset($_GET['delete'])) {
    $name = basename($_GET['delete']);
    $fullPath = BACKUP_DIR . $name;
    if (file_exists($fullPath)) {
        if (is_dir($fullPath)) {
            deleteDirectory($fullPath);
        } else {
            unlink($fullPath);
        }
        showToast('Backup deleted: ' . $name, 'success');
        logActivity($_SESSION['username'], 'BACKUP_DELETE', "Deleted backup: $name");
    } else {
        showToast('File not found.', 'danger');
    }
    header('Location: backup.php');
    exit;
}

// =============================================================================
// DOWNLOAD BACKUP
// =============================================================================

if (isset($_GET['download'])) {
    $name = basename($_GET['download']);
    $fullPath = BACKUP_DIR . $name;
    if (!file_exists($fullPath)) {
        showToast('File not found.', 'danger');
        header('Location: backup.php');
        exit;
    }

    if (is_dir($fullPath)) {
        if (!$zipAvailable) {
            showToast('Cannot download folder backup – ZipArchive not available.', 'danger');
            header('Location: backup.php');
            exit;
        }
        $tempZip = BACKUP_DIR . 'temp_' . time() . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($tempZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($files as $f) {
                if (!$f->isDir()) {
                    $filePath = $f->getRealPath();
                    $relativePath = substr($filePath, strlen($fullPath) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }
            $zip->close();
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $name . '.zip"');
            header('Content-Length: ' . filesize($tempZip));
            readfile($tempZip);
            unlink($tempZip);
            exit;
        } else {
            showToast('Failed to create ZIP for download.', 'danger');
            header('Location: backup.php');
            exit;
        }
    } else {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($fullPath));
        readfile($fullPath);
        exit;
    }
}

// =============================================================================
// LIST BACKUPS
// =============================================================================

$backups = [];
$files = glob(BACKUP_DIR . 'backup_*');
foreach ($files as $file) {
    $isDir = is_dir($file);
    $backups[] = [
        'name' => basename($file),
        'size' => $isDir ? getDirectorySize($file) : filesize($file),
        'date' => date('Y-m-d H:i:s', filemtime($file)),
        'is_dir' => $isDir,
        'is_pre_restore' => strpos(basename($file), 'pre_restore_backup') !== false,
    ];
}
usort($backups, function ($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// =============================================================================
// RENDER PAGE
// =============================================================================

renderHeader('Backup & Restore');
?>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-database text-primary"></i> Backup & Restore</h2>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <a href="settings.php" class="btn btn-secondary"><i class="fas fa-cog"></i> Settings</a>
        </div>
    </div>

    <?php if (!$zipAvailable): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <i class="fas fa-exclamation-triangle"></i> 
        <strong>ZipArchive not available.</strong> Backups will be saved as folders. 
        Enable <code>extension=zip</code> in php.ini for compressed backups.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['toast'])): ?>
        <div class="alert alert-<?= $_SESSION['toast']['type'] ?> alert-dismissible fade show" role="alert">
            <?= htmlspecialchars($_SESSION['toast']['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['toast']); ?>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Left Column: Create & Restore -->
        <div class="col-lg-5">
            <!-- Create Backup Card -->
            <div class="card shadow-sm rounded-4 border-0 mb-4">
                <div class="card-header bg-success text-white rounded-top-4 py-3">
                    <h5 class="mb-0"><i class="fas fa-plus-circle"></i> Create New Backup</h5>
                </div>
                <div class="card-body text-center">
                    <p class="text-muted">Complete backup includes:</p>
                    <div class="row text-start small g-1">
                        <div class="col-6"><i class="fas fa-database text-primary"></i> Database</div>
                        <div class="col-6"><i class="fas fa-images text-secondary"></i> Member photos</div>
                        <div class="col-6"><i class="fas fa-book text-success"></i> Book covers</div>
                        <div class="col-6"><i class="fas fa-image text-warning"></i> Logos &amp; signatures</div>
                        <div class="col-6"><i class="fas fa-file-pdf text-danger"></i> eBooks</div>
                        <div class="col-6"><i class="fas fa-file-alt text-info"></i> Reports &amp; logs</div>
                        <div class="col-12"><i class="fas fa-cache text-muted"></i> Cache</div>
                    </div>
                    <hr>
                    <form method="post">
                        <button type="submit" name="create_backup" class="btn btn-success btn-lg w-100">
                            <i class="fas fa-download"></i> Create Full Backup
                        </button>
                    </form>
                    <div class="alert alert-info mt-3 small">
                        <i class="fas fa-info-circle"></i> 
                        Scheduled: <?= $settings['backup_schedule'] ?? 'daily' ?> at <?= $settings['backup_time'] ?? '00:00' ?>
                        <?php if (!$zipAvailable): ?>
                            <br><span class="text-warning">Will be saved as folder</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Restore Card -->
            <div class="card shadow-sm rounded-4 border-0">
                <div class="card-header bg-warning text-white rounded-top-4 py-3">
                    <h5 class="mb-0"><i class="fas fa-upload"></i> Restore Backup</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <strong>Warning:</strong> Restoring will overwrite ALL current data. 
                        A pre‑restore backup will be created automatically.
                    </div>
                    <form method="post" enctype="multipart/form-data" id="restoreForm">
                        <div class="mb-3">
                            <label class="form-label">Select Backup File</label>
                            <input type="file" name="restore_file" class="form-control" accept=".zip,.sqlite" required>
                            <small class="text-muted">Accepted formats: ZIP (from this system) or SQLite database</small>
                        </div>
                        <button type="submit" name="restore_backup" class="btn btn-warning w-100" 
                                onclick="return confirm('WARNING: This will overwrite ALL current data!\n\nMake sure you have a recent backup.\n\nProceed?')">
                            <i class="fas fa-upload"></i> Restore
                        </button>
                    </form>
                    <div id="restoreProgress" class="mt-3" style="display:none;">
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 100%;">Restoring...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column: Backup List -->
        <div class="col-lg-7">
            <div class="card shadow-sm rounded-4 border-0">
                <div class="card-header bg-primary text-white rounded-top-4 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-list"></i> Available Backups</h5>
                    <span class="badge bg-light text-dark"><?= count($backups) ?></span>
                </div>
                <div class="card-body">
                    <?php if (empty($backups)): ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                            No backups found.
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Name</th>
                                        <th>Size</th>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th class="text-center">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $b): ?>
                                    <tr>
                                        <td>
                                            <?= htmlspecialchars($b['name']) ?>
                                            <?php if ($b['is_pre_restore']): ?>
                                                <span class="badge bg-info">Pre-restore</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= formatSize($b['size']) ?></td>
                                        <td><?= $b['date'] ?></td>
                                        <td>
                                            <?php if ($b['is_dir']): ?>
                                                <span class="badge bg-secondary">Folder</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">ZIP</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <div class="btn-group btn-group-sm">
                                                <a href="?download=<?= urlencode($b['name']) ?>" class="btn btn-primary" title="Download">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                                <a href="?delete=<?= urlencode($b['name']) ?>" class="btn btn-danger" title="Delete" 
                                                   onclick="return confirm('Delete this backup permanently?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tips Card -->
            <div class="card shadow-sm rounded-4 border-0 mt-4">
                <div class="card-header bg-info text-white rounded-top-4 py-3">
                    <h5 class="mb-0"><i class="fas fa-lightbulb"></i> Best Practices</h5>
                </div>
                <div class="card-body">
                    <ul class="mb-0 small">
                        <li><i class="fas fa-calendar-alt text-primary"></i> Schedule regular automatic backups.</li>
                        <li><i class="fas fa-download text-success"></i> Download critical backups to external storage.</li>
                        <li><i class="fas fa-history text-warning"></i> Keep at least 3–5 recent backups.</li>
                        <li><i class="fas fa-shield-alt text-danger"></i> Test restore in a staging environment periodically.</li>
                        <li class="text-info"><i class="fas fa-sync-alt"></i> <strong>Schema auto‑upgrade</strong> – After restore, the database is automatically upgraded to the latest version.</li>
                        <?php if (!$zipAvailable): ?>
                        <li class="text-warning">
                            <i class="fas fa-exclamation-triangle"></i> 
                            <strong>Enable ZipArchive</strong> – uncomment <code>extension=zip</code> in php.ini.
                        </li>
                        <?php endif; ?>
                        <li class="text-muted">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Windows users:</strong> If the restore fails due to file locks, try restarting the web server or using the <code>sqlite3</code> command-line tool.
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts after 5 seconds
    var alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Show progress bar on restore form submission
    var restoreForm = document.getElementById('restoreForm');
    if (restoreForm) {
        restoreForm.addEventListener('submit', function() {
            document.getElementById('restoreProgress').style.display = 'block';
        });
    }
});
</script>

<?php renderFooter(); ?>