<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin(); // only admin can edit

$lang_dir = __DIR__ . '/../lang/';
$languages = ['en', 'hi', 'ar', 'es', 'fr', 'de', 'zh', 'ru', 'ja'];
$current_lang = $_GET['lang'] ?? 'en';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $new_translations = [];
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'key_') === 0) {
            $original_key = substr($key, 4);
            $new_translations[$original_key] = $value;
        }
    }
    file_put_contents($lang_dir . $current_lang . '.json', json_encode($new_translations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    // Clear cache
    if (function_exists('apcu_delete')) {
        apcu_delete('lang_' . $current_lang);
    }
    $success = "Translations saved for $current_lang";
}

$current_data = json_decode(file_get_contents($lang_dir . $current_lang . '.json'), true) ?: [];
$reference_data = json_decode(file_get_contents($lang_dir . 'en.json'), true) ?: [];

renderHeader('Translation Editor');
?>
<div class="container-fluid px-4">
    <h2>Translation Editor</h2>
    <form method="post">
        <div class="mb-3">
            <label>Select Language</label>
            <select name="lang" class="form-select w-auto" onchange="location.href='?lang='+this.value">
                <?php foreach ($languages as $lang): ?>
                    <option value="<?= $lang ?>" <?= $lang === $current_lang ? 'selected' : '' ?>><?= strtoupper($lang) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr><th>Key</th><th>English (reference)</th><th><?= strtoupper($current_lang) ?> Translation</th></tr>
            </thead>
            <tbody>
                <?php foreach ($reference_data as $key => $english): ?>
                <tr>
                    <td><code><?= htmlspecialchars($key) ?></code></td>
                    <td><?= htmlspecialchars($english) ?></td>
                    <td>
                        <input type="text" name="key_<?= htmlspecialchars($key) ?>" class="form-control" 
                               value="<?= htmlspecialchars($current_data[$key] ?? '') ?>">
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button type="submit" name="save" class="btn btn-primary">Save Translations</button>
    </form>
</div>
<?php renderFooter(); ?>