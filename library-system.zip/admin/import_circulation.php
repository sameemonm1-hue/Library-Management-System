<?php
/**
 * Import Circulation Data from CSV
 * 
 * CSV format: admno, barcode, issue_date, due_date, return_date, fine, notes
 * 
 * - admno: member admission number (must exist in members table)
 * - barcode: book barcode (must exist in books table)
 * - issue_date: YYYY-MM-DD
 * - due_date: YYYY-MM-DD
 * - return_date: YYYY-MM-DD or empty (NULL)
 * - fine: decimal (optional, default 0)
 * - notes: text (optional)
 * 
 * Usage: Admin → Utilities → Import Circulation (or direct access)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Admin only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$error = '';
$success = '';
$imported = 0;
$skipped = 0;
$errors = [];

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "File upload failed. Error code: " . $file['error'];
    } else {
        $handle = fopen($file['tmp_name'], 'r');
        if ($handle === false) {
            $error = "Cannot read uploaded file.";
        } else {
            // Get headers (first row)
            $headers = fgetcsv($handle);
            if (!$headers) {
                $error = "Empty CSV file.";
            } else {
                // Normalise headers: trim, lowercase, replace spaces with underscores
                $headers = array_map(function($h) {
                    return strtolower(trim(str_replace(' ', '_', $h)));
                }, $headers);
                
                // Required columns
                $required = ['admno', 'barcode', 'issue_date', 'due_date'];
                $missing = array_diff($required, $headers);
                if (!empty($missing)) {
                    $error = "Missing required columns: " . implode(', ', $missing);
                } else {
                    // Map column indexes
                    $idx_admno = array_search('admno', $headers);
                    $idx_barcode = array_search('barcode', $headers);
                    $idx_issue = array_search('issue_date', $headers);
                    $idx_due = array_search('due_date', $headers);
                    $idx_return = array_search('return_date', $headers);
                    $idx_fine = array_search('fine', $headers);
                    $idx_notes = array_search('notes', $headers);
                    
                    $db->beginTransaction();
                    try {
                        $rowNum = 1;
                        while (($row = fgetcsv($handle)) !== false) {
                            $rowNum++;
                            $admno = trim($row[$idx_admno] ?? '');
                            $barcode = trim($row[$idx_barcode] ?? '');
                            $issue_date = trim($row[$idx_issue] ?? '');
                            $due_date = trim($row[$idx_due] ?? '');
                            $return_date = ($idx_return !== false && !empty($row[$idx_return])) ? trim($row[$idx_return]) : null;
                            $fine = ($idx_fine !== false && !empty($row[$idx_fine])) ? (float)$row[$idx_fine] : 0;
                            $notes = ($idx_notes !== false) ? trim($row[$idx_notes]) : '';
                            
                            // Validate required fields
                            if (empty($admno) || empty($barcode) || empty($issue_date) || empty($due_date)) {
                                $errors[] = "Row $rowNum: Missing required field (admno, barcode, issue_date, due_date)";
                                $skipped++;
                                continue;
                            }
                            
                            // Validate date formats
                            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $issue_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)) {
                                $errors[] = "Row $rowNum: Invalid date format (use YYYY-MM-DD)";
                                $skipped++;
                                continue;
                            }
                            if ($return_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $return_date)) {
                                $errors[] = "Row $rowNum: Invalid return_date format (use YYYY-MM-DD)";
                                $skipped++;
                                continue;
                            }
                            
                            // Check member exists and get details
                            $member = $db->prepare("SELECT name, member_category, total_fines, active_books FROM members WHERE admno = ? AND status = 'active'");
                            $member->execute([$admno]);
                            $memberData = $member->fetch();
                            if (!$memberData) {
                                $errors[] = "Row $rowNum: Member '$admno' not found or inactive";
                                $skipped++;
                                continue;
                            }
                            
                            // Check book exists and get details
                            $book = $db->prepare("SELECT title, author, category, available, quantity, item_category FROM books WHERE barcode = ?");
                            $book->execute([$barcode]);
                            $bookData = $book->fetch();
                            if (!$bookData) {
                                $errors[] = "Row $rowNum: Book with barcode '$barcode' not found";
                                $skipped++;
                                continue;
                            }
                            
                            // Calculate fine if not provided and loan is returned (or not)
                            if ($return_date && $fine == 0) {
                                $fine = calculateFine($due_date, $memberData['member_category'] ?? 'Student');
                            }
                            
                            // Insert circulation record
                            $stmt = $db->prepare("INSERT INTO circulation 
                                (admno, member_name, barcode, title, author, category, issue_date, due_date, return_date, fine, notes, is_manual, created_at) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, datetime('now'))");
                            $stmt->execute([
                                $admno,
                                $memberData['name'],
                                $barcode,
                                $bookData['title'],
                                $bookData['author'] ?? '',
                                $bookData['category'] ?? '',
                                $issue_date,
                                $due_date,
                                $return_date,
                                $fine,
                                $notes
                            ]);
                            
                            // Update book availability
                            if ($return_date) {
                                // Returned: increase available
                                $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
                                // Update member active books and fines
                                $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $admno]);
                            } else {
                                // Active loan: decrease available, increase active_books
                                $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$barcode]);
                                $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$admno]);
                            }
                            
                            $imported++;
                        }
                        $db->commit();
                        $success = "Import completed: $imported records imported, $skipped skipped.";
                        if (!empty($errors)) {
                            $success .= "<br>Errors:<br>" . implode('<br>', array_slice($errors, 0, 20));
                            if (count($errors) > 20) $success .= "<br>... and " . (count($errors) - 20) . " more.";
                        }
                        logActivity($_SESSION['username'], 'CIRCULATION_IMPORT', "Imported $imported circulation records");
                    } catch (PDOException $e) {
                        $db->rollBack();
                        $error = "Database error: " . $e->getMessage();
                    }
                }
            }
            fclose($handle);
        }
    }
}

renderHeader('Import Circulation Data');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-upload"></i> Import Circulation Data (CSV)</h2>
        <a href="../index.php" class="btn btn-primary">Back to Home</a>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-file-csv"></i> Upload CSV File</h5>
        </div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">CSV File</label>
                    <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                    <div class="form-text">Required columns: <code>admno, barcode, issue_date, due_date</code>. Optional: <code>return_date, fine, notes</code></div>
                </div>
                <button type="submit" class="btn btn-primary">Import Circulation</button>
                <a href="#" id="downloadSample" class="btn btn-secondary">Download Sample CSV</a>
            </form>
        </div>
    </div>
    
    <div class="card mt-4">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-info-circle"></i> CSV Format Guide</h5>
        </div>
        <div class="card-body">
            <p><strong>Required columns:</strong></p>
            <ul>
                <li><code>admno</code> – Member admission number (must exist in <strong>members</strong> table)</li>
                <li><code>barcode</code> – Book barcode (must exist in <strong>books</strong> table)</li>
                <li><code>issue_date</code> – Format YYYY-MM-DD</li>
                <li><code>due_date</code> – Format YYYY-MM-DD</li>
            </ul>
            <p><strong>Optional columns:</strong></p>
            <ul>
                <li><code>return_date</code> – YYYY-MM-DD (leave empty for active loans)</li>
                <li><code>fine</code> – Decimal (if empty, auto‑calculated based on due_date)</li>
                <li><code>notes</code> – Any text</li>
            </ul>
            <p><strong>Example CSV:</strong></p>
            <pre>admno,barcode,issue_date,due_date,return_date,fine,notes
MEM001,BK001,2025-01-01,2025-01-15,,0,"Initial import"
MEM002,BK002,2025-01-05,2025-01-20,2025-01-18,2.50,"Returned late"</pre>
        </div>
    </div>
</div>

<script>
document.getElementById('downloadSample')?.addEventListener('click', function(e) {
    e.preventDefault();
    let csv = "admno,barcode,issue_date,due_date,return_date,fine,notes\n";
    csv += "MEM001,BK001,2025-01-01,2025-01-15,,,\n";
    csv += "MEM002,BK002,2025-01-05,2025-01-20,2025-01-18,2.50,Returned late\n";
    let blob = new Blob(["\uFEFF" + csv], {type: 'text/csv;charset=utf-8;'});
    let link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'circulation_sample.csv';
    link.click();
    URL.revokeObjectURL(link.href);
});
</script>

<?php renderFooter(); ?>