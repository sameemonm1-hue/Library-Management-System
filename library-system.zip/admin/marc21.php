<?php
/**
 * MARC21 Support Module - Enhanced with Multi‑Target Z39.50 Search & ISBN Fetch
 * Features: Export books to MARC21, Import from MARC21 files, Edit MARC records,
 *           Search Library of Congress, NLM, DNB, BNE, NLA via Z39.50,
 *           Quick ISBN fetch from all targets.
 * 
 * Dependencies: composer require scriptotek/marc
 *               PHP YAZ extension (for Z39.50)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// Check if MARC library is available
$marcAvailable = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    if (class_exists('Scriptotek\Marc\MarcReader')) {
        $marcAvailable = true;
    } elseif (class_exists('File_MARC')) {
        $marcAvailable = true;
    }
}

// Check if YAZ extension is available for Z39.50
$yazAvailable = extension_loaded('yaz');

$db = getDB();
$settings = getSettings();
$toast = '';
$activeTab = $_GET['tab'] ?? 'export';

// ========== MARC FIELD MAPPING (Database -> MARC21) ==========
$marcMapping = [
    'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
    'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
    'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
    'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
    'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
    'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
    'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
    'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'call_number' => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
    'category'    => ['tag' => '084', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
    'price'       => ['tag' => '020', 'subfield' => 'c', 'indicators' => [' ', ' ']],
];

// ========== Z39.50 TARGETS ==========
$z39Targets = [
    'loc' => [
        'name' => 'Library of Congress (LoC)',
        'host' => 'z3950.loc.gov',
        'port' => 7090,
        'db'   => 'voyager',
        'syntax' => 'usmarc',
        'charset' => 'MARC8',
        'attr' => ['title' => 4, 'author' => 1, 'isbn' => 7]
    ],
    'nlm' => [
        'name' => 'National Library of Medicine (NLM)',
        'host' => 'locate.nlm.nih.gov',
        'port' => 210,
        'db'   => 'NLM',
        'syntax' => 'usmarc',
        'charset' => 'UTF-8',
        'attr' => ['title' => 4, 'author' => 1, 'isbn' => 7]
    ],
    'dnb' => [
        'name' => 'Deutsche Nationalbibliothek (DNB)',
        'host' => 'z3950.dnb.de',
        'port' => 2020,
        'db'   => 'DNB',
        'syntax' => 'usmarc',
        'charset' => 'UTF-8',
        'attr' => ['title' => 4, 'author' => 1, 'isbn' => 7]
    ],
    'bne' => [
        'name' => 'Biblioteca Nacional de España (BNE)',
        'host' => 'catalogo.bne.es',
        'port' => 210,
        'db'   => 'BIBLIO',
        'syntax' => 'usmarc',
        'charset' => 'MARC8',
        'attr' => ['title' => 4, 'author' => 1, 'isbn' => 7]
    ],
    'nla' => [
        'name' => 'National Library of Australia (NLA)',
        'host' => 'z3950.nla.gov.au',
        'port' => 7090,
        'db'   => 'NAT',
        'syntax' => 'usmarc',
        'charset' => 'UTF-8',
        'attr' => ['title' => 4, 'author' => 1, 'isbn' => 7]
    ]
];

// ========== HELPER FUNCTIONS ==========
function recordToMarc($book, $mapping) {
    if (class_exists('Scriptotek\Marc\Record')) {
        $record = new \Scriptotek\Marc\Record();
    } elseif (class_exists('File_MARC_Record')) {
        $record = new \File_MARC_Record();
    } else {
        throw new Exception("MARC library not available");
    }
    
    foreach ($mapping as $dbField => $marc) {
        if (empty($book[$dbField])) continue;
        
        $value = $book[$dbField];
        $tag = $marc['tag'];
        $subfield = $marc['subfield'];
        $indicators = $marc['indicators'] ?? [' ', ' '];
        
        if (class_exists('Scriptotek\Marc\Record')) {
            $field = $record->getField($tag);
            if (!$field) {
                $field = $record->addField($tag, $indicators);
            }
            $field->addSubfield($subfield, $value);
        } else {
            $field = $record->getField($tag);
            if (!$field) {
                $field = new \File_MARC_Data_Field($tag, $indicators);
                $record->appendField($field);
            }
            $field->appendSubfield(new \File_MARC_Subfield($subfield, $value));
        }
    }
    
    if (class_exists('Scriptotek\Marc\Record')) {
        $record->leader = "     nam a22     i 4500";
    } else {
        $record->setLeader("     nam a22     i 4500");
    }
    
    return $record;
}

function marcToArray($record) {
    $data = [];
    if (class_exists('Scriptotek\Marc\Record')) {
        foreach ($record->getFields() as $field) {
            $tag = $field->getTag();
            $subfields = [];
            foreach ($field->getSubfields() as $sf) {
                $subfields[$sf->getCode()] = $sf->getData();
            }
            $data[$tag] = $subfields;
        }
    } else {
        $fields = $record->getFields();
        while ($field = $fields->next()) {
            $tag = $field->getTag();
            $subfields = [];
            $subs = $field->getSubfields();
            while ($sub = $subs->next()) {
                $subfields[$sub->getCode()] = $sub->getData();
            }
            $data[$tag] = $subfields;
        }
    }
    return $data;
}

// ========== Z39.50 SEARCH FUNCTION (returns array) ==========
function z3950Search($target, $query, $field = 'title') {
    global $z39Targets;
    if (!function_exists('yaz_connect')) {
        return ['error' => 'YAZ PHP extension not installed.'];
    }
    
    $cfg = $z39Targets[$target] ?? null;
    if (!$cfg) return ['error' => 'Invalid target.'];
    
    $conn = yaz_connect($cfg['host'] . ':' . $cfg['port'] . '/' . $cfg['db']);
    if (!$conn) return ['error' => 'Connection failed.'];
    
    yaz_syntax($conn, $cfg['syntax']);
    yaz_search($conn, 'rpn', '@attr 1=' . $cfg['attr'][$field] . ' "' . yaz_escape($query) . '"');
    yaz_wait();
    
    $error = yaz_error($conn);
    if ($error) return ['error' => "Z39.50 error: $error"];
    
    $hits = yaz_hits($conn);
    $results = [];
    for ($i = 1; $i <= min($hits, 20); $i++) {
        $rec = yaz_record($conn, $i, 'string');
        if ($rec) {
            try {
                if (class_exists('Scriptotek\Marc\MarcReader')) {
                    $reader = \Scriptotek\Marc\MarcReader::fromString($rec);
                    $record = $reader->next();
                } else {
                    $reader = new \File_MARC($rec, \File_MARC::SOURCE_STRING);
                    $record = $reader->next();
                }
                if ($record) {
                    $data = marcToArray($record);
                    $results[] = [
                        'title' => $data['245']['a'] ?? 'N/A',
                        'author' => $data['100']['a'] ?? ($data['700']['a'] ?? 'N/A'),
                        'isbn' => $data['020']['a'] ?? '',
                        'publisher' => $data['260']['b'] ?? '',
                        'year' => $data['260']['c'] ?? '',
                        'pages' => $data['300']['a'] ?? '',
                        'call_number' => $data['050']['a'] ?? '',
                        'raw_marc' => $rec
                    ];
                }
            } catch (Exception $e) {
                // Skip malformed records
            }
        }
    }
    yaz_close($conn);
    return ['hits' => $hits, 'results' => $results];
}

// ========== EXPORT HANDLER ==========
if (isset($_GET['export'])) {
    $format = $_GET['format'] ?? 'mrc';
    $bookIds = $_GET['ids'] ?? [];
    if (is_string($bookIds)) $bookIds = explode(',', $bookIds);
    
    $sql = "SELECT * FROM books";
    $params = [];
    if (!empty($bookIds)) {
        $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
        $sql .= " WHERE id IN ($placeholders)";
        $params = $bookIds;
    }
    $sql .= " ORDER BY id";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();
    
    if (empty($books)) {
        showToast("No books selected for export", "warning");
        header("Location: marc21.php?tab=export");
        exit;
    }
    
    try {
        if (!$marcAvailable) throw new Exception("MARC library not installed.");
        
        if (class_exists('Scriptotek\Marc\MarcReader')) {
            $collection = new \Scriptotek\Marc\MarcCollection();
            foreach ($books as $book) {
                $record = recordToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXml();
                $filename = "export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/marc";
            }
        } else {
            $collection = new \File_MARC_Collection();
            foreach ($books as $book) {
                $record = recordToMarc($book, $marcMapping);
                $collection->addRecord($record);
            }
            if ($format === 'xml') {
                $content = $collection->toXML();
                $filename = "export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/octet-stream";
            }
        }
        
        header("Content-Type: $contentType");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Length: " . strlen($content));
        echo $content;
        exit;
    } catch (Exception $e) {
        showToast("Export failed: " . $e->getMessage(), "danger");
        header("Location: marc21.php?tab=export");
        exit;
    }
}

// ========== IMPORT HANDLER ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import'])) {
    if (!isset($_FILES['marc_file']) || $_FILES['marc_file']['error'] !== UPLOAD_ERR_OK) {
        showToast("Please select a valid MARC file (.mrc or .xml)", "danger");
        header("Location: marc21.php?tab=import");
        exit;
    }
    
    $file = $_FILES['marc_file']['tmp_name'];
    $filename = $_FILES['marc_file']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    try {
        if (!$marcAvailable) throw new Exception("MARC library not installed.");
        
        if ($ext === 'xml') {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARCXML(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        } else {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARC(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        }
        
        $imported = 0;
        $errors = 0;
        $records = ($reader instanceof \File_MARC_Collection) ? $reader : $reader->getRecords();
        
        foreach ($records as $record) {
            $data = marcToArray($record);
            $book = [];
            foreach ($marcMapping as $dbField => $marc) {
                $tag = $marc['tag'];
                $subfield = $marc['subfield'];
                $book[$dbField] = $data[$tag][$subfield] ?? '';
            }
            if (empty($book['barcode']) || empty($book['title'])) {
                $errors++;
                continue;
            }
            $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $check->execute([$book['barcode']]);
            if ($check->fetch()) {
                $stmt = $db->prepare("UPDATE books SET 
                    title = ?, author = ?, publisher = ?, isbn = ?, call_number = ?,
                    year = ?, pages = ?, subject = ?, category = ?, price = ?
                    WHERE barcode = ?");
                $stmt->execute([
                    $book['title'], $book['author'], $book['publisher'],
                    $book['isbn'], $book['call_number'], $book['year'],
                    $book['pages'], $book['subject'], $book['category'],
                    $book['price'], $book['barcode']
                ]);
            } else {
                $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, isbn, call_number,
                    year, pages, subject, category, price, quantity, available, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, datetime('now'))");
                $stmt->execute([
                    $book['barcode'], $book['title'], $book['author'], $book['publisher'],
                    $book['isbn'], $book['call_number'], $book['year'], $book['pages'],
                    $book['subject'], $book['category'], $book['price']
                ]);
            }
            $imported++;
        }
        
        showToast("Import completed: $imported records imported/updated, $errors errors", $imported > 0 ? "success" : "warning");
        logActivity($_SESSION['username'], 'MARC_IMPORT', "Imported $imported records from " . basename($filename));
        
    } catch (Exception $e) {
        showToast("Import failed: " . $e->getMessage(), "danger");
    }
    header("Location: marc21.php?tab=import");
    exit;
}

// ========== EDITOR: Load book for editing ==========
$editBook = null;
$editRecord = null;
$editMarcArray = [];
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $db->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$id]);
    $editBook = $stmt->fetch();
    if ($editBook) {
        try {
            $editRecord = recordToMarc($editBook, $marcMapping);
            $editMarcArray = marcToArray($editRecord);
        } catch (Exception $e) {
            $editMarcArray = [];
        }
    }
}

// ========== SAVE EDITED MARC ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marc'])) {
    $bookId = (int)$_POST['book_id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $isbn = $_POST['isbn'];
    $call_number = $_POST['call_number'];
    $year = $_POST['year'];
    $pages = $_POST['pages'];
    $subject = $_POST['subject'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $barcode = $_POST['barcode'];
    
    $stmt = $db->prepare("UPDATE books SET 
        title = ?, author = ?, publisher = ?, isbn = ?, call_number = ?,
        year = ?, pages = ?, subject = ?, category = ?, price = ?, barcode = ?
        WHERE id = ?");
    $stmt->execute([$title, $author, $publisher, $isbn, $call_number,
                   $year, $pages, $subject, $category, $price, $barcode, $bookId]);
    showToast("Book updated successfully", "success");
    logActivity($_SESSION['username'], 'MARC_EDIT', "Edited book ID $bookId");
    header("Location: marc21.php?tab=editor");
    exit;
}

// ========== ISBN FETCH FROM ALL TARGETS ==========
$isbnFetchResults = null;
if (isset($_GET['fetch_isbn']) && !empty($_GET['isbn'])) {
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    $isbnFetchResults = [];
    foreach ($z39Targets as $key => $target) {
        $result = z3950Search($key, $isbn, 'isbn');
        if (!isset($result['error']) && !empty($result['results'])) {
            $isbnFetchResults[$key] = [
                'target_name' => $target['name'],
                'records' => $result['results']
            ];
        }
    }
}

renderHeader('MARC21 Support');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-book"></i> MARC21 Support</h2>
        <div>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>

    <?php if (!$marcAvailable): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle"></i> MARC library not installed. 
        Run <code>composer require scriptotek/marc</code> in your project root to enable all features.
        <hr>
        <strong>Alternative:</strong> You can still export/import using basic CSV/Excel from the Utilities page.
    </div>
    <?php endif; ?>

    <?php if (!$yazAvailable): ?>
    <div class="alert alert-warning">
        <i class="fas fa-info-circle"></i> PHP YAZ extension is not installed. Z39.50 search will not work.
        To enable it, install <code>php-yaz</code> and restart your web server.
    </div>
    <?php endif; ?>

    <ul class="nav nav-tabs mb-3">
        <li class="nav-item"><a class="nav-link <?= $activeTab === 'export' ? 'active' : '' ?>" href="?tab=export"><i class="fas fa-download"></i> Export to MARC</a></li>
        <li class="nav-item"><a class="nav-link <?= $activeTab === 'import' ? 'active' : '' ?>" href="?tab=import"><i class="fas fa-upload"></i> Import from MARC</a></li>
        <li class="nav-item"><a class="nav-link <?= $activeTab === 'editor' ? 'active' : '' ?>" href="?tab=editor"><i class="fas fa-edit"></i> MARC Editor</a></li>
        <li class="nav-item"><a class="nav-link <?= $activeTab === 'z3950' ? 'active' : '' ?>" href="?tab=z3950"><i class="fas fa-search"></i> Z39.50 Search</a></li>
    </ul>

    <div class="tab-content">
        <!-- EXPORT TAB (unchanged) -->
        <div class="tab-pane fade <?= $activeTab === 'export' ? 'show active' : '' ?>" id="export">
            <div class="card">
                <div class="card-header bg-success text-white"><i class="fas fa-download"></i> Export Books to MARC21</div>
                <div class="card-body">
                    <form method="get" action="">
                        <input type="hidden" name="tab" value="export">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Select Books to Export</label>
                                <select name="ids[]" multiple class="form-select" size="10">
                                    <?php
                                    $allBooks = $db->query("SELECT id, barcode, title FROM books ORDER BY title LIMIT 500");
                                    foreach ($allBooks as $book) {
                                        echo "<option value='{$book['id']}'>{$book['barcode']} - {$book['title']}</option>";
                                    }
                                    ?>
                                </select>
                                <small class="text-muted">Hold Ctrl (or Cmd) to select multiple. Leave empty to export all books.</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Export Format</label>
                                <select name="format" class="form-select">
                                    <option value="mrc">MARC Binary (.mrc)</option>
                                    <option value="xml">MARCXML (.xml)</option>
                                </select>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" name="export" value="1" class="btn btn-success btn-lg px-5" <?= !$marcAvailable ? 'disabled' : '' ?>>
                                <i class="fas fa-file-export"></i> Export Now
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- IMPORT TAB (unchanged) -->
        <div class="tab-pane fade <?= $activeTab === 'import' ? 'show active' : '' ?>" id="import">
            <div class="card">
                <div class="card-header bg-warning text-white"><i class="fas fa-upload"></i> Import MARC21 File</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">MARC File (.mrc or .xml)</label>
                            <input type="file" name="marc_file" class="form-control" accept=".mrc,.xml" required>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> The system will match records by barcode. If a book with the same barcode exists, it will be updated; otherwise a new book will be added.
                        </div>
                        <div class="text-center">
                            <button type="submit" name="import" value="1" class="btn btn-warning btn-lg px-5" <?= !$marcAvailable ? 'disabled' : '' ?>>
                                <i class="fas fa-file-import"></i> Import
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- EDITOR TAB (unchanged) -->
        <div class="tab-pane fade <?= $activeTab === 'editor' ? 'show active' : '' ?>" id="editor">
            <div class="card">
                <div class="card-header bg-info text-white"><i class="fas fa-edit"></i> MARC Record Editor</div>
                <div class="card-body">
                    <?php if (!isset($_GET['edit'])): ?>
                        <form method="get" action="" class="mb-4">
                            <input type="hidden" name="tab" value="editor">
                            <div class="row">
                                <div class="col-md-8">
                                    <label>Select Book to Edit</label>
                                    <select name="edit" class="form-select">
                                        <option value="">-- Choose a book --</option>
                                        <?php
                                        $books = $db->query("SELECT id, barcode, title FROM books ORDER BY title LIMIT 500");
                                        foreach ($books as $b) {
                                            echo "<option value='{$b['id']}'>{$b['barcode']} - {$b['title']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-4 align-self-end">
                                    <button type="submit" class="btn btn-primary">Load MARC Record</button>
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        <h5>Editing: <?= htmlspecialchars($editBook['title']) ?> (<?= htmlspecialchars($editBook['barcode']) ?>)</h5>
                        <form method="post">
                            <input type="hidden" name="book_id" value="<?= $editBook['id'] ?>">
                            <div class="row g-3">
                                <div class="col-md-6"><label>Barcode *</label><input type="text" name="barcode" class="form-control" value="<?= htmlspecialchars($editBook['barcode']) ?>" required></div>
                                <div class="col-md-6"><label>Title *</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($editBook['title']) ?>" required></div>
                                <div class="col-md-6"><label>Author</label><input type="text" name="author" class="form-control" value="<?= htmlspecialchars($editBook['author'] ?? '') ?>"></div>
                                <div class="col-md-6"><label>Publisher</label><input type="text" name="publisher" class="form-control" value="<?= htmlspecialchars($editBook['publisher'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>ISBN</label><input type="text" name="isbn" class="form-control" value="<?= htmlspecialchars($editBook['isbn'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Call Number</label><input type="text" name="call_number" class="form-control" value="<?= htmlspecialchars($editBook['call_number'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Year</label><input type="text" name="year" class="form-control" value="<?= htmlspecialchars($editBook['year'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Pages</label><input type="number" name="pages" class="form-control" value="<?= htmlspecialchars($editBook['pages'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Subject</label><input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($editBook['subject'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Category</label><input type="text" name="category" class="form-control" value="<?= htmlspecialchars($editBook['category'] ?? '') ?>"></div>
                                <div class="col-md-4"><label>Price</label><input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($editBook['price'] ?? 0) ?>"></div>
                            </div>
                            <div class="mt-4 text-center">
                                <button type="submit" name="save_marc" class="btn btn-primary px-5">Save Changes</button>
                                <a href="marc21.php?tab=editor" class="btn btn-secondary">Cancel</a>
                            </div>
                        </form>
                        <hr>
                        <div class="mt-3">
                            <h6>MARC21 Preview (raw data)</h6>
                            <pre class="bg-light p-3 border rounded" style="max-height: 300px; overflow: auto;"><?php 
                                if ($editRecord) {
                                    if (method_exists($editRecord, 'toRaw')) {
                                        echo htmlspecialchars($editRecord->toRaw());
                                    } else {
                                        print_r($editMarcArray);
                                    }
                                } else {
                                    echo "No MARC representation available.";
                                }
                            ?></pre>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Z39.50 SEARCH TAB (with ISBN fetch section) -->
        <div class="tab-pane fade <?= $activeTab === 'z3950' ? 'show active' : '' ?>" id="z3950">
            <div class="card mb-4">
                <div class="card-header bg-secondary text-white">
                    <i class="fas fa-search"></i> Z39.50 Search – Multiple Catalogs
                </div>
                <div class="card-body">
                    <?php if (!$yazAvailable): ?>
                        <div class="alert alert-danger">YAZ extension not installed. Cannot perform Z39.50 searches.</div>
                    <?php else: ?>
                        <!-- Quick ISBN Fetch Section -->
                        <div class="alert alert-info">
                            <strong><i class="fas fa-barcode"></i> Quick ISBN Fetch:</strong> Enter an ISBN to search all libraries at once.
                        </div>
                        <form method="get" action="" class="mb-4">
                            <input type="hidden" name="tab" value="z3950">
                            <div class="row g-2">
                                <div class="col-md-8">
                                    <input type="text" name="isbn" class="form-control" placeholder="Enter ISBN (e.g., 9780132350884)" value="<?= htmlspecialchars($_GET['isbn'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" name="fetch_isbn" value="1" class="btn btn-primary w-100">
                                        <i class="fas fa-cloud-download-alt"></i> Fetch from All Libraries
                                    </button>
                                </div>
                            </div>
                        </form>

                        <?php if ($isbnFetchResults !== null): ?>
                            <hr>
                            <h5>ISBN Search Results for: <?= htmlspecialchars($_GET['isbn']) ?></h5>
                            <?php if (empty($isbnFetchResults)): ?>
                                <div class="alert alert-warning">No records found for this ISBN in any of the configured libraries.</div>
                            <?php else: ?>
                                <?php foreach ($isbnFetchResults as $sourceKey => $sourceData): ?>
                                    <div class="card mb-3">
                                        <div class="card-header bg-light">
                                            <strong><?= htmlspecialchars($sourceData['target_name']) ?></strong>
                                        </div>
                                        <div class="card-body">
                                            <?php foreach ($sourceData['records'] as $rec): ?>
                                                <div class="mb-3 border-bottom pb-2">
                                                    <div class="row">
                                                        <div class="col-md-9">
                                                            <h6><?= htmlspecialchars($rec['title']) ?></h6>
                                                            <p><strong>Author:</strong> <?= htmlspecialchars($rec['author']) ?><br>
                                                            <strong>ISBN:</strong> <?= htmlspecialchars($rec['isbn']) ?><br>
                                                            <strong>Publisher:</strong> <?= htmlspecialchars($rec['publisher']) ?> (<?= htmlspecialchars($rec['year']) ?>)<br>
                                                            <strong>Call Number:</strong> <?= htmlspecialchars($rec['call_number']) ?></p>
                                                        </div>
                                                        <div class="col-md-3 text-end">
                                                            <button class="btn btn-sm btn-success" onclick="importZ3950Record(<?= htmlspecialchars(json_encode($rec)) ?>)">
                                                                <i class="fas fa-database"></i> Import
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php endif; ?>

                        <hr>
                        <h5>Advanced Search (Choose Target & Field)</h5>
                        <form method="get" action="">
                            <input type="hidden" name="tab" value="z3950">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label">Search Target</label>
                                    <select name="target" class="form-select">
                                        <?php foreach ($z39Targets as $key => $targetInfo): ?>
                                            <option value="<?= $key ?>" <?= ($_GET['target'] ?? 'loc') === $key ? 'selected' : '' ?>><?= htmlspecialchars($targetInfo['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Field</label>
                                    <select name="field" class="form-select">
                                        <option value="title" <?= ($_GET['field'] ?? 'title') === 'title' ? 'selected' : '' ?>>Title</option>
                                        <option value="author" <?= ($_GET['field'] ?? 'title') === 'author' ? 'selected' : '' ?>>Author</option>
                                        <option value="isbn" <?= ($_GET['field'] ?? 'title') === 'isbn' ? 'selected' : '' ?>>ISBN</option>
                                    </select>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label">Query</label>
                                    <input type="text" name="query" class="form-control" value="<?= htmlspecialchars($_GET['query'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-2 align-self-end">
                                    <button type="submit" name="z3950" value="1" class="btn btn-secondary w-100">Search</button>
                                </div>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Existing Z39.50 search results display (same as before) -->
            <?php
            // This block displays results from the manual search (not the ISBN fetch)
            $z39Results = null;
            if (isset($_GET['z3950']) && $yazAvailable && $marcAvailable && !isset($_GET['fetch_isbn'])) {
                $query = trim($_GET['query']);
                $target = $_GET['target'] ?? 'loc';
                $field = $_GET['field'] ?? 'title';
                if (!empty($query)) {
                    $z39Results = z3950Search($target, $query, $field);
                }
            }
            if ($z39Results !== null && !isset($_GET['fetch_isbn'])):
            ?>
                <div class="card mt-3">
                    <div class="card-header bg-info text-white">Search Results</div>
                    <div class="card-body">
                        <?php if (isset($z39Results['error'])): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($z39Results['error']) ?></div>
                        <?php else: ?>
                            <div class="alert alert-info">Found <?= $z39Results['hits'] ?> record(s). Showing up to 20.</div>
                            <?php if (empty($z39Results['results'])): ?>
                                <div class="alert alert-warning">No records could be retrieved or parsed.</div>
                            <?php else: ?>
                                <?php foreach ($z39Results['results'] as $rec): ?>
                                    <div class="card mb-3 border-secondary">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-9">
                                                    <h5><?= htmlspecialchars($rec['title']) ?></h5>
                                                    <p><strong>Author:</strong> <?= htmlspecialchars($rec['author']) ?><br>
                                                    <strong>ISBN:</strong> <?= htmlspecialchars($rec['isbn']) ?><br>
                                                    <strong>Publisher:</strong> <?= htmlspecialchars($rec['publisher']) ?> (<?= htmlspecialchars($rec['year']) ?>)<br>
                                                    <strong>Call Number:</strong> <?= htmlspecialchars($rec['call_number']) ?></p>
                                                </div>
                                                <div class="col-md-3 text-end">
                                                    <button class="btn btn-sm btn-success" onclick="importZ3950Record(<?= htmlspecialchars(json_encode($rec)) ?>)">
                                                        <i class="fas fa-database"></i> Import
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function importZ3950Record(record) {
    if (confirm('Import this record into your library? A new barcode will be generated automatically.')) {
        fetch('marc21_ajax.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'import_from_z3950', record: record})
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('Book imported successfully!');
                location.reload();
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(err => alert('Network error: ' + err));
    }
}
</script>

<?php renderFooter(); ?>