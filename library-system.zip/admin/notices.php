<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

// Handle add/edit notice
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if(isset($_POST['add_notice'])) {
            $stmt = $db->prepare("INSERT INTO notices (title, content, is_active) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['title'], $_POST['content'], isset($_POST['is_active']) ? 1 : 0]);
            showToast("Notice added successfully", "success");
        } elseif(isset($_POST['update_notice'])) {
            $stmt = $db->prepare("UPDATE notices SET title = ?, content = ?, is_active = ? WHERE id = ?");
            $stmt->execute([$_POST['title'], $_POST['content'], isset($_POST['is_active']) ? 1 : 0, $_POST['id']]);
            showToast("Notice updated successfully", "success");
        }
        logActivity($_SESSION['username'], 'NOTICE_' . (isset($_POST['add_notice']) ? 'ADD' : 'UPDATE'), $_POST['title']);
    } catch(PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
    header("Location: notices.php");
    exit;
}

// Handle delete
if(isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM notices WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    showToast("Notice deleted", "success");
    header("Location: notices.php");
    exit;
}

$notices = $db->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();

renderHeader('Manage Notices');
?>

<style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
    }
    body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    
    .settings-bar { display: none !important; }
    
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .card-header {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .table thead th {
        background: var(--primary-color);
        color: white;
        border-bottom: none;
    }
    .modal-header {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .modal-header .btn-close {
        filter: invert(1);
    }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    .stat-card .stat-value {
        font-size: 28px;
        font-weight: 700;
    }
    .stat-card .stat-label {
        opacity: 0.9;
    }
    
    @media print {
        .no-print { display: none !important; }
        .settings-bar { display: none !important; }
        .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
        .card-header { background: #f8f9fa !important; color: #333 !important; }
        .table thead th { background: #333 !important; color: white !important; }
    }
</style>

<div class="container-fluid px-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color);"><i class="fas fa-bell"></i> Manage Notices</h2>
        <div class="no-print">
            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addNoticeModal">
                <i class="fas fa-plus"></i> Add Notice
            </button>
            <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>
    
    <!-- Statistics -->
    <div class="row g-3 mb-4 no-print">
        <div class="col-md-4 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count($notices) ?></div>
                <div class="stat-label">Total Notices</div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count(array_filter($notices, fn($n) => $n['is_active'])) ?></div>
                <div class="stat-label">Active</div>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count(array_filter($notices, fn($n) => !$n['is_active'])) ?></div>
                <div class="stat-label">Inactive</div>
            </div>
        </div>
    </div>
    
    <div class="card border-0 shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> Library Notices</span>
            <span class="badge bg-light text-dark"><?= count($notices) ?> notices</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Content</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Created</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($notices as $notice): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($notice['title']) ?></strong></td>
                            <td><?= htmlspecialchars(substr($notice['content'], 0, 100)) ?>...</td>
                            <td class="text-center">
                                <span class="badge <?= $notice['is_active'] ? 'bg-success' : 'bg-secondary' ?>">
                                    <?= $notice['is_active'] ? 'Active' : 'Inactive' ?>
                                </span>
                             </td>
                            <td class="text-center"><?= formatDate($notice['created_at']) ?></td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-warning" onclick="editNotice(<?= $notice['id'] ?>, '<?= addslashes($notice['title']) ?>', '<?= addslashes($notice['content']) ?>', <?= $notice['is_active'] ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?= $notice['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete this notice?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                             </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($notices)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No notices found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Notice Modal -->
<div class="modal fade" id="addNoticeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus"></i> Add Notice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Content (HTML supported)</label>
                        <textarea name="content" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" checked>
                            <label class="form-check-label">Active (show on OPAC)</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_notice" class="btn btn-primary">Add Notice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Notice Modal -->
<div class="modal fade" id="editNoticeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit Notice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Title</label>
                        <input type="text" name="title" id="edit_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Content (HTML supported)</label>
                        <textarea name="content" id="edit_content" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" id="edit_active">
                            <label class="form-check-label">Active (show on OPAC)</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_notice" class="btn btn-primary">Update Notice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editNotice(id, title, content, active) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_content').value = content;
    document.getElementById('edit_active').checked = active == 1;
    new bootstrap.Modal(document.getElementById('editNoticeModal')).show();
}
</script>

<?php renderFooter(); ?>