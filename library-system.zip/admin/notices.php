<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// Handle add/edit notice
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if(isset($_POST['add_notice'])) {
            $stmt = $db->prepare("INSERT INTO notices (title, content, is_active) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['title'], $_POST['content'], isset($_POST['is_active']) ? 1 : 0]);
            showToast("Notice added successfully", "success");
        } elseif(isset($_POST['update_notice'])) {
            $stmt = $db->prepare("UPDATE notices SET title = ?, content = ?, is_active = ? WHERE id = ?");
            $stmt->execute([$_POST['title'], $_POST['content'], isset($_POST['is_active']) ? 1 : 0, $_POST['id']]);
            showToast("Notice updated successfully", "success");
        }
        logActivity($_SESSION['username'], 'NOTICE_' . (isset($_POST['add_notice']) ? 'ADD' : 'UPDATE'), $_POST['title']);
    } catch(PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
    header("Location: notices.php");
    exit;
}

// Handle delete
if(isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM notices WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    showToast("Notice deleted", "success");
    header("Location: notices.php");
    exit;
}

$notices = $db->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();

renderHeader('Manage Notices');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-bell"></i> Manage Notices</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNoticeModal">
            <i class="fas fa-plus"></i> Add Notice
        </button>
    </div>
    
    <div class="card">
        <div class="card-header">Library Notices</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Title</th><th>Content</th><th>Status</th><th>Created</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($notices as $notice): ?>
                        <tr>
                            <td><?= htmlspecialchars($notice['title']) ?></td>
                            <td><?= htmlspecialchars(substr($notice['content'], 0, 100)) ?>...</td>
                            <td>
                                <span class="badge <?= $notice['is_active'] ? 'bg-success' : 'bg-secondary' ?>">
                                    <?= $notice['is_active'] ? 'Active' : 'Inactive' ?>
                                </span>
                             </td>
                            <td><?= formatDate($notice['created_at']) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-warning" onclick="editNotice(<?= $notice['id'] ?>, '<?= addslashes($notice['title']) ?>', '<?= addslashes($notice['content']) ?>', <?= $notice['is_active'] ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?= $notice['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete this notice?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                             </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($notices)): ?>
                        <tr><td colspan="5" class="text-center">No notices</td></tr>
                        <?php endif; ?>
                    </tbody>
                <table>
            </div>
        </div>
    </div>
</div>

<!-- Add Notice Modal -->
<div class="modal fade" id="addNoticeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Notice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Content (HTML supported)</label>
                        <textarea name="content" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" checked>
                            <label class="form-check-label">Active (show on OPAC)</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_notice" class="btn btn-primary">Add Notice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Notice Modal -->
<div class="modal fade" id="editNoticeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Notice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" name="title" id="edit_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Content (HTML supported)</label>
                        <textarea name="content" id="edit_content" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_active" id="edit_active">
                            <label class="form-check-label">Active (show on OPAC)</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_notice" class="btn btn-primary">Update Notice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editNotice(id, title, content, active) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_content').value = content;
    document.getElementById('edit_active').checked = active == 1;
    new bootstrap.Modal(document.getElementById('editNoticeModal')).show();
}
</script>

<?php renderFooter(); ?>