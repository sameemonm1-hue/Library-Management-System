<?php
/**
 * Migration script: SQLite → MySQL
 * Run: php migrate_sqlite_to_mysql.php
 */

// Configuration
$sqliteFile = __DIR__ . '/database.sqlite'; // adjust path
$mysqlHost = 'localhost';
$mysqlDb   = 'library_erp';
$mysqlUser = 'root';
$mysqlPass = '';

try {
    // Connect to SQLite
    $sqlite = new PDO("sqlite:$sqliteFile");
    $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Connect to MySQL (without database, then create it)
    $mysql = new PDO("mysql:host=$mysqlHost;charset=utf8mb4", $mysqlUser, $mysqlPass);
    $mysql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $mysql->exec("CREATE DATABASE IF NOT EXISTS `$mysqlDb` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $mysql->exec("USE `$mysqlDb`");

    // Create tables using the new db.php (or copy schema from above)
    require_once __DIR__ . '/config/db.php';
    createTables(); // defined in db.php

    // List of tables to migrate
    $tables = ['users', 'settings', 'institution', 'members', 'books', 'circulation'];

    foreach ($tables as $table) {
        echo "Migrating table: $table\n";

        // Get data from SQLite
        $rows = $sqlite->query("SELECT * FROM $table")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) continue;

        // Build INSERT query
        $columns = array_keys($rows[0]);
        $placeholders = ':' . implode(', :', $columns);
        $insert = $mysql->prepare("INSERT INTO $table (" . implode(',', $columns) . ") VALUES ($placeholders)");

        foreach ($rows as $row) {
            // Convert SQLite date formats if needed (e.g., 'now' to MySQL NOW())
            foreach ($row as $key => $value) {
                if ($value === 'now' || $value === 'CURRENT_TIMESTAMP') {
                    $row[$key] = date('Y-m-d H:i:s');
                }
            }
            $insert->execute($row);
        }
        echo "  -> " . count($rows) . " records migrated.\n";
    }

    echo "Migration completed successfully.\n";
} catch (Exception $e) {
    die("Error: " . $e->getMessage() . "\n");
}