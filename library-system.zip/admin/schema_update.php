<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireLogin();
requireAdmin();

$db = getDB();
require_once __DIR__ . '/../config/MigrationManager.php';
$mgr = new MigrationManager($db, __DIR__ . '/../migrations/');

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_migrations'])) {
    $result = $mgr->runPending();
    if (!empty($result['run'])) {
        $message = "Applied: " . implode(', ', $result['run']);
    }
    if (!empty($result['errors'])) {
        $error = "Errors: " . print_r($result['errors'], true);
    }
}

$status = $mgr->getStatus();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Schema Updater</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">
    <h1>Database Schema Updater</h1>
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= nl2br(htmlspecialchars($error)) ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <h3>Applied Migrations</h3>
            <ul class="list-group">
                <?php foreach ($status['applied'] as $m): ?>
                    <li class="list-group-item list-group-item-success">✅ <?= htmlspecialchars($m) ?></li>
                <?php endforeach; ?>
                <?php if (empty($status['applied'])): ?>
                    <li class="list-group-item">No migrations applied yet.</li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="col-md-6">
            <h3>Pending Migrations</h3>
            <ul class="list-group">
                <?php foreach ($status['pending'] as $m): ?>
                    <li class="list-group-item list-group-item-warning">⏳ <?= htmlspecialchars($m) ?></li>
                <?php endforeach; ?>
                <?php if (empty($status['pending'])): ?>
                    <li class="list-group-item">All migrations applied.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <form method="post" class="mt-4">
        <button type="submit" name="run_migrations" class="btn btn-primary" <?= empty($status['pending']) ? 'disabled' : '' ?>>
            Run Pending Migrations
        </button>
        <a href="../index.php" class="btn btn-secondary">Back to Dashboard</a>
    </form>
</body>
</html>