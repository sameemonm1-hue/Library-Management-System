<?php
/**
 * Meilisearch Sync Trigger
 * 
 * Call this script to update Meilisearch indexes after changes.
 * Can be accessed via AJAX, cron, or manually.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Only admin can trigger manually (optional)
if (isset($_GET['manual']) && (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin')) {
    http_response_code(403);
    echo "Unauthorized";
    exit;
}

$syncScript = __DIR__ . '/../cron/sync_meilisearch.php';
if (!file_exists($syncScript)) {
    http_response_code(500);
    echo "Sync script not found: $syncScript";
    exit;
}

// Run in background (non-blocking)
if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
    exec("start /B php \"$syncScript\" > NUL 2>&1");
} else {
    exec("php \"$syncScript\" > /dev/null 2>&1 &");
}

if (isset($_GET['manual'])) {
    showToast("Meilisearch sync triggered in background.", "success");
    header("Location: books.php");
    exit;
} else {
    echo "Sync triggered.";
}