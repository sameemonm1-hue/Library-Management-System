<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$message = '';
$error = '';

// Define staff photo directory
$staffPhotoDir = UPLOAD_DIR . 'staff/';
if (!is_dir($staffPhotoDir)) {
    mkdir($staffPhotoDir, 0777, true);
}

// Helper: process image – resize if GD available, otherwise just copy
function processUploadedImage($sourcePath, $targetPath, $maxWidth = 200, $maxHeight = 200) {
    if (!extension_loaded('gd')) {
        return copy($sourcePath, $targetPath);
    }
    list($width, $height, $type) = @getimagesize($sourcePath);
    if (!$width) return false;
    $ratio = $width / $height;
    if ($width > $height) {
        $newWidth = $maxWidth;
        $newHeight = $maxWidth / $ratio;
    } else {
        $newHeight = $maxHeight;
        $newWidth = $maxHeight * $ratio;
    }
    $newImage = imagecreatetruecolor($newWidth, $newHeight);
    switch ($type) {
        case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($sourcePath); break;
        case IMAGETYPE_PNG: $src = imagecreatefrompng($sourcePath); break;
        case IMAGETYPE_GIF: $src = imagecreatefromgif($sourcePath); break;
        case IMAGETYPE_WEBP: $src = imagecreatefromwebp($sourcePath); break;
        default: return false;
    }
    imagecopyresampled($newImage, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    switch ($type) {
        case IMAGETYPE_JPEG: imagejpeg($newImage, $targetPath, 85); break;
        case IMAGETYPE_PNG: imagepng($newImage, $targetPath, 8); break;
        case IMAGETYPE_GIF: imagegif($newImage, $targetPath); break;
        case IMAGETYPE_WEBP: imagewebp($newImage, $targetPath, 85); break;
    }
    imagedestroy($src);
    imagedestroy($newImage);
    return true;
}

// Helper: get base64 from file path
function getBase64Image($path) {
    if (empty($path) || !file_exists($path)) return '';
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $mime = 'image/jpeg';
    if ($ext == 'png') $mime = 'image/png';
    elseif ($ext == 'gif') $mime = 'image/gif';
    elseif ($ext == 'webp') $mime = 'image/webp';
    $data = file_get_contents($path);
    if ($data === false) return '';
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Handle add / update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? 0;
    $name = trim($_POST['name'] ?? '');
    $designation = trim($_POST['designation'] ?? '');
    $sort_order = (int)($_POST['sort_order'] ?? 0);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    $photo_path = '';
    $remove_photo = isset($_POST['remove_photo']) ? true : false;
    
    // Get existing photo path for update
    if ($id) {
        $stmt = $db->prepare("SELECT photo_path FROM staff_profiles WHERE id = ?");
        $stmt->execute([$id]);
        $oldPhoto = $stmt->fetchColumn();
        if ($remove_photo && $oldPhoto && file_exists($oldPhoto)) {
            unlink($oldPhoto);
            $oldPhoto = '';
        }
    } else {
        $oldPhoto = '';
    }
    
    // Handle file upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $_FILES['photo']['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mime, $allowed)) {
            $error = "Invalid file type. Only JPG, PNG, GIF, WEBP allowed.";
        } elseif ($_FILES['photo']['size'] > 5 * 1024 * 1024) {
            $error = "File too large. Max 5MB.";
        } else {
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $newName = 'staff_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $tempFile = $staffPhotoDir . 'temp_' . $newName;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $tempFile)) {
                $finalFile = $staffPhotoDir . $newName;
                if (processUploadedImage($tempFile, $finalFile, 200, 200)) {
                    unlink($tempFile);
                    $photo_path = 'uploads/staff/' . $newName;
                    if ($oldPhoto && file_exists($oldPhoto)) unlink($oldPhoto);
                } else {
                    if (rename($tempFile, $finalFile)) {
                        $photo_path = 'uploads/staff/' . $newName;
                        if ($oldPhoto && file_exists($oldPhoto)) unlink($oldPhoto);
                    } else {
                        $error = "Failed to save image.";
                        if (file_exists($tempFile)) unlink($tempFile);
                    }
                }
            } else {
                $error = "Failed to upload file. Check directory permissions.";
            }
        }
    } elseif (!$remove_photo && $oldPhoto) {
        $photo_path = $oldPhoto;
    }
    
    if (empty($error)) {
        try {
            if ($id) {
                $sql = "UPDATE staff_profiles SET name = ?, designation = ?, sort_order = ?, is_active = ?";
                $params = [$name, $designation, $sort_order, $is_active];
                if ($photo_path) {
                    $sql .= ", photo_path = ?";
                    $params[] = $photo_path;
                }
                $sql .= " WHERE id = ?";
                $params[] = $id;
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $message = "Staff profile updated successfully.";
            } else {
                $stmt = $db->prepare("INSERT INTO staff_profiles (name, designation, sort_order, is_active, photo_path) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $designation, $sort_order, $is_active, $photo_path]);
                $message = "Staff profile added successfully.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Handle AJAX reorder
if (isset($_POST['reorder']) && isset($_POST['order'])) {
    header('Content-Type: application/json');
    $order = json_decode($_POST['order'], true);
    if (is_array($order)) {
        $db->beginTransaction();
        try {
            foreach ($order as $idx => $id) {
                $newOrder = $idx + 1;
                $stmt = $db->prepare("UPDATE staff_profiles SET sort_order = ? WHERE id = ?");
                $stmt->execute([$newOrder, (int)$id]);
            }
            $db->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid order data']);
    }
    exit;
}

// Handle toggle active status via AJAX
if (isset($_POST['toggle_active']) && isset($_POST['id'])) {
    header('Content-Type: application/json');
    $id = (int)$_POST['id'];
    $stmt = $db->prepare("SELECT is_active FROM staff_profiles WHERE id = ?");
    $stmt->execute([$id]);
    $current = $stmt->fetchColumn();
    $newStatus = $current ? 0 : 1;
    $update = $db->prepare("UPDATE staff_profiles SET is_active = ? WHERE id = ?");
    $update->execute([$newStatus, $id]);
    echo json_encode(['success' => true, 'new_status' => $newStatus]);
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $db->prepare("SELECT photo_path FROM staff_profiles WHERE id = ?");
    $stmt->execute([$id]);
    $photo = $stmt->fetchColumn();
    if ($photo && file_exists($photo)) unlink($photo);
    $db->prepare("DELETE FROM staff_profiles WHERE id = ?")->execute([$id]);
    $message = "Staff deleted.";
    header("Location: staff.php");
    exit;
}

// Fetch all staff
$staff = $db->query("SELECT * FROM staff_profiles ORDER BY sort_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);

renderHeader('Manage Staff Profiles');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-user-tie"></i> Manage Staff Profiles</h2>
        <div>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
            <a href="settings.php" class="btn btn-secondary"><i class="fas fa-cog"></i> System Settings</a>
            <button type="button" class="btn btn-info" onclick="window.open('../index.php', '_blank')"><i class="fas fa-eye"></i> View Gallery</button>
        </div>
    </div>
    
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-5">
            <div class="card shadow-sm rounded-4">
                <div class="card-header bg-primary text-white">Add / Edit Staff</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" id="staffForm">
                        <input type="hidden" name="id" id="staff_id">
                        <div class="mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" id="staff_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Designation *</label>
                            <input type="text" name="designation" id="staff_designation" class="form-control" required placeholder="e.g., Head Librarian, Assistant Librarian">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Photo (JPG, PNG, GIF, WEBP, max 5MB)</label>
                            <input type="file" name="photo" class="form-control" accept="image/*" id="staff_photo">
                            <div id="photoPreview" class="mt-2" style="display:none;">
                                <img id="previewImg" style="height:100px; border-radius:8px;">
                            </div>
                            <div id="currentPhotoContainer" class="mt-2" style="display:none;">
                                <img id="currentPhotoImg" style="height:100px; border-radius:8px;">
                                <div class="form-check mt-1">
                                    <input class="form-check-input" type="checkbox" name="remove_photo" id="removePhotoCheck" value="1">
                                    <label class="form-check-label text-danger" for="removePhotoCheck">Remove current photo</label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Sort Order</label>
                            <input type="number" name="sort_order" id="staff_sort_order" class="form-control" value="0">
                            <small class="text-muted">Lower numbers appear first. You can also drag & drop to reorder.</small>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" name="is_active" id="staff_active" class="form-check-input" value="1" checked>
                            <label class="form-check-label">Active (show on login page)</label>
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Staff</button>
                        <button type="button" class="btn btn-secondary" onclick="resetForm()"><i class="fas fa-undo"></i> New</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-7">
            <div class="card shadow-sm rounded-4">
                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                    <span><i class="fas fa-list"></i> Existing Staff Profiles</span>
                    <div class="input-group w-50">
                        <input type="text" id="staffSearch" class="form-control form-control-sm" placeholder="Search by name/designation...">
                        <button class="btn btn-sm btn-light" onclick="document.getElementById('staffSearch').value=''; filterStaff();"><i class="fas fa-times"></i></button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="staffTable">
                            <thead>
                                <tr><th style="width:30px"><i class="fas fa-grip-vertical"></i></th><th>Photo</th><th>Name</th><th>Designation</th><th>Order</th><th>Status</th><th>Actions</th></tr>
                            </thead>
                            <tbody id="staffSortable">
                                <?php if (empty($staff)): ?>
                                    <tr><td colspan="7" class="text-center">No staff profiles found. Add your first staff member.<?php echo ' '; ?></td></tr>
                                <?php else: ?>
                                    <?php foreach ($staff as $s): ?>
                                        <?php 
                                            $photoBase64 = '';
                                            if (!empty($s['photo_path']) && file_exists($s['photo_path'])) {
                                                $photoBase64 = getBase64Image($s['photo_path']);
                                            }
                                        ?>
                                        <tr data-id="<?= $s['id'] ?>">
                                            <td class="drag-handle text-center"><i class="fas fa-grip-vertical text-muted"></i></td>
                                            <td>
                                                <?php if ($photoBase64): ?>
                                                    <img src="<?= $photoBase64 ?>" style="width:45px; height:45px; object-fit:cover; border-radius:50%;" alt="Staff Photo">
                                                <?php else: ?>
                                                    <i class="fas fa-user-tie fa-2x text-secondary"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars($s['name']) ?></td>
                                            <td><?= htmlspecialchars($s['designation']) ?></td>
                                            <td><?= $s['sort_order'] ?></td>
                                            <td>
                                                <button class="btn btn-sm toggle-status btn-<?= $s['is_active'] ? 'success' : 'secondary' ?>" data-id="<?= $s['id'] ?>">
                                                    <i class="fas fa-<?= $s['is_active'] ? 'check-circle' : 'eye-slash' ?>"></i> <?= $s['is_active'] ? 'Active' : 'Inactive' ?>
                                                </button>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-warning edit-staff" data-id="<?= $s['id'] ?>" data-name="<?= htmlspecialchars($s['name']) ?>" data-designation="<?= htmlspecialchars($s['designation']) ?>" data-order="<?= $s['sort_order'] ?>" data-active="<?= $s['is_active'] ?>" data-photo-base64="<?= $photoBase64 ?>"><i class="fas fa-edit"></i></button>
                                                <a href="?delete=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this staff profile?')"><i class="fas fa-trash"></i></a>
                                            <tr>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (count($staff) > 1): ?>
                    <div class="alert alert-info mt-2 small">
                        <i class="fas fa-arrows-alt"></i> Drag the <i class="fas fa-grip-vertical"></i> handle to reorder staff. Changes are saved automatically.
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header bg-info text-white">How to Display Staff on Login Page</div>
                <div class="card-body">
                    <p>Go to <strong>System Settings → General</strong> and make sure:</p>
                    <ul>
                        <li><code>staff_display_enabled</code> is set to <strong>enabled</strong> (checkbox).</li>
                        <li>Staff profiles are active (<code>is_active = 1</code>).</li>
                    </ul>
                    <p>The staff gallery will appear automatically on the right side of the login page.</p>
                    <hr>
                    <p><strong>Troubleshooting:</strong> If images still don't appear, check that the <code>uploads/staff/</code> folder has proper read permissions and that your web server can serve images from that location. You can test by directly accessing a photo URL like <code>/uploads/staff/staff_xxxxx.jpg</code>.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script>
// Photo preview (new upload)
function previewPhoto(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var preview = document.getElementById('photoPreview');
            var img = document.getElementById('previewImg');
            preview.style.display = 'block';
            img.src = e.target.result;
            document.getElementById('currentPhotoContainer').style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
document.getElementById('staff_photo')?.addEventListener('change', function() { previewPhoto(this); });

// Edit staff – uses base64 photo directly
function editStaff(id, name, designation, sortOrder, isActive, photoBase64) {
    document.getElementById('staff_id').value = id;
    document.getElementById('staff_name').value = name;
    document.getElementById('staff_designation').value = designation;
    document.getElementById('staff_sort_order').value = sortOrder;
    document.getElementById('staff_active').checked = (isActive == 1);
    document.getElementById('photoPreview').style.display = 'none';
    document.getElementById('staff_photo').value = '';
    if (photoBase64) {
        var currentContainer = document.getElementById('currentPhotoContainer');
        var currentImg = document.getElementById('currentPhotoImg');
        currentImg.src = photoBase64;
        currentContainer.style.display = 'block';
        document.getElementById('removePhotoCheck').checked = false;
    } else {
        document.getElementById('currentPhotoContainer').style.display = 'none';
    }
    document.querySelector('.card-header.bg-primary').scrollIntoView({ behavior: 'smooth' });
}

// Reset form
function resetForm() {
    document.getElementById('staffForm').reset();
    document.getElementById('staff_id').value = '';
    document.getElementById('photoPreview').style.display = 'none';
    document.getElementById('currentPhotoContainer').style.display = 'none';
    document.getElementById('staff_photo').value = '';
}

// Attach edit button events (data-photo-base64 attribute)
document.querySelectorAll('.edit-staff').forEach(btn => {
    btn.addEventListener('click', function() {
        editStaff(
            this.dataset.id,
            this.dataset.name,
            this.dataset.designation,
            this.dataset.order,
            this.dataset.active,
            this.dataset.photoBase64
        );
    });
});

// Toggle active status via AJAX
document.querySelectorAll('.toggle-status').forEach(btn => {
    btn.addEventListener('click', function() {
        let id = this.dataset.id;
        let btnEl = this;
        fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'toggle_active=1&id=' + id
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                let newStatus = data.new_status;
                btnEl.classList.remove('btn-success', 'btn-secondary');
                btnEl.classList.add(newStatus ? 'btn-success' : 'btn-secondary');
                btnEl.innerHTML = `<i class="fas fa-${newStatus ? 'check-circle' : 'eye-slash'}"></i> ${newStatus ? 'Active' : 'Inactive'}`;
                showToast('Status updated', 'success');
            } else {
                showToast('Error updating status', 'danger');
            }
        })
        .catch(() => showToast('Network error', 'danger'));
    });
});

// Drag & drop reordering
if (document.getElementById('staffSortable')) {
    new Sortable(document.getElementById('staffSortable'), {
        handle: '.drag-handle',
        animation: 150,
        onEnd: function() {
            let order = [];
            document.querySelectorAll('#staffSortable tr[data-id]').forEach(row => {
                order.push(row.dataset.id);
            });
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'reorder=1&order=' + JSON.stringify(order)
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('Order saved successfully', 'success');
                    document.querySelectorAll('#staffSortable tr[data-id]').forEach((row, idx) => {
                        let orderCell = row.cells[3];
                        if (orderCell) orderCell.innerText = idx + 1;
                    });
                } else {
                    showToast('Reorder failed: ' + (data.error || 'unknown'), 'danger');
                }
            })
            .catch(() => showToast('Network error', 'danger'));
        }
    });
}

// Search filter
function filterStaff() {
    let search = document.getElementById('staffSearch').value.toLowerCase();
    let rows = document.querySelectorAll('#staffSortable tr[data-id]');
    rows.forEach(row => {
        let name = row.cells[2]?.innerText.toLowerCase() || '';
        let designation = row.cells[3]?.innerText.toLowerCase() || '';
        if (name.includes(search) || designation.includes(search)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
document.getElementById('staffSearch')?.addEventListener('keyup', filterStaff);

function showToast(msg, type) {
    let toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '300px';
    toast.innerHTML = msg + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}
</script>

<style>
.drag-handle { cursor: grab; }
.drag-handle:active { cursor: grabbing; }
.table-hover tbody tr:hover .drag-handle { color: #1e3c72; }
</style>

<?php renderFooter(); ?>