<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$token = $_GET['token'] ?? '';
$error = '';
$success = '';

if (empty($token)) {
    die("Invalid reset link.");
}

$db = getDB();
$stmt = $db->prepare("SELECT * FROM members WHERE reset_token = ? AND token_expiry > datetime('now')");
$stmt->execute([$token]);
$member = $stmt->fetch();

if (!$member) {
    die("Reset token expired or invalid. Please request a new password reset.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    if (strlen($newPassword) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($newPassword !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $update = $db->prepare("UPDATE members SET password = ?, reset_token = NULL, token_expiry = NULL WHERE admno = ?");
        $update->execute([$hashed, $member['admno']]);
        $success = "Password reset successful. You can now login with your new password.";
        // Redirect after 3 seconds
        header("refresh:3;url=login.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#f0f2f5;}.card{max-width:500px;margin:80px auto;border-radius:20px;}</style>
</head>
<body>
<div class="container">
    <div class="card shadow">
        <div class="card-body p-5">
            <h3 class="text-center mb-4">Set New Password</h3>
            <?php if($success): ?><div class="alert alert-success"><?= $success ?> Redirecting to login...</div><?php endif; ?>
            <?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
            <?php if(!$success): ?>
            <form method="post">
                <div class="mb-3"><label>New Password</label><input type="password" name="password" class="form-control" required minlength="6"></div>
                <div class="mb-3"><label>Confirm Password</label><input type="password" name="confirm_password" class="form-control" required></div>
                <button type="submit" class="btn btn-primary w-100">Reset Password</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>