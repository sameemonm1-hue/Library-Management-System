<?php
/**
 * Bulk Messaging Module - Fully Self-Contained
 * Supports Email, SMS, WhatsApp with placeholders, templates, scheduling, logging.
 * All AJAX endpoints for templates are handled internally.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// Create log table if not exists
$db->exec("CREATE TABLE IF NOT EXISTS bulk_messages_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel TEXT NOT NULL,
    recipient TEXT NOT NULL,
    subject TEXT,
    message TEXT,
    status TEXT DEFAULT 'pending',
    error TEXT,
    scheduled_at DATETIME,
    sent_at DATETIME,
    created_by TEXT,
    filter_used TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Create message_templates table if not exists
$db->exec("CREATE TABLE IF NOT EXISTS message_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    subject TEXT,
    body TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// ==================== AJAX HANDLERS FOR TEMPLATES ====================
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    header('Content-Type: application/json');
    
    // Validate CSRF for POST/DELETE
    if (($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'DELETE') && 
        (!isset($_GET['csrf']) || $_GET['csrf'] !== $csrf_token)) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid CSRF token']);
        exit;
    }
    
    if (isset($_GET['get'])) {
        $id = (int)$_GET['get'];
        $stmt = $db->prepare("SELECT subject, body FROM message_templates WHERE id = ?");
        $stmt->execute([$id]);
        $template = $stmt->fetch();
        echo json_encode($template ?: []);
        exit;
    }
    
    if (isset($_GET['delete'])) {
        $id = (int)$_GET['delete'];
        $db->prepare("DELETE FROM message_templates WHERE id = ?")->execute([$id]);
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_template'])) {
        $name = trim($_POST['name']);
        $subject = trim($_POST['subject']);
        $body = trim($_POST['body']);
        if ($name && $body) {
            $stmt = $db->prepare("INSERT INTO message_templates (name, subject, body) VALUES (?, ?, ?)");
            $stmt->execute([$name, $subject, $body]);
            echo json_encode(['success' => true, 'id' => $db->lastInsertId()]);
        } else {
            echo json_encode(['error' => 'Name and body are required']);
        }
        exit;
    }
    
    exit;
}

// ==================== HELPER FUNCTIONS ====================
function resolvePlaceholders($text, $member, $bookData = []) {
    $placeholders = [
        '{name}' => $member['name'] ?? '',
        '{admno}' => $member['admno'] ?? '',
        '{email}' => $member['email'] ?? '',
        '{phone}' => $member['phone'] ?? '',
        '{due_date}' => $bookData['due_date'] ?? '',
        '{book_title}' => $bookData['title'] ?? '',
        '{overdue_days}' => $bookData['overdue_days'] ?? '',
        '{library_name}' => getInstitution()['name'] ?? 'Library',
        '{fine}' => isset($bookData['fine']) ? formatCurrency($bookData['fine']) : '',
    ];
    return str_replace(array_keys($placeholders), array_values($placeholders), $text);
}

function sendEmailBulk($to, $subject, $body, $settings) {
    if (!empty($settings['smtp_host'])) {
        if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
            require_once __DIR__ . '/../vendor/autoload.php';
        } else {
            // Fallback to mail()
            $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: noreply@librarysystem.com\r\n";
            return @mail($to, $subject, nl2br($body), $headers);
        }
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = $settings['smtp_host'];
            $mail->Port = (int)$settings['smtp_port'];
            $enc = strtolower($settings['smtp_encryption'] ?? 'tls');
            if ($enc == 'tls') $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            elseif ($enc == 'ssl') $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            $mail->SMTPAuth = true;
            $mail->Username = $settings['smtp_username'];
            $mail->Password = $settings['smtp_password'];
            $mail->setFrom($settings['mail_from'], $settings['mail_from_name']);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = nl2br($body);
            $mail->AltBody = strip_tags($body);
            return $mail->send();
        } catch (Exception $e) {
            error_log("Email failed: " . $e->getMessage());
            return false;
        }
    } else {
        $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: noreply@librarysystem.com\r\n";
        return @mail($to, $subject, nl2br($body), $headers);
    }
}

function sendSMSBulk($to, $message, $settings) {
    $apiKey = $settings['sms_api_key'] ?? '';
    if (empty($apiKey)) return false;
    // Example for TextLocal – replace with your gateway
    $data = ['apikey' => $apiKey, 'numbers' => $to, 'message' => $message, 'sender' => 'LIBRARY'];
    $ch = curl_init('https://api.textlocal.in/send/');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($response, true);
    return isset($result['status']) && $result['status'] === 'success';
}

function sendWhatsAppBulk($to, $message, $settings) {
    $apiKey = $settings['whatsapp_api_key'] ?? '';
    $phoneNumberId = $settings['whatsapp_phone_number_id'] ?? '';
    if (empty($apiKey) || empty($phoneNumberId)) return false;
    // Implement your WhatsApp API call here
    return true;
}

// ==================== PROCESS FORM SUBMISSION ====================
$success = $error = '';
$previewData = [];
$testMode = isset($_POST['test_mode']);
$scheduleTime = !empty($_POST['schedule_time']) ? date('Y-m-d H:i:s', strtotime($_POST['schedule_time'])) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh the page.";
    } else {
        $action = $_POST['action'];
        $channel = $_POST['channel'] ?? 'email';
        $subject = trim($_POST['subject'] ?? '');
        $messageTemplate = trim($_POST['message']);
        $recipientFilter = $_POST['recipient_filter'] ?? 'all';
        $category = $_POST['category'] ?? '';
        $specificMembers = trim($_POST['specific_members'] ?? '');
        $customSql = trim($_POST['custom_sql'] ?? '');
        $templateId = (int)($_POST['template_id'] ?? 0);
        
        // Load template if selected
        if ($templateId > 0) {
            $stmt = $db->prepare("SELECT subject, body FROM message_templates WHERE id = ?");
            $stmt->execute([$templateId]);
            $template = $stmt->fetch();
            if ($template) {
                $subject = $template['subject'] ?: $subject;
                $messageTemplate = $template['body'] ?: $messageTemplate;
            }
        }
        
        // Build recipient query
        $sql = "SELECT admno, name, email, phone, member_category, status FROM members WHERE 1=1";
        $params = [];
        
        if ($recipientFilter === 'active') {
            $sql .= " AND status = 'active'";
        } elseif ($recipientFilter === 'overdue') {
            $sql .= " AND admno IN (SELECT admno FROM circulation WHERE return_date IS NULL AND due_date < date('now'))";
        } elseif ($recipientFilter === 'category' && !empty($category)) {
            $sql .= " AND member_category = ?";
            $params[] = $category;
        } elseif ($recipientFilter === 'specific' && !empty($specificMembers)) {
            $admnos = array_map('trim', explode("\n", str_replace(["\r", ","], "\n", $specificMembers)));
            $admnos = array_filter($admnos);
            if (!empty($admnos)) {
                $placeholders = implode(',', array_fill(0, count($admnos), '?'));
                $sql .= " AND admno IN ($placeholders)";
                $params = array_merge($params, $admnos);
            } else {
                $error = "No valid member numbers provided.";
            }
        } elseif ($recipientFilter === 'custom' && !empty($customSql)) {
            if ($_SESSION['role'] !== 'admin') {
                $error = "Custom SQL only allowed for administrators.";
            } else {
                if (stripos($customSql, 'select') === false) {
                    $customSql = "SELECT admno, name, email, phone, member_category, status FROM members WHERE " . $customSql;
                }
                try {
                    $tempStmt = $db->prepare($customSql);
                    $tempStmt->execute();
                    $rows = $tempStmt->fetchAll();
                    $recipients = $rows;
                    $sql = null;
                } catch (Exception $e) {
                    $error = "Invalid custom SQL: " . $e->getMessage();
                }
            }
        }
        
        if (!isset($recipients) && !$error) {
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $recipients = $stmt->fetchAll();
        }
        
        if (empty($recipients) && !$error) {
            $error = "No recipients found for the selected filter.";
        }
        
        if (!$error && $action === 'preview') {
            $previewData = [];
            $count = 0;
            foreach ($recipients as $member) {
                if ($count++ >= 5) break;
                $bookData = [];
                if ($recipientFilter === 'overdue') {
                    $bookStmt = $db->prepare("SELECT title, due_date, julianday('now') - julianday(due_date) as overdue_days FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now') LIMIT 1");
                    $bookStmt->execute([$member['admno']]);
                    $book = $bookStmt->fetch();
                    if ($book) {
                        $bookData = [
                            'title' => $book['title'],
                            'due_date' => $book['due_date'],
                            'overdue_days' => round($book['overdue_days']),
                            'fine' => calculateFine($book['due_date'], $member['member_category'])
                        ];
                    }
                }
                $resolvedMsg = resolvePlaceholders($messageTemplate, $member, $bookData);
                $resolvedSubj = resolvePlaceholders($subject, $member, $bookData);
                $previewData[] = [
                    'admno' => $member['admno'],
                    'name' => $member['name'],
                    'contact' => ($channel == 'email') ? $member['email'] : $member['phone'],
                    'subject' => $resolvedSubj,
                    'message' => $resolvedMsg
                ];
            }
        } elseif (!$error && $action === 'send') {
            $sent = 0;
            $failed = 0;
            foreach ($recipients as $member) {
                $contact = ($channel == 'email') ? $member['email'] : $member['phone'];
                if (empty($contact)) {
                    $failed++;
                    continue;
                }
                $bookData = [];
                if ($recipientFilter === 'overdue') {
                    $bookStmt = $db->prepare("SELECT title, due_date, julianday('now') - julianday(due_date) as overdue_days FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now') LIMIT 1");
                    $bookStmt->execute([$member['admno']]);
                    $book = $bookStmt->fetch();
                    if ($book) {
                        $bookData = [
                            'title' => $book['title'],
                            'due_date' => $book['due_date'],
                            'overdue_days' => round($book['overdue_days']),
                            'fine' => calculateFine($book['due_date'], $member['member_category'])
                        ];
                    }
                }
                $resolvedMsg = resolvePlaceholders($messageTemplate, $member, $bookData);
                $resolvedSubj = resolvePlaceholders($subject, $member, $bookData);
                
                $status = 'pending';
                $errorMsg = null;
                if (!$testMode) {
                    if ($channel === 'email') {
                        $ok = sendEmailBulk($contact, $resolvedSubj, $resolvedMsg, $settings);
                    } elseif ($channel === 'sms') {
                        $ok = sendSMSBulk($contact, $resolvedMsg, $settings);
                    } else {
                        $ok = sendWhatsAppBulk($contact, $resolvedMsg, $settings);
                    }
                    $status = $ok ? 'sent' : 'failed';
                    if (!$ok) $errorMsg = "Send failed";
                    if ($ok) $sent++;
                    else $failed++;
                } else {
                    $status = 'test';
                    $sent++;
                }
                
                $logStmt = $db->prepare("INSERT INTO bulk_messages_log (channel, recipient, subject, message, status, error, scheduled_at, created_by, filter_used) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $logStmt->execute([
                    $channel, $contact, $resolvedSubj, $resolvedMsg, $status, $errorMsg,
                    $scheduleTime, $_SESSION['username'], $recipientFilter
                ]);
            }
            if ($testMode) {
                $success = "TEST MODE: Would have sent to $sent recipients. No actual messages were sent.";
            } else {
                $success = "Messages sent: $sent, failed: $failed. " . ($scheduleTime ? "Scheduled for $scheduleTime." : "");
            }
            logActivity($_SESSION['username'], 'BULK_MESSAGE', "$channel: $sent sent, $failed failed, filter=$recipientFilter");
        }
    }
}

// Fetch templates and logs
$templates = $db->query("SELECT id, name, subject, body FROM message_templates ORDER BY name")->fetchAll();
$logs = $db->query("SELECT * FROM bulk_messages_log ORDER BY created_at DESC LIMIT 100")->fetchAll();

renderHeader('Bulk Messaging');
?>
<div class="container-fluid px-4">
    <h2><i class="fas fa-bullhorn"></i> Advanced Bulk Messaging</h2>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible"><?= htmlspecialchars($success) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible"><?= htmlspecialchars($error) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    
    <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#send">📧 Compose & Send</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#templates">📝 Templates</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#logs">📜 Delivery Logs</button></li>
    </ul>
    
    <div class="tab-content">
        <!-- SEND TAB -->
        <div class="tab-pane fade show active" id="send">
            <div class="card">
                <div class="card-header bg-primary text-white">New Bulk Message</div>
                <div class="card-body">
                    <form method="post" id="bulkForm">
                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                        <input type="hidden" name="action" id="formAction" value="preview">
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>Channel *</label>
                                <select name="channel" class="form-select" required>
                                    <option value="email">Email</option>
                                    <option value="sms">SMS</option>
                                    <option value="whatsapp">WhatsApp</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Recipient Filter *</label>
                                <select name="recipient_filter" id="filterSelect" class="form-select" required>
                                    <option value="all">All Members (with contact)</option>
                                    <option value="active">Active Members Only</option>
                                    <option value="overdue">Members with Overdue Books</option>
                                    <option value="category">By Category</option>
                                    <option value="specific">Specific Members (admno list)</option>
                                    <option value="custom">Custom SQL (admin only)</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Use Template (optional)</label>
                                <select name="template_id" id="templateSelect" class="form-select">
                                    <option value="0">-- None --</option>
                                    <?php foreach ($templates as $tpl): ?>
                                        <option value="<?= $tpl['id'] ?>"><?= htmlspecialchars($tpl['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div id="categoryDiv" class="mb-3" style="display:none;">
                            <label>Member Category</label>
                            <select name="category" class="form-select">
                                <?php
                                $cats = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
                                foreach ($cats as $cat) echo "<option value=\"$cat\">$cat</option>";
                                ?>
                            </select>
                        </div>
                        
                        <div id="specificDiv" class="mb-3" style="display:none;">
                            <label>Specific Members (one AdmNo per line, or comma separated)</label>
                            <textarea name="specific_members" rows="3" class="form-control" placeholder="MEM001&#10;MEM002&#10;MEM003"></textarea>
                        </div>
                        
                        <div id="customDiv" class="mb-3" style="display:none;">
                            <label>Custom SQL WHERE clause (admin only)</label>
                            <textarea name="custom_sql" rows="2" class="form-control" placeholder="e.g., city = 'New York' AND status='active'"></textarea>
                            <small class="text-muted">Will be appended to: SELECT admno, name, email, phone FROM members WHERE ...</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>Subject (for email)</label>
                            <input type="text" name="subject" class="form-control" placeholder="Overdue Book Alert / Library News">
                        </div>
                        
                        <div class="mb-3">
                            <label>Message Body * <span class="text-muted">(supports {name}, {due_date}, {book_title}, {overdue_days}, {fine}, {library_name})</span></label>
                            <textarea name="message" rows="6" class="form-control" required placeholder="Dear {name},&#10;Your book '{book_title}' is overdue by {overdue_days} days. Please return it immediately.&#10;Fine accrued: {fine}"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>Schedule (optional)</label>
                                <input type="datetime-local" name="schedule_time" class="form-control">
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="form-check mt-4">
                                    <input type="checkbox" name="test_mode" value="1" id="testMode" class="form-check-input">
                                    <label for="testMode" class="form-check-label">Test Mode (dry run, no actual send)</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-secondary" onclick="setAction('preview')"><i class="fas fa-eye"></i> Preview (first 5)</button>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Send bulk messages now? This may incur charges.') && setAction('send')"><i class="fas fa-paper-plane"></i> Send Now</button>
                        </div>
                    </form>
                    
                    <?php if (!empty($previewData)): ?>
                        <hr>
                        <h5>Preview (first 5 recipients)</h5>
                        <div class="table-responsive">
                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr><th>AdmNo</th><th>Name</th><th>Contact</th><th>Subject</th><th>Message Preview</th></tr>
                                </thead>
                                <tbody>
                                <?php foreach ($previewData as $p): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($p['admno']) ?></td>
                                        <td><?= htmlspecialchars($p['name']) ?></td>
                                        <td><?= htmlspecialchars($p['contact']) ?></td>
                                        <td><?= htmlspecialchars($p['subject']) ?></td>
                                        <td><?= nl2br(htmlspecialchars(substr($p['message'], 0, 150))) ?>...</td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- TEMPLATES TAB -->
        <div class="tab-pane fade" id="templates">
            <div class="card">
                <div class="card-header bg-info text-white">Manage Message Templates</div>
                <div class="card-body">
                    <button class="btn btn-sm btn-success mb-3" data-bs-toggle="modal" data-bs-target="#addTemplateModal"><i class="fas fa-plus"></i> Add Template</button>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead><tr><th>Name</th><th>Subject</th><th>Body</th><th>Actions</th></tr></thead>
                            <tbody>
                            <?php foreach ($templates as $tpl): ?>
                                <tr>
                                    <td><?= htmlspecialchars($tpl['name']) ?></td>
                                    <td><?= htmlspecialchars($tpl['subject']) ?></td>
                                    <td><?= htmlspecialchars(substr($tpl['body'], 0, 80)) ?>...</td>
                                    <td>
                                        <button class="btn btn-sm btn-primary use-template" data-id="<?= $tpl['id'] ?>"><i class="fas fa-paste"></i> Use</button>
                                        <button class="btn btn-sm btn-danger delete-template" data-id="<?= $tpl['id'] ?>"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- LOGS TAB -->
        <div class="tab-pane fade" id="logs">
            <div class="card">
                <div class="card-header bg-secondary text-white">Message Delivery Logs</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead><tr><th>Date</th><th>Channel</th><th>Recipient</th><th>Subject</th><th>Status</th><th>Error</th></tr></thead>
                            <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= $log['created_at'] ?></td>
                                    <td><?= strtoupper($log['channel']) ?></td>
                                    <td><?= htmlspecialchars($log['recipient']) ?></td>
                                    <td><?= htmlspecialchars(substr($log['subject'], 0, 30)) ?></td>
                                    <td><span class="badge bg-<?= $log['status']=='sent'?'success':($log['status']=='failed'?'danger':'secondary') ?>"><?= $log['status'] ?></span></td>
                                    <td><?= htmlspecialchars($log['error']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Template -->
<div class="modal fade" id="addTemplateModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-success text-white"><h5>Add New Template</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="addTemplateForm">
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                    <div class="mb-2"><label>Template Name</label><input type="text" name="name" class="form-control" required></div>
                    <div class="mb-2"><label>Subject (optional)</label><input type="text" name="subject" class="form-control"></div>
                    <div class="mb-2"><label>Message Body</label><textarea name="body" rows="4" class="form-control" required></textarea></div>
                    <div class="mt-3"><button type="submit" class="btn btn-primary">Save Template</button></div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function setAction(act) {
    document.getElementById('formAction').value = act;
    return true;
}
document.getElementById('filterSelect').addEventListener('change', function() {
    document.getElementById('categoryDiv').style.display = this.value === 'category' ? 'block' : 'none';
    document.getElementById('specificDiv').style.display = this.value === 'specific' ? 'block' : 'none';
    document.getElementById('customDiv').style.display = this.value === 'custom' ? 'block' : 'none';
});
document.getElementById('templateSelect').addEventListener('change', function() {
    let id = this.value;
    if (id == 0) return;
    fetch('?get=' + id + '&csrf=<?= $csrf_token ?>', {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.subject) document.querySelector('input[name="subject"]').value = data.subject;
        document.querySelector('textarea[name="message"]').value = data.body;
    });
});
document.querySelectorAll('.delete-template').forEach(btn => {
    btn.addEventListener('click', function() {
        let id = this.dataset.id;
        if (confirm('Delete template?')) {
            fetch('?delete=' + id + '&csrf=<?= $csrf_token ?>', {
                method: 'DELETE',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(() => location.reload());
        }
    });
});
document.querySelectorAll('.use-template').forEach(btn => {
    btn.addEventListener('click', function() {
        let id = this.dataset.id;
        fetch('?get=' + id + '&csrf=<?= $csrf_token ?>', {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(r => r.json())
        .then(data => {
            document.querySelector('input[name="subject"]').value = data.subject || '';
            document.querySelector('textarea[name="message"]').value = data.body || '';
            document.querySelector('#send .nav-link').click();
        });
    });
});
document.getElementById('addTemplateForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append('save_template', '1');
    fetch('', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.error || 'Failed to save template');
        }
    });
});
</script>

<?php renderFooter(); ?>