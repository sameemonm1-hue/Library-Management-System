<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

// Handle update of suggestion status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_suggestion'])) {
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    $notes = trim($_POST['admin_notes']);
    $stmt = $db->prepare("UPDATE book_suggestions SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?");
    $stmt->execute([$status, $notes, $id]);
    header("Location: suggestions.php");
    exit;
}

// Handle deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM book_suggestions WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header("Location: suggestions.php");
    exit;
}

// Fetch suggestions – optionally filter by status or member
$filterStatus = $_GET['status'] ?? '';
$filterMember = $_GET['member'] ?? '';

$sql = "SELECT * FROM book_suggestions WHERE 1=1";
$params = [];

if (!empty($filterStatus) && in_array($filterStatus, ['pending', 'approved', 'rejected'])) {
    $sql .= " AND status = ?";
    $params[] = $filterStatus;
}
if (!empty($filterMember)) {
    $sql .= " AND (admno LIKE ? OR name LIKE ? OR title LIKE ?)";
    $like = "%$filterMember%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY submitted_at DESC, created_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$suggestions = $stmt->fetchAll();

renderHeader('Purchase Suggestions');
?>

<style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
    }
    body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
    
    .settings-bar { display: none !important; }
    
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .card-header.bg-primary {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .card-header.bg-light {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .table thead th {
        background: var(--primary-color);
        color: white;
        border-bottom: none;
    }
    .modal-header {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .modal-header .btn-close {
        filter: invert(1);
    }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    .stat-card .stat-value {
        font-size: 28px;
        font-weight: 700;
    }
    .stat-card .stat-label {
        opacity: 0.9;
    }
    
    @media print {
        .no-print { display: none !important; }
        .settings-bar { display: none !important; }
        .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
        .card-header.bg-primary { background: #f8f9fa !important; color: #333 !important; }
        .table thead th { background: #333 !important; color: white !important; }
    }
</style>

<div class="container-fluid px-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color);"><i class="fas fa-lightbulb text-warning"></i> Purchase / Suggestions</h2>
        <div class="no-print">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-arrow-left"></i> Back to Home</a>
        </div>
    </div>

    <!-- Statistics -->
    <div class="row g-3 mb-4 no-print">
        <div class="col-md-3 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count($suggestions) ?></div>
                <div class="stat-label">Total</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count(array_filter($suggestions, fn($s) => $s['status'] == 'pending')) ?></div>
                <div class="stat-label">Pending</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count(array_filter($suggestions, fn($s) => $s['status'] == 'approved')) ?></div>
                <div class="stat-label">Approved</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card text-center">
                <div class="stat-value"><?= count(array_filter($suggestions, fn($s) => $s['status'] == 'rejected')) ?></div>
                <div class="stat-label">Rejected</div>
            </div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="card mb-4 border-0 shadow-sm no-print">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-filter"></i> Filter Suggestions</span>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Status</label>
                    <select name="status" class="form-select form-select-sm">
                        <option value="">All</option>
                        <option value="pending" <?= $filterStatus == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="approved" <?= $filterStatus == 'approved' ? 'selected' : '' ?>>Approved</option>
                        <option value="rejected" <?= $filterStatus == 'rejected' ? 'selected' : '' ?>>Rejected</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Search</label>
                    <input type="text" name="member" class="form-control form-control-sm" value="<?= htmlspecialchars($filterMember) ?>" placeholder="AdmNo, Name, or Title">
                </div>
                <div class="col-md-5 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
                    <a href="suggestions.php" class="btn btn-secondary btn-sm"><i class="fas fa-undo"></i> Clear</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Suggestions Table -->
    <div class="card border-0 shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> Book Suggestions from OPAC</span>
            <span class="badge bg-light text-dark"><?= count($suggestions) ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Member</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th class="text-center">ISBN</th>
                            <th>Reason</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Submitted</th>
                            <th>Admin Notes</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($suggestions)): ?>
                            <tr><td colspan="9" class="text-center text-muted py-4">No suggestions found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($suggestions as $s): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($s['name'] ?? 'Unknown') ?></strong><br>
                                    <small class="text-muted"><?= htmlspecialchars($s['admno']) ?></small>
                                  </td>
                                <td><?= htmlspecialchars($s['title']) ?></td>
                                <td><?= htmlspecialchars($s['author'] ?: '-') ?></td>
                                <td class="text-center"><?= htmlspecialchars($s['isbn'] ?: '-') ?></td>
                                <td><?= nl2br(htmlspecialchars($s['reason'])) ?></td>
                                <td class="text-center">
                                    <span class="badge bg-<?= 
                                        $s['status'] == 'approved' ? 'success' : 
                                        ($s['status'] == 'rejected' ? 'danger' : 'warning') 
                                    ?>">
                                        <?= ucfirst($s['status']) ?>
                                    </span>
                                  </td>
                                <td class="text-center"><?= date('Y-m-d H:i', strtotime($s['submitted_at'] ?? $s['created_at'])) ?></td>
                                <td><?= htmlspecialchars($s['admin_notes'] ?: '-') ?></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal" 
                                        data-id="<?= $s['id'] ?>" 
                                        data-status="<?= $s['status'] ?>" 
                                        data-notes="<?= htmlspecialchars($s['admin_notes']) ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this suggestion?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                  </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Updating Suggestion -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Update Suggestion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <input type="hidden" name="id" id="suggestion_id">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" id="suggestion_status" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Admin Notes</label>
                        <textarea name="admin_notes" id="suggestion_notes" class="form-control" rows="3" placeholder="Add remarks or feedback to the member..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_suggestion" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    var editModal = document.getElementById('editModal');
    editModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        document.getElementById('suggestion_id').value = button.getAttribute('data-id');
        document.getElementById('suggestion_status').value = button.getAttribute('data-status');
        document.getElementById('suggestion_notes').value = button.getAttribute('data-notes');
    });
</script>

<?php renderFooter(); ?>