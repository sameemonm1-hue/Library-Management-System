<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// Handle update of suggestion status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_suggestion'])) {
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    $notes = trim($_POST['admin_notes']);
    $stmt = $db->prepare("UPDATE book_suggestions SET status = ?, admin_notes = ?, updated_at = datetime('now') WHERE id = ?");
    $stmt->execute([$status, $notes, $id]);
    header("Location: suggestions.php");
    exit;
}

// Handle deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM book_suggestions WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header("Location: suggestions.php");
    exit;
}

// Fetch suggestions – optionally filter by status or member
$filterStatus = $_GET['status'] ?? '';
$filterMember = $_GET['member'] ?? '';

$sql = "SELECT * FROM book_suggestions WHERE 1=1";
$params = [];

if (!empty($filterStatus) && in_array($filterStatus, ['pending', 'approved', 'rejected'])) {
    $sql .= " AND status = ?";
    $params[] = $filterStatus;
}
if (!empty($filterMember)) {
    $sql .= " AND (admno LIKE ? OR name LIKE ? OR title LIKE ?)";
    $like = "%$filterMember%";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY submitted_at DESC, created_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$suggestions = $stmt->fetchAll();

renderHeader('Purchase Suggestions');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-lightbulb text-warning"></i> Purchase / Suggestions</h2>
        <a href="../index.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </div>

    <!-- Filter Bar -->
    <div class="card mb-4">
        <div class="card-header bg-light">
            <i class="fas fa-filter"></i> Filter Suggestions
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All</option>
                        <option value="pending" <?= $filterStatus == 'pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="approved" <?= $filterStatus == 'approved' ? 'selected' : '' ?>>Approved</option>
                        <option value="rejected" <?= $filterStatus == 'rejected' ? 'selected' : '' ?>>Rejected</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Search (AdmNo / Member Name / Book Title)</label>
                    <input type="text" name="member" class="form-control" value="<?= htmlspecialchars($filterMember) ?>" placeholder="AdmNo, Name, or Title">
                </div>
                <div class="col-md-2">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <a href="suggestions.php" class="btn btn-secondary w-100">Clear Filters</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Suggestions Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <i class="fas fa-list"></i> Book Suggestions from OPAC
            <span class="float-end">Total: <?= count($suggestions) ?></span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Member</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>ISBN</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Submitted</th>
                            <th>Admin Notes</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($suggestions)): ?>
                            <tr><td colspan="9" class="text-center text-muted py-4">No suggestions found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($suggestions as $s): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($s['name'] ?? 'Unknown') ?></strong><br>
                                    <small class="text-muted"><?= htmlspecialchars($s['admno']) ?></small>
                                  </td>
                                <td><?= htmlspecialchars($s['title']) ?></td>
                                <td><?= htmlspecialchars($s['author'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($s['isbn'] ?: '-') ?></td>
                                <td><?= nl2br(htmlspecialchars($s['reason'])) ?></td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $s['status'] == 'approved' ? 'success' : 
                                        ($s['status'] == 'rejected' ? 'danger' : 'warning') 
                                    ?>">
                                        <?= ucfirst($s['status']) ?>
                                    </span>
                                  </td>
                                <td><?= date('Y-m-d H:i', strtotime($s['submitted_at'] ?? $s['created_at'])) ?></td>
                                <td><?= htmlspecialchars($s['admin_notes'] ?: '-') ?></td>
                                <td>
                                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal" 
                                        data-id="<?= $s['id'] ?>" 
                                        data-status="<?= $s['status'] ?>" 
                                        data-notes="<?= htmlspecialchars($s['admin_notes']) ?>">
                                        <i class="fas fa-edit"></i> Update
                                    </button>
                                    <a href="?delete=<?= $s['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this suggestion?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                  </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Updating Suggestion -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Update Suggestion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="suggestion_id">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Status</label>
                        <select name="status" id="suggestion_status" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Admin Notes</label>
                        <textarea name="admin_notes" id="suggestion_notes" class="form-control" rows="3" placeholder="Add remarks or feedback to the member..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_suggestion" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    var editModal = document.getElementById('editModal');
    editModal.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        document.getElementById('suggestion_id').value = button.getAttribute('data-id');
        document.getElementById('suggestion_status').value = button.getAttribute('data-status');
        document.getElementById('suggestion_notes').value = button.getAttribute('data-notes');
    });
</script>

<style>
    .table td { vertical-align: middle; }
    .badge { font-size: 0.8rem; }
</style>

<?php renderFooter(); ?>