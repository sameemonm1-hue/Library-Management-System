<?php
/**
 * Shared Export Functions for Books
 * Version: 1.0
 */

if (!function_exists('exportBooksCSV')) {
    function exportBooksCSV($db, $bookIds = null, $mode = 'copies') {
        while (ob_get_level()) ob_end_clean();
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=books_' . date('Y-m-d') . '.csv');
        header('Cache-Control: private, max-age=0, must-revalidate');
        header('Pragma: public');
        
        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF");
        
        if ($mode === 'titles') {
            $headers = [
                'Sl No', 'Date of Entry', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator', 
                'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition', 
                'Pages', 'Language', 'Country', 'Category', 'Sub Category', 
                'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC', 
                'Other Classification', 'Cutter', 'Call Number', 'Subjects', 
                'Keywords', 'Summary', 'Total Copies', 'Available', 'Price', 
                'Currency', 'Book Status', 'Item Category', 'Maintenance', 
                'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor', 
                'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number', 
                'eBook URL', 'Remarks', 'Source'
            ];
            fputcsv($out, $headers);
            
            $sql = "SELECT * FROM books";
            if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
                $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
                $sql .= " WHERE id IN ($placeholders)";
                $stmt = $db->prepare($sql);
                $stmt->execute($bookIds);
            } else {
                $stmt = $db->query($sql);
            }
            
            $grouped = [];
            while ($book = $stmt->fetch()) {
                $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
                if (!isset($grouped[$key])) {
                    $book['_quantity'] = (int)$book['quantity'];
                    $book['_available'] = (int)$book['available'];
                    $grouped[$key] = $book;
                } else {
                    $grouped[$key]['_quantity'] += (int)$book['quantity'];
                    $grouped[$key]['_available'] += (int)$book['available'];
                }
            }
            
            $sn = 1;
            foreach ($grouped as $book) {
                fputcsv($out, [
                    $sn++,
                    $book['date_of_entry'] ?? $book['created_at'] ?? '',
                    $book['title'], $book['sub_title'] ?? '', $book['author'] ?? '', $book['author2'] ?? '',
                    $book['collaborator'] ?? '', $book['publisher'] ?? '', $book['publisher_place'] ?? '',
                    $book['isbn'] ?? '', $book['issn'] ?? '', $book['year'] ?? '', $book['edition'] ?? '',
                    (int)($book['pages'] ?? 0), $book['language'] ?? 'English', $book['country'] ?? '',
                    $book['category'] ?? '', $book['sub_category'] ?? '', $book['collection_type'] ?? '',
                    $book['series'] ?? '', $book['volume'] ?? '', $book['ddc'] ?? '', $book['udc'] ?? '',
                    $book['lcc'] ?? '', $book['cc'] ?? '', $book['other_classification'] ?? '',
                    $book['cutter'] ?? '', $book['call_number'] ?? '', $book['subject'] ?? '', $book['keyword'] ?? '',
                    $book['summary'] ?? '', $book['_quantity'] ?? 0, $book['_available'] ?? 0,
                    $book['price'] ?? '', $book['price_currency'] ?? 'INR', $book['book_status'] ?? 'Available',
                    $book['item_category'] ?? '', $book['maintenance'] ?? '', $book['current_location'] ?? '',
                    $book['section'] ?? '', $book['branch'] ?? '', $book['shelf'] ?? '', $book['vendor'] ?? '',
                    $book['invoice'] ?? '', $book['acquisition_date'] ?? '', $book['funding_source'] ?? '',
                    $book['po_number'] ?? '', $book['ebook_url'] ?? '', $book['remarks'] ?? '',
                    $book['source'] ?? ''
                ]);
            }
        } else {
            $headers = [
                'Sl No', 'Date of Entry', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2', 
                'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 
                'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
                'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
                'Other Classification', 'Cutter', 'Call Number', 'Subjects',
                'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
                'Currency', 'Book Status', 'Item Category', 'Maintenance',
                'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
                'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
                'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
                'Material Type', 'Size', 'Weight', 'Remarks', 'Cover Path', 'Source'
            ];
            fputcsv($out, $headers);
            
            $sql = "SELECT * FROM books";
            if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
                $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
                $sql .= " WHERE id IN ($placeholders)";
                $stmt = $db->prepare($sql);
                $stmt->execute($bookIds);
            } else {
                $stmt = $db->query($sql);
            }
            
            $sn = 1;
            while ($book = $stmt->fetch()) {
                fputcsv($out, [
                    $sn++,
                    $book['date_of_entry'] ?? $book['created_at'] ?? '',
                    $book['barcode'], $book['accession_number'] ?? '', $book['title'], 
                    $book['sub_title'] ?? '', $book['author'] ?? '',
                    $book['author2'] ?? '', $book['collaborator'] ?? '', $book['publisher'] ?? '',
                    $book['publisher_place'] ?? '', $book['isbn'] ?? '', $book['issn'] ?? '',
                    $book['year'] ?? '', $book['edition'] ?? '', (int)($book['pages'] ?? 0),
                    $book['language'] ?? 'English', $book['country'] ?? '', $book['category'] ?? '',
                    $book['sub_category'] ?? '', $book['collection_type'] ?? '', $book['series'] ?? '',
                    $book['volume'] ?? '', $book['ddc'] ?? '', $book['udc'] ?? '', $book['lcc'] ?? '',
                    $book['cc'] ?? '', $book['other_classification'] ?? '', $book['cutter'] ?? '',
                    $book['call_number'] ?? '', $book['subject'] ?? '', $book['keyword'] ?? '',
                    $book['summary'] ?? '', (int)$book['quantity'], (int)$book['available'],
                    $book['price'] ?? '', $book['price_currency'] ?? 'INR', $book['book_status'] ?? 'Available',
                    $book['item_category'] ?? '', $book['maintenance'] ?? '', $book['current_location'] ?? '',
                    $book['section'] ?? '', $book['branch'] ?? '', $book['shelf'] ?? '', $book['vendor'] ?? '',
                    $book['invoice'] ?? '', $book['invoice_date'] ?? '', $book['acquisition_date'] ?? '',
                    $book['funding_source'] ?? '', $book['po_number'] ?? '', $book['ebook_url'] ?? '',
                    $book['contents'] ?? '', $book['accompanying_material'] ?? '', $book['material_type'] ?? '',
                    $book['size'] ?? '', $book['weight'] ?? '', $book['remarks'] ?? '', $book['cover_path'] ?? '',
                    $book['source'] ?? ''
                ]);
            }
        }
        
        fclose($out);
        exit;
    }
}

if (!function_exists('exportBooksExcel')) {
    function exportBooksExcel($db, $bookIds = null, $mode = 'copies') {
        global $excelAvailable;
        
        while (ob_get_level()) ob_end_clean();
        
        if ($excelAvailable) {
            try {
                $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                
                if ($mode === 'titles') {
                    $headers = [
                        'Sl No', 'Date of Entry', 'Title', 'Sub Title', 'Author', 'Author 2', 'Collaborator', 
                        'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 'Edition', 
                        'Pages', 'Language', 'Country', 'Category', 'Sub Category', 
                        'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC', 
                        'Other Classification', 'Cutter', 'Call Number', 'Subjects', 
                        'Keywords', 'Summary', 'Total Copies', 'Available', 'Price', 
                        'Currency', 'Book Status', 'Item Category', 'Maintenance', 
                        'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor', 
                        'Invoice', 'Acquisition Date', 'Funding Source', 'PO Number', 
                        'eBook URL', 'Remarks', 'Source'
                    ];
                } else {
                    $headers = [
                        'Sl No', 'Date of Entry', 'Barcode', 'Accession No', 'Title', 'Sub Title', 'Author', 'Author 2', 
                        'Collaborator', 'Publisher', 'Publisher Place', 'ISBN', 'ISSN', 'Year', 
                        'Edition', 'Pages', 'Language', 'Country', 'Category', 'Sub Category',
                        'Collection Type', 'Series', 'Volume', 'DDC', 'UDC', 'LCC', 'CC',
                        'Other Classification', 'Cutter', 'Call Number', 'Subjects',
                        'Keywords', 'Summary', 'Quantity', 'Available', 'Price',
                        'Currency', 'Book Status', 'Item Category', 'Maintenance',
                        'Current Location', 'Section', 'Branch', 'Shelf', 'Vendor',
                        'Invoice', 'Invoice Date', 'Acquisition Date', 'Funding Source',
                        'PO Number', 'eBook URL', 'Contents', 'Accompanying Material',
                        'Material Type', 'Size', 'Weight', 'Remarks', 'Source'
                    ];
                }
                
                $col = 'A';
                foreach ($headers as $header) {
                    $sheet->setCellValue($col . '1', $header);
                    $sheet->getColumnDimension($col)->setAutoSize(true);
                    $col++;
                }
                
                $sheet->getStyle('A1:' . $col . '1')->getFont()->setBold(true);
                
                $row = 2;
                $sql = "SELECT * FROM books";
                if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
                    $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
                    $sql .= " WHERE id IN ($placeholders)";
                    $stmt = $db->prepare($sql);
                    $stmt->execute($bookIds);
                } else {
                    $stmt = $db->query($sql);
                }
                
                if ($mode === 'titles') {
                    $grouped = [];
                    while ($book = $stmt->fetch()) {
                        $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
                        if (!isset($grouped[$key])) {
                            $book['_quantity'] = (int)$book['quantity'];
                            $book['_available'] = (int)$book['available'];
                            $grouped[$key] = $book;
                        } else {
                            $grouped[$key]['_quantity'] += (int)$book['quantity'];
                            $grouped[$key]['_available'] += (int)$book['available'];
                        }
                    }
                    $sn = 1;
                    foreach ($grouped as $book) {
                        $col = 'A';
                        $data = [
                            $sn++,
                            $book['date_of_entry'] ?? $book['created_at'] ?? '',
                            $book['title'], $book['sub_title'] ?? '', $book['author'] ?? '', $book['author2'] ?? '',
                            $book['collaborator'] ?? '', $book['publisher'] ?? '', $book['publisher_place'] ?? '',
                            $book['isbn'] ?? '', $book['issn'] ?? '', $book['year'] ?? '', $book['edition'] ?? '',
                            (int)($book['pages'] ?? 0), $book['language'] ?? 'English', $book['country'] ?? '',
                            $book['category'] ?? '', $book['sub_category'] ?? '', $book['collection_type'] ?? '',
                            $book['series'] ?? '', $book['volume'] ?? '', $book['ddc'] ?? '', $book['udc'] ?? '',
                            $book['lcc'] ?? '', $book['cc'] ?? '', $book['other_classification'] ?? '',
                            $book['cutter'] ?? '', $book['call_number'] ?? '', $book['subject'] ?? '', $book['keyword'] ?? '',
                            $book['summary'] ?? '', $book['_quantity'] ?? 0, $book['_available'] ?? 0,
                            $book['price'] ?? '', $book['price_currency'] ?? 'INR', $book['book_status'] ?? 'Available',
                            $book['item_category'] ?? '', $book['maintenance'] ?? '', $book['current_location'] ?? '',
                            $book['section'] ?? '', $book['branch'] ?? '', $book['shelf'] ?? '', $book['vendor'] ?? '',
                            $book['invoice'] ?? '', $book['acquisition_date'] ?? '', $book['funding_source'] ?? '',
                            $book['po_number'] ?? '', $book['ebook_url'] ?? '', $book['remarks'] ?? '',
                            $book['source'] ?? ''
                        ];
                        foreach ($data as $value) {
                            $sheet->setCellValue($col . $row, $value);
                            $col++;
                        }
                        $row++;
                    }
                } else {
                    $sn = 1;
                    while ($book = $stmt->fetch()) {
                        $col = 'A';
                        $data = [
                            $sn++,
                            $book['date_of_entry'] ?? $book['created_at'] ?? '',
                            $book['barcode'], $book['accession_number'] ?? '', $book['title'], 
                            $book['sub_title'] ?? '', $book['author'] ?? '',
                            $book['author2'] ?? '', $book['collaborator'] ?? '', $book['publisher'] ?? '',
                            $book['publisher_place'] ?? '', $book['isbn'] ?? '', $book['issn'] ?? '',
                            $book['year'] ?? '', $book['edition'] ?? '', (int)($book['pages'] ?? 0),
                            $book['language'] ?? 'English', $book['country'] ?? '', $book['category'] ?? '',
                            $book['sub_category'] ?? '', $book['collection_type'] ?? '', $book['series'] ?? '',
                            $book['volume'] ?? '', $book['ddc'] ?? '', $book['udc'] ?? '', $book['lcc'] ?? '',
                            $book['cc'] ?? '', $book['other_classification'] ?? '', $book['cutter'] ?? '',
                            $book['call_number'] ?? '', $book['subject'] ?? '', $book['keyword'] ?? '',
                            $book['summary'] ?? '', (int)$book['quantity'], (int)$book['available'],
                            $book['price'] ?? '', $book['price_currency'] ?? 'INR', $book['book_status'] ?? 'Available',
                            $book['item_category'] ?? '', $book['maintenance'] ?? '', $book['current_location'] ?? '',
                            $book['section'] ?? '', $book['branch'] ?? '', $book['shelf'] ?? '', $book['vendor'] ?? '',
                            $book['invoice'] ?? '', $book['invoice_date'] ?? '', $book['acquisition_date'] ?? '',
                            $book['funding_source'] ?? '', $book['po_number'] ?? '', $book['ebook_url'] ?? '',
                            $book['contents'] ?? '', $book['accompanying_material'] ?? '', $book['material_type'] ?? '',
                            $book['size'] ?? '', $book['weight'] ?? '', $book['remarks'] ?? '',
                            $book['source'] ?? ''
                        ];
                        foreach ($data as $value) {
                            $sheet->setCellValue($col . $row, $value);
                            $col++;
                        }
                        $row++;
                    }
                }
                
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment; filename=books_' . date('Y-m-d') . '.xlsx');
                header('Cache-Control: private, max-age=0, must-revalidate');
                header('Pragma: public');
                
                $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
                $writer->save('php://output');
                exit;
                
            } catch (Exception $e) {
                error_log("Excel export error: " . $e->getMessage());
            }
        }
        
        exportBooksCSV($db, $bookIds, $mode);
    }
}

if (!function_exists('exportBooksPDF')) {
    function exportBooksPDF($db, $bookIds = null, $mode = 'copies') {
        global $pdfAvailable;
        
        while (ob_get_level()) ob_end_clean();
        
        $settings = getSettings();
        $institution = getInstitution();
        $reportSettings = [
            'font_size' => $settings['report_font_size'] ?? 10,
            'primary_color' => $settings['report_primary_color'] ?? '#1e3c72',
            'logo_position' => $settings['report_logo_position'] ?? 'left',
            'logo_right' => $settings['report_logo_right'] ?? '',
            'watermark_text' => $settings['report_watermark_text'] ?? '',
            'watermark_enabled' => $settings['report_watermark_enabled'] ?? 0,
            'watermark_opacity' => $settings['report_watermark_opacity'] ?? 10,
            'signature_name' => $settings['report_signature_name'] ?? 'Librarian',
            'signature_title' => $settings['report_signature_title'] ?? 'Chief Librarian',
            'signature_image' => $settings['report_signature_image'] ?? '',
            'signature_enabled' => $settings['report_signature_enabled'] ?? 0,
            'footer_text' => $settings['report_footer_text'] ?? 'This is a system generated report'
        ];
        
        $html = '<!DOCTYPE html><html><head>';
        $html .= '<meta charset="UTF-8">';
        $html .= '<title>Books Catalog</title>';
        $html .= '<style>
            body { font-family: DejaVu Sans, Arial, sans-serif; font-size: ' . $reportSettings['font_size'] . 'px; margin: 20px; }
            h1 { font-size: 18px; text-align: center; color: ' . $reportSettings['primary_color'] . '; margin-bottom: 5px; }
            h2 { font-size: 14px; text-align: center; color: #555; margin-top: 0; margin-bottom: 15px; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
            th, td { border: 1px solid #ddd; padding: 5px; text-align: left; vertical-align: top; }
            th { background: ' . $reportSettings['primary_color'] . '; color: white; font-weight: bold; }
            tr:nth-child(even) { background: #f9f9f9; }
            .footer { text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 5px; margin-top: 15px; }
            .watermark { position: fixed; bottom: 50%; right: 50%; transform: translate(50%, 50%); opacity: ' . ($reportSettings['watermark_opacity'] / 100) . '; font-size: 48px; font-weight: bold; color: #000; white-space: nowrap; z-index: 1000; pointer-events: none; text-align: center; width: 100%; }
            .report-header { text-align: center; border-bottom: 2px solid ' . $reportSettings['primary_color'] . '; padding-bottom: 10px; margin-bottom: 15px; }
            .report-header img { max-height: 50px; }
            .signature { margin-top: 20px; text-align: right; border-top: 1px solid #ddd; padding-top: 10px; }
        </style>';
        
        if ($reportSettings['watermark_enabled'] && !empty($reportSettings['watermark_text'])) {
            $html .= '<div class="watermark">' . htmlspecialchars($reportSettings['watermark_text']) . '</div>';
        }
        
        $html .= '</head><body>';
        
        $logoHtml = '';
        if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
            $logoData = base64_encode(file_get_contents($institution['logo_path']));
            $mime = mime_content_type($institution['logo_path']);
            $logoHtml = '<img src="data:' . $mime . ';base64,' . $logoData . '" style="height:50px;">';
        }
        $html .= '<div class="report-header">';
        $html .= $logoHtml;
        $html .= '<h1>' . htmlspecialchars($institution['name'] ?? 'Library System') . '</h1>';
        $html .= '<h2>Books Catalog - ' . ($mode === 'titles' ? 'Grouped by Title' : 'Per Copy / Accession Register') . '</h2>';
        $html .= '<p>Generated: ' . date('F j, Y g:i A') . '</p>';
        $html .= '</div>';
        
        if ($mode === 'titles') {
            $html .= '<table>
                <thead><tr>
                    <th style="text-align:center;">#</th>
                    <th>Date of Entry</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Publisher</th>
                    <th>ISBN</th>
                    <th>Year</th>
                    <th style="text-align:center;">Copies</th>
                    <th style="text-align:center;">Available</th>
                </tr></thead><tbody>';
            
            $sql = "SELECT * FROM books";
            if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
                $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
                $sql .= " WHERE id IN ($placeholders)";
                $stmt = $db->prepare($sql);
                $stmt->execute($bookIds);
            } else {
                $stmt = $db->query($sql);
            }
            
            $grouped = [];
            while ($book = $stmt->fetch()) {
                $key = $book['title'] . '|' . ($book['author'] ?? '') . '|' . ($book['publisher'] ?? '') . '|' . ($book['isbn'] ?? '');
                if (!isset($grouped[$key])) {
                    $book['_quantity'] = (int)$book['quantity'];
                    $book['_available'] = (int)$book['available'];
                    $grouped[$key] = $book;
                } else {
                    $grouped[$key]['_quantity'] += (int)$book['quantity'];
                    $grouped[$key]['_available'] += (int)$book['available'];
                }
            }
            
            $i = 1;
            foreach ($grouped as $book) {
                $html .= '<tr>
                    <td style="text-align:center;">' . $i++ . '</td>
                    <td>' . htmlspecialchars($book['date_of_entry'] ?? $book['created_at'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['title']) . '</td>
                    <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['publisher'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                    <td style="text-align:center;">' . ($book['_quantity'] ?? 0) . '</td>
                    <td style="text-align:center;">' . ($book['_available'] ?? 0) . '</td>
                </tr>';
            }
        } else {
            $html .= '<table>
                <thead><tr>
                    <th style="text-align:center;">#</th>
                    <th>Date of Entry</th>
                    <th>Barcode</th>
                    <th>Accession</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Call No.</th>
                    <th>ISBN</th>
                    <th>Year</th>
                    <th style="text-align:center;">Status</th>
                </tr></thead><tbody>';
            
            $sql = "SELECT * FROM books";
            if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
                $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
                $sql .= " WHERE id IN ($placeholders)";
                $stmt = $db->prepare($sql);
                $stmt->execute($bookIds);
            } else {
                $stmt = $db->query($sql);
            }
            
            $i = 1;
            while ($book = $stmt->fetch()) {
                $status = ((int)$book['available'] > 0) ? 'Available' : 'Issued';
                $html .= '<tr>
                    <td style="text-align:center;">' . $i++ . '</td>
                    <td>' . htmlspecialchars($book['date_of_entry'] ?? $book['created_at'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['barcode']) . '</td>
                    <td>' . htmlspecialchars($book['accession_number'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['title']) . '</td>
                    <td>' . htmlspecialchars($book['author'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['call_number'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['isbn'] ?? '') . '</td>
                    <td>' . htmlspecialchars($book['year'] ?? '') . '</td>
                    <td style="text-align:center;"><span style="color:' . ($status === 'Available' ? '#28a745' : '#dc3545') . ';">' . $status . '</span></td>
                </tr>';
            }
        }
        
        $html .= '</tbody></table>';
        
        $booksData = [];
        $sql = "SELECT * FROM books";
        if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
            $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
            $sql .= " WHERE id IN ($placeholders)";
            $stmt = $db->prepare($sql);
            $stmt->execute($bookIds);
        } else {
            $stmt = $db->query($sql);
        }
        $booksData = $stmt->fetchAll();
        
        $totalTitles = count($booksData);
        $totalQuantity = array_sum(array_column($booksData, 'quantity'));
        $totalAvailable = array_sum(array_column($booksData, 'available'));
        
        $html .= '<div style="margin: 10px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportSettings['primary_color'] . ';">
            <strong>Summary:</strong> 
            Total Titles: ' . $totalTitles . ' | 
            Total Copies: ' . $totalQuantity . ' | 
            Available: ' . $totalAvailable . ' | 
            Issued: ' . ($totalQuantity - $totalAvailable) . '
        </div>';
        
        $html .= '<div class="footer">' . htmlspecialchars($reportSettings['footer_text']) . '</div>';
        
        if ($reportSettings['signature_enabled']) {
            $sigHtml = '';
            if (!empty($reportSettings['signature_image']) && file_exists($reportSettings['signature_image'])) {
                $sigData = base64_encode(file_get_contents($reportSettings['signature_image']));
                $sigMime = mime_content_type($reportSettings['signature_image']);
                $sigHtml = '<img src="data:' . $sigMime . ';base64,' . $sigData . '" style="max-height:50px;"><br>';
            }
            $html .= '<div class="signature">';
            $html .= $sigHtml;
            $html .= '<strong>' . htmlspecialchars($reportSettings['signature_name']) . '</strong><br>';
            $html .= '<small>' . htmlspecialchars($reportSettings['signature_title']) . '</small>';
            $html .= '</div>';
        }
        
        $html .= '</body></html>';
        
        if ($pdfAvailable && class_exists('Mpdf\Mpdf')) {
            try {
                $mpdf = new \Mpdf\Mpdf([
                    'mode' => 'utf-8',
                    'format' => 'A4',
                    'orientation' => 'portrait',
                    'margin_left' => 10,
                    'margin_right' => 10,
                    'margin_top' => 10,
                    'margin_bottom' => 10,
                    'default_font_size' => $reportSettings['font_size'],
                    'default_font' => 'dejavusans'
                ]);
                $mpdf->WriteHTML($html);
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename=books_' . date('Y-m-d') . '.pdf');
                header('Cache-Control: private, max-age=0, must-revalidate');
                header('Pragma: public');
                $mpdf->Output('books_' . date('Y-m-d') . '.pdf', 'D');
                exit;
            } catch (Exception $e) {
                error_log("mPDF export error: " . $e->getMessage());
            }
        }
        
        if ($pdfAvailable && class_exists('Dompdf\Dompdf')) {
            try {
                $options = new \Dompdf\Options();
                $options->set('isHtml5ParserEnabled', true);
                $options->set('isRemoteEnabled', true);
                $dompdf = new \Dompdf\Dompdf($options);
                $dompdf->loadHtml($html);
                $dompdf->setPaper('A4', 'portrait');
                $dompdf->render();
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename=books_' . date('Y-m-d') . '.pdf');
                header('Cache-Control: private, max-age=0, must-revalidate');
                header('Pragma: public');
                echo $dompdf->output();
                exit;
            } catch (Exception $e) {
                error_log("DOMPDF export error: " . $e->getMessage());
            }
        }
        
        header('Content-Type: text/html');
        echo $html;
        echo '<div style="text-align:center;margin-top:20px;">
            <button onclick="window.print()" style="padding:10px 20px;background:#1e3c72;color:white;border:none;border-radius:5px;cursor:pointer;">Print PDF</button>
            <button onclick="window.history.back()" style="padding:10px 20px;background:#6c757d;color:white;border:none;border-radius:5px;cursor:pointer;">Go Back</button>
        </div>';
        exit;
    }
}

if (!function_exists('exportBooksMARC')) {
    function exportBooksMARC($db, $bookIds = null, $format = 'mrc') {
        global $marcAvailable;
        
        while (ob_get_level()) ob_end_clean();
        
        if (!$marcAvailable) {
            header('Content-Type: text/html');
            echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
            echo '<h2>MARC Export Error</h2>';
            echo '<p>MARC library not installed. Please run: <code>composer require pear/file_marc</code></p>';
            echo '<p><a href="books.php">Back to Books</a></p>';
            echo '</body></html>';
            exit;
        }
        
        $sql = "SELECT * FROM books";
        if ($bookIds && is_array($bookIds) && count($bookIds) > 0 && $bookIds[0] !== 'all') {
            $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
            $sql .= " WHERE id IN ($placeholders)";
            $stmt = $db->prepare($sql);
            $stmt->execute($bookIds);
        } else {
            $stmt = $db->query($sql);
        }
        $books = $stmt->fetchAll();
        
        if (empty($books)) {
            header('Content-Type: text/html');
            echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
            echo '<h2>No Books Selected</h2>';
            echo '<p>Please select at least one book to export.</p>';
            echo '<p><a href="books.php">Back to Books</a></p>';
            echo '</body></html>';
            exit;
        }
        
        $marcMapping = [
            'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
            'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
            'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
            'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
            'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
            'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
            'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
            'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'call_number' => ['tag' => '090', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
            'category'    => ['tag' => '084', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
            'price'       => ['tag' => '020', 'subfield' => 'c', 'indicators' => [' ', ' ']],
            'series'      => ['tag' => '490', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'volume'      => ['tag' => '490', 'subfield' => 'v', 'indicators' => [' ', ' ']],
            'language'    => ['tag' => '008', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'summary'     => ['tag' => '520', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'contents'    => ['tag' => '505', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'issn'        => ['tag' => '022', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'ddc'         => ['tag' => '082', 'subfield' => 'a', 'indicators' => ['0', ' ']],
            'lcc'         => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'accession_number' => ['tag' => '952', 'subfield' => 'a', 'indicators' => [' ', ' ']],
            'item_category' => ['tag' => '952', 'subfield' => 'c', 'indicators' => [' ', ' ']],
            'book_status'   => ['tag' => '952', 'subfield' => 'g', 'indicators' => [' ', ' ']],
            'date_of_entry' => ['tag' => '008', 'subfield' => 'a', 'indicators' => [' ', ' ']],
        ];
        
        function dbToMarc($book, $mapping) {
            if (class_exists('Scriptotek\Marc\Record')) {
                $record = new \Scriptotek\Marc\Record();
                $record->leader = "     nam a22     i 4500";
                foreach ($mapping as $dbField => $marc) {
                    if (empty($book[$dbField])) continue;
                    $tag = $marc['tag'];
                    $subfield = $marc['subfield'];
                    $indicators = $marc['indicators'] ?? [' ', ' '];
                    $field = $record->getField($tag);
                    if (!$field) {
                        $field = $record->addField($tag, $indicators);
                    }
                    $field->addSubfield($subfield, $book[$dbField]);
                }
                return $record;
            } elseif (class_exists('File_MARC_Record')) {
                $record = new \File_MARC_Record();
                $record->setLeader("     nam a22     i 4500");
                foreach ($mapping as $dbField => $marc) {
                    if (empty($book[$dbField])) continue;
                    $tag = $marc['tag'];
                    $subfield = $marc['subfield'];
                    $indicators = $marc['indicators'] ?? [' ', ' '];
                    $field = $record->getField($tag);
                    if (!$field) {
                        $field = new \File_MARC_Data_Field($tag, $indicators);
                        $record->appendField($field);
                    }
                    $field->appendSubfield(new \File_MARC_Subfield($subfield, $book[$dbField]));
                }
                return $record;
            }
            throw new Exception("MARC library not available");
        }
        
        try {
            if (class_exists('Scriptotek\Marc\MarcCollection')) {
                $collection = new \Scriptotek\Marc\MarcCollection();
                foreach ($books as $book) {
                    $record = dbToMarc($book, $marcMapping);
                    $collection->addRecord($record);
                }
                if ($format === 'xml') {
                    $content = $collection->toXml();
                    $filename = "books_export_" . date('Ymd_His') . ".xml";
                    $contentType = "application/xml";
                } else {
                    $content = $collection->toRaw();
                    $filename = "books_export_" . date('Ymd_His') . ".mrc";
                    $contentType = "application/marc";
                }
            } elseif (class_exists('File_MARC_Collection')) {
                $collection = new \File_MARC_Collection();
                foreach ($books as $book) {
                    $record = dbToMarc($book, $marcMapping);
                    $collection->addRecord($record);
                }
                if ($format === 'xml') {
                    $content = $collection->toXML();
                    $filename = "books_export_" . date('Ymd_His') . ".xml";
                    $contentType = "application/xml";
                } else {
                    $content = $collection->toRaw();
                    $filename = "books_export_" . date('Ymd_His') . ".mrc";
                    $contentType = "application/octet-stream";
                }
            } else {
                throw new Exception("MARC collection class not found");
            }
            
            header("Content-Type: $contentType");
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Length: " . strlen($content));
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $content;
            exit;
            
        } catch (Exception $e) {
            header('Content-Type: text/html');
            echo '<!DOCTYPE html><html><head><title>Error</title></head><body>';
            echo '<h2>MARC Export Error</h2>';
            echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
            echo '<p><a href="books.php">Back to Books</a></p>';
            echo '</body></html>';
            exit;
        }
    }
}
?>