<?php
session_start();
require_once "../config/db.php";
require_once "../config/functions.php";
requireAdmin();
if (isset($_GET["id"])) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$_GET["id"]]);
    $book = $stmt->fetch();
    if ($book) {
        $book["cover_url"] = !empty($book["cover_path"]) ? getWebImageUrl($book["cover_path"]) : "";
        echo json_encode(["success" => true, "book" => $book]);
    } else {
        echo json_encode(["success" => false]);
    }
} else {
    echo json_encode(["success" => false]);
}
