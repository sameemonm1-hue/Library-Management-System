<?php
/**
 * MARC21 Advanced Module
 * Features: Import MARC, Export to MARC, Edit MARC records, Z39.50 search
 * 
 * Dependencies: composer require scriptotek/marc
 *               PHP YAZ extension (optional for Z39.50)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$marcAvailable = false;
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
    if (class_exists('Scriptotek\Marc\MarcReader')) {
        $marcAvailable = true;
    } elseif (class_exists('File_MARC')) {
        $marcAvailable = true;
    }
}
$yazAvailable = extension_loaded('yaz');

// MARC field mapping (DB -> MARC)
$marcMapping = [
    'title'       => ['tag' => '245', 'subfield' => 'a', 'indicators' => ['1', '0']],
    'subtitle'    => ['tag' => '245', 'subfield' => 'b', 'indicators' => ['1', '0']],
    'author'      => ['tag' => '100', 'subfield' => 'a', 'indicators' => ['1', '']],
    'author2'     => ['tag' => '700', 'subfield' => 'a', 'indicators' => ['1', '']],
    'collaborator'=> ['tag' => '710', 'subfield' => 'a', 'indicators' => ['2', '']],
    'publisher'   => ['tag' => '260', 'subfield' => 'b', 'indicators' => [' ', ' ']],
    'publisher_place' => ['tag' => '260', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'year'        => ['tag' => '260', 'subfield' => 'c', 'indicators' => [' ', ' ']],
    'edition'     => ['tag' => '250', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'isbn'        => ['tag' => '020', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'call_number' => ['tag' => '050', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'pages'       => ['tag' => '300', 'subfield' => 'a', 'indicators' => [' ', ' ']],
    'subject'     => ['tag' => '650', 'subfield' => 'a', 'indicators' => [' ', '0']],
    'barcode'     => ['tag' => '952', 'subfield' => 'p', 'indicators' => [' ', ' ']],
];

// Convert DB record to MARC record
function dbToMarc($book, $mapping) {
    if (class_exists('Scriptotek\Marc\Record')) {
        $record = new \Scriptotek\Marc\Record();
        $record->leader = "     nam a22     i 4500";
        foreach ($mapping as $dbField => $marc) {
            if (empty($book[$dbField])) continue;
            $field = $record->getField($marc['tag']);
            if (!$field) $field = $record->addField($marc['tag'], $marc['indicators']);
            $field->addSubfield($marc['subfield'], $book[$dbField]);
        }
        return $record;
    } elseif (class_exists('File_MARC_Record')) {
        $record = new \File_MARC_Record();
        $record->setLeader("     nam a22     i 4500");
        foreach ($mapping as $dbField => $marc) {
            if (empty($book[$dbField])) continue;
            $field = $record->getField($marc['tag']);
            if (!$field) {
                $field = new \File_MARC_Data_Field($marc['tag'], $marc['indicators']);
                $record->appendField($field);
            }
            $field->appendSubfield(new \File_MARC_Subfield($marc['subfield'], $book[$dbField]));
        }
        return $record;
    }
    throw new Exception("MARC library not available");
}

// Export
if (isset($_GET['export'])) {
    $format = $_GET['format'] ?? 'mrc';
    $bookIds = $_GET['ids'] ?? [];
    if (is_string($bookIds)) $bookIds = explode(',', $bookIds);
    $sql = "SELECT * FROM books";
    $params = [];
    if (!empty($bookIds)) {
        $placeholders = implode(',', array_fill(0, count($bookIds), '?'));
        $sql .= " WHERE id IN ($placeholders)";
        $params = $bookIds;
    }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();
    if (empty($books)) {
        showToast("No books selected", "warning");
        header("Location: marc21_advanced.php");
        exit;
    }
    try {
        if (!$marcAvailable) throw new Exception("MARC library not installed.");
        if (class_exists('Scriptotek\Marc\MarcCollection')) {
            $collection = new \Scriptotek\Marc\MarcCollection();
            foreach ($books as $book) $collection->addRecord(dbToMarc($book, $marcMapping));
            if ($format === 'xml') {
                $content = $collection->toXml();
                $filename = "export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/marc";
            }
        } else {
            $collection = new \File_MARC_Collection();
            foreach ($books as $book) $collection->addRecord(dbToMarc($book, $marcMapping));
            if ($format === 'xml') {
                $content = $collection->toXML();
                $filename = "export_" . date('Ymd_His') . ".xml";
                $contentType = "application/xml";
            } else {
                $content = $collection->toRaw();
                $filename = "export_" . date('Ymd_His') . ".mrc";
                $contentType = "application/octet-stream";
            }
        }
        header("Content-Type: $contentType");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Length: " . strlen($content));
        echo $content;
        exit;
    } catch (Exception $e) {
        showToast("Export failed: " . $e->getMessage(), "danger");
        header("Location: marc21_advanced.php");
        exit;
    }
}

// Import
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import'])) {
    if (!isset($_FILES['marc_file']) || $_FILES['marc_file']['error'] !== UPLOAD_ERR_OK) {
        showToast("Please select a valid MARC file", "danger");
        header("Location: marc21_advanced.php");
        exit;
    }
    $file = $_FILES['marc_file']['tmp_name'];
    $ext = strtolower(pathinfo($_FILES['marc_file']['name'], PATHINFO_EXTENSION));
    try {
        if (!$marcAvailable) throw new Exception("MARC library not installed.");
        if ($ext === 'xml') {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARCXML(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        } else {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                $reader = \Scriptotek\Marc\MarcReader::fromString(file_get_contents($file));
            } else {
                $reader = new \File_MARC(file_get_contents($file), \File_MARC::SOURCE_STRING);
            }
        }
        $imported = 0;
        $errors = 0;
        $records = ($reader instanceof \File_MARC_Collection) ? $reader : $reader->getRecords();
        foreach ($records as $record) {
            // Extract data from MARC using simple rules
            $data = [];
            if (class_exists('Scriptotek\Marc\Record')) {
                foreach ($record->getFields() as $field) {
                    $tag = $field->getTag();
                    $subfields = [];
                    foreach ($field->getSubfields() as $sf) $subfields[$sf->getCode()] = $sf->getData();
                    $data[$tag] = $subfields;
                }
            } else {
                $fields = $record->getFields();
                while ($field = $fields->next()) {
                    $tag = $field->getTag();
                    $subfields = [];
                    $subs = $field->getSubfields();
                    while ($sub = $subs->next()) $subfields[$sub->getCode()] = $sub->getData();
                    $data[$tag] = $subfields;
                }
            }
            $barcode = $data['952']['p'] ?? '';
            $title = $data['245']['a'] ?? '';
            if (empty($barcode) || empty($title)) {
                $errors++;
                continue;
            }
            $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $check->execute([$barcode]);
            if ($check->fetch()) {
                $stmt = $db->prepare("UPDATE books SET title=?, author=?, publisher=?, isbn=?, year=?, pages=?, subject=?, call_number=? WHERE barcode=?");
                $stmt->execute([
                    $title,
                    $data['100']['a'] ?? ($data['700']['a'] ?? ''),
                    $data['260']['b'] ?? '',
                    $data['020']['a'] ?? '',
                    $data['260']['c'] ?? '',
                    (int)($data['300']['a'] ?? 0),
                    $data['650']['a'] ?? '',
                    $data['050']['a'] ?? '',
                    $barcode
                ]);
            } else {
                $stmt = $db->prepare("INSERT INTO books (barcode, title, author, publisher, isbn, year, pages, subject, call_number, quantity, available, created_at) VALUES (?,?,?,?,?,?,?,?,?,1,1,datetime('now'))");
                $stmt->execute([
                    $barcode, $title,
                    $data['100']['a'] ?? ($data['700']['a'] ?? ''),
                    $data['260']['b'] ?? '',
                    $data['020']['a'] ?? '',
                    $data['260']['c'] ?? '',
                    (int)($data['300']['a'] ?? 0),
                    $data['650']['a'] ?? '',
                    $data['050']['a'] ?? ''
                ]);
            }
            $imported++;
        }
        showToast("Import completed: $imported records, $errors errors", $imported ? 'success' : 'warning');
        logActivity($_SESSION['username'], 'MARC_IMPORT', "Imported $imported records");
    } catch (Exception $e) {
        showToast("Import failed: " . $e->getMessage(), "danger");
    }
    header("Location: marc21_advanced.php");
    exit;
}

renderHeader('MARC21 Advanced');
?>
<div class="container-fluid px-4">
    <h2><i class="fas fa-tag"></i> MARC21 Advanced Module</h2>
    <?php if (!$marcAvailable): ?>
        <div class="alert alert-warning">MARC library not installed. Run <code>composer require scriptotek/marc</code> to enable import/export.</div>
    <?php endif; ?>
    <ul class="nav nav-tabs mb-3">
        <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#export">Export MARC</a></li>
        <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#import">Import MARC</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade show active" id="export">
            <div class="card">
                <div class="card-header">Export Books to MARC21</div>
                <div class="card-body">
                    <form method="get">
                        <div class="mb-3">
                            <label>Select Books</label>
                            <select name="ids[]" multiple class="form-control" size="8">
                                <?php $all = $db->query("SELECT id, barcode, title FROM books ORDER BY title LIMIT 500");
                                foreach ($all as $b) echo "<option value='{$b['id']}'>{$b['barcode']} - {$b['title']}</option>"; ?>
                            </select>
                            <small>Ctrl+click to select multiple. Leave empty to export all.</small>
                        </div>
                        <div class="mb-3">
                            <label>Format</label>
                            <select name="format" class="form-control"><option value="mrc">MARC Binary (.mrc)</option><option value="xml">MARCXML (.xml)</option></select>
                        </div>
                        <button type="submit" name="export" class="btn btn-primary" <?= !$marcAvailable ? 'disabled' : '' ?>>Export</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="import">
            <div class="card">
                <div class="card-header">Import MARC21 File</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3"><label>MARC File (.mrc or .xml)</label><input type="file" name="marc_file" class="form-control" accept=".mrc,.xml" required></div>
                        <button type="submit" name="import" class="btn btn-warning" <?= !$marcAvailable ? 'disabled' : '' ?>>Import</button>
                    </form>
                    <p class="mt-2 text-muted">Matches by barcode (field 952$p). Updates existing books, creates new ones if not found.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php renderFooter(); ?>