<?php
/**
 * System Settings Management Page - Version 3.1
 * Complete settings interface with modern UI, dark mode, tooltips, and enhanced functionality.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// =============================================================================
// INITIALIZATION
// =============================================================================

// CSRF Protection
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$db = getDB();
$settings = getSettings(); // now cached
$institutions = $db->query("SELECT * FROM institutions WHERE status = 'active' ORDER BY name")->fetchAll();

// Directory Setup
$rootPath = dirname(__DIR__);
if (!defined('LOGO_DIR')) {
    define('LOGO_DIR', $rootPath . '/uploads/logos/');
}
if (!is_dir(LOGO_DIR)) mkdir(LOGO_DIR, 0777, true);

// Timezone
$timezone = $settings['library_timezone'] ?? 'Asia/Kolkata';
date_default_timezone_set($timezone);

// Dark mode from session
$darkMode = $_SESSION['admin_dark_mode'] ?? false;
if (isset($_GET['toggle_dark'])) {
    $_SESSION['admin_dark_mode'] = !$darkMode;
    header("Location: settings.php");
    exit;
}
$darkMode = $_SESSION['admin_dark_mode'] ?? false;

// =============================================================================
// DATA DEFINITIONS (timezones, currencies, categories, rules)
// =============================================================================

$allTimezones = [
    // Asia
    'Asia/Kolkata' => 'Asia/Kolkata (IST)',
    'Asia/Dubai' => 'Asia/Dubai (GST)',
    'Asia/Riyadh' => 'Asia/Riyadh (AST)',
    'Asia/Karachi' => 'Asia/Karachi (PKT)',
    'Asia/Dhaka' => 'Asia/Dhaka (BST)',
    'Asia/Shanghai' => 'Asia/Shanghai (CST)',
    'Asia/Tokyo' => 'Asia/Tokyo (JST)',
    'Asia/Singapore' => 'Asia/Singapore (SGT)',
    'Asia/Bangkok' => 'Asia/Bangkok (ICT)',
    'Asia/Jakarta' => 'Asia/Jakarta (WIB)',
    'Asia/Kuala_Lumpur' => 'Asia/Kuala_Lumpur (MYT)',
    'Asia/Manila' => 'Asia/Manila (PHT)',
    'Asia/Taipei' => 'Asia/Taipei (CST)',
    'Asia/Seoul' => 'Asia/Seoul (KST)',
    'Asia/Muscat' => 'Asia/Muscat (GST)',
    'Asia/Qatar' => 'Asia/Qatar (AST)',
    'Asia/Kuwait' => 'Asia/Kuwait (AST)',
    'Asia/Bahrain' => 'Asia/Bahrain (AST)',
    'Asia/Amman' => 'Asia/Amman (EET)',
    'Asia/Beirut' => 'Asia/Beirut (EET)',
    'Asia/Damascus' => 'Asia/Damascus (EET)',
    'Asia/Gaza' => 'Asia/Gaza (EET)',
    'Asia/Jerusalem' => 'Asia/Jerusalem (IST)',
    'Asia/Yangon' => 'Asia/Yangon (MMT)',
    'Asia/Kathmandu' => 'Asia/Kathmandu (NPT)',
    'Asia/Colombo' => 'Asia/Colombo (IST)',
    'Asia/Tehran' => 'Asia/Tehran (IRST)',
    'Asia/Baghdad' => 'Asia/Baghdad (AST)',
    'Asia/Yerevan' => 'Asia/Yerevan (AMT)',
    'Asia/Tbilisi' => 'Asia/Tbilisi (GET)',
    'Asia/Baku' => 'Asia/Baku (AZT)',
    // Africa
    'Africa/Cairo' => 'Africa/Cairo (EET)',
    'Africa/Casablanca' => 'Africa/Casablanca (WET)',
    'Africa/Johannesburg' => 'Africa/Johannesburg (SAST)',
    'Africa/Lagos' => 'Africa/Lagos (WAT)',
    'Africa/Nairobi' => 'Africa/Nairobi (EAT)',
    // Europe
    'Europe/London' => 'Europe/London (GMT/BST)',
    'Europe/Paris' => 'Europe/Paris (CET/CEST)',
    'Europe/Berlin' => 'Europe/Berlin (CET/CEST)',
    'Europe/Rome' => 'Europe/Rome (CET/CEST)',
    'Europe/Madrid' => 'Europe/Madrid (CET/CEST)',
    'Europe/Amsterdam' => 'Europe/Amsterdam (CET/CEST)',
    'Europe/Brussels' => 'Europe/Brussels (CET/CEST)',
    'Europe/Zurich' => 'Europe/Zurich (CET/CEST)',
    'Europe/Vienna' => 'Europe/Vienna (CET/CEST)',
    'Europe/Stockholm' => 'Europe/Stockholm (CET/CEST)',
    'Europe/Oslo' => 'Europe/Oslo (CET/CEST)',
    'Europe/Copenhagen' => 'Europe/Copenhagen (CET/CEST)',
    'Europe/Helsinki' => 'Europe/Helsinki (EET/EEST)',
    'Europe/Warsaw' => 'Europe/Warsaw (CET/CEST)',
    'Europe/Prague' => 'Europe/Prague (CET/CEST)',
    'Europe/Budapest' => 'Europe/Budapest (CET/CEST)',
    'Europe/Bucharest' => 'Europe/Bucharest (EET/EEST)',
    'Europe/Sofia' => 'Europe/Sofia (EET/EEST)',
    'Europe/Athens' => 'Europe/Athens (EET/EEST)',
    'Europe/Istanbul' => 'Europe/Istanbul (TRT)',
    'Europe/Moscow' => 'Europe/Moscow (MSK)',
    'Europe/Dublin' => 'Europe/Dublin (GMT/IST)',
    'Europe/Lisbon' => 'Europe/Lisbon (WET/WEST)',
    // Americas
    'America/New_York' => 'America/New_York (EST/EDT)',
    'America/Los_Angeles' => 'America/Los_Angeles (PST/PDT)',
    'America/Chicago' => 'America/Chicago (CST/CDT)',
    'America/Denver' => 'America/Denver (MST/MDT)',
    'America/Toronto' => 'America/Toronto (EST/EDT)',
    'America/Vancouver' => 'America/Vancouver (PST/PDT)',
    'America/Mexico_City' => 'America/Mexico_City (CST/CDT)',
    'America/Sao_Paulo' => 'America/Sao_Paulo (BRT/BRST)',
    'America/Buenos_Aires' => 'America/Buenos_Aires (ART)',
    'America/Santiago' => 'America/Santiago (CLT/CLST)',
    'America/Bogota' => 'America/Bogota (COT)',
    'America/Lima' => 'America/Lima (PET)',
    'America/Caracas' => 'America/Caracas (VET)',
    // Australia & Pacific
    'Australia/Sydney' => 'Australia/Sydney (AEDT/AEST)',
    'Australia/Melbourne' => 'Australia/Melbourne (AEDT/AEST)',
    'Australia/Brisbane' => 'Australia/Brisbane (AEST)',
    'Australia/Perth' => 'Australia/Perth (AWST)',
    'Australia/Adelaide' => 'Australia/Adelaide (ACDT/ACST)',
    'Australia/Darwin' => 'Australia/Darwin (ACST)',
    'Australia/Hobart' => 'Australia/Hobart (AEDT/AEST)',
    'Pacific/Auckland' => 'Pacific/Auckland (NZDT/NZST)',
    'Pacific/Fiji' => 'Pacific/Fiji (FJT)',
    'Pacific/Guam' => 'Pacific/Guam (ChST)',
    'Pacific/Samoa' => 'Pacific/Samoa (SST)',
    'Pacific/Tahiti' => 'Pacific/Tahiti (TAHT)'
];

$allCurrencies = [
    'USD' => 'USD - US Dollar ($)',
    'EUR' => 'EUR - Euro (€)',
    'GBP' => 'GBP - British Pound (£)',
    'JPY' => 'JPY - Japanese Yen (¥)',
    'CNY' => 'CNY - Chinese Yuan (¥)',
    'INR' => 'INR - Indian Rupee (₹)',
    'AED' => 'AED - UAE Dirham (د.إ)',
    'SAR' => 'SAR - Saudi Riyal (﷼)',
    'QAR' => 'QAR - Qatari Riyal (﷼)',
    'KWD' => 'KWD - Kuwaiti Dinar (د.ك)',
    'BHD' => 'BHD - Bahraini Dinar (د.ب)',
    'OMR' => 'OMR - Omani Rial (﷼)',
    'CAD' => 'CAD - Canadian Dollar (C$)',
    'AUD' => 'AUD - Australian Dollar (A$)',
    'CHF' => 'CHF - Swiss Franc (Fr)',
    'SEK' => 'SEK - Swedish Krona (kr)',
    'NOK' => 'NOK - Norwegian Krone (kr)',
    'DKK' => 'DKK - Danish Krone (kr)',
    'PLN' => 'PLN - Polish Złoty (zł)',
    'TRY' => 'TRY - Turkish Lira (₺)',
    'RUB' => 'RUB - Russian Ruble (₽)',
    'ZAR' => 'ZAR - South African Rand (R)',
    'BRL' => 'BRL - Brazilian Real (R$)',
    'MXN' => 'MXN - Mexican Peso ($)',
    'SGD' => 'SGD - Singapore Dollar (S$)',
    'HKD' => 'HKD - Hong Kong Dollar (HK$)',
    'MYR' => 'MYR - Malaysian Ringgit (RM)',
    'THB' => 'THB - Thai Baht (฿)',
    'VND' => 'VND - Vietnamese Đồng (₫)',
    'PHP' => 'PHP - Philippine Peso (₱)',
    'IDR' => 'IDR - Indonesian Rupiah (Rp)',
    'PKR' => 'PKR - Pakistani Rupee (₨)',
    'BDT' => 'BDT - Bangladeshi Taka (৳)',
    'LKR' => 'LKR - Sri Lankan Rupee (₨)',
    'NPR' => 'NPR - Nepalese Rupee (₨)',
    'EGP' => 'EGP - Egyptian Pound (E£)',
    'NGN' => 'NGN - Nigerian Naira (₦)',
    'KES' => 'KES - Kenyan Shilling (KSh)',
    'GHS' => 'GHS - Ghanaian Cedi (₵)',
    'TZS' => 'TZS - Tanzanian Shilling (TSh)',
    'UGX' => 'UGX - Ugandan Shilling (USh)',
    'MAD' => 'MAD - Moroccan Dirham (د.م.)',
    'DZD' => 'DZD - Algerian Dinar (د.ج)',
    'TND' => 'TND - Tunisian Dinar (د.ت)',
    'LYD' => 'LYD - Libyan Dinar (ل.د)',
    'IQD' => 'IQD - Iraqi Dinar (ع.د)',
    'JOD' => 'JOD - Jordanian Dinar (د.ا)',
    'LBP' => 'LBP - Lebanese Pound (ل.ل)',
    'SYP' => 'SYP - Syrian Pound (£S)',
    'ILS' => 'ILS - Israeli Shekel (₪)',
    'AZN' => 'AZN - Azerbaijani Manat (₼)',
    'KZT' => 'KZT - Kazakhstani Tenge (₸)',
    'UZS' => 'UZS - Uzbekistani Soʻm (soʻm)',
    'GEL' => 'GEL - Georgian Lari (₾)',
    'AMD' => 'AMD - Armenian Dram (֏)'
];

// Member Categories
$memberCategories = [
    'Students' => [
        'label' => 'Students',
        'sub_categories' => [
            'early_years' => 'Early Years (Pre-K to Grade 1)',
            'elementary' => 'Elementary (Grades 2-5)',
            'middle' => 'Middle School (Grades 6-8)',
            'secondary' => 'Secondary School (Grades 9-12)',
            'diploma' => 'Diploma',
            'graduate' => 'Graduate',
            'post_graduate' => 'Post Graduate',
            'research' => 'Research Scholar'
        ]
    ],
    'Staff' => [
        'label' => 'Staff',
        'sub_categories' => [
            'teaching' => 'Teaching Staff',
            'non_teaching' => 'Non-Teaching Staff',
            'management' => 'Management Level'
        ]
    ]
];

// Default circulation rules for each category
$defaultCirculationRules = [
    'early_years' => ['max_books' => 2, 'loan_days' => 7, 'max_renewals' => 1, 'fine_per_day' => 1, 'max_fine_amount' => 10],
    'elementary' => ['max_books' => 3, 'loan_days' => 10, 'max_renewals' => 1, 'fine_per_day' => 1, 'max_fine_amount' => 15],
    'middle' => ['max_books' => 4, 'loan_days' => 14, 'max_renewals' => 2, 'fine_per_day' => 1.5, 'max_fine_amount' => 20],
    'secondary' => ['max_books' => 5, 'loan_days' => 14, 'max_renewals' => 2, 'fine_per_day' => 1.5, 'max_fine_amount' => 25],
    'diploma' => ['max_books' => 6, 'loan_days' => 21, 'max_renewals' => 2, 'fine_per_day' => 2, 'max_fine_amount' => 30],
    'graduate' => ['max_books' => 8, 'loan_days' => 30, 'max_renewals' => 3, 'fine_per_day' => 2, 'max_fine_amount' => 50],
    'post_graduate' => ['max_books' => 10, 'loan_days' => 30, 'max_renewals' => 3, 'fine_per_day' => 2.5, 'max_fine_amount' => 60],
    'research' => ['max_books' => 15, 'loan_days' => 45, 'max_renewals' => 4, 'fine_per_day' => 2.5, 'max_fine_amount' => 80],
    'teaching' => ['max_books' => 20, 'loan_days' => 60, 'max_renewals' => 5, 'fine_per_day' => 1, 'max_fine_amount' => 100],
    'non_teaching' => ['max_books' => 8, 'loan_days' => 30, 'max_renewals' => 2, 'fine_per_day' => 2, 'max_fine_amount' => 40],
    'management' => ['max_books' => 15, 'loan_days' => 45, 'max_renewals' => 3, 'fine_per_day' => 2, 'max_fine_amount' => 75]
];

// =============================================================================
// ENSURE ALL SETTINGS COLUMNS EXIST
// =============================================================================

$existingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);

$requiredCols = [
    // Core settings
    'software_header', 'library_logo', 'favicon_path', 'menu_position', 'auto_logout_minutes', 'new_arrivals_count', 'default_language',
    'staff_display_enabled', 'enable_audit_log', 'audit_log_retention_days', 'site_maintenance_mode', 'maintenance_message',
    'enable_member_notifications',
    
    // OPAC settings
    'opac_enabled', 'opac_show_new_arrivals', 'opac_show_popular_ebooks', 'opac_show_latest_ebooks',
    'opac_show_notices', 'opac_show_trending', 'opac_show_databases', 'opac_show_thought_of_the_day', 'opac_show_new_arrivals_in_left',
    'opac_quote_rotation_interval', 'opac_carousel_type', 'opac_header_text', 'opac_tagline', 'opac_books_per_page', 'opac_ebooks_per_page',
    'opac_notice_title', 'opac_notice_content', 'opac_header_logo', 'opac_font_family', 'opac_base_font_size', 'opac_heading_font_size',
    'opac_font_weight', 'opac_primary_color', 'opac_header_bg_color', 'opac_body_bg', 'opac_custom_css', 'container_max_width',
    'container_padding', 'openai_api_key',
    
    // Circulation settings
    'loan_days', 'fine_per_day', 'max_books', 'max_renewals', 'allow_holds', 'hold_days',
    'enforce_library_hours', 'enable_self_registration', 'self_registration_role', 'max_fine_amount', 'currency_code', 'currency_decimal_places',
    'circulation_rules', 'enable_category_rules',
    
    // Notification settings
    'notify_overdue', 'enable_email', 'enable_sms', 'smtp_host', 'smtp_port', 'smtp_encryption', 'smtp_username', 'smtp_password',
    'mail_from', 'mail_from_name', 'backup_email', 'sms_api_key', 'email_template_overdue', 'sms_template_overdue', 'whatsapp_template_overdue',
    
    // Member Portal settings
    'enable_member_password_reset', 'reset_token_expiry_hours', 'allow_member_password_change', 'enable_member_portal',
    'member_portal_theme', 'member_portal_primary_color', 'member_portal_custom_css', 'member_portal_show_my_books',
    'member_portal_show_fines', 'member_portal_show_holds', 'member_portal_show_history', 'member_portal_show_profile',
    
    // Backup settings
    'backup_schedule', 'backup_time', 'local_backup_retention', 'backup_include_uploads', 'backup_compress',
    'backup_notification_email', 'last_backup_time',
    
    // Cloud storage settings
    'cloud_storage_provider', 'cloud_folder_id', 'cloud_api_key', 'cloud_api_secret', 'cloud_refresh_token',
    'google_drive_enabled', 'google_drive_folder_id', 'google_drive_client_id', 'google_drive_client_secret',
    'google_drive_refresh_token', 'google_drive_auto_delete_days', 'google_drive_service_account_json',
    'dropbox_enabled', 'dropbox_access_token', 'dropbox_app_key', 'dropbox_app_secret',
    'onedrive_enabled', 'onedrive_client_id', 'onedrive_client_secret', 'onedrive_refresh_token',
    'pcloud_enabled', 'pcloud_access_token', 'pcloud_username', 'pcloud_password_hash',
    'internxt_enabled', 'internxt_api_key', 'internxt_api_secret', 'internxt_bucket', 'internxt_region',
    'mega_enabled', 'mega_email', 'mega_folder_id', 'mega_password_hash',
    'sync_enabled', 'sync_api_key', 'sync_api_secret', 'sync_folder_id',
    'terabox_enabled', 'terabox_api_key', 'terabox_api_secret', 'terabox_folder_id',
    'backblaze_enabled', 'backblaze_key_id', 'backblaze_application_key', 'backblaze_bucket_name',
    'wasabi_enabled', 'wasabi_access_key', 'wasabi_secret_key', 'wasabi_bucket', 'wasabi_region',
    's3_enabled', 's3_access_key', 's3_secret_key', 's3_bucket', 's3_region', 's3_endpoint',
    
    // Visitor settings
    'visitor_header_logo', 'visitor_header_text', 'visitor_tagline', 'visitor_header_bg', 'visitor_body_bg',
    'visitor_footer_bg', 'visitor_font_family', 'visitor_base_font_size', 'visitor_primary_color',
    'guest_enabled', 'guest_prefix', 'guest_number_padding', 'guest_last_reset',
    
    // Library Hours
    'library_open_days', 'library_open_time', 'library_close_time', 'library_lunch_start', 'library_lunch_end', 'library_timezone',
    
    // Report settings
    'report_font_size', 'report_primary_color', 'report_logo_position', 'report_logo_right', 'report_watermark_enabled',
    'report_watermark_text', 'report_watermark_opacity', 'report_signature_enabled', 'report_signature_name',
    'report_signature_title', 'report_signature_image', 'report_footer_text', 'report_logo',
    
    // Institution
    'current_institution_id',
    
    // WhatsApp
    'whatsapp_number', 'whatsapp_message', 'whatsapp_api_type', 'whatsapp_api_url', 'whatsapp_api_token',
    'whatsapp_phone_number_id', 'whatsapp_business_account_id', 'whatsapp_webhook_verified',
    'whatsapp_auto_reply_enabled', 'whatsapp_auto_reply_message', 'whatsapp_out_of_hours_reply',
    'whatsapp_booking_enabled', 'whatsapp_notify_overdue_enabled', 'whatsapp_notify_hold_ready_enabled',
    'whatsapp_welcome_message', 'whatsapp_template_overdue', 'whatsapp_template_hold_ready',
    'whatsapp_template_payment', 'whatsapp_template_event',
    
    // Advanced settings
    'source_options', 'default_source', 'enable_auto_supply_date',
    'enable_multi_branch', 'enable_budgeting', 'enable_interlibrary', 'enable_course_reserves', 'digital_asset_tracking',
    'detailed_audit_log', 'auto_scheduled_jobs',
    'enable_gdpr_compliance', 'gdpr_data_retention_days',
    'enable_api_rate_limiting', 'api_rate_limit_per_minute',
    'enable_webhooks', 'webhook_url', 'webhook_secret',
    'enable_sso', 'sso_provider', 'sso_client_id', 'sso_client_secret', 'sso_redirect_uri',
    'enable_oauth', 'oauth_provider', 'oauth_client_id', 'oauth_client_secret', 'oauth_redirect_uri',
    'enable_saml', 'saml_idp_metadata_url', 'saml_sp_entity_id', 'saml_sp_acs_url',
    'enable_ldap', 'ldap_host', 'ldap_port', 'ldap_encryption', 'ldap_base_dn', 'ldap_bind_dn', 'ldap_bind_password', 'ldap_user_filter',
    'enable_recaptcha', 'recaptcha_site_key', 'recaptcha_secret_key', 'enable_captcha_on_login', 'enable_captcha_on_registration',
    'enable_ai_recommendations', 'ai_recommendation_model', 'ai_max_recommendations',
    'enable_advanced_search', 'search_highlight_color', 'enable_auto_suggest', 'auto_suggest_limit',
    'enable_analytics', 'analytics_tracking_id', 'enable_heatmaps', 'enable_session_recording', 'enable_ab_testing',
    'enable_feature_flags', 'feature_flags_config',
    
    // Additional security settings
    'enable_2fa', 'session_lifetime', 'failed_login_attempts', 'lockout_time',
    'cookie_secure', 'cookie_httponly', 'enable_gdpr', 'gdpr_consent_text'
];

foreach ($requiredCols as $col) {
    if (!in_array($col, $existingCols)) {
        $db->exec("ALTER TABLE settings ADD COLUMN $col TEXT DEFAULT ''");
    }
}

// Refresh settings after ensuring columns exist
$settings = getSettings();

// =============================================================================
// HELPER FUNCTIONS (same as before, with minor improvements)
// =============================================================================

if (!function_exists('getWebImageUrlOrBase64')) {
    function getWebImageUrlOrBase64($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $root = dirname(__DIR__);
        $absPath = $root . '/' . ltrim($path, '/');
        if (file_exists($absPath)) {
            $ext = strtolower(pathinfo($absPath, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $data = @file_get_contents($absPath);
                if ($data !== false) {
                    return 'data:image/' . $ext . ';base64,' . base64_encode($data);
                }
            }
            $webPath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $absPath);
            if ($webPath) return $webPath;
        }
        return getWebImageUrl($path);
    }
}

if (!function_exists('isGdAvailable')) {
    function isGdAvailable() {
        return extension_loaded('gd') && function_exists('imagecreatefromjpeg') && function_exists('imagejpeg');
    }
}

if (!function_exists('safeUploadImage')) {
    function safeUploadImage($file, $targetDir, $prefix, $resize = false, $maxWidth = null, $maxHeight = null) {
        if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);
        $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowed)) {
            return ['error' => 'Invalid file type. Only JPEG, PNG, GIF, WEBP allowed.'];
        }
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = $prefix . '_' . uniqid() . '_' . time() . '.' . $ext;
        $targetPath = $targetDir . $filename;
        if ($resize && isGdAvailable() && $maxWidth && $maxHeight) {
            $result = resizeAndSave($file['tmp_name'], $targetPath, $maxWidth, $maxHeight);
            if ($result === true) {
                return ['success' => true, 'path' => 'uploads/logos/' . $filename];
            }
        }
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => true, 'path' => 'uploads/logos/' . $filename];
        }
        return ['error' => 'Failed to move uploaded file. Check directory permissions.'];
    }
}

if (!function_exists('resizeAndSave')) {
    function resizeAndSave($source, $destination, $maxWidth, $maxHeight) {
        list($origWidth, $origHeight, $type) = @getimagesize($source);
        if (!$origWidth) return false;
        $ratio = min($maxWidth / $origWidth, $maxHeight / $origHeight);
        $newWidth = round($origWidth * $ratio);
        $newHeight = round($origHeight * $ratio);
        $image = null;
        switch ($type) {
            case IMAGETYPE_JPEG: $image = @imagecreatefromjpeg($source); break;
            case IMAGETYPE_PNG: $image = @imagecreatefrompng($source); break;
            case IMAGETYPE_GIF: $image = @imagecreatefromgif($source); break;
            case IMAGETYPE_WEBP: $image = @imagecreatefromwebp($source); break;
            default: return false;
        }
        if (!$image) return false;
        $resized = imagecreatetruecolor($newWidth, $newHeight);
        if ($type == IMAGETYPE_PNG) {
            imagealphablending($resized, false);
            imagesavealpha($resized, true);
            $transparent = imagecolorallocatealpha($resized, 255, 255, 255, 127);
            imagefilledrectangle($resized, 0, 0, $newWidth, $newHeight, $transparent);
        }
        imagecopyresampled($resized, $image, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
        $success = false;
        switch ($type) {
            case IMAGETYPE_JPEG: $success = @imagejpeg($resized, $destination, 85); break;
            case IMAGETYPE_PNG: $success = @imagepng($resized, $destination, 8); break;
            case IMAGETYPE_GIF: $success = @imagegif($resized, $destination); break;
            case IMAGETYPE_WEBP: $success = @imagewebp($resized, $destination, 80); break;
        }
        imagedestroy($image);
        imagedestroy($resized);
        return $success;
    }
}

if (!function_exists('getCurrencySymbol')) {
    function getCurrencySymbol($code) {
        $symbols = [
            'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'JPY' => '¥', 'CNY' => '¥', 'INR' => '₹',
            'AED' => 'د.إ', 'SAR' => '﷼', 'QAR' => '﷼', 'KWD' => 'د.ك', 'BHD' => '.د.ب', 'OMR' => '﷼',
            'CAD' => 'C$', 'AUD' => 'A$', 'CHF' => 'Fr', 'SEK' => 'kr', 'NOK' => 'kr', 'DKK' => 'kr',
            'PLN' => 'zł', 'TRY' => '₺', 'RUB' => '₽', 'ZAR' => 'R', 'BRL' => 'R$', 'MXN' => '$',
            'SGD' => 'S$', 'HKD' => 'HK$', 'MYR' => 'RM', 'THB' => '฿', 'VND' => '₫', 'PHP' => '₱',
            'IDR' => 'Rp', 'PKR' => '₨', 'BDT' => '৳', 'LKR' => '₨', 'NPR' => '₨', 'EGP' => 'E£',
            'NGN' => '₦', 'KES' => 'KSh', 'GHS' => '₵', 'TZS' => 'TSh', 'UGX' => 'USh', 'MAD' => 'د.م.',
            'DZD' => 'د.ج', 'TND' => 'د.ت', 'LYD' => 'ل.د', 'IQD' => 'ع.د', 'JOD' => 'د.ا', 'LBP' => 'ل.ل',
            'SYP' => '£S', 'ILS' => '₪', 'AZN' => '₼', 'KZT' => '₸', 'UZS' => 'soʻm', 'GEL' => '₾', 'AMD' => '֏'
        ];
        return $symbols[$code] ?? $code;
    }
}

if (!function_exists('getCirculationRules')) {
    function getCirculationRules() {
        global $settings, $defaultCirculationRules;
        $categoryRulesEnabled = (int)($settings['enable_category_rules'] ?? 1);
        if ($categoryRulesEnabled && !empty($settings['circulation_rules'])) {
            $rules = json_decode($settings['circulation_rules'], true);
            if (is_array($rules) && !empty($rules)) {
                return $rules;
            }
        }
        return $defaultCirculationRules;
    }
}

if (!function_exists('getCategoryLabel')) {
    function getCategoryLabel($categoryKey) {
        global $memberCategories;
        foreach ($memberCategories as $group => $data) {
            if (isset($data['sub_categories'][$categoryKey])) {
                return $data['sub_categories'][$categoryKey];
            }
        }
        return ucwords(str_replace('_', ' ', $categoryKey));
    }
}

if (!function_exists('createBackupFile')) {
    function createBackupFile($includeUploads = true, $compress = true) {
        $backupDir = BACKUP_DIR;
        if (!is_dir($backupDir)) mkdir($backupDir, 0777, true);
        $timestamp = date('Y-m-d_H-i-s');
        $dbFile = DB_FILE;
        if (!$compress) {
            $backupFile = $backupDir . "library_backup_{$timestamp}.sqlite";
            if (!copy($dbFile, $backupFile)) return false;
            if ($includeUploads && is_dir(UPLOAD_DIR)) {
                $uploadsBackup = $backupDir . "uploads_backup_{$timestamp}";
                if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                    exec("xcopy \"" . str_replace('/', '\\', UPLOAD_DIR) . "\" \"" . str_replace('/', '\\', $uploadsBackup) . "\\\" /E /I /Q 2>NUL");
                } else {
                    exec("cp -r '" . UPLOAD_DIR . "' '$uploadsBackup' 2>/dev/null");
                }
            }
            return $backupFile;
        }
        $tempDb = $backupDir . "temp_backup_{$timestamp}.sqlite";
        if (!copy($dbFile, $tempDb)) return false;
        $zipFile = $backupDir . "library_backup_{$timestamp}.zip";
        $zip = new ZipArchive();
        if ($zip->open($zipFile, ZipArchive::CREATE) !== true) {
            @unlink($tempDb);
            return false;
        }
        $zip->addFile($tempDb, basename($tempDb));
        if ($includeUploads && is_dir(UPLOAD_DIR)) {
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(UPLOAD_DIR, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($files as $file) {
                if ($file->isFile()) {
                    $filePath = $file->getRealPath();
                    $relativePath = 'uploads/' . substr($filePath, strlen(UPLOAD_DIR));
                    $zip->addFile($filePath, $relativePath);
                }
            }
        }
        $zip->close();
        @unlink($tempDb);
        return $zipFile;
    }
}

if (!function_exists('cleanupOldLocalBackups')) {
    function cleanupOldLocalBackups() {
        global $settings;
        $backupDir = BACKUP_DIR;
        $retentionDays = (int)($settings['local_backup_retention'] ?? 30);
        $cutoffTime = time() - ($retentionDays * 86400);
        $files = array_merge(
            glob($backupDir . 'library_backup_*.zip'),
            glob($backupDir . 'library_backup_*.sqlite')
        );
        foreach ($files as $file) {
            if (filemtime($file) < $cutoffTime) {
                unlink($file);
            }
        }
    }
}

// =============================================================================
// AJAX HANDLERS
// =============================================================================

if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_fine_rates') {
    header('Content-Type: application/json');
    echo json_encode($db->query("SELECT * FROM fine_rates ORDER BY member_category")->fetchAll());
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_fine_rates'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'CSRF token validation failed']);
        exit;
    }
    header('Content-Type: application/json');
    $rates = json_decode($_POST['rates'], true);
    $db->beginTransaction();
    try {
        $db->exec("DELETE FROM fine_rates");
        $stmt = $db->prepare("INSERT INTO fine_rates (member_category, fine_per_day, max_fine, grace_period_days) VALUES (?, ?, ?, ?)");
        foreach ($rates as $r) {
            if (!empty($r['category'])) {
                $stmt->execute([
                    $r['category'],
                    (float)$r['fine'],
                    (float)($r['max_fine'] ?? 0),
                    (int)($r['grace_period'] ?? 0)
                ]);
            }
        }
        $db->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// =============================================================================
// SETTINGS UPDATE HANDLER
// =============================================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token.", "danger");
        header("Location: settings.php");
        exit;
    }

    try {
        // Process image uploads (same as before)
        $logoPath = $settings['library_logo'] ?? '';
        $faviconPath = $settings['favicon_path'] ?? '';
        $opacHeaderLogo = $settings['opac_header_logo'] ?? '';
        $visitorHeaderLogo = $settings['visitor_header_logo'] ?? '';
        $reportLogoRight = $settings['report_logo_right'] ?? '';
        $reportSignatureImage = $settings['report_signature_image'] ?? '';
        $reportLogo = $settings['report_logo'] ?? '';
        $libraryLogo = $settings['library_logo'] ?? '';

        $processImageUpload = function($fileKey, $prefix, $resize = false, $maxWidth = null, $maxHeight = null) use ($rootPath) {
            if (isset($_FILES[$fileKey]) && $_FILES[$fileKey]['error'] === UPLOAD_ERR_OK) {
                $result = safeUploadImage($_FILES[$fileKey], LOGO_DIR, $prefix, $resize, $maxWidth, $maxHeight);
                if (isset($result['error'])) {
                    showToast($result['error'], "danger");
                    return null;
                }
                return $result['path'];
            }
            return null;
        };

        $newLogo = $processImageUpload('library_logo', 'logo', true, 200, 60);
        if ($newLogo !== null) {
            if ($logoPath && file_exists($rootPath . '/' . $logoPath)) unlink($rootPath . '/' . $logoPath);
            $logoPath = $newLogo;
        }
        if (isset($_POST['remove_logo']) && $_POST['remove_logo'] == '1') {
            if ($logoPath && file_exists($rootPath . '/' . $logoPath)) unlink($rootPath . '/' . $logoPath);
            $logoPath = '';
        }

        $newFavicon = $processImageUpload('favicon', 'favicon', true, 64, 64);
        if ($newFavicon !== null) {
            if ($faviconPath && file_exists($rootPath . '/' . $faviconPath)) unlink($rootPath . '/' . $faviconPath);
            $faviconPath = $newFavicon;
        }
        if (isset($_POST['remove_favicon']) && $_POST['remove_favicon'] == '1') {
            if ($faviconPath && file_exists($rootPath . '/' . $faviconPath)) unlink($rootPath . '/' . $faviconPath);
            $faviconPath = '';
        }

        $newOpacLogo = $processImageUpload('opac_header_logo', 'opac_header', true, 150, 60);
        if ($newOpacLogo !== null) {
            if ($opacHeaderLogo && file_exists($rootPath . '/' . $opacHeaderLogo)) unlink($rootPath . '/' . $opacHeaderLogo);
            $opacHeaderLogo = $newOpacLogo;
        }
        if (isset($_POST['remove_opac_header_logo']) && $_POST['remove_opac_header_logo'] == '1') {
            if ($opacHeaderLogo && file_exists($rootPath . '/' . $opacHeaderLogo)) unlink($rootPath . '/' . $opacHeaderLogo);
            $opacHeaderLogo = '';
        }

        $newVisitorLogo = $processImageUpload('visitor_header_logo', 'visitor_header', false);
        if ($newVisitorLogo !== null) {
            if ($visitorHeaderLogo && file_exists($rootPath . '/' . $visitorHeaderLogo)) unlink($rootPath . '/' . $visitorHeaderLogo);
            $visitorHeaderLogo = $newVisitorLogo;
        }
        if (isset($_POST['remove_visitor_header_logo']) && $_POST['remove_visitor_header_logo'] == '1') {
            if ($visitorHeaderLogo && file_exists($rootPath . '/' . $visitorHeaderLogo)) unlink($rootPath . '/' . $visitorHeaderLogo);
            $visitorHeaderLogo = '';
        }

        $newReportRight = $processImageUpload('report_logo_right', 'report_logo_right', false);
        if ($newReportRight !== null) {
            if ($reportLogoRight && file_exists($rootPath . '/' . $reportLogoRight)) unlink($rootPath . '/' . $reportLogoRight);
            $reportLogoRight = $newReportRight;
        }
        if (isset($_POST['remove_report_logo_right']) && $_POST['remove_report_logo_right'] == '1') {
            if ($reportLogoRight && file_exists($rootPath . '/' . $reportLogoRight)) unlink($rootPath . '/' . $reportLogoRight);
            $reportLogoRight = '';
        }

        $newSignature = $processImageUpload('report_signature_image', 'report_signature', false);
        if ($newSignature !== null) {
            if ($reportSignatureImage && file_exists($rootPath . '/' . $reportSignatureImage)) unlink($rootPath . '/' . $reportSignatureImage);
            $reportSignatureImage = $newSignature;
        }
        if (isset($_POST['remove_report_signature_image']) && $_POST['remove_report_signature_image'] == '1') {
            if ($reportSignatureImage && file_exists($rootPath . '/' . $reportSignatureImage)) unlink($rootPath . '/' . $reportSignatureImage);
            $reportSignatureImage = '';
        }

        $newReportLogo = $processImageUpload('report_logo', 'report_logo', false);
        if ($newReportLogo !== null) {
            if ($reportLogo && file_exists($rootPath . '/' . $reportLogo)) unlink($rootPath . '/' . $reportLogo);
            $reportLogo = $newReportLogo;
        }
        if (isset($_POST['remove_report_logo']) && $_POST['remove_report_logo'] == '1') {
            if ($reportLogo && file_exists($rootPath . '/' . $reportLogo)) unlink($rootPath . '/' . $reportLogo);
            $reportLogo = '';
        }

        $checkbox = function($key) {
            return isset($_POST[$key]) ? 1 : 0;
        };
        $strVal = function($key, $default = '') {
            return trim($_POST[$key] ?? $default);
        };
        $intVal = function($key, $default = 0) {
            return (int)($_POST[$key] ?? $default);
        };
        $floatVal = function($key, $default = 0) {
            return (float)($_POST[$key] ?? $default);
        };

        $enableCategoryRules = isset($_POST['enable_category_rules']) ? 1 : 0;
        $circulationRules = [];
        if ($enableCategoryRules) {
            foreach ($defaultCirculationRules as $category => $defaults) {
                $circulationRules[$category] = [
                    'max_books' => $intVal('rule_' . $category . '_max_books', $defaults['max_books']),
                    'loan_days' => $intVal('rule_' . $category . '_loan_days', $defaults['loan_days']),
                    'max_renewals' => $intVal('rule_' . $category . '_max_renewals', $defaults['max_renewals']),
                    'fine_per_day' => $floatVal('rule_' . $category . '_fine_per_day', $defaults['fine_per_day']),
                    'max_fine_amount' => $floatVal('rule_' . $category . '_max_fine_amount', $defaults['max_fine_amount'])
                ];
            }
        } else {
            $circulationRules = $defaultCirculationRules;
        }

        // Build all settings fields (same as before)
        $updateFields = [
            // Core
            'software_header' => $strVal('software_header', 'Library ERP System'),
            'library_logo' => $logoPath,
            'favicon_path' => $faviconPath,
            'menu_position' => $strVal('menu_position', 'top'),
            'auto_logout_minutes' => $intVal('auto_logout_minutes', 30),
            'new_arrivals_count' => $intVal('new_arrivals_count', 10),
            'default_language' => $strVal('default_language', 'en'),
            'staff_display_enabled' => $checkbox('staff_display_enabled'),
            'enable_audit_log' => $checkbox('enable_audit_log'),
            'audit_log_retention_days' => $intVal('audit_log_retention_days', 90),
            'site_maintenance_mode' => $checkbox('site_maintenance_mode'),
            'maintenance_message' => $strVal('maintenance_message'),
            'enable_member_notifications' => $checkbox('enable_member_notifications'),

            // OPAC
            'opac_enabled' => $checkbox('opac_enabled'),
            'opac_show_new_arrivals' => $checkbox('opac_show_new_arrivals'),
            'opac_show_popular_ebooks' => $checkbox('opac_show_popular_ebooks'),
            'opac_show_latest_ebooks' => $checkbox('opac_show_latest_ebooks'),
            'opac_show_notices' => $checkbox('opac_show_notices'),
            'opac_show_trending' => $checkbox('opac_show_trending'),
            'opac_show_databases' => $checkbox('opac_show_databases'),
            'opac_show_thought_of_the_day' => $checkbox('opac_show_thought_of_the_day'),
            'opac_show_new_arrivals_in_left' => $checkbox('opac_show_new_arrivals_in_left'),
            'opac_quote_rotation_interval' => $intVal('opac_quote_rotation_interval', 10),
            'opac_carousel_type' => $strVal('opac_carousel_type', 'cover_flow'),
            'opac_header_text' => $strVal('opac_header_text'),
            'opac_tagline' => $strVal('opac_tagline'),
            'opac_books_per_page' => $intVal('opac_books_per_page', 12),
            'opac_ebooks_per_page' => $intVal('opac_ebooks_per_page', 8),
            'opac_notice_title' => $strVal('opac_notice_title'),
            'opac_notice_content' => $strVal('opac_notice_content'),
            'opac_header_logo' => $opacHeaderLogo,
            'opac_font_family' => $strVal('opac_font_family', 'Inter'),
            'opac_base_font_size' => $intVal('opac_base_font_size', 16),
            'opac_heading_font_size' => $intVal('opac_heading_font_size', 32),
            'opac_font_weight' => $strVal('opac_font_weight', '400'),
            'opac_primary_color' => $strVal('opac_primary_color', '#1e3c72'),
            'opac_header_bg_color' => $strVal('opac_header_bg_color', '#1e3c72'),
            'opac_body_bg' => $strVal('opac_body_bg', '#f0f2f5'),
            'opac_custom_css' => $strVal('opac_custom_css'),
            'container_max_width' => $intVal('container_max_width', 1600),
            'container_padding' => $intVal('container_padding', 10),
            'openai_api_key' => $strVal('openai_api_key'),

            // Circulation
            'loan_days' => $intVal('loan_days', 7),
            'fine_per_day' => $floatVal('fine_per_day', 2),
            'max_books' => $intVal('max_books', 5),
            'max_renewals' => $intVal('max_renewals', 0),
            'allow_holds' => $checkbox('allow_holds'),
            'hold_days' => $intVal('hold_days', 7),
            'enforce_library_hours' => $checkbox('enforce_library_hours'),
            'enable_self_registration' => $checkbox('enable_self_registration'),
            'self_registration_role' => $strVal('self_registration_role', 'Student'),
            'max_fine_amount' => $floatVal('max_fine_amount', 0),
            'currency_code' => $strVal('currency_code', 'INR'),
            'currency_decimal_places' => $intVal('currency_decimal_places', 2),
            'enable_category_rules' => $enableCategoryRules,
            'circulation_rules' => json_encode($circulationRules),

            // Notifications
            'notify_overdue' => $checkbox('notify_overdue'),
            'enable_email' => $checkbox('enable_email'),
            'enable_sms' => $checkbox('enable_sms'),
            'smtp_host' => $strVal('smtp_host'),
            'smtp_port' => $intVal('smtp_port', 587),
            'smtp_encryption' => $strVal('smtp_encryption', 'tls'),
            'smtp_username' => $strVal('smtp_username'),
            'smtp_password' => $strVal('smtp_password'),
            'mail_from' => $strVal('mail_from'),
            'mail_from_name' => $strVal('mail_from_name'),
            'backup_email' => $strVal('backup_email'),
            'sms_api_key' => $strVal('sms_api_key'),
            'email_template_overdue' => $strVal('email_template_overdue'),
            'sms_template_overdue' => $strVal('sms_template_overdue'),
            'whatsapp_template_overdue' => $strVal('whatsapp_template_overdue'),

            // Member Portal
            'enable_member_password_reset' => $checkbox('enable_member_password_reset'),
            'reset_token_expiry_hours' => $intVal('reset_token_expiry_hours', 24),
            'allow_member_password_change' => $checkbox('allow_member_password_change'),
            'enable_member_portal' => $checkbox('enable_member_portal'),
            'member_portal_theme' => $strVal('member_portal_theme', 'light'),
            'member_portal_primary_color' => $strVal('member_portal_primary_color', '#1e3c72'),
            'member_portal_custom_css' => $strVal('member_portal_custom_css'),
            'member_portal_show_my_books' => $checkbox('member_portal_show_my_books'),
            'member_portal_show_fines' => $checkbox('member_portal_show_fines'),
            'member_portal_show_holds' => $checkbox('member_portal_show_holds'),
            'member_portal_show_history' => $checkbox('member_portal_show_history'),
            'member_portal_show_profile' => $checkbox('member_portal_show_profile'),

            // Backup
            'backup_schedule' => $strVal('backup_schedule', 'manual'),
            'backup_time' => $strVal('backup_time', '00:00'),
            'local_backup_retention' => $intVal('local_backup_retention', 30),
            'backup_include_uploads' => $checkbox('backup_include_uploads'),
            'backup_compress' => $checkbox('backup_compress'),
            'backup_notification_email' => $strVal('backup_notification_email'),

            // Cloud Storage
            'cloud_storage_provider' => $strVal('cloud_storage_provider', 'local'),
            'cloud_folder_id' => $strVal('cloud_folder_id'),
            'cloud_api_key' => $strVal('cloud_api_key'),
            'cloud_api_secret' => $strVal('cloud_api_secret'),
            'cloud_refresh_token' => $strVal('cloud_refresh_token'),

            // Google Drive
            'google_drive_enabled' => $checkbox('google_drive_enabled'),
            'google_drive_service_account_json' => $strVal('google_drive_service_account_json'),
            'google_drive_folder_id' => $strVal('google_drive_folder_id'),
            'google_drive_client_id' => $strVal('google_drive_client_id'),
            'google_drive_client_secret' => $strVal('google_drive_client_secret'),
            'google_drive_refresh_token' => $strVal('google_drive_refresh_token'),
            'google_drive_auto_delete_days' => $intVal('google_drive_auto_delete_days', 30),

            // Dropbox
            'dropbox_enabled' => $checkbox('dropbox_enabled'),
            'dropbox_access_token' => $strVal('dropbox_access_token'),
            'dropbox_app_key' => $strVal('dropbox_app_key'),
            'dropbox_app_secret' => $strVal('dropbox_app_secret'),

            // OneDrive
            'onedrive_enabled' => $checkbox('onedrive_enabled'),
            'onedrive_client_id' => $strVal('onedrive_client_id'),
            'onedrive_client_secret' => $strVal('onedrive_client_secret'),
            'onedrive_refresh_token' => $strVal('onedrive_refresh_token'),

            // pCloud
            'pcloud_enabled' => $checkbox('pcloud_enabled'),
            'pcloud_access_token' => $strVal('pcloud_access_token'),
            'pcloud_username' => $strVal('pcloud_username'),
            'pcloud_password_hash' => !empty($_POST['pcloud_password']) ?
                password_hash($_POST['pcloud_password'], PASSWORD_DEFAULT) :
                ($settings['pcloud_password_hash'] ?? ''),

            // Internxt
            'internxt_enabled' => $checkbox('internxt_enabled'),
            'internxt_api_key' => $strVal('internxt_api_key'),
            'internxt_api_secret' => $strVal('internxt_api_secret'),
            'internxt_bucket' => $strVal('internxt_bucket'),
            'internxt_region' => $strVal('internxt_region'),

            // MEGA
            'mega_enabled' => $checkbox('mega_enabled'),
            'mega_email' => $strVal('mega_email'),
            'mega_folder_id' => $strVal('mega_folder_id'),
            'mega_password_hash' => !empty($_POST['mega_password']) ?
                password_hash($_POST['mega_password'], PASSWORD_DEFAULT) :
                ($settings['mega_password_hash'] ?? ''),

            // Sync.com
            'sync_enabled' => $checkbox('sync_enabled'),
            'sync_api_key' => $strVal('sync_api_key'),
            'sync_api_secret' => $strVal('sync_api_secret'),
            'sync_folder_id' => $strVal('sync_folder_id'),

            // Terabox
            'terabox_enabled' => $checkbox('terabox_enabled'),
            'terabox_api_key' => $strVal('terabox_api_key'),
            'terabox_api_secret' => $strVal('terabox_api_secret'),
            'terabox_folder_id' => $strVal('terabox_folder_id'),

            // Backblaze
            'backblaze_enabled' => $checkbox('backblaze_enabled'),
            'backblaze_key_id' => $strVal('backblaze_key_id'),
            'backblaze_application_key' => $strVal('backblaze_application_key'),
            'backblaze_bucket_name' => $strVal('backblaze_bucket_name'),

            // Wasabi
            'wasabi_enabled' => $checkbox('wasabi_enabled'),
            'wasabi_access_key' => $strVal('wasabi_access_key'),
            'wasabi_secret_key' => $strVal('wasabi_secret_key'),
            'wasabi_bucket' => $strVal('wasabi_bucket'),
            'wasabi_region' => $strVal('wasabi_region', 'us-east-1'),

            // S3
            's3_enabled' => $checkbox('s3_enabled'),
            's3_access_key' => $strVal('s3_access_key'),
            's3_secret_key' => $strVal('s3_secret_key'),
            's3_bucket' => $strVal('s3_bucket'),
            's3_region' => $strVal('s3_region', 'us-east-1'),
            's3_endpoint' => $strVal('s3_endpoint'),

            // Visitor
            'visitor_header_logo' => $visitorHeaderLogo,
            'visitor_header_text' => $strVal('visitor_header_text'),
            'visitor_tagline' => $strVal('visitor_tagline'),
            'visitor_header_bg' => $strVal('visitor_header_bg', '#1e3c72'),
            'visitor_body_bg' => $strVal('visitor_body_bg', '#f0f2f5'),
            'visitor_footer_bg' => $strVal('visitor_footer_bg', '#1e3c72'),
            'visitor_font_family' => $strVal('visitor_font_family', 'Inter'),
            'visitor_base_font_size' => $intVal('visitor_base_font_size', 16),
            'visitor_primary_color' => $strVal('visitor_primary_color', '#28a745'),

            // Guest
            'guest_enabled' => $checkbox('guest_enabled'),
            'guest_prefix' => $strVal('guest_prefix', 'GUEST-'),
            'guest_number_padding' => $intVal('guest_number_padding', 4),

            // Library Hours
            'library_open_days' => isset($_POST['library_open_days']) ?
                implode(',', $_POST['library_open_days']) : '',
            'library_open_time' => $strVal('library_open_time', '09:00'),
            'library_close_time' => $strVal('library_close_time', '18:00'),
            'library_lunch_start' => $strVal('library_lunch_start'),
            'library_lunch_end' => $strVal('library_lunch_end'),
            'library_timezone' => $strVal('library_timezone', 'Asia/Kolkata'),

            // Report
            'report_font_size' => $intVal('report_font_size', 10),
            'report_primary_color' => $strVal('report_primary_color', '#1e3c72'),
            'report_logo_position' => $strVal('report_logo_position', 'left'),
            'report_logo_right' => $reportLogoRight,
            'report_watermark_enabled' => $checkbox('report_watermark_enabled'),
            'report_watermark_text' => $strVal('report_watermark_text'),
            'report_watermark_opacity' => $intVal('report_watermark_opacity', 10),
            'report_signature_enabled' => $checkbox('report_signature_enabled'),
            'report_signature_name' => $strVal('report_signature_name', 'Librarian'),
            'report_signature_title' => $strVal('report_signature_title', 'Chief Librarian'),
            'report_signature_image' => $reportSignatureImage,
            'report_footer_text' => $strVal('report_footer_text'),
            'report_logo' => $reportLogo,

            // Institution
            'current_institution_id' => $intVal('current_institution_id', 1),

            // WhatsApp
            'whatsapp_number' => $strVal('whatsapp_number'),
            'whatsapp_message' => $strVal('whatsapp_message'),
            'whatsapp_api_type' => $strVal('whatsapp_api_type', 'whatsapp'),
            'whatsapp_api_url' => $strVal('whatsapp_api_url'),
            'whatsapp_api_token' => $strVal('whatsapp_api_token'),
            'whatsapp_phone_number_id' => $strVal('whatsapp_phone_number_id'),
            'whatsapp_business_account_id' => $strVal('whatsapp_business_account_id'),
            'whatsapp_webhook_verified' => $checkbox('whatsapp_webhook_verified'),
            'whatsapp_auto_reply_enabled' => $checkbox('whatsapp_auto_reply_enabled'),
            'whatsapp_auto_reply_message' => $strVal('whatsapp_auto_reply_message'),
            'whatsapp_out_of_hours_reply' => $strVal('whatsapp_out_of_hours_reply'),
            'whatsapp_booking_enabled' => $checkbox('whatsapp_booking_enabled'),
            'whatsapp_notify_overdue_enabled' => $checkbox('whatsapp_notify_overdue_enabled'),
            'whatsapp_notify_hold_ready_enabled' => $checkbox('whatsapp_notify_hold_ready_enabled'),
            'whatsapp_welcome_message' => $strVal('whatsapp_welcome_message'),
            'whatsapp_template_hold_ready' => $strVal('whatsapp_template_hold_ready'),
            'whatsapp_template_payment' => $strVal('whatsapp_template_payment'),
            'whatsapp_template_event' => $strVal('whatsapp_template_event'),

            // Advanced - Acquisition
            'source_options' => $strVal('source_options'),
            'default_source' => $strVal('default_source'),
            'enable_auto_supply_date' => $checkbox('enable_auto_supply_date'),

            // Advanced - Multi-Branch
            'enable_multi_branch' => $checkbox('enable_multi_branch'),
            'enable_budgeting' => $checkbox('enable_budgeting'),
            'enable_interlibrary' => $checkbox('enable_interlibrary'),
            'enable_course_reserves' => $checkbox('enable_course_reserves'),
            'digital_asset_tracking' => $checkbox('digital_asset_tracking'),
            'detailed_audit_log' => $checkbox('detailed_audit_log'),
            'auto_scheduled_jobs' => $checkbox('auto_scheduled_jobs'),

            // Advanced - GDPR
            'enable_gdpr_compliance' => $checkbox('enable_gdpr_compliance'),
            'gdpr_data_retention_days' => $intVal('gdpr_data_retention_days', 365),

            // Advanced - API
            'enable_api_rate_limiting' => $checkbox('enable_api_rate_limiting'),
            'api_rate_limit_per_minute' => $intVal('api_rate_limit_per_minute', 60),

            // Advanced - Webhooks
            'enable_webhooks' => $checkbox('enable_webhooks'),
            'webhook_url' => $strVal('webhook_url'),
            'webhook_secret' => $strVal('webhook_secret'),

            // Advanced - SSO
            'enable_sso' => $checkbox('enable_sso'),
            'sso_provider' => $strVal('sso_provider'),
            'sso_client_id' => $strVal('sso_client_id'),
            'sso_client_secret' => $strVal('sso_client_secret'),
            'sso_redirect_uri' => $strVal('sso_redirect_uri'),

            // Advanced - OAuth
            'enable_oauth' => $checkbox('enable_oauth'),
            'oauth_provider' => $strVal('oauth_provider'),
            'oauth_client_id' => $strVal('oauth_client_id'),
            'oauth_client_secret' => $strVal('oauth_client_secret'),
            'oauth_redirect_uri' => $strVal('oauth_redirect_uri'),

            // Advanced - SAML
            'enable_saml' => $checkbox('enable_saml'),
            'saml_idp_metadata_url' => $strVal('saml_idp_metadata_url'),
            'saml_sp_entity_id' => $strVal('saml_sp_entity_id'),
            'saml_sp_acs_url' => $strVal('saml_sp_acs_url'),

            // Advanced - LDAP
            'enable_ldap' => $checkbox('enable_ldap'),
            'ldap_host' => $strVal('ldap_host'),
            'ldap_port' => $intVal('ldap_port', 389),
            'ldap_encryption' => $strVal('ldap_encryption', 'none'),
            'ldap_base_dn' => $strVal('ldap_base_dn'),
            'ldap_bind_dn' => $strVal('ldap_bind_dn'),
            'ldap_bind_password' => $strVal('ldap_bind_password'),
            'ldap_user_filter' => $strVal('ldap_user_filter'),

            // Advanced - reCAPTCHA
            'enable_recaptcha' => $checkbox('enable_recaptcha'),
            'recaptcha_site_key' => $strVal('recaptcha_site_key'),
            'recaptcha_secret_key' => $strVal('recaptcha_secret_key'),
            'enable_captcha_on_login' => $checkbox('enable_captcha_on_login'),
            'enable_captcha_on_registration' => $checkbox('enable_captcha_on_registration'),

            // Advanced - AI Recommendations
            'enable_ai_recommendations' => $checkbox('enable_ai_recommendations'),
            'ai_recommendation_model' => $strVal('ai_recommendation_model', 'collaborative'),
            'ai_max_recommendations' => $intVal('ai_max_recommendations', 10),

            // Advanced - Search
            'enable_advanced_search' => $checkbox('enable_advanced_search'),
            'search_highlight_color' => $strVal('search_highlight_color', '#ffeb3b'),
            'enable_auto_suggest' => $checkbox('enable_auto_suggest'),
            'auto_suggest_limit' => $intVal('auto_suggest_limit', 10),

            // Advanced - Analytics
            'enable_analytics' => $checkbox('enable_analytics'),
            'analytics_tracking_id' => $strVal('analytics_tracking_id'),
            'enable_heatmaps' => $checkbox('enable_heatmaps'),
            'enable_session_recording' => $checkbox('enable_session_recording'),
            'enable_ab_testing' => $checkbox('enable_ab_testing'),
            'enable_feature_flags' => $checkbox('enable_feature_flags'),
            'feature_flags_config' => $strVal('feature_flags_config', '{}'),

            // Security settings
            'enable_2fa' => $checkbox('enable_2fa'),
            'session_lifetime' => $intVal('session_lifetime', 7200),
            'failed_login_attempts' => $intVal('failed_login_attempts', 5),
            'lockout_time' => $intVal('lockout_time', 15),
            'cookie_secure' => $checkbox('cookie_secure'),
            'cookie_httponly' => $checkbox('cookie_httponly'),
            'enable_gdpr' => $checkbox('enable_gdpr'),
            'gdpr_consent_text' => $strVal('gdpr_consent_text')
        ];

        // Build and execute update query
        $sql = "UPDATE settings SET " . implode(" = ?, ", array_keys($updateFields)) . " = ? WHERE id = 1";
        $stmt = $db->prepare($sql);
        $stmt->execute(array_values($updateFields));

        showToast("Settings updated successfully", "success");
        logActivity($_SESSION['username'], 'SETTINGS_UPDATE', 'System settings updated');
        $settings = getSettings();
        header("Location: settings.php");
        exit;

    } catch (PDOException $e) {
        showToast("Settings update failed: " . $e->getMessage(), "danger");
    }
}

// =============================================================================
// RESET TO DEFAULTS HANDLER
// =============================================================================

if (isset($_POST['reset_defaults']) && isset($_POST['confirm_reset']) && $_POST['confirm_reset'] === 'yes') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid token.", "danger");
        header("Location: settings.php");
        exit;
    }

    // Delete all settings rows and re-insert default row
    $db->exec("DELETE FROM settings WHERE id = 1");
    $stmt = $db->prepare("INSERT INTO settings (id) VALUES (1)");
    $stmt->execute();

    // Now get default settings
    $settings = getSettings();
    showToast("All settings have been reset to defaults.", "warning");
    header("Location: settings.php");
    exit;
}

// =============================================================================
// MANUAL BACKUP HANDLER
// =============================================================================

if (isset($_POST['manual_backup'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid token.", "danger");
        header("Location: settings.php");
        exit;
    }
    $includeUploads = isset($_POST['backup_include_uploads']) ? ($_POST['backup_include_uploads'] == '1') : true;
    $compress = isset($_POST['backup_compress']) ? ($_POST['backup_compress'] == '1') : true;
    $backupFile = createBackupFile($includeUploads, $compress);
    if (!$backupFile) {
        showToast("Failed to create backup", "danger");
    } else {
        showToast("Backup created: " . basename($backupFile), "success");
        $db->prepare("UPDATE settings SET last_backup_time = datetime('now') WHERE id = 1")->execute();
        cleanupOldLocalBackups();
    }
    header("Location: settings.php");
    exit;
}

// =============================================================================
// TEST EMAIL HANDLER
// =============================================================================

if (isset($_POST['test_email']) && isset($_POST['test_recipient'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid token.", "danger");
        header("Location: settings.php");
        exit;
    }
    $recipient = trim($_POST['test_recipient']);
    $subject = "Test Email from Library ERP";
    $message = "This is a test email from your Library ERP system.<br>SMTP settings are working.";
    if (sendEmail($recipient, $subject, $message)) {
        showToast("Test email sent to $recipient", "success");
    } else {
        showToast("Failed to send test email. Check SMTP settings.", "danger");
    }
    header("Location: settings.php");
    exit;
}

// =============================================================================
// CLEAR CACHE & OPTIMIZE DB
// =============================================================================

if (isset($_POST['clear_cache'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid token.", "danger");
        header("Location: settings.php");
        exit;
    }
    $tempFiles = glob(BACKUP_DIR . 'temp_*');
    foreach ($tempFiles as $file) {
        if (is_file($file)) unlink($file);
    }
    showToast("Cache cleared", "success");
    header("Location: settings.php");
    exit;
}

if (isset($_POST['optimize_db'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid token.", "danger");
        header("Location: settings.php");
        exit;
    }
    $db->exec("VACUUM");
    showToast("Database optimized", "success");
    header("Location: settings.php");
    exit;
}

// =============================================================================
// SYSTEM STATS
// =============================================================================

$totalMembers = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$totalBooks = $db->query("SELECT SUM(quantity) FROM books")->fetchColumn();
$totalCirculation = $db->query("SELECT COUNT(*) FROM circulation")->fetchColumn();
$dbSize = file_exists(DB_FILE) ? round(filesize(DB_FILE) / 1024 / 1024, 2) : 0;
$categoryRulesEnabled = (int)($settings['enable_category_rules'] ?? 1);
$circulationRules = getCirculationRules();

// =============================================================================
// RENDER PAGE
// =============================================================================

renderHeader('System Settings');

// Dark mode CSS class
$bodyClass = $darkMode ? 'dark-mode' : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg-body: #f0f2f5;
            --bg-card: #ffffff;
            --text-primary: #212529;
            --border-color: #e9ecef;
            --shadow: rgba(0,0,0,0.05);
            --shadow-hover: rgba(0,0,0,0.1);
        }
        .dark-mode {
            --bg-body: #1a1a2e;
            --bg-card: #2d2d44;
            --text-primary: #e9ecef;
            --border-color: #3a3a5a;
            --shadow: rgba(0,0,0,0.3);
            --shadow-hover: rgba(0,0,0,0.5);
        }
        body {
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
        }
        .card {
            background: var(--bg-card);
            border-color: var(--border-color);
            box-shadow: 0 5px 20px var(--shadow);
            transition: background 0.3s, border-color 0.3s, box-shadow 0.3s;
        }
        .card-hover:hover {
            box-shadow: 0 10px 25px var(--shadow-hover) !important;
        }
        .card-header {
            background: transparent;
            border-bottom-color: var(--border-color);
        }
        .form-control, .form-select {
            background: var(--bg-body);
            color: var(--text-primary);
            border-color: var(--border-color);
        }
        .form-control:focus, .form-select:focus {
            background: var(--bg-body);
            color: var(--text-primary);
            border-color: #1e3c72;
            box-shadow: 0 0 0 0.2rem rgba(30,60,114,0.25);
        }
        .table {
            color: var(--text-primary);
        }
        .table th {
            border-bottom-color: var(--border-color);
        }
        .table td {
            border-top-color: var(--border-color);
        }
        .alert {
            background: var(--bg-card);
            border-color: var(--border-color);
            color: var(--text-primary);
        }
        .settings-info {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
        }
        .nav-tabs .nav-link {
            color: var(--text-primary);
            border-bottom: 2px solid transparent;
        }
        .nav-tabs .nav-link:hover {
            border-bottom-color: #1e3c72;
            color: var(--text-primary);
        }
        .nav-tabs .nav-link.active {
            color: #1e3c72;
            border-bottom-color: #1e3c72;
            background: transparent;
        }
        .logo-preview {
            max-height: 60px;
            width: auto;
            object-fit: contain;
        }
        .help-tip {
            color: #6c757d;
            cursor: help;
            margin-left: 4px;
            font-size: 0.9rem;
        }
        .help-tip:hover {
            color: #1e3c72;
        }
        .fine-rate-row td {
            vertical-align: middle;
        }
        .fine-rate-row input {
            width: 100%;
        }
        @media (max-width: 768px) {
            .nav-tabs .nav-link { font-size: 0.8rem; padding: 0.3rem 0.6rem; }
            .tab-pane { padding-top: 10px; }
            .settings-info .col-md-8, .settings-info .col-md-4 { text-align: center; }
        }
    </style>
</head>
<body class="<?= $bodyClass ?>">

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-cog text-primary"></i> System Settings</h2>
        <div class="btn-group">
            <a href="?toggle_dark=1" class="btn btn-outline-secondary" title="Toggle Dark Mode">
                <i class="fas fa-<?= $darkMode ? 'sun' : 'moon' ?>"></i>
            </a>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <a href="backup.php" class="btn btn-info"><i class="fas fa-database"></i> Backup & Restore</a>
            <a href="../institution/" class="btn btn-secondary"><i class="fas fa-building"></i> Institutions</a>
        </div>
    </div>

    <!-- Settings Info -->
    <div class="settings-info no-print">
        <div class="row align-items-center">
            <div class="col-md-8">
                <i class="fas fa-sliders-h"></i> <strong>Quick Status:</strong>
                Database: <?= $dbSize ?> MB | Members: <?= number_format($totalMembers) ?> | Books: <?= number_format($totalBooks) ?> | Transactions: <?= number_format($totalCirculation) ?>
            </div>
            <div class="col-md-4 text-end">
                <span class="badge bg-light text-dark">PHP <?= phpversion() ?></span>
                <span class="badge bg-light text-dark">v3.1</span>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Main Form -->
        <div class="col-md-8">
            <div class="card shadow-sm rounded-4 border-0 card-hover">
                <div class="card-header bg-primary text-white rounded-top-4 py-3">
                    <h5 class="mb-0"><i class="fas fa-sliders-h"></i> System Configuration</h5>
                </div>
                <div class="card-body p-4">
                    <form method="post" enctype="multipart/form-data" id="settingsForm">
                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">

                        <!-- Navigation Tabs -->
                        <ul class="nav nav-tabs mb-3 flex-wrap" role="tablist" id="settingsTabs">
                            <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#general"><i class="fas fa-cog"></i> General</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#opac"><i class="fas fa-globe"></i> OPAC</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#circulation"><i class="fas fa-exchange-alt"></i> Circulation</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#memberPortal"><i class="fas fa-user-lock"></i> Member Portal</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#visitors"><i class="fas fa-user-friends"></i> Visitors</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#hours"><i class="fas fa-clock"></i> Hours</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#whatsapp"><i class="fab fa-whatsapp"></i> WhatsApp</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#backup"><i class="fas fa-database"></i> Backup</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#cloud"><i class="fas fa-cloud-upload-alt"></i> Cloud</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#institution"><i class="fas fa-building"></i> Institution</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#report"><i class="fas fa-file-alt"></i> Report</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#acquisition"><i class="fas fa-shopping-cart"></i> Acquisition</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#multi"><i class="fas fa-sitemap"></i> Multi‑Branch</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#advanced"><i class="fas fa-cogs"></i> Advanced</a></li>
                            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#security"><i class="fas fa-shield-alt"></i> Security</a></li>
                        </ul>

                        <div class="tab-content">
                            <!-- ============================================================ -->
                            <!-- GENERAL TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade show active" id="general">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Software Header <i class="fas fa-info-circle help-tip" title="The main title displayed in the header of the system."></i></label>
                                        <input type="text" name="software_header" class="form-control" value="<?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Library Logo</label>
                                        <input type="file" name="library_logo" class="form-control">
                                        <?php if (!empty($settings['library_logo'])): 
                                            $logoUrl = getWebImageUrlOrBase64($settings['library_logo']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $logoUrl ?>" class="logo-preview" style="height:80px;">
                                                <div class="form-check mt-1">
                                                    <input type="checkbox" name="remove_logo" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Favicon</label>
                                        <input type="file" name="favicon" class="form-control">
                                        <?php if (!empty($settings['favicon_path'])): 
                                            $favUrl = getWebImageUrlOrBase64($settings['favicon_path']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $favUrl ?>" style="height:32px;">
                                                <div class="form-check mt-1">
                                                    <input type="checkbox" name="remove_favicon" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Menu Position</label>
                                        <select name="menu_position" class="form-select">
                                            <option value="top" <?= ($settings['menu_position'] ?? 'top') == 'top' ? 'selected' : '' ?>>Top</option>
                                            <option value="left" <?= ($settings['menu_position'] ?? '') == 'left' ? 'selected' : '' ?>>Left Sidebar</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Auto Logout (minutes)</label>
                                        <input type="number" name="auto_logout_minutes" class="form-control" value="<?= $settings['auto_logout_minutes'] ?? 30 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">New Arrivals Count</label>
                                        <input type="number" name="new_arrivals_count" class="form-control" value="<?= $settings['new_arrivals_count'] ?? 10 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Default Language</label>
                                        <select name="default_language" class="form-select">
                                            <option value="en" <?= ($settings['default_language'] ?? 'en') == 'en' ? 'selected' : '' ?>>English</option>
                                            <option value="ar" <?= ($settings['default_language'] ?? '') == 'ar' ? 'selected' : '' ?>>Arabic</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="staff_display_enabled" class="form-check-input" <?= ($settings['staff_display_enabled'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Staff Gallery on Login</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_audit_log" id="enable_audit_log" class="form-check-input" <?= ($settings['enable_audit_log'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Audit Logging</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6" id="auditRetentionDiv" style="display: <?= ($settings['enable_audit_log'] ?? 1) ? 'block' : 'none' ?>;">
                                        <label class="form-label">Audit Log Retention (days)</label>
                                        <input type="number" name="audit_log_retention_days" class="form-control" value="<?= $settings['audit_log_retention_days'] ?? 90 ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="site_maintenance_mode" id="site_maintenance_mode" class="form-check-input" <?= ($settings['site_maintenance_mode'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Maintenance Mode</label>
                                        </div>
                                    </div>
                                    <div class="col-12" id="maintenanceMessageDiv" style="display: <?= ($settings['site_maintenance_mode'] ?? 0) ? 'block' : 'none' ?>;">
                                        <label class="form-label">Maintenance Message</label>
                                        <textarea name="maintenance_message" rows="2" class="form-control"><?= htmlspecialchars($settings['maintenance_message'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_member_notifications" class="form-check-input" <?= ($settings['enable_member_notifications'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Member Notifications</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- OPAC TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="opac">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">OPAC Header Logo</label>
                                        <input type="file" name="opac_header_logo" class="form-control">
                                        <?php if (!empty($settings['opac_header_logo'])): 
                                            $opacLogo = getWebImageUrlOrBase64($settings['opac_header_logo']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $opacLogo ?>" style="height:60px; object-fit:contain;">
                                                <div class="form-check">
                                                    <input type="checkbox" name="remove_opac_header_logo" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Container Max Width (px)</label>
                                        <input type="number" name="container_max_width" class="form-control" value="<?= $settings['container_max_width'] ?? 1600 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Container Padding (px)</label>
                                        <input type="number" name="container_padding" class="form-control" value="<?= $settings['container_padding'] ?? 10 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Font Family</label>
                                        <select name="opac_font_family" class="form-select">
                                            <option value="Inter" <?= ($settings['opac_font_family'] ?? 'Inter') == 'Inter' ? 'selected' : '' ?>>Inter</option>
                                            <option value="Poppins" <?= ($settings['opac_font_family'] ?? '') == 'Poppins' ? 'selected' : '' ?>>Poppins</option>
                                            <option value="Roboto" <?= ($settings['opac_font_family'] ?? '') == 'Roboto' ? 'selected' : '' ?>>Roboto</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Font Weight</label>
                                        <select name="opac_font_weight" class="form-select">
                                            <option value="400" <?= ($settings['opac_font_weight'] ?? '400') == '400' ? 'selected' : '' ?>>Normal</option>
                                            <option value="600" <?= ($settings['opac_font_weight'] ?? '') == '600' ? 'selected' : '' ?>>Semi-bold</option>
                                            <option value="700" <?= ($settings['opac_font_weight'] ?? '') == '700' ? 'selected' : '' ?>>Bold</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Base Font Size (px)</label>
                                        <input type="number" name="opac_base_font_size" class="form-control" value="<?= $settings['opac_base_font_size'] ?? 16 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Heading Font Size (px)</label>
                                        <input type="number" name="opac_heading_font_size" class="form-control" value="<?= $settings['opac_heading_font_size'] ?? 32 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Primary Color</label>
                                        <input type="color" name="opac_primary_color" class="form-control" value="<?= $settings['opac_primary_color'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Header Background</label>
                                        <input type="color" name="opac_header_bg_color" class="form-control" value="<?= $settings['opac_header_bg_color'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Body Background</label>
                                        <input type="color" name="opac_body_bg" class="form-control" value="<?= $settings['opac_body_bg'] ?? '#f0f2f5' ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Custom CSS</label>
                                        <textarea name="opac_custom_css" rows="3" class="form-control"><?= htmlspecialchars($settings['opac_custom_css'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_enabled" class="form-check-input" <?= ($settings['opac_enabled'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable OPAC</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">OPAC Header Text</label>
                                        <input type="text" name="opac_header_text" class="form-control" value="<?= htmlspecialchars($settings['opac_header_text'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">OPAC Tagline</label>
                                        <input type="text" name="opac_tagline" class="form-control" value="<?= htmlspecialchars($settings['opac_tagline'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Books per page</label>
                                        <input type="number" name="opac_books_per_page" class="form-control" value="<?= $settings['opac_books_per_page'] ?? 12 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">eBooks per page</label>
                                        <input type="number" name="opac_ebooks_per_page" class="form-control" value="<?= $settings['opac_ebooks_per_page'] ?? 8 ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Notice Title</label>
                                        <input type="text" name="opac_notice_title" class="form-control" value="<?= htmlspecialchars($settings['opac_notice_title'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Notice Content</label>
                                        <textarea name="opac_notice_content" rows="2" class="form-control"><?= htmlspecialchars($settings['opac_notice_content'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">OpenAI API Key (semantic search)</label>
                                        <input type="password" name="openai_api_key" class="form-control" value="<?= htmlspecialchars($settings['openai_api_key'] ?? '') ?>">
                                    </div>
                                    <div class="col-12"><hr><h6>Show/Hide Sections</h6></div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_new_arrivals" class="form-check-input" <?= ($settings['opac_show_new_arrivals'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">New Arrivals</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_popular_ebooks" class="form-check-input" <?= ($settings['opac_show_popular_ebooks'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Popular eBooks</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_latest_ebooks" class="form-check-input" <?= ($settings['opac_show_latest_ebooks'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Latest eBooks</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_notices" class="form-check-input" <?= ($settings['opac_show_notices'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Notices</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_trending" class="form-check-input" <?= ($settings['opac_show_trending'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Trending</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_databases" class="form-check-input" <?= ($settings['opac_show_databases'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Research Databases</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_thought_of_the_day" class="form-check-input" <?= ($settings['opac_show_thought_of_the_day'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Thought of the Day</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input type="checkbox" name="opac_show_new_arrivals_in_left" class="form-check-input" <?= ($settings['opac_show_new_arrivals_in_left'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">New Arrivals in Left Column</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Quote Rotation (seconds)</label>
                                        <input type="number" name="opac_quote_rotation_interval" class="form-control" value="<?= $settings['opac_quote_rotation_interval'] ?? 10 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Carousel Style</label>
                                        <select name="opac_carousel_type" class="form-select">
                                            <option value="cover_flow" <?= ($settings['opac_carousel_type'] ?? 'cover_flow') == 'cover_flow' ? 'selected' : '' ?>>Cover Flow (3D)</option>
                                            <option value="default" <?= ($settings['opac_carousel_type'] ?? '') == 'default' ? 'selected' : '' ?>>Default (Bootstrap)</option>
                                            <option value="slide" <?= ($settings['opac_carousel_type'] ?? '') == 'slide' ? 'selected' : '' ?>>Slide</option>
                                            <option value="fade" <?= ($settings['opac_carousel_type'] ?? '') == 'fade' ? 'selected' : '' ?>>Fade</option>
                                            <option value="cube" <?= ($settings['opac_carousel_type'] ?? '') == 'cube' ? 'selected' : '' ?>>Cube</option>
                                            <option value="flip" <?= ($settings['opac_carousel_type'] ?? '') == 'flip' ? 'selected' : '' ?>>Flip</option>
                                            <option value="zoom" <?= ($settings['opac_carousel_type'] ?? '') == 'zoom' ? 'selected' : '' ?>>Zoom</option>
                                            <option value="stack" <?= ($settings['opac_carousel_type'] ?? '') == 'stack' ? 'selected' : '' ?>>Stack</option>
                                            <option value="carousel" <?= ($settings['opac_carousel_type'] ?? '') == 'carousel' ? 'selected' : '' ?>>Classic Carousel</option>
                                            <option value="rotating" <?= ($settings['opac_carousel_type'] ?? '') == 'rotating' ? 'selected' : '' ?>>Rotating 3D Cover Flow</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- CIRCULATION TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="circulation">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="alert alert-info">
                                            <i class="fas fa-info-circle"></i> 
                                            <strong>Academic Library Mode:</strong> Enable this for educational institutions with different member categories. 
                                            Disable for public/community libraries that use global rules.
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="card bg-light border-0 p-3">
                                            <div class="form-check form-switch">
                                                <input type="checkbox" name="enable_category_rules" id="enable_category_rules" class="form-check-input" style="width: 3rem; height: 1.5rem;" <?= ($categoryRulesEnabled) ? 'checked' : '' ?>>
                                                <label class="form-check-label fw-bold ms-2" for="enable_category_rules">
                                                    <i class="fas fa-layer-group"></i> Enable Category-Specific Circulation Rules
                                                    <span class="badge <?= $categoryRulesEnabled ? 'bg-success' : 'bg-secondary' ?> ms-2">
                                                        <?= $categoryRulesEnabled ? 'Academic Mode (ON)' : 'Global Mode (OFF)' ?>
                                                    </span>
                                                </label>
                                            </div>
                                            <small class="text-muted mt-1 ms-4">
                                                <i class="fas fa-<?= $categoryRulesEnabled ? 'check-circle text-success' : 'circle text-secondary' ?>"></i>
                                                <?php if ($categoryRulesEnabled): ?>
                                                    Each member category (Students, Staff) will have individual circulation rules.
                                                <?php else: ?>
                                                    All members will use the global rules set below.
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                    <div class="col-12"><hr></div>
                                    <div class="col-12"><h6><i class="fas fa-globe-americas"></i> Global Circulation Rules</h6></div>
                                    <div class="col-md-4">
                                        <label class="form-label">Global - Max Books</label>
                                        <input type="number" name="max_books" class="form-control" value="<?= $settings['max_books'] ?? 5 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Global - Loan Days</label>
                                        <input type="number" name="loan_days" class="form-control" value="<?= $settings['loan_days'] ?? 7 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Global - Max Renewals</label>
                                        <input type="number" name="max_renewals" class="form-control" value="<?= $settings['max_renewals'] ?? 0 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Global - Fine per Day (<?= getCurrencySymbol($settings['currency_code'] ?? 'INR') ?>)</label>
                                        <input type="number" step="0.5" name="fine_per_day" class="form-control" value="<?= $settings['fine_per_day'] ?? 2 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Global - Max Fine</label>
                                        <input type="number" step="0.5" name="max_fine_amount" class="form-control" value="<?= $settings['max_fine_amount'] ?? 0 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Currency Code</label>
                                        <select name="currency_code" class="form-select">
                                            <?php foreach ($allCurrencies as $code => $label): ?>
                                                <option value="<?= $code ?>" <?= ($settings['currency_code'] ?? 'INR') == $code ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <!-- Category-based Rules -->
                                    <div class="col-12 <?= $categoryRulesEnabled ? '' : 'd-none' ?>" id="categoryRulesContainer">
                                        <hr><h6><i class="fas fa-layer-group"></i> Category-Specific Rules</h6>
                                    </div>
                                    <?php foreach ($memberCategories as $groupKey => $group): ?>
                                        <div class="col-12 <?= $categoryRulesEnabled ? '' : 'd-none' ?>" id="categoryRulesContainer">
                                            <h6 class="mt-3 text-primary"><?= htmlspecialchars($group['label']) ?></h6>
                                        </div>
                                        <?php foreach ($group['sub_categories'] as $catKey => $catLabel): 
                                            $rules = $circulationRules[$catKey] ?? $defaultCirculationRules[$catKey] ?? ['max_books' => 3, 'loan_days' => 7, 'max_renewals' => 1, 'fine_per_day' => 1, 'max_fine_amount' => 10];
                                            $prefix = 'rule_' . $catKey;
                                            $disabled = !$categoryRulesEnabled ? 'disabled' : '';
                                            $opacity = !$categoryRulesEnabled ? 'opacity: 0.6;' : '';
                                        ?>
                                            <div class="col-12 border-bottom pb-2 mb-2 <?= $categoryRulesEnabled ? '' : 'd-none' ?>" id="categoryRulesContainer" style="<?= $opacity ?>">
                                                <div class="row g-2 align-items-center">
                                                    <div class="col-12 col-md-3">
                                                        <strong><?= htmlspecialchars($catLabel) ?></strong>
                                                        <?php if (!$categoryRulesEnabled): ?><i class="fas fa-lock text-muted small"></i><?php endif; ?>
                                                    </div>
                                                    <div class="col-6 col-md-2">
                                                        <label class="form-label small">Max Books</label>
                                                        <input type="number" name="<?= $prefix ?>_max_books" class="form-control form-control-sm" value="<?= $rules['max_books'] ?>" min="0" <?= $disabled ?>>
                                                    </div>
                                                    <div class="col-6 col-md-2">
                                                        <label class="form-label small">Loan Days</label>
                                                        <input type="number" name="<?= $prefix ?>_loan_days" class="form-control form-control-sm" value="<?= $rules['loan_days'] ?>" min="0" <?= $disabled ?>>
                                                    </div>
                                                    <div class="col-6 col-md-1">
                                                        <label class="form-label small">Renewals</label>
                                                        <input type="number" name="<?= $prefix ?>_max_renewals" class="form-control form-control-sm" value="<?= $rules['max_renewals'] ?>" min="0" <?= $disabled ?>>
                                                    </div>
                                                    <div class="col-6 col-md-2">
                                                        <label class="form-label small">Fine/Day</label>
                                                        <input type="number" step="0.5" name="<?= $prefix ?>_fine_per_day" class="form-control form-control-sm" value="<?= $rules['fine_per_day'] ?>" min="0" <?= $disabled ?>>
                                                    </div>
                                                    <div class="col-6 col-md-2">
                                                        <label class="form-label small">Max Fine</label>
                                                        <input type="number" step="0.5" name="<?= $prefix ?>_max_fine_amount" class="form-control form-control-sm" value="<?= $rules['max_fine_amount'] ?>" min="0" <?= $disabled ?>>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                    <div class="col-12 mt-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="allow_holds" class="form-check-input" <?= ($settings['allow_holds'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Allow Holds</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Hold Duration (days)</label>
                                        <input type="number" name="hold_days" class="form-control" value="<?= $settings['hold_days'] ?? 7 ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enforce_library_hours" class="form-check-input" <?= ($settings['enforce_library_hours'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enforce Library Hours</label>
                                        </div>
                                    </div>
                                    <div class="col-12"><hr><h6>Self Registration</h6></div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_self_registration" class="form-check-input" <?= ($settings['enable_self_registration'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Allow Self Registration</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Default Role for Self Registration</label>
                                        <select name="self_registration_role" class="form-select">
                                            <option value="Student" <?= ($settings['self_registration_role'] ?? 'Student') == 'Student' ? 'selected' : '' ?>>Student</option>
                                            <option value="Teacher" <?= ($settings['self_registration_role'] ?? '') == 'Teacher' ? 'selected' : '' ?>>Teacher</option>
                                            <option value="Staff" <?= ($settings['self_registration_role'] ?? '') == 'Staff' ? 'selected' : '' ?>>Staff</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Member Category for Self Registration</label>
                                        <select name="self_registration_category" class="form-select" <?= $categoryRulesEnabled ? '' : 'disabled' ?>>
                                            <option value="">-- Select Category --</option>
                                            <?php foreach ($memberCategories as $groupKey => $group): ?>
                                                <optgroup label="<?= htmlspecialchars($group['label']) ?>">
                                                    <?php foreach ($group['sub_categories'] as $catKey => $catLabel): ?>
                                                        <option value="<?= $catKey ?>" <?= ($settings['self_registration_category'] ?? '') == $catKey ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($catLabel) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </optgroup>
                                            <?php endforeach; ?>
                                        </select>
                                        <?php if (!$categoryRulesEnabled): ?>
                                            <small class="text-muted">Enable Category Rules to use this option.</small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12"><hr><h6>Legacy Fine Rates (per category)</h6>
                                        <table class="table table-sm table-bordered">
                                            <thead><tr><th>Category</th><th>Fine/Day</th><th>Max Fine</th><th>Grace Period</th><th></th></tr></thead>
                                            <tbody id="fineRatesBody"><tr><td colspan="5" class="text-center">Loading...</td></tr></tbody>
                                        </table>
                                        <button type="button" class="btn btn-sm btn-outline-primary" onclick="addFineRateRow()">Add Category</button>
                                        <button type="button" class="btn btn-sm btn-success" onclick="saveFineRates()">Save Fine Rates</button>
                                        <div id="fineRatesMessage" class="small mt-1"></div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- NOTIFICATIONS TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="notifications">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="notify_overdue" class="form-check-input" <?= ($settings['notify_overdue'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Send Overdue Notifications</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_email" class="form-check-input" <?= ($settings['enable_email'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Email Alerts</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_sms" class="form-check-input" <?= ($settings['enable_sms'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable SMS Alerts</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">SMS API Key</label>
                                        <input type="text" name="sms_api_key" class="form-control" value="<?= htmlspecialchars($settings['sms_api_key'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Backup Email</label>
                                        <input type="email" name="backup_email" class="form-control" value="<?= htmlspecialchars($settings['backup_email'] ?? '') ?>">
                                    </div>
                                    <div class="col-12"><hr><h6>SMTP Settings</h6></div>
                                    <div class="col-md-6">
                                        <label class="form-label">SMTP Host</label>
                                        <input type="text" name="smtp_host" class="form-control" value="<?= htmlspecialchars($settings['smtp_host'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">SMTP Port</label>
                                        <input type="number" name="smtp_port" class="form-control" value="<?= $settings['smtp_port'] ?? 587 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Encryption</label>
                                        <select name="smtp_encryption" class="form-select">
                                            <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : '' ?>>TLS</option>
                                            <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') == 'ssl' ? 'selected' : '' ?>>SSL</option>
                                            <option value="none" <?= ($settings['smtp_encryption'] ?? '') == 'none' ? 'selected' : '' ?>>None</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">SMTP Username</label>
                                        <input type="text" name="smtp_username" class="form-control" value="<?= htmlspecialchars($settings['smtp_username'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">SMTP Password</label>
                                        <input type="password" name="smtp_password" class="form-control" value="<?= htmlspecialchars($settings['smtp_password'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">From Email</label>
                                        <input type="email" name="mail_from" class="form-control" value="<?= htmlspecialchars($settings['mail_from'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">From Name</label>
                                        <input type="text" name="mail_from_name" class="form-control" value="<?= htmlspecialchars($settings['mail_from_name'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <button type="button" class="btn btn-outline-info btn-sm" data-bs-toggle="modal" data-bs-target="#testEmailModal">Send Test Email</button>
                                    </div>
                                    <div class="col-12"><hr><h6>Templates</h6></div>
                                    <div class="col-12">
                                        <label class="form-label">Email Overdue Template</label>
                                        <textarea name="email_template_overdue" rows="3" class="form-control"><?= htmlspecialchars($settings['email_template_overdue'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">SMS Overdue Template</label>
                                        <textarea name="sms_template_overdue" rows="2" class="form-control"><?= htmlspecialchars($settings['sms_template_overdue'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- MEMBER PORTAL TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="memberPortal">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_member_portal" class="form-check-input" <?= ($settings['enable_member_portal'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Member Portal</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_member_password_reset" class="form-check-input" <?= ($settings['enable_member_password_reset'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Forgot Password</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Reset Token Expiry (hours)</label>
                                        <input type="number" name="reset_token_expiry_hours" class="form-control" value="<?= $settings['reset_token_expiry_hours'] ?? 24 ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="allow_member_password_change" class="form-check-input" <?= ($settings['allow_member_password_change'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Allow Members to Change Password</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Portal Theme</label>
                                        <select name="member_portal_theme" class="form-select">
                                            <option value="light" <?= ($settings['member_portal_theme'] ?? 'light') == 'light' ? 'selected' : '' ?>>Light</option>
                                            <option value="dark" <?= ($settings['member_portal_theme'] ?? '') == 'dark' ? 'selected' : '' ?>>Dark</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Primary Color</label>
                                        <input type="color" name="member_portal_primary_color" class="form-control" value="<?= $settings['member_portal_primary_color'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Custom CSS</label>
                                        <textarea name="member_portal_custom_css" rows="3" class="form-control"><?= htmlspecialchars($settings['member_portal_custom_css'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="member_portal_show_my_books" class="form-check-input" <?= ($settings['member_portal_show_my_books'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show My Books</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="member_portal_show_fines" class="form-check-input" <?= ($settings['member_portal_show_fines'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show Fines</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="member_portal_show_holds" class="form-check-input" <?= ($settings['member_portal_show_holds'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show Holds</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="member_portal_show_history" class="form-check-input" <?= ($settings['member_portal_show_history'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show History</label>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-check">
                                            <input type="checkbox" name="member_portal_show_profile" class="form-check-input" <?= ($settings['member_portal_show_profile'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show Profile</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- VISITORS TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="visitors">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Header Logo</label>
                                        <input type="file" name="visitor_header_logo" class="form-control">
                                        <?php if (!empty($settings['visitor_header_logo'])): 
                                            $visitorLogo = getWebImageUrlOrBase64($settings['visitor_header_logo']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $visitorLogo ?>" style="height:60px; object-fit:contain;">
                                                <div class="form-check">
                                                    <input type="checkbox" name="remove_visitor_header_logo" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Header Text</label>
                                        <input type="text" name="visitor_header_text" class="form-control" value="<?= htmlspecialchars($settings['visitor_header_text'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Tagline</label>
                                        <input type="text" name="visitor_tagline" class="form-control" value="<?= htmlspecialchars($settings['visitor_tagline'] ?? 'Visitors Log') ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Header BG</label>
                                        <input type="color" name="visitor_header_bg" class="form-control" value="<?= $settings['visitor_header_bg'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Body BG</label>
                                        <input type="color" name="visitor_body_bg" class="form-control" value="<?= $settings['visitor_body_bg'] ?? '#f0f2f5' ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Footer BG</label>
                                        <input type="color" name="visitor_footer_bg" class="form-control" value="<?= $settings['visitor_footer_bg'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Primary Color</label>
                                        <input type="color" name="visitor_primary_color" class="form-control" value="<?= $settings['visitor_primary_color'] ?? '#28a745' ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Font Family</label>
                                        <select name="visitor_font_family" class="form-select">
                                            <option value="Inter" <?= ($settings['visitor_font_family'] ?? 'Inter') == 'Inter' ? 'selected' : '' ?>>Inter</option>
                                            <option value="Poppins" <?= ($settings['visitor_font_family'] ?? '') == 'Poppins' ? 'selected' : '' ?>>Poppins</option>
                                            <option value="Roboto" <?= ($settings['visitor_font_family'] ?? '') == 'Roboto' ? 'selected' : '' ?>>Roboto</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Base Font Size (px)</label>
                                        <input type="number" name="visitor_base_font_size" class="form-control" value="<?= $settings['visitor_base_font_size'] ?? 16 ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="guest_enabled" class="form-check-input" <?= ($settings['guest_enabled'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Guest Entry/Exit</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Guest Prefix</label>
                                        <input type="text" name="guest_prefix" class="form-control" value="<?= htmlspecialchars($settings['guest_prefix'] ?? 'GUEST-') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Number Padding</label>
                                        <input type="number" name="guest_number_padding" class="form-control" value="<?= $settings['guest_number_padding'] ?? 4 ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- LIBRARY HOURS TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="hours">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Timezone</label>
                                        <select name="library_timezone" class="form-select">
                                            <?php foreach ($allTimezones as $tz => $label): ?>
                                                <option value="<?= $tz ?>" <?= ($settings['library_timezone'] ?? 'Asia/Kolkata') == $tz ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Open Days</label>
                                        <div class="row">
                                            <?php
                                            $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                                            $saved = explode(',', $settings['library_open_days'] ?? '1,2,3,4,5');
                                            foreach ($days as $i => $day):
                                                $num = $i + 1;
                                                $checked = in_array($num, $saved) ? 'checked' : '';
                                            ?>
                                                <div class="col-md-3">
                                                    <div class="form-check">
                                                        <input type="checkbox" name="library_open_days[]" value="<?= $num ?>" class="form-check-input" <?= $checked ?>>
                                                        <label class="form-check-label"><?= $day ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Opening Time</label>
                                        <input type="time" name="library_open_time" class="form-control" value="<?= htmlspecialchars($settings['library_open_time'] ?? '09:00') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Closing Time</label>
                                        <input type="time" name="library_close_time" class="form-control" value="<?= htmlspecialchars($settings['library_close_time'] ?? '18:00') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Lunch Start</label>
                                        <input type="time" name="library_lunch_start" class="form-control" value="<?= htmlspecialchars($settings['library_lunch_start'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Lunch End</label>
                                        <input type="time" name="library_lunch_end" class="form-control" value="<?= htmlspecialchars($settings['library_lunch_end'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enforce_library_hours" class="form-check-input" <?= ($settings['enforce_library_hours'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enforce Operating Hours</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- WHATSAPP TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="whatsapp">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">API Type</label>
                                        <select name="whatsapp_api_type" class="form-select">
                                            <option value="whatsapp" <?= ($settings['whatsapp_api_type'] ?? 'whatsapp') == 'whatsapp' ? 'selected' : '' ?>>WhatsApp Business API</option>
                                            <option value="twilio" <?= ($settings['whatsapp_api_type'] ?? '') == 'twilio' ? 'selected' : '' ?>>Twilio</option>
                                            <option value="ultramsg" <?= ($settings['whatsapp_api_type'] ?? '') == 'ultramsg' ? 'selected' : '' ?>>Ultramsg</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">WhatsApp Number</label>
                                        <input type="tel" name="whatsapp_number" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_number'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">API URL</label>
                                        <input type="url" name="whatsapp_api_url" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_api_url'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">API Token</label>
                                        <input type="password" name="whatsapp_api_token" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_api_token'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Phone Number ID</label>
                                        <input type="text" name="whatsapp_phone_number_id" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_phone_number_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Business Account ID</label>
                                        <input type="text" name="whatsapp_business_account_id" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_business_account_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="whatsapp_webhook_verified" class="form-check-input" <?= ($settings['whatsapp_webhook_verified'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Webhook Verified</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="whatsapp_auto_reply_enabled" id="autoReplyEnabled" class="form-check-input" <?= ($settings['whatsapp_auto_reply_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Auto-Reply</label>
                                        </div>
                                    </div>
                                    <div class="col-12" id="autoReplyFields" style="display: <?= ($settings['whatsapp_auto_reply_enabled'] ?? 0) ? 'block' : 'none' ?>;">
                                        <label class="form-label">Auto-Reply Message</label>
                                        <textarea name="whatsapp_auto_reply_message" rows="2" class="form-control"><?= htmlspecialchars($settings['whatsapp_auto_reply_message'] ?? '') ?></textarea>
                                        <label class="form-label mt-2">Out of Hours Reply</label>
                                        <textarea name="whatsapp_out_of_hours_reply" rows="2" class="form-control"><?= htmlspecialchars($settings['whatsapp_out_of_hours_reply'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="whatsapp_notify_overdue_enabled" class="form-check-input" <?= ($settings['whatsapp_notify_overdue_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Send Overdue Notifications</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Overdue Template</label>
                                        <textarea name="whatsapp_template_overdue" rows="3" class="form-control"><?= htmlspecialchars($settings['whatsapp_template_overdue'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="whatsapp_notify_hold_ready_enabled" class="form-check-input" <?= ($settings['whatsapp_notify_hold_ready_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Send Hold Ready Notifications</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Hold Ready Template</label>
                                        <textarea name="whatsapp_template_hold_ready" rows="3" class="form-control"><?= htmlspecialchars($settings['whatsapp_template_hold_ready'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Payment Template</label>
                                        <textarea name="whatsapp_template_payment" rows="3" class="form-control"><?= htmlspecialchars($settings['whatsapp_template_payment'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Event Template</label>
                                        <textarea name="whatsapp_template_event" rows="3" class="form-control"><?= htmlspecialchars($settings['whatsapp_template_event'] ?? '') ?></textarea>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="whatsapp_booking_enabled" class="form-check-input" <?= ($settings['whatsapp_booking_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Booking Requests</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Welcome Message</label>
                                        <textarea name="whatsapp_welcome_message" rows="2" class="form-control"><?= htmlspecialchars($settings['whatsapp_welcome_message'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- BACKUP TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="backup">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Schedule</label>
                                        <select name="backup_schedule" class="form-select">
                                            <option value="manual" <?= ($settings['backup_schedule'] ?? 'manual') == 'manual' ? 'selected' : '' ?>>Manual Only</option>
                                            <option value="daily" <?= ($settings['backup_schedule'] ?? '') == 'daily' ? 'selected' : '' ?>>Daily</option>
                                            <option value="weekly" <?= ($settings['backup_schedule'] ?? '') == 'weekly' ? 'selected' : '' ?>>Weekly</option>
                                            <option value="monthly" <?= ($settings['backup_schedule'] ?? '') == 'monthly' ? 'selected' : '' ?>>Monthly</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Backup Time</label>
                                        <input type="time" name="backup_time" class="form-control" value="<?= htmlspecialchars($settings['backup_time'] ?? '00:00') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Local Retention (days)</label>
                                        <input type="number" name="local_backup_retention" class="form-control" value="<?= $settings['local_backup_retention'] ?? 30 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Notification Email</label>
                                        <input type="email" name="backup_notification_email" class="form-control" value="<?= htmlspecialchars($settings['backup_notification_email'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="backup_include_uploads" class="form-check-input" <?= ($settings['backup_include_uploads'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Include Uploads</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="backup_compress" class="form-check-input" <?= ($settings['backup_compress'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Compress (ZIP)</label>
                                        </div>
                                    </div>
                                    <div class="col-12"><hr><h6>Cloud Destinations</h6></div>
                                    <!-- Google Drive -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="google_drive_enabled" id="googleDriveEnabled" class="form-check-input" <?= ($settings['google_drive_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Google Drive</label>
                                        </div>
                                        <div id="googleDriveFields" style="display: <?= ($settings['google_drive_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="google_drive_client_id" class="form-control" placeholder="Client ID" value="<?= htmlspecialchars($settings['google_drive_client_id'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="google_drive_client_secret" class="form-control" placeholder="Client Secret" value="<?= htmlspecialchars($settings['google_drive_client_secret'] ?? '') ?>"></div>
                                                <div class="col-12"><textarea name="google_drive_refresh_token" rows="2" class="form-control" placeholder="Refresh Token"><?= htmlspecialchars($settings['google_drive_refresh_token'] ?? '') ?></textarea></div>
                                                <div class="col-12"><input type="text" name="google_drive_folder_id" class="form-control" placeholder="Folder ID" value="<?= htmlspecialchars($settings['google_drive_folder_id'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="number" name="google_drive_auto_delete_days" class="form-control" placeholder="Auto delete after days" value="<?= $settings['google_drive_auto_delete_days'] ?? 30 ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Dropbox -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="dropbox_enabled" id="dropboxEnabled" class="form-check-input" <?= ($settings['dropbox_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Dropbox</label>
                                        </div>
                                        <div id="dropboxFields" style="display: <?= ($settings['dropbox_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="dropbox_access_token" class="form-control" placeholder="Access Token" value="<?= htmlspecialchars($settings['dropbox_access_token'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="dropbox_app_key" class="form-control" placeholder="App Key" value="<?= htmlspecialchars($settings['dropbox_app_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="dropbox_app_secret" class="form-control" placeholder="App Secret" value="<?= htmlspecialchars($settings['dropbox_app_secret'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- OneDrive -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="onedrive_enabled" id="onedriveEnabled" class="form-check-input" <?= ($settings['onedrive_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">OneDrive</label>
                                        </div>
                                        <div id="onedriveFields" style="display: <?= ($settings['onedrive_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="onedrive_client_id" class="form-control" placeholder="Client ID" value="<?= htmlspecialchars($settings['onedrive_client_id'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="onedrive_client_secret" class="form-control" placeholder="Client Secret" value="<?= htmlspecialchars($settings['onedrive_client_secret'] ?? '') ?>"></div>
                                                <div class="col-12"><textarea name="onedrive_refresh_token" rows="2" class="form-control" placeholder="Refresh Token"><?= htmlspecialchars($settings['onedrive_refresh_token'] ?? '') ?></textarea></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- pCloud -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="pcloud_enabled" id="pcloudEnabled" class="form-check-input" <?= ($settings['pcloud_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">pCloud</label>
                                        </div>
                                        <div id="pcloudFields" style="display: <?= ($settings['pcloud_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="pcloud_access_token" class="form-control" placeholder="Access Token" value="<?= htmlspecialchars($settings['pcloud_access_token'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="pcloud_username" class="form-control" placeholder="Username" value="<?= htmlspecialchars($settings['pcloud_username'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="password" name="pcloud_password" class="form-control" placeholder="Password (leave blank to keep current)"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Internxt -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="internxt_enabled" id="internxtEnabled" class="form-check-input" <?= ($settings['internxt_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Internxt</label>
                                        </div>
                                        <div id="internxtFields" style="display: <?= ($settings['internxt_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="internxt_api_key" class="form-control" placeholder="API Key" value="<?= htmlspecialchars($settings['internxt_api_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="internxt_api_secret" class="form-control" placeholder="API Secret" value="<?= htmlspecialchars($settings['internxt_api_secret'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="internxt_bucket" class="form-control" placeholder="Bucket" value="<?= htmlspecialchars($settings['internxt_bucket'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="internxt_region" class="form-control" placeholder="Region" value="<?= htmlspecialchars($settings['internxt_region'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- MEGA -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="mega_enabled" id="megaEnabled" class="form-check-input" <?= ($settings['mega_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">MEGA</label>
                                        </div>
                                        <div id="megaFields" style="display: <?= ($settings['mega_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="email" name="mega_email" class="form-control" placeholder="Email" value="<?= htmlspecialchars($settings['mega_email'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="password" name="mega_password" class="form-control" placeholder="Password (leave blank to keep current)"></div>
                                                <div class="col-12"><input type="text" name="mega_folder_id" class="form-control" placeholder="Folder ID" value="<?= htmlspecialchars($settings['mega_folder_id'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Sync.com -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="sync_enabled" id="syncEnabled" class="form-check-input" <?= ($settings['sync_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Sync.com</label>
                                        </div>
                                        <div id="syncFields" style="display: <?= ($settings['sync_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="sync_api_key" class="form-control" placeholder="API Key" value="<?= htmlspecialchars($settings['sync_api_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="sync_api_secret" class="form-control" placeholder="API Secret" value="<?= htmlspecialchars($settings['sync_api_secret'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="sync_folder_id" class="form-control" placeholder="Folder ID" value="<?= htmlspecialchars($settings['sync_folder_id'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Terabox -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="terabox_enabled" id="teraboxEnabled" class="form-check-input" <?= ($settings['terabox_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Terabox</label>
                                        </div>
                                        <div id="teraboxFields" style="display: <?= ($settings['terabox_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="terabox_api_key" class="form-control" placeholder="API Key" value="<?= htmlspecialchars($settings['terabox_api_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="terabox_api_secret" class="form-control" placeholder="API Secret" value="<?= htmlspecialchars($settings['terabox_api_secret'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="terabox_folder_id" class="form-control" placeholder="Folder ID" value="<?= htmlspecialchars($settings['terabox_folder_id'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Backblaze -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="backblaze_enabled" id="backblazeEnabled" class="form-check-input" <?= ($settings['backblaze_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Backblaze B2</label>
                                        </div>
                                        <div id="backblazeFields" style="display: <?= ($settings['backblaze_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="backblaze_key_id" class="form-control" placeholder="Key ID" value="<?= htmlspecialchars($settings['backblaze_key_id'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="password" name="backblaze_application_key" class="form-control" placeholder="Application Key" value="<?= htmlspecialchars($settings['backblaze_application_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="backblaze_bucket_name" class="form-control" placeholder="Bucket Name" value="<?= htmlspecialchars($settings['backblaze_bucket_name'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Wasabi -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="wasabi_enabled" id="wasabiEnabled" class="form-check-input" <?= ($settings['wasabi_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Wasabi</label>
                                        </div>
                                        <div id="wasabiFields" style="display: <?= ($settings['wasabi_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="wasabi_access_key" class="form-control" placeholder="Access Key" value="<?= htmlspecialchars($settings['wasabi_access_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="password" name="wasabi_secret_key" class="form-control" placeholder="Secret Key" value="<?= htmlspecialchars($settings['wasabi_secret_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="wasabi_bucket" class="form-control" placeholder="Bucket" value="<?= htmlspecialchars($settings['wasabi_bucket'] ?? '') ?>"></div>
                                                <div class="col-12">
                                                    <select name="wasabi_region" class="form-control">
                                                        <option value="us-east-1" <?= ($settings['wasabi_region'] ?? 'us-east-1') == 'us-east-1' ? 'selected' : '' ?>>US East</option>
                                                        <option value="us-west-1" <?= ($settings['wasabi_region'] ?? '') == 'us-west-1' ? 'selected' : '' ?>>US West</option>
                                                        <option value="eu-central-1" <?= ($settings['wasabi_region'] ?? '') == 'eu-central-1' ? 'selected' : '' ?>>EU Central</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Amazon S3 -->
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="s3_enabled" id="s3Enabled" class="form-check-input" <?= ($settings['s3_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Amazon S3</label>
                                        </div>
                                        <div id="s3Fields" style="display: <?= ($settings['s3_enabled'] ?? 0) ? 'block' : 'none' ?>; margin-left:20px;">
                                            <div class="row g-2 mt-2">
                                                <div class="col-12"><input type="text" name="s3_access_key" class="form-control" placeholder="Access Key ID" value="<?= htmlspecialchars($settings['s3_access_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="password" name="s3_secret_key" class="form-control" placeholder="Secret Key" value="<?= htmlspecialchars($settings['s3_secret_key'] ?? '') ?>"></div>
                                                <div class="col-12"><input type="text" name="s3_bucket" class="form-control" placeholder="Bucket" value="<?= htmlspecialchars($settings['s3_bucket'] ?? '') ?>"></div>
                                                <div class="col-12">
                                                    <select name="s3_region" class="form-control">
                                                        <option value="us-east-1" <?= ($settings['s3_region'] ?? 'us-east-1') == 'us-east-1' ? 'selected' : '' ?>>US East (N. Virginia)</option>
                                                        <option value="eu-west-1" <?= ($settings['s3_region'] ?? '') == 'eu-west-1' ? 'selected' : '' ?>>EU (Ireland)</option>
                                                        <option value="ap-southeast-1" <?= ($settings['s3_region'] ?? '') == 'ap-southeast-1' ? 'selected' : '' ?>>Singapore</option>
                                                    </select>
                                                </div>
                                                <div class="col-12"><input type="text" name="s3_endpoint" class="form-control" placeholder="Custom Endpoint" value="<?= htmlspecialchars($settings['s3_endpoint'] ?? '') ?>"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 mt-3">
                                        <button type="submit" name="manual_backup" class="btn btn-primary">Create Backup Now</button>
                                        <?php if ($settings['last_backup_time']): ?>
                                            <small class="text-muted ms-2">Last backup: <?= date('d-m-Y H:i:s', strtotime($settings['last_backup_time'])) ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- CLOUD STORAGE TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="cloud">
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Provider for eBooks</label>
                                        <select name="cloud_storage_provider" class="form-select" id="cloudProviderSelect">
                                            <option value="local" <?= ($settings['cloud_storage_provider'] ?? 'local') == 'local' ? 'selected' : '' ?>>Local</option>
                                            <option value="google_drive" <?= ($settings['cloud_storage_provider'] ?? '') == 'google_drive' ? 'selected' : '' ?>>Google Drive</option>
                                            <option value="dropbox" <?= ($settings['cloud_storage_provider'] ?? '') == 'dropbox' ? 'selected' : '' ?>>Dropbox</option>
                                            <option value="onedrive" <?= ($settings['cloud_storage_provider'] ?? '') == 'onedrive' ? 'selected' : '' ?>>OneDrive</option>
                                            <option value="pcloud" <?= ($settings['cloud_storage_provider'] ?? '') == 'pcloud' ? 'selected' : '' ?>>pCloud</option>
                                            <option value="internxt" <?= ($settings['cloud_storage_provider'] ?? '') == 'internxt' ? 'selected' : '' ?>>Internxt</option>
                                            <option value="mega" <?= ($settings['cloud_storage_provider'] ?? '') == 'mega' ? 'selected' : '' ?>>MEGA</option>
                                            <option value="backblaze" <?= ($settings['cloud_storage_provider'] ?? '') == 'backblaze' ? 'selected' : '' ?>>Backblaze</option>
                                            <option value="wasabi" <?= ($settings['cloud_storage_provider'] ?? '') == 'wasabi' ? 'selected' : '' ?>>Wasabi</option>
                                            <option value="s3" <?= ($settings['cloud_storage_provider'] ?? '') == 's3' ? 'selected' : '' ?>>Amazon S3</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Folder/Container ID</label>
                                        <input type="text" name="cloud_folder_id" class="form-control" value="<?= htmlspecialchars($settings['cloud_folder_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="alert alert-info">Use the same credentials from the Backup tab for each provider. Files will be stored in the selected cloud.</div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- INSTITUTION TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="institution">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Active Institution</label>
                                        <select name="current_institution_id" class="form-select">
                                            <?php foreach ($institutions as $inst): ?>
                                                <option value="<?= $inst['id'] ?>" <?= ($settings['current_institution_id'] ?? 1) == $inst['id'] ? 'selected' : '' ?>><?= htmlspecialchars($inst['name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- REPORT SETTINGS TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="report">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label">Font Size (px)</label>
                                        <input type="number" name="report_font_size" class="form-control" value="<?= $settings['report_font_size'] ?? 10 ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Primary Color</label>
                                        <input type="color" name="report_primary_color" class="form-control" value="<?= $settings['report_primary_color'] ?? '#1e3c72' ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Logo Position</label>
                                        <select name="report_logo_position" class="form-select">
                                            <option value="left" <?= ($settings['report_logo_position'] ?? 'left') == 'left' ? 'selected' : '' ?>>Left</option>
                                            <option value="center" <?= ($settings['report_logo_position'] ?? '') == 'center' ? 'selected' : '' ?>>Center</option>
                                            <option value="right" <?= ($settings['report_logo_position'] ?? '') == 'right' ? 'selected' : '' ?>>Right</option>
                                            <option value="both" <?= ($settings['report_logo_position'] ?? '') == 'both' ? 'selected' : '' ?>>Both</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Report Logo (Main)</label>
                                        <input type="file" name="report_logo" class="form-control">
                                        <?php if (!empty($settings['report_logo'])): 
                                            $reportLogo = getWebImageUrlOrBase64($settings['report_logo']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $reportLogo ?>" style="height:60px;">
                                                <div class="form-check">
                                                    <input type="checkbox" name="remove_report_logo" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Right Logo</label>
                                        <input type="file" name="report_logo_right" class="form-control">
                                        <?php if (!empty($settings['report_logo_right'])): 
                                            $rightLogo = getWebImageUrlOrBase64($settings['report_logo_right']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $rightLogo ?>" style="height:40px;">
                                                <div class="form-check">
                                                    <input type="checkbox" name="remove_report_logo_right" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="report_watermark_enabled" class="form-check-input" <?= ($settings['report_watermark_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Watermark</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Watermark Text</label>
                                        <input type="text" name="report_watermark_text" class="form-control" value="<?= htmlspecialchars($settings['report_watermark_text'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Opacity (%)</label>
                                        <input type="number" name="report_watermark_opacity" class="form-control" value="<?= $settings['report_watermark_opacity'] ?? 10 ?>" min="5" max="50">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="report_signature_enabled" class="form-check-input" <?= ($settings['report_signature_enabled'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Signature</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Signature Name</label>
                                        <input type="text" name="report_signature_name" class="form-control" value="<?= htmlspecialchars($settings['report_signature_name'] ?? 'Librarian') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Signature Title</label>
                                        <input type="text" name="report_signature_title" class="form-control" value="<?= htmlspecialchars($settings['report_signature_title'] ?? 'Chief Librarian') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Signature Image</label>
                                        <input type="file" name="report_signature_image" class="form-control">
                                        <?php if (!empty($settings['report_signature_image'])): 
                                            $sigImage = getWebImageUrlOrBase64($settings['report_signature_image']);
                                        ?>
                                            <div class="mt-2">
                                                <img src="<?= $sigImage ?>" style="height:50px;">
                                                <div class="form-check">
                                                    <input type="checkbox" name="remove_report_signature_image" value="1" class="form-check-input">
                                                    <label class="form-check-label">Remove</label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Footer Text</label>
                                        <input type="text" name="report_footer_text" class="form-control" value="<?= htmlspecialchars($settings['report_footer_text'] ?? '') ?>">
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- ACQUISITION TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="acquisition">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Source Options (comma separated)</label>
                                        <input type="text" name="source_options" class="form-control" value="<?= htmlspecialchars($settings['source_options'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Default Source</label>
                                        <input type="text" name="default_source" class="form-control" value="<?= htmlspecialchars($settings['default_source'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_auto_supply_date" class="form-check-input" <?= ($settings['enable_auto_supply_date'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Auto-fill Supply Date</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- MULTI-BRANCH TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="multi">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_multi_branch" class="form-check-input" <?= ($settings['enable_multi_branch'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Multi‑Branch</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_budgeting" class="form-check-input" <?= ($settings['enable_budgeting'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Budgeting</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_interlibrary" class="form-check-input" <?= ($settings['enable_interlibrary'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Interlibrary Loans</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_course_reserves" class="form-check-input" <?= ($settings['enable_course_reserves'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Course Reserves</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="digital_asset_tracking" class="form-check-input" <?= ($settings['digital_asset_tracking'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Digital Asset Tracking</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="detailed_audit_log" class="form-check-input" <?= ($settings['detailed_audit_log'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Detailed Audit Logging</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="auto_scheduled_jobs" class="form-check-input" <?= ($settings['auto_scheduled_jobs'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Auto Scheduled Jobs</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- ADVANCED TAB -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="advanced">
                                <div class="row g-3">
                                    <h6>GDPR & Compliance</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_gdpr_compliance" class="form-check-input" <?= ($settings['enable_gdpr_compliance'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable GDPR Compliance</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Data Retention Days</label>
                                        <input type="number" name="gdpr_data_retention_days" class="form-control" value="<?= $settings['gdpr_data_retention_days'] ?? 365 ?>">
                                    </div>
                                    <hr>
                                    <h6>API & Webhooks</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_api_rate_limiting" class="form-check-input" <?= ($settings['enable_api_rate_limiting'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable API Rate Limiting</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Rate Limit (per minute)</label>
                                        <input type="number" name="api_rate_limit_per_minute" class="form-control" value="<?= $settings['api_rate_limit_per_minute'] ?? 60 ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_webhooks" class="form-check-input" <?= ($settings['enable_webhooks'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Webhooks</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Webhook URL</label>
                                        <input type="url" name="webhook_url" class="form-control" value="<?= htmlspecialchars($settings['webhook_url'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Webhook Secret</label>
                                        <input type="password" name="webhook_secret" class="form-control" value="<?= htmlspecialchars($settings['webhook_secret'] ?? '') ?>">
                                    </div>
                                    <hr>
                                    <h6>SSO / OAuth / SAML</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_sso" class="form-check-input" <?= ($settings['enable_sso'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable SSO</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Provider</label>
                                        <input type="text" name="sso_provider" class="form-control" value="<?= htmlspecialchars($settings['sso_provider'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Client ID</label>
                                        <input type="text" name="sso_client_id" class="form-control" value="<?= htmlspecialchars($settings['sso_client_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Client Secret</label>
                                        <input type="password" name="sso_client_secret" class="form-control" value="<?= htmlspecialchars($settings['sso_client_secret'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Redirect URI</label>
                                        <input type="url" name="sso_redirect_uri" class="form-control" value="<?= htmlspecialchars($settings['sso_redirect_uri'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_oauth" class="form-check-input" <?= ($settings['enable_oauth'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable OAuth</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Provider</label>
                                        <input type="text" name="oauth_provider" class="form-control" value="<?= htmlspecialchars($settings['oauth_provider'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Client ID</label>
                                        <input type="text" name="oauth_client_id" class="form-control" value="<?= htmlspecialchars($settings['oauth_client_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Client Secret</label>
                                        <input type="password" name="oauth_client_secret" class="form-control" value="<?= htmlspecialchars($settings['oauth_client_secret'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Redirect URI</label>
                                        <input type="url" name="oauth_redirect_uri" class="form-control" value="<?= htmlspecialchars($settings['oauth_redirect_uri'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_saml" class="form-check-input" <?= ($settings['enable_saml'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable SAML</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">IdP Metadata URL</label>
                                        <input type="url" name="saml_idp_metadata_url" class="form-control" value="<?= htmlspecialchars($settings['saml_idp_metadata_url'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">SP Entity ID</label>
                                        <input type="text" name="saml_sp_entity_id" class="form-control" value="<?= htmlspecialchars($settings['saml_sp_entity_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">SP ACS URL</label>
                                        <input type="url" name="saml_sp_acs_url" class="form-control" value="<?= htmlspecialchars($settings['saml_sp_acs_url'] ?? '') ?>">
                                    </div>
                                    <hr>
                                    <h6>LDAP</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_ldap" class="form-check-input" <?= ($settings['enable_ldap'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable LDAP</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Host</label>
                                        <input type="text" name="ldap_host" class="form-control" value="<?= htmlspecialchars($settings['ldap_host'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Port</label>
                                        <input type="number" name="ldap_port" class="form-control" value="<?= $settings['ldap_port'] ?? 389 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Encryption</label>
                                        <select name="ldap_encryption" class="form-select">
                                            <option value="none" <?= ($settings['ldap_encryption'] ?? 'none') == 'none' ? 'selected' : '' ?>>None</option>
                                            <option value="ssl" <?= ($settings['ldap_encryption'] ?? '') == 'ssl' ? 'selected' : '' ?>>SSL</option>
                                            <option value="tls" <?= ($settings['ldap_encryption'] ?? '') == 'tls' ? 'selected' : '' ?>>TLS</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Base DN</label>
                                        <input type="text" name="ldap_base_dn" class="form-control" value="<?= htmlspecialchars($settings['ldap_base_dn'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Bind DN</label>
                                        <input type="text" name="ldap_bind_dn" class="form-control" value="<?= htmlspecialchars($settings['ldap_bind_dn'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Bind Password</label>
                                        <input type="password" name="ldap_bind_password" class="form-control" value="<?= htmlspecialchars($settings['ldap_bind_password'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">User Filter</label>
                                        <input type="text" name="ldap_user_filter" class="form-control" value="<?= htmlspecialchars($settings['ldap_user_filter'] ?? '') ?>">
                                    </div>
                                    <hr>
                                    <h6>reCAPTCHA</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_recaptcha" class="form-check-input" <?= ($settings['enable_recaptcha'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable reCAPTCHA</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Site Key</label>
                                        <input type="text" name="recaptcha_site_key" class="form-control" value="<?= htmlspecialchars($settings['recaptcha_site_key'] ?? '') ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Secret Key</label>
                                        <input type="password" name="recaptcha_secret_key" class="form-control" value="<?= htmlspecialchars($settings['recaptcha_secret_key'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_captcha_on_login" class="form-check-input" <?= ($settings['enable_captcha_on_login'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show on Login</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_captcha_on_registration" class="form-check-input" <?= ($settings['enable_captcha_on_registration'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Show on Registration</label>
                                        </div>
                                    </div>
                                    <hr>
                                    <h6>AI Recommendations</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_ai_recommendations" class="form-check-input" <?= ($settings['enable_ai_recommendations'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable AI Recommendations</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Model</label>
                                        <select name="ai_recommendation_model" class="form-select">
                                            <option value="collaborative" <?= ($settings['ai_recommendation_model'] ?? 'collaborative') == 'collaborative' ? 'selected' : '' ?>>Collaborative Filtering</option>
                                            <option value="content" <?= ($settings['ai_recommendation_model'] ?? '') == 'content' ? 'selected' : '' ?>>Content-Based</option>
                                            <option value="hybrid" <?= ($settings['ai_recommendation_model'] ?? '') == 'hybrid' ? 'selected' : '' ?>>Hybrid</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Max Recommendations</label>
                                        <input type="number" name="ai_max_recommendations" class="form-control" value="<?= $settings['ai_max_recommendations'] ?? 10 ?>">
                                    </div>
                                    <hr>
                                    <h6>Search & Analytics</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_advanced_search" class="form-check-input" <?= ($settings['enable_advanced_search'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Advanced Search</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Highlight Color</label>
                                        <input type="color" name="search_highlight_color" class="form-control" value="<?= $settings['search_highlight_color'] ?? '#ffeb3b' ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_auto_suggest" class="form-check-input" <?= ($settings['enable_auto_suggest'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Auto-Suggest</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Suggest Limit</label>
                                        <input type="number" name="auto_suggest_limit" class="form-control" value="<?= $settings['auto_suggest_limit'] ?? 10 ?>">
                                    </div>
                                    <hr>
                                    <h6>Analytics</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_analytics" class="form-check-input" <?= ($settings['enable_analytics'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Analytics</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Tracking ID</label>
                                        <input type="text" name="analytics_tracking_id" class="form-control" value="<?= htmlspecialchars($settings['analytics_tracking_id'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_heatmaps" class="form-check-input" <?= ($settings['enable_heatmaps'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Heatmaps</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_session_recording" class="form-check-input" <?= ($settings['enable_session_recording'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Session Recording</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_ab_testing" class="form-check-input" <?= ($settings['enable_ab_testing'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable A/B Testing</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_feature_flags" class="form-check-input" <?= ($settings['enable_feature_flags'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable Feature Flags</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Feature Flags Config (JSON)</label>
                                        <textarea name="feature_flags_config" rows="4" class="form-control"><?= htmlspecialchars($settings['feature_flags_config'] ?? '{}') ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- ============================================================ -->
                            <!-- SECURITY TAB (NEW) -->
                            <!-- ============================================================ -->
                            <div class="tab-pane fade" id="security">
                                <div class="row g-3">
                                    <h6>Two-Factor Authentication</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_2fa" class="form-check-input" <?= ($settings['enable_2fa'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable 2FA for Admin Login</label>
                                        </div>
                                    </div>
                                    <hr>
                                    <h6>Session Management</h6>
                                    <div class="col-md-6">
                                        <label class="form-label">Session Lifetime (seconds)</label>
                                        <input type="number" name="session_lifetime" class="form-control" value="<?= $settings['session_lifetime'] ?? 7200 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Max Failed Login Attempts</label>
                                        <input type="number" name="failed_login_attempts" class="form-control" value="<?= $settings['failed_login_attempts'] ?? 5 ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Lockout Time (minutes)</label>
                                        <input type="number" name="lockout_time" class="form-control" value="<?= $settings['lockout_time'] ?? 15 ?>">
                                    </div>
                                    <hr>
                                    <h6>Cookie Settings</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="cookie_secure" class="form-check-input" <?= ($settings['cookie_secure'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Secure Cookies (HTTPS only)</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="cookie_httponly" class="form-check-input" <?= ($settings['cookie_httponly'] ?? 1) ? 'checked' : '' ?>>
                                            <label class="form-check-label">HttpOnly Cookies</label>
                                        </div>
                                    </div>
                                    <hr>
                                    <h6>GDPR Consent</h6>
                                    <div class="col-12">
                                        <div class="form-check">
                                            <input type="checkbox" name="enable_gdpr" class="form-check-input" <?= ($settings['enable_gdpr'] ?? 0) ? 'checked' : '' ?>>
                                            <label class="form-check-label">Enable GDPR Consent</label>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Consent Text</label>
                                        <textarea name="gdpr_consent_text" rows="3" class="form-control"><?= htmlspecialchars($settings['gdpr_consent_text'] ?? '') ?></textarea>
                                    </div>
                                </div>
                            </div>

                        </div> <!-- end tab-content -->

                        <div class="mt-4 d-flex flex-wrap gap-2">
                            <button type="submit" name="update_settings" class="btn btn-primary px-5 py-2">
                                <i class="fas fa-save"></i> Save All Settings
                            </button>
                            <button type="button" class="btn btn-danger px-4 py-2" onclick="confirmReset()">
                                <i class="fas fa-undo-alt"></i> Reset to Defaults
                            </button>
                            <a href="settings.php" class="btn btn-secondary ms-2">Reset (Discard changes)</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Sidebar -->
        <div class="col-md-4">
            <!-- Change Password -->
            <div class="card mb-4 shadow-sm rounded-4 card-hover">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="fas fa-key"></i> Change Admin Password</h5>
                </div>
                <div class="card-body">
                    <form method="post" action="../index.php">
                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                        <div class="mb-3">
                            <input type="password" name="current_password" class="form-control" placeholder="Current Password" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="new_password" class="form-control" placeholder="New Password" required>
                        </div>
                        <div class="mb-3">
                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required>
                        </div>
                        <button type="submit" name="change_password" class="btn btn-warning w-100">Change Password</button>
                    </form>
                </div>
            </div>

            <!-- System Info -->
            <div class="card mb-4 shadow-sm rounded-4 card-hover">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> System Info</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr><th>PHP Version:</th><td><?= phpversion() ?></td></tr>
                        <tr><th>Database Size:</th><td><?= $dbSize ?> MB</td></tr>
                        <tr><th>Total Members:</th><td><?= number_format($totalMembers) ?></td></tr>
                        <tr><th>Total Books:</th><td><?= number_format($totalBooks) ?></td></tr>
                        <tr><th>Total Transactions:</th><td><?= number_format($totalCirculation) ?></td></tr>
                    </table>
                </div>
            </div>

            <!-- Maintenance -->
            <div class="card mb-4 shadow-sm rounded-4 card-hover">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><i class="fas fa-tools"></i> Maintenance</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                        <button type="submit" name="clear_cache" class="btn btn-outline-secondary w-100 mb-2">
                            <i class="fas fa-broom"></i> Clear Cache
                        </button>
                        <button type="submit" name="optimize_db" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-database"></i> Optimize Database
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================ -->
<!-- TEST EMAIL MODAL -->
<!-- ============================================================ -->
<div class="modal fade" id="testEmailModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">Send Test Email</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Recipient Email</label>
                        <input type="email" name="test_recipient" class="form-control" required>
                    </div>
                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="test_email" class="btn btn-info">Send Test</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================================ -->
<!-- JAVASCRIPT -->
<!-- ============================================================ -->
<script>
// =====================================================================
// TOGGLE VISIBILITY FUNCTIONS
// =====================================================================

function toggleVisibility(checkboxId, targetId) {
    const checkbox = document.getElementById(checkboxId);
    const target = document.getElementById(targetId);
    if (checkbox && target) {
        checkbox.addEventListener('change', function() {
            target.style.display = this.checked ? 'block' : 'none';
        });
    }
}

// Cloud storage providers
toggleVisibility('googleDriveEnabled', 'googleDriveFields');
toggleVisibility('dropboxEnabled', 'dropboxFields');
toggleVisibility('onedriveEnabled', 'onedriveFields');
toggleVisibility('pcloudEnabled', 'pcloudFields');
toggleVisibility('internxtEnabled', 'internxtFields');
toggleVisibility('megaEnabled', 'megaFields');
toggleVisibility('syncEnabled', 'syncFields');
toggleVisibility('teraboxEnabled', 'teraboxFields');
toggleVisibility('backblazeEnabled', 'backblazeFields');
toggleVisibility('wasabiEnabled', 'wasabiFields');
toggleVisibility('s3Enabled', 's3Fields');

// Other toggles
toggleVisibility('enable_audit_log', 'auditRetentionDiv');
toggleVisibility('site_maintenance_mode', 'maintenanceMessageDiv');
toggleVisibility('autoReplyEnabled', 'autoReplyFields');

// =====================================================================
// CATEGORY RULES TOGGLE
// =====================================================================

document.getElementById('enable_category_rules')?.addEventListener('change', function() {
    const isEnabled = this.checked;
    const containers = document.querySelectorAll('#categoryRulesContainer');
    const badge = this.closest('.form-check').querySelector('.badge');
    const infoMsg = document.querySelector('.alert-info small');

    containers.forEach(el => {
        el.style.display = isEnabled ? '' : 'none';
        const inputs = el.querySelectorAll('input, select');
        inputs.forEach(inp => {
            inp.disabled = !isEnabled;
            inp.closest('.col-12').style.opacity = isEnabled ? '1' : '0.6';
        });
    });
    if (badge) {
        badge.className = 'badge ms-2 ' + (isEnabled ? 'bg-success' : 'bg-secondary');
        badge.textContent = isEnabled ? 'Academic Mode (ON)' : 'Global Mode (OFF)';
    }
    if (infoMsg) {
        infoMsg.innerHTML = isEnabled 
            ? '<i class="fas fa-check-circle text-success"></i> Each member category will have individual rules.'
            : '<i class="fas fa-circle text-secondary"></i> All members will use global rules.';
    }
});

// Cloud provider selection
document.getElementById('cloudProviderSelect')?.addEventListener('change', function() {
    const providers = ['internxtFields', 'megaFields', 'syncFields', 'teraboxFields', 'backblazeFields', 'wasabiFields', 's3Fields'];
    providers.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
    const val = this.value;
    if (val === 'internxt') document.getElementById('internxtFields').style.display = 'block';
    if (val === 'mega') document.getElementById('megaFields').style.display = 'block';
    if (val === 'sync') document.getElementById('syncFields').style.display = 'block';
    if (val === 'terabox') document.getElementById('teraboxFields').style.display = 'block';
    if (val === 'backblaze') document.getElementById('backblazeFields').style.display = 'block';
    if (val === 'wasabi') document.getElementById('wasabiFields').style.display = 'block';
    if (val === 's3') document.getElementById('s3Fields').style.display = 'block';
});

// =====================================================================
// FINE RATES FUNCTIONS
// =====================================================================

function escapeHtml(s) {
    if (!s) return '';
    return s.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

function loadFineRates() {
    fetch('settings.php?ajax=get_fine_rates')
        .then(r => r.json())
        .then(data => {
            const tbody = document.getElementById('fineRatesBody');
            tbody.innerHTML = '';
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" class="text-center">No rates. Add below.</td></tr>';
                return;
            }
            data.forEach(rate => {
                const row = tbody.insertRow();
                row.insertCell(0).innerHTML = '<input type="text" class="form-control form-control-sm" value="' + escapeHtml(rate.member_category) + '" data-field="category">';
                row.insertCell(1).innerHTML = '<input type="number" step="0.5" class="form-control form-control-sm" value="' + rate.fine_per_day + '" data-field="fine">';
                row.insertCell(2).innerHTML = '<input type="number" step="0.5" class="form-control form-control-sm" value="' + (rate.max_fine || 0) + '" data-field="max_fine">';
                row.insertCell(3).innerHTML = '<input type="number" class="form-control form-control-sm" value="' + (rate.grace_period_days || 0) + '" data-field="grace_period">';
                row.insertCell(4).innerHTML = '<button class="btn btn-sm btn-danger" onclick="this.closest(\'tr\').remove()"><i class="fas fa-trash"></i></button>';
            });
        })
        .catch(err => console.error('Error loading fine rates:', err));
}

function addFineRateRow() {
    const tbody = document.getElementById('fineRatesBody');
    if (tbody.children.length === 1 && tbody.children[0].innerText.includes('No rates')) {
        tbody.innerHTML = '';
    }
    const row = tbody.insertRow();
    row.insertCell(0).innerHTML = '<input type="text" class="form-control form-control-sm" placeholder="New Category" data-field="category">';
    row.insertCell(1).innerHTML = '<input type="number" step="0.5" class="form-control form-control-sm" value="2" data-field="fine">';
    row.insertCell(2).innerHTML = '<input type="number" step="0.5" class="form-control form-control-sm" value="0" data-field="max_fine">';
    row.insertCell(3).innerHTML = '<input type="number" class="form-control form-control-sm" value="0" data-field="grace_period">';
    row.insertCell(4).innerHTML = '<button class="btn btn-sm btn-danger" onclick="this.closest(\'tr\').remove()"><i class="fas fa-trash"></i></button>';
}

function saveFineRates() {
    const rates = [];
    document.querySelectorAll('#fineRatesBody tr').forEach(row => {
        const cat = row.querySelector('input[data-field="category"]')?.value.trim();
        if (cat) {
            rates.push({
                category: cat,
                fine: parseFloat(row.querySelector('[data-field="fine"]').value),
                max_fine: parseFloat(row.querySelector('[data-field="max_fine"]').value),
                grace_period: parseInt(row.querySelector('[data-field="grace_period"]').value)
            });
        }
    });

    const formData = new FormData();
    formData.append('save_fine_rates', '1');
    formData.append('rates', JSON.stringify(rates));
    formData.append('csrf_token', '<?= $csrf_token ?>');

    fetch(window.location.href, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            const msg = document.getElementById('fineRatesMessage');
            if (data.success) {
                msg.innerHTML = '<span class="text-success">Saved successfully.</span>';
                setTimeout(() => msg.innerHTML = '', 3000);
                loadFineRates();
            } else {
                msg.innerHTML = '<span class="text-danger">Error: ' + (data.error || 'Unknown error') + '</span>';
            }
        })
        .catch(err => {
            document.getElementById('fineRatesMessage').innerHTML = '<span class="text-danger">Error: ' + err.message + '</span>';
        });
}

// Load fine rates when circulation tab is shown
document.querySelector('a[data-bs-target="#circulation"]')?.addEventListener('shown.bs.tab', function() {
    loadFineRates();
});

// Initial load if circulation tab is active
if (document.querySelector('#circulation.active')) {
    loadFineRates();
}

// =====================================================================
// RESET CONFIRMATION
// =====================================================================
function confirmReset() {
    if (confirm('⚠️ Are you sure you want to reset ALL settings to default values? This action cannot be undone.')) {
        const form = document.createElement('form');
        form.method = 'post';
        form.innerHTML = `
            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
            <input type="hidden" name="reset_defaults" value="1">
            <input type="hidden" name="confirm_reset" value="yes">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<?php renderFooter(); ?>