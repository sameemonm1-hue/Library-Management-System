<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['member_logged_in'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();
$memberId = $_SESSION['member_admno'];

// Get member's borrowed book categories
$stmt = $db->prepare("
    SELECT DISTINCT b.category 
    FROM circulation c 
    JOIN books b ON c.barcode = b.barcode 
    WHERE c.admno = ? AND b.category IS NOT NULL AND b.category != ''
");
$stmt->execute([$memberId]);
$categories = $stmt->fetchAll(PDO::FETCH_COLUMN);

$recommendations = [];

if (count($categories) > 0) {
    // Collaborative filtering: find members who borrowed same categories, then suggest their other books
    $placeholders = implode(',', array_fill(0, count($categories), '?'));
    $sql = "
        SELECT DISTINCT b.*, COUNT(DISTINCT c2.admno) as common_members
        FROM books b
        JOIN circulation c1 ON b.barcode = c1.barcode
        WHERE b.category IN ($placeholders)
        AND b.barcode NOT IN (SELECT barcode FROM circulation WHERE admno = ?)
        GROUP BY b.barcode
        ORDER BY common_members DESC, b.title
        LIMIT 10
    ";
    $params = array_merge($categories, [$memberId]);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $recommendations = $stmt->fetchAll();
}

// Fallback: if no recommendations, show most popular books overall
if (empty($recommendations)) {
    $recommendations = $db->query("
        SELECT b.*, COUNT(c.id) as borrow_count
        FROM books b
        JOIN circulation c ON b.barcode = c.barcode
        WHERE b.barcode NOT IN (SELECT barcode FROM circulation WHERE admno = '$memberId')
        GROUP BY b.barcode
        ORDER BY borrow_count DESC
        LIMIT 10
    ")->fetchAll();
}

renderHeader('Book Recommendations');
?>
<div class="container mt-4">
    <h2><i class="fas fa-robot"></i> AI-Powered Book Recommendations</h2>
    <p class="text-muted">Based on your borrowing history and what similar members liked.</p>

    <?php if (empty($recommendations)): ?>
        <div class="alert alert-info">No recommendations available yet. Borrow some books to get personalized suggestions!</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($recommendations as $book): ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100 shadow-sm">
                        <?php if (!empty($book['cover_path']) && file_exists($book['cover_path'])): ?>
                            <img src="<?= getWebImageUrl($book['cover_path']) ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
                        <?php else: ?>
                            <div class="card-img-top bg-light text-center py-5">
                                <i class="fas fa-book fa-4x text-secondary"></i>
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($book['title']) ?></h5>
                            <p class="card-text text-muted">by <?= htmlspecialchars($book['author'] ?? 'Unknown') ?></p>
                            <p class="small"><?= htmlspecialchars($book['category'] ?? 'General') ?></p>
                            <a href="book_details.php?barcode=<?= urlencode($book['barcode']) ?>" class="btn btn-sm btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php renderFooter(); ?>