-- =====================================================
-- Library ERP - New Tables & Schema Updates
-- Execute this script on your MySQL database.
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ========== 1. LOAN RULES (Advanced Circulation Policies) ==========
CREATE TABLE IF NOT EXISTS loan_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patron_category VARCHAR(50) NOT NULL,
    item_category VARCHAR(50) NOT NULL,
    max_loans INT NOT NULL DEFAULT 5,
    loan_days INT NOT NULL DEFAULT 7,
    renewals_allowed INT NOT NULL DEFAULT 0,
    fine_per_day DECIMAL(10,2) NOT NULL DEFAULT 2.00,
    grace_period INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_patron_item (patron_category, item_category),
    INDEX idx_patron (patron_category),
    INDEX idx_item (item_category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 2. EMAIL QUEUE (Notifications) ==========
CREATE TABLE IF NOT EXISTS email_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    alt_body TEXT,
    priority INT NOT NULL DEFAULT 0,
    attempts INT NOT NULL DEFAULT 0,
    last_attempt DATETIME,
    status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
    error TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status_priority (status, priority, created_at),
    INDEX idx_to_email (to_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 3. FINE CHARGES (Daily fine accrual log) ==========
CREATE TABLE IF NOT EXISTS fine_charges (
    id INT AUTO_INCREMENT PRIMARY KEY,
    circulation_id INT NOT NULL,
    admno VARCHAR(50) NOT NULL,
    charge_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_circulation (circulation_id),
    INDEX idx_admno (admno),
    INDEX idx_charge_date (charge_date),
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 4. BOOK RECOMMENDATIONS (Collaborative filtering) ==========
CREATE TABLE IF NOT EXISTS book_recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    recommended_book_id INT NOT NULL,
    score DECIMAL(5,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_book_rec (book_id, recommended_book_id),
    INDEX idx_book (book_id),
    INDEX idx_rec_book (recommended_book_id),
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (recommended_book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 5. FAQ (Chatbot knowledge base) ==========
CREATE TABLE IF NOT EXISTS faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FULLTEXT INDEX ft_question (question)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 6. API KEYS (REST API authentication) ==========
CREATE TABLE IF NOT EXISTS api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    permissions TEXT NOT NULL COMMENT 'Comma-separated: read,write,admin',
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_used DATETIME,
    INDEX idx_active_key (active, api_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 7. ADD MISSING COLUMNS TO EXISTING TABLES ==========
-- We use a stored procedure to add columns safely (IF NOT EXISTS)
DROP PROCEDURE IF EXISTS AddColumnIfNotExists;
DELIMITER $$
CREATE PROCEDURE AddColumnIfNotExists(
    IN tableName VARCHAR(64),
    IN columnName VARCHAR(64),
    IN columnDefinition VARCHAR(255)
)
BEGIN
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = tableName
        AND COLUMN_NAME = columnName
    ) THEN
        SET @sql = CONCAT('ALTER TABLE ', tableName, ' ADD COLUMN ', columnName, ' ', columnDefinition);
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

-- Add columns to `members` table
CALL AddColumnIfNotExists('members', 'email_verified', 'TINYINT(1) DEFAULT 0');
CALL AddColumnIfNotExists('members', 'registration_token', 'VARCHAR(64) DEFAULT NULL');
CALL AddColumnIfNotExists('members', 'approved', 'TINYINT(1) DEFAULT 0');
CALL AddColumnIfNotExists('members', 'reset_token', 'VARCHAR(64) DEFAULT NULL');
CALL AddColumnIfNotExists('members', 'reset_expiry', 'DATETIME DEFAULT NULL');

-- Add columns to `books` table
CALL AddColumnIfNotExists('books', 'embedding', 'JSON DEFAULT NULL');

-- Add columns to `reservations_queue` table (for hold shelf management)
CALL AddColumnIfNotExists('reservations_queue', 'hold_shelf_date', 'DATE DEFAULT NULL');
CALL AddColumnIfNotExists('reservations_queue', 'notification_sent', 'TINYINT(1) DEFAULT 0');

-- Add column to `circulation` for renew count if missing
CALL AddColumnIfNotExists('circulation', 'renew_count', 'INT DEFAULT 0');

-- Drop the stored procedure after use
DROP PROCEDURE IF EXISTS AddColumnIfNotExists;

-- ========== 8. INSERT SAMPLE DATA ==========
-- Default loan rules (only if table is empty)
INSERT IGNORE INTO loan_rules (patron_category, item_category, max_loans, loan_days, renewals_allowed, fine_per_day, grace_period) VALUES
('Student', 'General', 5, 7, 2, 2.00, 0),
('Student', 'Reference', 0, 0, 0, 0.00, 0),
('Student', 'Textbook', 2, 14, 1, 5.00, 2),
('Teacher', 'General', 10, 30, 3, 1.00, 5),
('Teacher', 'Reference', 2, 7, 0, 5.00, 0),
('Staff', 'General', 8, 21, 2, 2.00, 2);

-- Sample FAQ entries
INSERT IGNORE INTO faq (question, answer) VALUES
('What are library hours?', 'Library is open Monday–Friday 9:00 AM – 8:00 PM, Saturday 9:00 AM – 5:00 PM, Sunday closed.'),
('How do I renew a book?', 'You can renew online by logging into your account and clicking "Renew" next to the loan, or visit the library circulation desk.'),
('What is the overdue fine rate?', 'Fine rates depend on your member category and book type. Standard student fine is ₹2 per day for general books.'),
('How can I place a hold?', 'Log into your account, search for the book, and click "Place Hold". You will be notified when it becomes available.'),
('I lost a book. What should I do?', 'Report the loss immediately at the library counter. You may need to pay a replacement cost.');

-- Sample API key (replace 'your-secret-key-here' with a strong random string)
INSERT IGNORE INTO api_keys (api_key, name, permissions) VALUES
('test-api-key-12345678', 'Development Test Key', 'read,write');

-- ========== 9. INDEXES FOR PERFORMANCE (if missing) ==========
CREATE INDEX IF NOT EXISTS idx_circulation_admno_due ON circulation(admno, due_date);
CREATE INDEX IF NOT EXISTS idx_circulation_return_date ON circulation(return_date);
CREATE INDEX IF NOT EXISTS idx_books_category ON books(category);
CREATE INDEX IF NOT EXISTS idx_books_author ON books(author);
CREATE INDEX IF NOT EXISTS idx_members_category_status ON members(member_category, status);
CREATE INDEX IF NOT EXISTS idx_reservations_queue_status ON reservations_queue(status, requested_date);

SET FOREIGN_KEY_CHECKS = 1;