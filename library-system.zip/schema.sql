-- =====================================================
-- Library ERP System - Complete SQLite Schema
-- Version: 1.0 (Based on full codebase analysis)
-- =====================================================

PRAGMA foreign_keys = ON;

-- ==================== CORE TABLES ====================

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    fullname TEXT NOT NULL,
    email TEXT,
    role TEXT DEFAULT 'staff',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME,
    login_attempts INTEGER DEFAULT 0,
    locked_until DATETIME,
    token_version INTEGER DEFAULT 1,
    export_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admno TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    general_id TEXT,
    member_category TEXT DEFAULT 'Student',
    class TEXT,
    division TEXT,
    roll_no TEXT,
    email TEXT,
    phone TEXT,
    parent_phone TEXT,
    address TEXT,
    dob DATE,
    gender TEXT,
    blood_group TEXT,
    photo_path TEXT,
    admission_date DATE DEFAULT CURRENT_DATE,
    active_books INTEGER DEFAULT 0,
    total_issued INTEGER DEFAULT 0,
    total_fines REAL DEFAULT 0,
    total_paid_fines REAL DEFAULT 0,
    security_deposit REAL DEFAULT 0,
    membership_expiry DATE,
    emergency_contact TEXT,
    notes TEXT,
    status TEXT DEFAULT 'active',
    password TEXT,
    reset_token TEXT,
    token_expiry DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_reminder_sent DATE,
    expiry_notified INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    barcode TEXT UNIQUE NOT NULL,
    call_number TEXT,
    isbn TEXT,
    title TEXT NOT NULL,
    sub_title TEXT,
    author TEXT,
    author2 TEXT,
    collaborator TEXT,
    subject TEXT,
    keyword TEXT,
    category TEXT,
    sub_category TEXT,
    publisher TEXT,
    publisher_place TEXT,
    edition TEXT,
    year TEXT,
    pages INTEGER,
    language TEXT DEFAULT 'English',
    location TEXT,
    summary TEXT,
    description TEXT,
    cover_path TEXT,
    quantity INTEGER DEFAULT 1,
    available INTEGER DEFAULT 1,
    price REAL DEFAULT 0,
    price_currency TEXT DEFAULT 'INR',
    replacement_cost REAL DEFAULT 0,
    accession_number TEXT,
    total_lost INTEGER DEFAULT 0,
    item_category TEXT,
    remarks TEXT,
    status TEXT DEFAULT 'Available',
    book_status TEXT DEFAULT 'Available',
    binding TEXT,
    holding TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS circulation (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    class TEXT,
    division TEXT,
    barcode TEXT,
    isbn TEXT,
    title TEXT,
    author TEXT,
    category TEXT,
    publisher TEXT,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    fine REAL DEFAULT 0,
    renew_count INTEGER DEFAULT 0,
    notes TEXT,
    is_manual INTEGER DEFAULT 0,
    last_whatsapp_sent DATETIME,
    FOREIGN KEY (admno) REFERENCES members(admno),
    FOREIGN KEY (barcode) REFERENCES books(barcode)
);

CREATE TABLE IF NOT EXISTS loans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status TEXT DEFAULT 'issued' CHECK(status IN ('issued','returned','overdue')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

-- ==================== ACQUISITIONS & VENDORS ====================

CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_person TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    gst_no TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_no TEXT UNIQUE NOT NULL,
    vendor_id INTEGER,
    order_date DATE NOT NULL,
    expected_delivery DATE,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','shipped','received','cancelled')),
    total_amount REAL,
    notes TEXT,
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    po_id INTEGER NOT NULL,
    book_title TEXT NOT NULL,
    isbn TEXT,
    author TEXT,
    quantity INTEGER DEFAULT 1,
    unit_price REAL,
    received_quantity INTEGER DEFAULT 0,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
);

-- ==================== DIGITAL RESOURCES ====================

CREATE TABLE IF NOT EXISTS ebooks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT,
    subject TEXT,
    isbn TEXT,
    publisher TEXT,
    year TEXT,
    description TEXT,
    cover_path TEXT,
    file_path TEXT NOT NULL,
    file_size INTEGER,
    downloads INTEGER DEFAULT 0,
    full_text TEXT,
    cloud_file_id TEXT,
    storage_type TEXT DEFAULT 'local',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS research_databases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    url TEXT NOT NULL,
    category TEXT,
    type TEXT DEFAULT 'academic' CHECK(type IN ('academic','open_access','subscription')),
    icon TEXT DEFAULT 'database',
    is_featured INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS research_database_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    database_id INTEGER NOT NULL,
    user_id INTEGER,
    user_type TEXT CHECK(user_type IN ('member','admin','guest')),
    action TEXT CHECK(action IN ('access','search','download')),
    search_query TEXT,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (database_id) REFERENCES research_databases(id) ON DELETE CASCADE
);

-- ==================== FINES & PAYMENTS ====================

CREATE TABLE IF NOT EXISTS fine_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_category TEXT UNIQUE NOT NULL,
    fine_per_day REAL NOT NULL DEFAULT 2,
    max_fine REAL DEFAULT 0,
    grace_period_days INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS fine_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    circulation_id INTEGER,
    admno TEXT NOT NULL,
    amount REAL NOT NULL,
    payment_date DATE NOT NULL,
    payment_method TEXT DEFAULT 'cash' CHECK(payment_method IN ('cash','card','online','cheque')),
    receipt_no TEXT UNIQUE,
    status TEXT DEFAULT 'paid' CHECK(status IN ('paid','refunded','pending')),
    notes TEXT,
    collected_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS payment_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_admno TEXT NOT NULL,
    amount REAL NOT NULL,
    payment_type TEXT CHECK(payment_type IN ('fine','deposit','lost_fee','donation','membership_fee')) NOT NULL,
    reference_id TEXT,
    related_circulation_id INTEGER,
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    payment_method TEXT DEFAULT 'cash',
    receipt_no TEXT UNIQUE,
    notes TEXT,
    created_by TEXT,
    currency TEXT DEFAULT 'INR',
    FOREIGN KEY (related_circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS fine_settlements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admno TEXT NOT NULL,
    total_fine REAL NOT NULL,
    amount_paid REAL DEFAULT 0,
    amount_waived REAL DEFAULT 0,
    settlement_date DATE,
    settled_by TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS lost_books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    admno TEXT NOT NULL,
    circulation_id INTEGER,
    loss_date DATE NOT NULL,
    declared_lost_by TEXT,
    replacement_cost REAL,
    amount_paid REAL DEFAULT 0,
    replacement_book_barcode TEXT,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','paid','waived')),
    notes TEXT,
    currency TEXT DEFAULT 'INR',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
);

-- ==================== NOTIFICATIONS & COMMUNICATION ====================

CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER DEFAULT 1,
    member_admno TEXT NOT NULL,
    member_name TEXT,
    title TEXT NOT NULL,
    author TEXT,
    isbn TEXT,
    reason TEXT,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
    admin_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS overdue_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    circulation_id INTEGER NOT NULL,
    admno TEXT NOT NULL,
    notification_type TEXT CHECK(notification_type IN ('email','sms','whatsapp')),
    days_overdue INTEGER,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'sent',
    response TEXT,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipient_type TEXT CHECK(recipient_type IN ('member','admin','staff')),
    recipient TEXT NOT NULL,
    notification_type TEXT NOT NULL,
    subject TEXT,
    message TEXT,
    channel TEXT CHECK(channel IN ('email','sms','whatsapp','push')),
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')),
    sent_at DATETIME,
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS email_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    to_email TEXT NOT NULL,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    alt_body TEXT,
    priority INTEGER DEFAULT 0,
    attempts INTEGER DEFAULT 0,
    last_attempt DATETIME,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')),
    error TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS whatsapp_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone_number TEXT NOT NULL,
    message TEXT NOT NULL,
    priority INTEGER DEFAULT 0,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')),
    attempts INTEGER DEFAULT 0,
    last_attempt DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== ENTRY/EXIT & VISITOR MANAGEMENT ====================

CREATE TABLE IF NOT EXISTS entry_exit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    member_category TEXT,
    entry_date DATE NOT NULL,
    entry_time TIME NOT NULL,
    exit_time TIME,
    purpose TEXT,
    status TEXT DEFAULT 'inside' CHECK(status IN ('inside','exited')),
    notes TEXT DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== EVENTS ====================

CREATE TABLE IF NOT EXISTS library_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    venue TEXT,
    max_attendees INTEGER,
    registration_required BOOLEAN DEFAULT 1,
    status TEXT DEFAULT 'upcoming' CHECK(status IN ('upcoming','ongoing','completed','cancelled')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS event_attendees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    member_admno TEXT NOT NULL,
    check_in_time DATETIME,
    attended BOOLEAN DEFAULT 0,
    feedback TEXT,
    FOREIGN KEY (event_id) REFERENCES library_events(id) ON DELETE CASCADE
);

-- ==================== HOLDS & RESERVATIONS ====================

CREATE TABLE IF NOT EXISTS book_holds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    hold_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','notified','cancelled','expired')),
    notified INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reservations_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    priority INTEGER DEFAULT 1,
    requested_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status TEXT DEFAULT 'waiting' CHECK(status IN ('waiting','notified','borrowed','expired','cancelled')),
    notified_at DATETIME,
    processed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== SERIAL CONTROL ====================

CREATE TABLE IF NOT EXISTS serial_vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact_person TEXT,
    email TEXT,
    phone TEXT,
    address TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS serial_subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    issn TEXT,
    frequency TEXT NOT NULL CHECK(frequency IN ('daily','weekly','biweekly','monthly','bimonthly','quarterly','halfyearly','yearly')),
    vendor_id INTEGER,
    start_date DATE NOT NULL,
    end_date DATE,
    cost REAL,
    location TEXT,
    routing_list TEXT,
    notes TEXT,
    status TEXT DEFAULT 'active' CHECK(status IN ('active','expired','cancelled')),
    subscription_type TEXT DEFAULT 'print',
    access_url TEXT,
    access_credentials TEXT,
    digital_format TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES serial_vendors(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS serial_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subscription_id INTEGER NOT NULL,
    volume TEXT,
    issue_number TEXT NOT NULL,
    date_published DATE,
    date_received DATE,
    status TEXT DEFAULT 'expected' CHECK(status IN ('expected','received','claimed','missing','late')),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subscription_id) REFERENCES serial_subscriptions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS serial_reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subscription_id INTEGER NOT NULL,
    issue_id INTEGER,
    reminder_type TEXT DEFAULT 'missing_issue',
    sent_to TEXT NOT NULL,
    subject TEXT,
    message TEXT,
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subscription_id) REFERENCES serial_subscriptions(id),
    FOREIGN KEY (issue_id) REFERENCES serial_issues(id)
);

-- ==================== COMPUTER ACCESS MANAGEMENT ====================

CREATE TABLE IF NOT EXISTS computers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    computer_name TEXT NOT NULL,
    ip_address TEXT,
    location TEXT,
    status TEXT DEFAULT 'active' CHECK(status IN ('active','maintenance','offline')),
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS computer_policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_role TEXT UNIQUE NOT NULL,
    max_minutes_per_day INTEGER DEFAULT 60,
    max_minutes_per_week INTEGER DEFAULT 240,
    max_sessions_per_week INTEGER DEFAULT 3,
    require_attendance BOOLEAN DEFAULT 1,
    weekly_attendance_required INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS computer_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    computer_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    login_time DATETIME NOT NULL,
    logout_time DATETIME,
    duration_minutes INTEGER DEFAULT 0,
    FOREIGN KEY (computer_id) REFERENCES computers(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

CREATE TABLE IF NOT EXISTS computer_attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER NOT NULL,
    week_start_date DATE NOT NULL,
    sessions_count INTEGER DEFAULT 0,
    total_minutes INTEGER DEFAULT 0,
    compliant BOOLEAN DEFAULT 0,
    UNIQUE(member_id, week_start_date),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- ==================== SYSTEM & CONFIGURATION ====================

CREATE TABLE IF NOT EXISTS institutions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT,
    contact TEXT,
    email TEXT,
    logo_path TEXT,
    status TEXT DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    loan_days INTEGER DEFAULT 7,
    fine_per_day REAL DEFAULT 2,
    max_books INTEGER DEFAULT 5,
    menu_position TEXT DEFAULT 'top',
    software_header TEXT DEFAULT 'Library ERP System',
    library_logo TEXT,
    favicon_path TEXT,
    backup_email TEXT,
    notify_overdue BOOLEAN DEFAULT 1,
    auto_logout_minutes INTEGER DEFAULT 30,
    new_arrivals_count INTEGER DEFAULT 10,
    enable_sms BOOLEAN DEFAULT 0,
    sms_api_key TEXT,
    enable_email BOOLEAN DEFAULT 1,
    backup_password TEXT,
    opac_enabled BOOLEAN DEFAULT 1,
    allow_holds BOOLEAN DEFAULT 1,
    hold_days INTEGER DEFAULT 7,
    google_drive_enabled BOOLEAN DEFAULT 0,
    google_drive_folder_id TEXT,
    google_drive_client_id TEXT,
    google_drive_client_secret TEXT,
    google_drive_refresh_token TEXT,
    smtp_host TEXT,
    smtp_port INTEGER DEFAULT 587,
    smtp_encryption TEXT DEFAULT 'tls',
    smtp_username TEXT,
    smtp_password TEXT,
    mail_from TEXT,
    mail_from_name TEXT,
    backup_schedule TEXT DEFAULT 'daily',
    backup_time TEXT DEFAULT '00:00',
    current_institution_id INTEGER DEFAULT 1,
    opac_show_new_arrivals INTEGER DEFAULT 1,
    opac_show_popular_ebooks INTEGER DEFAULT 1,
    opac_show_latest_ebooks INTEGER DEFAULT 1,
    opac_show_notices INTEGER DEFAULT 1,
    opac_show_trending INTEGER DEFAULT 1,
    opac_show_databases INTEGER DEFAULT 1,
    opac_header_text TEXT,
    opac_tagline TEXT,
    opac_books_per_page INTEGER DEFAULT 12,
    opac_ebooks_per_page INTEGER DEFAULT 8,
    image_base_path TEXT DEFAULT 'uploads/',
    enable_whatsapp BOOLEAN DEFAULT 0,
    whatsapp_api_key TEXT,
    whatsapp_phone_number TEXT,
    whatsapp_api_url TEXT,
    right_logo_path TEXT,
    opac_notice_title TEXT,
    opac_notice_content TEXT,
    max_fine_amount REAL DEFAULT 0,
    enable_self_registration BOOLEAN DEFAULT 0,
    self_registration_role TEXT DEFAULT 'Student',
    email_template_overdue TEXT,
    sms_template_overdue TEXT,
    whatsapp_template_overdue TEXT,
    enable_member_password_reset INTEGER DEFAULT 1,
    reset_token_expiry_hours INTEGER DEFAULT 24,
    allow_member_password_change INTEGER DEFAULT 1,
    cloud_storage_provider TEXT DEFAULT 'local',
    cloud_api_key TEXT,
    cloud_api_secret TEXT,
    cloud_refresh_token TEXT,
    cloud_folder_id TEXT,
    google_drive_service_account_json TEXT,
    last_export DATETIME,
    currency_code TEXT DEFAULT 'USD',
    currency_symbol TEXT DEFAULT '$',
    currency_position TEXT DEFAULT 'left',
    opac_header_logo TEXT,
    login_bg_color TEXT DEFAULT '#667eea',
    login_text_color TEXT DEFAULT '#ffffff',
    login_header_logo TEXT,
    login_font_family TEXT DEFAULT 'Inter',
    login_base_font_size INTEGER DEFAULT 16,
    staff_display_enabled INTEGER DEFAULT 1,
    staff_card_bg_color TEXT DEFAULT '#ffffff',
    currency_decimal_places INTEGER DEFAULT 2,
    guest_enabled INTEGER DEFAULT 1,
    guest_prefix VARCHAR(20) DEFAULT 'GUEST-',
    guest_number_padding INTEGER DEFAULT 4,
    guest_daily_counter INTEGER DEFAULT 1,
    guest_last_reset DATE,
    whatsapp_number VARCHAR(20),
    whatsapp_message TEXT,
    fine_grace_period INTEGER DEFAULT 0,
    fine_calculation_method TEXT DEFAULT 'daily',
    auto_waive_fine_after_return BOOLEAN DEFAULT 0,
    fine_reminder_days INTEGER DEFAULT 3,
    enable_overdue_notifications BOOLEAN DEFAULT 1,
    library_open_days TEXT DEFAULT '1,2,3,4,5',
    library_open_time TEXT DEFAULT '09:00',
    library_close_time TEXT DEFAULT '18:00',
    library_lunch_start TEXT,
    library_lunch_end TEXT,
    library_timezone TEXT DEFAULT 'Asia/Kolkata',
    container_max_width INTEGER DEFAULT 1600,
    container_padding INTEGER DEFAULT 10,
    opac_font_family TEXT DEFAULT 'Inter',
    opac_base_font_size INTEGER DEFAULT 16,
    opac_heading_font_size INTEGER DEFAULT 32,
    opac_primary_color TEXT DEFAULT '#1e3c72',
    opac_header_bg_color TEXT DEFAULT '#1e3c72',
    opac_body_bg TEXT DEFAULT '#f0f2f5',
    opac_custom_css TEXT,
    max_renewals INTEGER DEFAULT 0,
    enable_audit_log INTEGER DEFAULT 1,
    audit_log_retention_days INTEGER DEFAULT 90,
    enable_member_notifications INTEGER DEFAULT 1,
    default_language TEXT DEFAULT 'en',
    site_maintenance_mode INTEGER DEFAULT 0,
    maintenance_message TEXT,
    razorpay_key_id TEXT,
    razorpay_key_secret TEXT,
    session_check_ip INTEGER DEFAULT 0,
    max_concurrent_sessions INTEGER DEFAULT 5,
    visitor_header_logo TEXT,
    visitor_header_text TEXT,
    visitor_tagline TEXT,
    visitor_header_bg TEXT DEFAULT '#1e3c72',
    visitor_body_bg TEXT DEFAULT '#f0f2f5',
    visitor_footer_bg TEXT DEFAULT '#1e3c72',
    visitor_font_family TEXT DEFAULT 'Inter',
    visitor_base_font_size INTEGER DEFAULT 16,
    visitor_primary_color TEXT DEFAULT '#28a745',
    report_font_size INTEGER DEFAULT 10,
    report_primary_color TEXT DEFAULT '#1e3c72',
    report_logo_position TEXT DEFAULT 'left',
    report_logo_right TEXT,
    report_watermark_text TEXT,
    report_watermark_enabled INTEGER DEFAULT 1,
    report_watermark_opacity INTEGER DEFAULT 10,
    report_signature_name TEXT DEFAULT 'Librarian',
    report_signature_title TEXT DEFAULT 'Chief Librarian',
    report_signature_image TEXT,
    report_signature_enabled INTEGER DEFAULT 0,
    report_footer_text TEXT DEFAULT 'This is a system generated report'
);

CREATE TABLE IF NOT EXISTS staff_profiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    designation TEXT NOT NULL,
    photo_path TEXT,
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS quick_actions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    icon_class TEXT NOT NULL,
    link_url TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS login_cards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    icon_class TEXT NOT NULL DEFAULT 'fas fa-info-circle',
    link_url TEXT NOT NULL DEFAULT '#',
    sort_order INTEGER DEFAULT 0,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS module_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    module_key TEXT NOT NULL,
    can_access INTEGER DEFAULT 1,
    UNIQUE(role, module_key)
);

-- ==================== ACTIVITY & LOGGING ====================

CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS session_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_type TEXT CHECK(user_type IN ('admin','member')),
    username TEXT NOT NULL,
    session_id TEXT,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    logout_time DATETIME,
    ip_address TEXT,
    user_agent TEXT
);

CREATE TABLE IF NOT EXISTS user_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    user_id INTEGER NOT NULL,
    fingerprint TEXT NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    expires_at DATETIME,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS remember_tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    token TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS session_audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    session_id TEXT,
    action TEXT,
    reason TEXT,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS rate_limits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key TEXT,
    endpoint TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS export_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    export_type TEXT NOT NULL CHECK(export_type IN ('pdf','excel','csv')),
    report_name TEXT NOT NULL,
    filters TEXT,
    file_size INTEGER,
    status TEXT DEFAULT 'success',
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS search_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    book_barcode TEXT,
    book_title TEXT,
    search_type TEXT DEFAULT 'books',
    user_ip TEXT,
    user_agent TEXT,
    session_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS opac_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    reviewer_name TEXT NOT NULL,
    rating INTEGER DEFAULT 5,
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== STATISTICS & REPORTS ====================

CREATE TABLE IF NOT EXISTS daily_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stat_date DATE UNIQUE NOT NULL,
    books_issued INTEGER DEFAULT 0,
    books_returned INTEGER DEFAULT 0,
    members_registered INTEGER DEFAULT 0,
    fines_collected REAL DEFAULT 0,
    entries_count INTEGER DEFAULT 0,
    exits_count INTEGER DEFAULT 0,
    ebook_downloads INTEGER DEFAULT 0,
    new_books_added INTEGER DEFAULT 0,
    active_loans INTEGER DEFAULT 0,
    overdue_count INTEGER DEFAULT 0,
    total_outstanding_fines REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS weekly_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_date DATE NOT NULL,
    week_start DATE NOT NULL,
    week_end DATE NOT NULL,
    report_data TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS monthly_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_month DATE NOT NULL,
    report_data TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS generated_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_type TEXT NOT NULL,
    report_date DATE NOT NULL,
    report_data TEXT NOT NULL,
    file_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== API & SECURITY ====================

CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    expires_at DATETIME,
    last_used DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== FTS (FULL-TEXT SEARCH) VIRTUAL TABLES ====================

CREATE VIRTUAL TABLE IF NOT EXISTS books_fts USING fts5(
    title, author, subject, isbn, publisher, description, keyword,
    content=books,
    content_rowid=id,
    tokenize='porter unicode61'
);

CREATE VIRTUAL TABLE IF NOT EXISTS members_fts USING fts5(
    name, admno, email, phone, address,
    content=members,
    content_rowid=id,
    tokenize='porter unicode61'
);

CREATE VIRTUAL TABLE IF NOT EXISTS circulation_fts USING fts5(
    title, author, member_name, admno,
    content=circulation,
    content_rowid=id,
    tokenize='porter unicode61'
);

-- ==================== TRIGGERS FOR FTS SYNC ====================

CREATE TRIGGER IF NOT EXISTS books_ai AFTER INSERT ON books BEGIN
    INSERT INTO books_fts(rowid, title, author, subject, isbn, publisher, description, keyword)
    VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keyword);
END;

CREATE TRIGGER IF NOT EXISTS books_ad AFTER DELETE ON books BEGIN
    DELETE FROM books_fts WHERE rowid = old.id;
END;

CREATE TRIGGER IF NOT EXISTS books_au AFTER UPDATE ON books BEGIN
    DELETE FROM books_fts WHERE rowid = old.id;
    INSERT INTO books_fts(rowid, title, author, subject, isbn, publisher, description, keyword)
    VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keyword);
END;

CREATE TRIGGER IF NOT EXISTS members_ai AFTER INSERT ON members BEGIN
    INSERT INTO members_fts(rowid, name, admno, email, phone, address)
    VALUES (new.id, new.name, new.admno, new.email, new.phone, new.address);
END;

CREATE TRIGGER IF NOT EXISTS members_ad AFTER DELETE ON members BEGIN
    DELETE FROM members_fts WHERE rowid = old.id;
END;

CREATE TRIGGER IF NOT EXISTS members_au AFTER UPDATE ON members BEGIN
    DELETE FROM members_fts WHERE rowid = old.id;
    INSERT INTO members_fts(rowid, name, admno, email, phone, address)
    VALUES (new.id, new.name, new.admno, new.email, new.phone, new.address);
END;

CREATE TRIGGER IF NOT EXISTS circulation_ai AFTER INSERT ON circulation BEGIN
    INSERT INTO circulation_fts(rowid, title, author, member_name, admno)
    VALUES (new.id, new.title, new.author, new.member_name, new.admno);
END;

CREATE TRIGGER IF NOT EXISTS circulation_ad AFTER DELETE ON circulation BEGIN
    DELETE FROM circulation_fts WHERE rowid = old.id;
END;

CREATE TRIGGER IF NOT EXISTS circulation_au AFTER UPDATE ON circulation BEGIN
    DELETE FROM circulation_fts WHERE rowid = old.id;
    INSERT INTO circulation_fts(rowid, title, author, member_name, admno)
    VALUES (new.id, new.title, new.author, new.member_name, new.admno);
END;

-- ==================== USER PREFERENCES ====================

CREATE TABLE IF NOT EXISTS user_preferences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    preference_key TEXT NOT NULL,
    preference_value TEXT,
    UNIQUE(user_id, preference_key),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==================== MEMBER DOCUMENTS ====================

CREATE TABLE IF NOT EXISTS member_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_admno TEXT NOT NULL,
    document_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    expiry_date DATE,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified BOOLEAN DEFAULT 0,
    verified_by TEXT,
    notes TEXT
);

-- ==================== STOCK VERIFICATION ====================

CREATE TABLE IF NOT EXISTS stock_verification (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    expected_status TEXT,
    actual_status TEXT,
    verified_date DATE,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== REPORT GENERATION ====================

CREATE TABLE IF NOT EXISTS report_generations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    report_type TEXT NOT NULL,
    period_start DATE,
    period_end DATE,
    duration_ms INTEGER,
    rows_generated INTEGER,
    status TEXT DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==================== SCHEMA VERSIONING ====================

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_file TEXT NOT NULL UNIQUE,
    applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ==================== DEFAULT DATA ====================

INSERT OR IGNORE INTO institutions (id, name, address, contact, email, status) VALUES 
(1, 'Main Library', '123 Library Street, City', '+1234567890', 'library@example.com', 'active');

-- Default admin user (password = admin123)
INSERT OR IGNORE INTO users (username, password, fullname, role, token_version) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 1),
('staff1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Library Staff', 'staff', 1);

-- Default settings row
INSERT OR IGNORE INTO settings (id) VALUES (1);

-- Default fine rates
INSERT OR IGNORE INTO fine_rates (member_category, fine_per_day, max_fine, grace_period_days, is_active) VALUES 
('Student', 2, 100, 0, 1),
('Staff', 5, 0, 3, 1),
('Teacher', 5, 0, 3, 1),
('General', 3, 200, 0, 1),
('Visitor', 10, 500, 0, 1);

-- Default quick actions
INSERT OR IGNORE INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES
('Issue Book', 'fa-arrow-right', 'circulation/issue.php', 1, 1),
('Return Book', 'fa-arrow-left', 'circulation/return.php', 2, 1),
('Renew', 'fa-sync-alt', 'circulation/renew.php', 3, 1),
('Computer Access', 'fa-desktop', 'computer_management/', 4, 1),
('eBooks', 'fa-file-pdf', 'ebooks/', 5, 1),
('Utilities Suite', 'fa-toolbox', 'utilities/', 6, 1),
('Serial Control', 'fa-newspaper', 'serial/', 7, 1),
('Backup & Restore', 'fa-database', 'admin/backup.php', 8, 1),
('Reports', 'fa-chart-bar', 'reports/', 9, 1),
('Settings', 'fa-cog', 'admin/settings.php', 10, 1);

-- Default computer policies
INSERT OR IGNORE INTO computer_policies (user_role, max_minutes_per_day, max_minutes_per_week, max_sessions_per_week, require_attendance, weekly_attendance_required) VALUES
('student', 60, 240, 3, 1, 1),
('teacher', 120, 480, 10, 0, 0),
('staff', 90, 360, 5, 1, 1),
('visitor', 30, 120, 2, 0, 0);

-- Default staff profiles
INSERT OR IGNORE INTO staff_profiles (name, designation, sort_order, is_active) VALUES
('Librarian', 'Head Librarian', 1, 1),
('Assistant Librarian', 'Staff', 2, 1);

-- Default research databases
INSERT OR IGNORE INTO research_databases (name, description, url, category, type, icon, is_featured, sort_order) VALUES 
('JSTOR', 'Digital library of academic journals, books, and primary sources', 'https://www.jstor.org/', 'Academic', 'academic', 'university', 1, 1),
('Google Scholar', 'Free academic search engine', 'https://scholar.google.com/', 'Academic', 'open_access', 'graduation-cap', 1, 2),
('PubMed', 'Biomedical literature database', 'https://pubmed.ncbi.nlm.nih.gov/', 'Medical', 'open_access', 'heartbeat', 1, 3),
('DOAJ', 'Directory of Open Access Journals', 'https://doaj.org/', 'Academic', 'open_access', 'lock-open', 1, 4),
('IEEE Xplore', 'Technical literature in electrical engineering', 'https://ieeexplore.ieee.org/', 'Engineering', 'subscription', 'microchip', 1, 5),
('ScienceDirect', 'Scientific and medical research', 'https://www.sciencedirect.com/', 'Science', 'subscription', 'flask', 1, 6),
('SpringerLink', 'Scientific documents and journals', 'https://link.springer.com/', 'Academic', 'subscription', 'book', 1, 7),
('ERIC', 'Education research database', 'https://eric.ed.gov/', 'Education', 'open_access', 'chalkboard-user', 1, 8);