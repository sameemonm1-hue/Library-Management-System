<?php
/**
 * tests/Unit/FineCalculationTest.php
 * PHPUnit test for fine calculation logic.
 *
 * Run: vendor/bin/phpunit tests/Unit/FineCalculationTest.php
 */

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../../config/functions.php';

class FineCalculationTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
    }

    public function testNoFineWhenReturnedOnTime()
    {
        $dueDate = date('Y-m-d', strtotime('+7 days'));
        $fine = calculateFine($dueDate, 'Student', date('Y-m-d'));
        $this->assertEquals(0.0, $fine);
    }

    public function testFineCalculatedCorrectlyForStudent()
    {
        $dueDate = date('Y-m-d', strtotime('-5 days'));
        $fine = calculateFine($dueDate, 'Student');
        // Default fine per day is 2 (from settings)
        $expected = 5 * 2;
        $this->assertEquals($expected, $fine);
    }

    public function testGracePeriodApplied()
    {
        $settings = getSettings();
        $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
        if ($gracePeriod == 0) {
            $this->markTestSkipped('Grace period not configured in settings.');
        }
        $dueDate = date('Y-m-d', strtotime('-'.($gracePeriod+2).' days'));
        $fine = calculateFine($dueDate, 'Student');
        $expected = 2 * 2; // 2 days after grace * 2 per day
        $this->assertEquals($expected, $fine);
    }

    public function testMaxFineLimit()
    {
        $settings = getSettings();
        $maxFine = (float)($settings['max_fine_amount'] ?? 0);
        if ($maxFine == 0) {
            $this->markTestSkipped('Max fine not configured.');
        }
        $dueDate = date('Y-m-d', strtotime('-100 days'));
        $fine = calculateFine($dueDate, 'Student');
        $this->assertLessThanOrEqual($maxFine, $fine);
    }

    public function testFineZeroWhenDueDateInFuture()
    {
        $dueDate = date('Y-m-d', strtotime('+10 days'));
        $fine = calculateFine($dueDate);
        $this->assertEquals(0.0, $fine);
    }

    public function testFineUsesMemberCategoryRate()
    {
        $studentFine = calculateFine(date('Y-m-d', strtotime('-3 days')), 'Student');
        $staffFine = calculateFine(date('Y-m-d', strtotime('-3 days')), 'Staff');
        $this->assertIsFloat($studentFine);
        $this->assertIsFloat($staffFine);
    }

    public function testCalculateFineWithCustomReturnDate()
    {
        $dueDate = date('Y-m-d', strtotime('-5 days'));
        $returnDate = date('Y-m-d', strtotime('-2 days'));
        $fine = calculateFine($dueDate, 'Student', $returnDate);
        // Overdue for 3 days (due -5, return -2 = 3 days)
        $expected = 3 * 2;
        $this->assertEquals($expected, $fine);
    }
}