<?php
/**
 * Library ERP REST API
 * Version: 1.0
 * Endpoints: /api/members, /api/books, /api/circulation, /api/ebooks, etc.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// API Authentication
function authenticateAPI() {
    $headers = getallheaders();
    $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? '';
    
    if (empty($apiKey)) {
        http_response_code(401);
        echo json_encode(['error' => 'API key required']);
        exit;
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM api_keys WHERE api_key = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > datetime('now'))");
    $stmt->execute([$apiKey]);
    $key = $stmt->fetch();
    
    if (!$key) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired API key']);
        exit;
    }
    
    // Update last used timestamp
    $db->prepare("UPDATE api_keys SET last_used = datetime('now') WHERE id = ?")->execute([$key['id']]);
    
    return $key;
}

// Parse request
$method = $_SERVER['REQUEST_METHOD'];
$path = $_GET['route'] ?? '';
$segments = explode('/', trim($path, '/'));
$resource = $segments[0] ?? '';
$id = $segments[1] ?? null;

// API Key authentication (except for public endpoints)
$publicEndpoints = ['/health', '/opac/search', '/opac/books', '/opac/ebooks'];
$isPublic = in_array('/' . $resource, $publicEndpoints) || ($resource === 'opac' && count($segments) > 1);

if (!$isPublic) {
    $apiKey = authenticateAPI();
}

$db = getDB();

// ========== API Routes ==========
switch ($resource) {
    case 'health':
        echo json_encode(['status' => 'ok', 'timestamp' => date('c')]);
        break;
        
    case 'members':
        require_once __DIR__ . '/members.php';
        break;
        
    case 'books':
        require_once __DIR__ . '/books.php';
        break;
        
    case 'circulation':
        require_once __DIR__ . '/circulation.php';
        break;
        
    case 'ebooks':
        require_once __DIR__ . '/ebooks.php';
        break;
        
    case 'opac':
        require_once __DIR__ . '/opac.php';
        break;
        
    case 'auth':
        require_once __DIR__ . '/auth.php';
        break;
        
    case 'notifications':
        require_once __DIR__ . '/notifications.php';
        break;
        
    case 'reports':
        require_once __DIR__ . '/reports.php';
        break;
        
    default:
        http_response_code(404);
        echo json_encode(['error' => 'Endpoint not found']);
}
?>