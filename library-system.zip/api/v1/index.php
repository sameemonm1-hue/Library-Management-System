<?php
/**
 * Library ERP REST API - Version 2.1
 * Fully integrated with the enhanced database schema (Version 14+)
 *
 * Endpoints:
 *   GET    /                        - API info (public)
 *   GET    /health                  - health check (public)
 *   GET    /stats                   - system statistics (public)
 *   GET    /members[/{id}]          (list, get, search by name/admno)
 *   POST   /members                 (create new member)
 *   PUT    /members/{id}            (update member)
 *   DELETE /members/{id}            (soft delete → status='inactive')
 *   GET    /books[/{id}]            (list, get, search by title/author/barcode)
 *   POST   /books                   (add new book)
 *   PUT    /books/{id}              (update book)
 *   DELETE /books/{id}              (hard delete)
 *   GET    /circulation[/{id}]      (list loans, get one)
 *   POST   /circulation/issue       (issue a book)
 *   POST   /circulation/return      (return a book)
 *   POST   /circulation/renew       (renew a loan)
 *   GET    /fines[/{admno}]         (get fines for a member)
 *   POST   /fines/pay               (record a fine payment)
 *   GET    /holds                   (list active holds)
 *   POST   /holds                   (place a hold)
 *   GET    /overdue                 (list overdue loans)
 *   GET    /ebooks[/{id}]           (list/get eBooks)
 *   GET    /opac/search?q={query}   (FTS5 search across books/members/circulation)
 *   GET    /opac/books              (OPAC book list)
 *   GET    /opac/ebooks             (OPAC eBook list)
 *   POST   /auth                    (staff or member login)
 *   GET    /notifications           (stub)
 *   GET    /reports?type={type}     (circulation, overdue, etc.)
 *
 * Authentication: All endpoints except /, /health, /stats, /opac/* require an API key
 * (X-API-Key header or api_key query parameter) stored in the api_keys table.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Include the database layer (defines Database class and all helpers)
require_once __DIR__ . '/../../config/db.php';

// Helper: send JSON response and exit
function sendJson($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Helper: extract JSON input
function getJsonInput() {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true);
}

// Authentication middleware
function authenticateAPI() {
    $headers = getallheaders();
    $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? '';
    if (empty($apiKey)) {
        sendJson(['error' => 'API key required'], 401);
    }
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM api_keys WHERE api_key = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > datetime('now'))");
    $stmt->execute([$apiKey]);
    $key = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$key) {
        sendJson(['error' => 'Invalid or expired API key'], 401);
    }
    // Update last_used timestamp
    $db->prepare("UPDATE api_keys SET last_used = datetime('now') WHERE id = ?")->execute([$key['id']]);
    return $key;
}

// Parse request
$method = $_SERVER['REQUEST_METHOD'];
$path = $_GET['route'] ?? '';
$segments = explode('/', trim($path, '/'));
$resource = $segments[0] ?? '';
$id = $segments[1] ?? null;
$sub = $segments[2] ?? null;

// ========== ROOT (public) ==========
if (empty($resource)) {
    sendJson([
        'name' => 'Library ERP REST API',
        'version' => '2.1',
        'endpoints' => [
            'public' => ['/', '/health', '/stats', '/opac/*'],
            'protected' => ['/members', '/books', '/circulation', '/fines', '/holds', '/overdue', '/ebooks', '/auth', '/notifications', '/reports']
        ],
        'documentation' => 'See README or Swagger docs'
    ]);
}

// Public endpoints that do not require authentication
$publicEndpoints = ['health', 'stats', 'opac'];
if (!in_array($resource, $publicEndpoints)) {
    authenticateAPI();
}

// Get DB connection
$db = getDB();

// ========== ROUTER ==========
switch ($resource) {
    case 'health':
        sendJson(['status' => 'ok', 'timestamp' => date('c')]);
        break;

    case 'stats':
        handleStats($db);
        break;

    case 'members':
        handleMembers($method, $id, $db);
        break;

    case 'books':
        handleBooks($method, $id, $db);
        break;

    case 'circulation':
        handleCirculation($method, $id, $sub, $db);
        break;

    case 'fines':
        handleFines($method, $id, $sub, $db);
        break;

    case 'holds':
        handleHolds($method, $id, $db);
        break;

    case 'overdue':
        handleOverdue($method, $db);
        break;

    case 'ebooks':
        handleEbooks($method, $id, $db);
        break;

    case 'opac':
        handleOpac($method, $sub, $db);
        break;

    case 'auth':
        handleAuth($method, $db);
        break;

    case 'notifications':
        handleNotifications($method, $id, $db);
        break;

    case 'reports':
        handleReports($method, $db);
        break;

    default:
        sendJson(['error' => 'Endpoint not found'], 404);
}

// ========== HANDLER IMPLEMENTATIONS ==========

function handleStats($db) {
    try {
        $totalBooks = (int)$db->query("SELECT COUNT(*) FROM books")->fetchColumn();
        $totalMembers = (int)$db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
        $activeLoans = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE status = 'issued'")->fetchColumn();
        $overdue = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE status = 'issued' AND due_date < date('now')")->fetchColumn();
        $totalFines = (float)$db->query("SELECT COALESCE(SUM(total_fines), 0) FROM members")->fetchColumn();
        sendJson([
            'total_books' => $totalBooks,
            'active_members' => $totalMembers,
            'active_loans' => $activeLoans,
            'overdue_loans' => $overdue,
            'total_outstanding_fines' => $totalFines
        ]);
    } catch (Exception $e) {
        sendJson(['error' => 'Failed to fetch stats: ' . $e->getMessage()], 500);
    }
}

function handleMembers($method, $id, $db) {
    switch ($method) {
        case 'GET':
            if ($id) {
                $stmt = $db->prepare("SELECT id, admno, name, member_category, class, division, email, phone, active_books, total_fines, status, membership_expiry, security_deposit FROM members WHERE id = ? OR admno = ?");
                $stmt->execute([$id, $id]);
                $member = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$member) sendJson(['error' => 'Member not found'], 404);
                sendJson($member);
            } else {
                $page = max(1, (int)($_GET['page'] ?? 1));
                $limit = min(100, (int)($_GET['limit'] ?? 20));
                $offset = ($page - 1) * $limit;
                $search = trim($_GET['search'] ?? '');
                $sql = "SELECT id, admno, name, member_category, email, phone, status FROM members WHERE 1=1";
                $params = [];
                if ($search) {
                    if ($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='members_fts'")->fetch()) {
                        $sql = "SELECT m.id, m.admno, m.name, m.member_category, m.email, m.phone, m.status 
                                FROM members m 
                                JOIN members_fts fts ON m.id = fts.rowid 
                                WHERE members_fts MATCH ? 
                                ORDER BY m.name LIMIT ? OFFSET ?";
                        $params = [$search . '*', $limit, $offset];
                    } else {
                        $like = "%$search%";
                        $sql .= " AND (name LIKE ? OR admno LIKE ? OR email LIKE ?)";
                        $params = [$like, $like, $like, $limit, $offset];
                    }
                } else {
                    $sql .= " ORDER BY name LIMIT ? OFFSET ?";
                    $params = [$limit, $offset];
                }
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
                // Count total with same filters
                $countSql = str_replace("SELECT id, admno, name, member_category, email, phone, status", "SELECT COUNT(*)", $sql);
                $countSql = preg_replace('/ LIMIT \? OFFSET \?$/', '', $countSql);
                $countStmt = $db->prepare($countSql);
                $countStmt->execute(array_slice($params, 0, count($params)-2));
                $total = (int)$countStmt->fetchColumn();
                sendJson(['data' => $members, 'total' => $total, 'page' => $page, 'limit' => $limit]);
            }
            break;

        case 'POST':
            $data = getJsonInput();
            if (empty($data['admno']) || empty($data['name'])) {
                sendJson(['error' => 'admno and name are required'], 400);
            }
            $check = $db->prepare("SELECT id FROM members WHERE admno = ?");
            $check->execute([$data['admno']]);
            if ($check->fetch()) {
                sendJson(['error' => 'Admission number already exists'], 409);
            }
            $fields = [
                'admno' => $data['admno'],
                'name' => $data['name'],
                'member_category' => $data['member_category'] ?? 'Student',
                'class' => $data['class'] ?? '',
                'division' => $data['division'] ?? '',
                'email' => $data['email'] ?? '',
                'phone' => $data['phone'] ?? '',
                'password' => password_hash($data['password'] ?? 'default123', PASSWORD_DEFAULT),
                'status' => 'active',
                'address' => $data['address'] ?? '',
                'dob' => $data['dob'] ?? null,
                'gender' => $data['gender'] ?? '',
                'blood_group' => $data['blood_group'] ?? '',
                'parent_phone' => $data['parent_phone'] ?? '',
                'emergency_contact' => $data['emergency_contact'] ?? '',
                'security_deposit' => $data['security_deposit'] ?? 0,
                'membership_expiry' => $data['membership_expiry'] ?? null,
                'designation' => $data['designation'] ?? '',
                'approval_status' => $data['approval_status'] ?? 'approved',
            ];
            $columns = implode(', ', array_keys($fields));
            $placeholders = implode(', ', array_fill(0, count($fields), '?'));
            $stmt = $db->prepare("INSERT INTO members ($columns) VALUES ($placeholders)");
            $stmt->execute(array_values($fields));
            sendJson(['message' => 'Member created', 'id' => $db->lastInsertId()], 201);
            break;

        case 'PUT':
            if (!$id) sendJson(['error' => 'Member ID required'], 400);
            $data = getJsonInput();
            $allowed = ['name', 'member_category', 'class', 'division', 'email', 'phone', 'address', 'dob', 'gender', 'blood_group', 'parent_phone', 'emergency_contact', 'security_deposit', 'membership_expiry', 'designation', 'status', 'approval_status'];
            $fields = [];
            $params = [];
            foreach ($allowed as $f) {
                if (array_key_exists($f, $data)) {
                    $fields[] = "$f = ?";
                    $params[] = $data[$f];
                }
            }
            if (isset($data['password'])) {
                $fields[] = "password = ?";
                $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            if (empty($fields)) sendJson(['error' => 'No fields to update'], 400);
            $params[] = $id;
            $db->prepare("UPDATE members SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);
            sendJson(['message' => 'Member updated']);
            break;

        case 'DELETE':
            if (!$id) sendJson(['error' => 'Member ID required'], 400);
            $db->prepare("UPDATE members SET status = 'inactive' WHERE id = ?")->execute([$id]);
            sendJson(['message' => 'Member deactivated']);
            break;

        default:
            sendJson(['error' => 'Method not allowed'], 405);
    }
}

function handleBooks($method, $id, $db) {
    switch ($method) {
        case 'GET':
            if ($id) {
                $stmt = $db->prepare("SELECT * FROM books WHERE id = ?");
                $stmt->execute([$id]);
                $book = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$book) sendJson(['error' => 'Book not found'], 404);
                sendJson($book);
            } else {
                $page = max(1, (int)($_GET['page'] ?? 1));
                $limit = min(100, (int)($_GET['limit'] ?? 20));
                $offset = ($page - 1) * $limit;
                $search = trim($_GET['search'] ?? '');
                $sql = "SELECT id, barcode, title, author, publisher, category, quantity, available, status FROM books WHERE 1=1";
                $params = [];
                if ($search) {
                    if ($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books_fts'")->fetch()) {
                        $sql = "SELECT b.id, b.barcode, b.title, b.author, b.publisher, b.category, b.quantity, b.available, b.status 
                                FROM books b 
                                JOIN books_fts fts ON b.id = fts.rowid 
                                WHERE books_fts MATCH ? 
                                ORDER BY b.title LIMIT ? OFFSET ?";
                        $params = [$search . '*', $limit, $offset];
                    } else {
                        $like = "%$search%";
                        $sql .= " AND (title LIKE ? OR author LIKE ? OR barcode LIKE ? OR isbn LIKE ?)";
                        $params = [$like, $like, $like, $like, $limit, $offset];
                    }
                } else {
                    $sql .= " ORDER BY title LIMIT ? OFFSET ?";
                    $params = [$limit, $offset];
                }
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $countSql = str_replace("SELECT id, barcode, title, author, publisher, category, quantity, available, status", "SELECT COUNT(*)", $sql);
                $countSql = preg_replace('/ LIMIT \? OFFSET \?$/', '', $countSql);
                $countStmt = $db->prepare($countSql);
                $countStmt->execute(array_slice($params, 0, count($params)-2));
                $total = (int)$countStmt->fetchColumn();
                sendJson(['data' => $books, 'total' => $total, 'page' => $page, 'limit' => $limit]);
            }
            break;

        case 'POST':
            $data = getJsonInput();
            if (empty($data['title']) || empty($data['barcode'])) {
                sendJson(['error' => 'title and barcode are required'], 400);
            }
            $check = $db->prepare("SELECT id FROM books WHERE barcode = ?");
            $check->execute([$data['barcode']]);
            if ($check->fetch()) {
                sendJson(['error' => 'Barcode already exists'], 409);
            }
            $fields = [
                'barcode' => $data['barcode'],
                'title' => $data['title'],
                'author' => $data['author'] ?? '',
                'publisher' => $data['publisher'] ?? '',
                'year' => $data['year'] ?? null,
                'category' => $data['category'] ?? '',
                'quantity' => $data['quantity'] ?? 1,
                'available' => $data['quantity'] ?? 1,
                'isbn' => $data['isbn'] ?? '',
                'call_number' => $data['call_number'] ?? '',
                'sub_title' => $data['sub_title'] ?? '',
                'author2' => $data['author2'] ?? '',
                'collaborator' => $data['collaborator'] ?? '',
                'subject' => $data['subject'] ?? '',
                'keyword' => $data['keyword'] ?? '',
                'sub_category' => $data['sub_category'] ?? '',
                'publisher_place' => $data['publisher_place'] ?? '',
                'edition' => $data['edition'] ?? '',
                'pages' => $data['pages'] ?? null,
                'language' => $data['language'] ?? 'English',
                'location' => $data['location'] ?? '',
                'summary' => $data['summary'] ?? '',
                'description' => $data['description'] ?? '',
                'price' => $data['price'] ?? 0,
                'replacement_cost' => $data['replacement_cost'] ?? 0,
                'accession_number' => $data['accession_number'] ?? '',
                'remarks' => $data['remarks'] ?? '',
                'status' => $data['status'] ?? 'Available',
                'book_status' => $data['book_status'] ?? 'Available',
                'binding' => $data['binding'] ?? '',
                'holding' => $data['holding'] ?? '',
                'maintenance' => $data['maintenance'] ?? '',
                'current_location' => $data['current_location'] ?? '',
                'section' => $data['section'] ?? '',
                'ddc' => $data['ddc'] ?? '',
                'udc' => $data['udc'] ?? '',
                'lcc' => $data['lcc'] ?? '',
                'cutter' => $data['cutter'] ?? '',
                'series' => $data['series'] ?? '',
                'volume' => $data['volume'] ?? '',
                'corporate_author' => $data['corporate_author'] ?? '',
                'conference_author' => $data['conference_author'] ?? '',
                'issn' => $data['issn'] ?? '',
                'illustrations' => $data['illustrations'] ?? '',
                'dimensions' => $data['dimensions'] ?? '',
                'country' => $data['country'] ?? '',
                'collection_type' => $data['collection_type'] ?? '',
                'branch' => $data['branch'] ?? '',
                'shelf' => $data['shelf'] ?? '',
                'vendor' => $data['vendor'] ?? '',
                'invoice' => $data['invoice'] ?? '',
                'invoice_date' => $data['invoice_date'] ?? null,
                'acquisition_date' => $data['acquisition_date'] ?? null,
                'funding_source' => $data['funding_source'] ?? '',
                'po_number' => $data['po_number'] ?? '',
                'ebook_url' => $data['ebook_url'] ?? '',
                'contents' => $data['contents'] ?? '',
                'accompanying_material' => $data['accompanying_material'] ?? '',
                'material_type' => $data['material_type'] ?? '',
                'size' => $data['size'] ?? '',
                'weight' => $data['weight'] ?? '',
                'cc' => $data['cc'] ?? '',
                'other_classification' => $data['other_classification'] ?? '',
            ];
            $columns = implode(', ', array_keys($fields));
            $placeholders = implode(', ', array_fill(0, count($fields), '?'));
            $stmt = $db->prepare("INSERT INTO books ($columns) VALUES ($placeholders)");
            $stmt->execute(array_values($fields));
            sendJson(['message' => 'Book created', 'id' => $db->lastInsertId()], 201);
            break;

        case 'PUT':
            if (!$id) sendJson(['error' => 'Book ID required'], 400);
            $data = getJsonInput();
            $allowed = ['barcode', 'title', 'author', 'publisher', 'year', 'category', 'quantity', 'available', 'isbn', 'call_number', 'sub_title', 'author2', 'collaborator', 'subject', 'keyword', 'sub_category', 'publisher_place', 'edition', 'pages', 'language', 'location', 'summary', 'description', 'price', 'replacement_cost', 'accession_number', 'remarks', 'status', 'book_status', 'binding', 'holding', 'maintenance', 'current_location', 'section', 'ddc', 'udc', 'lcc', 'cutter', 'series', 'volume', 'corporate_author', 'conference_author', 'issn', 'illustrations', 'dimensions', 'country', 'collection_type', 'branch', 'shelf', 'vendor', 'invoice', 'invoice_date', 'acquisition_date', 'funding_source', 'po_number', 'ebook_url', 'contents', 'accompanying_material', 'material_type', 'size', 'weight', 'cc', 'other_classification'];
            $fields = [];
            $params = [];
            foreach ($allowed as $f) {
                if (array_key_exists($f, $data)) {
                    $fields[] = "$f = ?";
                    $params[] = $data[$f];
                }
            }
            if (empty($fields)) sendJson(['error' => 'No fields to update'], 400);
            $params[] = $id;
            $db->prepare("UPDATE books SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);
            sendJson(['message' => 'Book updated']);
            break;

        case 'DELETE':
            if (!$id) sendJson(['error' => 'Book ID required'], 400);
            $db->prepare("DELETE FROM books WHERE id = ?")->execute([$id]);
            sendJson(['message' => 'Book deleted']);
            break;

        default:
            sendJson(['error' => 'Method not allowed'], 405);
    }
}

function handleCirculation($method, $id, $sub, $db) {
    if ($method === 'POST' && $sub === 'issue') {
        $data = getJsonInput();
        if (empty($data['admno']) || empty($data['barcode'])) {
            sendJson(['error' => 'admno and barcode are required'], 400);
        }

        $member = getMemberByAdmno($data['admno']);
        if (!$member || $member['status'] !== 'active') {
            sendJson(['error' => 'Member not found or inactive'], 404);
        }

        $book = getBookByBarcode($data['barcode']);
        if (!$book) {
            sendJson(['error' => 'Book not found'], 404);
        }
        if ($book['available'] < 1) {
            sendJson(['error' => 'No copies available for issue'], 400);
        }

        $rule = getLoanRule($member['member_category'], $book['category'] ?? 'Book');
        $dueDays = $rule['loan_period'] ?? 14;
        $dueDate = date('Y-m-d', strtotime("+$dueDays days"));

        $db->beginTransaction();
        try {
            $stmt = $db->prepare("INSERT INTO circulation (barcode, admno, member_name, class, division, title, author, isbn, publisher, category, issue_date, due_date, status) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'issued')");
            $stmt->execute([
                $data['barcode'],
                $member['admno'],
                $member['name'],
                $member['class'] ?? '',
                $member['division'] ?? '',
                $book['title'],
                $book['author'] ?? '',
                $book['isbn'] ?? '',
                $book['publisher'] ?? '',
                $book['category'] ?? '',
                date('Y-m-d'),
                $dueDate
            ]);
            $loanId = $db->lastInsertId();

            $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$data['barcode']]);
            $db->prepare("UPDATE members SET active_books = active_books + 1 WHERE admno = ?")->execute([$member['admno']]);

            $db->commit();
            sendJson(['message' => 'Book issued', 'loan_id' => $loanId, 'due_date' => $dueDate], 201);
        } catch (Exception $e) {
            $db->rollBack();
            sendJson(['error' => 'Issue failed: ' . $e->getMessage()], 500);
        }
    } elseif ($method === 'POST' && $sub === 'return') {
        $data = getJsonInput();
        if (empty($data['barcode'])) {
            sendJson(['error' => 'barcode is required'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM circulation WHERE barcode = ? AND status = 'issued'");
        $stmt->execute([$data['barcode']]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$loan) {
            sendJson(['error' => 'No active loan found for this barcode'], 404);
        }

        $fine = 0;
        $dueDate = $loan['due_date'];
        $today = date('Y-m-d');
        if ($today > $dueDate) {
            $settings = getSettings();
            $finePerDay = $settings['fine_per_day'] ?? 1;
            $days = (new DateTime($today))->diff(new DateTime($dueDate))->days;
            $fine = $days * $finePerDay;
        }

        $db->beginTransaction();
        try {
            $stmt = $db->prepare("UPDATE circulation SET return_date = ?, status = 'returned', fine = ? WHERE id = ?");
            $stmt->execute([$today, $fine, $loan['id']]);

            $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$data['barcode']]);
            $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $loan['admno']]);

            if ($fine > 0) {
                $stmt = $db->prepare("INSERT INTO fine_payments (circulation_id, admno, amount, payment_date, status) VALUES (?, ?, ?, ?, 'pending')");
                $stmt->execute([$loan['id'], $loan['admno'], $fine, $today]);
            }

            $db->commit();
            sendJson(['message' => 'Book returned', 'fine' => $fine]);
        } catch (Exception $e) {
            $db->rollBack();
            sendJson(['error' => 'Return failed: ' . $e->getMessage()], 500);
        }
    } elseif ($method === 'POST' && $sub === 'renew') {
        $data = getJsonInput();
        if (empty($data['loan_id'])) {
            sendJson(['error' => 'loan_id required'], 400);
        }

        $stmt = $db->prepare("SELECT * FROM circulation WHERE id = ? AND status = 'issued'");
        $stmt->execute([$data['loan_id']]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$loan) {
            sendJson(['error' => 'No active loan found'], 404);
        }

        $renewals = (int)$loan['renew_count'] ?? 0;
        $settings = getSettings();
        $maxRenewals = $settings['max_renewals'] ?? 0;
        if ($maxRenewals > 0 && $renewals >= $maxRenewals) {
            sendJson(['error' => 'Maximum renewals reached'], 400);
        }

        $member = getMemberByAdmno($loan['admno']);
        $rule = getLoanRule($member['member_category'], $loan['category'] ?? 'Book');
        $dueDays = $rule['loan_period'] ?? 14;
        $newDueDate = date('Y-m-d', strtotime($loan['due_date'] . " +$dueDays days"));

        $db->beginTransaction();
        try {
            $db->prepare("UPDATE circulation SET due_date = ?, renew_count = renew_count + 1 WHERE id = ?")->execute([$newDueDate, $loan['id']]);
            $db->commit();
            sendJson(['message' => 'Loan renewed', 'new_due_date' => $newDueDate]);
        } catch (Exception $e) {
            $db->rollBack();
            sendJson(['error' => 'Renewal failed: ' . $e->getMessage()], 500);
        }
    } elseif ($method === 'GET') {
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM circulation WHERE id = ?");
            $stmt->execute([$id]);
            $rec = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$rec) sendJson(['error' => 'Record not found'], 404);
            sendJson($rec);
        } else {
            $page = max(1, (int)($_GET['page'] ?? 1));
            $limit = min(100, (int)($_GET['limit'] ?? 20));
            $offset = ($page - 1) * $limit;
            $status = $_GET['status'] ?? '';
            $sql = "SELECT * FROM circulation WHERE 1=1";
            $params = [];
            if ($status) {
                $sql .= " AND status = ?";
                $params[] = $status;
            }
            $sql .= " ORDER BY issue_date DESC LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $recs = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $countSql = str_replace("SELECT *", "SELECT COUNT(*)", $sql);
            $countSql = preg_replace('/ LIMIT \? OFFSET \?$/', '', $countSql);
            $countStmt = $db->prepare($countSql);
            $countStmt->execute(array_slice($params, 0, count($params)-2));
            $total = (int)$countStmt->fetchColumn();
            sendJson(['data' => $recs, 'total' => $total, 'page' => $page, 'limit' => $limit]);
        }
    } else {
        sendJson(['error' => 'Method not allowed or invalid action'], 405);
    }
}

function handleFines($method, $id, $sub, $db) {
    if ($method === 'GET') {
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM fine_payments WHERE admno = ? OR id = ?");
            $stmt->execute([$id, $id]);
            $fines = $stmt->fetchAll(PDO::FETCH_ASSOC);
            sendJson($fines);
        } else {
            $page = max(1, (int)($_GET['page'] ?? 1));
            $limit = min(100, (int)($_GET['limit'] ?? 20));
            $offset = ($page - 1) * $limit;
            $stmt = $db->prepare("SELECT * FROM fine_payments ORDER BY payment_date DESC LIMIT ? OFFSET ?");
            $stmt->execute([$limit, $offset]);
            $fines = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $total = (int)$db->query("SELECT COUNT(*) FROM fine_payments")->fetchColumn();
            sendJson(['data' => $fines, 'total' => $total, 'page' => $page, 'limit' => $limit]);
        }
    } elseif ($method === 'POST' && $sub === 'pay') {
        $data = getJsonInput();
        if (empty($data['admno']) || empty($data['amount']) || $data['amount'] <= 0) {
            sendJson(['error' => 'admno and positive amount required'], 400);
        }
        $member = getMemberByAdmno($data['admno']);
        if (!$member) sendJson(['error' => 'Member not found'], 404);

        $db->beginTransaction();
        try {
            $stmt = $db->prepare("INSERT INTO fine_payments (admno, amount, payment_date, payment_method, receipt_no, status, notes) 
                                  VALUES (?, ?, ?, ?, ?, 'paid', ?)");
            $receiptNo = 'RCP' . date('Ymd') . rand(1000, 9999);
            $stmt->execute([
                $data['admno'],
                $data['amount'],
                date('Y-m-d'),
                $data['payment_method'] ?? 'cash',
                $receiptNo,
                $data['notes'] ?? ''
            ]);
            $db->prepare("UPDATE members SET total_fines = total_fines - ? WHERE admno = ?")->execute([$data['amount'], $data['admno']]);
            $db->commit();
            sendJson(['message' => 'Fine paid', 'receipt_no' => $receiptNo]);
        } catch (Exception $e) {
            $db->rollBack();
            sendJson(['error' => 'Payment failed: ' . $e->getMessage()], 500);
        }
    } else {
        sendJson(['error' => 'Method not allowed'], 405);
    }
}

function handleHolds($method, $id, $db) {
    if ($method === 'GET') {
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM book_holds WHERE id = ?");
            $stmt->execute([$id]);
            $hold = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$hold) sendJson(['error' => 'Hold not found'], 404);
            sendJson($hold);
        } else {
            $page = max(1, (int)($_GET['page'] ?? 1));
            $limit = min(100, (int)($_GET['limit'] ?? 20));
            $offset = ($page - 1) * $limit;
            $status = $_GET['status'] ?? 'pending';
            $stmt = $db->prepare("SELECT * FROM book_holds WHERE status = ? ORDER BY hold_date LIMIT ? OFFSET ?");
            $stmt->execute([$status, $limit, $offset]);
            $holds = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // Count total with same status
            $countStmt = $db->prepare("SELECT COUNT(*) FROM book_holds WHERE status = ?");
            $countStmt->execute([$status]);
            $total = (int)$countStmt->fetchColumn();
            sendJson(['data' => $holds, 'total' => $total, 'page' => $page, 'limit' => $limit]);
        }
    } elseif ($method === 'POST') {
        $data = getJsonInput();
        if (empty($data['book_barcode']) || empty($data['admno'])) {
            sendJson(['error' => 'book_barcode and admno required'], 400);
        }
        $book = getBookByBarcode($data['book_barcode']);
        if (!$book) sendJson(['error' => 'Book not found'], 404);
        $member = getMemberByAdmno($data['admno']);
        if (!$member) sendJson(['error' => 'Member not found'], 404);

        $check = $db->prepare("SELECT id FROM book_holds WHERE book_barcode = ? AND admno = ? AND status = 'pending'");
        $check->execute([$data['book_barcode'], $data['admno']]);
        if ($check->fetch()) {
            sendJson(['error' => 'Hold already placed for this book'], 409);
        }

        $settings = getSettings();
        $holdDays = $settings['hold_days'] ?? 7;
        $expiry = date('Y-m-d', strtotime("+$holdDays days"));

        $stmt = $db->prepare("INSERT INTO book_holds (book_barcode, admno, member_name, hold_date, expiry_date, status) VALUES (?, ?, ?, ?, ?, 'pending')");
        $stmt->execute([$data['book_barcode'], $data['admno'], $member['name'], date('Y-m-d'), $expiry]);
        sendJson(['message' => 'Hold placed', 'id' => $db->lastInsertId()], 201);
    } else {
        sendJson(['error' => 'Method not allowed'], 405);
    }
}

function handleOverdue($method, $db) {
    if ($method !== 'GET') sendJson(['error' => 'Method not allowed'], 405);
    $loans = getOverdueLoans();
    sendJson(['overdue_count' => count($loans), 'loans' => $loans]);
}

function handleEbooks($method, $id, $db) {
    if ($method !== 'GET') sendJson(['error' => 'Method not allowed'], 405);
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
        $stmt->execute([$id]);
        $ebook = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$ebook) sendJson(['error' => 'eBook not found'], 404);
        sendJson($ebook);
    } else {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $limit = min(100, (int)($_GET['limit'] ?? 20));
        $offset = ($page - 1) * $limit;
        $search = trim($_GET['search'] ?? '');
        $sql = "SELECT * FROM ebooks WHERE 1=1";
        $params = [];
        if ($search) {
            $like = "%$search%";
            $sql .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ?)";
            $params = [$like, $like, $like, $limit, $offset];
        } else {
            $sql .= " ORDER BY title LIMIT ? OFFSET ?";
            $params = [$limit, $offset];
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $ebooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $countSql = str_replace("SELECT *", "SELECT COUNT(*)", $sql);
        $countSql = preg_replace('/ LIMIT \? OFFSET \?$/', '', $countSql);
        $countStmt = $db->prepare($countSql);
        $countStmt->execute(array_slice($params, 0, count($params)-2));
        $total = (int)$countStmt->fetchColumn();
        sendJson(['data' => $ebooks, 'total' => $total, 'page' => $page, 'limit' => $limit]);
    }
}

function handleOpac($method, $sub, $db) {
    if ($method !== 'GET') sendJson(['error' => 'Method not allowed'], 405);
    if ($sub === 'search') {
        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) sendJson(['books' => [], 'ebooks' => []]);
        $books = [];
        $ebooks = [];
        if ($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='books_fts'")->fetch()) {
            $stmt = $db->prepare("SELECT b.id, b.barcode, b.title, b.author, b.available FROM books b JOIN books_fts fts ON b.id = fts.rowid WHERE books_fts MATCH ? ORDER BY b.title LIMIT 20");
            $stmt->execute([$q . '*']);
            $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $like = "%$q%";
            $stmt = $db->prepare("SELECT id, barcode, title, author, available FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? LIMIT 20");
            $stmt->execute([$like, $like, $like]);
            $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        $stmt = $db->prepare("SELECT id, title, author FROM ebooks WHERE title LIKE ? OR author LIKE ? LIMIT 10");
        $like = "%$q%";
        $stmt->execute([$like, $like]);
        $ebooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        sendJson(['books' => $books, 'ebooks' => $ebooks]);
    } elseif ($sub === 'books') {
        $stmt = $db->query("SELECT id, barcode, title, author, available FROM books WHERE status = 'Available' ORDER BY title LIMIT 20");
        sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
    } elseif ($sub === 'ebooks') {
        $stmt = $db->query("SELECT id, title, author, cover_path FROM ebooks ORDER BY downloads DESC LIMIT 20");
        sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
    } else {
        sendJson(['error' => 'Invalid OPAC action'], 400);
    }
}

function handleAuth($method, $db) {
    if ($method !== 'POST') sendJson(['error' => 'Method not allowed'], 405);
    $data = getJsonInput();
    $type = $data['type'] ?? '';
    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';

    if ($type === 'staff') {
        $stmt = $db->prepare("SELECT id, username, role, password FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user || !password_verify($password, $user['password'])) {
            sendJson(['error' => 'Invalid credentials'], 401);
        }
        $db->prepare("UPDATE users SET last_login = datetime('now') WHERE id = ?")->execute([$user['id']]);
        $token = bin2hex(random_bytes(32));
        sendJson(['token' => $token, 'user' => ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']]]);
    } elseif ($type === 'member') {
        $stmt = $db->prepare("SELECT id, admno, name, password FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$username]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$member || !password_verify($password, $member['password'])) {
            sendJson(['error' => 'Invalid credentials'], 401);
        }
        $token = bin2hex(random_bytes(32));
        sendJson(['token' => $token, 'user' => ['id' => $member['id'], 'admno' => $member['admno'], 'name' => $member['name']]]);
    } else {
        sendJson(['error' => 'Invalid login type. Use "staff" or "member"'], 400);
    }
}

function handleNotifications($method, $id, $db) {
    // Stub – can be extended to list/send notifications
    sendJson(['message' => 'Notifications endpoint – implement as required']);
}

function handleReports($method, $db) {
    if ($method !== 'GET') sendJson(['error' => 'Method not allowed'], 405);
    $reportType = $_GET['type'] ?? 'circulation';
    switch ($reportType) {
        case 'circulation':
            $stmt = $db->query("SELECT COUNT(*) as total, date(issue_date) as day FROM circulation GROUP BY date(issue_date) ORDER BY day DESC LIMIT 30");
            sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;
        case 'overdue':
            $stmt = $db->query("SELECT c.*, m.name as member_name, b.title as book_title FROM circulation c JOIN members m ON c.admno = m.admno JOIN books b ON c.barcode = b.barcode WHERE c.status = 'issued' AND c.due_date < date('now')");
            sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;
        case 'members':
            $stmt = $db->query("SELECT member_category, COUNT(*) as count FROM members GROUP BY member_category");
            sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;
        case 'fines':
            $stmt = $db->query("SELECT admno, SUM(amount) as total_fines FROM fine_payments GROUP BY admno ORDER BY total_fines DESC LIMIT 20");
            sendJson($stmt->fetchAll(PDO::FETCH_ASSOC));
            break;
        default:
            sendJson(['error' => 'Report type not supported'], 400);
    }
}
?>