-- =====================================================
-- Library ERP System - MySQL Schema
-- Version: 1.0 (Complete)
-- Engine: InnoDB, Charset: utf8mb4
-- =====================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;

-- ==================== CORE TABLES ====================

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    role ENUM('admin','librarian','staff') DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME,
    login_attempts INT DEFAULT 0,
    locked_until DATETIME,
    token_version INT DEFAULT 1,
    export_count INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admno VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    general_id VARCHAR(50),
    member_category VARCHAR(50) DEFAULT 'Student',
    class VARCHAR(50),
    division VARCHAR(50),
    roll_no VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    parent_phone VARCHAR(20),
    address TEXT,
    dob DATE,
    gender ENUM('Male','Female','Other'),
    blood_group VARCHAR(5),
    photo_path VARCHAR(255),
    admission_date DATE DEFAULT (CURDATE()),
    active_books INT DEFAULT 0,
    total_issued INT DEFAULT 0,
    total_fines DECIMAL(10,2) DEFAULT 0.00,
    total_paid_fines DECIMAL(10,2) DEFAULT 0.00,
    security_deposit DECIMAL(10,2) DEFAULT 0.00,
    membership_expiry DATE,
    emergency_contact VARCHAR(100),
    notes TEXT,
    status ENUM('active','inactive') DEFAULT 'active',
    password VARCHAR(255),
    reset_token VARCHAR(64),
    token_expiry DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_reminder_sent DATE,
    expiry_notified TINYINT(1) DEFAULT 0,
    INDEX idx_admno (admno),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    barcode VARCHAR(50) NOT NULL UNIQUE,
    call_number VARCHAR(50),
    isbn VARCHAR(20),
    title VARCHAR(255) NOT NULL,
    sub_title VARCHAR(255),
    author VARCHAR(255),
    author2 VARCHAR(255),
    collaborator VARCHAR(255),
    subject VARCHAR(255),
    keyword TEXT,
    category VARCHAR(100),
    sub_category VARCHAR(100),
    publisher VARCHAR(255),
    publisher_place VARCHAR(255),
    edition VARCHAR(50),
    year VARCHAR(10),
    pages INT,
    language VARCHAR(50) DEFAULT 'English',
    location VARCHAR(100),
    summary TEXT,
    description TEXT,
    cover_path VARCHAR(255),
    quantity INT DEFAULT 1,
    available INT DEFAULT 1,
    price DECIMAL(10,2) DEFAULT 0.00,
    price_currency VARCHAR(3) DEFAULT 'INR',
    replacement_cost DECIMAL(10,2) DEFAULT 0.00,
    accession_number VARCHAR(50),
    total_lost INT DEFAULT 0,
    item_category VARCHAR(50),
    remarks TEXT,
    status ENUM('Available','Deleted') DEFAULT 'Available',
    book_status VARCHAR(50) DEFAULT 'Available',
    binding VARCHAR(50),
    holding VARCHAR(255),
    marcxml LONGTEXT,
    marc_json JSON,
    embedding JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_barcode (barcode),
    INDEX idx_isbn (isbn),
    INDEX idx_title (title),
    INDEX idx_category (category),
    INDEX idx_available (available)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS circulation (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(100) NOT NULL,
    class VARCHAR(50),
    division VARCHAR(50),
    barcode VARCHAR(50),
    isbn VARCHAR(20),
    title VARCHAR(255),
    author VARCHAR(255),
    category VARCHAR(100),
    publisher VARCHAR(255),
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    fine DECIMAL(10,2) DEFAULT 0.00,
    renew_count INT DEFAULT 0,
    notes TEXT,
    is_manual TINYINT(1) DEFAULT 0,
    last_whatsapp_sent DATETIME,
    INDEX idx_admno (admno),
    INDEX idx_barcode (barcode),
    INDEX idx_issue_date (issue_date),
    FOREIGN KEY (admno) REFERENCES members(admno) ON DELETE CASCADE,
    FOREIGN KEY (barcode) REFERENCES books(barcode) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status ENUM('issued','returned','overdue') DEFAULT 'issued',
    renew_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_member (member_id),
    INDEX idx_book (book_id),
    INDEX idx_due_date (due_date),
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== ACQUISITIONS & VENDORS ====================

CREATE TABLE IF NOT EXISTS vendors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    gst_no VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS purchase_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(50) NOT NULL UNIQUE,
    vendor_id INT,
    order_date DATE NOT NULL,
    expected_delivery DATE,
    status ENUM('pending','approved','shipped','received','cancelled') DEFAULT 'pending',
    total_amount DECIMAL(10,2),
    notes TEXT,
    created_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS purchase_order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    po_id INT NOT NULL,
    book_title VARCHAR(255) NOT NULL,
    isbn VARCHAR(20),
    author VARCHAR(255),
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2),
    received_quantity INT DEFAULT 0,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== DIGITAL RESOURCES ====================

CREATE TABLE IF NOT EXISTS ebooks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    subject VARCHAR(100),
    isbn VARCHAR(20),
    publisher VARCHAR(255),
    year VARCHAR(10),
    description TEXT,
    cover_path VARCHAR(255),
    file_path VARCHAR(255) NOT NULL,
    file_size INT,
    downloads INT DEFAULT 0,
    full_text LONGTEXT,
    cloud_file_id VARCHAR(255),
    storage_type ENUM('local','google_drive','dropbox','onedrive') DEFAULT 'local',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_title (title),
    INDEX idx_downloads (downloads)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS research_databases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    url VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    type ENUM('academic','open_access','subscription') DEFAULT 'academic',
    icon VARCHAR(50) DEFAULT 'database',
    is_featured TINYINT(1) DEFAULT 0,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS research_database_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    database_id INT NOT NULL,
    user_id INT,
    user_type ENUM('member','admin','guest'),
    action ENUM('access','search','download'),
    search_query VARCHAR(255),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (database_id) REFERENCES research_databases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== FINES & PAYMENTS ====================

CREATE TABLE IF NOT EXISTS fine_rates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_category VARCHAR(50) NOT NULL UNIQUE,
    fine_per_day DECIMAL(10,2) NOT NULL DEFAULT 2.00,
    max_fine DECIMAL(10,2) DEFAULT 0.00,
    grace_period_days INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fine_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    circulation_id INT,
    admno VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('cash','card','online','cheque') DEFAULT 'cash',
    receipt_no VARCHAR(50) UNIQUE,
    status ENUM('paid','refunded','pending') DEFAULT 'paid',
    notes TEXT,
    collected_by VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_admno VARCHAR(50) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_type ENUM('fine','deposit','lost_fee','donation','membership_fee') NOT NULL,
    reference_id VARCHAR(100),
    related_circulation_id INT,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method ENUM('cash','card','online','cheque') DEFAULT 'cash',
    receipt_no VARCHAR(50) UNIQUE,
    notes TEXT,
    created_by VARCHAR(50),
    currency VARCHAR(3) DEFAULT 'INR',
    FOREIGN KEY (related_circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fine_settlements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admno VARCHAR(50) NOT NULL,
    total_fine DECIMAL(10,2) NOT NULL,
    amount_paid DECIMAL(10,2) DEFAULT 0.00,
    amount_waived DECIMAL(10,2) DEFAULT 0.00,
    settlement_date DATE,
    settled_by VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lost_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_barcode VARCHAR(50) NOT NULL,
    admno VARCHAR(50) NOT NULL,
    circulation_id INT,
    loss_date DATE NOT NULL,
    declared_lost_by VARCHAR(50),
    replacement_cost DECIMAL(10,2),
    amount_paid DECIMAL(10,2) DEFAULT 0.00,
    replacement_book_barcode VARCHAR(50),
    status ENUM('pending','paid','waived') DEFAULT 'pending',
    notes TEXT,
    currency VARCHAR(3) DEFAULT 'INR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== NOTIFICATIONS & COMMUNICATION ====================

CREATE TABLE IF NOT EXISTS notices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS suggestions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    institution_id INT DEFAULT 1,
    member_admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(100),
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    isbn VARCHAR(20),
    reason TEXT,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS overdue_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    circulation_id INT NOT NULL,
    admno VARCHAR(50) NOT NULL,
    notification_type ENUM('email','sms','whatsapp'),
    days_overdue INT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('sent','failed') DEFAULT 'sent',
    response TEXT,
    FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notification_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_type ENUM('member','admin','staff'),
    recipient VARCHAR(100) NOT NULL,
    notification_type VARCHAR(50) NOT NULL,
    subject VARCHAR(255),
    message TEXT,
    channel ENUM('email','sms','whatsapp','push'),
    status ENUM('pending','sent','failed') DEFAULT 'pending',
    sent_at DATETIME,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    alt_body TEXT,
    priority INT DEFAULT 0,
    attempts INT DEFAULT 0,
    last_attempt DATETIME,
    status ENUM('pending','sent','failed') DEFAULT 'pending',
    error TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS whatsapp_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone_number VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    priority INT DEFAULT 0,
    status ENUM('pending','sent','failed') DEFAULT 'pending',
    attempts INT DEFAULT 0,
    last_attempt DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_key VARCHAR(50) NOT NULL UNIQUE,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== ENTRY/EXIT & VISITOR MANAGEMENT ====================

CREATE TABLE IF NOT EXISTS entry_exit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(100) NOT NULL,
    member_category VARCHAR(50),
    entry_date DATE NOT NULL,
    entry_time TIME NOT NULL,
    exit_time TIME,
    purpose VARCHAR(100),
    status ENUM('inside','exited') DEFAULT 'inside',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_admno (admno),
    INDEX idx_entry_date (entry_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== EVENTS ====================

CREATE TABLE IF NOT EXISTS library_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    venue VARCHAR(255),
    max_attendees INT,
    registration_required TINYINT(1) DEFAULT 1,
    status ENUM('upcoming','ongoing','completed','cancelled') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_date (event_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS event_attendees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    member_admno VARCHAR(50) NOT NULL,
    check_in_time DATETIME,
    attended TINYINT(1) DEFAULT 0,
    feedback TEXT,
    FOREIGN KEY (event_id) REFERENCES library_events(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== HOLDS & RESERVATIONS ====================

CREATE TABLE IF NOT EXISTS book_holds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_barcode VARCHAR(50) NOT NULL,
    admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(100) NOT NULL,
    hold_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status ENUM('pending','available','cancelled','expired','picked_up') DEFAULT 'pending',
    notified TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_book (book_barcode),
    INDEX idx_admno (admno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reservations_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_barcode VARCHAR(50) NOT NULL,
    admno VARCHAR(50) NOT NULL,
    member_name VARCHAR(100) NOT NULL,
    priority INT DEFAULT 1,
    requested_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status ENUM('waiting','notified','borrowed','expired','cancelled') DEFAULT 'waiting',
    notified_at DATETIME,
    processed_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_book (book_barcode),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== SERIAL CONTROL ====================

CREATE TABLE IF NOT EXISTS serial_vendors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS serial_subscriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    issn VARCHAR(20),
    frequency ENUM('daily','weekly','biweekly','monthly','bimonthly','quarterly','halfyearly','yearly') NOT NULL,
    vendor_id INT,
    start_date DATE NOT NULL,
    end_date DATE,
    cost DECIMAL(10,2),
    location VARCHAR(100),
    routing_list TEXT,
    notes TEXT,
    status ENUM('active','expired','cancelled') DEFAULT 'active',
    subscription_type ENUM('print','online','both') DEFAULT 'print',
    access_url VARCHAR(255),
    access_credentials TEXT,
    digital_format VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES serial_vendors(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS serial_issues (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT NOT NULL,
    volume VARCHAR(50),
    issue_number VARCHAR(50) NOT NULL,
    date_published DATE,
    date_received DATE,
    status ENUM('expected','received','claimed','missing','late') DEFAULT 'expected',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subscription_id) REFERENCES serial_subscriptions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS serial_reminders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subscription_id INT NOT NULL,
    issue_id INT,
    reminder_type VARCHAR(50) DEFAULT 'missing_issue',
    sent_to VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    message TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subscription_id) REFERENCES serial_subscriptions(id),
    FOREIGN KEY (issue_id) REFERENCES serial_issues(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== COMPUTER ACCESS MANAGEMENT ====================

CREATE TABLE IF NOT EXISTS computers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    computer_name VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45),
    location VARCHAR(100),
    status ENUM('active','maintenance','offline') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS computer_policies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_role VARCHAR(50) NOT NULL UNIQUE,
    max_minutes_per_day INT DEFAULT 60,
    max_minutes_per_week INT DEFAULT 240,
    max_sessions_per_week INT DEFAULT 3,
    require_attendance TINYINT(1) DEFAULT 1,
    weekly_attendance_required INT DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS computer_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    computer_id INT NOT NULL,
    member_id INT NOT NULL,
    login_time DATETIME NOT NULL,
    logout_time DATETIME,
    duration_minutes INT DEFAULT 0,
    FOREIGN KEY (computer_id) REFERENCES computers(id),
    FOREIGN KEY (member_id) REFERENCES members(id),
    INDEX idx_login_time (login_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS computer_attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    week_start_date DATE NOT NULL,
    sessions_count INT DEFAULT 0,
    total_minutes INT DEFAULT 0,
    compliant TINYINT(1) DEFAULT 0,
    UNIQUE KEY uk_member_week (member_id, week_start_date),
    FOREIGN KEY (member_id) REFERENCES members(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== SYSTEM & CONFIGURATION ====================

CREATE TABLE IF NOT EXISTS institutions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT,
    contact VARCHAR(50),
    email VARCHAR(100),
    logo_path VARCHAR(255),
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY CHECK (id = 1),
    loan_days INT DEFAULT 7,
    fine_per_day DECIMAL(10,2) DEFAULT 2.00,
    max_books INT DEFAULT 5,
    menu_position ENUM('top','left') DEFAULT 'top',
    software_header VARCHAR(100) DEFAULT 'Library ERP System',
    library_logo VARCHAR(255),
    favicon_path VARCHAR(255),
    backup_email VARCHAR(100),
    notify_overdue TINYINT(1) DEFAULT 1,
    auto_logout_minutes INT DEFAULT 30,
    new_arrivals_count INT DEFAULT 10,
    enable_sms TINYINT(1) DEFAULT 0,
    sms_api_key VARCHAR(255),
    enable_email TINYINT(1) DEFAULT 1,
    backup_password VARCHAR(255),
    opac_enabled TINYINT(1) DEFAULT 1,
    allow_holds TINYINT(1) DEFAULT 1,
    hold_days INT DEFAULT 7,
    google_drive_enabled TINYINT(1) DEFAULT 0,
    google_drive_folder_id VARCHAR(255),
    google_drive_client_id VARCHAR(255),
    google_drive_client_secret VARCHAR(255),
    google_drive_refresh_token VARCHAR(255),
    smtp_host VARCHAR(255),
    smtp_port INT DEFAULT 587,
    smtp_encryption ENUM('tls','ssl','none') DEFAULT 'tls',
    smtp_username VARCHAR(255),
    smtp_password VARCHAR(255),
    mail_from VARCHAR(255),
    mail_from_name VARCHAR(255),
    backup_schedule ENUM('daily','weekly','monthly','manual') DEFAULT 'daily',
    backup_time TIME DEFAULT '00:00:00',
    current_institution_id INT DEFAULT 1,
    opac_show_new_arrivals TINYINT(1) DEFAULT 1,
    opac_show_popular_ebooks TINYINT(1) DEFAULT 1,
    opac_show_latest_ebooks TINYINT(1) DEFAULT 1,
    opac_show_notices TINYINT(1) DEFAULT 1,
    opac_show_trending TINYINT(1) DEFAULT 1,
    opac_show_databases TINYINT(1) DEFAULT 1,
    opac_header_text VARCHAR(255),
    opac_tagline VARCHAR(255),
    opac_books_per_page INT DEFAULT 12,
    opac_ebooks_per_page INT DEFAULT 8,
    image_base_path VARCHAR(100) DEFAULT 'uploads/',
    enable_whatsapp TINYINT(1) DEFAULT 0,
    whatsapp_api_key VARCHAR(255),
    whatsapp_phone_number VARCHAR(20),
    whatsapp_api_url VARCHAR(255),
    right_logo_path VARCHAR(255),
    opac_notice_title VARCHAR(255),
    opac_notice_content TEXT,
    max_fine_amount DECIMAL(10,2) DEFAULT 0.00,
    enable_self_registration TINYINT(1) DEFAULT 0,
    self_registration_role VARCHAR(50) DEFAULT 'Student',
    email_template_overdue TEXT,
    sms_template_overdue TEXT,
    whatsapp_template_overdue TEXT,
    enable_member_password_reset TINYINT(1) DEFAULT 1,
    reset_token_expiry_hours INT DEFAULT 24,
    allow_member_password_change TINYINT(1) DEFAULT 1,
    cloud_storage_provider ENUM('local','google_drive','dropbox','onedrive') DEFAULT 'local',
    cloud_api_key VARCHAR(255),
    cloud_api_secret VARCHAR(255),
    cloud_refresh_token VARCHAR(255),
    cloud_folder_id VARCHAR(255),
    google_drive_service_account_json TEXT,
    last_export DATETIME,
    currency_code VARCHAR(3) DEFAULT 'INR',
    currency_symbol VARCHAR(5) DEFAULT '₹',
    currency_position ENUM('left','right') DEFAULT 'left',
    opac_header_logo VARCHAR(255),
    login_bg_color VARCHAR(7) DEFAULT '#667eea',
    login_text_color VARCHAR(7) DEFAULT '#ffffff',
    login_header_logo VARCHAR(255),
    login_font_family VARCHAR(50) DEFAULT 'Inter',
    login_base_font_size INT DEFAULT 16,
    staff_display_enabled TINYINT(1) DEFAULT 1,
    staff_card_bg_color VARCHAR(7) DEFAULT '#ffffff',
    currency_decimal_places INT DEFAULT 2,
    guest_enabled TINYINT(1) DEFAULT 1,
    guest_prefix VARCHAR(20) DEFAULT 'GUEST-',
    guest_number_padding INT DEFAULT 4,
    guest_daily_counter INT DEFAULT 1,
    guest_last_reset DATE,
    whatsapp_number VARCHAR(20),
    whatsapp_message TEXT,
    fine_grace_period INT DEFAULT 0,
    fine_calculation_method ENUM('daily','hourly') DEFAULT 'daily',
    auto_waive_fine_after_return TINYINT(1) DEFAULT 0,
    fine_reminder_days INT DEFAULT 3,
    enable_overdue_notifications TINYINT(1) DEFAULT 1,
    library_open_days VARCHAR(50) DEFAULT '1,2,3,4,5',
    library_open_time TIME DEFAULT '09:00:00',
    library_close_time TIME DEFAULT '18:00:00',
    library_lunch_start TIME,
    library_lunch_end TIME,
    library_timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
    container_max_width INT DEFAULT 1600,
    container_padding INT DEFAULT 10,
    opac_font_family VARCHAR(50) DEFAULT 'Inter',
    opac_base_font_size INT DEFAULT 16,
    opac_heading_font_size INT DEFAULT 32,
    opac_primary_color VARCHAR(7) DEFAULT '#1e3c72',
    opac_header_bg_color VARCHAR(7) DEFAULT '#1e3c72',
    opac_body_bg VARCHAR(7) DEFAULT '#f0f2f5',
    opac_custom_css TEXT,
    max_renewals INT DEFAULT 0,
    enable_audit_log TINYINT(1) DEFAULT 1,
    audit_log_retention_days INT DEFAULT 90,
    enable_member_notifications TINYINT(1) DEFAULT 1,
    default_language VARCHAR(2) DEFAULT 'en',
    site_maintenance_mode TINYINT(1) DEFAULT 0,
    maintenance_message TEXT,
    razorpay_key_id VARCHAR(100),
    razorpay_key_secret VARCHAR(100),
    session_check_ip TINYINT(1) DEFAULT 0,
    max_concurrent_sessions INT DEFAULT 5,
    visitor_header_logo VARCHAR(255),
    visitor_header_text VARCHAR(255),
    visitor_tagline VARCHAR(255),
    visitor_header_bg VARCHAR(7) DEFAULT '#1e3c72',
    visitor_body_bg VARCHAR(7) DEFAULT '#f0f2f5',
    visitor_footer_bg VARCHAR(7) DEFAULT '#1e3c72',
    visitor_font_family VARCHAR(50) DEFAULT 'Inter',
    visitor_base_font_size INT DEFAULT 16,
    visitor_primary_color VARCHAR(7) DEFAULT '#28a745',
    report_font_size INT DEFAULT 10,
    report_primary_color VARCHAR(7) DEFAULT '#1e3c72',
    report_logo_position ENUM('left','center','right','both') DEFAULT 'left',
    report_logo_right VARCHAR(255),
    report_watermark_text VARCHAR(255),
    report_watermark_enabled TINYINT(1) DEFAULT 1,
    report_watermark_opacity INT DEFAULT 10,
    report_signature_name VARCHAR(100) DEFAULT 'Librarian',
    report_signature_title VARCHAR(100) DEFAULT 'Chief Librarian',
    report_signature_image VARCHAR(255),
    report_signature_enabled TINYINT(1) DEFAULT 0,
    report_footer_text VARCHAR(255) DEFAULT 'This is a system generated report'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    photo_path VARCHAR(255),
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quick_actions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    icon_class VARCHAR(50) NOT NULL,
    link_url VARCHAR(255) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    icon_class VARCHAR(50) NOT NULL DEFAULT 'fas fa-info-circle',
    link_url VARCHAR(255) NOT NULL DEFAULT '#',
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS module_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    module_key VARCHAR(50) NOT NULL,
    can_access TINYINT(1) DEFAULT 1,
    UNIQUE KEY uk_role_module (role, module_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== ACTIVITY & LOGGING ====================

CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    action VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS session_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('admin','member') NOT NULL,
    username VARCHAR(50) NOT NULL,
    session_id VARCHAR(128),
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    logout_time TIMESTAMP NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    INDEX idx_session_id (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(128) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    fingerprint VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    expires_at DATETIME,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS remember_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS session_audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    session_id VARCHAR(128),
    action VARCHAR(50),
    reason TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    api_key VARCHAR(255),
    endpoint VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_api_key (api_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS export_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    username VARCHAR(50) NOT NULL,
    export_type ENUM('pdf','excel','csv') NOT NULL,
    report_name VARCHAR(255) NOT NULL,
    filters TEXT,
    file_size INT,
    status ENUM('success','failed') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS search_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    keyword VARCHAR(255) NOT NULL,
    book_barcode VARCHAR(50),
    book_title VARCHAR(255),
    search_type VARCHAR(50) DEFAULT 'books',
    user_ip VARCHAR(45),
    user_agent TEXT,
    session_id VARCHAR(128),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_keyword (keyword)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS opac_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_barcode VARCHAR(50) NOT NULL,
    reviewer_name VARCHAR(100) NOT NULL,
    rating INT DEFAULT 5,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== STATISTICS & REPORTS ====================

CREATE TABLE IF NOT EXISTS daily_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stat_date DATE NOT NULL UNIQUE,
    books_issued INT DEFAULT 0,
    books_returned INT DEFAULT 0,
    members_registered INT DEFAULT 0,
    fines_collected DECIMAL(10,2) DEFAULT 0.00,
    entries_count INT DEFAULT 0,
    exits_count INT DEFAULT 0,
    ebook_downloads INT DEFAULT 0,
    new_books_added INT DEFAULT 0,
    active_loans INT DEFAULT 0,
    overdue_count INT DEFAULT 0,
    total_outstanding_fines DECIMAL(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS weekly_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_date DATE NOT NULL,
    week_start DATE NOT NULL,
    week_end DATE NOT NULL,
    report_data JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS monthly_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_month DATE NOT NULL,
    report_data JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS generated_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_type VARCHAR(50) NOT NULL,
    report_date DATE NOT NULL,
    report_data JSON NOT NULL,
    file_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== API & SECURITY ====================

CREATE TABLE IF NOT EXISTS api_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    permissions TEXT NOT NULL COMMENT 'Comma-separated: read,write,admin',
    active TINYINT(1) NOT NULL DEFAULT 1,
    last_used DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active_key (active, api_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== FTS (FULL-TEXT SEARCH) TABLES ====================
-- Note: MySQL uses FULLTEXT indexes, not virtual tables like SQLite FTS5.
-- We create separate tables with FULLTEXT for books, members, circulation.

CREATE TABLE IF NOT EXISTS books_fts (
    id INT NOT NULL PRIMARY KEY,
    title VARCHAR(255),
    author VARCHAR(255),
    subject VARCHAR(255),
    isbn VARCHAR(20),
    publisher VARCHAR(255),
    description TEXT,
    keyword TEXT,
    FULLTEXT INDEX ft_books (title, author, subject, description, keyword)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS members_fts (
    id INT NOT NULL PRIMARY KEY,
    name VARCHAR(100),
    admno VARCHAR(50),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    FULLTEXT INDEX ft_members (name, admno, email, address)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS circulation_fts (
    id INT NOT NULL PRIMARY KEY,
    title VARCHAR(255),
    author VARCHAR(255),
    member_name VARCHAR(100),
    admno VARCHAR(50),
    FULLTEXT INDEX ft_circulation (title, author, member_name, admno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== USER PREFERENCES ====================

CREATE TABLE IF NOT EXISTS user_preferences (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    preference_key VARCHAR(50) NOT NULL,
    preference_value TEXT,
    UNIQUE KEY uk_user_pref (user_id, preference_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MEMBER DOCUMENTS ====================

CREATE TABLE IF NOT EXISTS member_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_admno VARCHAR(50) NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    expiry_date DATE,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified TINYINT(1) DEFAULT 0,
    verified_by VARCHAR(50),
    notes TEXT,
    INDEX idx_member (member_admno)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== STOCK VERIFICATION ====================

CREATE TABLE IF NOT EXISTS stock_verification (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_barcode VARCHAR(50) NOT NULL,
    expected_status VARCHAR(50),
    actual_status VARCHAR(50),
    verified_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== REPORT GENERATION ====================

CREATE TABLE IF NOT EXISTS report_generations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    report_type VARCHAR(50) NOT NULL,
    period_start DATE,
    period_end DATE,
    duration_ms INT,
    rows_generated INT,
    status ENUM('completed','failed') DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== MIGRATION & SCHEMA VERSIONING ====================

CREATE TABLE IF NOT EXISTS migrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    migration_file VARCHAR(255) NOT NULL UNIQUE,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS schema_version (
    version INT PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==================== DEFAULT DATA ====================

INSERT IGNORE INTO institutions (id, name, address, contact, email, status) VALUES 
(1, 'Main Library', '123 Library Street, City', '+1234567890', 'library@example.com', 'active');

-- Default admin user (password = admin123)
INSERT IGNORE INTO users (username, password, fullname, role, token_version) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin', 1),
('staff1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Library Staff', 'staff', 1);

-- Default settings row
INSERT IGNORE INTO settings (id) VALUES (1);

-- Default fine rates
INSERT IGNORE INTO fine_rates (member_category, fine_per_day, max_fine, grace_period_days, is_active) VALUES 
('Student', 2.00, 100.00, 0, 1),
('Staff', 5.00, 0.00, 3, 1),
('Teacher', 5.00, 0.00, 3, 1),
('General', 3.00, 200.00, 0, 1),
('Visitor', 10.00, 500.00, 0, 1);

-- Default quick actions
INSERT IGNORE INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES
('Issue Book', 'fa-arrow-right', 'circulation/issue.php', 1, 1),
('Return Book', 'fa-arrow-left', 'circulation/return.php', 2, 1),
('Renew', 'fa-sync-alt', 'circulation/renew.php', 3, 1),
('Computer Access', 'fa-desktop', 'computer_management/', 4, 1),
('eBooks', 'fa-file-pdf', 'ebooks/', 5, 1),
('Utilities Suite', 'fa-toolbox', 'utilities/', 6, 1),
('Serial Control', 'fa-newspaper', 'serial/', 7, 1),
('Backup & Restore', 'fa-database', 'admin/backup.php', 8, 1),
('Reports', 'fa-chart-bar', 'reports/', 9, 1),
('Settings', 'fa-cog', 'admin/settings.php', 10, 1);

-- Default computer policies
INSERT IGNORE INTO computer_policies (user_role, max_minutes_per_day, max_minutes_per_week, max_sessions_per_week, require_attendance, weekly_attendance_required) VALUES
('student', 60, 240, 3, 1, 1),
('teacher', 120, 480, 10, 0, 0),
('staff', 90, 360, 5, 1, 1),
('visitor', 30, 120, 2, 0, 0);

-- Default staff profiles
INSERT IGNORE INTO staff_profiles (name, designation, sort_order, is_active) VALUES
('Librarian', 'Head Librarian', 1, 1),
('Assistant Librarian', 'Staff', 2, 1);

-- Default research databases
INSERT IGNORE INTO research_databases (name, description, url, category, type, icon, is_featured, sort_order) VALUES 
('JSTOR', 'Digital library of academic journals, books, and primary sources', 'https://www.jstor.org/', 'Academic', 'academic', 'university', 1, 1),
('Google Scholar', 'Free academic search engine', 'https://scholar.google.com/', 'Academic', 'open_access', 'graduation-cap', 1, 2),
('PubMed', 'Biomedical literature database', 'https://pubmed.ncbi.nlm.nih.gov/', 'Medical', 'open_access', 'heartbeat', 1, 3),
('DOAJ', 'Directory of Open Access Journals', 'https://doaj.org/', 'Academic', 'open_access', 'lock-open', 1, 4),
('IEEE Xplore', 'Technical literature in electrical engineering', 'https://ieeexplore.ieee.org/', 'Engineering', 'subscription', 'microchip', 1, 5),
('ScienceDirect', 'Scientific and medical research', 'https://www.sciencedirect.com/', 'Science', 'subscription', 'flask', 1, 6),
('SpringerLink', 'Scientific documents and journals', 'https://link.springer.com/', 'Academic', 'subscription', 'book', 1, 7),
('ERIC', 'Education research database', 'https://eric.ed.gov/', 'Education', 'open_access', 'chalkboard-user', 1, 8);

-- Default email templates
INSERT IGNORE INTO email_templates (template_key, subject, body) VALUES
('overdue', 'Overdue Book Notice', '<p>Dear {member_name},</p><p>The book "{book_title}" is overdue by {days_overdue} days. Fine accrued: {fine_amount}.</p><p>Please return it soon.</p>'),
('hold_ready', 'Hold Available for Pickup', '<p>Dear {member_name},</p><p>The book "{book_title}" is now available for you at the library. Please collect it by {expiry_date}.</p>'),
('membership_expiry', 'Membership Expiry Reminder', '<p>Dear {member_name},</p><p>Your library membership expires on {expiry_date}. Renew now to continue borrowing.</p>');

-- Default API key (development only – change in production)
INSERT IGNORE INTO api_keys (api_key, name, permissions, active) VALUES
('lib-api-key-2024-secure', 'Default API Key', 'read,write', 1);

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;