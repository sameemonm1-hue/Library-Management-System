<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$action = $_GET['action'] ?? 'list';
$editInstitution = null;

if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM institutions WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editInstitution = $stmt->fetch();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token. Please refresh and try again.", "danger");
        header("Location: index.php");
        exit;
    }

    try {
        $logoPath = '';
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logoPath = uploadFile($_FILES['logo'], LOGO_DIR, 'inst_logo');
        }
        
        if (isset($_POST['update_institution'])) {
            $sql = "UPDATE institutions SET name = ?, address = ?, contact = ?, email = ?, status = ?";
            $params = [$_POST['name'], $_POST['address'], $_POST['contact'], $_POST['email'], $_POST['status']];
            
            if ($logoPath) {
                $sql .= ", logo_path = ?";
                $params[] = $logoPath;
                // Delete old logo
                if ($editInstitution && $editInstitution['logo_path'] && file_exists($editInstitution['logo_path'])) {
                    unlink($editInstitution['logo_path']);
                }
            }
            
            $sql .= " WHERE id = ?";
            $params[] = $_POST['id'];
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            showToast("Institution updated successfully", "success");
            // Regenerate CSRF token after successful action
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } elseif (isset($_POST['add_institution'])) {
            $stmt = $db->prepare("INSERT INTO institutions (name, address, contact, email, logo_path, status) VALUES (?, ?, ?, ?, ?, 'active')");
            $stmt->execute([$_POST['name'], $_POST['address'], $_POST['contact'], $_POST['email'], $logoPath]);
            showToast("Institution added successfully", "success");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        
        header("Location: index.php");
        exit;
        
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// Handle delete (with CSRF token check)
if (isset($_GET['delete'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: index.php");
        exit;
    }
    $stmt = $db->prepare("DELETE FROM institutions WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    showToast("Institution deleted", "success");
    header("Location: index.php");
    exit;
}

// Handle set active institution
if (isset($_GET['set_active'])) {
    $db->prepare("UPDATE settings SET current_institution_id = ? WHERE id = 1")->execute([$_GET['set_active']]);
    showToast("Active institution changed", "success");
    header("Location: index.php");
    exit;
}

$institutions = $db->query("SELECT * FROM institutions ORDER BY name")->fetchAll();
$currentInstitutionId = $settings['current_institution_id'] ?? 1;

renderHeader('Institution Management');
?>

<div class="container-fluid px-4">
<div class="d-flex justify-content-between align-items-center mt-3 mb-4">
    <h2><i class="fas fa-building"></i> Institution Management</h2>
    <div>
        <a href="../index.php" class="btn btn-primary">
            <i class="fas fa-home"></i> Back to Home
        </a>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addInstitutionModal">
            <i class="fas fa-plus"></i> Add Institution
        </button>
    </div>
</div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-list"></i> Registered Institutions
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Logo</th><th>Name</th><th>Address</th><th>Contact</th><th>Email</th>
                                    <th>Status</th><th>Active</th><th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($institutions as $inst): ?>
                                <tr class="<?= $inst['id'] == $currentInstitutionId ? 'table-success' : '' ?>">
                                    <td>
                                        <?php if ($inst['logo_path'] && file_exists($inst['logo_path'])): ?>
                                            <img src="<?= htmlspecialchars($inst['logo_path']) ?>" style="height: 40px; width: auto;">
                                        <?php else: ?>
                                            <i class="fas fa-building fa-2x text-muted"></i>
                                        <?php endif; ?>
                                     </div>
                                    <td><?= htmlspecialchars($inst['name']) ?> </div>
                                    <td><?= htmlspecialchars($inst['address'] ?? '-') ?> </div>
                                    <td><?= htmlspecialchars($inst['contact'] ?? '-') ?> </div>
                                    <td><?= htmlspecialchars($inst['email'] ?? '-') ?> </div>
                                    <td>
                                        <span class="badge <?= $inst['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>">
                                            <?= $inst['status'] ?>
                                        </span>
                                     </div>
                                    <td>
                                        <?php if ($inst['id'] == $currentInstitutionId): ?>
                                            <span class="badge bg-primary"><i class="fas fa-check"></i> Current</span>
                                        <?php else: ?>
                                            <a href="?set_active=<?= $inst['id'] ?>" class="btn btn-sm btn-outline-primary">Set Active</a>
                                        <?php endif; ?>
                                     </div>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <a href="?edit=<?= $inst['id'] ?>" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                            <a href="?delete=<?= $inst['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-danger" onclick="return confirm('Delete this institution?')"><i class="fas fa-trash"></i></a>
                                        </div>
                                     </div>
                                 </tr>
                                <?php endforeach; ?>
                            </tbody>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Institution Modal -->
<div class="modal fade" id="addInstitutionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Institution</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Institution Name *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Contact Number</label>
                        <input type="text" name="contact" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label>Logo</label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_institution" class="btn btn-primary">Add Institution</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($editInstitution): ?>
<!-- Edit Institution Modal -->
<div class="modal fade show" id="editInstitutionModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Institution</h5>
                <a href="index.php" class="btn-close"></a>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $editInstitution['id'] ?>">
                    <div class="mb-3">
                        <label>Institution Name *</label>
                        <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editInstitution['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label>Address</label>
                        <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($editInstitution['address'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label>Contact Number</label>
                        <input type="text" name="contact" class="form-control" value="<?= htmlspecialchars($editInstitution['contact'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editInstitution['email'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label>Status</label>
                        <select name="status" class="form-select">
                            <option value="active" <?= ($editInstitution['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= ($editInstitution['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Logo (leave empty to keep current)</label>
                        <input type="file" name="logo" class="form-control" accept="image/*">
                        <?php if ($editInstitution['logo_path'] && file_exists($editInstitution['logo_path'])): ?>
                            <div class="mt-2">
                                <img src="<?= htmlspecialchars($editInstitution['logo_path']) ?>" style="height: 50px;">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="index.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" name="update_institution" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>