#!/usr/bin/env php
<?php
/**
 * CLI Import Circulation Data
 * Usage: php cli_import_circulation.php /path/to/circulation.csv
 */

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

if ($argc < 2) {
    echo "Usage: php cli_import_circulation.php <csv_file>\n";
    exit(1);
}

$csvFile = $argv[1];
if (!file_exists($csvFile)) {
    echo "Error: File not found: $csvFile\n";
    exit(1);
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/functions.php';

$db = getDB();
$handle = fopen($csvFile, 'r');
if (!$handle) {
    echo "Error: Cannot read file.\n";
    exit(1);
}

// Read headers
$headers = fgetcsv($handle);
if (!$headers) {
    echo "Error: Empty CSV.\n";
    exit(1);
}

$headers = array_map(function($h) {
    return strtolower(trim(str_replace(' ', '_', $h)));
}, $headers);

$required = ['admno', 'barcode', 'issue_date', 'due_date'];
$missing = array_diff($required, $headers);
if (!empty($missing)) {
    echo "Error: Missing columns: " . implode(', ', $missing) . "\n";
    exit(1);
}

$idx_admno = array_search('admno', $headers);
$idx_barcode = array_search('barcode', $headers);
$idx_issue = array_search('issue_date', $headers);
$idx_due = array_search('due_date', $headers);
$idx_return = array_search('return_date', $headers);
$idx_fine = array_search('fine', $headers);
$idx_notes = array_search('notes', $headers);

$imported = 0;
$skipped = 0;
$errors = [];

$db->beginTransaction();
try {
    $rowNum = 1;
    while (($row = fgetcsv($handle)) !== false) {
        $rowNum++;
        $admno = trim($row[$idx_admno] ?? '');
        $barcode = trim($row[$idx_barcode] ?? '');
        $issue_date = trim($row[$idx_issue] ?? '');
        $due_date = trim($row[$idx_due] ?? '');
        $return_date = ($idx_return !== false && !empty($row[$idx_return])) ? trim($row[$idx_return]) : null;
        $fine = ($idx_fine !== false && !empty($row[$idx_fine])) ? (float)$row[$idx_fine] : 0;
        $notes = ($idx_notes !== false) ? trim($row[$idx_notes]) : '';
        
        if (empty($admno) || empty($barcode) || empty($issue_date) || empty($due_date)) {
            $errors[] = "Row $rowNum: Missing required field";
            $skipped++;
            continue;
        }
        
        // Validate dates
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $issue_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)) {
            $errors[] = "Row $rowNum: Invalid date format (use YYYY-MM-DD)";
            $skipped++;
            continue;
        }
        if ($return_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $return_date)) {
            $errors[] = "Row $rowNum: Invalid return_date format";
            $skipped++;
            continue;
        }
        
        // Member exists?
        $member = $db->prepare("SELECT name, member_category FROM members WHERE admno = ? AND status = 'active'");
        $member->execute([$admno]);
        $memberData = $member->fetch();
        if (!$memberData) {
            $errors[] = "Row $rowNum: Member '$admno' not found or inactive";
            $skipped++;
            continue;
        }
        
        // Book exists?
        $book = $db->prepare("SELECT title, author, category, available FROM books WHERE barcode = ?");
        $book->execute([$barcode]);
        $bookData = $book->fetch();
        if (!$bookData) {
            $errors[] = "Row $rowNum: Book '$barcode' not found";
            $skipped++;
            continue;
        }
        
        if ($return_date && $fine == 0) {
            $fine = calculateFine($due_date, $memberData['member_category']);
        }
        
        // Insert
        $stmt = $db->prepare("INSERT INTO circulation 
            (admno, member_name, barcode, title, author, category, issue_date, due_date, return_date, fine, notes, is_manual, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, datetime('now'))");
        $stmt->execute([
            $admno, $memberData['name'], $barcode,
            $bookData['title'], $bookData['author'] ?? '', $bookData['category'] ?? '',
            $issue_date, $due_date, $return_date, $fine, $notes
        ]);
        
        // Update counts
        if ($return_date) {
            $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
            $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $admno]);
        } else {
            $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$barcode]);
            $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$admno]);
        }
        
        $imported++;
        if ($imported % 100 == 0) echo "Imported $imported records...\n";
    }
    $db->commit();
    echo "Import completed: $imported records, $skipped skipped.\n";
    if (!empty($errors)) {
        echo "Errors (first 20):\n" . implode("\n", array_slice($errors, 0, 20)) . "\n";
    }
} catch (PDOException $e) {
    $db->rollBack();
    echo "Database error: " . $e->getMessage() . "\n";
    exit(1);
}

fclose($handle);