/**
 * Library ERP - Mobile Responsive Functions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Sidebar toggle for mobile
    initSidebarToggle();
    
    // Responsive tables
    initResponsiveTables();
    
    // Touch-friendly enhancements
    initTouchEnhancements();
    
    // Loading spinner
    initPageLoader();
    
    // Toast notifications
    initToasts();
});

function initSidebarToggle() {
    const sidebar = document.querySelector('.staff-sidebar');
    const main = document.querySelector('.staff-main');
    
    if (!sidebar) return;
    
    // Create toggle button
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'menu-toggle';
    toggleBtn.innerHTML = '<i class="fas fa-bars"></i>';
    toggleBtn.setAttribute('aria-label', 'Toggle Menu');
    document.body.insertBefore(toggleBtn, document.body.firstChild);
    
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    document.body.appendChild(overlay);
    
    toggleBtn.addEventListener('click', function() {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
        document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : '';
    });
    
    overlay.addEventListener('click', function() {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    });
    
    // Close sidebar on window resize if desktop
    window.addEventListener('resize', function() {
        if (window.innerWidth > 992) {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}

function initResponsiveTables() {
    const tables = document.querySelectorAll('.table-responsive table');
    
    tables.forEach(table => {
        const wrapper = table.closest('.table-responsive');
        if (wrapper && !wrapper.classList.contains('table-responsive-wrapper')) {
            wrapper.classList.add('table-responsive-wrapper');
        }
        
        // Add data-label attributes for mobile card view
        if (window.innerWidth <= 768) {
            const headers = table.querySelectorAll('thead th');
            const rows = table.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                cells.forEach((cell, index) => {
                    if (headers[index]) {
                        cell.setAttribute('data-label', headers[index].innerText);
                    }
                });
            });
            
            table.classList.add('table-card-mobile');
        }
    });
}

function initTouchEnhancements() {
    // Add active state for touch
    const touchElements = document.querySelectorAll('.btn, .nav-link, .quick-card, .book-card');
    
    touchElements.forEach(el => {
        el.addEventListener('touchstart', function() {
            this.classList.add('touch-active');
        }, { passive: true });
        
        el.addEventListener('touchend', function() {
            this.classList.remove('touch-active');
        });
    });
}

function initPageLoader() {
    // Create loader
    const loader = document.createElement('div');
    loader.className = 'page-loader';
    loader.innerHTML = '<div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>';
    document.body.appendChild(loader);
    
    // Hide loader when page loads
    window.addEventListener('load', function() {
        setTimeout(() => {
            loader.classList.add('hide');
            setTimeout(() => loader.remove(), 300);
        }, 500);
    });
}

function initToasts() {
    // Convert alerts to toasts on mobile
    if (window.innerWidth <= 768) {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            const message = alert.innerText;
            const type = alert.classList.contains('alert-success') ? 'success' : 
                        (alert.classList.contains('alert-danger') ? 'danger' : 
                        (alert.classList.contains('alert-warning') ? 'warning' : 'info'));
            showToast(message, type);
            alert.remove();
        });
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast-notification alert alert-${type}`;
    toast.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-grow-1">${message}</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// Fix for iOS input zoom
if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.style.fontSize = '16px';
        });
    });
}