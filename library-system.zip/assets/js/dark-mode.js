/**
 * Dark Mode Toggle – saves preference in localStorage
 */
(function() {
    const darkMode = localStorage.getItem('dark-mode') === 'true';
    if (darkMode) {
        document.body.classList.add('dark-mode');
    }

    // Create toggle button (if not already present)
    const toggleBtn = document.getElementById('darkModeToggle');
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('dark-mode', document.body.classList.contains('dark-mode'));
        });
    } else {
        // You can also auto-create a button in the sidebar or navbar
        console.log('Dark mode toggle button not found. Add <button id="darkModeToggle">🌓 Dark Mode</button> somewhere.');
    }
})();