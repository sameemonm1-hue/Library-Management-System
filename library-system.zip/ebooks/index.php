<?php
/**
 * eBook Management Module - Advanced Edition
 * Version: 4.1 - Unified Gradient Cards & Enhanced UI
 * 
 * NEW FEATURES:
 * - Unified gradient cards matching library events module
 * - Consistent color scheme across all cards
 * - Enhanced visual hierarchy
 * - Improved responsive design
 * - Modern glass-morphism effects
 * - Multiple eBook formats (PDF, EPUB, MOBI, DOC, DOCX, TXT)
 * - Advanced metadata fetching with multiple sources
 * - Series and collection support
 * - Tags and categories
 * - Advanced statistics dashboard
 * - Bulk operations (delete, feature, activate/deactivate)
 * - Export to CSV
 * - Reading progress tracking
 * - User ratings
 * - Advanced search with filters
 * - Cloud storage enhanced
 * - Quick actions bar
 * - View counter
 * - Featured eBooks
 * - Access levels (public, registered, staff, admin)
 * - File format badges with icons
 * - Improved UI with better responsiveness
 * - Keyboard shortcuts
 * - Batch import enhancements
 */

session_start();
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// Ensure upload directories exist
if (!defined('EBOOK_DIR')) {
    define('EBOOK_DIR', __DIR__ . '/../uploads/ebooks/');
}
if (!defined('EBOOK_COVER_DIR')) {
    define('EBOOK_COVER_DIR', __DIR__ . '/../uploads/ebook_covers/');
}
if (!defined('EBOOK_COVER_URL')) {
    define('EBOOK_COVER_URL', 'uploads/ebook_covers/');
}

// Create directories if they don't exist
foreach ([EBOOK_DIR, EBOOK_COVER_DIR] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}

// ========== ENSURE TABLE STRUCTURE ==========
try {
    $columns = $db->query("PRAGMA table_info(ebooks)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $required = [
        'isbn', 'cover_path', 'publisher', 'year', 'description', 'file_size', 
        'cloud_file_id', 'storage_type', 'full_text', 'language', 'pages', 'edition',
        'format', 'series', 'series_number', 'tags', 'rating_avg', 'rating_count',
        'views', 'reading_progress', 'is_featured', 'is_active', 'access_level',
        'uploaded_by', 'last_accessed', 'metadata_source', 'doi', 'oclc_number',
        'license_type', 'copyright_year', 'keywords', 'table_of_contents', 'isbn10', 'isbn13'
    ];
    foreach ($required as $col) {
        if (!in_array($col, $columns)) {
            $db->exec("ALTER TABLE ebooks ADD COLUMN $col TEXT DEFAULT ''");
        }
    }
} catch (PDOException $e) {
    $db->exec("CREATE TABLE IF NOT EXISTS ebooks(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT,
        subject TEXT,
        isbn TEXT,
        isbn10 TEXT DEFAULT '',
        isbn13 TEXT DEFAULT '',
        publisher TEXT,
        year TEXT,
        description TEXT,
        cover_path TEXT,
        file_path TEXT NOT NULL,
        file_size INTEGER,
        downloads INTEGER DEFAULT 0,
        cloud_file_id TEXT DEFAULT '',
        storage_type TEXT DEFAULT 'local',
        full_text TEXT,
        language TEXT DEFAULT '',
        pages INTEGER DEFAULT 0,
        edition TEXT DEFAULT '',
        format TEXT DEFAULT 'pdf',
        series TEXT DEFAULT '',
        series_number INTEGER DEFAULT 0,
        tags TEXT DEFAULT '',
        rating_avg REAL DEFAULT 0,
        rating_count INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        reading_progress INTEGER DEFAULT 0,
        is_featured INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        access_level TEXT DEFAULT 'public',
        uploaded_by INTEGER,
        last_accessed DATETIME,
        metadata_source TEXT DEFAULT '',
        doi TEXT DEFAULT '',
        oclc_number TEXT DEFAULT '',
        license_type TEXT DEFAULT '',
        copyright_year TEXT DEFAULT '',
        keywords TEXT DEFAULT '',
        table_of_contents TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// ========== FTS5 VIRTUAL TABLE ==========
try {
    $db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS ebooks_fts USING fts5(
        title, author, subject, isbn, publisher, description, keywords,
        content=ebooks, content_rowid=id, tokenize='porter unicode61'
    )");

    $db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_ai AFTER INSERT ON ebooks BEGIN
        INSERT INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description, keywords)
        VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keywords);
    END");

    $db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_ad AFTER DELETE ON ebooks BEGIN
        DELETE FROM ebooks_fts WHERE rowid = old.id;
    END");

    $db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_au AFTER UPDATE ON ebooks BEGIN
        DELETE FROM ebooks_fts WHERE rowid = old.id;
        INSERT INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description, keywords)
        VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keywords);
    END");

    // Populate FTS if empty
    $count = $db->query("SELECT COUNT(*) FROM ebooks_fts")->fetchColumn();
    if ($count == 0) {
        $db->exec("INSERT OR REPLACE INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description, keywords)
                   SELECT id, title, author, subject, isbn, publisher, description, keywords FROM ebooks");
    }
} catch (PDOException $e) {
    // FTS might not be supported
}

// ========== HELPER FUNCTIONS ==========

/**
 * Get eBook cover image as base64 or URL
 */
function getEbookCover($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) {
        return $coverPath;
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (file_exists($fullPath)) {
        $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
        $data = @file_get_contents($fullPath);
        if ($data !== false && in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $mime = mime_content_type($fullPath) ?: 'image/' . $ext;
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
        return getWebImageUrl($coverPath);
    }
    return '';
}

/**
 * Get eBook cover base64 for direct embedding
 */
function getEbookCoverBase64($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) {
        return '';
    }
    $data = @file_get_contents($fullPath);
    if ($data === false) {
        return '';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

/**
 * Extract text from PDF
 */
function extractTextFromPDF($filePath) {
    if (function_exists('exec') && !ini_get('safe_mode')) {
        $output = tempnam(sys_get_temp_dir(), 'pdftext');
        @exec('pdftotext -layout "' . escapeshellarg($filePath) . '" "' . escapeshellarg($output) . '" 2>/dev/null');
        if (file_exists($output)) {
            $text = file_get_contents($output);
            @unlink($output);
            return trim($text);
        }
    }
    return '';
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}

/**
 * Download a file from a URL and save it locally
 */
function downloadFromUrl($url, $targetPath) {
    $ctx = stream_context_create([
        'http' => [
            'timeout' => 60,
            'ignore_errors' => true,
            'follow_location' => 1,
            'max_redirects' => 10,
        ],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
    ]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false) {
        return false;
    }
    if (file_put_contents($targetPath, $data) === false) {
        return false;
    }
    return true;
}

/**
 * Get file extension from URL or filename
 */
function getExtensionFromUrl($url) {
    $path = parse_url($url, PHP_URL_PATH);
    if ($path) {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (in_array($ext, ['pdf', 'epub', 'mobi', 'doc', 'docx', 'txt'])) {
            return $ext;
        }
    }
    $headers = @get_headers($url, 1);
    if ($headers && isset($headers['Content-Type'])) {
        $ctype = is_array($headers['Content-Type']) ? $headers['Content-Type'][0] : $headers['Content-Type'];
        if (strpos($ctype, 'pdf') !== false) return 'pdf';
        if (strpos($ctype, 'epub') !== false) return 'epub';
        if (strpos($ctype, 'mobi') !== false) return 'mobi';
        if (strpos($ctype, 'word') !== false || strpos($ctype, 'doc') !== false) {
            if (strpos($ctype, 'docx') !== false) return 'docx';
            return 'doc';
        }
        if (strpos($ctype, 'text') !== false) return 'txt';
    }
    return 'pdf';
}

/**
 * Get file icon by format
 */
function getFileIcon($format) {
    $icons = [
        'pdf' => 'fa-file-pdf',
        'epub' => 'fa-file-book',
        'mobi' => 'fa-file-mobi',
        'doc' => 'fa-file-word',
        'docx' => 'fa-file-word',
        'txt' => 'fa-file-alt',
        'default' => 'fa-file'
    ];
    return $icons[$format] ?? $icons['default'];
}

/**
 * Get color by format
 */
function getFormatColor($format) {
    $colors = [
        'pdf' => 'danger',
        'epub' => 'primary',
        'mobi' => 'secondary',
        'doc' => 'info',
        'docx' => 'info',
        'txt' => 'warning',
        'default' => 'secondary'
    ];
    return $colors[$format] ?? $colors['default'];
}

/**
 * Enhanced metadata fetch with multiple sources
 */
function fetchEnhancedBookMetadata($isbn) {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return null;
    
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $result = [];
    
    // Try Google Books
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $result = [
                'title' => $info['title'] ?? '',
                'author' => isset($info['authors']) ? implode(', ', $info['authors']) : '',
                'publisher' => $info['publisher'] ?? '',
                'year' => substr($info['publishedDate'] ?? '', 0, 4),
                'pages' => $info['pageCount'] ?? 0,
                'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
                'summary' => $info['description'] ?? '',
                'subject' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'language' => strtoupper($info['language'] ?? ''),
                'edition' => $info['edition'] ?? '',
                'subtitle' => $info['subtitle'] ?? '',
                'series' => $info['series'] ?? '',
                'isbn10' => $info['industryIdentifiers'][0]['identifier'] ?? '',
                'isbn13' => $info['industryIdentifiers'][1]['identifier'] ?? '',
                'source' => 'Google Books'
            ];
            return $result;
        }
    }
    
    // Try OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $resp2 = @file_get_contents($url2, false, $ctx);
    if ($resp2) {
        $data2 = json_decode($resp2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $result = [
                'title' => $book['title'] ?? '',
                'author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                'publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                'year' => $book['publish_date'] ?? '',
                'pages' => $book['number_of_pages'] ?? 0,
                'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'summary' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''),
                'subject' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : '',
                'language' => isset($book['languages'][0]['name']) ? $book['languages'][0]['name'] : '',
                'source' => 'OpenLibrary'
            ];
            return $result;
        }
    }
    
    return null;
}

// ========== AJAX HANDLERS ==========

// Fetch metadata from single source
if (isset($_GET['ajax_fetch_metadata'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    
    $result = fetchEnhancedBookMetadata($isbn);
    if ($result) {
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No metadata found']);
    }
    exit;
}

// Fetch all sources
if (isset($_GET['ajax_fetch_all_sources'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
    $results = [];
    
    // Google Books
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $resp = @file_get_contents($url, false, $ctx);
    if ($resp) {
        $data = json_decode($resp, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $results[] = [
                'source_display' => 'Google Books',
                'title' => $info['title'] ?? '',
                'author' => isset($info['authors'][0]) ? $info['authors'][0] : '',
                'publisher' => $info['publisher'] ?? '',
                'year' => substr($info['publishedDate'] ?? '', 0, 4),
                'pages' => $info['pageCount'] ?? 0,
                'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
                'summary' => $info['description'] ?? '',
                'subject' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'language' => strtoupper($info['language'] ?? '')
            ];
        }
    }
    
    // OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $resp2 = @file_get_contents($url2, false, $ctx);
    if ($resp2) {
        $data2 = json_decode($resp2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $results[] = [
                'source_display' => 'OpenLibrary',
                'title' => $book['title'] ?? '',
                'author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                'publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                'year' => $book['publish_date'] ?? '',
                'pages' => $book['number_of_pages'] ?? 0,
                'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'summary' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''),
                'subject' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : ''
            ];
        }
    }
    
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

// ========== EXPORT CSV HANDLER ==========
if (isset($_GET['export_csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=ebooks_' . date('Y-m-d') . '.csv');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = [
        'ID', 'Title', 'Author', 'Subject', 'ISBN', 'ISBN10', 'ISBN13',
        'Publisher', 'Year', 'Pages', 'Language', 'Edition', 'Format',
        'Series', 'Series Number', 'Tags', 'Downloads', 'Views',
        'Rating', 'Rating Count', 'Description', 'Created At'
    ];
    fputcsv($out, $headers);
    
    $stmt = $db->query("SELECT * FROM ebooks ORDER BY title");
    
    while ($ebook = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($out, [
            $ebook['id'],
            $ebook['title'],
            $ebook['author'] ?? '',
            $ebook['subject'] ?? '',
            $ebook['isbn'] ?? '',
            $ebook['isbn10'] ?? '',
            $ebook['isbn13'] ?? '',
            $ebook['publisher'] ?? '',
            $ebook['year'] ?? '',
            $ebook['pages'] ?? 0,
            $ebook['language'] ?? '',
            $ebook['edition'] ?? '',
            $ebook['format'] ?? 'pdf',
            $ebook['series'] ?? '',
            $ebook['series_number'] ?? 0,
            $ebook['tags'] ?? '',
            $ebook['downloads'] ?? 0,
            $ebook['views'] ?? 0,
            $ebook['rating_avg'] ?? 0,
            $ebook['rating_count'] ?? 0,
            $ebook['description'] ?? '',
            $ebook['created_at'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}

// ========== BULK OPERATIONS ==========

if (isset($_POST['bulk_action']) && isset($_POST['selected_ebooks']) && is_array($_POST['selected_ebooks'])) {
    $selectedIds = array_map('intval', $_POST['selected_ebooks']);
    $action = $_POST['bulk_action'];
    
    if (!empty($selectedIds)) {
        $placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
        
        switch ($action) {
            case 'delete':
                $stmt = $db->prepare("SELECT file_path, cover_path, cloud_file_id, storage_type FROM ebooks WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                $ebooks = $stmt->fetchAll();
                foreach ($ebooks as $ebook) {
                    if ($ebook['file_path'] && file_exists($ebook['file_path'])) @unlink($ebook['file_path']);
                    if ($ebook['cover_path'] && file_exists($ebook['cover_path'])) @unlink($ebook['cover_path']);
                    if (!empty($ebook['cloud_file_id']) && $ebook['storage_type'] !== 'local' && function_exists('deleteFromCloud')) {
                        deleteFromCloud($ebook['cloud_file_id'], $ebook['storage_type']);
                    }
                }
                $stmt = $db->prepare("DELETE FROM ebooks WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                showToast("Deleted " . count($selectedIds) . " eBooks", "success");
                break;
                
            case 'feature':
                $stmt = $db->prepare("UPDATE ebooks SET is_featured = 1 WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                showToast("Featured " . count($selectedIds) . " eBooks", "success");
                break;
                
            case 'unfeature':
                $stmt = $db->prepare("UPDATE ebooks SET is_featured = 0 WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                showToast("Unfeatured " . count($selectedIds) . " eBooks", "success");
                break;
                
            case 'activate':
                $stmt = $db->prepare("UPDATE ebooks SET is_active = 1 WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                showToast("Activated " . count($selectedIds) . " eBooks", "success");
                break;
                
            case 'deactivate':
                $stmt = $db->prepare("UPDATE ebooks SET is_active = 0 WHERE id IN ($placeholders)");
                $stmt->execute($selectedIds);
                showToast("Deactivated " . count($selectedIds) . " eBooks", "success");
                break;
                
            case 'export_csv':
                exportSelectedEbooksCSV($db, $selectedIds);
                exit;
                
            default:
                showToast("Unknown action", "warning");
        }
    }
    header("Location: index.php");
    exit;
}

// ========== EXPORT SELECTED EBOOKS ==========
function exportSelectedEbooksCSV($db, $selectedIds) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=ebooks_export_' . date('Y-m-d') . '.csv');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = ['ID', 'Title', 'Author', 'Subject', 'ISBN', 'Publisher', 'Year', 'Pages', 'Format', 'Downloads', 'Views', 'Rating'];
    fputcsv($out, $headers);
    
    $placeholders = implode(',', array_fill(0, count($selectedIds), '?'));
    $stmt = $db->prepare("SELECT * FROM ebooks WHERE id IN ($placeholders)");
    $stmt->execute($selectedIds);
    
    while ($ebook = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($out, [
            $ebook['id'],
            $ebook['title'],
            $ebook['author'] ?? '',
            $ebook['subject'] ?? '',
            $ebook['isbn'] ?? '',
            $ebook['publisher'] ?? '',
            $ebook['year'] ?? '',
            $ebook['pages'] ?? 0,
            $ebook['format'] ?? 'pdf',
            $ebook['downloads'] ?? 0,
            $ebook['views'] ?? 0,
            $ebook['rating_avg'] ?? 0
        ]);
    }
    fclose($out);
    exit;
}

// ========== CORE CRUD ==========
$editEbook = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editEbook = $stmt->fetch();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $coverPath = $_POST['existing_cover'] ?? '';
        $filePath = $_POST['existing_file'] ?? '';
        $cloudFileId = $_POST['existing_cloud_id'] ?? '';
        $storageType = $_POST['existing_storage_type'] ?? 'local';
        $fileSize = 0;
        $fullText = '';

        // Cover upload
        if (isset($_FILES['ebook_cover']) && $_FILES['ebook_cover']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['ebook_cover']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                throw new Exception("Invalid cover image format. Only JPG, PNG, GIF, WEBP allowed.");
            }
            if ($_FILES['ebook_cover']['size'] > 10 * 1024 * 1024) {
                throw new Exception("Cover image too large. Max 10MB.");
            }
            $filename = 'ebook_cover_' . time() . '_' . uniqid() . '.' . $ext;
            $target = EBOOK_COVER_DIR . $filename;
            if (move_uploaded_file($_FILES['ebook_cover']['tmp_name'], $target)) {
                if ($coverPath && file_exists($coverPath) && strpos($coverPath, 'uploads/ebook_covers/') === 0) {
                    @unlink($coverPath);
                }
                $coverPath = 'uploads/ebook_covers/' . $filename;
            } else {
                throw new Exception("Failed to upload cover image.");
            }
        }

        // Handle eBook URL download
        $ebookUrl = trim($_POST['ebook_url'] ?? '');
        $isUrlUpload = false;
        $tempFile = null;

        if (!empty($ebookUrl) && (!isset($_FILES['ebook_file']) || $_FILES['ebook_file']['error'] !== UPLOAD_ERR_OK)) {
            if (!filter_var($ebookUrl, FILTER_VALIDATE_URL)) {
                throw new Exception("Invalid eBook URL provided.");
            }
            $ext = getExtensionFromUrl($ebookUrl);
            if (!in_array($ext, ['pdf', 'epub', 'mobi', 'doc', 'docx', 'txt'])) {
                throw new Exception("Unsupported file type from URL. Supported: PDF, EPUB, MOBI, DOC, DOCX, TXT");
            }
            $tempFile = tempnam(sys_get_temp_dir(), 'ebook_url_') . '.' . $ext;
            if (!downloadFromUrl($ebookUrl, $tempFile)) {
                throw new Exception("Failed to download file from URL. Please check the link and try again.");
            }
            $_FILES['ebook_file']['tmp_name'] = $tempFile;
            $_FILES['ebook_file']['name'] = basename(parse_url($ebookUrl, PHP_URL_PATH)) ?: 'ebook.' . $ext;
            $_FILES['ebook_file']['size'] = filesize($tempFile);
            $_FILES['ebook_file']['error'] = UPLOAD_ERR_OK;
            $isUrlUpload = true;
        }

        // eBook file upload/processing
        if (isset($_FILES['ebook_file']) && $_FILES['ebook_file']['error'] === UPLOAD_ERR_OK) {
            $tempFile = $_FILES['ebook_file']['tmp_name'];
            $ext = strtolower(pathinfo($_FILES['ebook_file']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['pdf', 'epub', 'mobi', 'doc', 'docx', 'txt'])) {
                throw new Exception("Only PDF, EPUB, MOBI, DOC, DOCX, TXT files are allowed.");
            }
            if ($_FILES['ebook_file']['size'] > 200 * 1024 * 1024) {
                throw new Exception("File too large. Max 200MB.");
            }
            
            $cloudProvider = $settings['cloud_storage_provider'] ?? 'local';
            if ($cloudProvider !== 'local' && function_exists('uploadToCloud')) {
                try {
                    $cloudResult = uploadToCloud($tempFile);
                    if ($cloudResult && isset($cloudResult['file_id'])) {
                        $cloudFileId = $cloudResult['file_id'];
                        $storageType = $cloudProvider;
                        $filePath = '';
                        if (!empty($_POST['existing_cloud_id']) && $_POST['existing_cloud_id'] != $cloudFileId && function_exists('deleteFromCloud')) {
                            deleteFromCloud($_POST['existing_cloud_id'], $_POST['existing_storage_type'] ?? 'local');
                        }
                    } else {
                        throw new Exception("Cloud upload failed");
                    }
                } catch (Exception $e) {
                    error_log("Cloud upload error: " . $e->getMessage());
                    $storageType = 'local';
                    $cloudFileId = '';
                    $targetPath = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                    if (!copy($tempFile, $targetPath)) {
                        throw new Exception("Failed to save file locally.");
                    }
                    $filePath = $targetPath;
                }
            } else {
                $targetPath = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                if (!copy($tempFile, $targetPath)) {
                    throw new Exception("Failed to save file.");
                }
                $filePath = $targetPath;
                $storageType = 'local';
                $cloudFileId = '';
            }
            
            $fileSize = $_FILES['ebook_file']['size'];
            
            // Extract full text if PDF
            if ($ext === 'pdf' && file_exists($filePath)) {
                $fullText = extractTextFromPDF($filePath);
            }

            if ($isUrlUpload && file_exists($tempFile)) {
                @unlink($tempFile);
            }
        }

        // Common fields
        $title = trim($_POST['title']);
        $author = trim($_POST['author'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $isbn = trim($_POST['isbn'] ?? '');
        $publisher = trim($_POST['publisher'] ?? '');
        $year = trim($_POST['year'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $language = trim($_POST['language'] ?? '');
        $pages = (int)($_POST['pages'] ?? 0);
        $edition = trim($_POST['edition'] ?? '');
        $format = trim($_POST['format'] ?? 'pdf');
        $series = trim($_POST['series'] ?? '');
        $series_number = (int)($_POST['series_number'] ?? 0);
        $tags = trim($_POST['tags'] ?? '');
        $access_level = trim($_POST['access_level'] ?? 'public');
        $license_type = trim($_POST['license_type'] ?? '');
        $keywords = trim($_POST['keywords'] ?? '');

        if (isset($_POST['update_ebook'])) {
            // ========== UPDATE EBOOK ==========
            $id = (int)$_POST['id'];
            
            $stmt = $db->prepare("UPDATE ebooks SET 
                title = ?, author = ?, subject = ?, isbn = ?, 
                publisher = ?, year = ?, description = ?, 
                cover_path = ?, file_path = ?, file_size = ?,
                cloud_file_id = ?, storage_type = ?,
                language = ?, pages = ?, edition = ?,
                format = ?, series = ?, series_number = ?,
                tags = ?, access_level = ?, license_type = ?,
                keywords = ?, full_text = ?
                WHERE id = ?");
            $stmt->execute([
                $title, $author, $subject, $isbn,
                $publisher, $year, $description,
                $coverPath, $filePath, $fileSize,
                $cloudFileId, $storageType,
                $language, $pages, $edition,
                $format, $series, $series_number,
                $tags, $access_level, $license_type,
                $keywords, $fullText,
                $id
            ]);
            
            showToast("eBook updated successfully", "success");
            logActivity($_SESSION['username'], 'EBOOK_UPDATE', "Updated eBook: $title");
            header("Location: index.php");
            exit;

        } elseif (isset($_POST['add_ebook'])) {
            // ========== ADD NEW EBOOK ==========
            if (empty($title)) throw new Exception("Title is required");
            if (empty($filePath) && empty($cloudFileId)) {
                throw new Exception("eBook file or URL is required.");
            }
            
            $stmt = $db->prepare("INSERT INTO ebooks (
                title, author, subject, isbn, publisher, year, description,
                cover_path, file_path, file_size, downloads, cloud_file_id, storage_type,
                language, pages, edition, format, series, series_number,
                tags, access_level, license_type, keywords, full_text,
                uploaded_by, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([
                $title, $author, $subject, $isbn,
                $publisher, $year, $description,
                $coverPath, $filePath, $fileSize,
                $cloudFileId, $storageType,
                $language, $pages, $edition,
                $format, $series, $series_number,
                $tags, $access_level, $license_type,
                $keywords, $fullText,
                $_SESSION['user_id']
            ]);
            $newId = $db->lastInsertId();
            
            // Extract full text if PDF
            if ($storageType === 'local' && $filePath && preg_match('/\.pdf$/i', $filePath) && file_exists($filePath)) {
                $fullText = extractTextFromPDF($filePath);
                if ($fullText) {
                    $db->prepare("UPDATE ebooks SET full_text = ? WHERE id = ?")->execute([$fullText, $newId]);
                }
            }
            
            showToast("eBook added successfully", "success");
            logActivity($_SESSION['username'], 'EBOOK_ADD', "Added eBook: $title");
            header("Location: index.php");
            exit;
        }
    } catch (Exception $e) {
        showToast("Error: " . $e->getMessage(), "danger");
        header("Location: index.php");
        exit;
    }
}

// ========== DELETE EBOOK ==========
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("SELECT file_path, cover_path, cloud_file_id, storage_type FROM ebooks WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    $ebook = $stmt->fetch();
    if ($ebook) {
        if ($ebook['file_path'] && file_exists($ebook['file_path'])) {
            @unlink($ebook['file_path']);
        }
        if ($ebook['cover_path'] && file_exists($ebook['cover_path'])) {
            @unlink($ebook['cover_path']);
        }
        if (!empty($ebook['cloud_file_id']) && $ebook['storage_type'] !== 'local' && function_exists('deleteFromCloud')) {
            deleteFromCloud($ebook['cloud_file_id'], $ebook['storage_type']);
        }
    }
    $db->prepare("DELETE FROM ebooks WHERE id = ?")->execute([$_GET['delete']]);
    showToast("eBook deleted successfully", "success");
    header("Location: index.php");
    exit;
}

// ========== BULK IMPORT ==========
if (isset($_POST['bulk_import'])) {
    if (isset($_FILES['bulk_zip']) && $_FILES['bulk_zip']['error'] === UPLOAD_ERR_OK) {
        $zip = new ZipArchive();
        if ($zip->open($_FILES['bulk_zip']['tmp_name']) === true) {
            $imported = 0;
            $failed = 0;
            $tempDir = sys_get_temp_dir() . '/bulk_import_' . uniqid();
            mkdir($tempDir, 0777, true);
            
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = $zip->getNameIndex($i);
                if (substr($filename, -1) == '/') continue;
                
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                if (in_array($ext, ['pdf', 'epub', 'mobi', 'doc', 'docx', 'txt'])) {
                    $tmp = tempnam($tempDir, 'ebook');
                    $contents = $zip->getFromName($filename);
                    if ($contents !== false && file_put_contents($tmp, $contents) !== false) {
                        $title = pathinfo($filename, PATHINFO_FILENAME);
                        $cloudProvider = $settings['cloud_storage_provider'] ?? 'local';
                        $filePath = ''; 
                        $cloudFileId = ''; 
                        $storageType = 'local';
                        
                        if ($cloudProvider !== 'local' && function_exists('uploadToCloud')) {
                            try {
                                $res = uploadToCloud($tmp);
                                if ($res && isset($res['file_id'])) {
                                    $cloudFileId = $res['file_id'];
                                    $storageType = $cloudProvider;
                                } else {
                                    throw new Exception("Cloud failed");
                                }
                            } catch (Exception $e) {
                                $target = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                                if (copy($tmp, $target)) {
                                    $filePath = $target;
                                } else {
                                    $failed++;
                                    continue;
                                }
                            }
                        } else {
                            $target = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                            if (copy($tmp, $target)) {
                                $filePath = $target;
                            } else {
                                $failed++;
                                continue;
                            }
                        }
                        
                        if ($filePath || $cloudFileId) {
                            $stmt = $db->prepare("INSERT INTO ebooks (title, file_path, file_size, cloud_file_id, storage_type, format, created_at) 
                                VALUES (?, ?, ?, ?, ?, ?, datetime('now'))");
                            $stmt->execute([$title, $filePath, filesize($tmp), $cloudFileId, $storageType, $ext]);
                            $imported++;
                        } else {
                            $failed++;
                        }
                        @unlink($tmp);
                    } else {
                        $failed++;
                    }
                }
            }
            $zip->close();
            @rmdir($tempDir);
            showToast("Imported $imported eBooks from ZIP ($failed failed)", $imported > 0 ? 'success' : 'danger');
        } else {
            showToast("Failed to open ZIP file", "danger");
        }
        header("Location: index.php");
        exit;
    }
    
    if (isset($_FILES['bulk_csv']) && $_FILES['bulk_csv']['error'] === UPLOAD_ERR_OK) {
        $handle = fopen($_FILES['bulk_csv']['tmp_name'], 'r');
        if ($handle) {
            $header = fgetcsv($handle);
            $imported = 0;
            $failed = 0;
            while (($row = fgetcsv($handle)) !== false) {
                $data = array_combine($header, $row);
                if (empty($data['title'])) {
                    $failed++;
                    continue;
                }
                try {
                    $stmt = $db->prepare("INSERT INTO ebooks (title, author, subject, isbn, publisher, year, description, file_path, format, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
                    $stmt->execute([
                        $data['title'] ?? '',
                        $data['author'] ?? '',
                        $data['subject'] ?? '',
                        $data['isbn'] ?? '',
                        $data['publisher'] ?? '',
                        $data['year'] ?? '',
                        $data['description'] ?? '',
                        $data['file_path'] ?? '',
                        $data['format'] ?? 'pdf'
                    ]);
                    $imported++;
                } catch (Exception $e) {
                    $failed++;
                }
            }
            fclose($handle);
            showToast("Imported $imported eBooks from CSV ($failed failed)", $imported > 0 ? 'success' : 'danger');
        }
        header("Location: index.php");
        exit;
    }
}

// ========== SEARCH WITH FILTERS ==========
$search = $_GET['search'] ?? '';
$subject_filter = $_GET['subject_filter'] ?? '';
$format_filter = $_GET['format_filter'] ?? '';
$series_filter = $_GET['series_filter'] ?? '';
$is_featured = isset($_GET['is_featured']) && $_GET['is_featured'] == '1' ? 1 : null;
$sort_by = $_GET['sort_by'] ?? 'created_at';
$sort_order = $_GET['sort_order'] ?? 'DESC';

$allowed_sort = ['title', 'author', 'year', 'downloads', 'views', 'rating_avg', 'created_at'];
if (!in_array($sort_by, $allowed_sort)) $sort_by = 'created_at';
$sort_order = strtoupper($sort_order) === 'ASC' ? 'ASC' : 'DESC';

$sql = "SELECT * FROM ebooks WHERE 1=1";
$params = [];

if ($search) {
    $sql .= " AND ebooks_fts MATCH ?";
    $params[] = $search;
} else {
    if ($subject_filter) {
        $sql .= " AND subject = ?";
        $params[] = $subject_filter;
    }
    if ($format_filter) {
        $sql .= " AND format = ?";
        $params[] = $format_filter;
    }
    if ($series_filter) {
        $sql .= " AND series = ?";
        $params[] = $series_filter;
    }
    if ($is_featured !== null) {
        $sql .= " AND is_featured = ?";
        $params[] = $is_featured;
    }
}

$sql .= " ORDER BY $sort_by $sort_order LIMIT 200";

try {
    if ($search) {
        $stmt = $db->prepare("SELECT e.* FROM ebooks e JOIN ebooks_fts f ON e.id = f.rowid WHERE $sql");
        $stmt->execute($params);
    } else {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
    }
    $displayEbooks = $stmt->fetchAll();
} catch (PDOException $e) {
    $displayEbooks = [];
}

// ========== STATISTICS ==========
$totalEbooks = $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn() ?: 0;
$totalDownloads = $db->query("SELECT SUM(downloads) FROM ebooks")->fetchColumn() ?: 0;
$totalStorage = $db->query("SELECT SUM(file_size) FROM ebooks WHERE storage_type = 'local'")->fetchColumn() ?: 0;
$totalViews = $db->query("SELECT SUM(views) FROM ebooks")->fetchColumn() ?: 0;
$featuredCount = $db->query("SELECT COUNT(*) FROM ebooks WHERE is_featured = 1")->fetchColumn() ?: 0;
$totalFormats = $db->query("SELECT COUNT(DISTINCT format) FROM ebooks")->fetchColumn() ?: 0;

// Get distinct subjects, formats, series for filters
$subjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject")->fetchAll(PDO::FETCH_COLUMN) ?: [];
$formats = $db->query("SELECT DISTINCT format FROM ebooks WHERE format IS NOT NULL AND format != '' ORDER BY format")->fetchAll(PDO::FETCH_COLUMN) ?: [];
$seriesList = $db->query("SELECT DISTINCT series FROM ebooks WHERE series IS NOT NULL AND series != '' ORDER BY series")->fetchAll(PDO::FETCH_COLUMN) ?: [];

renderHeader('eBook Management');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eBook Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f6f9; 
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: var(--gradient-primary);
            border-radius: var(--radius-card);
            padding: 20px 20px 20px 70px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
            cursor: default;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }
        
        /* ===== FILTER CARD ===== */
        .filter-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 20px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }
        .filter-card:hover {
            box-shadow: var(--shadow-hover);
        }
        
        /* ===== QUICK ACTIONS BAR ===== */
        .quick-actions-bar {
            background: white;
            border-radius: var(--radius-card);
            padding: 12px 20px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
        }
        .quick-actions-bar:hover {
            box-shadow: var(--shadow-hover);
        }
        
        /* ===== EBOOK COVER STYLES ===== */
        .ebook-cover-thumb {
            width: 60px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        .ebook-cover-thumb:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .ebook-cover-large {
            max-height: 200px;
            width: auto;
            object-fit: contain;
            border-radius: 12px;
            border: 2px solid #e9ecef;
            background: #f8f9fa;
            padding: 10px;
        }
        .default-cover-thumb {
            width: 60px;
            height: 80px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 8px;
            color: white;
            font-size: 1.8rem;
        }
        .default-cover-large {
            width: 150px;
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 12px;
            color: white;
            font-size: 4rem;
        }
        
        /* ===== TABLE STYLES ===== */
        .table-container {
            background: white;
            border-radius: var(--radius-card);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .table-container .table {
            margin-bottom: 0;
        }
        .table-container thead th {
            background: var(--gradient-primary);
            color: white;
            border: none;
            padding: 12px 15px;
            font-weight: 600;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 5;
        }
        .table-container thead th a {
            color: white;
            text-decoration: none;
        }
        .table-container thead th a:hover {
            text-decoration: underline;
        }
        .table-container tbody tr {
            transition: all 0.2s ease;
        }
        .table-container tbody tr:hover {
            background: rgba(30, 60, 114, 0.05);
        }
        .table-container tbody td {
            padding: 10px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
        }
        
        /* ===== BADGE STYLES ===== */
        .badge-status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .format-badge {
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .storage-badge {
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.65rem;
        }
        .storage-local { background: #e9ecef; color: #495057; }
        .storage-cloud { background: #cfe2ff; color: #084298; }
        .download-badge { font-size: 0.8rem; padding: 2px 10px; border-radius: 12px; }
        .featured-badge { background: #ffc107; color: #212529; padding: 2px 8px; border-radius: 10px; font-size: 0.65rem; font-weight: 600; }
        
        /* ===== MODALS - UNIFIED ===== */
        .modal-content {
            border-radius: var(--radius-card);
            border: none;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        }
        .modal-header {
            background: var(--gradient-primary);
            color: white;
            border-radius: var(--radius-card) var(--radius-card) 0 0;
            padding: 20px 25px;
            border: none;
        }
        .modal-header .btn-close {
            filter: brightness(0) invert(1);
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 2px 15px;
        }
        .modal-dialog-scrollable .modal-body {
            max-height: calc(95vh - 130px);
            overflow-y: auto;
            padding: 25px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar {
            width: 6px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        .modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb:hover {
            background: var(--primary-light);
        }
        
        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .ebook-cover-thumb { width: 40px; height: 55px; }
            .default-cover-thumb { width: 40px; height: 55px; font-size: 1.2rem; }
            .quick-actions-bar { flex-direction: column; align-items: stretch; }
            .table-container { overflow-x: auto; }
            .modal-dialog-scrollable .modal-body { max-height: calc(90vh - 120px); padding: 15px; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-value { font-size: 18px; }
            .modal-body { padding: 15px; }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .table-container thead th {
                background: #333 !important;
                color: white !important;
            }
            .quick-actions-bar { display: none !important; }
            .filter-card { display: none !important; }
            .modal { display: none !important; }
        }
        
        /* ===== SELECT2 OVERRIDE ===== */
        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 8px;
            border-color: #ced4da;
        }
        .select2-container--bootstrap-5 .select2-selection:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(30, 60, 114, 0.25);
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- ===== PAGE HEADER ===== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-file-pdf me-2 text-danger"></i> eBook Management</h2>
            <p class="text-muted small">Manage your digital library collection</p>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addEbookModal">
                <i class="fas fa-plus"></i> Add eBook
            </button>
            <button class="btn btn-info text-white btn-sm" data-bs-toggle="modal" data-bs-target="#bulkImportModal">
                <i class="fas fa-upload"></i> Bulk Import
            </button>
            <button class="btn btn-secondary btn-sm" onclick="exportAllEbooks()">
                <i class="fas fa-download"></i> Export
            </button>
        </div>
    </div>

    <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-file-pdf"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalEbooks) ?></div>
                    <div class="stat-label">Total eBooks</div>
                    <div class="stat-sub"><i class="fas fa-book"></i> All titles</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-download"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalDownloads) ?></div>
                    <div class="stat-label">Downloads</div>
                    <div class="stat-sub"><i class="fas fa-arrow-down"></i> Total downloads</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-eye"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalViews) ?></div>
                    <div class="stat-label">Views</div>
                    <div class="stat-sub"><i class="fas fa-arrow-up"></i> Total views</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-star"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($featuredCount) ?></div>
                    <div class="stat-label">Featured</div>
                    <div class="stat-sub"><i class="fas fa-star"></i> Featured titles</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-hdd"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= formatFileSize($totalStorage ?? 0) ?></div>
                    <div class="stat-label">Storage Used</div>
                    <div class="stat-sub"><i class="fas fa-database"></i> Local storage</div>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-chart-line"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= $totalEbooks ? round($totalDownloads/$totalEbooks, 1) : 0 ?></div>
                    <div class="stat-label">Avg Downloads</div>
                    <div class="stat-sub"><i class="fas fa-file"></i> Per eBook</div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== QUICK ACTIONS BAR ===== -->
    <div class="quick-actions-bar no-print">
        <span class="fw-bold me-2" style="color: var(--primary-color);"><i class="fas fa-bolt"></i> Bulk Actions:</span>
        <button class="btn btn-sm btn-outline-primary" onclick="selectAllEbooks()"><i class="fas fa-check-double"></i> Select All</button>
        <button class="btn btn-sm btn-outline-danger" onclick="bulkDelete()"><i class="fas fa-trash"></i> Delete</button>
        <button class="btn btn-sm btn-outline-warning" onclick="bulkFeature()"><i class="fas fa-star"></i> Feature</button>
        <button class="btn btn-sm btn-outline-secondary" onclick="bulkUnfeature()"><i class="fas fa-star-half-alt"></i> Unfeature</button>
        <button class="btn btn-sm btn-outline-success" onclick="bulkActivate()"><i class="fas fa-check"></i> Activate</button>
        <button class="btn btn-sm btn-outline-danger" onclick="bulkDeactivate()"><i class="fas fa-times"></i> Deactivate</button>
        <button class="btn btn-sm btn-outline-info" onclick="bulkExport()"><i class="fas fa-download"></i> Export</button>
        <span class="ms-auto text-muted small" id="selectedCount">0 selected</span>
    </div>

    <!-- ===== FILTER CARD ===== -->
    <div class="filter-card no-print">
        <form method="GET" class="row g-2">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" 
                       placeholder="Search by title, author, subject, ISBN..." 
                       value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <select name="subject_filter" class="form-select select2">
                    <option value="">All Subjects</option>
                    <?php foreach ($subjects as $s): ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= $subject_filter == $s ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <select name="format_filter" class="form-select">
                    <option value="">Format</option>
                    <?php foreach ($formats as $f): ?>
                        <option value="<?= htmlspecialchars($f) ?>" <?= $format_filter == $f ? 'selected' : '' ?>>
                            <?= strtoupper(htmlspecialchars($f)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="series_filter" class="form-select select2">
                    <option value="">All Series</option>
                    <?php foreach ($seriesList as $s): ?>
                        <option value="<?= htmlspecialchars($s) ?>" <?= $series_filter == $s ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <select name="is_featured" class="form-select">
                    <option value="">All</option>
                    <option value="1" <?= $is_featured === 1 ? 'selected' : '' ?>>Featured</option>
                    <option value="0" <?= $is_featured === 0 ? 'selected' : '' ?>>Not Featured</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
            <?php if ($search || $subject_filter || $format_filter || $series_filter || $is_featured !== null): ?>
                <div class="col-12">
                    <a href="index.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-times"></i> Clear Filters
                    </a>
                    <span class="ms-2 text-muted">Found <?= count($displayEbooks) ?> result(s)</span>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <!-- ===== EBOOKS TABLE ===== -->
    <div class="table-container">
        <div class="d-flex flex-wrap justify-content-between align-items-center p-3 bg-white border-bottom">
            <span><i class="fas fa-list text-primary me-1"></i> eBook Collection</span>
            <span class="badge bg-secondary"><?= count($displayEbooks) ?> eBooks</span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" id="selectAllEbooks" onchange="toggleAllEbooks(this)"></th>
                        <th style="width: 60px;">Cover</th>
                        <th>
                            <a href="?<?= http_build_query(array_merge($_GET, ['sort_by'=>'title', 'sort_order'=>($sort_by=='title' && $sort_order=='ASC' ? 'DESC' : 'ASC')])) ?>" class="text-white text-decoration-none">
                                Title/Author <?= $sort_by=='title' ? ($sort_order=='ASC' ? '↑' : '↓') : '' ?>
                            </a>
                        </th>
                        <th>Subject</th>
                        <th>Format</th>
                        <th style="text-align: center;">Downloads</th>
                        <th style="text-align: center;">Views</th>
                        <th style="text-align: center;">Rating</th>
                        <th style="text-align: center;">Featured</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($displayEbooks as $ebook): 
                        $coverBase64 = getEbookCoverBase64($ebook['cover_path'] ?? '');
                        $coverUrl = getEbookCover($ebook['cover_path'] ?? '');
                        $formatColor = getFormatColor($ebook['format'] ?? 'pdf');
                        $fileIcon = getFileIcon($ebook['format'] ?? 'pdf');
                    ?>
                    <tr>
                        <td><input type="checkbox" class="ebook-select" value="<?= $ebook['id'] ?>" onchange="updateSelectedCount()"></td>
                        <td class="text-center">
                            <?php if ($coverBase64): ?>
                                <img src="<?= $coverBase64 ?>" class="ebook-cover-thumb" alt="Cover" 
                                     onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                <div class="default-cover-thumb" style="display:none;">
                                    <i class="fas <?= $fileIcon ?>"></i>
                                </div>
                            <?php elseif ($coverUrl): ?>
                                <img src="<?= $coverUrl ?>" class="ebook-cover-thumb" alt="Cover"
                                     onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                <div class="default-cover-thumb" style="display:none;">
                                    <i class="fas <?= $fileIcon ?>"></i>
                                </div>
                            <?php else: ?>
                                <div class="default-cover-thumb">
                                    <i class="fas <?= $fileIcon ?>"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($ebook['title'] ?? 'Untitled') ?></strong>
                            <br><small class="text-muted">
                                <i class="fas fa-user"></i> <?= htmlspecialchars($ebook['author'] ?? 'Unknown Author') ?>
                                <?php if (!empty($ebook['series'])): ?>
                                    <br><span class="badge bg-secondary"><?= htmlspecialchars($ebook['series']) ?></span>
                                    <?php if (!empty($ebook['series_number'])): ?>
                                        <span class="badge bg-secondary">#<?= $ebook['series_number'] ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if (!empty($ebook['pages']) && $ebook['pages'] > 0): ?>
                                    <span class="badge bg-light text-dark ms-1"><?= $ebook['pages'] ?>p</span>
                                <?php endif; ?>
                            </small>
                            <?php if (!empty($ebook['tags'])): ?>
                                <br><small><?php foreach (explode(',', $ebook['tags']) as $tag): ?>
                                    <span class="badge bg-info text-white"><?= htmlspecialchars(trim($tag)) ?></span>
                                <?php endforeach; ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-warning text-dark">
                                <?= htmlspecialchars($ebook['subject'] ?? 'Uncategorized') ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-<?= $formatColor ?> format-badge">
                                <i class="fas <?= $fileIcon ?>"></i> <?= strtoupper(htmlspecialchars($ebook['format'] ?? 'pdf')) ?>
                            </span>
                            <br><span class="badge storage-<?= ($ebook['storage_type'] ?? 'local') === 'cloud' ? 'cloud' : 'local' ?> storage-badge">
                                <i class="fas fa-<?= ($ebook['storage_type'] ?? 'local') === 'cloud' ? 'cloud' : 'hdd' ?>"></i>
                                <?= ucfirst($ebook['storage_type'] ?? 'local') ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-primary download-badge">
                                <i class="fas fa-download"></i> <?= (int)($ebook['downloads'] ?? 0) ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-secondary download-badge">
                                <i class="fas fa-eye"></i> <?= (int)($ebook['views'] ?? 0) ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <?php if ($ebook['rating_avg'] > 0): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-star"></i> <?= number_format($ebook['rating_avg'], 1) ?>
                                    (<?= $ebook['rating_count'] ?>)
                                </span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if ($ebook['is_featured']): ?>
                                <span class="featured-badge"><i class="fas fa-star"></i> Featured</span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="download.php?id=<?= $ebook['id'] ?>" class="btn btn-success" title="Download">
                                    <i class="fas fa-download"></i>
                                </a>
                                <button onclick="editEbook(<?= $ebook['id'] ?>)" class="btn btn-warning" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="?delete=<?= $ebook['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete this eBook permanently?')" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($displayEbooks)): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                No eBooks found.
                                <br><button class="btn btn-success btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#addEbookModal">
                                    <i class="fas fa-plus"></i> Add your first eBook
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ========== ADD EBOOK MODAL ========== -->
<div class="modal fade" id="addEbookModal" tabindex="-1" aria-labelledby="addEbookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-plus-circle me-2"></i>Add New eBook</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <!-- ISBN & Metadata -->
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-bold">ISBN (Auto-fetch Metadata)</label>
                            <div class="input-group">
                                <input type="text" name="isbn" id="add_isbn" class="form-control" placeholder="Enter ISBN (10 or 13 digits)">
                                <button type="button" class="btn btn-info" onclick="fetchMetadataForAdd()">
                                    <i class="fas fa-globe"></i> Fetch
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="fetchAllSourcesForAdd()">
                                    <i class="fas fa-list"></i> All Sources
                                </button>
                            </div>
                            <div id="addApiStatus" class="small text-muted mt-1"></div>
                        </div>
                    </div>

                    <!-- Basic Information -->
                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-info-circle me-2"></i>Basic Information</h6></div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" id="add_title" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Year</label>
                            <input type="text" name="year" id="add_year" class="form-control" placeholder="e.g., 2024">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" id="add_author" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Publisher</label>
                            <input type="text" name="publisher" id="add_publisher" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" id="add_subject" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Pages</label>
                            <input type="number" name="pages" id="add_pages" class="form-control" min="0">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Language</label>
                            <input type="text" name="language" id="add_language" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Edition</label>
                            <input type="text" name="edition" id="add_edition" class="form-control">
                        </div>
                    </div>

                    <!-- Series & Tags -->
                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-tags me-2"></i>Series & Tags</h6></div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label">Series</label>
                            <input type="text" name="series" id="add_series" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Series #</label>
                            <input type="number" name="series_number" id="add_series_number" class="form-control" min="0">
                        </div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label">Tags (comma separated)</label>
                            <input type="text" name="tags" id="add_tags" class="form-control">
                        </div>
                    </div>

                    <!-- Format & Access -->
                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-cog me-2"></i>Format & Access</h6></div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">File Format</label>
                            <select name="format" id="add_format" class="form-select">
                                <option value="pdf">PDF</option>
                                <option value="epub">EPUB</option>
                                <option value="mobi">MOBI</option>
                                <option value="doc">DOC</option>
                                <option value="docx">DOCX</option>
                                <option value="txt">TXT</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Access Level</label>
                            <select name="access_level" class="form-select">
                                <option value="public">Public</option>
                                <option value="registered">Registered Users</option>
                                <option value="staff">Staff Only</option>
                                <option value="admin">Admin Only</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">License Type</label>
                            <input type="text" name="license_type" class="form-control">
                        </div>
                    </div>

                    <!-- Files -->
                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-upload me-2"></i>Files</h6></div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cover Image</label>
                            <input type="file" name="ebook_cover" class="form-control" accept="image/*" onchange="previewCover(this, 'addCoverPreview')">
                            <small class="text-muted">Max 10MB. JPG, PNG, GIF, WEBP</small>
                        </div>
                        <div class="col-md-6 mb-3 text-center">
                            <div id="addCoverPreview" class="mt-2" style="display:none;">
                                <img id="addPreviewImg" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">eBook URL</label>
                            <input type="url" name="ebook_url" id="add_ebook_url" class="form-control" placeholder="https://example.com/ebook.pdf">
                            <small class="text-muted">Direct link to PDF/EPUB/MOBI/DOC/DOCX/TXT</small>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Or Upload eBook File</label>
                            <input type="file" name="ebook_file" class="form-control" accept=".pdf,.epub,.mobi,.doc,.docx,.txt">
                            <small class="text-muted">Max 200MB</small>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-align-left me-2"></i>Description & Keywords</h6></div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="add_description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Keywords</label>
                            <input type="text" name="keywords" id="add_keywords" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_ebook" class="btn btn-success"><i class="fas fa-save me-1"></i> Add eBook</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== BULK IMPORT MODAL ========== -->
<div class="modal fade" id="bulkImportModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-upload me-2"></i>Bulk Import eBooks</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <h6>Import from ZIP</h6>
                    <p class="small text-muted">Upload ZIP containing PDF/EPUB/MOBI/DOC/DOCX/TXT files.</p>
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="bulk_zip" class="form-control mb-2" accept=".zip" required>
                        <button type="submit" name="bulk_import" class="btn btn-success w-100">
                            <i class="fas fa-upload"></i> Import ZIP
                        </button>
                    </form>
                </div>
                <hr>
                <div>
                    <h6>Import from CSV</h6>
                    <p class="small text-muted">Columns: title,author,subject,isbn,publisher,year,description,file_path,format</p>
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="bulk_csv" class="form-control mb-2" accept=".csv" required>
                        <button type="submit" name="bulk_import" class="btn btn-info text-white w-100">
                            <i class="fas fa-upload"></i> Import CSV
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== EDIT EBOOK MODAL ========== -->
<div class="modal fade" id="editEbookModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit eBook</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <label class="form-label fw-bold">ISBN</label>
                            <div class="input-group">
                                <input type="text" name="isbn" id="edit_isbn" class="form-control">
                                <button type="button" class="btn btn-info" onclick="fetchMetadataForEdit()">
                                    <i class="fas fa-globe"></i> Fetch
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="fetchAllSourcesForEdit()">
                                    <i class="fas fa-list"></i> All Sources
                                </button>
                            </div>
                            <div id="editApiStatus" class="small text-muted mt-1"></div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-info-circle me-2"></i>Basic Information</h6></div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" id="edit_title" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Year</label>
                            <input type="text" name="year" id="edit_year" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" id="edit_author" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Publisher</label>
                            <input type="text" name="publisher" id="edit_publisher" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" id="edit_subject" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Pages</label>
                            <input type="number" name="pages" id="edit_pages" class="form-control" min="0">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Language</label>
                            <input type="text" name="language" id="edit_language" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Edition</label>
                            <input type="text" name="edition" id="edit_edition" class="form-control">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-tags me-2"></i>Series & Tags</h6></div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label">Series</label>
                            <input type="text" name="series" id="edit_series" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Series #</label>
                            <input type="number" name="series_number" id="edit_series_number" class="form-control" min="0">
                        </div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label">Tags</label>
                            <input type="text" name="tags" id="edit_tags" class="form-control">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-cog me-2"></i>Format & Access</h6></div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">File Format</label>
                            <select name="format" id="edit_format" class="form-select">
                                <option value="pdf">PDF</option>
                                <option value="epub">EPUB</option>
                                <option value="mobi">MOBI</option>
                                <option value="doc">DOC</option>
                                <option value="docx">DOCX</option>
                                <option value="txt">TXT</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Access Level</label>
                            <select name="access_level" id="edit_access_level" class="form-select">
                                <option value="public">Public</option>
                                <option value="registered">Registered Users</option>
                                <option value="staff">Staff Only</option>
                                <option value="admin">Admin Only</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">License Type</label>
                            <input type="text" name="license_type" id="edit_license_type" class="form-control">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-upload me-2"></i>Files</h6></div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cover Image</label>
                            <input type="file" name="ebook_cover" class="form-control" accept="image/*" onchange="previewCover(this, 'editCoverPreview')">
                            <small class="text-muted">Upload new cover to replace existing</small>
                        </div>
                        <div class="col-md-6 mb-3 text-center">
                            <?php $editCoverBase64 = getEbookCoverBase64($editEbook['cover_path'] ?? ''); ?>
                            <?php if ($editCoverBase64): ?>
                                <div id="editCurrentCover">
                                    <img src="<?= $editCoverBase64 ?>" class="ebook-cover-large" alt="Current Cover">
                                    <input type="hidden" name="existing_cover" value="<?= htmlspecialchars($editEbook['cover_path'] ?? '') ?>">
                                    <p class="small text-muted mt-1">Current cover</p>
                                </div>
                            <?php endif; ?>
                            <div id="editCoverPreview" class="mt-2" style="display:none;">
                                <img id="editPreviewImg" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px;">
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">eBook URL</label>
                            <input type="url" name="ebook_url" id="edit_ebook_url" class="form-control" placeholder="https://example.com/ebook.pdf">
                            <small class="text-muted">If provided, will download and replace current file</small>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Upload New eBook File</label>
                            <input type="file" name="ebook_file" class="form-control" accept=".pdf,.epub,.mobi,.doc,.docx,.txt">
                            <input type="hidden" name="existing_file" id="edit_existing_file">
                            <input type="hidden" name="existing_cloud_id" id="edit_existing_cloud_id">
                            <input type="hidden" name="existing_storage_type" id="edit_existing_storage_type">
                            <?php if (!empty($editEbook['file_path']) && file_exists($editEbook['file_path'])): ?>
                                <small class="text-muted">Current: <?= basename($editEbook['file_path']) ?> (<?= formatFileSize($editEbook['file_size'] ?? 0) ?>)</small>
                            <?php elseif (!empty($editEbook['cloud_file_id'])): ?>
                                <small class="text-muted">Current: Cloud storage</small>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"><h6 class="border-bottom pb-2 mb-3" style="color: var(--primary-color);"><i class="fas fa-align-left me-2"></i>Description & Keywords</h6></div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Keywords</label>
                            <input type="text" name="keywords" id="edit_keywords" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_ebook" class="btn btn-primary"><i class="fas fa-save me-1"></i> Update eBook</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== METADATA SOURCES MODAL ========== -->
<div class="modal fade" id="metadataModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-list me-2"></i>Metadata Sources</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="metadataResults" style="max-height: 70vh; overflow-y: auto;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() { 
    $('.select2').select2({ theme: 'bootstrap-5', width: '100%', allowClear: true }); 
});

let metadataTarget = 'add';

// ========== SELECT/DESELECT ALL ==========
function toggleAllEbooks(master) {
    document.querySelectorAll('.ebook-select').forEach(cb => cb.checked = master.checked);
    updateSelectedCount();
}

function selectAllEbooks() {
    let checkboxes = document.querySelectorAll('.ebook-select');
    let allChecked = true;
    checkboxes.forEach(cb => { if (!cb.checked) allChecked = false; });
    checkboxes.forEach(cb => cb.checked = !allChecked);
    updateSelectedCount();
}

function updateSelectedCount() {
    let checked = document.querySelectorAll('.ebook-select:checked').length;
    document.getElementById('selectedCount').textContent = checked + ' selected';
}

function getSelectedIds() {
    let ids = [];
    document.querySelectorAll('.ebook-select:checked').forEach(cb => ids.push(cb.value));
    return ids;
}

// ========== BULK ACTIONS ==========
function bulkDelete() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    if (!confirm('Delete ' + ids.length + ' selected eBooks?')) return;
    submitBulkAction('delete');
}

function bulkFeature() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    submitBulkAction('feature');
}

function bulkUnfeature() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    submitBulkAction('unfeature');
}

function bulkActivate() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    submitBulkAction('activate');
}

function bulkDeactivate() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    submitBulkAction('deactivate');
}

function bulkExport() {
    let ids = getSelectedIds();
    if (ids.length === 0) { alert('Please select at least one eBook.'); return; }
    submitBulkAction('export_csv');
}

function submitBulkAction(action) {
    let form = document.createElement('form');
    form.method = 'post';
    let actionInput = document.createElement('input');
    actionInput.type = 'hidden';
    actionInput.name = 'bulk_action';
    actionInput.value = action;
    form.appendChild(actionInput);
    
    document.querySelectorAll('.ebook-select:checked').forEach(cb => {
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ebooks[]';
        input.value = cb.value;
        form.appendChild(input);
    });
    
    document.body.appendChild(form);
    form.submit();
}

// ========== EXPORT ==========
function exportAllEbooks() {
    window.location.href = '?export_csv=1';
}

// ========== FETCH METADATA ==========
function fetchMetadataForAdd() { fetchSingleMetadata('add'); }
function fetchMetadataForEdit() { fetchSingleMetadata('edit'); }

function fetchSingleMetadata(target) {
    let isbn = document.getElementById(target === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    if (!isbn) { alert('Please enter an ISBN first'); return; }
    let statusDiv = document.getElementById(target === 'add' ? 'addApiStatus' : 'editApiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching metadata...';
    
    fetch(`index.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data) {
                let b = data.data;
                let prefix = target === 'add' ? 'add_' : 'edit_';
                
                if (b.title) document.getElementById(prefix + 'title').value = b.title;
                if (b.author) document.getElementById(prefix + 'author').value = b.author;
                if (b.publisher) document.getElementById(prefix + 'publisher').value = b.publisher;
                if (b.year) document.getElementById(prefix + 'year').value = b.year;
                if (b.subject) document.getElementById(prefix + 'subject').value = b.subject;
                if (b.summary) document.getElementById(prefix + 'description').value = b.summary;
                if (b.language) document.getElementById(prefix + 'language').value = b.language;
                if (b.pages) document.getElementById(prefix + 'pages').value = b.pages;
                if (b.edition) document.getElementById(prefix + 'edition').value = b.edition;
                if (b.series) document.getElementById(prefix + 'series').value = b.series;
                
                if (b.cover_url) {
                    let previewDiv = document.getElementById(target === 'add' ? 'addCoverPreview' : 'editCoverPreview');
                    previewDiv.innerHTML = `<img src="${b.cover_url}" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px;">`;
                    previewDiv.style.display = 'block';
                }
                statusDiv.innerHTML = '<span class="text-success">Metadata applied successfully.</span>';
            } else {
                statusDiv.innerHTML = '<span class="text-danger">' + (data.error || 'Not found') + '</span>';
            }
        })
        .catch(err => { 
            statusDiv.innerHTML = '<span class="text-danger">Network error. Please try again.</span>';
            console.error(err);
        });
}

function fetchAllSourcesForAdd() { fetchAllSources('add'); }
function fetchAllSourcesForEdit() { fetchAllSources('edit'); }

function fetchAllSources(target) {
    let isbn = document.getElementById(target === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    if (!isbn) { alert('Please enter an ISBN first'); return; }
    metadataTarget = target;
    
    fetch(`index.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.results && data.results.length) {
                let html = '<div class="row g-3">';
                data.results.forEach((source, index) => {
                    html += `<div class="col-md-6">
                        <div class="card h-100 result-card">
                            <div class="card-header bg-light">
                                <strong><i class="fas fa-${source.source_display === 'Google Books' ? 'google' : 'book'}"></i> ${escapeHtml(source.source_display)}</strong>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title">${escapeHtml(source.title || 'No title')}</h6>
                                <p class="small mb-1"><strong>Author:</strong> ${escapeHtml(source.author || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Publisher:</strong> ${escapeHtml(source.publisher || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Year:</strong> ${escapeHtml(source.year || 'N/A')}</p>
                                ${source.cover_url ? `<img src="${source.cover_url}" style="max-height:60px; max-width:100%; object-fit:contain; margin:5px 0;">` : ''}
                                <button class="btn btn-sm btn-primary mt-2" onclick="applyMetadataFromSource(${index})">
                                    <i class="fas fa-check"></i> Use This
                                </button>
                            </div>
                        </div>
                    </div>`;
                });
                html += '</div>';
                document.getElementById('metadataResults').innerHTML = html;
                new bootstrap.Modal(document.getElementById('metadataModal')).show();
            }
        });
}

function applyMetadataFromSource(index) {
    let isbn = document.getElementById(metadataTarget === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    fetch(`index.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.results && data.results[index]) {
                let source = data.results[index];
                let prefix = metadataTarget === 'add' ? 'add_' : 'edit_';
                if (source.title) document.getElementById(prefix + 'title').value = source.title;
                if (source.author) document.getElementById(prefix + 'author').value = source.author;
                if (source.publisher) document.getElementById(prefix + 'publisher').value = source.publisher;
                if (source.year) document.getElementById(prefix + 'year').value = source.year;
                if (source.subject) document.getElementById(prefix + 'subject').value = source.subject;
                if (source.summary) document.getElementById(prefix + 'description').value = source.summary;
                if (source.language) document.getElementById(prefix + 'language').value = source.language;
                if (source.pages) document.getElementById(prefix + 'pages').value = source.pages;
                if (source.cover_url) {
                    let previewDiv = document.getElementById(metadataTarget === 'add' ? 'addCoverPreview' : 'editCoverPreview');
                    previewDiv.innerHTML = `<img src="${source.cover_url}" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px;">`;
                    previewDiv.style.display = 'block';
                }
                bootstrap.Modal.getInstance(document.getElementById('metadataModal')).hide();
            }
        });
}

// ========== EDIT EBOOK ==========
function editEbook(id) {
    fetch('ajax_ebook.php?id=' + id)
        .then(r => r.json())
        .then(data => {
            if (data && !data.error) {
                document.getElementById('edit_id').value = data.id;
                document.getElementById('edit_title').value = data.title || '';
                document.getElementById('edit_author').value = data.author || '';
                document.getElementById('edit_isbn').value = data.isbn || '';
                document.getElementById('edit_publisher').value = data.publisher || '';
                document.getElementById('edit_year').value = data.year || '';
                document.getElementById('edit_subject').value = data.subject || '';
                document.getElementById('edit_description').value = data.description || '';
                document.getElementById('edit_language').value = data.language || '';
                document.getElementById('edit_pages').value = data.pages || 0;
                document.getElementById('edit_edition').value = data.edition || '';
                document.getElementById('edit_series').value = data.series || '';
                document.getElementById('edit_series_number').value = data.series_number || 0;
                document.getElementById('edit_tags').value = data.tags || '';
                document.getElementById('edit_format').value = data.format || 'pdf';
                document.getElementById('edit_access_level').value = data.access_level || 'public';
                document.getElementById('edit_license_type').value = data.license_type || '';
                document.getElementById('edit_keywords').value = data.keywords || '';
                document.getElementById('edit_existing_file').value = data.file_path || '';
                document.getElementById('edit_existing_cloud_id').value = data.cloud_file_id || '';
                document.getElementById('edit_existing_storage_type').value = data.storage_type || 'local';
                document.getElementById('edit_ebook_url').value = '';
                
                let coverPreview = document.getElementById('editCurrentCover');
                if (coverPreview && data.cover_url) {
                    coverPreview.innerHTML = `
                        <img src="${data.cover_url}" class="ebook-cover-large" alt="Current Cover">
                        <input type="hidden" name="existing_cover" value="${escapeHtml(data.cover_path || '')}">
                        <p class="small text-muted mt-1">Current cover</p>
                    `;
                    coverPreview.style.display = 'block';
                } else if (coverPreview) {
                    coverPreview.style.display = 'none';
                }
                
                new bootstrap.Modal(document.getElementById('editEbookModal')).show();
            }
        })
        .catch(err => { 
            alert('Error loading eBook details');
            console.error(err);
        });
}

// ========== PREVIEW COVER ==========
function previewCover(input, targetId) {
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = function(e) {
            let previewDiv = document.getElementById(targetId);
            if (previewDiv) {
                previewDiv.style.display = 'block';
                let img = document.getElementById(targetId.replace('Preview', 'PreviewImg'));
                if (img) {
                    img.src = e.target.result;
                }
            }
            if (targetId === 'editCoverPreview') {
                let current = document.getElementById('editCurrentCover');
                if (current) current.style.display = 'none';
            }
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// ========== ESCAPE HTML ==========
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        let searchInput = document.querySelector('input[name="search"]');
        if (searchInput) searchInput.focus();
    }
    if (e.key === 'Escape') {
        let modals = document.querySelectorAll('.modal.show');
        if (modals.length > 0) {
            let modal = bootstrap.Modal.getInstance(modals[modals.length - 1]);
            if (modal) modal.hide();
        }
    }
});

// ========== AUTO-DISMISS ALERTS ==========
setTimeout(function() { 
    document.querySelectorAll('.alert').forEach(function(alert) { 
        let bsAlert = bootstrap.Alert.getInstance(alert);
        if (bsAlert) setTimeout(function() { bsAlert.close(); }, 5000);
    }); 
}, 3000);

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateSelectedCount();
});
</script>
<?php renderFooter(); ?>
</body>
</html>