<?php
/**
 * eBook Management Module - Complete Update
 * Features: 
 * - Full-text search (FTS5)
 * - Metadata fetch from ISBN (Google Books, OpenLibrary)
 * - Cover image upload & preview with visible covers everywhere
 * - Bulk import (ZIP of PDFs / CSV)
 * - Cloud storage ready
 * - Download counter
 * - Edit/Delete with full CRUD
 * - Enhanced UI with cover thumbnails
 * - Improved modal scrolling
 * - Responsive design
 * - Add eBooks from online URL (direct download link)
 */

session_start();
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// Ensure upload directories exist
if (!defined('EBOOK_DIR')) {
    define('EBOOK_DIR', __DIR__ . '/../uploads/ebooks/');
}
if (!defined('EBOOK_COVER_DIR')) {
    define('EBOOK_COVER_DIR', __DIR__ . '/../uploads/ebook_covers/');
}
if (!defined('EBOOK_COVER_URL')) {
    define('EBOOK_COVER_URL', 'uploads/ebook_covers/');
}

// Create directories if they don't exist
foreach ([EBOOK_DIR, EBOOK_COVER_DIR] as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}

// ========== ENSURE TABLE STRUCTURE ==========
try {
    $columns = $db->query("PRAGMA table_info(ebooks)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $required = ['isbn', 'cover_path', 'publisher', 'year', 'description', 'file_size', 'cloud_file_id', 'storage_type', 'full_text', 'language', 'pages', 'edition'];
    foreach ($required as $col) {
        if (!in_array($col, $columns)) {
            $db->exec("ALTER TABLE ebooks ADD COLUMN $col TEXT DEFAULT ''");
        }
    }
} catch (PDOException $e) {
    $db->exec("CREATE TABLE IF NOT EXISTS ebooks(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT,
        subject TEXT,
        isbn TEXT,
        publisher TEXT,
        year TEXT,
        description TEXT,
        cover_path TEXT,
        file_path TEXT NOT NULL,
        file_size INTEGER,
        downloads INTEGER DEFAULT 0,
        cloud_file_id TEXT DEFAULT '',
        storage_type TEXT DEFAULT 'local',
        full_text TEXT,
        language TEXT DEFAULT '',
        pages INTEGER DEFAULT 0,
        edition TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
}

// ========== FTS5 VIRTUAL TABLE ==========
$db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS ebooks_fts USING fts5(title, author, subject, isbn, publisher, description, content=ebooks, content_rowid=id)");
$db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_ai AFTER INSERT ON ebooks BEGIN
    INSERT INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description)
    VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description);
END");
$db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_ad AFTER DELETE ON ebooks BEGIN
    DELETE FROM ebooks_fts WHERE rowid = old.id;
END");
$db->exec("CREATE TRIGGER IF NOT EXISTS ebooks_au AFTER UPDATE ON ebooks BEGIN
    DELETE FROM ebooks_fts WHERE rowid = old.id;
    INSERT INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description)
    VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description);
END");

// Populate FTS if empty
$count = $db->query("SELECT COUNT(*) FROM ebooks_fts")->fetchColumn();
if ($count == 0) {
    $db->exec("INSERT OR REPLACE INTO ebooks_fts(rowid, title, author, subject, isbn, publisher, description)
               SELECT id, title, author, subject, isbn, publisher, description FROM ebooks");
}

// ========== HELPER FUNCTIONS ==========

/**
 * Get eBook cover image as base64 or URL
 */
function getEbookCover($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) {
        return $coverPath;
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (file_exists($fullPath)) {
        $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
        $data = @file_get_contents($fullPath);
        if ($data !== false && in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $mime = mime_content_type($fullPath) ?: 'image/' . $ext;
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
        return getWebImageUrl($coverPath);
    }
    return '';
}

/**
 * Get eBook cover base64 for direct embedding
 */
function getEbookCoverBase64($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) {
        return '';
    }
    $data = @file_get_contents($fullPath);
    if ($data === false) {
        return '';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

/**
 * Extract text from PDF
 */
function extractTextFromPDF($filePath) {
    if (function_exists('exec') && !ini_get('safe_mode')) {
        $output = tempnam(sys_get_temp_dir(), 'pdftext');
        @exec('pdftotext -layout "' . escapeshellarg($filePath) . '" "' . escapeshellarg($output) . '" 2>/dev/null');
        if (file_exists($output)) {
            $text = file_get_contents($output);
            @unlink($output);
            return trim($text);
        }
    }
    return '';
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}

/**
 * Download a file from a URL and save it locally
 */
function downloadFromUrl($url, $targetPath) {
    $ctx = stream_context_create([
        'http' => [
            'timeout' => 30,
            'ignore_errors' => true,
            'follow_location' => 1,
            'max_redirects' => 5,
        ],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
    ]);
    $data = @file_get_contents($url, false, $ctx);
    if ($data === false) {
        return false;
    }
    if (file_put_contents($targetPath, $data) === false) {
        return false;
    }
    return true;
}

/**
 * Get file extension from URL or filename
 */
function getExtensionFromUrl($url) {
    $path = parse_url($url, PHP_URL_PATH);
    if ($path) {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (in_array($ext, ['pdf', 'doc', 'docx'])) {
            return $ext;
        }
    }
    // Fallback: try to detect from Content-Type header
    $headers = @get_headers($url, 1);
    if ($headers && isset($headers['Content-Type'])) {
        $ctype = is_array($headers['Content-Type']) ? $headers['Content-Type'][0] : $headers['Content-Type'];
        if (strpos($ctype, 'pdf') !== false) return 'pdf';
        if (strpos($ctype, 'word') !== false || strpos($ctype, 'doc') !== false) {
            if (strpos($ctype, 'docx') !== false) return 'docx';
            return 'doc';
        }
    }
    return 'pdf'; // default
}

// ========== AJAX HANDLERS ==========

// Fetch metadata from single source
if (isset($_GET['ajax_fetch_metadata'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
    
    // Try Google Books first
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $result = [
                'title' => $info['title'] ?? '',
                'author' => isset($info['authors'][0]) ? $info['authors'][0] : '',
                'publisher' => $info['publisher'] ?? '',
                'year' => substr($info['publishedDate'] ?? '', 0, 4),
                'pages' => $info['pageCount'] ?? 0,
                'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
                'summary' => $info['description'] ?? '',
                'subject' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'language' => strtoupper($info['language'] ?? ''),
                'edition' => $info['edition'] ?? ''
            ];
            echo json_encode(['success' => true, 'data' => $result]);
            exit;
        }
    }
    
    // Fallback to OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $resp2 = @file_get_contents($url2, false, $ctx);
    if ($resp2) {
        $data2 = json_decode($resp2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $result = [
                'title' => $book['title'] ?? '',
                'author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                'publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                'year' => $book['publish_date'] ?? '',
                'pages' => $book['number_of_pages'] ?? 0,
                'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'summary' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''),
                'subject' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : ''
            ];
            echo json_encode(['success' => true, 'data' => $result]);
            exit;
        }
    }
    echo json_encode(['success' => false, 'error' => 'No metadata found']);
    exit;
}

// Fetch all sources
if (isset($_GET['ajax_fetch_all_sources'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    
    $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
    $results = [];
    
    // Google Books
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn";
    $resp = @file_get_contents($url, false, $ctx);
    if ($resp) {
        $data = json_decode($resp, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $results[] = [
                'source_display' => 'Google Books',
                'title' => $info['title'] ?? '',
                'author' => isset($info['authors'][0]) ? $info['authors'][0] : '',
                'publisher' => $info['publisher'] ?? '',
                'year' => substr($info['publishedDate'] ?? '', 0, 4),
                'pages' => $info['pageCount'] ?? 0,
                'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
                'summary' => $info['description'] ?? '',
                'subject' => isset($info['categories'][0]) ? $info['categories'][0] : '',
                'language' => strtoupper($info['language'] ?? '')
            ];
        }
    }
    
    // OpenLibrary
    $url2 = "https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data";
    $resp2 = @file_get_contents($url2, false, $ctx);
    if ($resp2) {
        $data2 = json_decode($resp2, true);
        $key = "ISBN:$isbn";
        if (isset($data2[$key])) {
            $book = $data2[$key];
            $results[] = [
                'source_display' => 'OpenLibrary',
                'title' => $book['title'] ?? '',
                'author' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                'publisher' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                'year' => $book['publish_date'] ?? '',
                'pages' => $book['number_of_pages'] ?? 0,
                'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'summary' => is_array($book['description']) ? ($book['description']['value'] ?? '') : ($book['description'] ?? ''),
                'subject' => isset($book['subjects'][0]['name']) ? $book['subjects'][0]['name'] : ''
            ];
        }
    }
    
    echo json_encode(['success' => true, 'results' => $results]);
    exit;
}

// ========== CORE CRUD ==========
$editEbook = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editEbook = $stmt->fetch();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $coverPath = $_POST['existing_cover'] ?? '';
        $filePath = $_POST['existing_file'] ?? '';
        $cloudFileId = $_POST['existing_cloud_id'] ?? '';
        $storageType = $_POST['existing_storage_type'] ?? 'local';
        $fileSize = 0;

        // Cover upload
        if (isset($_FILES['ebook_cover']) && $_FILES['ebook_cover']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['ebook_cover']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                throw new Exception("Invalid cover image format. Only JPG, PNG, GIF, WEBP allowed.");
            }
            if ($_FILES['ebook_cover']['size'] > 10 * 1024 * 1024) {
                throw new Exception("Cover image too large. Max 10MB.");
            }
            $filename = 'ebook_cover_' . time() . '_' . uniqid() . '.' . $ext;
            $target = EBOOK_COVER_DIR . $filename;
            if (move_uploaded_file($_FILES['ebook_cover']['tmp_name'], $target)) {
                if ($coverPath && file_exists($coverPath) && strpos($coverPath, 'uploads/ebook_covers/') === 0) {
                    @unlink($coverPath);
                }
                $coverPath = 'uploads/ebook_covers/' . $filename;
            } else {
                throw new Exception("Failed to upload cover image.");
            }
        }

        // ===== NEW: Handle eBook URL =====
        $ebookUrl = trim($_POST['ebook_url'] ?? '');
        $isUrlUpload = false;
        $tempFile = null;

        // If a URL is provided and no file is uploaded (or upload failed), download from URL
        if (!empty($ebookUrl) && (!isset($_FILES['ebook_file']) || $_FILES['ebook_file']['error'] !== UPLOAD_ERR_OK)) {
            // Validate URL
            if (!filter_var($ebookUrl, FILTER_VALIDATE_URL)) {
                throw new Exception("Invalid eBook URL provided.");
            }
            // Determine file extension
            $ext = getExtensionFromUrl($ebookUrl);
            if (!in_array($ext, ['pdf', 'doc', 'docx'])) {
                throw new Exception("Unsupported file type from URL. Only PDF, DOC, DOCX are allowed.");
            }
            // Create temp file
            $tempFile = tempnam(sys_get_temp_dir(), 'ebook_url_') . '.' . $ext;
            if (!downloadFromUrl($ebookUrl, $tempFile)) {
                throw new Exception("Failed to download file from URL. Please check the link and try again.");
            }
            // Set up $_FILES-like info for further processing
            $_FILES['ebook_file']['tmp_name'] = $tempFile;
            $_FILES['ebook_file']['name'] = basename(parse_url($ebookUrl, PHP_URL_PATH)) ?: 'ebook.' . $ext;
            $_FILES['ebook_file']['size'] = filesize($tempFile);
            $_FILES['ebook_file']['error'] = UPLOAD_ERR_OK;
            $isUrlUpload = true;
        }

        // eBook file upload (either from file input or from URL)
        if (isset($_FILES['ebook_file']) && $_FILES['ebook_file']['error'] === UPLOAD_ERR_OK) {
            $tempFile = $_FILES['ebook_file']['tmp_name'];
            $ext = strtolower(pathinfo($_FILES['ebook_file']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['pdf', 'doc', 'docx'])) {
                throw new Exception("Only PDF, DOC, DOCX files are allowed.");
            }
            if ($_FILES['ebook_file']['size'] > 100 * 1024 * 1024) {
                throw new Exception("File too large. Max 100MB.");
            }
            
            $cloudProvider = $settings['cloud_storage_provider'] ?? 'local';
            if ($cloudProvider !== 'local' && function_exists('uploadToCloud')) {
                try {
                    $cloudResult = uploadToCloud($tempFile);
                    if ($cloudResult && isset($cloudResult['file_id'])) {
                        $cloudFileId = $cloudResult['file_id'];
                        $storageType = $cloudProvider;
                        $filePath = '';
                        if (!empty($_POST['existing_cloud_id']) && $_POST['existing_cloud_id'] != $cloudFileId && function_exists('deleteFromCloud')) {
                            deleteFromCloud($_POST['existing_cloud_id'], $_POST['existing_storage_type'] ?? 'local');
                        }
                    } else {
                        throw new Exception("Cloud upload failed");
                    }
                } catch (Exception $e) {
                    error_log("Cloud upload error: " . $e->getMessage());
                    $storageType = 'local';
                    $cloudFileId = '';
                    $targetPath = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                    if (!copy($tempFile, $targetPath)) {
                        throw new Exception("Failed to save file locally.");
                    }
                    $filePath = $targetPath;
                }
            } else {
                $targetPath = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                if (!copy($tempFile, $targetPath)) {
                    throw new Exception("Failed to save file.");
                }
                $filePath = $targetPath;
                $storageType = 'local';
                $cloudFileId = '';
            }
            
            $fileSize = $_FILES['ebook_file']['size'];
            
            // Extract full text if PDF
            if ($ext === 'pdf' && file_exists($filePath)) {
                $fullText = extractTextFromPDF($filePath);
                if ($fullText) {
                    // Will be saved in update/insert
                }
            }

            // Clean up temp file if it came from URL
            if ($isUrlUpload && file_exists($tempFile)) {
                @unlink($tempFile);
            }
        }

        // Common fields
        $title = trim($_POST['title']);
        $author = trim($_POST['author'] ?? '');
        $subject = trim($_POST['subject'] ?? '');
        $isbn = trim($_POST['isbn'] ?? '');
        $publisher = trim($_POST['publisher'] ?? '');
        $year = trim($_POST['year'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $language = trim($_POST['language'] ?? '');
        $pages = (int)($_POST['pages'] ?? 0);
        $edition = trim($_POST['edition'] ?? '');

        if (isset($_POST['update_ebook'])) {
            // ========== UPDATE EBOOK ==========
            $id = (int)$_POST['id'];
            
            $stmt = $db->prepare("UPDATE ebooks SET 
                title = ?, author = ?, subject = ?, isbn = ?, 
                publisher = ?, year = ?, description = ?, 
                cover_path = ?, file_path = ?, file_size = ?,
                cloud_file_id = ?, storage_type = ?,
                language = ?, pages = ?, edition = ?
                WHERE id = ?");
            $stmt->execute([
                $title, $author, $subject, $isbn,
                $publisher, $year, $description,
                $coverPath, $filePath, $fileSize,
                $cloudFileId, $storageType,
                $language, $pages, $edition,
                $id
            ]);
            
            // Update full text if PDF was uploaded
            if (isset($_FILES['ebook_file']) && $_FILES['ebook_file']['error'] === UPLOAD_ERR_OK && $ext === 'pdf' && file_exists($filePath)) {
                $fullText = extractTextFromPDF($filePath);
                if ($fullText) {
                    $db->prepare("UPDATE ebooks SET full_text = ? WHERE id = ?")->execute([$fullText, $id]);
                }
            }
            
            showToast("eBook updated successfully", "success");
            logActivity($_SESSION['username'], 'EBOOK_UPDATE', "Updated eBook: $title");
            header("Location: index.php");
            exit;

        } elseif (isset($_POST['add_ebook'])) {
            // ========== ADD NEW EBOOK ==========
            if (empty($title)) throw new Exception("Title is required");
            if (empty($filePath) && empty($cloudFileId)) {
                // If no file was uploaded and no URL was processed, but we have a URL field, maybe we should check if it was set?
                // The URL handling above would have set $filePath or $cloudFileId if successful.
                // If still empty, throw error.
                throw new Exception("eBook file or URL is required.");
            }
            
            $stmt = $db->prepare("INSERT INTO ebooks (
                title, author, subject, isbn, publisher, year, description,
                cover_path, file_path, file_size, downloads, cloud_file_id, storage_type,
                language, pages, edition, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([
                $title, $author, $subject, $isbn,
                $publisher, $year, $description,
                $coverPath, $filePath, $fileSize,
                $cloudFileId, $storageType,
                $language, $pages, $edition
            ]);
            $newId = $db->lastInsertId();
            
            // Extract full text if PDF
            if ($storageType === 'local' && $filePath && preg_match('/\.pdf$/i', $filePath) && file_exists($filePath)) {
                $fullText = extractTextFromPDF($filePath);
                if ($fullText) {
                    $db->prepare("UPDATE ebooks SET full_text = ? WHERE id = ?")->execute([$fullText, $newId]);
                }
            }
            
            showToast("eBook added successfully", "success");
            logActivity($_SESSION['username'], 'EBOOK_ADD', "Added eBook: $title");
            header("Location: index.php");
            exit;
        }
    } catch (Exception $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// ========== DELETE EBOOK ==========
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("SELECT file_path, cover_path, cloud_file_id, storage_type FROM ebooks WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    $ebook = $stmt->fetch();
    if ($ebook) {
        if ($ebook['file_path'] && file_exists($ebook['file_path'])) {
            @unlink($ebook['file_path']);
        }
        if ($ebook['cover_path'] && file_exists($ebook['cover_path'])) {
            @unlink($ebook['cover_path']);
        }
        if (!empty($ebook['cloud_file_id']) && $ebook['storage_type'] !== 'local' && function_exists('deleteFromCloud')) {
            deleteFromCloud($ebook['cloud_file_id'], $ebook['storage_type']);
        }
    }
    $db->prepare("DELETE FROM ebooks WHERE id = ?")->execute([$_GET['delete']]);
    showToast("eBook deleted successfully", "success");
    header("Location: index.php");
    exit;
}

// ========== BULK IMPORT ==========
if (isset($_POST['bulk_import'])) {
    if (isset($_FILES['bulk_zip']) && $_FILES['bulk_zip']['error'] === UPLOAD_ERR_OK) {
        $zip = new ZipArchive();
        if ($zip->open($_FILES['bulk_zip']['tmp_name']) === true) {
            $imported = 0;
            $failed = 0;
            $tempDir = sys_get_temp_dir() . '/bulk_import_' . uniqid();
            mkdir($tempDir, 0777, true);
            
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = $zip->getNameIndex($i);
                // Skip directories
                if (substr($filename, -1) == '/') continue;
                
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                if (in_array($ext, ['pdf', 'doc', 'docx'])) {
                    $tmp = tempnam($tempDir, 'ebook');
                    $contents = $zip->getFromName($filename);
                    if ($contents !== false && file_put_contents($tmp, $contents) !== false) {
                        $title = pathinfo($filename, PATHINFO_FILENAME);
                        $cloudProvider = $settings['cloud_storage_provider'] ?? 'local';
                        $filePath = ''; 
                        $cloudFileId = ''; 
                        $storageType = 'local';
                        
                        if ($cloudProvider !== 'local' && function_exists('uploadToCloud')) {
                            try {
                                $res = uploadToCloud($tmp);
                                if ($res && isset($res['file_id'])) {
                                    $cloudFileId = $res['file_id'];
                                    $storageType = $cloudProvider;
                                } else {
                                    throw new Exception("Cloud failed");
                                }
                            } catch (Exception $e) {
                                $target = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                                if (copy($tmp, $target)) {
                                    $filePath = $target;
                                } else {
                                    $failed++;
                                    continue;
                                }
                            }
                        } else {
                            $target = EBOOK_DIR . 'ebook_' . time() . '_' . uniqid() . '.' . $ext;
                            if (copy($tmp, $target)) {
                                $filePath = $target;
                            } else {
                                $failed++;
                                continue;
                            }
                        }
                        
                        if ($filePath || $cloudFileId) {
                            $stmt = $db->prepare("INSERT INTO ebooks (title, file_path, file_size, cloud_file_id, storage_type, created_at) 
                                VALUES (?, ?, ?, ?, ?, datetime('now'))");
                            $stmt->execute([$title, $filePath, filesize($tmp), $cloudFileId, $storageType]);
                            $imported++;
                        } else {
                            $failed++;
                        }
                        @unlink($tmp);
                    } else {
                        $failed++;
                    }
                }
            }
            $zip->close();
            @rmdir($tempDir);
            showToast("Imported $imported eBooks from ZIP ($failed failed)", $imported > 0 ? 'success' : 'danger');
        } else {
            showToast("Failed to open ZIP file", "danger");
        }
        header("Location: index.php");
        exit;
    }
    
    if (isset($_FILES['bulk_csv']) && $_FILES['bulk_csv']['error'] === UPLOAD_ERR_OK) {
        $handle = fopen($_FILES['bulk_csv']['tmp_name'], 'r');
        if ($handle) {
            $header = fgetcsv($handle);
            $imported = 0;
            $failed = 0;
            while (($row = fgetcsv($handle)) !== false) {
                $data = array_combine($header, $row);
                if (empty($data['title'])) {
                    $failed++;
                    continue;
                }
                try {
                    $stmt = $db->prepare("INSERT INTO ebooks (title, author, subject, isbn, publisher, year, description, file_path, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
                    $stmt->execute([
                        $data['title'] ?? '',
                        $data['author'] ?? '',
                        $data['subject'] ?? '',
                        $data['isbn'] ?? '',
                        $data['publisher'] ?? '',
                        $data['year'] ?? '',
                        $data['description'] ?? '',
                        $data['file_path'] ?? ''
                    ]);
                    $imported++;
                } catch (Exception $e) {
                    $failed++;
                }
            }
            fclose($handle);
            showToast("Imported $imported eBooks from CSV ($failed failed)", $imported > 0 ? 'success' : 'danger');
        }
        header("Location: index.php");
        exit;
    }
}

// ========== SEARCH ==========
$search = $_GET['search'] ?? '';
$displayEbooks = [];
if ($search) {
    $stmt = $db->prepare("SELECT e.* FROM ebooks e JOIN ebooks_fts f ON e.id = f.rowid WHERE ebooks_fts MATCH ? ORDER BY rank");
    $stmt->execute([$search]);
    $displayEbooks = $stmt->fetchAll();
} else {
    $displayEbooks = $db->query("SELECT * FROM ebooks ORDER BY created_at DESC LIMIT 100")->fetchAll();
}

// ========== STATISTICS ==========
$totalEbooks = $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn();
$totalDownloads = $db->query("SELECT SUM(downloads) FROM ebooks")->fetchColumn();
$totalStorage = $db->query("SELECT SUM(file_size) FROM ebooks WHERE storage_type = 'local'")->fetchColumn();

renderHeader('eBook Management');
?>

<style>
/* Enhanced styling for eBook management */
.ebook-cover-thumb {
    width: 60px;
    height: 80px;
    object-fit: cover;
    border-radius: 8px;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
    background: #f8f9fa;
}
.ebook-cover-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.ebook-cover-large {
    max-height: 200px;
    width: auto;
    object-fit: contain;
    border-radius: 12px;
    border: 2px solid #e9ecef;
    background: #f8f9fa;
    padding: 10px;
}
.ebook-cover-modal {
    max-height: 300px;
    width: auto;
    object-fit: contain;
    border-radius: 12px;
    border: 3px solid #1e3c72;
    background: #f8f9fa;
    padding: 15px;
}
.default-cover-thumb {
    width: 60px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #dc3545, #b02a37);
    border-radius: 8px;
    color: white;
    font-size: 1.8rem;
}
.default-cover-large {
    width: 150px;
    height: 200px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #dc3545, #b02a37);
    border-radius: 12px;
    color: white;
    font-size: 4rem;
}
.stat-card {
    transition: all 0.3s ease;
    border: none;
    border-radius: 15px;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
.filter-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.table th {
    background: #073b6f;
    color: white;
    border-bottom: 2px solid #dee2e6;
    white-space: nowrap;
}
.table td {
    vertical-align: middle;
}
.storage-badge {
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
}
.storage-local {
    background: #e9ecef;
    color: #495057;
}
.storage-cloud {
    background: #cfe2ff;
    color: #084298;
}
.download-badge {
    font-size: 0.8rem;
    padding: 3px 10px;
    border-radius: 12px;
}
.modal-dialog-scrollable {
    max-height: 95vh;
}
.modal-dialog-scrollable .modal-content {
    max-height: 95vh;
    display: flex;
    flex-direction: column;
}
.modal-dialog-scrollable .modal-body {
    flex: 1 1 auto;
    overflow-y: auto;
    padding: 1rem;
    max-height: calc(95vh - 130px);
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar {
    width: 6px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb {
    background: #1e3c72;
    border-radius: 10px;
}
.modal-dialog-scrollable .modal-body::-webkit-scrollbar-thumb:hover {
    background: #2a5298;
}
@media (max-width: 768px) {
    .ebook-cover-thumb {
        width: 40px;
        height: 55px;
    }
    .default-cover-thumb {
        width: 40px;
        height: 55px;
        font-size: 1.2rem;
    }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-file-pdf text-danger"></i> eBook Management</h2>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addEbookModal">
                <i class="fas fa-plus"></i> Add eBook
            </button>
            <button class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#bulkImportModal">
                <i class="fas fa-upload"></i> Bulk Import
            </button>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
            <div class="card stat-card bg-primary text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($totalEbooks) ?></h3>
                    <small><i class="fas fa-file-pdf"></i> Total eBooks</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card stat-card bg-success text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= number_format($totalDownloads) ?></h3>
                    <small><i class="fas fa-download"></i> Total Downloads</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card stat-card bg-info text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= $totalEbooks ? round($totalDownloads/$totalEbooks, 1) : 0 ?></h3>
                    <small><i class="fas fa-chart-line"></i> Avg Downloads/eBook</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6">
            <div class="card stat-card bg-secondary text-white">
                <div class="card-body text-center">
                    <h3 class="mb-0"><?= formatFileSize($totalStorage ?? 0) ?></h3>
                    <small><i class="fas fa-hdd"></i> Total Storage Used</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Search Bar -->
    <div class="filter-card mb-4">
        <form method="GET" class="row g-3">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control form-control-lg" 
                       placeholder="Search eBooks by title, author, subject, ISBN, description..." 
                       value="<?= htmlspecialchars($search) ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100 h-100">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
            <?php if ($search): ?>
                <div class="col-12">
                    <a href="index.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-times"></i> Clear Search
                    </a>
                    <span class="ms-2 text-muted">Found <?= count($displayEbooks) ?> result(s)</span>
                </div>
            <?php endif; ?>
        </form>
    </div>

    <!-- eBooks Table -->
    <div class="card">
        <div class="card-header bg-primary text-white d-flex flex-wrap justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> eBook Collection</span>
            <span class="badge bg-light text-dark"><?= count($displayEbooks) ?> eBooks</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 60px;">Cover</th>
                            <th>Title / Author</th>
                            <th>ISBN</th>
                            <th>Publisher / Year</th>
                            <th>Subject</th>
                            <th style="text-align: center;">Downloads</th>
                            <th style="text-align: center;">Storage</th>
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($displayEbooks as $ebook): 
                            $coverBase64 = getEbookCoverBase64($ebook['cover_path'] ?? '');
                            $coverUrl = getEbookCover($ebook['cover_path'] ?? '');
                        ?>
                        <tr>
                            <td class="text-center">
                                <?php if ($coverBase64): ?>
                                    <img src="<?= $coverBase64 ?>" class="ebook-cover-thumb" alt="Cover" 
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                    <div class="default-cover-thumb" style="display:none;">
                                        <i class="fas fa-file-pdf"></i>
                                    </div>
                                <?php elseif ($coverUrl): ?>
                                    <img src="<?= $coverUrl ?>" class="ebook-cover-thumb" alt="Cover"
                                         onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover-thumb').style.display='flex';">
                                    <div class="default-cover-thumb" style="display:none;">
                                        <i class="fas fa-file-pdf"></i>
                                    </div>
                                <?php else: ?>
                                    <div class="default-cover-thumb">
                                        <i class="fas fa-file-pdf"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($ebook['title'] ?? 'Untitled') ?></strong>
                                <br><small class="text-muted">
                                    <i class="fas fa-user"></i> <?= htmlspecialchars($ebook['author'] ?? 'Unknown Author') ?>
                                    <?php if (!empty($ebook['edition'])): ?>
                                        <br><span class="badge bg-secondary"><?= htmlspecialchars($ebook['edition']) ?> edition</span>
                                    <?php endif; ?>
                                    <?php if (!empty($ebook['pages']) && $ebook['pages'] > 0): ?>
                                        <span class="badge bg-light text-dark ms-1"><?= $ebook['pages'] ?> pages</span>
                                    <?php endif; ?>
                                </small>
                            </td>
                            <td>
                                <?= htmlspecialchars($ebook['isbn'] ?? '-') ?>
                                <?php if (!empty($ebook['language'])): ?>
                                    <br><span class="badge bg-info text-white"><?= htmlspecialchars($ebook['language']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($ebook['publisher'] ?? '-') ?>
                                <?php if (!empty($ebook['year'])): ?>
                                    <br><small><?= htmlspecialchars($ebook['year']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-warning text-dark">
                                    <?= htmlspecialchars($ebook['subject'] ?? 'Uncategorized') ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-primary download-badge">
                                    <i class="fas fa-download"></i> <?= (int)($ebook['downloads'] ?? 0) ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <?php $storage = $ebook['storage_type'] ?? 'local'; ?>
                                <span class="badge storage-<?= $storage === 'cloud' ? 'cloud' : 'local' ?> storage-badge">
                                    <i class="fas fa-<?= $storage === 'cloud' ? 'cloud' : 'hdd' ?>"></i>
                                    <?= ucfirst($storage) ?>
                                </span>
                                <?php if (!empty($ebook['file_size']) && $storage === 'local'): ?>
                                    <br><small class="text-muted"><?= formatFileSize($ebook['file_size']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="download.php?id=<?= $ebook['id'] ?>" class="btn btn-success" title="Download">
                                        <i class="fas fa-download"></i>
                                    </a>
                                    <button onclick="editEbook(<?= $ebook['id'] ?>)" class="btn btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="?delete=<?= $ebook['id'] ?>" class="btn btn-danger" onclick="return confirm('Delete this eBook permanently? This cannot be undone.')" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($displayEbooks)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                    No eBooks found.
                                    <br><button class="btn btn-success btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#addEbookModal">
                                        <i class="fas fa-plus"></i> Add your first eBook
                                    </button>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ========== ADD EBOOK MODAL (FIXED SCROLLING) ========== -->
<div class="modal fade" id="addEbookModal" tabindex="-1" aria-labelledby="addEbookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-success text-white sticky-top" style="z-index: 10;">
                <h5 class="modal-title" id="addEbookModalLabel"><i class="fas fa-plus"></i> Add New eBook</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="row">
                        <!-- ISBN & Metadata -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 text-success"><i class="fas fa-search"></i> ISBN & Metadata</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">ISBN</label>
                            <div class="input-group">
                                <input type="text" name="isbn" id="add_isbn" class="form-control" placeholder="Enter ISBN (10 or 13 digits)">
                                <button type="button" class="btn btn-info" onclick="fetchMetadataForAdd()">
                                    <i class="fas fa-globe"></i> Fetch Metadata
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="fetchAllSourcesForAdd()">
                                    <i class="fas fa-list"></i> All Sources
                                </button>
                            </div>
                            <div id="addApiStatus" class="small text-muted mt-1"></div>
                        </div>
                        
                        <!-- Basic Information -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-success"><i class="fas fa-info-circle"></i> Basic Information</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" id="add_title" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Year</label>
                            <input type="text" name="year" id="add_year" class="form-control" placeholder="e.g., 2024">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" id="add_author" class="form-control" placeholder="Author name">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Publisher</label>
                            <input type="text" name="publisher" id="add_publisher" class="form-control" placeholder="Publisher name">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" id="add_subject" class="form-control" placeholder="Subject/Category">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Language</label>
                            <input type="text" name="language" id="add_language" class="form-control" placeholder="e.g., English">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Pages</label>
                            <input type="number" name="pages" id="add_pages" class="form-control" min="0" placeholder="0">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Edition</label>
                            <input type="text" name="edition" id="add_edition" class="form-control" placeholder="e.g., 2nd">
                        </div>
                        
                        <!-- File Upload / URL -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-success"><i class="fas fa-upload"></i> Files</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cover Image</label>
                            <input type="file" name="ebook_cover" class="form-control" accept="image/*" onchange="previewCover(this, 'addCoverPreview')">
                            <small class="text-muted">Max 10MB. Supported: JPG, PNG, GIF, WEBP</small>
                        </div>
                        <div class="col-md-6 mb-3 text-center">
                            <div id="addCoverPreview" class="mt-2" style="display:none;">
                                <img id="addPreviewImg" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px; border:2px solid #e9ecef;">
                            </div>
                        </div>
                        <!-- NEW: eBook URL -->
                        <div class="col-md-12 mb-3">
                            <label class="form-label">eBook URL (optional)</label>
                            <input type="url" name="ebook_url" id="add_ebook_url" class="form-control" placeholder="https://example.com/ebook.pdf">
                            <small class="text-muted">Paste a direct link to a PDF/DOC/DOCX file. The system will download it automatically.</small>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Or Upload eBook File (PDF, DOC, DOCX)</label>
                            <input type="file" name="ebook_file" class="form-control" accept=".pdf,.doc,.docx">
                            <small class="text-muted">Max 100MB. Supported: PDF, DOC, DOCX. If both URL and file are provided, the file takes priority.</small>
                        </div>
                        
                        <!-- Description -->
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-success"><i class="fas fa-align-left"></i> Description</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="add_description" class="form-control" rows="3" placeholder="Enter a brief description of the eBook..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_ebook" class="btn btn-success">Add eBook</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== BULK IMPORT MODAL ========== -->
<div class="modal fade" id="bulkImportModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-upload"></i> Bulk Import eBooks</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <h6>Import from ZIP</h6>
                    <p class="small text-muted">Upload a ZIP file containing PDF/DOC/DOCX files. Filenames become titles.</p>
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="bulk_zip" class="form-control mb-2" accept=".zip" required>
                        <button type="submit" name="bulk_import" class="btn btn-success w-100">
                            <i class="fas fa-upload"></i> Import ZIP
                        </button>
                    </form>
                </div>
                <hr>
                <div>
                    <h6>Import from CSV</h6>
                    <p class="small text-muted">CSV format: title,author,subject,isbn,publisher,year,description,file_path</p>
                    <form method="post" enctype="multipart/form-data">
                        <input type="file" name="bulk_csv" class="form-control mb-2" accept=".csv" required>
                        <button type="submit" name="bulk_import" class="btn btn-info w-100 text-white">
                            <i class="fas fa-upload"></i> Import CSV
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== EDIT EBOOK MODAL ========== -->
<div class="modal fade" id="editEbookModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content" style="max-height: 95vh;">
            <div class="modal-header bg-warning sticky-top" style="z-index: 10;">
                <h5 class="modal-title"><i class="fas fa-edit"></i> Edit eBook</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body" style="overflow-y: auto; max-height: calc(95vh - 130px);">
                    <div class="row">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 text-warning"><i class="fas fa-search"></i> ISBN & Metadata</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">ISBN</label>
                            <div class="input-group">
                                <input type="text" name="isbn" id="edit_isbn" class="form-control" placeholder="Enter ISBN">
                                <button type="button" class="btn btn-info" onclick="fetchMetadataForEdit()">
                                    <i class="fas fa-globe"></i> Fetch Metadata
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="fetchAllSourcesForEdit()">
                                    <i class="fas fa-list"></i> All Sources
                                </button>
                            </div>
                            <div id="editApiStatus" class="small text-muted mt-1"></div>
                        </div>
                        
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-warning"><i class="fas fa-info-circle"></i> Basic Information</h6>
                        </div>
                        <div class="col-md-8 mb-3">
                            <label class="form-label">Title *</label>
                            <input type="text" name="title" id="edit_title" class="form-control" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Year</label>
                            <input type="text" name="year" id="edit_year" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Author</label>
                            <input type="text" name="author" id="edit_author" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Publisher</label>
                            <input type="text" name="publisher" id="edit_publisher" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" name="subject" id="edit_subject" class="form-control">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Language</label>
                            <input type="text" name="language" id="edit_language" class="form-control">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Pages</label>
                            <input type="number" name="pages" id="edit_pages" class="form-control" min="0">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">Edition</label>
                            <input type="text" name="edition" id="edit_edition" class="form-control">
                        </div>
                        
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-warning"><i class="fas fa-upload"></i> Files</h6>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Cover Image</label>
                            <input type="file" name="ebook_cover" class="form-control" accept="image/*" onchange="previewCover(this, 'editCoverPreview')">
                            <small class="text-muted">Upload new cover to replace existing</small>
                        </div>
                        <div class="col-md-6 mb-3 text-center">
                            <?php $editCoverBase64 = getEbookCoverBase64($editEbook['cover_path'] ?? ''); ?>
                            <?php if ($editCoverBase64): ?>
                                <div id="editCurrentCover">
                                    <img src="<?= $editCoverBase64 ?>" class="ebook-cover-large" alt="Current Cover">
                                    <input type="hidden" name="existing_cover" value="<?= htmlspecialchars($editEbook['cover_path'] ?? '') ?>">
                                    <p class="small text-muted mt-1">Current cover</p>
                                </div>
                            <?php endif; ?>
                            <div id="editCoverPreview" class="mt-2" style="display:none;">
                                <img id="editPreviewImg" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px; border:2px solid #e9ecef;">
                            </div>
                        </div>
                        <!-- NEW: eBook URL for editing -->
                        <div class="col-md-12 mb-3">
                            <label class="form-label">eBook URL (optional)</label>
                            <input type="url" name="ebook_url" id="edit_ebook_url" class="form-control" placeholder="https://example.com/ebook.pdf">
                            <small class="text-muted">If you provide a URL, the file will be downloaded and replace the current one.</small>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">eBook File (leave empty to keep current)</label>
                            <input type="file" name="ebook_file" class="form-control" accept=".pdf,.doc,.docx">
                            <input type="hidden" name="existing_file" id="edit_existing_file">
                            <input type="hidden" name="existing_cloud_id" id="edit_existing_cloud_id">
                            <input type="hidden" name="existing_storage_type" id="edit_existing_storage_type">
                            <?php if (!empty($editEbook['file_path']) && file_exists($editEbook['file_path'])): ?>
                                <small class="text-muted">Current file: <?= basename($editEbook['file_path']) ?> (<?= formatFileSize($editEbook['file_size'] ?? 0) ?>)</small>
                            <?php elseif (!empty($editEbook['cloud_file_id'])): ?>
                                <small class="text-muted">Current file: Cloud storage (ID: <?= htmlspecialchars($editEbook['cloud_file_id']) ?>)</small>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-12 mt-2">
                            <h6 class="border-bottom pb-2 text-warning"><i class="fas fa-align-left"></i> Description</h6>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer sticky-bottom" style="background: white; border-radius: 0 0 10px 10px; z-index: 10;">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_ebook" class="btn btn-primary">Update eBook</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ========== METADATA SOURCES MODAL ========== -->
<div class="modal fade" id="metadataModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-list"></i> Metadata Sources</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="metadataResults" style="max-height: 70vh; overflow-y: auto;"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ========== JAVASCRIPT ========== -->
<script>
let metadataTarget = 'add';
let currentEditId = null;

// ========== FETCH METADATA ==========
function fetchMetadataForAdd() { fetchSingleMetadata('add'); }
function fetchMetadataForEdit() { fetchSingleMetadata('edit'); }

function fetchSingleMetadata(target) {
    let isbn = document.getElementById(target === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    if (!isbn) { 
        alert('Please enter an ISBN first'); 
        return; 
    }
    let statusDiv = document.getElementById(target === 'add' ? 'addApiStatus' : 'editApiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching metadata...';
    
    fetch(`index.php?ajax_fetch_metadata=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data) {
                let b = data.data;
                let prefix = target === 'add' ? 'add_' : 'edit_';
                
                if (b.title) document.getElementById(prefix + 'title').value = b.title;
                if (b.author) document.getElementById(prefix + 'author').value = b.author;
                if (b.publisher) document.getElementById(prefix + 'publisher').value = b.publisher;
                if (b.year) document.getElementById(prefix + 'year').value = b.year;
                if (b.subject) document.getElementById(prefix + 'subject').value = b.subject;
                if (b.summary) document.getElementById(prefix + 'description').value = b.summary;
                if (b.language) document.getElementById(prefix + 'language').value = b.language;
                if (b.pages) document.getElementById(prefix + 'pages').value = b.pages;
                if (b.edition) document.getElementById(prefix + 'edition').value = b.edition;
                
                if (b.cover_url) {
                    let previewDiv = document.getElementById(target === 'add' ? 'addCoverPreview' : 'editCoverPreview');
                    previewDiv.innerHTML = `<img src="${b.cover_url}" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px; border:2px solid #e9ecef;">`;
                    previewDiv.style.display = 'block';
                }
                
                statusDiv.innerHTML = '<span class="text-success"><i class="fas fa-check-circle"></i> Metadata applied successfully.</span>';
            } else {
                statusDiv.innerHTML = '<span class="text-danger"><i class="fas fa-exclamation-circle"></i> ' + (data.error || 'Not found') + '</span>';
            }
        })
        .catch(err => { 
            statusDiv.innerHTML = '<span class="text-danger">Network error. Please try again.</span>';
            console.error(err);
        });
}

// ========== FETCH ALL SOURCES ==========
function fetchAllSourcesForAdd() { fetchAllSources('add'); }
function fetchAllSourcesForEdit() { fetchAllSources('edit'); }

function fetchAllSources(target) {
    let isbn = document.getElementById(target === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    if (!isbn) { 
        alert('Please enter an ISBN first'); 
        return; 
    }
    metadataTarget = target;
    let statusDiv = document.getElementById(target === 'add' ? 'addApiStatus' : 'editApiStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching all sources...';
    
    fetch(`index.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            statusDiv.innerHTML = '';
            if (data.success && data.results && data.results.length) {
                let html = '<div class="row g-3">';
                data.results.forEach((source, index) => {
                    html += `<div class="col-md-6">
                        <div class="card h-100">
                            <div class="card-header bg-light">
                                <strong><i class="fas fa-${source.source_display === 'Google Books' ? 'google' : 'book'}"></i> ${escapeHtml(source.source_display)}</strong>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title">${escapeHtml(source.title || 'No title')}</h6>
                                <p class="small mb-1"><strong>Author:</strong> ${escapeHtml(source.author || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Publisher:</strong> ${escapeHtml(source.publisher || 'Unknown')}</p>
                                <p class="small mb-1"><strong>Year:</strong> ${escapeHtml(source.year || 'N/A')}</p>
                                <p class="small mb-1"><strong>Subject:</strong> ${escapeHtml(source.subject || 'N/A')}</p>
                                ${source.cover_url ? `<img src="${source.cover_url}" style="max-height:60px; max-width:100%; object-fit:contain; margin:5px 0;">` : ''}
                                <button class="btn btn-sm btn-primary mt-2" onclick="applyMetadataFromSource(${index})">
                                    <i class="fas fa-check"></i> Use This
                                </button>
                            </div>
                        </div>
                    </div>`;
                });
                html += '</div>';
                document.getElementById('metadataResults').innerHTML = html;
                new bootstrap.Modal(document.getElementById('metadataModal')).show();
            } else {
                alert('No metadata found from any source.');
            }
        })
        .catch(err => { 
            console.error(err); 
            alert('Error fetching sources. Please try again.');
        });
}

// ========== APPLY METADATA FROM SOURCE ==========
function applyMetadataFromSource(index) {
    // This is a placeholder - we need to store the results globally or re-fetch
    // For simplicity, we'll re-fetch and apply the selected source
    let isbn = document.getElementById(metadataTarget === 'add' ? 'add_isbn' : 'edit_isbn').value.trim();
    if (!isbn) return;
    fetch(`index.php?ajax_fetch_all_sources=1&isbn=${encodeURIComponent(isbn)}`)
        .then(r => r.json())
        .then(data => {
            if (data.success && data.results && data.results[index]) {
                let source = data.results[index];
                let prefix = metadataTarget === 'add' ? 'add_' : 'edit_';
                if (source.title) document.getElementById(prefix + 'title').value = source.title;
                if (source.author) document.getElementById(prefix + 'author').value = source.author;
                if (source.publisher) document.getElementById(prefix + 'publisher').value = source.publisher;
                if (source.year) document.getElementById(prefix + 'year').value = source.year;
                if (source.subject) document.getElementById(prefix + 'subject').value = source.subject;
                if (source.summary) document.getElementById(prefix + 'description').value = source.summary;
                if (source.language) document.getElementById(prefix + 'language').value = source.language;
                if (source.pages) document.getElementById(prefix + 'pages').value = source.pages;
                if (source.cover_url) {
                    let previewDiv = document.getElementById(metadataTarget === 'add' ? 'addCoverPreview' : 'editCoverPreview');
                    previewDiv.innerHTML = `<img src="${source.cover_url}" style="max-height:150px; max-width:100%; object-fit:contain; border-radius:8px; border:2px solid #e9ecef;">`;
                    previewDiv.style.display = 'block';
                    if (metadataTarget === 'edit') {
                        let current = document.getElementById('editCurrentCover');
                        if (current) current.style.display = 'none';
                    }
                }
                // Close the modal
                bootstrap.Modal.getInstance(document.getElementById('metadataModal')).hide();
            } else {
                alert('Could not apply metadata.');
            }
        })
        .catch(err => {
            alert('Error applying metadata.');
            console.error(err);
        });
}

// ========== EDIT EBOOK ==========
function editEbook(id) {
    fetch('ajax_ebook.php?id=' + id)
        .then(r => r.json())
        .then(data => {
            if (data && !data.error) {
                currentEditId = data.id;
                document.getElementById('edit_id').value = data.id;
                document.getElementById('edit_title').value = data.title || '';
                document.getElementById('edit_author').value = data.author || '';
                document.getElementById('edit_isbn').value = data.isbn || '';
                document.getElementById('edit_publisher').value = data.publisher || '';
                document.getElementById('edit_year').value = data.year || '';
                document.getElementById('edit_subject').value = data.subject || '';
                document.getElementById('edit_description').value = data.description || '';
                document.getElementById('edit_language').value = data.language || '';
                document.getElementById('edit_pages').value = data.pages || 0;
                document.getElementById('edit_edition').value = data.edition || '';
                document.getElementById('edit_existing_cover').value = data.cover_path || '';
                document.getElementById('edit_existing_file').value = data.file_path || '';
                document.getElementById('edit_existing_cloud_id').value = data.cloud_file_id || '';
                document.getElementById('edit_existing_storage_type').value = data.storage_type || 'local';
                // Clear URL field
                document.getElementById('edit_ebook_url').value = '';
                
                // Show current cover
                let coverPreview = document.getElementById('editCurrentCover');
                if (coverPreview) {
                    if (data.cover_url) {
                        coverPreview.innerHTML = `
                            <img src="${data.cover_url}" class="ebook-cover-large" alt="Current Cover">
                            <input type="hidden" name="existing_cover" value="${escapeHtml(data.cover_path || '')}">
                            <p class="small text-muted mt-1">Current cover</p>
                        `;
                        coverPreview.style.display = 'block';
                    } else {
                        coverPreview.style.display = 'none';
                    }
                }
                document.getElementById('editCoverPreview').innerHTML = '';
                document.getElementById('editCoverPreview').style.display = 'none';
                
                new bootstrap.Modal(document.getElementById('editEbookModal')).show();
            } else {
                alert('Error loading eBook details: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(err => { 
            alert('Error loading eBook details: ' + err.message);
            console.error(err);
        });
}

// ========== PREVIEW COVER ==========
function previewCover(input, targetId) {
    if (input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = function(e) {
            let previewDiv = document.getElementById(targetId);
            if (previewDiv) {
                previewDiv.style.display = 'block';
                let img = document.getElementById(targetId.replace('Preview', 'PreviewImg'));
                if (img) {
                    img.src = e.target.result;
                }
            }
            // Hide current cover if editing
            if (targetId === 'editCoverPreview') {
                let current = document.getElementById('editCurrentCover');
                if (current) current.style.display = 'none';
            }
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        let previewDiv = document.getElementById(targetId);
        if (previewDiv) previewDiv.style.display = 'none';
    }
}

// ========== ESCAPE HTML ==========
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// ========== AUTO-DISMISS ALERTS ==========
setTimeout(function() { 
    var alerts = document.querySelectorAll('.alert'); 
    alerts.forEach(function(alert) { 
        var bsAlert = new bootstrap.Alert(alert); 
        setTimeout(function() { bsAlert.close(); }, 5000); 
    }); 
}, 3000);

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+F to focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        var searchInput = document.querySelector('input[name="search"]');
        if (searchInput) searchInput.focus();
    }
});
</script>

<?php renderFooter(); ?>