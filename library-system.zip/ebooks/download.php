<?php
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

if (!isset($_GET['id'])) {
    header('HTTP/1.0 400 Bad Request');
    echo 'Missing eBook ID';
    exit;
}

$stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
$stmt->execute([$_GET['id']]);
$ebook = $stmt->fetch();

if (!$ebook) {
    header('HTTP/1.0 404 Not Found');
    echo 'eBook not found';
    exit;
}

// Increment download counter
$db->prepare("UPDATE ebooks SET downloads = downloads + 1 WHERE id = ?")->execute([$_GET['id']]);

$storageType = $ebook['storage_type'] ?? 'local';
$filePath = $ebook['file_path'];
$cloudFileId = $ebook['cloud_file_id'];

if ($storageType !== 'local' && !empty($cloudFileId)) {
    // Redirect to cloud download handler (implement as needed)
    header("Location: cloud_download.php?id=" . $ebook['id']);
    exit;
} elseif (!empty($filePath) && file_exists($filePath)) {
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    $contentType = 'application/octet-stream';
    if ($ext === 'pdf') $contentType = 'application/pdf';
    elseif ($ext === 'doc') $contentType = 'application/msword';
    elseif ($ext === 'docx') $contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    
    header('Content-Type: ' . $contentType);
    header('Content-Disposition: attachment; filename="' . basename($ebook['title']) . '.' . $ext . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: private');
    header('Pragma: public');
    readfile($filePath);
    exit;
}

header('HTTP/1.0 404 Not Found');
echo 'File not available';
?>