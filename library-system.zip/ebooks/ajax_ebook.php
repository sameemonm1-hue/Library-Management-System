<?php
require_once __DIR__ . '/../config/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = getDB();
$id = $_GET['id'] ?? 0;

if ($id) {
    $stmt = $db->prepare("SELECT * FROM ebooks WHERE id = ?");
    $stmt->execute([$id]);
    $ebook = $stmt->fetch();
    if ($ebook) {
        $ebook['cover_url'] = !empty($ebook['cover_path']) ? getWebImageUrl($ebook['cover_path']) : '';
    }
    header('Content-Type: application/json');
    echo json_encode($ebook);
} else {
    echo json_encode(null);
}
?>