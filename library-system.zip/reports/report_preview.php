<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// Get report settings
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';

// Get logos as base64
function getLogoBase64() {
    $settings = getSettings();
    if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])) {
        $imageData = base64_encode(file_get_contents($settings['library_logo']));
        $imageMime = mime_content_type($settings['library_logo']);
        return 'data:' . $imageMime . ';base64,' . $imageData;
    }
    $institution = getInstitution();
    if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
        $imageData = base64_encode(file_get_contents($institution['logo_path']));
        $imageMime = mime_content_type($institution['logo_path']);
        return 'data:' . $imageMime . ';base64,' . $imageData;
    }
    return '';
}

function getRightLogoBase64() {
    $settings = getSettings();
    $logoPath = $settings['report_logo_right'] ?? '';
    if ($logoPath && file_exists($logoPath)) {
        $imageData = base64_encode(file_get_contents($logoPath));
        $imageMime = mime_content_type($logoPath);
        return 'data:' . $imageMime . ';base64,' . $imageData;
    }
    return '';
}

function getSignatureBase64() {
    $settings = getSettings();
    $logoPath = $settings['report_signature_image'] ?? '';
    if ($logoPath && file_exists($logoPath)) {
        $imageData = base64_encode(file_get_contents($logoPath));
        $imageMime = mime_content_type($logoPath);
        return 'data:' . $imageMime . ';base64,' . $imageData;
    }
    return '';
}

$logoBase64 = getLogoBase64();
$rightLogoBase64 = getRightLogoBase64();
$signatureBase64 = getSignatureBase64();
$watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : ($institution['name'] ?? 'Library');
$opacity = $reportWatermarkOpacity / 100;

renderHeader('Report Settings Preview');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Preview - Library System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .preview-container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin: 20px 0;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            position: relative;
        }
        .watermark-preview:before {
            content: "<?= addslashes($watermarkText) ?>";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 60px;
            color: rgba(0,0,0,<?= $opacity ?>);
            white-space: pre;
            pointer-events: none;
            z-index: 0;
        }
        .report-content {
            position: relative;
            z-index: 1;
            background: white;
        }
        @media print {
            body { background: white; margin: 0; padding: 0; }
            .no-print { display: none !important; }
            .preview-container { box-shadow: none; padding: 0; margin: 0; }
        }
        .settings-badge {
            background: <?= $reportPrimaryColor ?>;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4 no-print">
        <h2><i class="fas fa-eye"></i> Report Live Preview</h2>
        <div>
            <a href="../settings.php#report" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Settings</a>
            <a href="index.php" class="btn btn-info"><i class="fas fa-chart-line"></i> Go to Reports</a>
            <button onclick="window.print()" class="btn btn-success"><i class="fas fa-print"></i> Print Preview</button>
        </div>
    </div>

    <!-- Current Settings Summary -->
    <div class="row no-print mb-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-font fa-2x text-primary"></i>
                    <h6 class="mt-2">Font Size</h6>
                    <span class="settings-badge"><?= $reportFontSize ?>px</span>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-palette fa-2x text-primary"></i>
                    <h6 class="mt-2">Primary Color</h6>
                    <div class="settings-badge" style="background: <?= $reportPrimaryColor ?>"><?= $reportPrimaryColor ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-image fa-2x text-primary"></i>
                    <h6 class="mt-2">Logo Position</h6>
                    <span class="settings-badge"><?= ucfirst($reportLogoPosition) ?></span>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-water fa-2x text-primary"></i>
                    <h6 class="mt-2">Watermark</h6>
                    <span class="settings-badge"><?= $reportWatermarkEnabled ? 'On (' . $reportWatermarkOpacity . '%)' : 'Off' ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Report Preview -->
    <div class="preview-container <?= $reportWatermarkEnabled ? 'watermark-preview' : '' ?>">
        <div class="report-content">
            <!-- Header -->
            <div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid <?= $reportPrimaryColor ?>; padding-bottom: 15px;">
                
                <?php if ($reportLogoPosition === 'both'): ?>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div><?= $logoBase64 ? '<img src="' . $logoBase64 . '" style="height:60px;">' : '' ?></div>
                    <div>
                        <h2 style="margin:0; color:<?= $reportPrimaryColor ?>;"><?= htmlspecialchars($institution['name'] ?? 'Library Management System') ?></h2>
                        <h3 style="margin:5px 0; font-size:18px;">Members Report (Sample)</h3>
                    </div>
                    <div><?= $rightLogoBase64 ? '<img src="' . $rightLogoBase64 . '" style="height:60px;">' : '' ?></div>
                </div>
                
                <?php elseif ($reportLogoPosition === 'left'): ?>
                <div style="display: flex; align-items: center; justify-content: center; gap: 20px;">
                    <?= $logoBase64 ? '<img src="' . $logoBase64 . '" style="height:60px;">' : '' ?>
                    <div>
                        <h2 style="margin:0; color:<?= $reportPrimaryColor ?>;"><?= htmlspecialchars($institution['name'] ?? 'Library Management System') ?></h2>
                        <h3 style="margin:5px 0; font-size:18px;">Members Report (Sample)</h3>
                    </div>
                </div>
                
                <?php elseif ($reportLogoPosition === 'right'): ?>
                <div style="display: flex; align-items: center; justify-content: center; gap: 20px;">
                    <div>
                        <h2 style="margin:0; color:<?= $reportPrimaryColor ?>;"><?= htmlspecialchars($institution['name'] ?? 'Library Management System') ?></h2>
                        <h3 style="margin:5px 0; font-size:18px;">Members Report (Sample)</h3>
                    </div>
                    <?= $logoBase64 ? '<img src="' . $logoBase64 . '" style="height:60px;">' : '' ?>
                </div>
                
                <?php elseif ($reportLogoPosition === 'center'): ?>
                <?= $logoBase64 ? '<div><img src="' . $logoBase64 . '" style="height:60px; margin-bottom:10px;"></div>' : '' ?>
                <h2 style="margin:0; color:<?= $reportPrimaryColor ?>;"><?= htmlspecialchars($institution['name'] ?? 'Library Management System') ?></h2>
                <h3 style="margin:5px 0; font-size:18px;">Members Report (Sample)</h3>
                
                <?php else: ?>
                <h2 style="margin:0; color:<?= $reportPrimaryColor ?>;"><?= htmlspecialchars($institution['name'] ?? 'Library Management System') ?></h2>
                <h3 style="margin:5px 0; font-size:18px;">Members Report (Sample)</h3>
                <?php endif; ?>
                
                <div style="font-size: 11px; margin: 8px 0;"><strong>Period:</strong> <?= date('F 1, Y') ?> to <?= date('F d, Y') ?></div>
                <div style="font-size: 10px; color: #666;">Generated: <?= date('Y-m-d H:i:s') ?></div>
            </div>

            <!-- Sample Table -->
            <table style="width: 100%; border-collapse: collapse; font-size: <?= $reportFontSize ?>px;">
                <thead>
                    <tr style="background-color: <?= $reportPrimaryColor ?>; color: white;">
                        <th style="border: 1px solid #000; padding: 8px; text-align: center;">Sl No</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Adm No</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Name</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Category</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Class</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Division</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: left;">Email</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: center;">Active</th>
                        <th style="border: 1px solid #000; padding: 8px; text-align: right;">Fines</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td style="border: 1px solid #000; padding: 6px; text-align: center;">1</td><td style="border: 1px solid #000; padding: 6px;">LIB001</td><td style="border: 1px solid #000; padding: 6px;">John Doe</td><td style="border: 1px solid #000; padding: 6px;">Student</td><td style="border: 1px solid #000; padding: 6px;">Grade 10</td><td style="border: 1px solid #000; padding: 6px;">A</td><td style="border: 1px solid #000; padding: 6px;">john@example.com</td><td style="border: 1px solid #000; padding: 6px; text-align: center;">3</td><td style="border: 1px solid #000; padding: 6px; text-align: right;">₹ 50.00</td></tr>
                    <tr style="background-color: #f9f9f9;"><td style="border: 1px solid #000; padding: 6px; text-align: center;">2</td><td style="border: 1px solid #000; padding: 6px;">LIB002</td><td style="border: 1px solid #000; padding: 6px;">Jane Smith</td><td style="border: 1px solid #000; padding: 6px;">Teacher</td><td style="border: 1px solid #000; padding: 6px;">Science</td><td style="border: 1px solid #000; padding: 6px;">-</td><td style="border: 1px solid #000; padding: 6px;">jane@example.com</td><td style="border: 1px solid #000; padding: 6px; text-align: center;">2</td><td style="border: 1px solid #000; padding: 6px; text-align: right;">₹ 0.00</td></tr>
                    <tr><td style="border: 1px solid #000; padding: 6px; text-align: center;">3</td><td style="border: 1px solid #000; padding: 6px;">LIB003</td><td style="border: 1px solid #000; padding: 6px;">Mike Johnson</td><td style="border: 1px solid #000; padding: 6px;">Staff</td><td style="border: 1px solid #000; padding: 6px;">Admin</td><td style="border: 1px solid #000; padding: 6px;">-</td><td style="border: 1px solid #000; padding: 6px;">mike@example.com</td><td style="border: 1px solid #000; padding: 6px; text-align: center;">1</td><td style="border: 1px solid #000; padding: 6px; text-align: right;">₹ 25.00</td></tr>
                </tbody>
                <tfoot>
                    <tr style="background-color: #f0f0f0; font-weight: bold;">
                        <td colspan="7" style="border: 1px solid #000; padding: 8px; text-align: right;">Totals:</td>
                        <td style="border: 1px solid #000; padding: 8px; text-align: center;">6</td>
                        <td style="border: 1px solid #000; padding: 8px; text-align: right;">₹ 75.00</td>
                    </tr>
                </tfoot>
            </table>

            <!-- Summary -->
            <div style="margin: 15px 0; padding: 10px; background-color: #f5f5f5; border-left: 4px solid <?= $reportPrimaryColor ?>;">
                <strong>Summary:</strong> Total Records: 3 | Active Books: 6 | Total Fines: ₹ 75.00
            </div>

            <!-- Footer -->
            <div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">
                <?= htmlspecialchars($reportFooterText) ?><br>
                &copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. All rights reserved.
            </div>

            <!-- Signature -->
            <?php if ($reportSignatureEnabled): ?>
            <div style="margin-top: 30px; text-align: right;">
                <?= $signatureBase64 ? '<div><img src="' . $signatureBase64 . '" style="height:50px;"></div>' : '' ?>
                <div><strong><?= htmlspecialchars($reportSignatureName) ?></strong></div>
                <div><?= htmlspecialchars($reportSignatureTitle) ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="alert alert-info no-print mt-3">
        <i class="fas fa-info-circle"></i> 
        <strong>Note:</strong> This is a sample preview. Your actual reports will use your real data with these same settings.
        Click <strong>Print Preview</strong> to see how it looks when printed or saved as PDF.
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php renderFooter(); ?>