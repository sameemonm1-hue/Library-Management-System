<?php
/**
 * Stock Verification Report
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();

// Get filter parameters
$date = $_GET['date'] ?? date('Y-m-d');
$format = $_GET['format'] ?? '';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    // Fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ========== BUILD DATA ==========

// Get verification records for selected date
// Note: table name is 'stock_verifications' (plural) in the original code
$stmt = $db->prepare("SELECT * FROM stock_verifications WHERE verification_date = ? ORDER BY book_barcode");
$stmt->execute([$date]);
$verifications = $stmt->fetchAll();

// Separate missing and extra
$missing = [];
$extra = [];
$missingQty = 0;
$extraQty = 0;

foreach ($verifications as $v) {
    if (strpos($v['discrepancy'] ?? '', 'Missing') !== false) {
        $missing[] = $v;
        if (preg_match('/Missing: (\d+)/', $v['discrepancy'] ?? '', $matches)) {
            $missingQty += (int)$matches[1];
        }
    } else {
        $extra[] = $v;
        if (preg_match('/Extra: (\d+)/', $v['discrepancy'] ?? '', $matches)) {
            $extraQty += (int)$matches[1];
        }
    }
}

$totalMissing = count($missing);
$totalExtra = count($extra);

// ========== EXPORT HANDLING ==========
if ($format === 'excel' || $format === 'pdf') {
    $title = 'Stock Verification Report';
    $filename = 'stock_report_' . $date;
    
    // Build export data with 'Sl No'
    $exportData = [];
    $sn = 1;
    foreach ($missing as $m) {
        preg_match('/Missing: (\d+)/', $m['discrepancy'] ?? '', $matches);
        $count = $matches[1] ?? 0;
        $exportData[] = [
            'Sl No' => $sn++,
            'Barcode' => $m['book_barcode'],
            'System Qty' => $m['system_status'],
            'Physical Qty' => $m['physical_status'],
            'Missing Copies' => $count,
            'Status' => 'Missing',
            'Verified By' => $m['verified_by'] ?? '',
            'Verified At' => isset($m['created_at']) ? formatTime($m['created_at']) : ''
        ];
    }
    foreach ($extra as $e) {
        preg_match('/Extra: (\d+)/', $e['discrepancy'] ?? '', $matches);
        $count = $matches[1] ?? 0;
        $exportData[] = [
            'Sl No' => $sn++,
            'Barcode' => $e['book_barcode'],
            'System Qty' => $e['system_status'],
            'Physical Qty' => $e['physical_status'],
            'Extra Copies' => $count,
            'Status' => 'Extra',
            'Verified By' => $e['verified_by'] ?? '',
            'Verified At' => isset($e['created_at']) ? formatTime($e['created_at']) : ''
        ];
    }
    
    if (empty($exportData)) {
        die("No stock verification records found for the selected date.");
    }
    
    $headers = ['Sl No', 'Barcode', 'System Qty', 'Physical Qty', 'Variance', 'Status', 'Verified By', 'Verified At'];
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .missing-row { background-color: #f8d7da; }
        .extra-row { background-color: #fff3cd; }
    </style>
    </head><body>';
    
    $filters = ['Verification Date' => formatDate($date)];
    $html .= getReportHeaderHTML($title, null, null, $filters);
    
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $isMissing = ($row['Status'] === 'Missing');
        $html .= '<tr class="' . ($isMissing ? 'missing-row' : 'extra-row') . '">';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="5" class="text-right">Total Records:</td>';
    $html .= '<td colspan="3" class="text-center">' . count($exportData) . ' (Missing: ' . $totalMissing . ', Extra: ' . $totalExtra . ')</td>';
    $html .= '</tr></tfoot></table>';
    
    // Summary
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Missing: ' . $totalMissing . ' titles (' . $missingQty . ' copies) | Extra: ' . $totalExtra . ' entries (' . $extraQty . ' copies) | Total Variance: ' . ($missingQty + $extraQty) . ' copies
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    
    if ($format === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title></head><body>' . $html . '</body></html>';
        exit;
    } else {
        exportToPDF($html, $filename . '.pdf', $paperSize, $orientation);
        exit;
    }
}

// ========== ON‑SCREEN DISPLAY ==========

// Get available verification dates
$dates = $db->query("SELECT DISTINCT verification_date FROM stock_verifications ORDER BY verification_date DESC LIMIT 30")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Report - <?= h($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar-custom { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
        .missing-row { background-color: #f8d7da; }
        .extra-row { background-color: #fff3cd; }
        @media print { .no-print { display: none; } }
        .summary-card { transition: all 0.3s; }
        .summary-card:hover { transform: translateY(-5px); }
        .logo-print { max-height: 60px; }
        .settings-info { background: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>cc 100%); color: white; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-custom navbar-dark mb-4 no-print">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="/library-system/">
                <?php if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])): ?>
                    <img src="<?= $settings['library_logo'] ?>" style="height: 35px;" class="me-2">
                <?php else: ?>
                    <i class="fas fa-book-open me-2"></i>
                <?php endif; ?>
                <?= h($settings['software_header'] ?? 'Library ERP System') ?> - Stock Report
            </a>
            <a href="/library-system/reports/" class="btn btn-outline-light btn-sm">← Back to Reports</a>
        </div>
    </nav>
    
    <div class="container">
        <!-- Settings Info Bar -->
        <div class="settings-info no-print">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <i class="fas fa-chart-bar"></i> <strong>Report Settings Active:</strong> 
                    Font Size: <?= $reportFontSize ?>px | 
                    Logo: <?= ucfirst($reportLogoPosition) ?> | 
                    Watermark: <?= $reportWatermarkEnabled ? 'Enabled' : 'Disabled' ?> | 
                    Signature: <?= $reportSignatureEnabled ? 'Enabled' : 'Disabled' ?>
                </div>
                <div class="col-md-4 text-end">
                    <a href="../settings.php#report" class="btn btn-sm btn-light">Configure</a>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header bg-white fw-bold no-print">
                <i class="fas fa-boxes"></i> Stock Verification Report
            </div>
            <div class="card-body">
                <!-- Filters -->
                <form class="row g-3 mb-4 no-print" method="get">
                    <div class="col-md-4">
                        <label class="form-label">Verification Date</label>
                        <select name="date" class="form-select">
                            <?php if (empty($dates)): ?>
                                <option value="<?= $date ?>"><?= formatDate($date) ?> (Current)</option>
                            <?php else: ?>
                                <?php foreach ($dates as $d): ?>
                                    <option value="<?= $d ?>" <?= $date === $d ? 'selected' : '' ?>>
                                        <?= formatDate($d) ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-primary w-100">View Report</button>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">&nbsp;</label>
                        <?php if (!empty($verifications)): ?>
                            <a href="?format=excel&date=<?= $date ?>" class="btn btn-success w-100">
                                <i class="fas fa-file-excel"></i> Export to Excel
                            </a>
                        <?php else: ?>
                            <button class="btn btn-secondary w-100" disabled>
                                <i class="fas fa-file-excel"></i> No Data to Export
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
                
                <!-- Summary Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-danger text-white summary-card">
                            <div class="card-body text-center">
                                <h3><?= $totalMissing ?></h3>
                                <small>Missing Book Titles</small>
                                <p class="small mb-0">Total Missing Copies: <?= $missingQty ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-warning text-dark summary-card">
                            <div class="card-body text-center">
                                <h3><?= $totalExtra ?></h3>
                                <small>Extra Book Entries</small>
                                <p class="small mb-0">Total Extra Copies: <?= $extraQty ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-info text-white summary-card">
                            <div class="card-body text-center">
                                <h3><?= count($verifications) ?></h3>
                                <small>Total Discrepancies</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-secondary text-white summary-card">
                            <div class="card-body text-center">
                                <h3><?= $missingQty + $extraQty ?></h3>
                                <small>Total Copy Variance</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Report Header -->
                <div class="text-center mb-4">
                    <?php $logo = getReportLogo(); if ($logo): ?>
                        <img src="<?= $logo['base64'] ?>" class="logo-print mb-2" style="max-height: 60px;">
                    <?php endif; ?>
                    <h3><?= h(getInstitutionName()) ?></h3>
                    <h5>Stock Verification Report</h5>
                    <p>Verification Date: <?= formatDate($date) ?></p>
                    <?php if (!empty($verifications)): ?>
                        <p>Verified By: <?= h($verifications[0]['verified_by'] ?? 'N/A') ?></p>
                    <?php endif; ?>
                </div>
                
                <?php if (empty($verifications)): ?>
                    <div class="alert alert-info text-center py-5">
                        <i class="fas fa-info-circle fa-3x mb-3"></i>
                        <h5>No stock verification records found for this date.</h5>
                        <p>Please perform a stock verification from the <a href="/library-system/stock/">Stock Verification Module</a>.</p>
                    </div>
                <?php else: ?>
                    
                    <!-- Missing Books -->
                    <?php if (!empty($missing)): ?>
                        <h4 class="text-danger mt-3"><i class="fas fa-exclamation-triangle"></i> Missing Books</h4>
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-hover">
                                <thead class="table-danger">
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Barcode</th>
                                        <th>System Qty</th>
                                        <th>Physical Qty</th>
                                        <th>Missing Copies</th>
                                        <th>Verified By</th>
                                        <th>Verified At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $sn = 1; foreach ($missing as $m): 
                                        preg_match('/Missing: (\d+)/', $m['discrepancy'] ?? '', $matches);
                                        $missingCount = $matches[1] ?? 0;
                                    ?>
                                    <tr class="missing-row">
                                        <td><?= $sn++ ?></td>
                                        <td><code><?= h($m['book_barcode']) ?></code></td>
                                        <td><?= $m['system_status'] ?></td>
                                        <td><?= $m['physical_status'] ?></td>
                                        <td class="text-danger fw-bold"><?= $missingCount ?></td>
                                        <td><?= h($m['verified_by'] ?? '') ?></td>
                                        <td class="datetime-display"><?= isset($m['created_at']) ? formatTime($m['created_at']) : '' ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="table-danger">
                                    <tr class="fw-bold">
                                        <td colspan="4" class="text-end">Total Missing Copies:</td>
                                        <td><?= $missingQty ?></td>
                                        <td colspan="2"></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> No missing books found in this verification.
                        </div>
                    <?php endif; ?>
                    
                    <!-- Extra Books -->
                    <?php if (!empty($extra)): ?>
                        <h4 class="text-warning mt-4"><i class="fas fa-plus-circle"></i> Extra Books (Found in Physical but not in System)</h4>
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-hover">
                                <thead class="table-warning">
                                    <tr>
                                        <th>Sl No</th>
                                        <th>Barcode</th>
                                        <th>System Qty</th>
                                        <th>Physical Qty</th>
                                        <th>Extra Copies</th>
                                        <th>Verified By</th>
                                        <th>Verified At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $sn = 1; foreach ($extra as $e): 
                                        preg_match('/Extra: (\d+)/', $e['discrepancy'] ?? '', $matches);
                                        $extraCount = $matches[1] ?? 0;
                                    ?>
                                    <tr class="extra-row">
                                        <td><?= $sn++ ?></td>
                                        <td><code><?= h($e['book_barcode']) ?></code></td>
                                        <td><?= $e['system_status'] ?></td>
                                        <td><?= $e['physical_status'] ?></td>
                                        <td class="text-warning fw-bold"><?= $extraCount ?></td>
                                        <td><?= h($e['verified_by'] ?? '') ?></td>
                                        <td class="datetime-display"><?= isset($e['created_at']) ? formatTime($e['created_at']) : '' ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot class="table-warning">
                                    <tr class="fw-bold">
                                        <td colspan="4" class="text-end">Total Extra Copies:</td>
                                        <td><?= $extraQty ?></td>
                                        <td colspan="2"></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> No extra books found in this verification.
                        </div>
                    <?php endif; ?>
                    
                    <!-- Summary Message -->
                    <div class="alert alert-secondary mt-3">
                        <strong><i class="fas fa-chart-line"></i> Verification Summary:</strong><br>
                        Total discrepancies found: <?= count($verifications) ?> records.<br>
                        Missing: <?= $totalMissing ?> titles (<?= $missingQty ?> copies) | 
                        Extra: <?= $totalExtra ?> entries (<?= $extraQty ?> copies)
                    </div>
                    
                <?php endif; ?>
                
                <div class="mt-3 no-print">
                    <button onclick="window.print()" class="btn btn-secondary">
                        <i class="fas fa-print"></i> Print Report
                    </button>
                    <a href="/library-system/stock/" class="btn btn-primary float-end">
                        <i class="fas fa-clipboard-list"></i> New Verification
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>