<?php
/**
 * Members Report with Class/Dept and Div/Course filters
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();

$category = $_GET['category'] ?? 'all';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$status = $_GET['status'] ?? 'all';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ==================== BUILD QUERY ====================

$sql = "SELECT admno, name, member_category, class, division, email, phone, active_books, total_issued, total_fines, status 
        FROM members WHERE 1=1";
$params = [];
if ($category !== 'all') { $sql .= " AND member_category = ?"; $params[] = $category; }
if (!empty($class)) { $sql .= " AND class LIKE ?"; $params[] = "%$class%"; }
if (!empty($division)) { $sql .= " AND division LIKE ?"; $params[] = "%$division%"; }
if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
$sql .= " ORDER BY name";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$members = $stmt->fetchAll();

// ==================== EXPORT HANDLING ====================

if ($format === 'excel') {
    $institutionName = getInstitutionName();
    $filters = [
        'Category' => $category === 'all' ? 'All' : $category,
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Status' => $status === 'all' ? 'All' : ucfirst($status)
    ];
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Members Report</title>
    <style>body{font-family:Arial;margin:20px}h2,h3,p{text-align:center}table{margin:0 auto;border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px;text-align:left}th{background:#1e3c72;color:white}</style>
    </head><body>';
    $html .= '<center><h2>' . htmlspecialchars($institutionName) . '</h2><h3>Members Report</h3>';
    foreach ($filters as $label => $value) {
        $html .= '<p><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . '</p>';
    }
    $html .= '<p><b>Generated:</b> ' . date('Y-m-d H:i:s') . '</p><hr></center>';
    $html .= '<table>';
    $html .= '<thead><tr><th>Sl No</th><th>Adm/Mem No</th><th>Name</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Email</th><th>Phone</th><th>Active Books</th><th>Total Issued</th><th>Total Fines</th><th>Status</th></tr></thead><tbody>';
    $sn = 1;
    foreach ($members as $m) {
        $html .= '<tr>';
        $html .= '<td>' . $sn++ . '</td>';
        $html .= '<td>' . h($m['admno']) . '</td>';
        $html .= '<td>' . h($m['name']) . '</td>';
        $html .= '<td>' . h($m['member_category']) . '</td>';
        $html .= '<td>' . h($m['class']) . '</td>';
        $html .= '<td>' . h($m['division']) . '</td>';
        $html .= '<td>' . h($m['email']) . '</td>';
        $html .= '<td>' . h($m['phone']) . '</td>';
        $html .= '<td>' . $m['active_books'] . '</td>';
        $html .= '<td>' . $m['total_issued'] . '</td>';
        $html .= '<td>' . formatCurrency($m['total_fines']) . '</td>';
        $html .= '<td>' . $m['status'] . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color:#f0f0f0;font-weight:bold;"><td colspan="8" align="right">Totals:</td><td>' . array_sum(array_column($members, 'active_books')) . '</td><td>' . array_sum(array_column($members, 'total_issued')) . '</td><td>' . formatCurrency(array_sum(array_column($members, 'total_fines'))) . '</td><td>' . count($members) . ' Members</td></tr></tfoot>';
    $html .= '</table>';
    $html .= '<p align="center"><strong>Summary:</strong> Total Members: ' . count($members) . ' | Active Books: ' . array_sum(array_column($members, 'active_books')) . ' | Total Issued: ' . array_sum(array_column($members, 'total_issued')) . ' | Total Fines: ' . formatCurrency(array_sum(array_column($members, 'total_fines'))) . '</p>';
    $html .= '<p align="center">This is a system generated report.</p></body></html>';
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="members_report_' . date('Y-m-d') . '.xls"');
    echo $html;
    exit;
}

if ($format === 'pdf') {
    $institutionName = getInstitutionName();
    $filters = [
        'Category' => $category === 'all' ? 'All' : $category,
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Status' => $status === 'all' ? 'All' : ucfirst($status)
    ];
    $exportData = [];
    $sn = 1;
    foreach ($members as $m) {
        $exportData[] = [
            'Sl No' => $sn++,
            'Adm/Mem No' => $m['admno'],
            'Name' => $m['name'],
            'Category' => $m['member_category'],
            'Class/Dept' => $m['class'],
            'Div/Course' => $m['division'],
            'Email' => $m['email'],
            'Phone' => $m['phone'],
            'Active Books' => $m['active_books'],
            'Total Issued' => $m['total_issued'],
            'Total Fines' => formatCurrency($m['total_fines']),
            'Status' => $m['status']
        ];
    }
    $headers = ['Sl No', 'Adm/Mem No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Email', 'Phone', 'Active Books', 'Total Issued', 'Total Fines', 'Status'];
    $title = 'Members Report';
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
    </style>
    </head><body>';
    $html .= getReportHeaderHTML($title, null, null, $filters);
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="8" class="text-right">Totals:</td>';
    $html .= '<td class="text-center">' . array_sum(array_column($members, 'active_books')) . '</td>';
    $html .= '<td class="text-center">' . array_sum(array_column($members, 'total_issued')) . '</td>';
    $html .= '<td class="text-right">' . formatCurrency(array_sum(array_column($members, 'total_fines'))) . '</td>';
    $html .= '<td class="text-center">' . count($members) . ' Members</td>';
    $html .= '</tr></tfoot></table>';
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total Members: ' . count($members) . ' | Active Books: ' . array_sum(array_column($members, 'active_books')) . ' | Total Issued: ' . array_sum(array_column($members, 'total_issued')) . ' | Total Fines: ' . formatCurrency(array_sum(array_column($members, 'total_fines'))) . '
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    exportToPDF($html, 'members_report_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
    exit;
}

// ==================== ON‑SCREEN DISPLAY ====================
$categories = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Members Report - <?= h($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .container { max-width: 1400px; margin-top: 20px; }
        .filter-bar-logo { height: 40px; width: auto; max-width: 120px; object-fit: contain; }
        .filter-bar-icon { font-size: 32px; color: #1e3c72; }
        @media (max-width: 768px) {
            .filter-bar-logo { height: 30px; }
            .filter-bar-icon { font-size: 24px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold py-2"><i class="fas fa-users"></i> Members Report</div>
            <div class="card-body">
                <form method="get" class="mb-4">
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <div class="flex-shrink-0">
                            <?php if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])): ?>
                                <img src="<?= $settings['library_logo'] ?>" class="filter-bar-logo" alt="Logo">
                            <?php else: ?>
                                <i class="fas fa-university filter-bar-icon"></i>
                            <?php endif; ?>
                        </div>
                        <div style="min-width:130px;"><label class="small mb-0">Category</label><select name="category" class="form-select form-select-sm">
                            <option value="all">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= h($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
                            <?php endforeach; ?>
                        </select></div>
                        <div style="min-width:130px;"><label class="small mb-0">Class/Dept</label><input type="text" name="class" class="form-control form-control-sm" value="<?= h($class) ?>"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Div/Course</label><input type="text" name="division" class="form-control form-control-sm" value="<?= h($division) ?>"></div>
                        <div style="min-width:110px;"><label class="small mb-0">Status</label><select name="status" class="form-select form-select-sm">
                            <option value="all">All</option>
                            <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select></div>
                        <div style="min-width:110px;"><label class="small mb-0">Paper Size</label><select name="paper_size" class="form-select form-select-sm">
                            <option value="A4" <?= $paperSize=='A4'?'selected':''?>>A4</option>
                            <option value="Letter" <?= $paperSize=='Letter'?'selected':''?>>Letter</option>
                            <option value="Legal" <?= $paperSize=='Legal'?'selected':''?>>Legal</option>
                            <option value="A3" <?= $paperSize=='A3'?'selected':''?>>A3</option>
                        </select></div>
                        <div style="min-width:110px;"><label class="small mb-0">Orientation</label><select name="orientation" class="form-select form-select-sm">
                            <option value="landscape" <?= $orientation=='landscape'?'selected':''?>>Landscape</option>
                            <option value="portrait" <?= $orientation=='portrait'?'selected':''?>>Portrait</option>
                        </select></div>
                        <div><button type="submit" class="btn btn-primary btn-sm">Filter</button></div>
                        <div><a href="?format=excel&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= urlencode($status) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-success btn-sm">Excel</a></div>
                        <div><a href="?format=pdf&category=<?= urlencode($category) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= urlencode($status) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-danger btn-sm">PDF</a></div>
                        <div><button type="button" onclick="window.print()" class="btn btn-secondary btn-sm">Print</button></div>
                        <div class="flex-shrink-0"><i class="fas fa-book-open filter-bar-icon"></i></div>
                    </div>
                </form>
                
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm">
                        <thead class="table-dark">
                            <tr><th>Sl No</th><th>Adm/Mem No</th><th>Name</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Email</th><th>Phone</th><th>Active Books</th><th>Total Issued</th><th>Total Fines</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php $sn = 1; foreach ($members as $m): ?>
                            <tr><td><?= $sn++ ?></td><td><?= h($m['admno']) ?></td><td><?= h($m['name']) ?></td>
                            <td><?= h($m['member_category']) ?></td><td><?= h($m['class']) ?></td><td><?= h($m['division']) ?></td>
                            <td><?= h($m['email']) ?></td><td><?= h($m['phone']) ?></td>
                            <td><?= $m['active_books'] ?></td><td><?= $m['total_issued'] ?></td>
                            <td><?= formatCurrency($m['total_fines']) ?></td><td><?= ucfirst($m['status']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot class="table-light"><tr class="fw-bold"><td colspan="8" class="text-end">Total:</td>
                        <td><?= array_sum(array_column($members, 'active_books')) ?></td>
                        <td><?= array_sum(array_column($members, 'total_issued')) ?></td>
                        <td><?= formatCurrency(array_sum(array_column($members, 'total_fines'))) ?></td>
                        <td><?= count($members) ?> Members</td></tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>