<?php
/**
 * eBooks Report Module
 * Version: 1.1 - UNIFIED GRADIENT COLORS
 * 
 * Comprehensive report for eBooks with advanced filtering and export options
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// ==================== CONSTANTS ====================
// Check if constant is already defined before defining it
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}
if (!defined('EBOOK_DIR')) {
    define('EBOOK_DIR', BASE_PATH . '/uploads/ebooks/');
}
if (!defined('EBOOK_COVER_DIR')) {
    define('EBOOK_COVER_DIR', BASE_PATH . '/uploads/ebook_covers/');
}

// ==================== CONFIGURATION ====================
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$subject = isset($_GET['subject']) ? trim($_GET['subject']) : '';
$author = isset($_GET['author']) ? trim($_GET['author']) : '';
$publisher = isset($_GET['publisher']) ? trim($_GET['publisher']) : '';
$format = isset($_GET['format']) ? trim($_GET['format']) : '';
$yearFrom = isset($_GET['year_from']) ? (int)$_GET['year_from'] : 0;
$yearTo = isset($_GET['year_to']) ? (int)$_GET['year_to'] : 0;
$minDownloads = isset($_GET['min_downloads']) ? (int)$_GET['min_downloads'] : 0;
$sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'title';
$sortOrder = isset($_GET['sort_order']) && strtoupper($_GET['sort_order']) === 'DESC' ? 'DESC' : 'ASC';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// Export parameters
$exportFormat = isset($_GET['export']) ? $_GET['export'] : '';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

// ==================== HELPER FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function getCurrencySymbol($code = null) {
    if ($code === null) {
        $settings = getSettings();
        $code = $settings['currency_code'] ?? 'INR';
    }
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function formatCurrency($amount, $withSymbol = true) {
    $settings = getSettings();
    $symbol = getCurrencySymbol();
    $code = $settings['currency_code'] ?? 'INR';
    $position = $settings['currency_position'] ?? 'left';
    $decimals = (int)($settings['currency_decimal_places'] ?? 2);
    $formatted = number_format((float)$amount, $decimals);
    if ($withSymbol) {
        return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . $code;
    }
    return $formatted;
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date)) return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}

function getCoverBase64($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) {
        return $coverPath;
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) {
        return '';
    }
    $data = @file_get_contents($fullPath);
    if ($data === false) {
        return '';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getFormatBadge($format) {
    $colors = [
        'pdf' => 'danger',
        'epub' => 'primary',
        'mobi' => 'secondary',
        'doc' => 'info',
        'docx' => 'info',
        'txt' => 'warning'
    ];
    $color = $colors[$format] ?? 'secondary';
    return '<span class="badge bg-' . $color . '">' . strtoupper(htmlspecialchars($format)) . '</span>';
}

// ==================== IMAGE / LOGO FUNCTIONS ====================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// ==================== EXPORT FUNCTIONS ====================

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { error_log("mPDF error: " . $e->getMessage()); }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { error_log("DomPDF error: " . $e->getMessage()); }
    }

    // Ultimate fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToExcel($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            
            $sheet->setCellValue('A1', 'eBooks Report');
            $sheet->mergeCells('A1:M1');
            $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
            $sheet->setCellValue('A2', 'Generated: ' . date('Y-m-d H:i:s'));
            $sheet->mergeCells('A2:M2');
            
            $row = 4;
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . $row, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A4:' . $col . $row)->getFont()->setBold(true);
            
            $row = 5;
            foreach ($data as $rowData) {
                $col = 'A';
                foreach ($rowData as $value) {
                    if (is_numeric($value) && $value > 1000) {
                        $sheet->setCellValue($col . $row, $value);
                    } else {
                        $sheet->setCellValue($col . $row, $value);
                    }
                    $col++;
                }
                $row++;
            }
            
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) { error_log("Excel export error: " . $e->getMessage()); }
    }
    
    exportToCSV($data, $headers, $filename);
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['# ' . getInstitutionName()]);
    fputcsv($out, ['# Generated: ' . date('Y-m-d H:i:s')]);
    fputcsv($out, ['#']);
    fputcsv($out, $headers);
    foreach ($data as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
    exit;
}

// ==================== BUILD QUERY ====================

$sql = "SELECT * FROM ebooks WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR publisher LIKE ? OR description LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like, $like]);
}

if (!empty($subject)) {
    $sql .= " AND subject LIKE ?";
    $params[] = "%$subject%";
}

if (!empty($author)) {
    $sql .= " AND author LIKE ?";
    $params[] = "%$author%";
}

if (!empty($publisher)) {
    $sql .= " AND publisher LIKE ?";
    $params[] = "%$publisher%";
}

if (!empty($format)) {
    $sql .= " AND format = ?";
    $params[] = $format;
}

if ($yearFrom > 0) {
    $sql .= " AND year >= ?";
    $params[] = (string)$yearFrom;
}

if ($yearTo > 0) {
    $sql .= " AND year <= ?";
    $params[] = (string)$yearTo;
}

if ($minDownloads > 0) {
    $sql .= " AND downloads >= ?";
    $params[] = $minDownloads;
}

$allowedSort = ['title', 'author', 'publisher', 'year', 'format', 'downloads', 'created_at'];
if (!in_array($sortBy, $allowedSort)) $sortBy = 'title';
$sortOrder = strtoupper($sortOrder) === 'DESC' ? 'DESC' : 'ASC';
$sql .= " ORDER BY $sortBy $sortOrder LIMIT ? OFFSET ?";

$params[] = $limit;
$params[] = $offset;

$stmt = $db->prepare($sql);
$stmt->execute($params);
$ebooks = $stmt->fetchAll();

// Count query
$countSql = "SELECT COUNT(*) FROM ebooks WHERE 1=1";
$countParams = [];

if (!empty($search)) {
    $countSql .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR publisher LIKE ? OR description LIKE ?)";
    $like = "%$search%";
    $countParams = array_merge($countParams, [$like, $like, $like, $like, $like]);
}

if (!empty($subject)) {
    $countSql .= " AND subject LIKE ?";
    $countParams[] = "%$subject%";
}

if (!empty($author)) {
    $countSql .= " AND author LIKE ?";
    $countParams[] = "%$author%";
}

if (!empty($publisher)) {
    $countSql .= " AND publisher LIKE ?";
    $countParams[] = "%$publisher%";
}

if (!empty($format)) {
    $countSql .= " AND format = ?";
    $countParams[] = $format;
}

if ($yearFrom > 0) {
    $countSql .= " AND year >= ?";
    $countParams[] = (string)$yearFrom;
}

if ($yearTo > 0) {
    $countSql .= " AND year <= ?";
    $countParams[] = (string)$yearTo;
}

if ($minDownloads > 0) {
    $countSql .= " AND downloads >= ?";
    $countParams[] = $minDownloads;
}

$stmt = $db->prepare($countSql);
$stmt->execute($countParams);
$totalRecords = (int)$stmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Statistics
$totalEbooks = $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn() ?: 0;
$totalDownloads = $db->query("SELECT SUM(downloads) FROM ebooks")->fetchColumn() ?: 0;
$totalSize = $db->query("SELECT SUM(file_size) FROM ebooks")->fetchColumn() ?: 0;
$totalViews = $db->query("SELECT SUM(views) FROM ebooks")->fetchColumn() ?: 0;

// Distinct values for filters
$subjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject")->fetchAll(PDO::FETCH_COLUMN);
$authors = $db->query("SELECT DISTINCT author FROM ebooks WHERE author IS NOT NULL AND author != '' ORDER BY author")->fetchAll(PDO::FETCH_COLUMN);
$publishers = $db->query("SELECT DISTINCT publisher FROM ebooks WHERE publisher IS NOT NULL AND publisher != '' ORDER BY publisher")->fetchAll(PDO::FETCH_COLUMN);
$formats = $db->query("SELECT DISTINCT format FROM ebooks WHERE format IS NOT NULL AND format != '' ORDER BY format")->fetchAll(PDO::FETCH_COLUMN);
$years = $db->query("SELECT DISTINCT year FROM ebooks WHERE year IS NOT NULL AND year != '' ORDER BY year DESC")->fetchAll(PDO::FETCH_COLUMN);

// ==================== EXPORT HANDLER ====================

if (isset($_GET['export'])) {
    $exportData = [];
    $sn = 1;
    foreach ($ebooks as $ebook) {
        $exportData[] = [
            'Sl No' => $sn++,
            'Title' => $ebook['title'] ?? 'Untitled',
            'Author' => $ebook['author'] ?? 'Unknown',
            'Subject' => $ebook['subject'] ?? 'Uncategorized',
            'Publisher' => $ebook['publisher'] ?? '-',
            'Year' => $ebook['year'] ?? '-',
            'Format' => strtoupper($ebook['format'] ?? 'pdf'),
            'Language' => $ebook['language'] ?? '-',
            'Pages' => $ebook['pages'] ?? 0,
            'File Size' => $ebook['file_size'] ? formatFileSize($ebook['file_size']) : '-',
            'Downloads' => $ebook['downloads'] ?? 0,
            'Storage' => $ebook['storage_type'] ?? 'local',
            'Source' => $ebook['metadata_source'] ?? '-'
        ];
    }
    
    $headers = ['Sl No', 'Title', 'Author', 'Subject', 'Publisher', 'Year', 'Format', 'Language', 'Pages', 'File Size', 'Downloads', 'Storage', 'Source'];
    $filename = 'ebooks_report_' . date('Y-m-d');
    $exportFormat = $_GET['export'];
    
    if ($exportFormat === 'pdf') {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>eBooks Report</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
        </style>
        </head><body>';
        
        $html .= getReportHeaderHTML('eBooks Report', null, null, [
            'Search' => $search ?: 'None',
            'Subject' => $subject ?: 'All',
            'Author' => $author ?: 'All',
            'Year Range' => ($yearFrom && $yearTo) ? $yearFrom . ' - ' . $yearTo : 'All'
        ]);
        $html .= '<table><thead><tr>';
        foreach ($headers as $header) {
            $html .= '<th>' . htmlspecialchars($header) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        
        foreach ($exportData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                    $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
                } elseif (is_numeric($value)) {
                    $html .= '<td class="text-right">' . $value . '</td>';
                } else {
                    $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                }
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
        $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
            <strong>Summary:</strong> 
            Total eBooks: ' . $totalEbooks . ' | 
            Total Downloads: ' . $totalDownloads . ' | 
            Total Size: ' . formatFileSize($totalSize) . '
        </div>';
        $html .= getReportFooterHTML();
        $html .= '</body></html>';
        
        exportToPDF($html, $filename . '.pdf', $paperSize, $orientation);
    } elseif ($exportFormat === 'excel') {
        exportToExcel($exportData, $headers, $filename);
    } else {
        exportToCSV($exportData, $headers, $filename);
    }
    exit;
}

// ==================== RENDER ====================
renderHeader('eBooks Report');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eBooks Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        
        /* ========== SETTINGS BAR - UNIFIED ========== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        
        /* ========== STAT CARDS - UNIFIED GRADIENT ========== */
        .stat-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 12px;
            cursor: default;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card .stat-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 15px;
            top: 15px;
            color: white;
        }
        .stat-card .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: white;
        }
        .stat-card .stat-label {
            font-size: 0.85rem;
            opacity: 0.9;
            color: rgba(255,255,255,0.95);
        }
        .stat-card .card-body {
            position: relative;
            z-index: 1;
        }
        .stat-card.bg-primary { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-warning { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-info { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-secondary { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        
        .filter-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .logo-preview { max-height: 40px; width: auto; object-fit: contain; background: white; padding: 2px 6px; border-radius: 4px; }
        .settings-preview-card {
            background: white; border-radius: 12px; padding: 12px 18px; margin-bottom: 16px;
            border-left: 3px solid <?= $reportPrimaryColor ?>;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05); font-size: 0.75rem;
        }
        .cover-thumb { width: 50px; height: 65px; object-fit: cover; border-radius: 6px; border: 2px solid #e9ecef; background: #f8f9fa; }
        .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--primary-dark); border-color: var(--primary-dark); }
        .pagination .page-link { color: var(--primary-color); }
        .pagination .page-item.active .page-link {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .card-header.bg-report { background: var(--primary-color); color: white; border-bottom: none; }
        .table thead th { background: var(--primary-color); color: white; }
        
        @media (max-width: 768px) {
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
        }
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .settings-preview-card { display: none !important; }
            .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .stat-card .stat-number { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-icon { display: none !important; }
            .table thead th { background: #333 !important; color: white !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color);"><i class="fas fa-file-pdf text-danger"></i> eBooks Report</h2>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="books_titles_summary.php" class="btn btn-primary btn-sm"><i class="fas fa-book-open"></i> Books Summary</a>
            <a href="books.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-book"></i> Books Report</a>
            <button class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            <button class="btn btn-success btn-sm" onclick="exportReport('excel')"><i class="fas fa-file-excel"></i> Excel</button>
            <button class="btn btn-danger btn-sm" onclick="exportReport('pdf')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>

    <!-- ========== SETTINGS BAR - UNIFIED ========== -->
    <div class="settings-bar no-print">
        <div class="settings-items-wrap">
            <span class="settings-label"><i class="fas fa-sliders-h"></i> Settings:</span>
            <span class="settings-item"><i class="fas fa-font"></i> <?= $reportFontSize ?>px</span>
            <span class="settings-item"><i class="fas fa-image"></i> <?= ucfirst($reportLogoPosition) ?></span>
            <span class="settings-item"><i class="fas fa-tint"></i> <?= $reportWatermarkEnabled ? 'On' : 'Off' ?></span>
            <span class="settings-item"><i class="fas fa-signature"></i> <?= $reportSignatureEnabled ? 'On' : 'Off' ?></span>
        </div>
        <a href="../settings.php#report"><i class="fas fa-cog"></i> Configure</a>
    </div>

    <!-- Logo Preview -->
    <?php
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    if ($mainLogo || $rightLogo):
    ?>
    <div class="settings-preview-card no-print">
        <div class="d-flex align-items-center gap-3 flex-wrap">
            <strong><i class="fas fa-image"></i> Logo:</strong>
            <?php if ($mainLogo): ?>
                <img src="<?= $mainLogo['base64'] ?>" class="logo-preview" alt="Logo">
            <?php endif; ?>
            <?php if ($rightLogo): ?>
                <span><strong>Right:</strong></span>
                <img src="<?= $rightLogo['base64'] ?>" class="logo-preview" alt="Right Logo">
            <?php endif; ?>
            <span class="text-muted" style="font-size:0.6rem;">Position: <?= ucfirst($reportLogoPosition) ?></span>
        </div>
    </div>
    <?php endif; ?>

    <!-- Statistics - UNIFIED GRADIENT -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="card stat-card bg-primary text-white"><div class="card-body"><div class="stat-number"><?= number_format($totalEbooks) ?></div><div class="stat-label">Total eBooks</div></div></div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card bg-warning text-white"><div class="card-body"><div class="stat-number"><?= number_format($totalDownloads) ?></div><div class="stat-label">Total Downloads</div></div></div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card bg-info text-white"><div class="card-body"><div class="stat-number"><?= formatFileSize($totalSize) ?></div><div class="stat-label">Total Size</div></div></div>
        </div>
        <div class="col-md-3 col-6">
            <div class="card stat-card bg-secondary text-white"><div class="card-body"><div class="stat-number"><?= number_format($totalViews) ?></div><div class="stat-label">Total Views</div></div></div>
        </div>
    </div>

    <!-- Filters -->
    <div class="filter-card no-print">
        <form method="GET" id="filterForm">
            <div class="row g-2">
                <div class="col-md-3"><input type="text" name="search" class="form-control form-control-sm" placeholder="Search title, author, subject..." value="<?= htmlspecialchars($search) ?>"></div>
                <div class="col-md-2">
                    <select name="subject" class="form-select form-select-sm">
                        <option value="">All Subjects</option>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= htmlspecialchars($s) ?>" <?= $subject == $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="author" class="form-select form-select-sm">
                        <option value="">All Authors</option>
                        <?php foreach ($authors as $a): ?>
                            <option value="<?= htmlspecialchars($a) ?>" <?= $author == $a ? 'selected' : '' ?>><?= htmlspecialchars($a) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="format" class="form-select form-select-sm">
                        <option value="">All Formats</option>
                        <?php foreach ($formats as $f): ?>
                            <option value="<?= htmlspecialchars($f) ?>" <?= $format == $f ? 'selected' : '' ?>><?= strtoupper(htmlspecialchars($f)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-1">
                    <select name="year_from" class="form-select form-select-sm">
                        <option value="0">From</option>
                        <?php foreach ($years as $y): ?>
                            <option value="<?= $y ?>" <?= $yearFrom == $y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-1">
                    <select name="year_to" class="form-select form-select-sm">
                        <option value="0">To</option>
                        <?php foreach ($years as $y): ?>
                            <option value="<?= $y ?>" <?= $yearTo == $y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-1">
                    <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-search"></i></button>
                </div>
                <div class="col-md-1">
                    <a href="ebooks.php" class="btn btn-secondary btn-sm w-100"><i class="fas fa-undo"></i></a>
                </div>
            </div>
            <div class="row g-2 mt-2">
                <div class="col-auto">
                    <label class="form-label small">Min Downloads</label>
                    <select name="min_downloads" class="form-select form-select-sm">
                        <option value="0">All</option>
                        <option value="1" <?= $minDownloads == 1 ? 'selected' : '' ?>>1+</option>
                        <option value="5" <?= $minDownloads == 5 ? 'selected' : '' ?>>5+</option>
                        <option value="10" <?= $minDownloads == 10 ? 'selected' : '' ?>>10+</option>
                        <option value="50" <?= $minDownloads == 50 ? 'selected' : '' ?>>50+</option>
                        <option value="100" <?= $minDownloads == 100 ? 'selected' : '' ?>>100+</option>
                    </select>
                </div>
                <div class="col-auto">
                    <label class="form-label small">Sort By</label>
                    <select name="sort_by" class="form-select form-select-sm">
                        <option value="title" <?= $sortBy == 'title' ? 'selected' : '' ?>>Title</option>
                        <option value="author" <?= $sortBy == 'author' ? 'selected' : '' ?>>Author</option>
                        <option value="publisher" <?= $sortBy == 'publisher' ? 'selected' : '' ?>>Publisher</option>
                        <option value="year" <?= $sortBy == 'year' ? 'selected' : '' ?>>Year</option>
                        <option value="downloads" <?= $sortBy == 'downloads' ? 'selected' : '' ?>>Downloads</option>
                    </select>
                </div>
                <div class="col-auto">
                    <label class="form-label small">Order</label>
                    <select name="sort_order" class="form-select form-select-sm">
                        <option value="ASC" <?= $sortOrder == 'ASC' ? 'selected' : '' ?>>Ascending</option>
                        <option value="DESC" <?= $sortOrder == 'DESC' ? 'selected' : '' ?>>Descending</option>
                    </select>
                </div>
                <div class="col-auto">
                    <label class="form-label small">Per Page</label>
                    <select name="limit" class="form-select form-select-sm">
                        <option value="25" <?= $limit == 25 ? 'selected' : '' ?>>25</option>
                        <option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option>
                        <option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option>
                        <option value="200" <?= $limit == 200 ? 'selected' : '' ?>>200</option>
                    </select>
                </div>
            </div>
        </form>
    </div>

    <!-- Results -->
    <div class="card">
        <div class="card-header bg-report fw-bold py-2 d-flex justify-content-between align-items-center">
            <span><i class="fas fa-file-pdf"></i> eBooks List</span>
            <span><?= number_format($totalRecords) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="table-dark" style="background: var(--primary-color); color: white;">
                        <tr>
                            <th>#</th>
                            <th>Cover</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Subject</th>
                            <th>Publisher</th>
                            <th>Year</th>
                            <th>Format</th>
                            <th>Language</th>
                            <th>Pages</th>
                            <th>File Size</th>
                            <th>Downloads</th>
                            <th>Storage</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($ebooks)): ?>
                            <tr><td colspan="14" class="text-center py-4 text-muted">No eBooks found.</td></tr>
                        <?php else: ?>
                            <?php $sn = ($page-1)*$limit+1; foreach ($ebooks as $ebook): 
                                $coverBase64 = getCoverBase64($ebook['cover_path'] ?? '');
                            ?>
                            <tr>
                                <td class="text-center"><?= $sn++ ?></td>
                                <td class="text-center">
                                    <?php if ($coverBase64): ?>
                                        <img src="<?= $coverBase64 ?>" class="cover-thumb" alt="Cover" 
                                             onerror="this.onerror=null;this.style.display='none';">
                                    <?php else: ?>
                                        <div class="cover-thumb d-flex align-items-center justify-content-center bg-light">
                                            <i class="fas fa-file-pdf text-danger"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?= htmlspecialchars($ebook['title'] ?? 'Untitled') ?></strong></td>
                                <td><?= htmlspecialchars($ebook['author'] ?? 'Unknown') ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($ebook['subject'] ?? 'Uncategorized') ?></span></td>
                                <td><?= htmlspecialchars($ebook['publisher'] ?? '-') ?></td>
                                <td class="text-center"><?= htmlspecialchars($ebook['year'] ?? '-') ?></td>
                                <td class="text-center"><?= getFormatBadge($ebook['format'] ?? 'pdf') ?></td>
                                <td><?= htmlspecialchars($ebook['language'] ?? '-') ?></td>
                                <td class="text-center"><?= $ebook['pages'] ?? 0 ?></td>
                                <td><?= $ebook['file_size'] ? formatFileSize($ebook['file_size']) : '-' ?></td>
                                <td class="text-center"><span class="badge bg-primary"><?= $ebook['downloads'] ?? 0 ?></span></td>
                                <td><span class="badge bg-<?= ($ebook['storage_type'] ?? 'local') === 'cloud' ? 'info' : 'secondary' ?>"><?= ucfirst($ebook['storage_type'] ?? 'local') ?></span></td>
                                <td class="text-center">
                                    <a href="download.php?id=<?= $ebook['id'] ?>" class="btn btn-sm btn-success"><i class="fas fa-download"></i></a>
                                    <a href="edit.php?id=<?= $ebook['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                    <a href="delete.php?id=<?= $ebook['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this eBook?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($ebooks)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="11" class="text-end">Totals:</td>
                            <td class="text-center"><?= array_sum(array_column($ebooks, 'downloads')) ?></td>
                            <td colspan="2"></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($totalRecords > $limit): ?>
    <div class="d-flex justify-content-center mt-3 no-print">
        <nav>
            <ul class="pagination">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page-1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Previous</a>
                </li>
                <?php for ($p = max(1, $page-2); $p <= min($totalPages, $page+2); $p++): ?>
                    <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?page=<?= $p ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?page=<?= $page+1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function exportReport(format) {
    const url = new URL(window.location.href);
    url.searchParams.set('export', format);
    window.location.href = url.toString();
}
</script>

<?php renderFooter(); ?>