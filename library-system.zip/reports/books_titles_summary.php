<?php
/**
 * Books & eBooks Titles Summary Module
 * Version: 3.4 - Unified Gradient Cards
 * 
 * This module provides a unified view of books and eBooks with:
 * - Advanced filtering (type, category, subject, author, publisher, year range, cover status)
 * - Statistics dashboard with gradient cards
 * - Export to CSV, Excel, PDF with full report settings
 * - Cover thumbnails with preview
 * - Pagination with customizable items per page
 * - Responsive design
 * - Integration with report settings (logo, watermark, signature)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// ==================== CONFIGURATION ====================
$itemsPerPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 20;
$itemsPerPage = in_array($itemsPerPage, [10, 20, 50, 100]) ? $itemsPerPage : 20;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $itemsPerPage;

// ==================== FILTERS ====================
$typeFilter = isset($_GET['type']) ? $_GET['type'] : 'both';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$subject = isset($_GET['subject']) ? trim($_GET['subject']) : '';
$author = isset($_GET['author']) ? trim($_GET['author']) : '';
$publisher = isset($_GET['publisher']) ? trim($_GET['publisher']) : '';
$yearFrom = isset($_GET['year_from']) ? (int)$_GET['year_from'] : 0;
$yearTo = isset($_GET['year_to']) ? (int)$_GET['year_to'] : 0;
$sortBy = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'title';
$sortOrder = isset($_GET['sort_order']) && strtoupper($_GET['sort_order']) === 'DESC' ? 'DESC' : 'ASC';
$hasCover = isset($_GET['has_cover']) ? (int)$_GET['has_cover'] : -1;
$format = isset($_GET['format']) ? $_GET['format'] : '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// ==================== ALLOWED SORT FIELDS ====================
$allowedSortFields = ['title', 'author', 'publisher', 'year', 'category', 'subject', 'created_at', 'total_copies', 'available_copies'];
if (!in_array($sortBy, $allowedSortFields)) {
    $sortBy = 'title';
}

// ==================== HELPER FUNCTIONS ====================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}

function getCoverBase64($coverPath) {
    if (empty($coverPath)) {
        return '';
    }
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) {
        return $coverPath;
    }
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) {
        return '';
    }
    $data = @file_get_contents($fullPath);
    if ($data === false) {
        return '';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

function getStatusBadge($available, $total) {
    if ($total <= 0) {
        return '<span class="badge bg-secondary">No copies</span>';
    }
    if ($available > 0) {
        return '<span class="badge bg-success">Available (' . $available . '/' . $total . ')</span>';
    }
    return '<span class="badge bg-danger">All Issued</span>';
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $institutionName = getInstitutionName();
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// EXPORT FUNCTIONS
// =============================================================================

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { error_log("mPDF error: " . $e->getMessage()); }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { error_log("DomPDF error: " . $e->getMessage()); }
    }

    // Ultimate fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToExcel($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            
            $sheet->setCellValue('A1', 'Books & eBooks Summary');
            $sheet->mergeCells('A1:M1');
            $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
            $sheet->setCellValue('A2', 'Generated: ' . date('Y-m-d H:i:s'));
            $sheet->mergeCells('A2:M2');
            
            $row = 4;
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . $row, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A4:' . $col . $row)->getFont()->setBold(true);
            
            $row = 5;
            foreach ($data as $rowData) {
                $col = 'A';
                foreach ($rowData as $value) {
                    if (is_numeric($value) && $value > 1000) {
                        $sheet->setCellValue($col . $row, $value);
                    } else {
                        $sheet->setCellValue($col . $row, $value);
                    }
                    $col++;
                }
                $row++;
            }
            
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) { error_log("Excel export error: " . $e->getMessage()); }
    }
    
    exportToCSV($data, $headers, $filename);
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['# ' . getInstitutionName()]);
    fputcsv($out, ['# Generated: ' . date('Y-m-d H:i:s')]);
    fputcsv($out, ['#']);
    fputcsv($out, $headers);
    foreach ($data as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
    exit;
}

// =============================================================================
// BUILD QUERY
// =============================================================================

// Base queries for books and ebooks
$bookQuery = "SELECT 
    'book' AS item_type,
    id,
    barcode AS identifier,
    title,
    author,
    publisher,
    year,
    category,
    subject,
    cover_path,
    created_at,
    quantity AS total_copies,
    available AS available_copies,
    NULL AS file_size,
    NULL AS downloads,
    NULL AS language,
    '' AS edition,
    '' AS format,
    'Book' AS type_label,
    source,
    CASE WHEN cover_path IS NOT NULL AND cover_path != '' THEN 1 ELSE 0 END AS has_cover,
    'Book' AS display_type
FROM books 
WHERE 1=1 AND (status != 'Deleted' OR status IS NULL)";

$ebookQuery = "SELECT 
    'ebook' AS item_type,
    id,
    id AS identifier,
    title,
    author,
    publisher,
    year,
    subject AS category,
    subject,
    cover_path,
    created_at,
    1 AS total_copies,
    CASE WHEN file_path IS NOT NULL AND file_path != '' THEN 1 ELSE 0 END AS available_copies,
    file_size,
    downloads,
    language,
    edition,
    format,
    'eBook' AS type_label,
    metadata_source AS source,
    CASE WHEN cover_path IS NOT NULL AND cover_path != '' THEN 1 ELSE 0 END AS has_cover,
    'eBook' AS display_type
FROM ebooks 
WHERE 1=1";

// Build WHERE clauses
$whereClauses = [];
$params = [];

// Search filter
if (!empty($search)) {
    $searchTerm = '%' . $search . '%';
    $whereClauses[] = "(title LIKE ? OR author LIKE ? OR subject LIKE ? OR publisher LIKE ? OR category LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Type filter
if ($typeFilter === 'books') {
    $whereClauses[] = "item_type = 'book'";
} elseif ($typeFilter === 'ebooks') {
    $whereClauses[] = "item_type = 'ebook'";
}

// Category/Subject filter
if (!empty($category)) {
    $whereClauses[] = "(category = ? OR subject = ?)";
    $params[] = $category;
    $params[] = $category;
}

if (!empty($subject)) {
    $whereClauses[] = "subject = ?";
    $params[] = $subject;
}

if (!empty($author)) {
    $whereClauses[] = "author LIKE ?";
    $params[] = '%' . $author . '%';
}

if (!empty($publisher)) {
    $whereClauses[] = "publisher LIKE ?";
    $params[] = '%' . $publisher . '%';
}

if ($yearFrom > 0) {
    $whereClauses[] = "year >= ?";
    $params[] = (string)$yearFrom;
}

if ($yearTo > 0) {
    $whereClauses[] = "year <= ?";
    $params[] = (string)$yearTo;
}

if ($hasCover === 0) {
    $whereClauses[] = "(cover_path IS NULL OR cover_path = '')";
} elseif ($hasCover === 1) {
    $whereClauses[] = "(cover_path IS NOT NULL AND cover_path != '')";
}

$whereSQL = !empty($whereClauses) ? ' AND ' . implode(' AND ', $whereClauses) : '';

// Count queries
$countBookSQL = "SELECT COUNT(*) FROM books WHERE 1=1 AND (status != 'Deleted' OR status IS NULL)";
$countEbookSQL = "SELECT COUNT(*) FROM ebooks WHERE 1=1";

$countParams = [];
if (!empty($search)) {
    $searchTerm = '%' . $search . '%';
    $countBookSQL .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR publisher LIKE ? OR category LIKE ?)";
    $countEbookSQL .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR publisher LIKE ? OR category LIKE ?)";
    for ($i = 0; $i < 10; $i++) {
        $countParams[] = $searchTerm;
    }
}

// Apply other filters to counts
if (!empty($category)) {
    $countBookSQL .= " AND (category = ? OR subject = ?)";
    $countEbookSQL .= " AND (subject = ? OR subject = ?)";
    $countParams[] = $category;
    $countParams[] = $category;
    $countParams[] = $category;
    $countParams[] = $category;
}

if (!empty($subject)) {
    $countBookSQL .= " AND subject = ?";
    $countEbookSQL .= " AND subject = ?";
    $countParams[] = $subject;
    $countParams[] = $subject;
}

if (!empty($author)) {
    $countBookSQL .= " AND author LIKE ?";
    $countEbookSQL .= " AND author LIKE ?";
    $countParams[] = '%' . $author . '%';
    $countParams[] = '%' . $author . '%';
}

if (!empty($publisher)) {
    $countBookSQL .= " AND publisher LIKE ?";
    $countEbookSQL .= " AND publisher LIKE ?";
    $countParams[] = '%' . $publisher . '%';
    $countParams[] = '%' . $publisher . '%';
}

if ($yearFrom > 0) {
    $countBookSQL .= " AND year >= ?";
    $countEbookSQL .= " AND year >= ?";
    $countParams[] = (string)$yearFrom;
    $countParams[] = (string)$yearFrom;
}

if ($yearTo > 0) {
    $countBookSQL .= " AND year <= ?";
    $countEbookSQL .= " AND year <= ?";
    $countParams[] = (string)$yearTo;
    $countParams[] = (string)$yearTo;
}

// Execute count queries
$bookCount = 0;
$ebookCount = 0;

try {
    if ($typeFilter === 'both' || $typeFilter === 'books') {
        $stmt = $db->prepare($countBookSQL);
        $stmt->execute($countParams);
        $bookCount = (int)$stmt->fetchColumn();
    }

    if ($typeFilter === 'both' || $typeFilter === 'ebooks') {
        $stmt = $db->prepare($countEbookSQL);
        $stmt->execute($countParams);
        $ebookCount = (int)$stmt->fetchColumn();
    }
} catch (PDOException $e) {
    error_log("Count query error: " . $e->getMessage());
    $bookCount = 0;
    $ebookCount = 0;
}

$totalItems = $bookCount + $ebookCount;

// Build main query with UNION
$combinedQuery = "SELECT * FROM ($bookQuery $whereSQL UNION ALL $ebookQuery $whereSQL) 
    ORDER BY $sortBy $sortOrder 
    LIMIT ? OFFSET ?";

$allParams = array_merge($params, [$itemsPerPage, $offset]);
$items = [];

try {
    $stmt = $db->prepare($combinedQuery);
    $stmt->execute($allParams);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Main query error: " . $e->getMessage());
    $items = [];
}

// ==================== GET FILTER OPTIONS ====================
$allCategories = [];
$allSubjects = [];
$allAuthors = [];
$allPublishers = [];
$allYears = [];

try {
    $categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' AND (status != 'Deleted' OR status IS NULL) ORDER BY category LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $ebookCategories = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $allCategories = array_unique(array_merge($categories, $ebookCategories));
    sort($allCategories);

    $subjects = $db->query("SELECT DISTINCT subject FROM books WHERE subject IS NOT NULL AND subject != '' AND (status != 'Deleted' OR status IS NULL) ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $ebookSubjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $allSubjects = array_unique(array_merge($subjects, $ebookSubjects));
    sort($allSubjects);

    $authors = $db->query("SELECT DISTINCT author FROM books WHERE author IS NOT NULL AND author != '' AND (status != 'Deleted' OR status IS NULL) ORDER BY author LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $ebookAuthors = $db->query("SELECT DISTINCT author FROM ebooks WHERE author IS NOT NULL AND author != '' ORDER BY author LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $allAuthors = array_unique(array_merge($authors, $ebookAuthors));
    sort($allAuthors);

    $publishers = $db->query("SELECT DISTINCT publisher FROM books WHERE publisher IS NOT NULL AND publisher != '' AND (status != 'Deleted' OR status IS NULL) ORDER BY publisher LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $ebookPublishers = $db->query("SELECT DISTINCT publisher FROM ebooks WHERE publisher IS NOT NULL AND publisher != '' ORDER BY publisher LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
    $allPublishers = array_unique(array_merge($publishers, $ebookPublishers));
    sort($allPublishers);

    $years = $db->query("SELECT DISTINCT year FROM books WHERE year IS NOT NULL AND year != '' AND year GLOB '[0-9][0-9][0-9][0-9]' AND (status != 'Deleted' OR status IS NULL) ORDER BY year DESC LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
    $ebookYears = $db->query("SELECT DISTINCT year FROM ebooks WHERE year IS NOT NULL AND year != '' AND year GLOB '[0-9][0-9][0-9][0-9]' ORDER BY year DESC LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
    $allYears = array_unique(array_merge($years, $ebookYears));
    rsort($allYears);
} catch (PDOException $e) {
    error_log("Filter options query error: " . $e->getMessage());
}

// ==================== STATISTICS ====================
$totalBooks = 0;
$totalEbooks = 0;
$totalCopies = 0;
$totalAvailable = 0;
$totalDownloads = 0;
$totalEbookSize = 0;
$totalViews = 0;

try {
    $totalBooks = $db->query("SELECT COUNT(*) FROM books WHERE (status != 'Deleted' OR status IS NULL)")->fetchColumn() ?: 0;
    $totalEbooks = $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn() ?: 0;
    $totalCopies = $db->query("SELECT SUM(quantity) FROM books WHERE (status != 'Deleted' OR status IS NULL)")->fetchColumn() ?: 0;
    $totalAvailable = $db->query("SELECT SUM(available) FROM books WHERE (status != 'Deleted' OR status IS NULL)")->fetchColumn() ?: 0;
    $totalDownloads = $db->query("SELECT SUM(downloads) FROM ebooks")->fetchColumn() ?: 0;
    $totalEbookSize = $db->query("SELECT SUM(file_size) FROM ebooks WHERE file_size IS NOT NULL")->fetchColumn() ?: 0;
    $totalViews = $db->query("SELECT SUM(views) FROM ebooks")->fetchColumn() ?: 0;
} catch (PDOException $e) {
    error_log("Statistics query error: " . $e->getMessage());
}

// ==================== EXPORT HANDLER ====================
if (isset($_GET['export']) && $_GET['export'] == 1) {
    $format = $_GET['format'] ?? 'excel';
    $exportData = [];
    $sn = 1;
    foreach ($items as $item) {
        $isBook = $item['item_type'] === 'book';
        $status = $isBook ? ($item['available_copies'] > 0 ? 'Available' : 'Issued') : ($item['available_copies'] > 0 ? 'Available' : 'No File');
        $exportData[] = [
            'Sl No' => $sn++,
            'Type' => $isBook ? 'Book' : 'eBook',
            'Identifier' => $isBook ? ($item['barcode'] ?? 'N/A') : 'EBOOK-' . ($item['id'] ?? 0),
            'Title' => $item['title'] ?? 'Untitled',
            'Author' => $item['author'] ?? 'Unknown',
            'Publisher' => $item['publisher'] ?? '-',
            'Year' => $item['year'] ?? '-',
            'Category/Subject' => $item['category'] ?? $item['subject'] ?? 'Uncategorized',
            'Copies' => $isBook ? ($item['total_copies'] ?? 0) : 1,
            'Available' => $isBook ? ($item['available_copies'] ?? 0) : ($item['available_copies'] ?? 0),
            'Status' => $status,
            'Downloads' => $isBook ? '-' : ($item['downloads'] ?? 0),
            'Language' => $item['language'] ?? '-',
            'Edition' => $item['edition'] ?? '-',
            'Format' => $isBook ? '-' : ($item['format'] ?? 'pdf'),
            'File Size' => $isBook ? '-' : ($item['file_size'] ? formatFileSize($item['file_size']) : '-'),
            'Source' => $item['source'] ?? '-'
        ];
    }
    
    $headers = ['Sl No', 'Type', 'Identifier', 'Title', 'Author', 'Publisher', 'Year', 'Category/Subject', 'Copies', 'Available', 'Status', 'Downloads', 'Language', 'Edition', 'Format', 'File Size', 'Source'];
    $filename = 'books_ebooks_summary_' . date('Y-m-d');
    
    if ($format === 'pdf') {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Books & eBooks Summary</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
        </style>
        </head><body>';
        
        $filters = [
            'Type' => ucfirst($typeFilter),
            'Search' => $search ?: 'None',
            'Category' => $category ?: 'All',
            'Subject' => $subject ?: 'All',
            'Author' => $author ?: 'All',
            'Year Range' => ($yearFrom && $yearTo) ? $yearFrom . ' - ' . $yearTo : 'All'
        ];
        
        $html .= getReportHeaderHTML('Books & eBooks Summary', null, null, $filters);
        $html .= '<table><thead><tr>';
        foreach ($headers as $header) {
            $html .= '<th>' . htmlspecialchars($header) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        
        foreach ($exportData as $row) {
            $html .= '<tr>';
            foreach ($row as $value) {
                if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                    $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
                } elseif (is_numeric($value)) {
                    $html .= '<td class="text-right">' . $value . '</td>';
                } else {
                    $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                }
            }
            $html .= '</tr>';
        }
        
        $html .= '</tbody></table>';
        
        $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
            <strong>Summary:</strong> 
            Total Titles: ' . ($totalBooks + $totalEbooks) . ' | 
            Books: ' . $totalBooks . ' | 
            eBooks: ' . $totalEbooks . ' | 
            Total Copies: ' . $totalCopies . ' | 
            Available: ' . $totalAvailable . '
        </div>';
        
        $html .= getReportFooterHTML();
        $html .= '</body></html>';
        
        exportToPDF($html, $filename . '.pdf', $paperSize, $orientation);
    } else {
        exportToExcel($exportData, $headers, $filename);
    }
    exit;
}

// ==================== RENDER ====================
renderHeader('Books & eBooks Summary');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books & eBooks Summary</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        body {
            background: #f0f2f5;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        /* ========== SETTINGS BAR - UNIFIED ========== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        
        /* ========== STAT CARDS - UNIFIED GRADIENT ========== */
        .stat-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 12px;
            cursor: default;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card .stat-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 15px;
            top: 15px;
            color: white;
        }
        .stat-card .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: white;
        }
        .stat-card .stat-label {
            font-size: 0.85rem;
            opacity: 0.9;
            color: rgba(255,255,255,0.95);
        }
        .stat-card .stat-sub {
            font-size: 0.75rem;
            opacity: 0.7;
            color: rgba(255,255,255,0.85);
        }
        .stat-card .card-body {
            position: relative;
            z-index: 1;
        }
        
        /* Individual stat colors - all use primary gradient */
        .stat-card.bg-primary { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-success { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-info { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-warning { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-secondary { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        .stat-card.bg-dark { background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%) !important; }
        
        .filter-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
        }
        .filter-card .card-header {
            background: transparent;
            border-bottom: 1px solid #e9ecef;
            padding: 0 0 10px 0;
            cursor: pointer;
        }
        
        .summary-table th {
            background: var(--primary-color);
            color: white;
            border-bottom: 2px solid #dee2e6;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 5;
        }
        .summary-table td {
            vertical-align: middle;
        }
        .summary-table .table-container {
            max-height: 70vh;
            overflow-y: auto;
            position: relative;
        }
        .summary-table .table-container::-webkit-scrollbar {
            width: 6px;
        }
        .summary-table .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .summary-table .table-container::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        
        .cover-thumb {
            width: 50px;
            height: 65px;
            object-fit: cover;
            border-radius: 6px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        .cover-thumb:hover {
            transform: scale(1.15);
            border-color: var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            z-index: 10;
            position: relative;
        }
        .default-cover {
            width: 50px;
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 6px;
            color: white;
            font-size: 1.4rem;
        }
        .default-cover.ebook {
            background: linear-gradient(135deg, #dc3545, #b02a37);
        }
        
        .type-badge {
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .type-badge.book {
            background: #cfe2ff;
            color: #084298;
        }
        .type-badge.ebook {
            background: #f8d7da;
            color: #721c24;
        }
        
        .format-badge {
            font-size: 0.65rem;
            padding: 2px 8px;
            border-radius: 4px;
        }
        
        .btn-filter {
            border-radius: 30px;
            padding: 5px 15px;
            font-size: 0.85rem;
        }
        .btn-filter.active {
            background: var(--primary-color);
            color: white;
        }
        
        .pagination .page-link {
            color: var(--primary-color);
        }
        .pagination .page-item.active .page-link {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .logo-preview {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            background: white;
            padding: 2px 6px;
            border-radius: 4px;
        }
        
        .settings-preview-card {
            background: white;
            border-radius: 12px;
            padding: 12px 18px;
            margin-bottom: 16px;
            border-left: 3px solid <?= $reportPrimaryColor ?>;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            font-size: 0.75rem;
        }
        .settings-preview-card .logo-container {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .settings-preview-card .logo-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .settings-preview-card .logo-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.7rem;
        }
        
        .source-badge {
            font-size: 9px;
            padding: 1px 5px;
            border-radius: 10px;
            background: #e9ecef;
            color: #495057;
        }
        
        .quick-actions-bar {
            background: white;
            border-radius: 12px;
            padding: 10px 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        
        @media (max-width: 768px) {
            .stat-card .stat-number {
                font-size: 1.2rem;
            }
            .cover-thumb {
                width: 35px;
                height: 45px;
            }
            .default-cover {
                width: 35px;
                height: 45px;
                font-size: 1rem;
            }
            .quick-actions-bar {
                flex-direction: column;
                align-items: stretch;
            }
            .settings-bar {
                font-size: 0.7rem;
                padding: 8px 12px;
                flex-direction: column;
                gap: 6px;
                text-align: center;
            }
            .settings-bar .settings-items-wrap {
                justify-content: center;
            }
            .settings-preview-card .logo-container {
                flex-direction: column;
                align-items: flex-start;
            }
        }
        
        @media print {
            .no-print { display: none !important; }
            .filter-card { display: none !important; }
            .stat-card { box-shadow: none !important; border: 1px solid #ddd; background: #f8f9fa !important; color: #333 !important; }
            .stat-card .stat-number { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon { display: none !important; }
            .summary-table th { background: #333 !important; color: white !important; }
            .cover-thumb { max-width: 30px; max-height: 40px; }
            .settings-bar { display: none !important; }
            .settings-preview-card { display: none !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color); margin: 0; font-size: 1.4rem; font-weight: 700;">
            <i class="fas fa-book-open" style="color: var(--primary-color);"></i> Books &amp; eBooks Summary
        </h2>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="../reports/index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Reports Home</a>
            <a href="books.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-book"></i> Books</a>
            <a href="ebooks.php" class="btn btn-outline-danger btn-sm"><i class="fas fa-file-pdf"></i> eBooks</a>
            <button class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            <button class="btn btn-success btn-sm" onclick="exportReport('excel')"><i class="fas fa-file-excel"></i> Excel</button>
            <button class="btn btn-danger btn-sm" onclick="exportReport('pdf')"><i class="fas fa-file-pdf"></i> PDF</button>
        </div>
    </div>


    <!-- ========== LOGO PREVIEW CARD ========== -->
    <?php
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    if ($mainLogo || $rightLogo):
    ?>
    <div class="settings-preview-card no-print">
        <div class="logo-container">
            <div class="logo-item">
                <span class="logo-label"><i class="fas fa-image"></i> Logo:</span>
                <?php if ($mainLogo): ?>
                    <img src="<?= $mainLogo['base64'] ?>" class="logo-preview" alt="Logo">
                <?php endif; ?>
            </div>
            <?php if ($rightLogo): ?>
            <div class="logo-item">
                <span class="logo-label">Right Logo:</span>
                <img src="<?= $rightLogo['base64'] ?>" class="logo-preview" alt="Right Logo">
            </div>
            <?php endif; ?>
            <div class="logo-item">
                <span class="logo-label">Position:</span>
                <span class="badge bg-<?= $reportLogoPosition == 'left' ? 'primary' : ($reportLogoPosition == 'right' ? 'info' : ($reportLogoPosition == 'center' ? 'warning' : 'secondary')) ?>">
                    <?= ucfirst($reportLogoPosition) ?>
                </span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Statistics Cards - UNIFIED GRADIENT -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-primary text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-tag"></i></div>
                    <div class="stat-number"><?= number_format($totalBooks + $totalEbooks) ?></div>
                    <div class="stat-label">Total Titles</div>
                    <div class="stat-sub">Books: <?= number_format($totalBooks) ?> | eBooks: <?= number_format($totalEbooks) ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-success text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-copy"></i></div>
                    <div class="stat-number"><?= number_format($totalCopies) ?></div>
                    <div class="stat-label">Total Copies</div>
                    <div class="stat-sub"><?= $totalBooks > 0 ? round($totalCopies / $totalBooks, 1) : 0 ?> copies per title</div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-info text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?= number_format($totalAvailable) ?></div>
                    <div class="stat-label">Available Copies</div>
                    <div class="stat-sub"><?= $totalCopies > 0 ? round(($totalAvailable / $totalCopies) * 100, 1) : 0 ?>% of total</div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-warning text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-download"></i></div>
                    <div class="stat-number"><?= number_format($totalDownloads) ?></div>
                    <div class="stat-label">Total Downloads</div>
                    <div class="stat-sub"><?= $totalEbooks > 0 ? round($totalDownloads / $totalEbooks, 1) : 0 ?> avg per eBook</div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-secondary text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-hdd"></i></div>
                    <div class="stat-number"><?= formatFileSize($totalEbookSize ?? 0) ?></div>
                    <div class="stat-label">eBook Storage</div>
                </div>
            </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6">
            <div class="card stat-card bg-dark text-white">
                <div class="card-body">
                    <div class="stat-icon"><i class="fas fa-eye"></i></div>
                    <div class="stat-number"><?= number_format($totalViews) ?></div>
                    <div class="stat-label">Total Views</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions Bar -->
    <div class="quick-actions-bar no-print">
        <span class="fw-bold me-2"><i class="fas fa-bolt"></i> Quick Actions:</span>
        <button class="btn btn-sm btn-outline-primary" onclick="toggleFilterPanel()"><i class="fas fa-filter"></i> Toggle Filters</button>
        <button class="btn btn-sm btn-outline-success" onclick="exportReport('excel')"><i class="fas fa-file-excel"></i> Export Excel</button>
        <button class="btn btn-sm btn-outline-danger" onclick="exportReport('pdf')"><i class="fas fa-file-pdf"></i> Export PDF</button>
        <button class="btn btn-sm btn-outline-secondary" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
        <span class="ms-auto text-muted small" id="recordCount"><?= number_format($totalItems) ?> records</span>
    </div>

    <!-- Type Filter Buttons -->
    <div class="filter-card no-print">
        <div class="d-flex flex-wrap align-items-center gap-2">
            <span class="fw-bold me-2"><i class="fas fa-filter"></i> Filter:</span>
            <a href="?type=both&search=<?= urlencode($search) ?>&category=<?= urlencode($category) ?>&subject=<?= urlencode($subject) ?>&author=<?= urlencode($author) ?>&publisher=<?= urlencode($publisher) ?>&year_from=<?= $yearFrom ?>&year_to=<?= $yearTo ?>&sort_by=<?= $sortBy ?>&sort_order=<?= $sortOrder ?>&has_cover=<?= $hasCover ?>&per_page=<?= $itemsPerPage ?>" 
               class="btn btn-filter <?= $typeFilter === 'both' ? 'active btn-primary' : 'btn-outline-primary' ?>">
                <i class="fas fa-layer-group"></i> All (<?= $totalBooks + $totalEbooks ?>)
            </a>
            <a href="?type=books&search=<?= urlencode($search) ?>&category=<?= urlencode($category) ?>&subject=<?= urlencode($subject) ?>&author=<?= urlencode($author) ?>&publisher=<?= urlencode($publisher) ?>&year_from=<?= $yearFrom ?>&year_to=<?= $yearTo ?>&sort_by=<?= $sortBy ?>&sort_order=<?= $sortOrder ?>&has_cover=<?= $hasCover ?>&per_page=<?= $itemsPerPage ?>" 
               class="btn btn-filter <?= $typeFilter === 'books' ? 'active btn-primary' : 'btn-outline-primary' ?>">
                <i class="fas fa-book"></i> Books (<?= $bookCount ?>)
            </a>
            <a href="?type=ebooks&search=<?= urlencode($search) ?>&category=<?= urlencode($category) ?>&subject=<?= urlencode($subject) ?>&author=<?= urlencode($author) ?>&publisher=<?= urlencode($publisher) ?>&year_from=<?= $yearFrom ?>&year_to=<?= $yearTo ?>&sort_by=<?= $sortBy ?>&sort_order=<?= $sortOrder ?>&has_cover=<?= $hasCover ?>&per_page=<?= $itemsPerPage ?>" 
               class="btn btn-filter <?= $typeFilter === 'ebooks' ? 'active btn-primary' : 'btn-outline-primary' ?>">
                <i class="fas fa-file-pdf"></i> eBooks (<?= $ebookCount ?>)
            </a>
        </div>
    </div>

    <!-- Advanced Filters -->
    <div class="filter-card no-print" id="filterCard">
        <div class="card-header" onclick="toggleFilters()">
            <div class="d-flex justify-content-between align-items-center">
                <span><i class="fas fa-sliders-h"></i> Advanced Filters</span>
                <i class="fas fa-chevron-down" id="filterChevron"></i>
            </div>
        </div>
        <div class="card-body" id="filterBody">
            <form method="GET" id="filterForm">
                <input type="hidden" name="type" value="<?= htmlspecialchars($typeFilter) ?>">
                <input type="hidden" name="sort_by" value="<?= htmlspecialchars($sortBy) ?>">
                <input type="hidden" name="sort_order" value="<?= htmlspecialchars($sortOrder) ?>">
                
                <div class="row g-3">
                    <div class="col-md-12">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search by title, author, subject, publisher..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </div>
                
                <div class="row g-3 mt-2">
                    <div class="col-md-3">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select select2">
                            <option value="">All Categories</option>
                            <?php foreach ($allCategories as $cat): ?>
                                <option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Subject</label>
                        <select name="subject" class="form-select select2">
                            <option value="">All Subjects</option>
                            <?php foreach ($allSubjects as $subj): ?>
                                <option value="<?= htmlspecialchars($subj) ?>" <?= $subject == $subj ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($subj) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Author</label>
                        <select name="author" class="form-select select2">
                            <option value="">All Authors</option>
                            <?php foreach ($allAuthors as $auth): ?>
                                <option value="<?= htmlspecialchars($auth) ?>" <?= $author == $auth ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($auth) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Publisher</label>
                        <select name="publisher" class="form-select select2">
                            <option value="">All Publishers</option>
                            <?php foreach ($allPublishers as $pub): ?>
                                <option value="<?= htmlspecialchars($pub) ?>" <?= $publisher == $pub ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($pub) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="row g-3 mt-2">
                    <div class="col-md-3">
                        <label class="form-label">Year From</label>
                        <select name="year_from" class="form-select">
                            <option value="0">Any</option>
                            <?php foreach ($allYears as $y): ?>
                                <option value="<?= $y ?>" <?= $yearFrom == $y ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Year To</label>
                        <select name="year_to" class="form-select">
                            <option value="0">Any</option>
                            <?php foreach ($allYears as $y): ?>
                                <option value="<?= $y ?>" <?= $yearTo == $y ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Cover</label>
                        <select name="has_cover" class="form-select">
                            <option value="-1">All</option>
                            <option value="1" <?= $hasCover === 1 ? 'selected' : '' ?>>Has Cover</option>
                            <option value="0" <?= $hasCover === 0 ? 'selected' : '' ?>>No Cover</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Per Page</label>
                        <select name="per_page" class="form-select">
                            <option value="10" <?= $itemsPerPage == 10 ? 'selected' : '' ?>>10</option>
                            <option value="20" <?= $itemsPerPage == 20 ? 'selected' : '' ?>>20</option>
                            <option value="50" <?= $itemsPerPage == 50 ? 'selected' : '' ?>>50</option>
                            <option value="100" <?= $itemsPerPage == 100 ? 'selected' : '' ?>>100</option>
                        </select>
                    </div>
                </div>
                
                <div class="row g-3 mt-3">
                    <div class="col-md-12 d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply Filters</button>
                        <a href="books_titles_summary.php" class="btn btn-secondary">Clear All</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Results Summary -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
        <div>
            <span class="fw-bold"><?= number_format($totalItems) ?></span> titles found
            <?php if ($typeFilter === 'books'): ?>
                <span class="text-muted">(<?= number_format($bookCount) ?> books)</span>
            <?php elseif ($typeFilter === 'ebooks'): ?>
                <span class="text-muted">(<?= number_format($ebookCount) ?> eBooks)</span>
            <?php else: ?>
                <span class="text-muted">(<?= number_format($bookCount) ?> books, <?= number_format($ebookCount) ?> eBooks)</span>
            <?php endif; ?>
        </div>
        <div class="d-flex gap-2">
            <span class="text-muted">Page <?= $page ?> of <?= max(1, ceil($totalItems / $itemsPerPage)) ?></span>
        </div>
    </div>

    <!-- Results Table -->
    <div class="card summary-table">
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table table-hover table-bordered mb-0">
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th style="width: 60px;">Cover</th>
                            <th style="width: 80px;">Type</th>
                            <th>
                                <a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'title', 'sort_order' => $sortBy === 'title' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">
                                    Title <?= $sortBy === 'title' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?>
                                </a>
                            </th>
                            <th>
                                <a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'author', 'sort_order' => $sortBy === 'author' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">
                                    Author <?= $sortBy === 'author' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?>
                                </a>
                            </th>
                            <th>Category/Subject</th>
                            <th>
                                <a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'publisher', 'sort_order' => $sortBy === 'publisher' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">
                                    Publisher <?= $sortBy === 'publisher' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?>
                                </a>
                            </th>
                            <th>
                                <a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'year', 'sort_order' => $sortBy === 'year' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">
                                    Year <?= $sortBy === 'year' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?>
                                </a>
                            </th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'total_copies', 'sort_order' => $sortBy === 'total_copies' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">Copies <?= $sortBy === 'total_copies' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?></a></th>
                            <th><a href="?<?= http_build_query(array_merge($_GET, ['sort_by' => 'available_copies', 'sort_order' => $sortBy === 'available_copies' ? ($sortOrder === 'ASC' ? 'DESC' : 'ASC') : 'ASC'])) ?>" class="text-white text-decoration-none">Avail <?= $sortBy === 'available_copies' ? ($sortOrder === 'ASC' ? '↑' : '↓') : '' ?></a></th>
                            <th>Status</th>
                            <th>Downloads</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($items)): ?>
                            <tr>
                                <td colspan="13" class="text-center py-5 text-muted">
                                    <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                    No titles found matching your criteria.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($items as $index => $item): 
                                $isBook = $item['item_type'] === 'book';
                                $coverBase64 = getCoverBase64($item['cover_path'] ?? '');
                                $rowNum = $offset + $index + 1;
                                $status = $isBook ? ($item['available_copies'] > 0 ? 'Available' : 'Issued') : ($item['available_copies'] > 0 ? 'Available' : 'No File');
                                $identifier = $isBook ? ($item['barcode'] ?? 'N/A') : 'EBOOK-' . ($item['id'] ?? 0);
                            ?>
                            <tr>
                                <td class="text-center"><?= $rowNum ?></td>
                                <td class="text-center">
                                    <?php if ($coverBase64): ?>
                                        <img src="<?= $coverBase64 ?>" class="cover-thumb" alt="Cover" 
                                             onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.default-cover').style.display='flex';">
                                        <div class="default-cover <?= $isBook ? '' : 'ebook' ?>" style="display:none;">
                                            <i class="fas fa-<?= $isBook ? 'book' : 'file-pdf' ?>"></i>
                                        </div>
                                    <?php else: ?>
                                        <div class="default-cover <?= $isBook ? '' : 'ebook' ?>">
                                            <i class="fas fa-<?= $isBook ? 'book' : 'file-pdf' ?>"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="type-badge <?= $isBook ? 'book' : 'ebook' ?>">
                                        <?= $isBook ? '📖 Book' : '📄 eBook' ?>
                                    </span>
                                    <?php if (!$isBook && !empty($item['format'])): ?>
                                        <br><span class="badge bg-<?= $item['format'] === 'pdf' ? 'danger' : ($item['format'] === 'epub' ? 'primary' : 'secondary') ?> format-badge"><?= strtoupper(htmlspecialchars($item['format'])) ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($item['source'])): ?>
                                        <br><span class="source-badge"><i class="fas fa-database"></i> <?= htmlspecialchars($item['source']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= htmlspecialchars(substr($item['title'] ?? 'Untitled', 0, 60)) ?></strong>
                                    <?php if (!empty($item['edition']) && $item['edition'] != '1'): ?>
                                        <br><small class="text-muted"><?= htmlspecialchars($item['edition']) ?> ed.</small>
                                    <?php endif; ?>
                                    <?php if (!empty($item['language'])): ?>
                                        <br><span class="badge bg-info text-white"><?= htmlspecialchars($item['language']) ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($item['author'] ?? 'Unknown') ?></td>
                                <td>
                                    <span class="badge bg-secondary"><?= htmlspecialchars($item['category'] ?? $item['subject'] ?? 'Uncategorized') ?></span>
                                    <?php if (!empty($item['subject']) && $item['subject'] != ($item['category'] ?? '')): ?>
                                        <br><small class="text-muted"><?= htmlspecialchars($item['subject']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($item['publisher'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($item['year'] ?? '-') ?></td>
                                <td class="text-center"><?= $isBook ? ($item['total_copies'] ?? 0) : 1 ?></td>
                                <td class="text-center">
                                    <span class="badge bg-<?= ($item['available_copies'] ?? 0) > 0 ? 'success' : 'danger' ?>">
                                        <?= $item['available_copies'] ?? 0 ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($isBook): ?>
                                        <?= getStatusBadge($item['available_copies'] ?? 0, $item['total_copies'] ?? 0) ?>
                                    <?php else: ?>
                                        <span class="badge bg-<?= ($item['available_copies'] ?? 0) > 0 ? 'success' : 'secondary' ?>">
                                            <?= ($item['available_copies'] ?? 0) > 0 ? 'Available' : 'No file' ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?= $isBook ? '-' : ($item['downloads'] ?? 0) ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <?php if ($isBook): ?>
                                            <a href="books.php?edit=<?= urlencode($identifier) ?>&mode=full" class="btn btn-warning" title="Edit Book">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="books.php?delete=<?= urlencode($identifier) ?>" class="btn btn-danger" onclick="return confirm('Delete this book?')" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <a href="books.php?view=grid&search=<?= urlencode($item['title'] ?? '') ?>" class="btn btn-info text-white" title="View in Books">
                                                <i class="fas fa-book"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="ebooks.php?edit=<?= $item['id'] ?? 0 ?>" class="btn btn-warning" title="Edit eBook">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="ebooks.php?delete=<?= $item['id'] ?? 0 ?>" class="btn btn-danger" onclick="return confirm('Delete this eBook?')" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <a href="ebooks.php?search=<?= urlencode($item['title'] ?? '') ?>" class="btn btn-info text-white" title="View in eBooks">
                                                <i class="fas fa-file-pdf"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($items)): ?>
                        <?php 
                        $totalCopiesSum = array_sum(array_map(function($i) { 
                            return $i['item_type'] === 'book' ? ($i['total_copies'] ?? 0) : 1; 
                        }, $items));
                        $totalAvailableSum = array_sum(array_column($items, 'available_copies'));
                        ?>
                        <tfoot class="table-light">
                            <tr class="fw-bold">
                                <td colspan="7" class="text-end">Totals:</td>
                                <td colspan="2" class="text-center"><?= $totalCopiesSum ?></td>
                                <td class="text-center"><?= $totalAvailableSum ?></td>
                                <td colspan="3"></td>
                            </tr>
                        </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($totalItems > $itemsPerPage): 
        $totalPages = ceil($totalItems / $itemsPerPage);
    ?>
    <div class="d-flex justify-content-center mt-4 no-print">
        <nav>
            <ul class="pagination">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">Previous</a>
                </li>
                
                <?php for ($p = max(1, $page - 2); $p <= min($totalPages, $page + 2); $p++): ?>
                    <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
                
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <div class="text-center text-muted small mt-3 no-print">
        <i class="fas fa-info-circle"></i> Report generated on <?= date('Y-m-d H:i:s') ?> | &copy; <?= date('Y') ?> <?= htmlspecialchars(getInstitutionName()) ?>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
// Initialize Select2
$(document).ready(function() {
    if (typeof $.fn.select2 !== 'undefined') {
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: '100%',
            allowClear: true
        });
    }
});

// ==================== FILTER TOGGLES ====================
function toggleFilters() {
    const body = document.getElementById('filterBody');
    const chevron = document.getElementById('filterChevron');
    if (body && chevron) {
        if (body.style.display === 'none') {
            body.style.display = 'block';
            chevron.className = 'fas fa-chevron-up';
            localStorage.setItem('showFilters_books_ebooks', 'true');
        } else {
            body.style.display = 'none';
            chevron.className = 'fas fa-chevron-down';
            localStorage.setItem('showFilters_books_ebooks', 'false');
        }
    }
}

function toggleFilterPanel() {
    toggleFilters();
}

// Restore filter state
document.addEventListener('DOMContentLoaded', function() {
    const body = document.getElementById('filterBody');
    const chevron = document.getElementById('filterChevron');
    if (body && chevron) {
        const showFilters = localStorage.getItem('showFilters_books_ebooks') !== 'false';
        body.style.display = showFilters ? 'block' : 'none';
        chevron.className = showFilters ? 'fas fa-chevron-up' : 'fas fa-chevron-down';
    }
});

// ==================== EXPORT FUNCTIONS ====================
function exportReport(format) {
    const url = new URL(window.location.href);
    url.searchParams.set('export', '1');
    url.searchParams.set('format', format);
    window.location.href = url.toString();
}

// ==================== KEYBOARD SHORTCUTS ====================
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) searchInput.focus();
    }
    if (e.ctrlKey && e.key === 'e') {
        e.preventDefault();
        exportReport('excel');
    }
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        exportReport('pdf');
    }
    if (e.key === 'Escape') {
        const clearBtn = document.querySelector('a[href="books_titles_summary.php"]');
        if (clearBtn) clearBtn.click();
    }
});

// Auto-submit on filter change
document.querySelectorAll('.select2, select[name="per_page"]').forEach(el => {
    el.addEventListener('change', function() {
        this.closest('form')?.submit();
    });
});
</script>

<?php renderFooter(); ?>
</body>
</html>