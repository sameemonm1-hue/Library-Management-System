<?php
/**
 * Books Summary Report - Unique Titles vs Total Copies
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();

// Get report settings from database (with fallbacks)
$settings = getSettings();
$institution = getInstitution();

$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';

// Filters from URL
$selectedCategory = $_GET['category'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';
$format = $_GET['format'] ?? ''; // 'excel' or 'pdf'

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    // Fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function formatNumber($num) {
    return number_format((int)$num);
}

// ========== BUILD QUERY ==========
$sql = "SELECT 
            category, 
            COUNT(DISTINCT CONCAT(COALESCE(title,''), '-', COALESCE(author,''))) as titles, 
            SUM(quantity) as total_copies 
        FROM books 
        WHERE 1=1";
$params = [];

if (!empty($selectedCategory)) {
    $sql .= " AND category = ?";
    $params[] = $selectedCategory;
}
$sql .= " GROUP BY category ORDER BY category";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$categoryData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Overall totals
$overallSql = "SELECT 
                    COUNT(DISTINCT CONCAT(COALESCE(title,''), '-', COALESCE(author,''))) as total_titles, 
                    SUM(quantity) as total_copies 
                FROM books";
$overallParams = [];
if (!empty($selectedCategory)) {
    $overallSql .= " WHERE category = ?";
    $overallParams[] = $selectedCategory;
}
$overallStmt = $db->prepare($overallSql);
$overallStmt->execute($overallParams);
$overall = $overallStmt->fetch(PDO::FETCH_ASSOC);

$displayData = $categoryData;
$displayData[] = [
    'category' => '** OVERALL **',
    'titles' => $overall['total_titles'] ?? 0,
    'total_copies' => $overall['total_copies'] ?? 0
];

// Distinct categories for dropdown
$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

// ========== EXPORT HANDLING ==========
if ($format === 'excel' || $format === 'pdf') {
    $title = 'Books Summary (Titles vs Copies)';
    $filename = 'books_titles_summary_' . date('Y-m-d');
    
    // Build export data with 'Sl No'
    $exportData = [];
    $sn = 1;
    foreach ($displayData as $row) {
        $exportData[] = [
            'Sl No' => $sn++,
            'Category' => $row['category'] ?? 'Uncategorized',
            'Unique Titles' => (int)$row['titles'],
            'Total Copies' => (int)$row['total_copies']
        ];
    }
    $headers = ['Sl No', 'Category', 'Unique Titles', 'Total Copies'];
    
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
    </style>
    </head><body>';
    
    $filters = [];
    if (!empty($selectedCategory)) $filters['Category'] = $selectedCategory;
    $html .= getReportHeaderHTML($title, null, null, $filters);
    
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value)) {
                $html .= '<td class="text-right">' . number_format($value) . '</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="3" class="text-right">Overall Totals:</td>';
    $html .= '<td class="text-center">' . formatNumber($overall['total_titles']) . ' / ' . formatNumber($overall['total_copies']) . '</td>';
    $html .= '</tr></tfoot></table>';
    
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    
    if ($format === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title></head><body>' . $html . '</body></html>';
        exit;
    } else {
        exportToPDF($html, $filename . '.pdf', $paperSize, $orientation);
        exit;
    }
}

// ========== ON‑SCREEN DISPLAY ==========
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Summary - Titles vs Copies</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .container-fluid { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .settings-info { background: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>cc 100%); color: white; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
        @media print { .no-print, .btn, form, .settings-info { display: none !important; } }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mt-2 mb-4">
        <h2><i class="fas fa-chart-simple"></i> Books Summary (Titles vs Copies)</h2>
        <div class="no-print">
            <a href="index.php" class="btn btn-primary btn-sm">Standard Reports</a>
            <a href="advanced_reports.php" class="btn btn-primary btn-sm">Advanced Reports</a>
            <a href="../index.php" class="btn btn-primary btn-sm">Back to Home</a>
        </div>
    </div>

    <div class="settings-info no-print">
        <div class="row align-items-center">
            <div class="col-md-8">
                <i class="fas fa-chart-bar"></i> <strong>Report Settings:</strong> 
                Logo: <?= ucfirst($reportLogoPosition) ?> | 
                Watermark: <?= $reportWatermarkEnabled ? 'On' : 'Off' ?> | Signature: <?= $reportSignatureEnabled ? 'On' : 'Off' ?>
            </div>
            <div class="col-md-4 text-end">
                <a href="../settings.php#report" class="btn btn-sm btn-light">Configure</a>
            </div>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4 no-print">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Filter Options</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3" id="filterForm">
                <div class="col-md-4">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <option value="">-- All Categories --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= $selectedCategory == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Paper Size (PDF)</label>
                    <select name="paper_size" class="form-select">
                        <option value="A4" <?= $paperSize == 'A4' ? 'selected' : '' ?>>A4</option>
                        <option value="Letter" <?= $paperSize == 'Letter' ? 'selected' : '' ?>>Letter</option>
                        <option value="Legal" <?= $paperSize == 'Legal' ? 'selected' : '' ?>>Legal</option>
                        <option value="A3" <?= $paperSize == 'A3' ? 'selected' : '' ?>>A3</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Orientation (PDF)</label>
                    <select name="orientation" class="form-select">
                        <option value="landscape" <?= $orientation == 'landscape' ? 'selected' : '' ?>>Landscape</option>
                        <option value="portrait" <?= $orientation == 'portrait' ? 'selected' : '' ?>>Portrait</option>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Apply</button>
                </div>
                <div class="col-md-2 align-self-end">
                    <a href="books_titles_summary.php" class="btn btn-warning w-100"><i class="fas fa-eraser"></i> Clear</a>
                </div>
            </form>
            <hr>
            <div class="row g-2">
                <div class="col-auto"><button onclick="exportReport('excel')" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel</button></div>
                <div class="col-auto"><button onclick="exportReport('pdf')" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF</button></div>
                <div class="col-auto"><button onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button></div>
            </div>
        </div>
    </div>

    <!-- Report Table -->
    <div class="card">
        <div class="card-header bg-primary text-white fw-bold py-2">
            <i class="fas fa-chart-simple"></i> Books Summary (Titles vs Copies)
            <span class="float-end">Categories: <?= count($categoryData) ?> | Overall Titles: <?= formatNumber($overall['total_titles']) ?> | Copies: <?= formatNumber($overall['total_copies']) ?></span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr><th>#</th><th>Category</th><th>Unique Titles</th><th>Total Copies</th></tr>
                    </thead>
                    <tbody>
                        <?php $sn = 1; foreach ($displayData as $row): ?>
                        <tr <?= $row['category'] === '** OVERALL **' ? 'class="table-info fw-bold"' : '' ?>>
                            <td class="text-center"><?= $sn++ ?></td>
                            <td class="text-left"><?= htmlspecialchars($row['category'] ?? 'Uncategorized') ?></td>
                            <td class="text-center"><strong><?= formatNumber($row['titles']) ?></strong></td>
                            <td class="text-center"><strong><?= formatNumber($row['total_copies']) ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="2" class="text-end">Overall Totals:</td>
                            <td class="text-center"><?= formatNumber($overall['total_titles']) ?></td>
                            <td class="text-center"><?= formatNumber($overall['total_copies']) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function exportReport(format) {
    let form = document.getElementById('filterForm');
    let url = 'books_titles_summary.php?format=' + format;
    let category = document.querySelector('select[name="category"]').value;
    let paperSize = document.querySelector('select[name="paper_size"]').value;
    let orientation = document.querySelector('select[name="orientation"]').value;
    if (category) url += '&category=' + encodeURIComponent(category);
    url += '&paper_size=' + encodeURIComponent(paperSize);
    url += '&orientation=' + encodeURIComponent(orientation);
    window.location.href = url;
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>s