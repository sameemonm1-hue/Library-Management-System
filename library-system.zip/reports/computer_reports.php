<?php
/**
 * Computer Usage Reports with Class/Dept and Div/Course filters
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */
session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();

// Filter parameters
$from_date = $_GET['from_date'] ?? date('Y-m-01');
$to_date = $_GET['to_date'] ?? date('Y-m-d');
$member_search = $_GET['member_search'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$computer_id = $_GET['computer_id'] ?? '';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ==================== BUILD QUERY ====================

$sql = "SELECT cs.*, 
               m.admno, m.name as member_name, m.member_category, m.class, m.division,
               c.computer_name, c.location as computer_location
        FROM computer_sessions cs
        LEFT JOIN members m ON cs.member_id = m.id
        LEFT JOIN computers c ON cs.computer_id = c.id
        WHERE 1=1";
$params = [];

if ($from_date) {
    $sql .= " AND DATE(cs.login_time) >= ?";
    $params[] = $from_date;
}
if ($to_date) {
    $sql .= " AND DATE(cs.login_time) <= ?";
    $params[] = $to_date;
}
if ($member_search) {
    $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)";
    $params[] = "%$member_search%";
    $params[] = "%$member_search%";
}
if (!empty($class)) {
    $sql .= " AND m.class LIKE ?";
    $params[] = "%$class%";
}
if (!empty($division)) {
    $sql .= " AND m.division LIKE ?";
    $params[] = "%$division%";
}
if ($computer_id) {
    $sql .= " AND cs.computer_id = ?";
    $params[] = $computer_id;
}
$sql .= " ORDER BY cs.login_time DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

$totalSessions = count($sessions);
$totalMinutes = array_sum(array_column($sessions, 'duration_minutes'));
$totalHours = round($totalMinutes / 60, 1);
$avgMinutes = $totalSessions > 0 ? round($totalMinutes / $totalSessions, 1) : 0;

$computers = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();

// ==================== EXPORT HANDLING ====================

if ($format === 'excel') {
    $institutionName = getInstitutionName();
    $computerName = '';
    if ($computer_id) {
        foreach ($computers as $c) {
            if ($c['id'] == $computer_id) {
                $computerName = $c['computer_name'];
                break;
            }
        }
    }
    $filters = [
        'Member' => $member_search ?: 'All',
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Computer' => $computerName ?: 'All'
    ];
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Computer Usage Report</title>
    <style>body{font-family:Arial;margin:20px}h2,h3,p{text-align:center}table{margin:0 auto;border-collapse:collapse;width:100%}th,td{border:1px solid #000;padding:6px;text-align:left}th{background:#1e3c72;color:white}</style>
    </head><body>';
    $html .= '<center><h2>' . htmlspecialchars($institutionName) . '</h2><h3>Computer Usage Report</h3>';
    $html .= '<p><b>Period:</b> ' . formatDate($from_date) . ' to ' . formatDate($to_date) . '</p>';
    foreach ($filters as $label => $value) {
        if ($value && $label !== 'Period') {
            $html .= '<p><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . '</p>';
        }
    }
    $html .= '<p><b>Generated:</b> ' . date('Y-m-d H:i:s') . '</p><hr></center>';
    $html .= '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%;">';
    $html .= '<thead><tr><th>Sl No</th><th>Member Name</th><th>Adm No</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Computer</th><th>Login Time</th><th>Logout Time</th><th>Duration (min)</th></tr></thead><tbody>';
    $sn = 1;
    foreach ($sessions as $s) {
        $html .= '<tr>';
        $html .= '<td>' . $sn++ . '</td>';
        $html .= '<td>' . htmlspecialchars($s['member_name'] ?? 'Unknown') . '</td>';
        $html .= '<td>' . htmlspecialchars($s['admno'] ?? '-') . '</td>';
        $html .= '<td>' . htmlspecialchars($s['member_category'] ?? '-') . '</td>';
        $html .= '<td>' . htmlspecialchars($s['class'] ?? '-') . '</td>';
        $html .= '<td>' . htmlspecialchars($s['division'] ?? '-') . '</td>';
        $html .= '<td>' . htmlspecialchars($s['computer_name'] ?? '-') . '</td>';
        $html .= '<td>' . date('d-m-Y H:i', strtotime($s['login_time'])) . '</td>';
        $html .= '<td>' . ($s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : 'Active') . '</td>';
        $html .= '<td>' . ($s['duration_minutes'] ?? '-') . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color:#f0f0f0; font-weight:bold;"><td colspan="9" align="right">Total Sessions: ' . $totalSessions . ' | Total Minutes:</td><td align="center">' . $totalMinutes . '</td></tr></tfoot>';
    $html .= '</table>';
    $html .= '<div style="margin:15px 0;padding:10px;background:#f5f5f5;border-left:4px solid #1e3c72;">
                <strong>Summary:</strong> Total Sessions: ' . $totalSessions . ' | Total Usage: ' . $totalHours . ' hrs | Avg Duration: ' . $avgMinutes . ' min
            </div>';
    $html .= '<p align="center">This is a system generated report.</p></body></html>';
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="computer_usage_report_' . date('Y-m-d') . '.xls"');
    echo $html;
    exit;
}

if ($format === 'pdf') {
    $institutionName = getInstitutionName();
    $computerName = '';
    if ($computer_id) {
        foreach ($computers as $c) {
            if ($c['id'] == $computer_id) {
                $computerName = $c['computer_name'];
                break;
            }
        }
    }
    $filters = [
        'Member' => $member_search ?: 'All',
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Computer' => $computerName ?: 'All'
    ];
    $exportData = [];
    $sn = 1;
    foreach ($sessions as $s) {
        $exportData[] = [
            'Sl No' => $sn++,
            'Member Name' => $s['member_name'] ?? 'Unknown',
            'Adm No' => $s['admno'] ?? '-',
            'Category' => $s['member_category'] ?? '-',
            'Class/Dept' => $s['class'] ?? '-',
            'Div/Course' => $s['division'] ?? '-',
            'Computer' => $s['computer_name'] ?? '-',
            'Login Time' => date('d-m-Y H:i', strtotime($s['login_time'])),
            'Logout Time' => $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : 'Active',
            'Duration (min)' => $s['duration_minutes'] ?? '-'
        ];
    }
    $headers = ['Sl No', 'Member Name', 'Adm No', 'Category', 'Class/Dept', 'Div/Course', 'Computer', 'Login Time', 'Logout Time', 'Duration (min)'];
    $title = 'Computer Usage Report';
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
    </style>
    </head><body>';
    $html .= getReportHeaderHTML($title, $from_date, $to_date, $filters);
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="9" class="text-right">Total Sessions: ' . $totalSessions . ' | Total Minutes:</td>';
    $html .= '<td class="text-center">' . $totalMinutes . '</td>';
    $html .= '</tr></tfoot></table>';
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total Sessions: ' . $totalSessions . ' | Total Usage: ' . $totalHours . ' hrs | Avg Duration: ' . $avgMinutes . ' min
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    exportToPDF($html, 'computer_usage_report_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
    exit;
}

// ==================== ON‑SCREEN DISPLAY ====================
renderHeader('Computer Usage Report');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-desktop"></i> Computer Usage Report</h2>
        <div>
            <a href="index.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4">
        <div class="card-header bg-white fw-bold">
            <i class="fas fa-filter"></i> Filter Reports
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label class="form-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" value="<?= htmlspecialchars($from_date) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" value="<?= htmlspecialchars($to_date) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Member (Adm No / Name)</label>
                    <input type="text" name="member_search" class="form-control" value="<?= htmlspecialchars($member_search) ?>" placeholder="Search...">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Class/Dept</label>
                    <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($class) ?>" placeholder="Class/Dept">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Div/Course</label>
                    <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($division) ?>" placeholder="Div/Course">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Computer</label>
                    <select name="computer_id" class="form-select">
                        <option value="">All Computers</option>
                        <?php foreach ($computers as $comp): ?>
                            <option value="<?= $comp['id'] ?>" <?= $computer_id == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Paper Size (PDF)</label>
                    <select name="paper_size" class="form-select">
                        <option value="A4" <?= $paperSize=='A4'?'selected':''?>>A4</option>
                        <option value="Letter" <?= $paperSize=='Letter'?'selected':''?>>Letter</option>
                        <option value="Legal" <?= $paperSize=='Legal'?'selected':''?>>Legal</option>
                        <option value="A3" <?= $paperSize=='A3'?'selected':''?>>A3</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Orientation</label>
                    <select name="orientation" class="form-select">
                        <option value="landscape" <?= $orientation=='landscape'?'selected':''?>>Landscape</option>
                        <option value="portrait" <?= $orientation=='portrait'?'selected':''?>>Portrait</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
                    <a href="?format=excel&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&member_search=<?= urlencode($member_search) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&computer_id=<?= urlencode($computer_id) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-success"><i class="fas fa-file-excel"></i> Export Excel</a>
                    <a href="?format=pdf&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&member_search=<?= urlencode($member_search) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&computer_id=<?= urlencode($computer_id) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> Export PDF</a>
                    <button type="button" onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
                    <a href="computer_reports.php" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Total Sessions</h6><h2 class="mb-0"><?= $totalSessions ?></h2></div>
                        <i class="fas fa-users fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Total Usage</h6><h2 class="mb-0"><?= $totalHours ?> hrs</h2></div>
                        <i class="fas fa-clock fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Avg Duration</h6><h2 class="mb-0"><?= $avgMinutes ?> min</h2></div>
                        <i class="fas fa-chart-line fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Report Table -->
    <div class="card">
        <div class="card-header bg-white fw-bold"><i class="fas fa-table"></i> Session Details</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr><th>Sl No</th><th>Member Name</th><th>Adm No</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Computer</th><th>Login Time</th><th>Logout Time</th><th>Duration (min)</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($sessions)): ?>
                            <tr><td colspan="10" class="text-center text-muted py-4">No sessions found for selected filters.</td></tr>
                        <?php else: ?>
                            <?php $sn = 1; foreach ($sessions as $s): ?>
                            <tr>
                                <td><?= $sn++ ?></td>
                                <td><?= htmlspecialchars($s['member_name'] ?? 'Unknown') ?></td>
                                <td><?= htmlspecialchars($s['admno'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['member_category'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['class'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['division'] ?? '-') ?></td>
                                <td><strong><?= htmlspecialchars($s['computer_name'] ?? '-') ?></strong><br><small><?= htmlspecialchars($s['computer_location'] ?? '') ?></small></td>
                                <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                                <td><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : '<span class="badge bg-warning">Active</span>' ?></td>
                                <td><?= $s['duration_minutes'] ?? '-' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="9" class="text-end">Total Sessions: <?= $totalSessions ?> | Total Minutes: <?= $totalMinutes ?></td>
                            <td><?= $totalMinutes ?> min</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<?php renderFooter(); ?>