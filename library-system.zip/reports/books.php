<?php
/**
 * Comprehensive Books Report Module
 * Version: 4.2 - COMPLETE FIXED VERSION
 * Added: Logo, Watermark, Signature support in PDF exports
 * Fixed: Duplicate "Sl No" column in PDF
 * Aligned: Numeric values right, dates center
 */

session_start(); // MUST BE FIRST

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();

// ==================== CONFIGURATION ====================
$reportType = $_GET['report_type'] ?? 'books';
$category = $_GET['category'] ?? 'all';
$status = $_GET['status'] ?? 'all';
$location = $_GET['location'] ?? '';
$year_from = $_GET['year_from'] ?? '';
$year_to = $_GET['year_to'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'title';
$sort_order = $_GET['sort_order'] ?? 'ASC';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// Export parameters
$format = $_GET['format'] ?? '';
$export_mode = $_GET['export_mode'] ?? 'copies';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== FIELD TOGGLE SYSTEM ====================

// Define all extended fields with their display names
$extendedFieldDefinitions = [
    'sub_title' => 'Sub Title',
    'author2' => 'Author 2',
    'collaborator' => 'Collaborator',
    'isbn' => 'ISBN',
    'issn' => 'ISSN',
    'language' => 'Language',
    'country' => 'Country',
    'category' => 'Category',
    'sub_category' => 'Sub Category',
    'collection_type' => 'Collection Type',
    'series' => 'Series',
    'ddc' => 'DDC',
    'udc' => 'UDC',
    'lcc' => 'LCC',
    'cc' => 'CC',
    'other_classification' => 'Other Classification',
    'cutter' => 'Cutter',
    'keywords' => 'Keywords',
    'summary' => 'Summary',
    'location' => 'Location',
    'section' => 'Section',
    'branch' => 'Branch',
    'shelf' => 'Shelf',
    'vendor' => 'Vendor',
    'invoice_date' => 'Invoice Date',
    'acquisition_date' => 'Acquisition Date',
    'funding_source' => 'Funding Source',
    'po_number' => 'PO Number',
    'ebook_url' => 'eBook URL',
    'contents' => 'Contents',
    'accompanying_material' => 'Accompanying Material',
    'material_type' => 'Material Type',
    'size' => 'Size',
    'weight' => 'Weight',
    'binding' => 'Binding',
    'book_status' => 'Book Status',
    'item_category' => 'Item Category',
    'maintenance' => 'Maintenance',
    'current_location' => 'Current Location',
    'total_lost' => 'Total Lost',
    'replacement_cost' => 'Replacement Cost',
    'accession_number' => 'Accession Number'
];

// Initialize field visibility in session if not exists
if (!isset($_SESSION['book_report_fields'])) {
    $_SESSION['book_report_fields'] = [];
    // Set all fields to OFF by default
    foreach ($extendedFieldDefinitions as $key => $label) {
        $_SESSION['book_report_fields'][$key] = false;
    }
}

// Handle field toggle
if (isset($_GET['toggle_field'])) {
    $field = $_GET['toggle_field'];
    if (array_key_exists($field, $extendedFieldDefinitions)) {
        $_SESSION['book_report_fields'][$field] = !$_SESSION['book_report_fields'][$field];
    }
    $redirectUrl = strtok($_SERVER['REQUEST_URI'], '?');
    $queryParams = $_GET;
    unset($queryParams['toggle_field']);
    if (!empty($queryParams)) {
        $redirectUrl .= '?' . http_build_query($queryParams);
    }
    header("Location: " . $redirectUrl);
    exit;
}

// Handle reset fields
if (isset($_GET['reset_fields'])) {
    foreach ($extendedFieldDefinitions as $key => $label) {
        $_SESSION['book_report_fields'][$key] = false;
    }
    $redirectUrl = strtok($_SERVER['REQUEST_URI'], '?');
    $queryParams = $_GET;
    unset($queryParams['reset_fields']);
    if (!empty($queryParams)) {
        $redirectUrl .= '?' . http_build_query($queryParams);
    }
    header("Location: " . $redirectUrl);
    exit;
}

// Get current field visibility
$showFields = $_SESSION['book_report_fields'];

// ==================== CHECK LIBRARIES ====================
$excelAvailable = false;
$pdfAvailable = false;

$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        $excelAvailable = true;
    }
    if (class_exists('Mpdf\Mpdf') || class_exists('Dompdf\Dompdf')) {
        $pdfAvailable = true;
    }
}

// ==================== HELPER FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function getCurrencySymbol($code = null) {
    if ($code === null) {
        $settings = getSettings();
        $code = $settings['currency_code'] ?? 'INR';
    }
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function formatCurrency($amount, $withSymbol = true) {
    $settings = getSettings();
    $symbol = getCurrencySymbol();
    $code = $settings['currency_code'] ?? 'INR';
    $position = $settings['currency_position'] ?? 'left';
    $decimals = (int)($settings['currency_decimal_places'] ?? 2);
    $formatted = number_format((float)$amount, $decimals);
    if ($withSymbol) {
        return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . $code;
    }
    return $formatted;
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function getInstitutionNameForReport() {
    return getInstitutionName();
}

// ==================== LOGO FUNCTIONS (from index.php) ====================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionNameForReport();
    
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    
    if (!$reportWatermarkEnabled) return $html;
    
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionNameForReport();
    $opacity = $reportWatermarkOpacity / 100;
    
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

// ==================== PDF GENERATION (from index.php) ====================

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    
    $html = addWatermarkToHTML($html);
    
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionNameForReport());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    
    // Fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ==================== BUILD QUERY ====================

function buildBooksQuery($db, $category, $status, $location, $year_from, $year_to, $price_min, $price_max, $sort_by, $sort_order) {
    $sql = "SELECT * FROM books WHERE 1=1";
    $params = [];
    
    if ($category !== 'all') {
        $sql .= " AND category = ?";
        $params[] = $category;
    }
    if ($status === 'available') {
        $sql .= " AND available > 0";
    } elseif ($status === 'unavailable') {
        $sql .= " AND available = 0";
    } elseif ($status === 'lowstock') {
        $sql .= " AND available > 0 AND available <= 2";
    }
    if (!empty($location)) {
        $sql .= " AND (location LIKE ? OR current_location LIKE ? OR shelf LIKE ? OR branch LIKE ?)";
        $like = "%$location%";
        $params = array_merge($params, [$like, $like, $like, $like]);
    }
    if (!empty($year_from)) {
        $sql .= " AND year >= ?";
        $params[] = $year_from;
    }
    if (!empty($year_to)) {
        $sql .= " AND year <= ?";
        $params[] = $year_to;
    }
    if ($price_min !== '') {
        $sql .= " AND price >= ?";
        $params[] = (float)$price_min;
    }
    if ($price_max !== '') {
        $sql .= " AND price <= ?";
        $params[] = (float)$price_max;
    }
    
    $allowed_sort = ['title','author','publisher','year','barcode','created_at','acquisition_date'];
    if (!in_array($sort_by, $allowed_sort)) $sort_by = 'title';
    $sort_order = strtoupper($sort_order) === 'DESC' ? 'DESC' : 'ASC';
    $sql .= " ORDER BY $sort_by $sort_order";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// ==================== EXPORT FUNCTIONS ====================

function exportBooksCSV($db, $data, $showFields, $title = 'Books Report') {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    
    $headers = ['Sl No', 'Date Added', 'Barcode', 'Accession No', 'Title', 'Author', 
                'Edition', 'Volume', 'Publisher', 'Year', 'Pages', 'Source', 
                'Price', 'Call No.', 'Date of Supply', 'Bill No.', 'Remark'];
    foreach ($showFields as $key => $visible) {
        if ($visible) {
            $headers[] = $GLOBALS['extendedFieldDefinitions'][$key] ?? $key;
        }
    }
    fputcsv($out, $headers);
    
    $sn = 1;
    foreach ($data as $row) {
        $values = [
            $sn++,
            $row['created_at'] ?? '',
            $row['barcode'] ?? '',
            $row['accession_number'] ?? '',
            $row['title'] ?? '',
            $row['author'] ?? '',
            $row['edition'] ?? '',
            $row['volume'] ?? '',
            $row['publisher'] ?? '',
            $row['year'] ?? '',
            $row['pages'] ?? 0,
            $row['vendor'] ?? '',
            formatCurrency($row['price'] ?? 0),
            $row['call_number'] ?? '',
            $row['invoice_date'] ?? '',
            $row['invoice'] ?? '',
            $row['remarks'] ?? ''
        ];
        foreach ($showFields as $key => $visible) {
            if ($visible) {
                $values[] = $row[$key] ?? '';
            }
        }
        fputcsv($out, $values);
    }
    fclose($out);
    exit;
}

function exportBooksExcel($db, $data, $showFields, $title = 'Books Report') {
    global $excelAvailable;
    while (ob_get_level()) ob_end_clean();
    
    if ($excelAvailable) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Books');
            $row = 1; $col = 'A';
            $coreHeaders = ['Sl No', 'Date Added', 'Barcode', 'Accession No', 'Title', 'Author', 
                           'Edition', 'Volume', 'Publisher', 'Year', 'Pages', 'Source', 
                           'Price', 'Call No.', 'Date of Supply', 'Bill No.', 'Remark'];
            foreach ($coreHeaders as $header) {
                $sheet->setCellValue($col . $row, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            foreach ($showFields as $key => $visible) {
                if ($visible) {
                    $sheet->setCellValue($col . $row, $GLOBALS['extendedFieldDefinitions'][$key] ?? $key);
                    $sheet->getColumnDimension($col)->setAutoSize(true);
                    $col++;
                }
            }
            $sheet->getStyle('A1:' . $col . '1')->getFont()->setBold(true);
            $row = 2; $sn = 1;
            foreach ($data as $book) {
                $col = 'A';
                $values = [
                    $sn++,
                    $book['created_at'] ?? '',
                    $book['barcode'] ?? '',
                    $book['accession_number'] ?? '',
                    $book['title'] ?? '',
                    $book['author'] ?? '',
                    $book['edition'] ?? '',
                    $book['volume'] ?? '',
                    $book['publisher'] ?? '',
                    $book['year'] ?? '',
                    $book['pages'] ?? 0,
                    $book['vendor'] ?? '',
                    formatCurrency($book['price'] ?? 0),
                    $book['call_number'] ?? '',
                    $book['invoice_date'] ?? '',
                    $book['invoice'] ?? '',
                    $book['remarks'] ?? ''
                ];
                foreach ($values as $value) {
                    $sheet->setCellValue($col . $row, $value);
                    $col++;
                }
                foreach ($showFields as $key => $visible) {
                    if ($visible) {
                        $sheet->setCellValue($col . $row, $book[$key] ?? '');
                        $col++;
                    }
                }
                $row++;
            }
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="books_' . date('Y-m-d') . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) {
            error_log("Excel export error: " . $e->getMessage());
        }
    }
    exportBooksCSV($db, $data, $showFields, $title);
}

// ==================== FIXED PDF EXPORT ====================

function exportBooksPDF($db, $data, $showFields, $title = 'Books Report', $paperSize = 'A4', $orientation = 'landscape') {
    global $pdfAvailable, $reportPrimaryColor, $currencySymbol, $currencyDecimalPlaces;
    
    while (ob_get_level()) ob_end_clean();
    
    // Build data array with keys including 'Sl No' for consistent processing
    $exportData = [];
    $sn = 1;
    foreach ($data as $book) {
        $row = [
            'Sl No' => $sn++,
            'Date Added' => $book['created_at'] ?? '',
            'Barcode' => $book['barcode'] ?? '',
            'Accession No' => $book['accession_number'] ?? '',
            'Title' => $book['title'] ?? '',
            'Author' => $book['author'] ?? '',
            'Edition' => $book['edition'] ?? '',
            'Volume' => $book['volume'] ?? '',
            'Publisher' => $book['publisher'] ?? '',
            'Year' => $book['year'] ?? '',
            'Pages' => $book['pages'] ?? 0,
            'Source' => $book['vendor'] ?? '',
            'Price' => formatCurrency($book['price'] ?? 0, true),
            'Call No.' => $book['call_number'] ?? '',
            'Supply Date' => $book['invoice_date'] ?? '',
            'Bill No.' => $book['invoice'] ?? '',
            'Remark' => $book['remarks'] ?? ''
        ];
        // Add extended fields
        foreach ($showFields as $key => $visible) {
            if ($visible) {
                $row[$GLOBALS['extendedFieldDefinitions'][$key] ?? $key] = $book[$key] ?? '';
            }
        }
        $exportData[] = $row;
    }
    
    // Build headers from the first row keys
    $headers = array_keys($exportData[0] ?? []);
    if (empty($headers)) {
        $headers = ['No Data'];
    }
    
    // Generate HTML for PDF
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
        </style>
    </head>
    <body>';
    
    // Header with logo
    $html .= getReportHeaderHTML($title, null, null, [
        'Category' => $GLOBALS['category'] ?? 'All',
        'Status' => $GLOBALS['status'] ?? 'All',
        'Location' => $GLOBALS['location'] ?? 'All'
    ]);
    
    // Table
    $html .= '<table>';
    $html .= '<thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; } // Skip 'Sl No' to avoid duplicate
            if (is_numeric($value) && $value > 1000) {
                $html .= '<td class="text-right">' . number_format($value) . '</td>';
            } elseif (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '0000-00-00') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="' . (count($headers) - 1) . '" class="text-right">Total Records:</td>';
    $html .= '<td class="text-center">' . count($exportData) . '</td>';
    $html .= '</tr></tfoot></table>';
    
    // Summary
    $totalPrice = array_sum(array_column($data, 'price'));
    $totalQty = array_sum(array_column($data, 'quantity'));
    $totalAvail = array_sum(array_column($data, 'available'));
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total Records: ' . count($exportData) . ' | Total Copies: ' . $totalQty . ' | Available: ' . $totalAvail . ' | Total Price: ' . formatCurrency($totalPrice) . '
    </div>';
    
    // Footer with signature
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    
    // Export to PDF
    exportToPDF($html, $title . '_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
}

// ==================== HANDLE EXPORT REQUESTS ====================

if (isset($_GET['export'])) {
    $data = buildBooksQuery($db, $category, $status, $location, $year_from, $year_to, $price_min, $price_max, $sort_by, $sort_order);
    $exportType = $_GET['export'];
    
    if ($exportType === 'csv') {
        exportBooksCSV($db, $data, $showFields, 'Books Report');
    } elseif ($exportType === 'excel') {
        exportBooksExcel($db, $data, $showFields, 'Books Report');
    } elseif ($exportType === 'pdf') {
        exportBooksPDF($db, $data, $showFields, 'Books Report', $paperSize, $orientation);
    }
}

// ==================== FETCH DATA FOR DISPLAY ====================

$books = buildBooksQuery($db, $category, $status, $location, $year_from, $year_to, $price_min, $price_max, $sort_by, $sort_order);

$totalRecords = count($books);
$totalPrice = array_sum(array_column($books, 'price'));
$totalAvailable = array_sum(array_column($books, 'available'));
$totalQuantity = array_sum(array_column($books, 'quantity'));

$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

$institution = getInstitution();
$settings = getSettings();

renderHeader('Books Report');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books Report - Library System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .container { max-width: 1400px; margin-top: 20px; }
        .stat-card { transition: transform 0.2s; cursor: pointer; border: none; }
        .stat-card:hover { transform: translateY(-5px); }
        .filter-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .export-dropdown .btn { min-width: 80px; }
        @media print { .no-print { display: none !important; } }
        .table-responsive { overflow-x: auto; }
        .table th { background: #1e3c72; color: white; white-space: nowrap; }
        .table td { white-space: nowrap; }
        .field-toggle { cursor: pointer; user-select: none; }
        .field-toggle:hover { background: #e9ecef; }
        .toggle-on { color: #28a745; }
        .toggle-off { color: #6c757d; }
    </style>
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h2><i class="fas fa-book"></i> Books Report</h2>
            <p class="text-muted small"><?= $totalRecords ?> records, <?= $totalQuantity ?> copies, <?= $totalAvailable ?> available</p>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <div class="dropdown export-dropdown">
                <button class="btn btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-download"></i> Export
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#" onclick="exportReport('csv')"><i class="fas fa-file-csv"></i> CSV</a></li>
                    <?php if ($excelAvailable): ?>
                    <li><a class="dropdown-item" href="#" onclick="exportReport('excel')"><i class="fas fa-file-excel"></i> Excel</a></li>
                    <?php endif; ?>
                    <?php if ($pdfAvailable): ?>
                    <li><a class="dropdown-item" href="#" onclick="exportReport('pdf')"><i class="fas fa-file-pdf"></i> PDF</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <button type="button" class="btn btn-secondary" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#fieldToggleModal">
                <i class="fas fa-columns"></i> Fields (<?= count(array_filter($showFields)) ?> visible)
            </button>
            <?php if (array_filter($showFields)): ?>
            <a href="?reset_fields=1" class="btn btn-warning"><i class="fas fa-undo"></i> Reset Fields</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Statistics -->
    <div class="row mb-4">
        <div class="col-md-3"><div class="card stat-card bg-primary text-white"><div class="card-body text-center"><h3><?= number_format($totalRecords) ?></h3><p>Total Records</p></div></div></div>
        <div class="col-md-3"><div class="card stat-card bg-success text-white"><div class="card-body text-center"><h3><?= number_format($totalQuantity) ?></h3><p>Total Copies</p></div></div></div>
        <div class="col-md-3"><div class="card stat-card bg-info text-white"><div class="card-body text-center"><h3><?= number_format($totalAvailable) ?></h3><p>Available</p></div></div></div>
        <div class="col-md-3"><div class="card stat-card bg-warning text-white"><div class="card-body text-center"><h3><?= number_format($totalQuantity - $totalAvailable) ?></h3><p>Issued</p></div></div></div>
    </div>

    <!-- Filters -->
    <div class="card filter-card mb-4 no-print">
        <div class="card-header bg-white py-2">
            <i class="fas fa-filter"></i> Filters
            <button class="btn btn-sm btn-secondary float-end" type="button" data-bs-toggle="collapse" data-bs-target="#filterCollapse">
                <i class="fas fa-chevron-down"></i>
            </button>
        </div>
        <div class="collapse show" id="filterCollapse">
            <div class="card-body">
                <form method="get" id="filterForm">
                    <div class="row g-2">
                        <div class="col-md-2">
                            <label class="form-label small">Category</label>
                            <select name="category" class="form-select form-select-sm">
                                <option value="all">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Status</label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="all">All Books</option>
                                <option value="available" <?= $status === 'available' ? 'selected' : '' ?>>Available</option>
                                <option value="unavailable" <?= $status === 'unavailable' ? 'selected' : '' ?>>Issued/Unavailable</option>
                                <option value="lowstock" <?= $status === 'lowstock' ? 'selected' : '' ?>>Low Stock (≤2)</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Location</label>
                            <input type="text" name="location" class="form-control form-control-sm" value="<?= htmlspecialchars($location) ?>" placeholder="Shelf, Section, Branch">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Year From</label>
                            <input type="text" name="year_from" class="form-control form-control-sm" value="<?= htmlspecialchars($year_from) ?>" placeholder="e.g., 2020">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Year To</label>
                            <input type="text" name="year_to" class="form-control form-control-sm" value="<?= htmlspecialchars($year_to) ?>" placeholder="e.g., 2025">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Sort By</label>
                            <select name="sort_by" class="form-select form-select-sm">
                                <option value="title" <?= $sort_by === 'title' ? 'selected' : '' ?>>Title</option>
                                <option value="author" <?= $sort_by === 'author' ? 'selected' : '' ?>>Author</option>
                                <option value="publisher" <?= $sort_by === 'publisher' ? 'selected' : '' ?>>Publisher</option>
                                <option value="year" <?= $sort_by === 'year' ? 'selected' : '' ?>>Year</option>
                                <option value="barcode" <?= $sort_by === 'barcode' ? 'selected' : '' ?>>Barcode</option>
                                <option value="created_at" <?= $sort_by === 'created_at' ? 'selected' : '' ?>>Date Added</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mt-2">
                        <div class="col-md-2">
                            <label class="form-label small">Price Min</label>
                            <input type="number" step="0.01" name="price_min" class="form-control form-control-sm" value="<?= htmlspecialchars($price_min) ?>" placeholder="0.00">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Price Max</label>
                            <input type="number" step="0.01" name="price_max" class="form-control form-control-sm" value="<?= htmlspecialchars($price_max) ?>" placeholder="9999.00">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Paper Size</label>
                            <select name="paper_size" class="form-select form-select-sm">
                                <option value="A4" <?= $paperSize === 'A4' ? 'selected' : '' ?>>A4</option>
                                <option value="Letter" <?= $paperSize === 'Letter' ? 'selected' : '' ?>>Letter</option>
                                <option value="Legal" <?= $paperSize === 'Legal' ? 'selected' : '' ?>>Legal</option>
                                <option value="A3" <?= $paperSize === 'A3' ? 'selected' : '' ?>>A3</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label small">Orientation</label>
                            <select name="orientation" class="form-select form-select-sm">
                                <option value="landscape" <?= $orientation === 'landscape' ? 'selected' : '' ?>>Landscape</option>
                                <option value="portrait" <?= $orientation === 'portrait' ? 'selected' : '' ?>>Portrait</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end gap-2">
                            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Apply</button>
                            <a href="books_report.php" class="btn btn-secondary btn-sm"><i class="fas fa-undo"></i> Reset</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Books Table -->
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> Books List</span>
            <span class="badge bg-secondary"><?= count($books) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-striped mb-0">
                    <thead>
                        <tr>
                            <th style="text-align:center;width:40px;">#</th>
                            <th>Date Added</th>
                            <th>Barcode</th>
                            <th>Acc. No.</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Edition</th>
                            <th>Volume</th>
                            <th>Publisher</th>
                            <th>Year</th>
                            <th>Pages</th>
                            <th>Source</th>
                            <th style="text-align:right;">Price</th>
                            <th>Call No.</th>
                            <th>Supply Date</th>
                            <th>Bill No.</th>
                            <th>Remark</th>
                            <?php foreach ($showFields as $key => $visible): if ($visible): ?>
                            <th><?= htmlspecialchars($extendedFieldDefinitions[$key] ?? $key) ?></th>
                            <?php endif; endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn = 1; foreach ($books as $book): ?>
                        <tr>
                            <td style="text-align:center;"><?= $sn++ ?></td>
                            <td><?= date('d-m-Y', strtotime($book['created_at'] ?? 'now')) ?></td>
                            <td><code><?= htmlspecialchars($book['barcode'] ?? '-') ?></code></td>
                            <td><?= htmlspecialchars($book['accession_number'] ?? '-') ?></td>
                            <td><strong><?= htmlspecialchars(substr($book['title'] ?? '', 0, 60)) ?></strong></td>
                            <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['edition'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['volume'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['publisher'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['year'] ?? '-') ?></td>
                            <td><?= $book['pages'] ?? 0 ?></td>
                            <td><?= htmlspecialchars($book['vendor'] ?? '-') ?></td>
                            <td style="text-align:right;"><?= formatCurrency($book['price'] ?? 0) ?></td>
                            <td><?= htmlspecialchars($book['call_number'] ?? '-') ?></td>
                            <td><?= $book['invoice_date'] ? date('d-m-Y', strtotime($book['invoice_date'])) : '-' ?></td>
                            <td><?= htmlspecialchars($book['invoice'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['remarks'] ?? '-') ?></td>
                            <?php foreach ($showFields as $key => $visible): if ($visible): ?>
                            <td><?= htmlspecialchars($book[$key] ?? '-') ?></td>
                            <?php endif; endforeach; ?>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($books)): ?>
                        <tr><td colspan="30" class="text-center py-4 text-muted">No books found matching the filters.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($books)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="12" class="text-end">Totals:</td>
                            <td style="text-align:right;"><?= formatCurrency(array_sum(array_column($books, 'price'))) ?></td>
                            <td colspan="4"></td>
                            <?php
                            $extraCols = array_filter($showFields);
                            $extraCount = count($extraCols);
                            if ($extraCount > 0) {
                                echo '<td colspan="' . $extraCount . '"></td>';
                            }
                            ?>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="mt-4 text-center text-muted small">
        <p>Books Report &copy; <?= date('Y') ?> <?= htmlspecialchars(getInstitutionNameForReport()) ?></p>
    </div>
</div>

<!-- Field Toggle Modal -->
<div class="modal fade" id="fieldToggleModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-columns"></i> Show/Hide Fields</h5>
                <p class="mb-0 ms-3 text-white-50"><?= count(array_filter($showFields)) ?> of <?= count($extendedFieldDefinitions) ?> extended fields visible</p>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Click on any field name to toggle visibility. Extended fields are shown/hidden dynamically.
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-primary">Core Fields (Always Visible)</h6>
                        <ul class="list-group mb-3">
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Sl No</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Date Added</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Barcode</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Accession No.</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Title</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Author</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Edition</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Volume</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Publisher</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Year of Publication</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Pages</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Source</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Price</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Call No.</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Date of Supply + Bill No.</li>
                            <li class="list-group-item"><i class="fas fa-check-circle text-success"></i> Remark</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-secondary">Extended Fields <small class="text-muted">(Click to toggle)</small></h6>
                        <ul class="list-group">
                            <?php foreach ($extendedFieldDefinitions as $key => $label): ?>
                            <?php $isVisible = $showFields[$key] ?? false; ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center field-toggle" 
                                onclick="window.location.href='?toggle_field=<?= $key ?>&<?= http_build_query(array_diff_key($_GET, ['toggle_field' => 1])) ?>'"
                                style="cursor:pointer;">
                                <span>
                                    <i class="fas fa-<?= $isVisible ? 'eye text-success' : 'eye-slash text-secondary' ?>"></i>
                                    <?= htmlspecialchars($label) ?>
                                </span>
                                <span class="badge <?= $isVisible ? 'bg-success' : 'bg-secondary' ?>">
                                    <?= $isVisible ? 'Visible' : 'Hidden' ?>
                                </span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="?reset_fields=1&<?= http_build_query(array_diff_key($_GET, ['reset_fields' => 1])) ?>" class="btn btn-warning">
                    <i class="fas fa-undo"></i> Reset All
                </a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function exportReport(format) {
    let form = document.getElementById('filterForm');
    let url = '?export=' + format;
    let inputs = form.querySelectorAll('input, select');
    inputs.forEach(function(input) {
        if (input.name && input.value) {
            url += '&' + encodeURIComponent(input.name) + '=' + encodeURIComponent(input.value);
        }
    });
    let paperSize = document.querySelector('select[name="paper_size"]');
    let orientation = document.querySelector('select[name="orientation"]');
    if (paperSize) url += '&paper_size=' + encodeURIComponent(paperSize.value);
    if (orientation) url += '&orientation=' + encodeURIComponent(orientation.value);
    window.location.href = url;
}

document.querySelectorAll('select[name="category"], select[name="status"], select[name="sort_by"]').forEach(function(el) {
    el.addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });
});

window.onbeforeprint = function() { console.log('Printing report...'); };
</script>

<style>
@media print {
    .no-print { display: none !important; }
    .card { border: none !important; box-shadow: none !important; }
    .card-header { background: #f8f9fa !important; }
    .table thead th { background: #1e3c72 !important; color: white !important; }
    .modal { display: none !important; }
}
</style>

<?php renderFooter(); ?>