<?php
/**
 * Overdue Books Report
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$finePerDay = (float)($settings['fine_per_day'] ?? 2);
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ==================== BUILD QUERY ====================

$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';

$sql = "SELECT c.*, 
        m.name as member_name, m.class, m.division,
        b.title, b.author, b.isbn
        FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno
        LEFT JOIN books b ON c.barcode = b.barcode
        WHERE c.return_date IS NULL AND c.due_date < date('now')";
$params = [];

if($class) {
    $sql .= " AND m.class LIKE ?";
    $params[] = "%$class%";
}
if($division) {
    $sql .= " AND m.division LIKE ?";
    $params[] = "%$division%";
}

$sql .= " ORDER BY c.due_date ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$overdueBooks = $stmt->fetchAll();

$totalFine = 0;
foreach($overdueBooks as $book) {
    $days = ceil((time() - strtotime($book['due_date'])) / 86400);
    $totalFine += $days * $finePerDay;
}

// ==================== EXPORT HANDLING ====================

if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $paperSize = $_GET['paper_size'] ?? 'A4';
    $orientation = $_GET['orientation'] ?? 'landscape';
    
    if ($exportType === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="overdue_books_' . date('Y-m-d') . '.xls"');
        $institutionName = getInstitutionName();
        $filters = [];
        if($class) $filters['Class/Department'] = $class;
        if($division) $filters['Division/Course'] = $division;
        echo "<html><head><meta charset='UTF-8'><title>Overdue Books Report</title>";
        echo "<style>th{background:#dc3545;color:white;padding:8px;}td{padding:6px;}table{border-collapse:collapse;width:100%;}th,td{border:1px solid #000;}</style>";
        echo "</head><body>";
        echo "<h2>" . htmlspecialchars($institutionName) . "</h2>";
        echo "<h3>Overdue Books Report</h3>";
        echo "<p><b>Generated:</b> " . date('Y-m-d H:i:s') . "</p>";
        if(!empty($filters)) {
            foreach ($filters as $label => $value) {
                echo "<p><b>" . htmlspecialchars($label) . ":</b> " . htmlspecialchars($value) . "</p>";
            }
        }
        echo "<hr>";
        echo "<table border='1' cellpadding='5' cellspacing='0' style='border-collapse: collapse; width: 100%;'>";
        echo "<thead><tr><th>Sl No</th><th>Adm/Mem No</th><th>Member Name</th><th>Class/Dept</th><th>Div/Course</th><th>Book Title</th><th>Author</th><th>ISBN</th><th>Issue Date</th><th>Due Date</th><th>Days Overdue</th><th>Fine Amount</th></tr></thead><tbody>";
        $sl = 1;
        foreach($overdueBooks as $book) {
            $days = ceil((time() - strtotime($book['due_date'])) / 86400);
            $fine = $days * $finePerDay;
            echo "<tr>
                    <td align='center'>{$sl}</td>
                    <td>" . htmlspecialchars($book['admno']) . "</td>
                    <td>" . htmlspecialchars($book['member_name']) . "</td>
                    <td>" . htmlspecialchars($book['class'] ?? '-') . "</td>
                    <td>" . htmlspecialchars($book['division'] ?? '-') . "</td>
                    <td>" . htmlspecialchars($book['title'] ?? 'N/A') . "</td>
                    <td>" . htmlspecialchars($book['author'] ?? '-') . "</td>
                    <td>" . htmlspecialchars($book['isbn'] ?? '-') . "</td>
                    <td>" . formatDate($book['issue_date']) . "</td>
                    <td>" . formatDate($book['due_date']) . "</td>
                    <td align='center'>{$days}</td>
                    <td align='right'>" . formatCurrency($fine) . "</td>
                  </tr>";
            $sl++;
        }
        echo "</tbody>";
        echo "<tfoot><tr style='background-color:#f0f0f0;font-weight:bold;'><td colspan='11' align='right'>Total Fine:</td><td align='right'>" . formatCurrency($totalFine) . "</td></tr></tfoot>";
        echo "</table>";
        echo "<p align='center' style='margin-top:20px;'>This is a system generated report from Library Management System</p>";
        echo "</body></html>";
        exit;
    }
    
    elseif ($exportType === 'pdf') {
        $institutionName = getInstitutionName();
        $filters = [];
        if($class) $filters['Class/Department'] = $class;
        if($division) $filters['Division/Course'] = $division;
        $exportData = [];
        $sn = 1;
        foreach($overdueBooks as $book) {
            $days = ceil((time() - strtotime($book['due_date'])) / 86400);
            $fine = $days * $finePerDay;
            $exportData[] = [
                'Sl No' => $sn++,
                'Adm No' => $book['admno'],
                'Member Name' => $book['member_name'],
                'Class' => $book['class'] ?? '-',
                'Division' => $book['division'] ?? '-',
                'Book Title' => $book['title'] ?? 'N/A',
                'Author' => $book['author'] ?? '-',
                'Issue Date' => formatDate($book['issue_date']),
                'Due Date' => formatDate($book['due_date']),
                'Days' => $days,
                'Fine' => formatCurrency($fine)
            ];
        }
        $headers = ['Sl No', 'Adm No', 'Member Name', 'Class', 'Division', 'Book Title', 'Author', 'Issue Date', 'Due Date', 'Days', 'Fine'];
        $title = 'Overdue Books Report';
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: #dc3545; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
        </style>
        </head><body>';
        $html .= getReportHeaderHTML($title, null, null, $filters);
        $html .= '<table><thead><tr>';
        foreach ($headers as $header) {
            $html .= '<th>' . htmlspecialchars($header) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($exportData as $row) {
            $html .= '<tr>';
            $first = true;
            foreach ($row as $key => $value) {
                if ($first) { $first = false; continue; }
                if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                    $html .= '<td class="text-right">' . $value . '</td>';
                } elseif (is_numeric($value)) {
                    $html .= '<td class="text-right">' . $value . '</td>';
                } elseif (empty($value) || $value === '-') {
                    $html .= '<td class="text-center">-</td>';
                } else {
                    $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                }
            }
            $html .= '</tr>';
        }
        $html .= '</tbody>';
        $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
        $html .= '<td colspan="10" class="text-right">Total Fine:</td>';
        $html .= '<td class="text-right">' . formatCurrency($totalFine) . '</td>';
        $html .= '</tr></tfoot></table>';
        $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid #dc3545; font-size: 10px;">
            <strong>Summary:</strong> Total Overdue Books: ' . count($overdueBooks) . ' | Total Fine Amount: ' . formatCurrency($totalFine) . ' | Fine per Day: ' . formatCurrency($finePerDay) . ' | Members Affected: ' . count(array_unique(array_column($overdueBooks, 'admno'))) . '
        </div>';
        $html .= getReportFooterHTML();
        $html .= '</body></html>';
        exportToPDF($html, 'overdue_books_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
        exit;
    }
}

// ==================== ON‑SCREEN DISPLAY ====================
renderHeader('Overdue Books');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-exclamation-triangle text-danger"></i> Overdue Books</h2>
        <div>
            <div class="btn-group me-2">
                <button type="button" class="btn btn-success" onclick="exportExcel()">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </div>
            <div class="btn-group me-2">
                <button type="button" class="btn btn-danger dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-file-pdf"></i> Export PDF
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'portrait')">A4 Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'landscape')">A4 Landscape</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'portrait')">Letter Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'landscape')">Letter Landscape</a></li>
                </ul>
            </div>
            <button type="button" class="btn btn-info" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
        </div>
    </div>
    
    <!-- Filter Form -->
    <div class="card mb-4">
        <div class="card-header bg-info text-white">
            <i class="fas fa-filter"></i> Filter Overdue Books
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Class/Department</label>
                    <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($class) ?>" placeholder="Search by class/department">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Division/Course</label>
                    <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($division) ?>" placeholder="Search by division/course">
                </div>
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary flex-grow-1"><i class="fas fa-search"></i> Apply Filter</button>
                        <a href="overdue.php" class="btn btn-secondary">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Total Overdue</h6><h2 class="mb-0"><?= count($overdueBooks) ?></h2></div>
                        <i class="fas fa-clock fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Total Fine</h6><h2 class="mb-0"><?= formatCurrency($totalFine) ?></h2></div>
                        <i class="fas fa-dollar-sign fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Fine per Day</h6><h2 class="mb-0"><?= formatCurrency($finePerDay) ?></h2></div>
                        <i class="fas fa-charging-station fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><h6 class="mb-0">Members</h6><h2 class="mb-0"><?= count(array_unique(array_column($overdueBooks, 'admno'))) ?></h2></div>
                        <i class="fas fa-users fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header bg-danger text-white">
            <i class="fas fa-clock"></i> Overdue Books List
            <span class="float-end">Total: <?= count($overdueBooks) ?> | Fine: <?= formatCurrency($totalFine) ?></span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-danger">
                        <tr><th>Sl No</th><th>Adm No</th><th>Member Name</th><th>Class</th><th>Division</th><th>Book Title</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Days</th><th>Fine</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php $sn = 1; foreach($overdueBooks as $book): 
                            $days = ceil((time() - strtotime($book['due_date'])) / 86400);
                            $fine = $days * $finePerDay;
                        ?>
                        <tr>
                            <td><?= $sn++ ?></td>
                            <td><?= htmlspecialchars($book['admno']) ?></td>
                            <td><?= htmlspecialchars($book['member_name']) ?></td>
                            <td><?= htmlspecialchars($book['class'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['division'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['title'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                            <td><?= formatDate($book['issue_date']) ?></td>
                            <td><?= formatDate($book['due_date']) ?> <span class="badge bg-danger"><?= $days ?>d</span></td>
                            <td><span class="fw-bold text-danger"><?= formatCurrency($fine) ?></span></td>
                            <td>
                                <form method="post" action="return.php" style="display:inline-block">
                                    <input type="hidden" name="barcode" value="<?= htmlspecialchars($book['barcode']) ?>">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <button type="submit" name="return" class="btn btn-sm btn-warning" onclick="return confirm('Process return with fine?')">
                                        <i class="fas fa-undo"></i> Return
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($overdueBooks)): ?>
                        <tr><td colspan="12" class="text-center py-4">No overdue books found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if(!empty($overdueBooks)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="10" class="text-end">Total Estimated Fine:</td>
                            <td colspan="2"><?= formatCurrency($totalFine) ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function exportExcel() {
    let classFilter = document.querySelector('input[name="class"]').value;
    let divisionFilter = document.querySelector('input[name="division"]').value;
    let url = '?export=excel';
    if(classFilter) url += '&class=' + encodeURIComponent(classFilter);
    if(divisionFilter) url += '&division=' + encodeURIComponent(divisionFilter);
    window.location.href = url;
}
function exportPDF(paperSize, orientation) {
    let classFilter = document.querySelector('input[name="class"]').value;
    let divisionFilter = document.querySelector('input[name="division"]').value;
    let url = '?export=pdf&paper_size=' + paperSize + '&orientation=' + orientation;
    if(classFilter) url += '&class=' + encodeURIComponent(classFilter);
    if(divisionFilter) url += '&division=' + encodeURIComponent(divisionFilter);
    window.location.href = url;
}
</script>

<?php renderFooter(); ?>