<?php
/**
 * Advanced Reports Module - Version 10.4 (UNIFIED GRADIENT COLORS)
 * All 17 report types fully functional with proper data fetching and export
 * 
 * @package LibraryERP
 * @author  Sameermon
 * @version 10.4
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

// ==================== LOAD COMPOSER AUTOLOAD ====================
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

// ==================== ERROR HANDLING ====================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
$logDir = __DIR__ . '/../logs/';
if (!is_dir($logDir)) mkdir($logDir, 0777, true);
ini_set('error_log', $logDir . 'report_errors.log');

// ==================== REQUIRE LOGIN ====================
requireLogin();

// ==================== DATABASE CONNECTION ====================
$db = getDB();

// ==================== REPORT PARAMETERS ====================
$reportType = $_GET['type'] ?? 'members';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';
$format = $_GET['format'] ?? '';
$limit = (int)($_GET['limit'] ?? 100);
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// Filter variables
$filterClass = $_GET['filter_class'] ?? '';
$filterDivision = $_GET['filter_division'] ?? '';
$overdueMinDays = $_GET['overdue_min_days'] ?? '';
$overdueFromDate = $_GET['overdue_from_date'] ?? date('Y-m-01');
$overdueToDate = $_GET['overdue_to_date'] ?? date('Y-m-d');
$computerMemberSearch = $_GET['computer_member_search'] ?? '';
$computerId = $_GET['computer_id'] ?? '';
$computerFromDate = $_GET['computer_from_date'] ?? date('Y-m-01');
$computerToDate = $_GET['computer_to_date'] ?? date('Y-m-d');
$category = $_GET['category'] ?? 'all';
$status = $_GET['status'] ?? 'all';
$location = $_GET['location'] ?? '';
$memberCategoryFilter = $_GET['member_category'] ?? 'all';
$bookCategoryFilter = $_GET['book_category'] ?? 'all';
$paymentMethod = $_GET['payment_method'] ?? 'all';
$fineFromDate = $_GET['fine_from_date'] ?? date('Y-m-01');
$fineToDate = $_GET['fine_to_date'] ?? date('Y-m-d');
$admno = $_GET['admno'] ?? '';
$purpose = $_GET['purpose'] ?? '';

// ==================== SETTINGS ====================
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);
$finePerDay = (float)($settings['fine_per_day'] ?? 2);

// ==================== CONSTANTS ====================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}
define('ITEMS_PER_PAGE', $limit);

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function formatTime($time, $format = 'H:i:s') {
    if (empty($time)) return '';
    try {
        return date($format, strtotime($time));
    } catch (Exception $e) {
        return $time;
    }
}

function getStatusBadge($status) {
    $badges = [
        'active' => 'success',
        'inactive' => 'secondary',
        'suspended' => 'warning',
        'blocked' => 'danger',
        'Returned' => 'success',
        'Overdue' => 'danger',
        'Issued' => 'primary',
        'Available' => 'success',
        'Unavailable' => 'danger',
        'Low Stock' => 'warning',
        'paid' => 'success',
        'pending' => 'warning',
        'refunded' => 'info',
        'overdue' => 'danger'
    ];
    return $badges[$status] ?? 'secondary';
}

function getTransactionSummary($db, $from, $to) {
    try {
        $sql = "SELECT 
                    COUNT(*) as total_transactions,
                    SUM(CASE WHEN return_date IS NULL AND due_date >= date('now') THEN 1 ELSE 0 END) as active_loans,
                    SUM(CASE WHEN return_date IS NOT NULL THEN 1 ELSE 0 END) as returns_count,
                    SUM(COALESCE(fine, 0)) as total_fines
                FROM circulation 
                WHERE DATE(issue_date) BETWEEN ? AND ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$from, $to]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$result) {
            return ['total_transactions' => 0, 'active_loans' => 0, 'returns_count' => 0, 'total_fines' => 0];
        }
        return $result;
    } catch (Exception $e) {
        error_log("getTransactionSummary error: " . $e->getMessage());
        return ['total_transactions' => 0, 'active_loans' => 0, 'returns_count' => 0, 'total_fines' => 0];
    }
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

// =============================================================================
// REPORT HEADER / FOOTER / WATERMARK
// =============================================================================

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } 
    else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $institutionName = getInstitutionName();
    $currentYear = date('Y');
    
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . $currentYear . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.';
    $html .= '</div>';
    
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// DATA FETCHING FUNCTIONS - ALL REPORT TYPES (SQLite Compatible)
// =============================================================================

// ==================== 1. MEMBERS REPORT ====================
function getMembersData($db, $category = 'all', $class = '', $division = '', $status = 'all', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT id, admno, name, member_category, class, division, email, phone, 
                       COALESCE(active_books, 0) as active_books, 
                       COALESCE(total_issued, 0) as total_issued, 
                       COALESCE(total_fines, 0) as total_fines, 
                       status 
                FROM members WHERE 1=1";
        $params = [];
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND member_category = ?"; 
            $params[] = $category; 
        }
        if (!empty($class)) { 
            $sql .= " AND class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if ($status !== 'all' && !empty($status)) { 
            $sql .= " AND status = ?"; 
            $params[] = $status; 
        }
        $sql .= " ORDER BY name LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getMembersData error: " . $e->getMessage());
        return [];
    }
}

function getMembersCount($db, $category = 'all', $class = '', $division = '', $status = 'all') {
    try {
        $sql = "SELECT COUNT(*) FROM members WHERE 1=1";
        $params = [];
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND member_category = ?"; 
            $params[] = $category; 
        }
        if (!empty($class)) { 
            $sql .= " AND class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if ($status !== 'all' && !empty($status)) { 
            $sql .= " AND status = ?"; 
            $params[] = $status; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getMembersCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 2. BOOKS REPORT ====================
function getBooksData($db, $category = 'all', $status = 'all', $location = '', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT id, barcode, title, author, publisher, category, isbn, 
                       quantity, COALESCE(available, quantity) as available, 
                       price, call_number, location, year 
                FROM books WHERE 1=1";
        $params = [];
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND category = ?"; 
            $params[] = $category; 
        }
        if ($status === 'available') { 
            $sql .= " AND (COALESCE(available, quantity) > 0)"; 
        } elseif ($status === 'unavailable') { 
            $sql .= " AND (COALESCE(available, quantity) = 0)"; 
        } elseif ($status === 'lowstock') { 
            $sql .= " AND (COALESCE(available, quantity) > 0) AND (COALESCE(available, quantity) <= 2)"; 
        }
        if (!empty($location)) { 
            $sql .= " AND location LIKE ?"; 
            $params[] = "%$location%"; 
        }
        $sql .= " ORDER BY title LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getBooksData error: " . $e->getMessage());
        return [];
    }
}

function getBooksCount($db, $category = 'all', $status = 'all', $location = '') {
    try {
        $sql = "SELECT COUNT(*) FROM books WHERE 1=1";
        $params = [];
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND category = ?"; 
            $params[] = $category; 
        }
        if ($status === 'available') { 
            $sql .= " AND (COALESCE(available, quantity) > 0)"; 
        } elseif ($status === 'unavailable') { 
            $sql .= " AND (COALESCE(available, quantity) = 0)"; 
        } elseif ($status === 'lowstock') { 
            $sql .= " AND (COALESCE(available, quantity) > 0) AND (COALESCE(available, quantity) <= 2)"; 
        }
        if (!empty($location)) { 
            $sql .= " AND location LIKE ?"; 
            $params[] = "%$location%"; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getBooksCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 3. CIRCULATION REPORT ====================
function getCirculationData($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT c.*, 
                       m.id as member_id, m.admno as member_admno, m.name as member_name, m.class, m.division, m.member_category,
                       b.id as book_id, b.title as book_title, b.author, b.isbn, b.category as book_category, b.barcode
                FROM circulation c 
                LEFT JOIN members m ON c.admno = m.admno 
                LEFT JOIN books b ON c.barcode = b.barcode 
                WHERE DATE(c.issue_date) BETWEEN ? AND ?";
        $params = [$from, $to];
        if (!empty($admno)) { 
            $sql .= " AND c.admno LIKE ?"; 
            $params[] = "%$admno%"; 
        }
        if (!empty($class)) { 
            $sql .= " AND m.class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND m.division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if ($memberCategory !== 'all' && !empty($memberCategory)) { 
            $sql .= " AND m.member_category = ?"; 
            $params[] = $memberCategory; 
        }
        if ($bookCategory !== 'all' && !empty($bookCategory)) { 
            $sql .= " AND b.category = ?"; 
            $params[] = $bookCategory; 
        }
        if ($type === 'issued') { 
            $sql .= " AND c.return_date IS NULL AND c.due_date >= date('now')"; 
        } elseif ($type === 'returned') { 
            $sql .= " AND c.return_date IS NOT NULL"; 
        } elseif ($type === 'overdue') { 
            $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')"; 
        }
        $sql .= " ORDER BY c.issue_date DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        // Ensure we have all required fields
        foreach ($results as &$row) {
            if (!isset($row['member_admno']) && isset($row['admno'])) {
                $row['member_admno'] = $row['admno'];
            }
            if (!isset($row['member_name']) && isset($row['member_name'])) {
                // Already set from JOIN
            }
            if (!isset($row['book_title']) && isset($row['title'])) {
                $row['book_title'] = $row['title'];
            }
        }
        return $results;
    } catch (Exception $e) {
        error_log("getCirculationData error: " . $e->getMessage());
        return [];
    }
}

function getCirculationCount($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all') {
    try {
        $sql = "SELECT COUNT(*) FROM circulation c 
                LEFT JOIN members m ON c.admno = m.admno 
                LEFT JOIN books b ON c.barcode = b.barcode 
                WHERE DATE(c.issue_date) BETWEEN ? AND ?";
        $params = [$from, $to];
        if (!empty($admno)) { 
            $sql .= " AND c.admno LIKE ?"; 
            $params[] = "%$admno%"; 
        }
        if (!empty($class)) { 
            $sql .= " AND m.class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND m.division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if ($memberCategory !== 'all' && !empty($memberCategory)) { 
            $sql .= " AND m.member_category = ?"; 
            $params[] = $memberCategory; 
        }
        if ($bookCategory !== 'all' && !empty($bookCategory)) { 
            $sql .= " AND b.category = ?"; 
            $params[] = $bookCategory; 
        }
        if ($type === 'issued') { 
            $sql .= " AND c.return_date IS NULL AND c.due_date >= date('now')"; 
        } elseif ($type === 'returned') { 
            $sql .= " AND c.return_date IS NOT NULL"; 
        } elseif ($type === 'overdue') { 
            $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')"; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getCirculationCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 4. ENTRY/EXIT REPORT ====================
function getEntryExitData($db, $from, $to, $admno = '', $category = 'all', $purpose = '', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT e.*, m.id as member_id, m.admno as member_admno, m.name as member_name, m.member_category
                FROM entry_exit e 
                LEFT JOIN members m ON e.admno = m.admno
                WHERE e.entry_date BETWEEN ? AND ?";
        $params = [$from, $to];
        if (!empty($admno)) { 
            $sql .= " AND e.admno LIKE ?"; 
            $params[] = "%$admno%"; 
        }
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND e.member_category = ?"; 
            $params[] = $category; 
        }
        if (!empty($purpose)) { 
            $sql .= " AND e.purpose LIKE ?"; 
            $params[] = "%$purpose%"; 
        }
        $sql .= " ORDER BY e.entry_date DESC, e.entry_time DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        foreach ($results as &$row) {
            if (!isset($row['member_admno']) && isset($row['admno'])) {
                $row['member_admno'] = $row['admno'];
            }
            if (!isset($row['member_name']) && isset($row['member_name'])) {
                // Already set from JOIN
            }
        }
        return $results;
    } catch (Exception $e) {
        error_log("getEntryExitData error: " . $e->getMessage());
        return [];
    }
}

function getEntryExitCount($db, $from, $to, $admno = '', $category = 'all', $purpose = '') {
    try {
        $sql = "SELECT COUNT(*) FROM entry_exit e WHERE e.entry_date BETWEEN ? AND ?";
        $params = [$from, $to];
        if (!empty($admno)) { 
            $sql .= " AND e.admno LIKE ?"; 
            $params[] = "%$admno%"; 
        }
        if ($category !== 'all' && !empty($category)) { 
            $sql .= " AND e.member_category = ?"; 
            $params[] = $category; 
        }
        if (!empty($purpose)) { 
            $sql .= " AND e.purpose LIKE ?"; 
            $params[] = "%$purpose%"; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getEntryExitCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 5. OVERDUE BOOKS REPORT ====================
function getOverdueData($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT c.*, 
                       m.id as member_id, m.admno as member_admno, m.name as member_name, m.class, m.division, 
                       b.id as book_id, b.title, b.author, b.isbn, b.barcode
                FROM circulation c 
                LEFT JOIN members m ON c.admno = m.admno 
                LEFT JOIN books b ON c.barcode = b.barcode 
                WHERE c.return_date IS NULL AND c.due_date < date('now')";
        $params = [];
        if ($fromDate && $toDate) { 
            $sql .= " AND c.due_date BETWEEN ? AND ?"; 
            $params[] = $fromDate; 
            $params[] = $toDate; 
        }
        if (!empty($class)) { 
            $sql .= " AND m.class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND m.division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if (!empty($minDays) && is_numeric($minDays)) { 
            $sql .= " AND julianday('now') - julianday(c.due_date) >= ?"; 
            $params[] = (int)$minDays; 
        }
        $sql .= " ORDER BY c.due_date ASC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getOverdueData error: " . $e->getMessage());
        return [];
    }
}

function getOverdueCount($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '') {
    try {
        $sql = "SELECT COUNT(*) FROM circulation c 
                LEFT JOIN members m ON c.admno = m.admno 
                WHERE c.return_date IS NULL AND c.due_date < date('now')";
        $params = [];
        if ($fromDate && $toDate) { 
            $sql .= " AND c.due_date BETWEEN ? AND ?"; 
            $params[] = $fromDate; 
            $params[] = $toDate; 
        }
        if (!empty($class)) { 
            $sql .= " AND m.class LIKE ?"; 
            $params[] = "%$class%"; 
        }
        if (!empty($division)) { 
            $sql .= " AND m.division LIKE ?"; 
            $params[] = "%$division%"; 
        }
        if (!empty($minDays) && is_numeric($minDays)) { 
            $sql .= " AND julianday('now') - julianday(c.due_date) >= ?"; 
            $params[] = (int)$minDays; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getOverdueCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 6. COMPUTER USAGE REPORT ====================
function getComputerData($db, $fromDate, $toDate, $memberSearch = '', $computerId = '', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT cs.*, 
                       m.id as member_id, m.admno, m.name as member_name, m.member_category, 
                       m.class, m.division, 
                       c.id as computer_id, c.computer_name 
                FROM computer_sessions cs 
                LEFT JOIN members m ON cs.member_id = m.id 
                LEFT JOIN computers c ON cs.computer_id = c.id 
                WHERE 1=1";
        $params = [];
        if ($fromDate) { 
            $sql .= " AND DATE(cs.login_time) >= ?"; 
            $params[] = $fromDate; 
        }
        if ($toDate) { 
            $sql .= " AND DATE(cs.login_time) <= ?"; 
            $params[] = $toDate; 
        }
        if (!empty($memberSearch)) { 
            $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; 
            $params[] = "%$memberSearch%"; 
            $params[] = "%$memberSearch%"; 
        }
        if (!empty($computerId)) { 
            $sql .= " AND cs.computer_id = ?"; 
            $params[] = $computerId; 
        }
        $sql .= " ORDER BY cs.login_time DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        foreach ($results as &$row) {
            if ($row['login_time'] && $row['logout_time']) {
                $diff = strtotime($row['logout_time']) - strtotime($row['login_time']);
                $row['duration_minutes'] = round($diff / 60);
            } else {
                $row['duration_minutes'] = 0;
            }
            // Ensure member_admno is set
            if (!isset($row['admno'])) {
                $row['admno'] = '';
            }
        }
        return $results;
    } catch (Exception $e) {
        error_log("getComputerData error: " . $e->getMessage());
        return [];
    }
}

function getComputerCount($db, $fromDate, $toDate, $memberSearch = '', $computerId = '') {
    try {
        $sql = "SELECT COUNT(*) FROM computer_sessions cs 
                LEFT JOIN members m ON cs.member_id = m.id 
                WHERE 1=1";
        $params = [];
        if ($fromDate) { 
            $sql .= " AND DATE(cs.login_time) >= ?"; 
            $params[] = $fromDate; 
        }
        if ($toDate) { 
            $sql .= " AND DATE(cs.login_time) <= ?"; 
            $params[] = $toDate; 
        }
        if (!empty($memberSearch)) { 
            $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; 
            $params[] = "%$memberSearch%"; 
            $params[] = "%$memberSearch%"; 
        }
        if (!empty($computerId)) { 
            $sql .= " AND cs.computer_id = ?"; 
            $params[] = $computerId; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getComputerCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 7. FINE PAYMENTS REPORT ====================
function getFinePaymentsData($db, $from, $to, $method = 'all', $status = 'all', $limit = 100, $offset = 0) {
    try {
        $sql = "SELECT fp.*, m.id as member_id, m.admno as member_admno, m.name as member_name, m.member_category
                FROM fine_payments fp
                LEFT JOIN members m ON fp.admno = m.admno
                WHERE DATE(fp.payment_date) BETWEEN ? AND ?";
        $params = [$from, $to];
        if ($method !== 'all' && !empty($method)) { 
            $sql .= " AND fp.payment_method = ?"; 
            $params[] = $method; 
        }
        if ($status !== 'all' && !empty($status)) { 
            $sql .= " AND fp.status = ?"; 
            $params[] = $status; 
        }
        $sql .= " ORDER BY fp.payment_date DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
        
        foreach ($results as &$row) {
            if (!isset($row['member_admno']) && isset($row['admno'])) {
                $row['member_admno'] = $row['admno'];
            }
        }
        return $results;
    } catch (Exception $e) {
        error_log("getFinePaymentsData error: " . $e->getMessage());
        return [];
    }
}

function getFinePaymentsCount($db, $from, $to, $method = 'all', $status = 'all') {
    try {
        $sql = "SELECT COUNT(*) FROM fine_payments WHERE DATE(payment_date) BETWEEN ? AND ?";
        $params = [$from, $to];
        if ($method !== 'all' && !empty($method)) { 
            $sql .= " AND payment_method = ?"; 
            $params[] = $method; 
        }
        if ($status !== 'all' && !empty($status)) { 
            $sql .= " AND status = ?"; 
            $params[] = $status; 
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Exception $e) {
        error_log("getFinePaymentsCount error: " . $e->getMessage());
        return 0;
    }
}

// ==================== 8. MEMBERS BY CATEGORY ====================
function getCategoryWiseMembers($db) {
    try {
        $stmt = $db->query("SELECT COALESCE(member_category, 'Uncategorized') as category, COUNT(*) as count FROM members GROUP BY member_category");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getCategoryWiseMembers error: " . $e->getMessage());
        return [];
    }
}

// ==================== 9. MEMBERS BY CLASS/DIVISION ====================
function getClassDivisionMembers($db) {
    try {
        $stmt = $db->query("SELECT COALESCE(class, 'N/A') as class, COALESCE(division, 'N/A') as division, COUNT(*) as count FROM members GROUP BY class, division ORDER BY class, division");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getClassDivisionMembers error: " . $e->getMessage());
        return [];
    }
}

// ==================== 10. ACTIVE VS INACTIVE MEMBERS ====================
function getActiveInactiveMembers($db) {
    try {
        $stmt = $db->query("SELECT 
                            CASE 
                                WHEN status = 'active' OR status IS NULL OR status = '' THEN 'Active' 
                                ELSE 'Inactive' 
                            END as status, 
                            COUNT(*) as count 
                            FROM members 
                            GROUP BY 
                            CASE 
                                WHEN status = 'active' OR status IS NULL OR status = '' THEN 'Active' 
                                ELSE 'Inactive' 
                            END");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getActiveInactiveMembers error: " . $e->getMessage());
        return [];
    }
}

// ==================== 11. BOOKS BY CATEGORY ====================
function getBooksByCategory($db) {
    try {
        $stmt = $db->query("SELECT COALESCE(category, 'Uncategorized') as category, 
                                   SUM(quantity) as total_qty, 
                                   SUM(COALESCE(available, quantity)) as avail_qty 
                            FROM books 
                            GROUP BY category");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getBooksByCategory error: " . $e->getMessage());
        return [];
    }
}

// ==================== 12. BOOKS SUMMARY (TITLES VS COPIES) ====================
function getBooksTitlesSummary($db) {
    try {
        $stmt = $db->query("SELECT 
                            COALESCE(category, 'Uncategorized') as category, 
                            COUNT(DISTINCT COALESCE(title, '') || '-' || COALESCE(author, '')) as titles, 
                            SUM(quantity) as total_copies 
                            FROM books 
                            GROUP BY category 
                            ORDER BY category");
        $categoryData = $stmt->fetchAll();
        
        $stmtTotal = $db->query("SELECT 
                            COUNT(DISTINCT COALESCE(title, '') || '-' || COALESCE(author, '')) as total_titles, 
                            SUM(quantity) as total_copies 
                            FROM books");
        $overall = $stmtTotal->fetch(PDO::FETCH_ASSOC);
        $categoryData[] = [
            'category' => '** OVERALL **',
            'titles' => $overall['total_titles'] ?? 0,
            'total_copies' => $overall['total_copies'] ?? 0
        ];
        return $categoryData;
    } catch (Exception $e) {
        error_log("getBooksTitlesSummary error: " . $e->getMessage());
        return [];
    }
}

// ==================== 13. MOST ISSUED BOOKS ====================
function getMostIssuedBooks($db, $from, $to, $limit = 20) {
    try {
        $stmt = $db->prepare("SELECT b.title, b.author, COUNT(c.id) as issue_count 
                            FROM circulation c 
                            LEFT JOIN books b ON c.barcode = b.barcode 
                            WHERE c.issue_date BETWEEN ? AND ? 
                            GROUP BY b.barcode 
                            ORDER BY issue_count DESC 
                            LIMIT ?");
        $stmt->execute([$from, $to, $limit]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getMostIssuedBooks error: " . $e->getMessage());
        return [];
    }
}

// ==================== 14. MOST ACTIVE MEMBERS ====================
function getMostActiveMembers($db, $from, $to, $limit = 20) {
    try {
        $stmt = $db->prepare("SELECT m.admno, m.name, m.member_category, COUNT(c.id) as total_issues 
                            FROM members m 
                            LEFT JOIN circulation c ON m.admno = c.admno AND c.issue_date BETWEEN ? AND ? 
                            GROUP BY m.admno 
                            ORDER BY total_issues DESC 
                            LIMIT ?");
        $stmt->execute([$from, $to, $limit]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getMostActiveMembers error: " . $e->getMessage());
        return [];
    }
}

// ==================== 15. DAILY VISITORS REPORT ====================
function getDailyVisitors($db, $from, $to, $limit = 30) {
    try {
        $stmt = $db->prepare("SELECT entry_date, COUNT(*) as visitors 
                            FROM entry_exit 
                            WHERE entry_date BETWEEN ? AND ? 
                            GROUP BY entry_date 
                            ORDER BY entry_date DESC 
                            LIMIT ?");
        $stmt->execute([$from, $to, $limit]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getDailyVisitors error: " . $e->getMessage());
        return [];
    }
}

// ==================== 16. PURPOSE OF VISIT ANALYSIS ====================
function getPurposeAnalysis($db, $from, $to) {
    try {
        $stmt = $db->prepare("SELECT COALESCE(purpose, 'Not Specified') as purpose, COUNT(*) as count 
                            FROM entry_exit 
                            WHERE entry_date BETWEEN ? AND ? 
                            GROUP BY purpose 
                            ORDER BY count DESC");
        $stmt->execute([$from, $to]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getPurposeAnalysis error: " . $e->getMessage());
        return [];
    }
}

// ==================== 17. CLASS/DIVISION ISSUES & OVERDUE ====================
function getClassDivisionIssuesOverdue($db, $from, $to, $class = '', $division = '') {
    try {
        $sql = "SELECT 
                    COALESCE(m.class, 'N/A') AS class,
                    COALESCE(m.division, 'N/A') AS division,
                    COUNT(DISTINCT c.id) AS total_issues,
                    COUNT(DISTINCT CASE WHEN c.due_date < date('now') AND c.return_date IS NULL THEN c.id END) AS total_overdue
                FROM members m
                LEFT JOIN circulation c ON m.admno = c.admno
                WHERE DATE(c.issue_date) BETWEEN :fromDate AND :toDate
        ";
        $params = [':fromDate' => $from, ':toDate' => $to];
        if (!empty($class)) {
            $sql .= " AND m.class = :class";
            $params[':class'] = $class;
        }
        if (!empty($division)) {
            $sql .= " AND m.division = :division";
            $params[':division'] = $division;
        }
        $sql .= " GROUP BY m.class, m.division ORDER BY class, division";
        $stmt = $db->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        error_log("getClassDivisionIssuesOverdue error: " . $e->getMessage());
        return [];
    }
}

// =============================================================================
// EXPORT DATA PREPARATION FUNCTION - FIXED
// =============================================================================

function prepareExportData($rawData, $reportType) {
    $exportData = [];
    $sn = 1;
    
    foreach ($rawData as $row) {
        $rowData = ['Sl No' => $sn++];
        
        switch ($reportType) {
            case 'members':
                $rowData['Adm No'] = $row['admno'] ?? '';
                $rowData['Name'] = $row['name'] ?? '';
                $rowData['Category'] = $row['member_category'] ?? '';
                $rowData['Class/Dept'] = $row['class'] ?? '';
                $rowData['Div/Course'] = $row['division'] ?? '';
                $rowData['Email'] = $row['email'] ?? '';
                $rowData['Phone'] = $row['phone'] ?? '';
                $rowData['Active Books'] = (int)($row['active_books'] ?? 0);
                $rowData['Total Issued'] = (int)($row['total_issued'] ?? 0);
                $rowData['Total Fines'] = formatCurrency($row['total_fines'] ?? 0);
                $rowData['Status'] = ucfirst($row['status'] ?? 'active');
                break;
                
            case 'books':
                $rowData['Barcode'] = $row['barcode'] ?? '';
                $rowData['Title'] = $row['title'] ?? '';
                $rowData['Author'] = $row['author'] ?? '';
                $rowData['Publisher'] = $row['publisher'] ?? '';
                $rowData['Category'] = $row['category'] ?? '';
                $rowData['ISBN'] = $row['isbn'] ?? '';
                $rowData['Quantity'] = (int)($row['quantity'] ?? 0);
                $rowData['Available'] = (int)($row['available'] ?? 0);
                $rowData['Price'] = formatCurrency($row['price'] ?? 0);
                $rowData['Call Number'] = $row['call_number'] ?? '';
                $rowData['Location'] = $row['location'] ?? '';
                $rowData['Year'] = $row['year'] ?? '';
                break;
                
            case 'circulation':
                $rowData['Adm No'] = $row['member_admno'] ?? $row['admno'] ?? '';
                $rowData['Member'] = $row['member_name'] ?? '';
                $rowData['Book'] = $row['book_title'] ?? $row['title'] ?? '';
                $rowData['Author'] = $row['author'] ?? '';
                $rowData['Barcode'] = $row['barcode'] ?? '';
                $rowData['Issue Date'] = formatDate($row['issue_date'] ?? '');
                $rowData['Return Date'] = !empty($row['return_date']) ? formatDate($row['return_date']) : '';
                $rowData['Due Date'] = formatDate($row['due_date'] ?? '');
                $rowData['Fine'] = formatCurrency($row['fine'] ?? 0);
                $statusText = !empty($row['return_date']) ? 'Returned' : (!empty($row['due_date']) && strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued');
                $rowData['Status'] = $statusText;
                break;
                
            case 'entry_exit':
                $rowData['Adm No'] = $row['member_admno'] ?? $row['admno'] ?? '';
                $rowData['Member'] = $row['member_name'] ?? '';
                $rowData['Category'] = $row['member_category'] ?? '';
                $rowData['Entry Date'] = formatDate($row['entry_date'] ?? '');
                $rowData['Entry Time'] = formatTime($row['entry_time'] ?? '');
                $rowData['Exit Time'] = !empty($row['exit_time']) ? formatTime($row['exit_time']) : '';
                $rowData['Purpose'] = $row['purpose'] ?? '';
                break;
                
            case 'overdue':
                $rowData['Adm No'] = $row['member_admno'] ?? $row['admno'] ?? '';
                $rowData['Member'] = $row['member_name'] ?? '';
                $rowData['Class/Dept'] = $row['class'] ?? '';
                $rowData['Div/Course'] = $row['division'] ?? '';
                $rowData['Book'] = $row['title'] ?? '';
                $rowData['Author'] = $row['author'] ?? '';
                $rowData['Barcode'] = $row['barcode'] ?? '';
                $rowData['Issue Date'] = formatDate($row['issue_date'] ?? '');
                $rowData['Due Date'] = formatDate($row['due_date'] ?? '');
                $days = !empty($row['due_date']) ? max(1, ceil((time() - strtotime($row['due_date'])) / 86400)) : 0;
                $rowData['Days Overdue'] = $days;
                $rowData['Fine'] = formatCurrency($days * ($GLOBALS['finePerDay'] ?? 2));
                break;
                
            case 'computer':
                $rowData['Member'] = $row['member_name'] ?? '';
                $rowData['Adm No'] = $row['admno'] ?? '';
                $rowData['Category'] = $row['member_category'] ?? '';
                $rowData['Class/Dept'] = $row['class'] ?? '';
                $rowData['Div/Course'] = $row['division'] ?? '';
                $rowData['Computer'] = $row['computer_name'] ?? '';
                $rowData['Login Time'] = !empty($row['login_time']) ? date('d-m-Y H:i', strtotime($row['login_time'])) : '';
                $rowData['Logout Time'] = !empty($row['logout_time']) ? date('d-m-Y H:i', strtotime($row['logout_time'])) : 'Active';
                $rowData['Duration (min)'] = $row['duration_minutes'] ?? 0;
                break;
                
            case 'fines':
                $rowData['Receipt No'] = $row['receipt_no'] ?? '';
                $rowData['Adm No'] = $row['member_admno'] ?? $row['admno'] ?? '';
                $rowData['Member'] = $row['member_name'] ?? '';
                $rowData['Category'] = $row['member_category'] ?? '';
                $rowData['Amount'] = formatCurrency($row['amount'] ?? 0);
                $rowData['Method'] = ucfirst($row['payment_method'] ?? 'cash');
                $rowData['Date'] = formatDate($row['payment_date'] ?? '');
                $rowData['Status'] = ucfirst($row['status'] ?? 'paid');
                $rowData['Notes'] = $row['notes'] ?? '';
                break;
                
            case 'category_wise':
                $rowData['Category'] = $row['category'] ?? '';
                $rowData['Count'] = (int)($row['count'] ?? 0);
                break;
                
            case 'class_division':
                $rowData['Class'] = $row['class'] ?? '';
                $rowData['Division'] = $row['division'] ?? '';
                $rowData['Count'] = (int)($row['count'] ?? 0);
                break;
                
            case 'active_inactive':
                $rowData['Status'] = $row['status'] ?? '';
                $rowData['Count'] = (int)($row['count'] ?? 0);
                break;
                
            case 'books_by_category':
                $rowData['Category'] = $row['category'] ?? '';
                $rowData['Total Copies'] = (int)($row['total_qty'] ?? 0);
                $rowData['Available Copies'] = (int)($row['avail_qty'] ?? 0);
                break;
                
            case 'books_titles_summary':
                $rowData['Category'] = $row['category'] ?? '';
                $rowData['Titles'] = (int)($row['titles'] ?? 0);
                $rowData['Total Copies'] = (int)($row['total_copies'] ?? 0);
                break;
                
            case 'most_issued_books':
                $rowData['Title'] = $row['title'] ?? '';
                $rowData['Author'] = $row['author'] ?? '';
                $rowData['Issue Count'] = (int)($row['issue_count'] ?? 0);
                break;
                
            case 'member_activity':
                $rowData['Adm No'] = $row['admno'] ?? '';
                $rowData['Name'] = $row['name'] ?? '';
                $rowData['Category'] = $row['member_category'] ?? '';
                $rowData['Total Issues'] = (int)($row['total_issues'] ?? 0);
                break;
                
            case 'daily_visitors':
                $rowData['Date'] = formatDate($row['entry_date'] ?? '');
                $rowData['Visitors'] = (int)($row['visitors'] ?? 0);
                break;
                
            case 'purpose_analysis':
                $rowData['Purpose'] = $row['purpose'] ?? '';
                $rowData['Count'] = (int)($row['count'] ?? 0);
                break;
                
            case 'class_division_issues_overdue':
                $rowData['Class'] = $row['class'] ?? '';
                $rowData['Division'] = $row['division'] ?? '';
                $rowData['Total Issues'] = (int)($row['total_issues'] ?? 0);
                $rowData['Total Overdue'] = (int)($row['total_overdue'] ?? 0);
                break;
                
            default:
                // Generic fallback - copy all fields
                foreach ($row as $key => $value) {
                    $rowData[$key] = is_array($value) ? implode(', ', $value) : $value;
                }
                break;
        }
        
        $exportData[] = $rowData;
    }
    
    return $exportData;
}

// =============================================================================
// EXPORT FUNCTIONS
// =============================================================================

function generatePDFReport($data, $headers, $title, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    global $reportPrimaryColor, $reportFooterText, $reportFontSize, $reportLogoPosition;

    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    // Clean data
    $cleanData = [];
    if (!empty($data)) {
        foreach ($data as $row) {
            if (is_array($row)) {
                $cleanRow = [];
                foreach ($row as $key => $value) {
                    if (is_null($value)) {
                        $cleanRow[$key] = '';
                    } elseif (is_array($value)) {
                        $cleanRow[$key] = implode(', ', $value);
                    } else {
                        $cleanRow[$key] = $value;
                    }
                }
                $cleanData[] = $cleanRow;
            }
        }
    }

    if (empty($cleanData)) {
        $cleanData = [['No Data Available' => '']];
        $headers = ['No Data Available'];
    }

    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($institutionName) . ' - ' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
            .report-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px; }
            .report-title { font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . '; }
            .report-subtitle { font-size: 16px; font-weight: bold; margin: 8px 0; }
            .report-meta { font-size: 10px; margin: 3px 0; color: #555; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .text-danger { color: #dc3545; }
            .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
            .logo-img { height: 50px; width: auto; object-fit: contain; margin-bottom: 8px; }
            .table-footer { background-color: #f0f0f0; font-weight: bold; }
        </style>
    </head>
    <body>';

    // Header
    $html .= '<div class="report-header">';
    
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img">';
        $html .= '<div>';
        $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img">';
        $html .= '</div>';
    } 
    elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img"><br>';
        $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
    } 
    else {
        $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
    }
    
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        $html .= '<div class="report-meta"><strong>Period:</strong> ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to']) . '</div>';
    }
    $html .= '<div class="report-meta"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';

    // Table
    $displayHeaders = $headers;
    if (!empty($cleanData) && !in_array('Sl No', $displayHeaders) && array_key_exists('Sl No', $cleanData[0])) {
        array_unshift($displayHeaders, 'Sl No');
    }
    
    $html .= '<table><thead><tr>';
    foreach ($displayHeaders as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';

    $sn = 1;
    foreach ($cleanData as $row) {
        $html .= '<tr>';
        foreach ($displayHeaders as $header) {
            if ($header === 'Sl No') {
                $html .= '<td class="text-center">' . $sn . '</td>';
            } else {
                $value = $row[$header] ?? '';
                if (is_numeric($value) && $value > 1000) {
                    $html .= '<td class="text-right">' . number_format($value) . '</td>';
                } elseif (is_numeric($value) && strpos((string)$value, '.') !== false) {
                    $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
                } elseif (is_numeric($value)) {
                    $html .= '<td class="text-right">' . $value . '</td>';
                } elseif (empty($value) || $value === '0000-00-00') {
                    $html .= '<td class="text-center">-</td>';
                } elseif (is_array($value)) {
                    $html .= '<td>' . htmlspecialchars(implode(', ', $value)) . '</td>';
                } else {
                    $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                }
            }
        }
        $html .= '</tr>';
        $sn++;
    }

    $html .= '</tbody>';
    $html .= '<tfoot><tr class="table-footer">';
    $html .= '<td colspan="' . (count($displayHeaders) - 1) . '" class="text-right">Total Records:</td>';
    $html .= '<td class="text-center">' . count($cleanData) . '</td>';
    $html .= '</tr></tfoot></table>';

    // Footer
    $html .= '<div class="footer">' . htmlspecialchars($reportFooterText) . '<br>&copy; ' . date('Y') . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.</div>';
    $html .= '</body></html>';
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { 
            error_log("mPDF error: " . $e->getMessage()); 
        }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { 
            error_log("DomPDF error: " . $e->getMessage()); 
        }
    }

    // Fallback
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToExcel($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    // Clean data
    $cleanData = [];
    if (!empty($data)) {
        foreach ($data as $row) {
            if (is_array($row)) {
                $cleanRow = [];
                foreach ($row as $key => $value) {
                    if (is_null($value)) {
                        $cleanRow[$key] = '';
                    } elseif (is_array($value)) {
                        $cleanRow[$key] = implode(', ', $value);
                    } else {
                        $cleanRow[$key] = $value;
                    }
                }
                $cleanData[] = $cleanRow;
            }
        }
    }

    if (empty($cleanData)) {
        $cleanData = [['No Data Available' => '']];
        $headers = ['No Data Available'];
    }

    if (!in_array('Sl No', $headers) && isset($cleanData[0]['Sl No'])) {
        array_unshift($headers, 'Sl No');
    }

    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            
            $sheet->setCellValue('A1', getInstitutionName() . ' - ' . $filename);
            $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
            
            $row = 2;
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . $row, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A' . $row . ':' . $col . $row)->getFont()->setBold(true);
            $sheet->getStyle('A' . $row . ':' . $col . $row)->getFill()
                ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                ->getStartColor()->setARGB('FF' . ltrim($GLOBALS['reportPrimaryColor'], '#'));
            $sheet->getStyle('A' . $row . ':' . $col . $row)->getFont()->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_WHITE));
            
            $row++;
            foreach ($cleanData as $rowData) {
                $col = 'A';
                foreach ($headers as $header) {
                    $value = $rowData[$header] ?? '';
                    if (is_array($value)) {
                        $sheet->setCellValue($col . $row, implode(', ', $value));
                    } else {
                        $sheet->setCellValue($col . $row, $value);
                    }
                    $col++;
                }
                $row++;
            }
            
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) { 
            error_log("Excel export error: " . $e->getMessage()); 
        }
    }
    // Fallback to CSV
    exportToCSV($cleanData, $headers, $filename);
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['# ' . getInstitutionName()]);
    fputcsv($out, ['# Generated: ' . date('Y-m-d H:i:s')]);
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        fputcsv($out, ['# Period: ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to'])]);
    }
    fputcsv($out, ['#']);
    
    $cleanHeaders = [];
    foreach ($headers as $header) {
        $cleanHeaders[] = $header;
    }
    fputcsv($out, $cleanHeaders);
    
    foreach ($data as $row) {
        $csvRow = [];
        foreach ($cleanHeaders as $header) {
            $value = $row[$header] ?? '';
            if (is_array($value)) {
                $csvRow[] = implode(', ', $value);
            } else {
                $csvRow[] = $value;
            }
        }
        fputcsv($out, $csvRow);
    }
    fclose($out);
    exit;
}

// =============================================================================
// MAIN EXPORT HANDLER - FIXED
// =============================================================================

if (isset($_GET['export']) && $_GET['export'] == 1) {
    $format = $_GET['format'] ?? 'excel';
    $exportType = $_GET['type'] ?? $reportType;
    $rawData = [];
    $headers = [];
    $title = '';
    $filename = '';
    $limit = 10000;
    $offset = 0;

    // Get data based on report type
    switch ($exportType) {
        case 'members':
            $rawData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Email', 'Phone', 'Active Books', 'Total Issued', 'Total Fines', 'Status'];
            $title = 'Members Report';
            $filename = 'members_report_' . date('Y-m-d');
            break;
        case 'books':
            $rawData = getBooksData($db, $category, $status, $location, $limit, $offset);
            $headers = ['Sl No', 'Barcode', 'Title', 'Author', 'Publisher', 'Category', 'ISBN', 'Quantity', 'Available', 'Price', 'Call Number', 'Location', 'Year'];
            $title = 'Books Report';
            $filename = 'books_report_' . date('Y-m-d');
            break;
        case 'circulation':
            $rawData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Book', 'Author', 'Barcode', 'Issue Date', 'Return Date', 'Due Date', 'Fine', 'Status'];
            $title = 'Circulation Report';
            $filename = 'circulation_report_' . date('Y-m-d');
            break;
        case 'entry_exit':
            $rawData = getEntryExitData($db, $from, $to, '', $category, $purpose, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Category', 'Entry Date', 'Entry Time', 'Exit Time', 'Purpose'];
            $title = 'Entry/Exit Report';
            $filename = 'entry_exit_report_' . date('Y-m-d');
            break;
        case 'overdue':
            $rawData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Class/Dept', 'Div/Course', 'Book', 'Author', 'Barcode', 'Issue Date', 'Due Date', 'Days Overdue', 'Fine'];
            $title = 'Overdue Books Report';
            $filename = 'overdue_books_report_' . date('Y-m-d');
            break;
        case 'computer':
            $rawData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
            $headers = ['Sl No', 'Member', 'Adm No', 'Category', 'Class/Dept', 'Div/Course', 'Computer', 'Login Time', 'Logout Time', 'Duration (min)'];
            $title = 'Computer Usage Report';
            $filename = 'computer_usage_report_' . date('Y-m-d');
            break;
        case 'fines':
            $rawData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
            $headers = ['Sl No', 'Receipt No', 'Adm No', 'Member', 'Category', 'Amount', 'Method', 'Date', 'Status', 'Notes'];
            $title = 'Fine Payments Report';
            $filename = 'fine_payments_report_' . date('Y-m-d');
            break;
        case 'category_wise':
            $rawData = getCategoryWiseMembers($db);
            $headers = ['Sl No', 'Category', 'Count'];
            $title = 'Members by Category';
            $filename = 'members_by_category_' . date('Y-m-d');
            break;
        case 'class_division':
            $rawData = getClassDivisionMembers($db);
            $headers = ['Sl No', 'Class', 'Division', 'Count'];
            $title = 'Members by Class/Division';
            $filename = 'members_by_class_division_' . date('Y-m-d');
            break;
        case 'active_inactive':
            $rawData = getActiveInactiveMembers($db);
            $headers = ['Sl No', 'Status', 'Count'];
            $title = 'Active vs Inactive Members';
            $filename = 'active_inactive_members_' . date('Y-m-d');
            break;
        case 'books_by_category':
            $rawData = getBooksByCategory($db);
            $headers = ['Sl No', 'Category', 'Total Copies', 'Available Copies'];
            $title = 'Books by Category';
            $filename = 'books_by_category_' . date('Y-m-d');
            break;
        case 'books_titles_summary':
            $rawData = getBooksTitlesSummary($db);
            $headers = ['Sl No', 'Category', 'Titles', 'Total Copies'];
            $title = 'Books Summary (Titles vs Copies)';
            $filename = 'books_summary_' . date('Y-m-d');
            break;
        case 'most_issued_books':
            $rawData = getMostIssuedBooks($db, $from, $to, $limit);
            $headers = ['Sl No', 'Title', 'Author', 'Issue Count'];
            $title = 'Most Issued Books';
            $filename = 'most_issued_books_' . date('Y-m-d');
            break;
        case 'member_activity':
            $rawData = getMostActiveMembers($db, $from, $to, $limit);
            $headers = ['Sl No', 'Adm No', 'Name', 'Category', 'Total Issues'];
            $title = 'Most Active Members';
            $filename = 'most_active_members_' . date('Y-m-d');
            break;
        case 'daily_visitors':
            $rawData = getDailyVisitors($db, $from, $to, $limit);
            $headers = ['Sl No', 'Date', 'Visitors'];
            $title = 'Daily Visitors Report';
            $filename = 'daily_visitors_' . date('Y-m-d');
            break;
        case 'purpose_analysis':
            $rawData = getPurposeAnalysis($db, $from, $to);
            $headers = ['Sl No', 'Purpose', 'Count'];
            $title = 'Purpose of Visit Analysis';
            $filename = 'purpose_analysis_' . date('Y-m-d');
            break;
        case 'class_division_issues_overdue':
            $rawData = getClassDivisionIssuesOverdue($db, $from, $to, $filterClass, $filterDivision);
            $headers = ['Sl No', 'Class', 'Division', 'Total Issues', 'Total Overdue'];
            $title = 'Class/Division Issues & Overdue';
            $filename = 'class_division_issues_overdue_' . date('Y-m-d');
            break;
        default:
            die("Invalid export type");
    }

    // Prepare export data with proper headers
    $exportData = prepareExportData($rawData, $exportType);

    if ($format === 'pdf') {
        $pdfHtml = generatePDFReport($exportData, $headers, $title, $filename, $paperSize, $orientation);
        exportToPDF($pdfHtml, $filename . '.pdf', $paperSize, $orientation);
    } elseif ($format === 'excel') {
        exportToExcel($exportData, $headers, $filename);
    } elseif ($format === 'csv') {
        exportToCSV($exportData, $headers, $filename);
    } else {
        exportToExcel($exportData, $headers, $filename);
    }
    exit;
}

// =============================================================================
// GET DATA FOR DISPLAY (on-screen) with Pagination
// =============================================================================

$displayData = [];
$totalRecords = 0;
$reportTitle = 'Report';
$overdueTotalFine = 0;
$summary = [];
$totalSessions = 0;
$totalMinutes = 0;
$totalFines = 0;

switch ($reportType) {
    case 'members':
        $totalRecords = getMembersCount($db, $category, $filterClass, $filterDivision, $status);
        $displayData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
        $reportTitle = 'Members Report';
        break;
    case 'books':
        $totalRecords = getBooksCount($db, $category, $status, $location);
        $displayData = getBooksData($db, $category, $status, $location, $limit, $offset);
        $reportTitle = 'Books Report';
        break;
    case 'circulation':
        $totalRecords = getCirculationCount($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter);
        $displayData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
        $summary = getTransactionSummary($db, $from, $to);
        $reportTitle = 'Circulation Report';
        break;
    case 'entry_exit':
        $totalRecords = getEntryExitCount($db, $from, $to, '', $category, $purpose);
        $displayData = getEntryExitData($db, $from, $to, '', $category, $purpose, $limit, $offset);
        $reportTitle = 'Entry/Exit Report';
        break;
    case 'overdue':
        $totalRecords = getOverdueCount($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays);
        $displayData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
        $overdueTotalFine = 0;
        foreach ($displayData as &$book) {
            $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
            $book['days_overdue'] = $days;
            $book['fine_amount'] = $days * $finePerDay;
            $overdueTotalFine += $book['fine_amount'];
        }
        $reportTitle = 'Overdue Books Report';
        break;
    case 'computer':
        $totalRecords = getComputerCount($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId);
        $displayData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
        $totalSessions = $totalRecords;
        $totalMinutes = array_sum(array_column($displayData, 'duration_minutes'));
        $reportTitle = 'Computer Usage Report';
        break;
    case 'fines':
        $totalRecords = getFinePaymentsCount($db, $fineFromDate, $fineToDate, $paymentMethod, $status);
        $displayData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
        $totalFines = array_sum(array_column($displayData, 'amount'));
        $reportTitle = 'Fine Payments Report';
        break;
    case 'category_wise':
        $displayData = getCategoryWiseMembers($db);
        $totalRecords = count($displayData);
        $reportTitle = 'Members by Category';
        break;
    case 'class_division':
        $displayData = getClassDivisionMembers($db);
        $totalRecords = count($displayData);
        $reportTitle = 'Members by Class/Division';
        break;
    case 'active_inactive':
        $displayData = getActiveInactiveMembers($db);
        $totalRecords = count($displayData);
        $reportTitle = 'Active vs Inactive Members';
        break;
    case 'books_by_category':
        $displayData = getBooksByCategory($db);
        $totalRecords = count($displayData);
        $reportTitle = 'Books by Category';
        break;
    case 'books_titles_summary':
        $displayData = getBooksTitlesSummary($db);
        $totalRecords = count($displayData);
        $reportTitle = 'Books Summary (Titles vs Copies)';
        break;
    case 'most_issued_books':
        $displayData = getMostIssuedBooks($db, $from, $to, $limit);
        $totalRecords = count($displayData);
        $reportTitle = 'Most Issued Books';
        break;
    case 'member_activity':
        $displayData = getMostActiveMembers($db, $from, $to, $limit);
        $totalRecords = count($displayData);
        $reportTitle = 'Most Active Members';
        break;
    case 'daily_visitors':
        $displayData = getDailyVisitors($db, $from, $to, $limit);
        $totalRecords = count($displayData);
        $reportTitle = 'Daily Visitors Report';
        break;
    case 'purpose_analysis':
        $displayData = getPurposeAnalysis($db, $from, $to);
        $totalRecords = count($displayData);
        $reportTitle = 'Purpose of Visit Analysis';
        break;
    case 'class_division_issues_overdue':
        $displayData = getClassDivisionIssuesOverdue($db, $from, $to, $filterClass, $filterDivision);
        $totalRecords = count($displayData);
        $reportTitle = 'Class/Division Issues & Overdue';
        break;
    default:
        $displayData = [];
        $totalRecords = 0;
        $reportTitle = 'Report';
}

$totalPages = ($limit > 0) ? ceil($totalRecords / $limit) : 1;
$page = min($page, $totalPages);

// =============================================================================
// GET DROPDOWN DATA
// =============================================================================

function getCategories($db) {
    try {
        $stmt = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return [];
    }
}

function getMemberCategories($db) {
    try {
        $stmt = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return [];
    }
}

function getComputers($db) {
    try {
        $stmt = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

function getPaymentMethods($db) {
    return ['cash', 'card', 'online', 'cheque'];
}

function getPurposes($db) {
    try {
        $stmt = $db->query("SELECT DISTINCT purpose FROM entry_exit WHERE purpose IS NOT NULL AND purpose != '' ORDER BY purpose");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        return [];
    }
}

$bookCategories = getCategories($db);
$memberCategories = getMemberCategories($db);
$computers = getComputers($db);
$paymentMethods = getPaymentMethods($db);
$purposes = getPurposes($db);

// =============================================================================
// RENDER PAGE
// =============================================================================

$institutionName = getInstitutionName();
renderHeader($institutionName . ' - Advanced Reports');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($institutionName) ?> - Advanced Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        
        /* ========== SETTINGS BAR - UNIFIED ========== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        
        /* ========== LOGO PREVIEW ========== */
        .settings-preview-card {
            background: white;
            border-radius: 12px;
            padding: 12px 18px;
            margin-bottom: 16px;
            border-left: 3px solid <?= $reportPrimaryColor ?>;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            font-size: 0.75rem;
        }
        .settings-preview-card .logo-container {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }
        .settings-preview-card .logo-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .settings-preview-card .logo-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.7rem;
        }
        .logo-preview {
            max-height: 40px;
            width: auto;
            object-fit: contain;
            background: white;
            padding: 2px 6px;
            border-radius: 4px;
        }
        
        /* ========== STAT CARDS - UNIFIED GRADIENT ========== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            border: none;
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: white;
        }
        .stat-card .stat-label {
            color: rgba(255,255,255,0.9);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .overdue-row { background-color: #f8d7da !important; }
        .overdue-row:hover { background-color: #f5c6cb !important; }
        .table-responsive { overflow-x: auto; }
        
        .filter-section {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .filter-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 2px;
        }
        .report-actions { display: flex; flex-wrap: wrap; gap: 5px; }
        
        /* ========== REPORT TYPE BUTTONS - UNIFIED ========== */
        .report-type-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 8px;
        }
        .report-type-btn {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #e9ecef;
            background: white;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 0.8rem;
        }
        .report-type-btn:hover {
            border-color: var(--primary-color);
            background: #f8f9fa;
            transform: translateY(-2px);
        }
        .report-type-btn.active {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white;
        }
        .report-type-btn i {
            font-size: 1.2rem;
            display: block;
            margin-bottom: 3px;
        }
        
        /* ========== TABLE STYLES ========== */
        .table-dark th {
            background-color: var(--primary-color) !important;
            border-color: var(--primary-color) !important;
            color: white !important;
        }
        .card-header.bg-report {
            background-color: var(--primary-color) !important;
            color: white !important;
            border-bottom: none;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .pagination .page-link {
            color: var(--primary-color);
        }
        .pagination .page-item.active .page-link {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .pdf-download-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .pdf-download-btn:hover {
            background: #c82333;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
        }
        .pdf-download-btn .badge {
            background: rgba(255,255,255,0.3);
            color: white;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 12px;
        }
        
        .pagination-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .dropdown-menu { z-index: 1050; }
        
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .filter-section .row > div { margin-bottom: 8px; }
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
            .settings-preview-card .logo-container { flex-direction: column; align-items: flex-start; }
        }
        
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .settings-preview-card { display: none !important; }
            .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .table-dark th { background: #333 !important; color: white !important; }
            .card-header.bg-report { background: #333 !important; color: white !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 style="color: var(--primary-color);"><i class="fas fa-chart-line"></i> <?= htmlspecialchars($institutionName) ?> - Advanced Reports</h2>
        <div class="no-print report-actions">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Reports Home</a>
            <a href="../reports/index.php" class="btn btn-info btn-sm"><i class="fas fa-chart-pie"></i> All Reports</a>
            <a href="../index.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>


    <!-- ========== LOGO PREVIEW CARD ========== -->
    <?php
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    if ($mainLogo || $rightLogo):
    ?>
    <div class="settings-preview-card no-print">
        <div class="logo-container">
            <div class="logo-item">
                <span class="logo-label"><i class="fas fa-image"></i> Logo:</span>
                <?php if ($mainLogo): ?>
                    <img src="<?= $mainLogo['base64'] ?>" class="logo-preview" alt="Logo">
                <?php endif; ?>
            </div>
            <?php if ($rightLogo): ?>
            <div class="logo-item">
                <span class="logo-label">Right Logo:</span>
                <img src="<?= $rightLogo['base64'] ?>" class="logo-preview" alt="Right Logo">
            </div>
            <?php endif; ?>
            <div class="logo-item">
                <span class="logo-label">Position:</span>
                <span class="badge bg-<?= $reportLogoPosition == 'left' ? 'primary' : ($reportLogoPosition == 'right' ? 'info' : ($reportLogoPosition == 'center' ? 'warning' : 'secondary')) ?>">
                    <?= ucfirst($reportLogoPosition) ?>
                </span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ========== QUICK STATS - UNIFIED GRADIENT ========== -->
    <div class="stats-grid no-print">
        <div class="stat-card"><div class="stat-value"><?= number_format($totalRecords) ?></div><div class="stat-label">Total Records</div></div>
        <?php if ($reportType == 'members' && !empty($displayData)): ?>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'active_books')) ?></div><div class="stat-label">Active Books</div></div>
            <div class="stat-card"><div class="stat-value"><?= count(array_filter($displayData, function($m) { return ($m['status'] ?? '') === 'active'; })) ?></div><div class="stat-label">Active Members</div></div>
        <?php elseif ($reportType == 'books' && !empty($displayData)): ?>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'quantity')) ?></div><div class="stat-label">Total Copies</div></div>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'available')) ?></div><div class="stat-label">Available Copies</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Titles</div></div>
        <?php elseif ($reportType == 'circulation' && !empty($summary)): ?>
            <div class="stat-card"><div class="stat-value"><?= $summary['total_transactions'] ?? 0 ?></div><div class="stat-label">Transactions</div></div>
            <div class="stat-card"><div class="stat-value"><?= $summary['active_loans'] ?? 0 ?></div><div class="stat-label">Active Loans</div></div>
            <div class="stat-card"><div class="stat-value"><?= $summary['returns_count'] ?? 0 ?></div><div class="stat-label">Returns</div></div>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($summary['total_fines'] ?? 0) ?></div><div class="stat-label">Total Fine</div></div>
        <?php elseif ($reportType == 'overdue' && !empty($displayData)): ?>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($overdueTotalFine ?? 0) ?></div><div class="stat-label">Total Fine</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Overdue Books</div></div>
        <?php elseif ($reportType == 'computer' && !empty($displayData)): ?>
            <div class="stat-card"><div class="stat-value"><?= $totalSessions ?? 0 ?></div><div class="stat-label">Sessions</div></div>
            <div class="stat-card"><div class="stat-value"><?= $totalMinutes ?? 0 ?></div><div class="stat-label">Total Minutes</div></div>
        <?php elseif ($reportType == 'fines' && !empty($displayData)): ?>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($totalFines ?? 0) ?></div><div class="stat-label">Total Collected</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Payments</div></div>
        <?php endif; ?>
    </div>

    <!-- ========== REPORT TYPE SELECTION ========== -->
    <div class="filter-section no-print">
        <div class="d-flex align-items-center gap-2 mb-2">
            <i class="fas fa-list"></i> <strong>Select Report Type:</strong>
        </div>
        <div class="report-type-grid">
            <?php
            $reportTypes = [
                'members' => ['icon' => 'fas fa-users', 'label' => 'Members'],
                'books' => ['icon' => 'fas fa-book', 'label' => 'Books'],
                'circulation' => ['icon' => 'fas fa-exchange-alt', 'label' => 'Circulation'],
                'entry_exit' => ['icon' => 'fas fa-door-open', 'label' => 'Entry/Exit'],
                'overdue' => ['icon' => 'fas fa-clock', 'label' => 'Overdue'],
                'computer' => ['icon' => 'fas fa-desktop', 'label' => 'Computer'],
                'fines' => ['icon' => 'fas fa-hand-holding-usd', 'label' => 'Fine Payments'],
                'category_wise' => ['icon' => 'fas fa-chart-pie', 'label' => 'Members by Category'],
                'class_division' => ['icon' => 'fas fa-graduation-cap', 'label' => 'By Class/Division'],
                'active_inactive' => ['icon' => 'fas fa-user-check', 'label' => 'Active/Inactive'],
                'books_by_category' => ['icon' => 'fas fa-chart-bar', 'label' => 'Books by Category'],
                'books_titles_summary' => ['icon' => 'fas fa-chart-simple', 'label' => 'Books Summary'],
                'most_issued_books' => ['icon' => 'fas fa-star', 'label' => 'Most Issued Books'],
                'member_activity' => ['icon' => 'fas fa-trophy', 'label' => 'Most Active Members'],
                'daily_visitors' => ['icon' => 'fas fa-calendar-day', 'label' => 'Daily Visitors'],
                'purpose_analysis' => ['icon' => 'fas fa-question-circle', 'label' => 'Purpose Analysis'],
                'class_division_issues_overdue' => ['icon' => 'fas fa-chart-line', 'label' => 'Class Issues & Overdue']
            ];
            foreach ($reportTypes as $key => $rt):
                $isActive = ($reportType == $key);
            ?>
            <div class="report-type-btn <?= $isActive ? 'active' : '' ?>" onclick="location.href='?type=<?= $key ?>&from=<?= $from ?>&to=<?= $to ?>'">
                <i class="<?= $rt['icon'] ?>"></i>
                <?= $rt['label'] ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ========== FILTER SECTION ========== -->
    <div class="filter-section no-print">
        <form method="get" class="row g-2 align-items-end" id="reportFilterForm">
            <input type="hidden" name="type" value="<?= htmlspecialchars($reportType) ?>">

            <?php if ($reportType == 'circulation' || $reportType == 'entry_exit' || $reportType == 'fines' || $reportType == 'most_issued_books' || $reportType == 'member_activity' || $reportType == 'daily_visitors' || $reportType == 'purpose_analysis' || $reportType == 'class_division_issues_overdue'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="from" class="form-control form-control-sm" value="<?= htmlspecialchars($from) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="to" class="form-control form-control-sm" value="<?= htmlspecialchars($to) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'overdue'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="overdue_from_date" class="form-control form-control-sm" value="<?= htmlspecialchars($overdueFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="overdue_to_date" class="form-control form-control-sm" value="<?= htmlspecialchars($overdueToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Min Days</div><select name="overdue_min_days" class="form-select form-select-sm"><option value="">All</option><option value="7" <?= $overdueMinDays == '7' ? 'selected' : '' ?>>7+ days</option><option value="14" <?= $overdueMinDays == '14' ? 'selected' : '' ?>>14+ days</option><option value="30" <?= $overdueMinDays == '30' ? 'selected' : '' ?>>30+ days</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'computer'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="computer_from_date" class="form-control form-control-sm" value="<?= htmlspecialchars($computerFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="computer_to_date" class="form-control form-control-sm" value="<?= htmlspecialchars($computerToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Member</div><input type="text" name="computer_member_search" class="form-control form-control-sm" placeholder="Search member..." value="<?= htmlspecialchars($computerMemberSearch) ?>"></div>
                <div class="col-auto"><div class="filter-label">Computer</div><select name="computer_id" class="form-select form-select-sm"><option value="">All Computers</option><?php foreach ($computers as $comp): ?><option value="<?= $comp['id'] ?>" <?= $computerId == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'entry_exit'): ?>
                <div class="col-auto"><div class="filter-label">Adm/Mem No</div><input type="text" name="admno" class="form-control form-control-sm" placeholder="Adm/Mem No" value="<?= htmlspecialchars($admno) ?>"></div>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Purpose</div><select name="purpose" class="form-select form-select-sm"><option value="">All Purposes</option><?php foreach ($purposes as $p): ?><option value="<?= htmlspecialchars($p) ?>" <?= $purpose == $p ? 'selected' : '' ?>><?= htmlspecialchars($p) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'members' || $reportType == 'circulation' || $reportType == 'overdue' || $reportType == 'class_division_issues_overdue' || $reportType == 'class_division'): ?>
                <?php if ($reportType == 'members'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
                <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Member Category</div><select name="member_category" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $memberCategoryFilter == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Book Category</div><select name="book_category" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $bookCategoryFilter == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
                <div class="col-auto"><div class="filter-label">Class/Dept</div><input type="text" name="filter_class" class="form-control form-control-sm" placeholder="Class/Dept" value="<?= htmlspecialchars($filterClass) ?>"></div>
                <div class="col-auto"><div class="filter-label">Div/Course</div><input type="text" name="filter_division" class="form-control form-control-sm" placeholder="Div/Course" value="<?= htmlspecialchars($filterDivision) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'members'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All Status</option><option value="active" <?= $status == 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $status == 'inactive' ? 'selected' : '' ?>>Inactive</option><option value="suspended" <?= $status == 'suspended' ? 'selected' : '' ?>>Suspended</option><option value="blocked" <?= $status == 'blocked' ? 'selected' : '' ?>>Blocked</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'books' || $reportType == 'books_by_category' || $reportType == 'books_titles_summary'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php if ($reportType == 'books'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All Books</option><option value="available" <?= $status == 'available' ? 'selected' : '' ?>>Available</option><option value="unavailable" <?= $status == 'unavailable' ? 'selected' : '' ?>>Unavailable</option><option value="lowstock" <?= $status == 'lowstock' ? 'selected' : '' ?>>Low Stock</option></select></div>
                <div class="col-auto"><div class="filter-label">Location</div><input type="text" name="location" class="form-control form-control-sm" placeholder="Location" value="<?= htmlspecialchars($location) ?>"></div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All</option><option value="issued" <?= $status == 'issued' ? 'selected' : '' ?>>Issued</option><option value="returned" <?= $status == 'returned' ? 'selected' : '' ?>>Returned</option><option value="overdue" <?= $status == 'overdue' ? 'selected' : '' ?>>Overdue</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'fines'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="fine_from_date" class="form-control form-control-sm" value="<?= htmlspecialchars($fineFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="fine_to_date" class="form-control form-control-sm" value="<?= htmlspecialchars($fineToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Method</div><select name="payment_method" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($paymentMethods as $m): ?><option value="<?= $m ?>" <?= $paymentMethod == $m ? 'selected' : '' ?>><?= ucfirst($m) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All</option><option value="paid" <?= $status == 'paid' ? 'selected' : '' ?>>Paid</option><option value="pending" <?= $status == 'pending' ? 'selected' : '' ?>>Pending</option><option value="refunded" <?= $status == 'refunded' ? 'selected' : '' ?>>Refunded</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'most_issued_books' || $reportType == 'member_activity' || $reportType == 'daily_visitors'): ?>
                <div class="col-auto"><div class="filter-label">Limit</div><input type="number" name="limit" class="form-control form-control-sm" value="<?= $limit ?>" min="1" max="500"></div>
            <?php endif; ?>

            <div class="col-auto"><div class="filter-label">Paper Size</div><select name="paper_size" class="form-select form-select-sm"><option value="A4" <?= $paperSize == 'A4' ? 'selected' : '' ?>>A4</option><option value="Letter" <?= $paperSize == 'Letter' ? 'selected' : '' ?>>Letter</option><option value="Legal" <?= $paperSize == 'Legal' ? 'selected' : '' ?>>Legal</option><option value="A3" <?= $paperSize == 'A3' ? 'selected' : '' ?>>A3</option></select></div>
            <div class="col-auto"><div class="filter-label">Orientation</div><select name="orientation" class="form-select form-select-sm"><option value="landscape" <?= $orientation == 'landscape' ? 'selected' : '' ?>>Landscape</option><option value="portrait" <?= $orientation == 'portrait' ? 'selected' : '' ?>>Portrait</option></select></div>
            <div class="col-auto"><div class="filter-label">Records</div><select name="limit" class="form-select form-select-sm"><option value="25" <?= $limit == 25 ? 'selected' : '' ?>>25</option><option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option><option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option><option value="200" <?= $limit == 200 ? 'selected' : '' ?>>200</option><option value="500" <?= $limit == 500 ? 'selected' : '' ?>>500</option></select></div>

            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button></div>
            <div class="col-auto"><a href="?type=<?= htmlspecialchars($reportType) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-undo"></i> Reset</a></div>
            <div class="col-auto">
                <button type="button" class="pdf-download-btn" onclick="downloadPDFReport()">
                    <i class="fas fa-file-pdf"></i> Download PDF <span class="badge">PDF</span>
                </button>
            </div>
            <div class="col-auto">
                <div class="dropdown d-inline-block">
                    <button class="btn btn-success btn-sm dropdown-toggle" type="button" onclick="toggleExportDropdown(event)"><i class="fas fa-download"></i> Export</button>
                    <ul class="dropdown-menu dropdown-menu-end" id="exportDropdownMenu">
                        <li><a class="dropdown-item" href="#" onclick="exportReport('excel')"><i class="fas fa-file-excel text-success"></i> Excel</a></li>
                        <li><a class="dropdown-item" href="#" onclick="exportReport('pdf')"><i class="fas fa-file-pdf text-danger"></i> PDF (server)</a></li>
                        <li><a class="dropdown-item" href="#" onclick="exportReport('csv')"><i class="fas fa-file-csv text-primary"></i> CSV</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-auto"><button type="button" onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Print</button></div>
        </form>
    </div>

    <!-- ========== REPORT CONTENT ========== -->
    <?php if (empty($displayData)): ?>
        <div class="alert alert-info text-center py-4"><i class="fas fa-info-circle fa-2x mb-2 d-block"></i><h5>No records found</h5><p class="mb-0">Try adjusting your filters or date range.</p></div>
    <?php elseif ($reportType == 'overdue'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($institutionName) ?> - Overdue Books Report <span class="float-end">Total: <?= count($displayData) ?> | Fine: <?= formatCurrency($overdueTotalFine ?? 0) ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th class="text-center">#</th><th class="text-center">Adm No</th><th>Member</th><th>Class/Dept</th><th>Div/Course</th><th>Book</th><th>Author</th><th class="text-center">Barcode</th><th class="text-center">Issue Date</th><th class="text-center">Due Date</th><th class="text-center">Days</th><th class="text-end">Fine</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $b): ?><tr class="overdue-row"><td class="text-center"><?= $sn++ ?></td><td class="text-center"><?= htmlspecialchars($b['member_admno'] ?? $b['admno'] ?? '-') ?></td><td><?= htmlspecialchars($b['member_name'] ?? 'Unknown') ?></td><td><?= htmlspecialchars($b['class']??'-') ?></td><td><?= htmlspecialchars($b['division']??'-') ?></td><td><?= htmlspecialchars($b['title']??'N/A') ?></td><td><?= htmlspecialchars($b['author']??'-') ?></td><td class="text-center"><?= htmlspecialchars($b['barcode'] ?? '-') ?></td><td class="text-center"><?= formatDate($b['issue_date'] ?? '') ?></td><td class="text-center"><?= formatDate($b['due_date'] ?? '') ?> <span class="badge bg-danger ms-1">Overdue</span></td><td class="text-center"><strong><?= $b['days_overdue'] ?? 0 ?></strong></td><td class="text-end text-danger"><?= formatCurrency($b['fine_amount'] ?? 0) ?></td></tr><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="11" class="text-end">Total Fine:</td><td class="text-end text-danger"><?= formatCurrency($overdueTotalFine ?? 0) ?></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php elseif ($reportType == 'computer'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-desktop"></i> <?= htmlspecialchars($institutionName) ?> - Computer Usage Report <span class="float-end">Sessions: <?= $totalSessions ?? 0 ?> | Minutes: <?= $totalMinutes ?? 0 ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th class="text-center">#</th><th>Member</th><th class="text-center">Adm No</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Computer</th><th class="text-center">Login Time</th><th class="text-center">Logout Time</th><th class="text-center">Minutes</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $s): ?><tr><td class="text-center"><?= $sn++ ?></td><td><?= htmlspecialchars($s['member_name']??'Unknown') ?><br><small class="text-muted"><?= htmlspecialchars($s['member_category']??'-') ?></small></td><td class="text-center"><?= htmlspecialchars($s['admno']??'-') ?></td><td><?= htmlspecialchars($s['member_category']??'-') ?></td><td><?= htmlspecialchars($s['class']??'-') ?></td><td><?= htmlspecialchars($s['division']??'-') ?></td><td><strong><?= htmlspecialchars($s['computer_name']??'-') ?></strong></td><td class="text-center"><?= isset($s['login_time']) ? date('d-m-Y H:i', strtotime($s['login_time'])) : '-' ?></td><td class="text-center"><?= isset($s['logout_time']) && $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : '<span class="badge bg-warning">Active</span>' ?></td><td class="text-center"><?= $s['duration_minutes']??'-' ?></td><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="9" class="text-end">Total Sessions: <?= $totalSessions ?? 0 ?> | Total Minutes:</td><td class="text-center"><?= $totalMinutes ?? 0 ?></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php elseif ($reportType == 'fines'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-hand-holding-usd"></i> <?= htmlspecialchars($institutionName) ?> - Fine Payments Report <span class="float-end">Total: <?= formatCurrency($totalFines ?? 0) ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th class="text-center">#</th><th class="text-center">Receipt No</th><th class="text-center">Adm No</th><th>Member</th><th>Category</th><th class="text-end">Amount</th><th class="text-center">Method</th><th class="text-center">Date</th><th class="text-center">Status</th><th>Notes</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $f): ?><tr><td class="text-center"><?= $sn++ ?></td><td class="text-center"><?= htmlspecialchars($f['receipt_no']??'-') ?></td><td class="text-center"><?= htmlspecialchars($f['member_admno'] ?? $f['admno'] ?? '-') ?></td><td><?= htmlspecialchars($f['member_name']??'Unknown') ?></td><td><?= htmlspecialchars($f['member_category']??'-') ?></td><td class="text-end"><?= formatCurrency($f['amount'] ?? 0) ?></td><td class="text-center"><?= ucfirst($f['payment_method']??'cash') ?></td><td class="text-center"><?= formatDate($f['payment_date'] ?? '') ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($f['status']??'paid') ?>"><?= ucfirst($f['status']??'paid') ?></span></td><td><?= htmlspecialchars($f['notes']??'') ?></td></tr><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="5" class="text-end">Total Collected:</td><td class="text-end"><?= formatCurrency($totalFines ?? 0) ?></td><td colspan="4"></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php elseif (in_array($reportType, ['category_wise', 'active_inactive', 'class_division', 'books_by_category', 'books_titles_summary', 'most_issued_books', 'member_activity', 'daily_visitors', 'purpose_analysis', 'class_division_issues_overdue'])): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-chart-bar"></i> <?= htmlspecialchars($institutionName) ?> - <?= $reportTitle ?> <span class="float-end">Records: <?= $totalRecords ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark">
                        <tr>
                            <?php if (!empty($displayData)): ?>
                                <?php foreach (array_keys($displayData[0]) as $col): ?>
                                    <th><?= htmlspecialchars(str_replace('_', ' ', ucfirst($col))) ?></th>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <th>No Data Available</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($displayData as $row): ?>
                            <tr>
                                <?php foreach ($row as $cell): ?>
                                    <td><?= htmlspecialchars((string)$cell) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="<?= max(1, count($displayData[0] ?? []) - 1) ?>" class="text-end">Total Records:</td>
                            <td class="text-center"><?= count($displayData) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-chart-line"></i> <?= htmlspecialchars($institutionName) ?> - <?= $reportTitle ?> <span class="float-end">Records: <?= $totalRecords ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr>
                        <?php if($reportType == 'members') echo '<th class="text-center">#</th><th class="text-center">Adm No</th><th>Name</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Email</th><th>Phone</th><th class="text-center">Active</th><th class="text-center">Issued</th><th class="text-end">Fines</th><th class="text-center">Status</th>';
                        elseif($reportType == 'books') echo '<th class="text-center">#</th><th class="text-center">Barcode</th><th>Title</th><th>Author</th><th>Publisher</th><th>Category</th><th>ISBN</th><th class="text-center">Qty</th><th class="text-center">Avail</th><th class="text-end">Price</th><th>Location</th>';
                        elseif($reportType == 'circulation') echo '<th class="text-center">#</th><th class="text-center">Adm No</th><th>Member</th><th>Book</th><th>Author</th><th class="text-center">Barcode</th><th class="text-center">Issue</th><th class="text-center">Return</th><th class="text-center">Due</th><th class="text-end">Fine</th><th class="text-center">Status</th>';
                        elseif($reportType == 'entry_exit') echo '<th class="text-center">#</th><th class="text-center">Adm No</th><th>Member</th><th>Category</th><th class="text-center">Date</th><th class="text-center">Entry</th><th class="text-center">Exit</th><th>Purpose</th>';
                        ?>
                    </tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $row): ?><tr><td class="text-center"><?= $sn++ ?></td><?php if($reportType == 'members'): ?><td class="text-center"><?= htmlspecialchars($row['admno'] ?? '-') ?></td><td><?= htmlspecialchars($row['name'] ?? 'Unknown') ?></td><td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td><td><?= htmlspecialchars($row['class'] ?? '-') ?></td><td><?= htmlspecialchars($row['division'] ?? '-') ?></td><td><?= htmlspecialchars($row['email'] ?? '-') ?></td><td><?= htmlspecialchars($row['phone'] ?? '-') ?></td><td class="text-center"><?= $row['active_books'] ?? 0 ?></td><td class="text-center"><?= $row['total_issued'] ?? 0 ?></td><td class="text-end"><?= formatCurrency($row['total_fines'] ?? 0) ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($row['status'] ?? 'active') ?>"><?= ucfirst($row['status'] ?? 'active') ?></span></td><?php elseif($reportType == 'books'): ?><td class="text-center"><?= htmlspecialchars($row['barcode'] ?? '-') ?></td><td><?= htmlspecialchars($row['title'] ?? 'N/A') ?></td><td><?= htmlspecialchars($row['author'] ?? '-') ?></td><td><?= htmlspecialchars($row['publisher'] ?? '-') ?></td><td><?= htmlspecialchars($row['category'] ?? '-') ?></td><td><?= htmlspecialchars($row['isbn'] ?? '-') ?></td><td class="text-center"><?= $row['quantity'] ?? 0 ?></td><td class="text-center"><span class="badge bg-<?= ($row['available'] ?? 0) == 0 ? 'danger' : (($row['available'] ?? 0) <= 2 ? 'warning' : 'success') ?>"><?= $row['available'] ?? 0 ?></span></td><td class="text-end"><?= formatCurrency($row['price'] ?? 0) ?></td><td><?= htmlspecialchars($row['location'] ?? '-') ?></td><?php elseif($reportType == 'circulation'): $statusText = isset($row['return_date']) && $row['return_date'] ? 'Returned' : (isset($row['due_date']) && strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued'); ?><td class="text-center"><?= htmlspecialchars($row['member_admno'] ?? $row['admno'] ?? '-') ?></td><td><?= htmlspecialchars($row['member_name'] ?? 'N/A') ?></td><td><?= htmlspecialchars($row['book_title'] ?? $row['title'] ?? 'N/A') ?></td><td><?= htmlspecialchars($row['author'] ?? '-') ?></td><td class="text-center"><?= htmlspecialchars($row['barcode'] ?? '-') ?></td><td class="text-center"><?= formatDate($row['issue_date'] ?? '') ?></td><td class="text-center"><?= isset($row['return_date']) && $row['return_date'] ? formatDate($row['return_date']) : '-' ?></td><td class="text-center"><?= formatDate($row['due_date'] ?? '') ?></td><td class="text-end"><?= formatCurrency($row['fine'] ?? 0) ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($statusText) ?>"><?= $statusText ?></span></td><?php elseif($reportType == 'entry_exit'): ?><td class="text-center"><?= htmlspecialchars($row['member_admno'] ?? $row['admno'] ?? '-') ?></td><td><?= htmlspecialchars($row['member_name'] ?? 'Unknown') ?></td><td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td><td class="text-center"><?= formatDate($row['entry_date'] ?? '') ?></td><td class="text-center"><?= formatTime($row['entry_time'] ?? '') ?></td><td class="text-center"><?= isset($row['exit_time']) && $row['exit_time'] ? formatTime($row['exit_time']) : '-' ?></td><td><?= htmlspecialchars($row['purpose'] ?? '-') ?></td><?php endif; ?></tr><?php endforeach; ?></tbody>
                    <?php if($reportType == 'books' && !empty($displayData)): $totalQty = array_sum(array_column($displayData, 'quantity')); $totalAvail = array_sum(array_column($displayData, 'available')); $totalPrice = array_sum(array_column($displayData, 'price')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="7" class="text-end">Totals:</td><td class="text-center"><?= $totalQty ?></td><td class="text-center"><?= $totalAvail ?></td><td class="text-end"><?= formatCurrency($totalPrice) ?></td><td></td></tr></tfoot>
                    <?php elseif($reportType == 'circulation' && !empty($displayData)): $totalFine = array_sum(array_column($displayData, 'fine')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="9" class="text-end">Total Fine:</td><td colspan="2" class="text-end"><?= formatCurrency($totalFine) ?></td></tr></tfoot>
                    <?php elseif($reportType == 'members' && !empty($displayData)): $totalActive = array_sum(array_column($displayData, 'active_books')); $totalIssued = array_sum(array_column($displayData, 'total_issued')); $totalFines = array_sum(array_column($displayData, 'total_fines')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="8" class="text-end">Totals:</td><td class="text-center"><?= $totalActive ?></td><td class="text-center"><?= $totalIssued ?></td><td class="text-end"><?= formatCurrency($totalFines) ?></td><td class="text-center"><?= count($displayData) ?> Members</td></tr></tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ========== PAGINATION ========== -->
    <?php if ($totalRecords > $limit): ?>
    <div class="pagination-wrapper mt-3 no-print">
        <div>
            Showing <?= ($page-1)*$limit+1 ?> to <?= min($page*$limit, $totalRecords) ?> of <?= $totalRecords ?> records
        </div>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page-1 ?>&<?= http_build_query(array_filter($_GET, function($k) { return $k != 'page'; }, ARRAY_FILTER_USE_KEY)) ?>">Prev</a></li>
                <?php for ($p = max(1, $page-3); $p <= min($totalPages, $page+3); $p++): ?>
                <li class="page-item <?= $p == $page ? 'active' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $p ?>&<?= http_build_query(array_filter($_GET, function($k) { return $k != 'page'; }, ARRAY_FILTER_USE_KEY)) ?>"><?= $p ?></a></li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page+1 ?>&<?= http_build_query(array_filter($_GET, function($k) { return $k != 'page'; }, ARRAY_FILTER_USE_KEY)) ?>">Next</a></li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <!-- ========== FOOTER ========== -->
    <div class="text-center text-muted small mt-3 no-print">
        <i class="fas fa-info-circle"></i> Report generated on <?= date('Y-m-d H:i:s') ?> | &copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function downloadPDFReport() {
    var btn = document.querySelector('.pdf-download-btn');
    var originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating PDF...';
    btn.disabled = true;
    
    var url = window.location.href.split('?')[0] + '?export=1&format=pdf';
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    
    fetch(url)
        .then(function(response) {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.blob();
        })
        .then(function(blob) {
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'report.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        })
        .catch(function(error) {
            console.error('Download failed:', error);
            window.open(url, '_blank');
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        });
}

function toggleExportDropdown(e) {
    e.preventDefault();
    e.stopPropagation();
    var menu = document.getElementById('exportDropdownMenu');
    menu.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    var dropdown = document.querySelector('.dropdown');
    var menu = document.getElementById('exportDropdownMenu');
    if (dropdown && !dropdown.contains(event.target)) {
        menu.classList.remove('show');
    }
});

function exportReport(format) {
    var url = window.location.href.split('?')[0] + '?export=1&format=' + format;
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    window.location.href = url;
}
</script>

<?php renderFooter(); ?>