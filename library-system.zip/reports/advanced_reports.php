<?php
/**
 * Advanced Reports Module
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 * Features: Members analysis, Books by category, Most issued books, Member activity,
 * Daily visitors, Purpose analysis, Class/Division issues & overdue, and Books summary (titles vs copies).
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$reportType = $_GET['type'] ?? 'class_division';
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
$fromDate = $_GET['from_date'] ?? date('Y-m-01');
$toDate = $_GET['to_date'] ?? date('Y-m-d');
$export = $_GET['export'] ?? '';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// Additional filters for Class/Division wise issues & overdue
$filterClass = $_GET['filter_class'] ?? '';
$filterDivision = $_GET['filter_division'] ?? '';

// Report settings from database
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';

// Currency settings
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    // Fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

// ========== DATA RETRIEVAL ==========
function getReportData($db, $type, $fromDate, $toDate, $limit, $filterClass = '', $filterDivision = '') {
    $data = [];
    switch ($type) {
        case 'class_division':
            $stmt = $db->query("SELECT class, division, COUNT(*) as count FROM members GROUP BY class, division ORDER BY class, division");
            $data = $stmt->fetchAll();
            break;
        case 'category_wise':
            $stmt = $db->query("SELECT member_category, COUNT(*) as count FROM members GROUP BY member_category");
            $data = $stmt->fetchAll();
            break;
        case 'active_inactive':
            $stmt = $db->query("SELECT 
                                CASE 
                                    WHEN status = 'active' OR status IS NULL THEN 'Active' 
                                    ELSE 'Inactive' 
                                END as status, 
                                COUNT(*) as count 
                                FROM members 
                                GROUP BY 
                                CASE 
                                    WHEN status = 'active' OR status IS NULL THEN 'Active' 
                                    ELSE 'Inactive' 
                                END");
            $data = $stmt->fetchAll();
            break;
        case 'books_by_category':
            $stmt = $db->query("SELECT category, SUM(quantity) as total_qty, SUM(available) as avail_qty FROM books GROUP BY category");
            $data = $stmt->fetchAll();
            break;
        case 'books_titles_summary':
            // Per category
            $stmt = $db->query("SELECT 
                                category, 
                                COUNT(DISTINCT CONCAT(COALESCE(title,''), '-', COALESCE(author,''))) as titles, 
                                SUM(quantity) as total_copies 
                                FROM books 
                                GROUP BY category 
                                ORDER BY category");
            $categoryData = $stmt->fetchAll();
            $stmtTotal = $db->query("SELECT 
                                COUNT(DISTINCT CONCAT(COALESCE(title,''), '-', COALESCE(author,''))) as total_titles, 
                                SUM(quantity) as total_copies 
                                FROM books");
            $overall = $stmtTotal->fetch(PDO::FETCH_ASSOC);
            $data = $categoryData;
            $data[] = [
                'category' => '** OVERALL **',
                'titles' => $overall['total_titles'] ?? 0,
                'total_copies' => $overall['total_copies'] ?? 0
            ];
            break;
        case 'most_issued_books':
            $stmt = $db->prepare("SELECT b.title, b.author, COUNT(c.id) as issue_count 
                                FROM circulation c 
                                LEFT JOIN books b ON c.barcode = b.barcode 
                                WHERE c.issue_date BETWEEN ? AND ? 
                                GROUP BY b.title 
                                ORDER BY issue_count DESC 
                                LIMIT ?");
            $stmt->execute([$fromDate, $toDate, $limit]);
            $data = $stmt->fetchAll();
            break;
        case 'member_activity':
            $stmt = $db->prepare("SELECT m.admno, m.name, m.member_category, COUNT(c.id) as total_issues 
                                FROM members m 
                                LEFT JOIN circulation c ON m.admno = c.admno AND c.issue_date BETWEEN ? AND ? 
                                GROUP BY m.admno 
                                ORDER BY total_issues DESC 
                                LIMIT ?");
            $stmt->execute([$fromDate, $toDate, $limit]);
            $data = $stmt->fetchAll();
            break;
        case 'daily_visitors':
            $stmt = $db->prepare("SELECT entry_date, COUNT(*) as visitors FROM entry_exit WHERE entry_date BETWEEN ? AND ? GROUP BY entry_date ORDER BY entry_date DESC LIMIT ?");
            $stmt->execute([$fromDate, $toDate, $limit]);
            $data = $stmt->fetchAll();
            break;
        case 'purpose_analysis':
            $stmt = $db->prepare("SELECT purpose, COUNT(*) as count FROM entry_exit WHERE entry_date BETWEEN ? AND ? GROUP BY purpose ORDER BY count DESC");
            $stmt->execute([$fromDate, $toDate]);
            $data = $stmt->fetchAll();
            break;
        case 'class_division_issues_overdue':
            $sql = "
                SELECT 
                    COALESCE(m.class, 'N/A') AS class,
                    COALESCE(m.division, 'N/A') AS division,
                    COUNT(DISTINCT CASE WHEN c.issue_date BETWEEN :fromDate AND :toDate THEN c.id END) AS total_issues,
                    COUNT(DISTINCT CASE WHEN c.due_date < CURDATE() AND c.return_date IS NULL THEN c.id END) AS total_overdue
                FROM members m
                LEFT JOIN circulation c ON m.admno = c.admno
                WHERE 1=1
            ";
            $params = [':fromDate' => $fromDate, ':toDate' => $toDate];
            if (!empty($filterClass)) {
                $sql .= " AND m.class = :class";
                $params[':class'] = $filterClass;
            }
            if (!empty($filterDivision)) {
                $sql .= " AND m.division = :division";
                $params[':division'] = $filterDivision;
            }
            $sql .= " GROUP BY m.class, m.division ORDER BY class, division";
            $stmt = $db->prepare($sql);
            foreach ($params as $key => &$val) {
                $stmt->bindValue($key, $val);
            }
            $stmt->execute();
            $data = $stmt->fetchAll();
            break;
        default:
            $data = [];
    }
    return $data;
}

// ========== EXPORT HANDLING ==========
if ($export == 1 && !empty($format)) {
    $rawData = getReportData($db, $reportType, $fromDate, $toDate, $limit, $filterClass, $filterDivision);
    $title = ucfirst(str_replace('_', ' ', $reportType)) . ' Report';
    $filename = strtolower(str_replace(' ', '_', $title)) . '_' . date('Y-m-d');
    
    if (empty($rawData)) {
        die("No data available for export.");
    }
    
    // Build export data with 'Sl No' as first key
    $exportData = [];
    $sn = 1;
    foreach ($rawData as $row) {
        $rowData = ['Sl No' => $sn++];
        foreach ($row as $key => $value) {
            $rowData[$key] = $value;
        }
        $exportData[] = $rowData;
    }
    $headers = array_keys($exportData[0]);
    
    // Generate HTML for PDF/Excel
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
    $html .= '<style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
    </style>
    </head><body>';
    
    $filters = [];
    if ($reportType == 'most_issued_books' || $reportType == 'member_activity' || $reportType == 'daily_visitors' || $reportType == 'purpose_analysis' || $reportType == 'class_division_issues_overdue') {
        $filters = ['Period' => formatDate($fromDate) . ' to ' . formatDate($toDate), 'Limit' => $limit];
        if (!empty($filterClass)) $filters['Class'] = $filterClass;
        if (!empty($filterDivision)) $filters['Division'] = $filterDivision;
    }
    $html .= getReportHeaderHTML($title, $fromDate, $toDate, $filters);
    
    // Table
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars(str_replace('_', ' ', ucfirst($header))) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; } // Skip 'Sl No' to avoid duplicate
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="' . (count($headers) - 1) . '" class="text-right">Total Records:</td>';
    $html .= '<td class="text-center">' . count($exportData) . '</td>';
    $html .= '</tr></tfoot></table>';
    
    // Summary
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total Records: ' . count($exportData) . ' | Report Type: ' . htmlspecialchars($title) . '
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    
    if ($format === 'excel') {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title></head><body>' . $html . '</body></html>';
        exit;
    } else {
        exportToPDF($html, $filename . '.pdf', $paperSize, $orientation);
        exit;
    }
}

// ========== ON‑SCREEN DATA ==========
$reportData = getReportData($db, $reportType, $fromDate, $toDate, $limit, $filterClass, $filterDivision);

// Summary stats (for cards)
$totalMembers = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$totalBooks = $db->query("SELECT SUM(quantity) FROM books")->fetchColumn();
$totalIssued = $db->query("SELECT COUNT(*) FROM circulation")->fetchColumn();
$totalDownloads = $db->query("SELECT SUM(downloads) FROM ebooks")->fetchColumn();

// Distinct class/division for dropdowns
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

renderHeader('Advanced Reports');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Reports - Library System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .module-card { cursor: pointer; transition: 0.3s; border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .module-card:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .settings-info { background: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>cc 100%); color: white; padding: 10px 15px; border-radius: 8px; margin-bottom: 15px; }
        @media print { .no-print, .btn, .module-card, form, .settings-info { display: none !important; } }
        .stat-card { border-radius: 10px; transition: transform 0.2s; }
        .stat-card:hover { transform: translateY(-3px); }
        .filter-row { background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-chart-line"></i> Advanced Reports</h2>
        <div class="no-print">
            <a href="../advanced_analytics/advanced_analytics.php" class="btn btn-primary">Advanced Analytics</a>
            <a href="index.php" class="btn btn-primary">Standard Reports</a>
            <a href="../index.php" class="btn btn-primary">Back to Home</a>
        </div>
    </div>

    <!-- Report Settings Info Bar -->
    <div class="settings-info no-print">
        <div class="row align-items-center">
            <div class="col-md-8">
                <i class="fas fa-chart-bar"></i> <strong>Report Settings Active:</strong> 
                Font Size: <?= $reportFontSize ?>px | 
                Logo: <?= ucfirst($reportLogoPosition) ?> | 
                Watermark: <?= $reportWatermarkEnabled ? 'Enabled' : 'Disabled' ?> | 
                Signature: <?= $reportSignatureEnabled ? 'Enabled' : 'Disabled' ?>
            </div>
            <div class="col-md-4 text-end">
                <a href="../settings.php#report" class="btn btn-sm btn-light">Configure</a>
            </div>
        </div>
    </div>

    <!-- Summary Statistics Cards -->
    <div class="row mb-4 no-print">
        <div class="col-md-3">
            <div class="card stat-card bg-primary text-white">
                <div class="card-body text-center">
                    <h3><?= number_format($totalMembers) ?></h3>
                    <small><i class="fas fa-users"></i> Total Members</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-success text-white">
                <div class="card-body text-center">
                    <h3><?= number_format($totalBooks) ?></h3>
                    <small><i class="fas fa-book"></i> Total Books (Copies)</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-warning text-dark">
                <div class="card-body text-center">
                    <h3><?= number_format($totalIssued) ?></h3>
                    <small><i class="fas fa-exchange-alt"></i> Total Transactions</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-info text-white">
                <div class="card-body text-center">
                    <h3><?= number_format($totalDownloads) ?></h3>
                    <small><i class="fas fa-download"></i> eBook Downloads</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Report Type Selection (Dropdown + Card Link) -->
    <div class="card mb-4 no-print">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Select Report Type</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3" id="reportForm">
                <div class="col-md-4">
                    <label class="form-label">Report Type</label>
                    <select name="type" class="form-select" onchange="this.form.submit()">
                        <option value="class_division" <?= $reportType == 'class_division' ? 'selected' : '' ?>>Members by Class & Division</option>
                        <option value="category_wise" <?= $reportType == 'category_wise' ? 'selected' : '' ?>>Members by Category</option>
                        <option value="active_inactive" <?= $reportType == 'active_inactive' ? 'selected' : '' ?>>Active vs Inactive Members</option>
                        <option value="books_by_category" <?= $reportType == 'books_by_category' ? 'selected' : '' ?>>Books by Category (Copies)</option>
                        <option value="books_titles_summary" <?= $reportType == 'books_titles_summary' ? 'selected' : '' ?>>Books Summary (Titles vs Copies)</option>
                        <option value="most_issued_books" <?= $reportType == 'most_issued_books' ? 'selected' : '' ?>>Most Issued Books</option>
                        <option value="member_activity" <?= $reportType == 'member_activity' ? 'selected' : '' ?>>Most Active Members</option>
                        <option value="daily_visitors" <?= $reportType == 'daily_visitors' ? 'selected' : '' ?>>Daily Visitors</option>
                        <option value="purpose_analysis" <?= $reportType == 'purpose_analysis' ? 'selected' : '' ?>>Purpose of Visit Analysis</option>
                        <option value="class_division_issues_overdue" <?= $reportType == 'class_division_issues_overdue' ? 'selected' : '' ?>>Class/Division wise Issues & Overdue</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" value="<?= $fromDate ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" value="<?= $toDate ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Limit (if applicable)</label>
                    <input type="number" name="limit" class="form-control" value="<?= $limit ?>" min="1" max="500">
                </div>
                
                <!-- Class & Division filters (only used by class_division_issues_overdue) -->
                <div class="col-md-3">
                    <label class="form-label">Filter by Class (Optional)</label>
                    <select name="filter_class" class="form-select">
                        <option value="">-- All Classes --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= htmlspecialchars($class) ?>" <?= $filterClass == $class ? 'selected' : '' ?>><?= htmlspecialchars($class) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Filter by Division (Optional)</label>
                    <select name="filter_division" class="form-select">
                        <option value="">-- All Divisions --</option>
                        <?php foreach ($divisions as $division): ?>
                            <option value="<?= htmlspecialchars($division) ?>" <?= $filterDivision == $division ? 'selected' : '' ?>><?= htmlspecialchars($division) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Quick link to the standalone Books Summary report -->
                <div class="col-md-3 mb-3">
                    <div class="card text-center module-card" onclick="location.href='books_titles_summary.php'">
                        <div class="card-body">
                            <i class="fas fa-chart-simple fa-3x text-success mb-2"></i>
                            <h6>Books Summary</h6>
                            <p class="small text-muted">Titles vs Copies (Standalone)</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Apply Filters</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Export Options -->
    <div class="card mb-4 no-print">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-download"></i> Export Options</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <input type="hidden" name="type" value="<?= $reportType ?>">
                <input type="hidden" name="from_date" value="<?= $fromDate ?>">
                <input type="hidden" name="to_date" value="<?= $toDate ?>">
                <input type="hidden" name="limit" value="<?= $limit ?>">
                <input type="hidden" name="filter_class" value="<?= $filterClass ?>">
                <input type="hidden" name="filter_division" value="<?= $filterDivision ?>">
                <input type="hidden" name="export" value="1">
                <div class="col-md-3">
                    <label class="form-label">Paper Size (PDF)</label>
                    <select name="paper_size" class="form-select">
                        <option value="A4" <?= $paperSize == 'A4' ? 'selected' : '' ?>>A4</option>
                        <option value="Letter" <?= $paperSize == 'Letter' ? 'selected' : '' ?>>Letter</option>
                        <option value="Legal" <?= $paperSize == 'Legal' ? 'selected' : '' ?>>Legal</option>
                        <option value="A3" <?= $paperSize == 'A3' ? 'selected' : '' ?>>A3</option>
                        <option value="A5" <?= $paperSize == 'A5' ? 'selected' : '' ?>>A5</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Orientation (PDF)</label>
                    <select name="orientation" class="form-select">
                        <option value="landscape" <?= $orientation == 'landscape' ? 'selected' : '' ?>>Landscape</option>
                        <option value="portrait" <?= $orientation == 'portrait' ? 'selected' : '' ?>>Portrait</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="format" value="excel" class="btn btn-success w-100"><i class="fas fa-file-excel"></i> Excel</button>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="format" value="pdf" class="btn btn-danger w-100"><i class="fas fa-file-pdf"></i> PDF</button>
                </div>
                <div class="col-md-2">
                    <button type="button" onclick="window.print()" class="btn btn-secondary w-100"><i class="fas fa-print"></i> Print</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Report Display Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-table"></i> <?= ucfirst(str_replace('_', ' ', $reportType)) ?> Report</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <?php if (!empty($reportData)): ?>
                                <?php foreach (array_keys($reportData[0]) as $col): ?>
                                    <th><?= htmlspecialchars(str_replace('_', ' ', ucfirst($col))) ?></th>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <th>No Data Available</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reportData as $row): ?>
                            <tr>
                                <?php foreach ($row as $cell): ?>
                                    <td><?= htmlspecialchars((string)$cell) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($reportData)): ?>
                            <tr><td colspan="10" class="text-center py-4">No records found for selected criteria</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($reportData) && count($reportData) > 0): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="<?= count(array_keys($reportData[0])) - 1 ?>" class="text-end">Total Records:</td>
                            <td class="text-center"><?= count($reportData) ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<?php renderFooter(); ?>