<?php
/**
 * Advanced Reports Module - Version 6.0 (Complete Update)
 * Fully respects all report settings from settings.php:
 * - Logo, right logo, logo position
 * - Watermark (text & opacity)
 * - Font size & primary colour
 * - Signature (name, title, image)
 * - All export formats (PDF, Excel, CSV)
 *
 * New in v6.0:
 * - Fine Payments Report
 * - Pagination for large datasets
 * - Interactive charts (Circulation trends) -- REMOVED per user request
 * - Improved filter UI with Select2
 * - AJAX-powered PDF download
 * - Better mobile responsiveness
 * - More robust image handling
 * - Enhanced error logging
 *
 * @package LibraryERP
 * @author  Sameermon
 * @version 6.1
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

// ==================== LOAD COMPOSER AUTOLOAD ====================
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

// ==================== ERROR HANDLING ====================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/report_errors.log');

// ==================== REQUIRE LOGIN ====================
requireLogin();

// ==================== DATABASE CONNECTION ====================
$db = getDB();

// ==================== REPORT PARAMETERS ====================
$reportType = $_GET['type'] ?? 'members';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';
$format = $_GET['format'] ?? '';
$limit = (int)($_GET['limit'] ?? 100);
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// Filter variables
$filterClass = $_GET['filter_class'] ?? '';
$filterDivision = $_GET['filter_division'] ?? '';
$overdueMinDays = $_GET['overdue_min_days'] ?? '';
$overdueFromDate = $_GET['overdue_from_date'] ?? date('Y-m-01');
$overdueToDate = $_GET['overdue_to_date'] ?? date('Y-m-d');
$computerMemberSearch = $_GET['computer_member_search'] ?? '';
$computerId = $_GET['computer_id'] ?? '';
$computerFromDate = $_GET['computer_from_date'] ?? date('Y-m-01');
$computerToDate = $_GET['computer_to_date'] ?? date('Y-m-d');
$category = $_GET['category'] ?? 'all';
$status = $_GET['status'] ?? 'all';
$location = $_GET['location'] ?? '';
$memberCategoryFilter = $_GET['member_category'] ?? 'all';
$bookCategoryFilter = $_GET['book_category'] ?? 'all';
$paymentMethod = $_GET['payment_method'] ?? 'all';
$fineFromDate = $_GET['fine_from_date'] ?? date('Y-m-01');
$fineToDate = $_GET['fine_to_date'] ?? date('Y-m-d');

// ==================== SETTINGS ====================
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);
$finePerDay = (float)($settings['fine_per_day'] ?? 2);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));
define('ITEMS_PER_PAGE', $limit);

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function formatTime($time, $format = 'H:i:s') {
    if (empty($time)) return '';
    try {
        return date($format, strtotime($time));
    } catch (Exception $e) {
        return $time;
    }
}

function getStatusBadge($status) {
    $badges = [
        'active' => 'success',
        'inactive' => 'secondary',
        'suspended' => 'warning',
        'blocked' => 'danger',
        'Returned' => 'success',
        'Overdue' => 'danger',
        'Issued' => 'primary',
        'Available' => 'success',
        'Unavailable' => 'danger',
        'Low Stock' => 'warning',
        'paid' => 'success',
        'pending' => 'warning',
        'refunded' => 'info'
    ];
    return $badges[$status] ?? 'secondary';
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

// =============================================================================
// REPORT HEADER / FOOTER / WATERMARK
// =============================================================================

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else { // text only
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// DATA FETCHING FUNCTIONS
// =============================================================================

function getMembersData($db, $category = 'all', $class = '', $division = '', $status = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT admno, name, member_category, class, division, email, phone, 
                   active_books, total_issued, total_fines, status 
            FROM members WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND member_category = ?"; $params[] = $category; }
    if (!empty($class)) { $sql .= " AND class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND division LIKE ?"; $params[] = "%$division%"; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $sql .= " ORDER BY name LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getMembersCount($db, $category = 'all', $class = '', $division = '', $status = 'all') {
    $sql = "SELECT COUNT(*) FROM members WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND member_category = ?"; $params[] = $category; }
    if (!empty($class)) { $sql .= " AND class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND division LIKE ?"; $params[] = "%$division%"; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getBooksData($db, $category = 'all', $status = 'all', $location = '', $limit = 100, $offset = 0) {
    $sql = "SELECT barcode, title, author, publisher, category, isbn, 
                   quantity, available, price, call_number, location, year 
            FROM books WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND category = ?"; $params[] = $category; }
    if ($status === 'available') { $sql .= " AND available > 0"; }
    elseif ($status === 'unavailable') { $sql .= " AND available = 0"; }
    elseif ($status === 'lowstock') { $sql .= " AND available > 0 AND available <= 2"; }
    if (!empty($location)) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    $sql .= " ORDER BY title LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getBooksCount($db, $category = 'all', $status = 'all', $location = '') {
    $sql = "SELECT COUNT(*) FROM books WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND category = ?"; $params[] = $category; }
    if ($status === 'available') { $sql .= " AND available > 0"; }
    elseif ($status === 'unavailable') { $sql .= " AND available = 0"; }
    elseif ($status === 'lowstock') { $sql .= " AND available > 0 AND available <= 2"; }
    if (!empty($location)) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getCirculationData($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT c.*, m.name as member_name, m.class, m.division, m.member_category,
                   b.title as book_title, b.author, b.isbn, b.category as book_category
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE DATE(c.issue_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND c.admno LIKE ?"; $params[] = "%$admno%"; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if ($memberCategory !== 'all') { $sql .= " AND m.member_category = ?"; $params[] = $memberCategory; }
    if ($bookCategory !== 'all') { $sql .= " AND b.category = ?"; $params[] = $bookCategory; }
    if ($type === 'issued') { $sql .= " AND c.return_date IS NULL AND c.due_date >= CURRENT_DATE"; }
    elseif ($type === 'returned') { $sql .= " AND c.return_date IS NOT NULL"; }
    elseif ($type === 'overdue') { $sql .= " AND c.return_date IS NULL AND c.due_date < CURRENT_DATE"; }
    $sql .= " ORDER BY c.issue_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getCirculationCount($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all') {
    $sql = "SELECT COUNT(*) FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE DATE(c.issue_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND c.admno LIKE ?"; $params[] = "%$admno%"; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if ($memberCategory !== 'all') { $sql .= " AND m.member_category = ?"; $params[] = $memberCategory; }
    if ($bookCategory !== 'all') { $sql .= " AND b.category = ?"; $params[] = $bookCategory; }
    if ($type === 'issued') { $sql .= " AND c.return_date IS NULL AND c.due_date >= CURRENT_DATE"; }
    elseif ($type === 'returned') { $sql .= " AND c.return_date IS NOT NULL"; }
    elseif ($type === 'overdue') { $sql .= " AND c.return_date IS NULL AND c.due_date < CURRENT_DATE"; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getEntryExitData($db, $from, $to, $admno = '', $category = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT e.*, m.name as member_name, m.member_category
            FROM entry_exit e 
            LEFT JOIN members m ON e.admno = m.admno
            WHERE e.entry_date BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND e.admno LIKE ?"; $params[] = "%$admno%"; }
    if ($category !== 'all') { $sql .= " AND e.member_category = ?"; $params[] = $category; }
    $sql .= " ORDER BY e.entry_date DESC, e.entry_time DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getEntryExitCount($db, $from, $to, $admno = '', $category = 'all') {
    $sql = "SELECT COUNT(*) FROM entry_exit e WHERE e.entry_date BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND e.admno LIKE ?"; $params[] = "%$admno%"; }
    if ($category !== 'all') { $sql .= " AND e.member_category = ?"; $params[] = $category; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getOverdueData($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '', $limit = 100, $offset = 0) {
    $sql = "SELECT c.*, m.name as member_name, m.class, m.division, 
                   b.title, b.author, b.isbn, b.barcode
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE c.return_date IS NULL AND c.due_date < CURRENT_DATE";
    $params = [];
    if ($fromDate && $toDate) { $sql .= " AND c.due_date BETWEEN ? AND ?"; $params[] = $fromDate; $params[] = $toDate; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if (!empty($minDays) && is_numeric($minDays)) { $sql .= " AND (julianday('now') - julianday(c.due_date)) >= ?"; $params[] = (int)$minDays; }
    $sql .= " ORDER BY c.due_date ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getOverdueCount($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '') {
    $sql = "SELECT COUNT(*) FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            WHERE c.return_date IS NULL AND c.due_date < CURRENT_DATE";
    $params = [];
    if ($fromDate && $toDate) { $sql .= " AND c.due_date BETWEEN ? AND ?"; $params[] = $fromDate; $params[] = $toDate; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if (!empty($minDays) && is_numeric($minDays)) { $sql .= " AND (julianday('now') - julianday(c.due_date)) >= ?"; $params[] = (int)$minDays; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getComputerData($db, $fromDate, $toDate, $memberSearch = '', $computerId = '', $limit = 100, $offset = 0) {
    $sql = "SELECT cs.*, m.admno, m.name as member_name, m.member_category, 
                   m.class, m.division, c.computer_name 
            FROM computer_sessions cs 
            LEFT JOIN members m ON cs.member_id = m.id 
            LEFT JOIN computers c ON cs.computer_id = c.id 
            WHERE 1=1";
    $params = [];
    if ($fromDate) { $sql .= " AND DATE(cs.login_time) >= ?"; $params[] = $fromDate; }
    if ($toDate) { $sql .= " AND DATE(cs.login_time) <= ?"; $params[] = $toDate; }
    if (!empty($memberSearch)) { $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; $params[] = "%$memberSearch%"; $params[] = "%$memberSearch%"; }
    if (!empty($computerId)) { $sql .= " AND cs.computer_id = ?"; $params[] = $computerId; }
    $sql .= " ORDER BY cs.login_time DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getComputerCount($db, $fromDate, $toDate, $memberSearch = '', $computerId = '') {
    $sql = "SELECT COUNT(*) FROM computer_sessions cs 
            LEFT JOIN members m ON cs.member_id = m.id 
            WHERE 1=1";
    $params = [];
    if ($fromDate) { $sql .= " AND DATE(cs.login_time) >= ?"; $params[] = $fromDate; }
    if ($toDate) { $sql .= " AND DATE(cs.login_time) <= ?"; $params[] = $toDate; }
    if (!empty($memberSearch)) { $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; $params[] = "%$memberSearch%"; $params[] = "%$memberSearch%"; }
    if (!empty($computerId)) { $sql .= " AND cs.computer_id = ?"; $params[] = $computerId; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getFinePaymentsData($db, $from, $to, $method = 'all', $status = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT fp.*, m.name as member_name, m.member_category
            FROM fine_payments fp
            LEFT JOIN members m ON fp.admno = m.admno
            WHERE DATE(fp.payment_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if ($method !== 'all') { $sql .= " AND fp.payment_method = ?"; $params[] = $method; }
    if ($status !== 'all') { $sql .= " AND fp.status = ?"; $params[] = $status; }
    $sql .= " ORDER BY fp.payment_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getFinePaymentsCount($db, $from, $to, $method = 'all', $status = 'all') {
    $sql = "SELECT COUNT(*) FROM fine_payments WHERE DATE(payment_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if ($method !== 'all') { $sql .= " AND payment_method = ?"; $params[] = $method; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getTransactionSummary($db, $from, $to) {
    $sql = "SELECT 
                COUNT(*) as total_transactions,
                SUM(CASE WHEN return_date IS NULL THEN 1 ELSE 0 END) as active_loans,
                SUM(CASE WHEN return_date IS NOT NULL THEN 1 ELSE 0 END) as returns_count,
                SUM(fine) as total_fines
            FROM circulation 
            WHERE DATE(issue_date) BETWEEN ? AND ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$from, $to]);
    return $stmt->fetch();
}

// =============================================================================
// EXPORT FUNCTIONS
// =============================================================================

function generatePDFReport($data, $headers, $title, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    global $reportPrimaryColor, $reportFooterText, $currencySymbol, $currencyDecimalPlaces,
           $reportFontSize, $reportLogoPosition;

    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
            .report-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px; }
            .report-title { font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . '; }
            .report-subtitle { font-size: 16px; font-weight: bold; margin: 8px 0; }
            .report-meta { font-size: 10px; margin: 3px 0; color: #555; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .text-danger { color: #dc3545; }
            .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
            .logo-img { height: 50px; width: auto; object-fit: contain; margin-bottom: 8px; }
            .table-footer { background-color: #f0f0f0; font-weight: bold; }
        </style>
    </head>
    <body>';

    // Header with logos
    $html .= '<div class="report-header">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '<div>' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '</div>';
    } else {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img"><br>';
    }
    $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
    $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        $html .= '<div class="report-meta"><strong>Period:</strong> ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to']) . '</div>';
    }
    $html .= '<div class="report-meta"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';

    // Table
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';

    $sn = 1;
    foreach ($data as $row) {
        $html .= '<tr>';
        $html .= '<td class="text-center">' . $sn++ . '</td>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && $value > 1000) {
                $html .= '<td class="text-right">' . number_format($value) . '</td>';
            } elseif (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '0000-00-00') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }

    $html .= '</tbody>';
    $html .= '<tfoot><tr class="table-footer">';
    $html .= '<td colspan="' . (count($headers) - 1) . '" class="text-right">Total Records:</td>';
    $html .= '<td class="text-center">' . count($data) . '</td>';
    $html .= '</tr></tfoot></table>';

    // Footer
    $html .= '<div class="footer">' . htmlspecialchars($reportFooterText) . '<br>&copy; ' . date('Y') . ' All rights reserved.</div>';
    $html .= '</body></html>';
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { error_log("mPDF error: " . $e->getMessage()); }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { error_log("DomPDF error: " . $e->getMessage()); }
    }

    // Ultimate fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToExcel($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $logo = getReportLogo();
            if ($logo && file_exists($logo['path'])) {
                try {
                    $drawing = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
                    $drawing->setName('Logo');
                    $drawing->setDescription('Report Logo');
                    $drawing->setPath($logo['path']);
                    $drawing->setHeight(60);
                    $drawing->setCoordinates('A1');
                    $drawing->setWorksheet($sheet);
                } catch (Exception $e) {}
            }
            $startRow = $logo ? 3 : 1;
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . $startRow, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A' . $startRow . ':' . $col . $startRow)->getFont()->setBold(true);
            $row = $startRow + 1;
            foreach ($data as $rowData) {
                $col = 'A';
                foreach ($rowData as $value) {
                    $sheet->setCellValue($col . $row, $value);
                    $col++;
                }
                $row++;
            }
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) { error_log("Excel export error: " . $e->getMessage()); }
    }
    // Fallback to CSV
    exportToCSV($data, $headers, $filename);
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['# ' . getInstitutionName()]);
    fputcsv($out, ['# Generated: ' . date('Y-m-d H:i:s')]);
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        fputcsv($out, ['# Period: ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to'])]);
    }
    fputcsv($out, ['#']);
    fputcsv($out, $headers);
    foreach ($data as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
    exit;
}

// =============================================================================
// MAIN EXPORT HANDLER
// =============================================================================

if (isset($_GET['export']) && $_GET['export'] == 1) {
    $format = $_GET['format'] ?? 'excel';
    $exportType = $_GET['type'] ?? $reportType;
    $rawData = [];
    $headers = [];
    $title = '';
    $filename = '';
    $limit = 10000; // For export, we get all records (max 10k)
    $offset = 0;

    switch ($exportType) {
        case 'members':
            $rawData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Email', 'Phone', 'Active Books', 'Total Issued', 'Total Fines', 'Status'];
            $title = 'Members Report';
            $filename = 'members_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'],
                    'Name' => $row['name'],
                    'Category' => $row['member_category'] ?? '-',
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Email' => $row['email'] ?? '-',
                    'Phone' => $row['phone'] ?? '-',
                    'Active Books' => (int)$row['active_books'],
                    'Total Issued' => (int)$row['total_issued'],
                    'Total Fines' => formatCurrency($row['total_fines']),
                    'Status' => ucfirst($row['status'] ?? 'active')
                ];
            }
            break;
        case 'books':
            $rawData = getBooksData($db, $category, $status, $location, $limit, $offset);
            $headers = ['Sl No', 'Barcode', 'Title', 'Author', 'Publisher', 'Category', 'ISBN', 'Quantity', 'Available', 'Price', 'Call Number', 'Location', 'Year'];
            $title = 'Books Report';
            $filename = 'books_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Barcode' => $row['barcode'],
                    'Title' => $row['title'],
                    'Author' => $row['author'] ?? '-',
                    'Publisher' => $row['publisher'] ?? '-',
                    'Category' => $row['category'] ?? '-',
                    'ISBN' => $row['isbn'] ?? '-',
                    'Quantity' => (int)$row['quantity'],
                    'Available' => (int)$row['available'],
                    'Price' => formatCurrency($row['price'] ?? 0),
                    'Call Number' => $row['call_number'] ?? '-',
                    'Location' => $row['location'] ?? '-',
                    'Year' => $row['year'] ?? '-'
                ];
            }
            break;
        case 'circulation':
            $rawData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Book', 'Author', 'Barcode', 'Issue Date', 'Return Date', 'Due Date', 'Fine', 'Status'];
            $title = 'Circulation Report';
            $filename = 'circulation_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $statusText = $row['return_date'] ? 'Returned' : (strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued');
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'],
                    'Member' => $row['member_name'] ?? 'N/A',
                    'Book' => $row['book_title'] ?? 'N/A',
                    'Author' => $row['author'] ?? '-',
                    'Barcode' => $row['barcode'],
                    'Issue Date' => formatDate($row['issue_date']),
                    'Return Date' => $row['return_date'] ? formatDate($row['return_date']) : '-',
                    'Due Date' => formatDate($row['due_date']),
                    'Fine' => formatCurrency($row['fine'] ?? 0),
                    'Status' => $statusText
                ];
            }
            break;
        case 'entry_exit':
            $rawData = getEntryExitData($db, $from, $to, '', $category, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Category', 'Entry Date', 'Entry Time', 'Exit Time', 'Purpose'];
            $title = 'Entry/Exit Report';
            $filename = 'entry_exit_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'],
                    'Member' => $row['member_name'],
                    'Category' => $row['member_category'] ?? '-',
                    'Entry Date' => formatDate($row['entry_date']),
                    'Entry Time' => formatTime($row['entry_time']),
                    'Exit Time' => $row['exit_time'] ? formatTime($row['exit_time']) : '-',
                    'Purpose' => $row['purpose'] ?? '-'
                ];
            }
            break;
        case 'overdue':
            $rawData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
            $finePerDay = (float)($GLOBALS['finePerDay'] ?? 2);
            $headers = ['Sl No', 'Adm No', 'Member', 'Class/Dept', 'Div/Course', 'Book', 'Author', 'Barcode', 'Issue Date', 'Due Date', 'Days Overdue', 'Fine'];
            $title = 'Overdue Books Report';
            $filename = 'overdue_books_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $days = max(1, ceil((time() - strtotime($row['due_date'])) / 86400));
                $fine = $days * $finePerDay;
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'],
                    'Member' => $row['member_name'],
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Book' => $row['title'] ?? 'N/A',
                    'Author' => $row['author'] ?? '-',
                    'Barcode' => $row['barcode'],
                    'Issue Date' => formatDate($row['issue_date']),
                    'Due Date' => formatDate($row['due_date']),
                    'Days Overdue' => $days,
                    'Fine' => formatCurrency($fine)
                ];
            }
            break;
        case 'computer':
            $rawData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
            $headers = ['Sl No', 'Member', 'Adm No', 'Category', 'Class/Dept', 'Div/Course', 'Computer', 'Login Time', 'Logout Time', 'Duration (min)'];
            $title = 'Computer Usage Report';
            $filename = 'computer_usage_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Member' => $row['member_name'] ?? 'Unknown',
                    'Adm No' => $row['admno'] ?? '-',
                    'Category' => $row['member_category'] ?? '-',
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Computer' => $row['computer_name'] ?? '-',
                    'Login Time' => date('d-m-Y H:i', strtotime($row['login_time'])),
                    'Logout Time' => $row['logout_time'] ? date('d-m-Y H:i', strtotime($row['logout_time'])) : 'Active',
                    'Duration (min)' => $row['duration_minutes'] ?? '-'
                ];
            }
            break;
        case 'fines':
            $rawData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
            $headers = ['Sl No', 'Receipt No', 'Adm No', 'Member', 'Category', 'Amount', 'Method', 'Date', 'Status', 'Notes'];
            $title = 'Fine Payments Report';
            $filename = 'fine_payments_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Receipt No' => $row['receipt_no'] ?? '-',
                    'Adm No' => $row['admno'],
                    'Member' => $row['member_name'] ?? 'Unknown',
                    'Category' => $row['member_category'] ?? '-',
                    'Amount' => formatCurrency($row['amount']),
                    'Method' => ucfirst($row['payment_method'] ?? 'cash'),
                    'Date' => formatDate($row['payment_date']),
                    'Status' => ucfirst($row['status'] ?? 'paid'),
                    'Notes' => $row['notes'] ?? ''
                ];
            }
            break;
        default:
            die("Invalid export type");
    }

    if ($format === 'pdf') {
        $pdfHtml = generatePDFReport($data, $headers, $title, $filename, $paperSize, $orientation);
        exportToPDF($pdfHtml, $filename . '.pdf', $paperSize, $orientation);
    } else {
        $exportData = [];
        foreach ($data as $row) $exportData[] = array_values($row);
        if ($format === 'excel') {
            exportToExcel($exportData, $headers, $filename);
        } elseif ($format === 'csv') {
            exportToCSV($exportData, $headers, $filename);
        } else {
            exportToExcel($exportData, $headers, $filename);
        }
    }
    exit;
}

// =============================================================================
// GET DATA FOR DISPLAY (on-screen) with Pagination
// =============================================================================

switch ($reportType) {
    case 'members':
        $totalRecords = getMembersCount($db, $category, $filterClass, $filterDivision, $status);
        $displayData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
        break;
    case 'books':
        $totalRecords = getBooksCount($db, $category, $status, $location);
        $displayData = getBooksData($db, $category, $status, $location, $limit, $offset);
        break;
    case 'circulation':
        $totalRecords = getCirculationCount($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter);
        $displayData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
        $summary = getTransactionSummary($db, $from, $to);
        // Removed $trend = getCirculationTrend(...) – chart no longer needed
        break;
    case 'entry_exit':
        $totalRecords = getEntryExitCount($db, $from, $to, '', $category);
        $displayData = getEntryExitData($db, $from, $to, '', $category, $limit, $offset);
        break;
    case 'overdue':
        $totalRecords = getOverdueCount($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays);
        $displayData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
        $overdueTotalFine = 0;
        foreach ($displayData as &$book) {
            $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
            $book['days_overdue'] = $days;
            $book['fine_amount'] = $days * $finePerDay;
            $overdueTotalFine += $book['fine_amount'];
        }
        break;
    case 'computer':
        $totalRecords = getComputerCount($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId);
        $displayData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
        $totalSessions = $totalRecords;
        $totalMinutes = array_sum(array_column($displayData, 'duration_minutes'));
        break;
    case 'fines':
        $totalRecords = getFinePaymentsCount($db, $fineFromDate, $fineToDate, $paymentMethod, $status);
        $displayData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
        $totalFines = array_sum(array_column($displayData, 'amount'));
        break;
    default:
        $displayData = [];
        $totalRecords = 0;
}

$totalPages = ($limit > 0) ? ceil($totalRecords / $limit) : 1;
$page = min($page, $totalPages);

// =============================================================================
// GET DROPDOWN DATA
// =============================================================================

function getCategories($db) {
    $stmt = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' ORDER BY category");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
function getMemberCategories($db) {
    $stmt = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
function getComputers($db) {
    $stmt = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name");
    return $stmt->fetchAll();
}
function getPaymentMethods($db) {
    return ['cash', 'card', 'online', 'cheque'];
}
$bookCategories = getCategories($db);
$memberCategories = getMemberCategories($db);
$computers = getComputers($db);
$paymentMethods = getPaymentMethods($db);

// =============================================================================
// RENDER PAGE
// =============================================================================

renderHeader('Reports');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Library System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f0f2f5; }
        .module-card { cursor: pointer; transition: all 0.3s ease; border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .module-card:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .module-card .card-body { padding: 1rem; }
        .module-card .module-icon { font-size: 2.5rem; margin-bottom: 0.5rem; }
        .settings-info {
            background: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>cc 100%);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: #1e3c72;
        }
        .stat-label {
            color: #6c757d;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .overdue-row { background-color: #f8d7da !important; }
        .overdue-row:hover { background-color: #f5c6cb !important; }
        .table-responsive { overflow-x: auto; }
        @media print { .no-print, .btn, .module-card, form, .settings-info { display: none !important; } }
        .filter-section {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .logo-preview {
            max-height: 40px;
            width: auto;
            object-fit: contain;
        }
        .settings-preview-card {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-top: 15px;
            border-left: 3px solid <?= $reportPrimaryColor ?>;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .report-title {
            color: <?= $reportPrimaryColor ?>;
        }
        .table-dark th {
            background-color: <?= $reportPrimaryColor ?>;
            border-color: <?= $reportPrimaryColor ?>;
        }
        .btn-primary {
            background-color: <?= $reportPrimaryColor ?>;
            border-color: <?= $reportPrimaryColor ?>;
        }
        .btn-primary:hover {
            background-color: <?= $reportPrimaryColor ?>dd;
            border-color: <?= $reportPrimaryColor ?>dd;
        }
        .card-header.bg-report {
            background-color: <?= $reportPrimaryColor ?>;
            color: white;
        }
        .filter-label {
            font-size: 0.8rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 2px;
        }
        .report-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }
        @media (max-width: 768px) {
            .module-card .module-icon { font-size: 2rem; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .filter-section .row > div { margin-bottom: 8px; }
        }
        .pdf-download-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .pdf-download-btn:hover {
            background: #c82333;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
        }
        .pdf-download-btn .badge {
            background: rgba(255,255,255,0.3);
            color: white;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 12px;
        }
        .pagination-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-top: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-chart-line"></i> Reports Module</h2>
        <div class="no-print report-actions">
            <a href="../advanced_analytics/advanced_analytics.php" class="btn btn-primary"><i class="fas fa-chart-pie"></i> Analytics</a>
            <a href="../index.php" class="btn btn-outline-secondary"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <!-- Settings Preview -->
    <div class="settings-info no-print">
        <div class="row align-items-center">
            <div class="col-md-8">
                <i class="fas fa-sliders-h"></i> <strong>Report Settings:</strong>
                Font: <?= $reportFontSize ?>px | Logo: <?= ucfirst($reportLogoPosition) ?> |
                Watermark: <?= $reportWatermarkEnabled ? 'On' : 'Off' ?> | Signature: <?= $reportSignatureEnabled ? 'On' : 'Off' ?>
            </div>
            <div class="col-md-4 text-end">
                <a href="../settings.php#report" class="btn btn-sm btn-light"><i class="fas fa-cog"></i> Configure</a>
            </div>
        </div>
    </div>

    <!-- Logo Preview Card -->
    <?php
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    if ($mainLogo || $rightLogo):
    ?>
    <div class="settings-preview-card no-print">
        <div class="row align-items-center">
            <div class="col-md-6">
                <strong><i class="fas fa-image"></i> Logo Preview:</strong>
                <?php if ($mainLogo): ?>
                    <img src="<?= $mainLogo['base64'] ?>" class="logo-preview ms-2" alt="Main Logo">
                <?php endif; ?>
                <?php if ($rightLogo): ?>
                    <span class="ms-3"><strong>Right Logo:</strong></span>
                    <img src="<?= $rightLogo['base64'] ?>" class="logo-preview ms-2" alt="Right Logo">
                <?php endif; ?>
            </div>
            <div class="col-md-6 text-end">
                <small class="text-muted">Position: <?= ucfirst($reportLogoPosition) ?></small>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Quick Stats -->
    <div class="stats-grid no-print">
        <div class="stat-card"><div class="stat-value"><?= number_format($totalRecords) ?></div><div class="stat-label">Total Records</div></div>
        <?php if ($reportType == 'members'): ?>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'active_books')) ?></div><div class="stat-label">Active Books</div></div>
            <div class="stat-card"><div class="stat-value"><?= count(array_filter($displayData, fn($m) => $m['status'] === 'active')) ?></div><div class="stat-label">Active Members</div></div>
        <?php elseif ($reportType == 'books'): ?>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'quantity')) ?></div><div class="stat-label">Total Copies</div></div>
            <div class="stat-card"><div class="stat-value"><?= array_sum(array_column($displayData, 'available')) ?></div><div class="stat-label">Available Copies</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Titles</div></div>
        <?php elseif ($reportType == 'circulation'): ?>
            <div class="stat-card"><div class="stat-value"><?= $summary['total_transactions'] ?? 0 ?></div><div class="stat-label">Transactions</div></div>
            <div class="stat-card"><div class="stat-value"><?= $summary['active_loans'] ?? 0 ?></div><div class="stat-label">Active Loans</div></div>
            <div class="stat-card"><div class="stat-value"><?= $summary['returns_count'] ?? 0 ?></div><div class="stat-label">Returns</div></div>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($summary['total_fines'] ?? 0) ?></div><div class="stat-label">Total Fine</div></div>
        <?php elseif ($reportType == 'overdue'): ?>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($overdueTotalFine ?? 0) ?></div><div class="stat-label">Total Fine</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Overdue Books</div></div>
        <?php elseif ($reportType == 'computer'): ?>
            <div class="stat-card"><div class="stat-value"><?= $totalSessions ?? 0 ?></div><div class="stat-label">Sessions</div></div>
            <div class="stat-card"><div class="stat-value"><?= $totalMinutes ?? 0 ?></div><div class="stat-label">Total Minutes</div></div>
        <?php elseif ($reportType == 'fines'): ?>
            <div class="stat-card"><div class="stat-value"><?= formatCurrency($totalFines ?? 0) ?></div><div class="stat-label">Total Collected</div></div>
            <div class="stat-card"><div class="stat-value"><?= count($displayData) ?></div><div class="stat-label">Payments</div></div>
        <?php endif; ?>
    </div>

    <!-- Report Type Cards -->
    <div class="row no-print mb-4">
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'members' ? 'border-primary' : '' ?>" onclick="location.href='?type=members'"><div class="card-body"><div class="module-icon text-primary"><i class="fas fa-users"></i></div><h6>Members</h6><p class="small text-muted">All members</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'books' ? 'border-primary' : '' ?>" onclick="location.href='?type=books'"><div class="card-body"><div class="module-icon text-success"><i class="fas fa-book"></i></div><h6>Books</h6><p class="small text-muted">Catalog</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'circulation' ? 'border-primary' : '' ?>" onclick="location.href='?type=circulation'"><div class="card-body"><div class="module-icon text-warning"><i class="fas fa-exchange-alt"></i></div><h6>Circulation</h6><p class="small text-muted">Transactions</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'entry_exit' ? 'border-primary' : '' ?>" onclick="location.href='?type=entry_exit'"><div class="card-body"><div class="module-icon text-info"><i class="fas fa-door-open"></i></div><h6>Entry/Exit</h6><p class="small text-muted">Movement</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'overdue' ? 'border-primary' : '' ?>" onclick="location.href='?type=overdue'"><div class="card-body"><div class="module-icon text-danger"><i class="fas fa-exclamation-triangle"></i></div><h6>Overdues</h6><p class="small text-muted">Dues & fines</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'computer' ? 'border-primary' : '' ?>" onclick="location.href='?type=computer'"><div class="card-body"><div class="module-icon text-secondary"><i class="fas fa-desktop"></i></div><h6>Computer</h6><p class="small text-muted">Usage logs</p></div></div></div>
        <div class="col-md-2 col-6 mb-3"><div class="card text-center module-card <?= $reportType == 'fines' ? 'border-primary' : '' ?>" onclick="location.href='?type=fines'"><div class="card-body"><div class="module-icon text-warning"><i class="fas fa-hand-holding-usd"></i></div><h6>Fine Payments</h6><p class="small text-muted">Collected fines</p></div></div></div>
    </div>

    <!-- Filter Section -->
    <div class="filter-section no-print">
        <form method="get" class="row g-2 align-items-end" id="reportFilterForm">
            <input type="hidden" name="type" value="<?= htmlspecialchars($reportType) ?>">

            <?php if ($reportType == 'circulation' || $reportType == 'entry_exit' || $reportType == 'fines'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="<?= ($reportType=='fines')?'fine_from_date':'from' ?>" class="form-control form-control-sm" value="<?= htmlspecialchars(($reportType=='fines')?$fineFromDate:$from) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="<?= ($reportType=='fines')?'fine_to_date':'to' ?>" class="form-control form-control-sm" value="<?= htmlspecialchars(($reportType=='fines')?$fineToDate:$to) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'overdue'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="overdue_from_date" class="form-control form-control-sm" value="<?= htmlspecialchars($overdueFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="overdue_to_date" class="form-control form-control-sm" value="<?= htmlspecialchars($overdueToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Min Days</div><select name="overdue_min_days" class="form-select form-select-sm"><option value="">All</option><option value="7" <?= $overdueMinDays == '7' ? 'selected' : '' ?>>7+ days</option><option value="14" <?= $overdueMinDays == '14' ? 'selected' : '' ?>>14+ days</option><option value="30" <?= $overdueMinDays == '30' ? 'selected' : '' ?>>30+ days</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'computer'): ?>
                <div class="col-auto"><div class="filter-label">From Date</div><input type="date" name="computer_from_date" class="form-control form-control-sm" value="<?= htmlspecialchars($computerFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To Date</div><input type="date" name="computer_to_date" class="form-control form-control-sm" value="<?= htmlspecialchars($computerToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Member</div><input type="text" name="computer_member_search" class="form-control form-control-sm" placeholder="Search member..." value="<?= htmlspecialchars($computerMemberSearch) ?>"></div>
                <div class="col-auto"><div class="filter-label">Computer</div><select name="computer_id" class="form-select form-select-sm"><option value="">All Computers</option><?php foreach ($computers as $comp): ?><option value="<?= $comp['id'] ?>" <?= $computerId == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'members' || $reportType == 'circulation' || $reportType == 'overdue'): ?>
                <?php if ($reportType == 'members'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
                <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Member Category</div><select name="member_category" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $memberCategoryFilter == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Book Category</div><select name="book_category" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $bookCategoryFilter == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
                <div class="col-auto"><div class="filter-label">Class/Dept</div><input type="text" name="filter_class" class="form-control form-control-sm" placeholder="Class/Dept" value="<?= htmlspecialchars($filterClass) ?>"></div>
                <div class="col-auto"><div class="filter-label">Div/Course</div><input type="text" name="filter_division" class="form-control form-control-sm" placeholder="Div/Course" value="<?= htmlspecialchars($filterDivision) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'members'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All Status</option><option value="active" <?= $status == 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $status == 'inactive' ? 'selected' : '' ?>>Inactive</option><option value="suspended" <?= $status == 'suspended' ? 'selected' : '' ?>>Suspended</option><option value="blocked" <?= $status == 'blocked' ? 'selected' : '' ?>>Blocked</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'books'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All Books</option><option value="available" <?= $status == 'available' ? 'selected' : '' ?>>Available</option><option value="unavailable" <?= $status == 'unavailable' ? 'selected' : '' ?>>Unavailable</option><option value="lowstock" <?= $status == 'lowstock' ? 'selected' : '' ?>>Low Stock</option></select></div>
                <div class="col-auto"><div class="filter-label">Location</div><input type="text" name="location" class="form-control form-control-sm" placeholder="Location" value="<?= htmlspecialchars($location) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All</option><option value="issued" <?= $status == 'issued' ? 'selected' : '' ?>>Issued</option><option value="returned" <?= $status == 'returned' ? 'selected' : '' ?>>Returned</option><option value="overdue" <?= $status == 'overdue' ? 'selected' : '' ?>>Overdue</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'entry_exit'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm"><option value="all">All Categories</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'fines'): ?>
                <div class="col-auto"><div class="filter-label">Method</div><select name="payment_method" class="form-select form-select-sm"><option value="all">All</option><?php foreach ($paymentMethods as $m): ?><option value="<?= $m ?>" <?= $paymentMethod == $m ? 'selected' : '' ?>><?= ucfirst($m) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm"><option value="all">All</option><option value="paid" <?= $status == 'paid' ? 'selected' : '' ?>>Paid</option><option value="pending" <?= $status == 'pending' ? 'selected' : '' ?>>Pending</option><option value="refunded" <?= $status == 'refunded' ? 'selected' : '' ?>>Refunded</option></select></div>
            <?php endif; ?>

            <div class="col-auto"><div class="filter-label">Paper Size</div><select name="paper_size" class="form-select form-select-sm"><option value="A4" <?= $paperSize == 'A4' ? 'selected' : '' ?>>A4</option><option value="Letter" <?= $paperSize == 'Letter' ? 'selected' : '' ?>>Letter</option><option value="Legal" <?= $paperSize == 'Legal' ? 'selected' : '' ?>>Legal</option><option value="A3" <?= $paperSize == 'A3' ? 'selected' : '' ?>>A3</option></select></div>
            <div class="col-auto"><div class="filter-label">Orientation</div><select name="orientation" class="form-select form-select-sm"><option value="landscape" <?= $orientation == 'landscape' ? 'selected' : '' ?>>Landscape</option><option value="portrait" <?= $orientation == 'portrait' ? 'selected' : '' ?>>Portrait</option></select></div>
            <div class="col-auto"><div class="filter-label">Records per page</div><select name="limit" class="form-select form-select-sm"><option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option><option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option><option value="200" <?= $limit == 200 ? 'selected' : '' ?>>200</option><option value="500" <?= $limit == 500 ? 'selected' : '' ?>>500</option></select></div>

            <div class="col-auto"><button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button></div>
            <div class="col-auto"><a href="?type=<?= htmlspecialchars($reportType) ?>" class="btn btn-secondary btn-sm"><i class="fas fa-undo"></i> Reset</a></div>
            <div class="col-auto"><button type="button" class="pdf-download-btn" onclick="downloadPDFReport()"><i class="fas fa-file-pdf"></i> Download PDF <span class="badge">PDF</span></button></div>
            <div class="col-auto">
                <div class="dropdown export-dropdown d-inline-block">
                    <button class="btn btn-success btn-sm dropdown-toggle" type="button" onclick="toggleExportDropdown(event)"><i class="fas fa-download"></i> Export</button>
                    <ul class="dropdown-menu dropdown-menu-end" id="exportDropdownMenu">
                        <li><a class="dropdown-item" href="#" onclick="exportReport('excel')"><i class="fas fa-file-excel text-success"></i> Excel</a></li>
                        <li><a class="dropdown-item" href="#" onclick="exportReport('pdf')"><i class="fas fa-file-pdf text-danger"></i> PDF (server)</a></li>
                        <li><a class="dropdown-item" href="#" onclick="exportReport('csv')"><i class="fas fa-file-csv text-primary"></i> CSV</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-auto"><button type="button" onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Print</button></div>
        </form>
    </div>

    <!-- Report Content -->
    <?php if (empty($displayData)): ?>
        <div class="alert alert-info text-center py-4"><i class="fas fa-info-circle fa-2x mb-2 d-block"></i><h5>No records found</h5><p class="mb-0">Try adjusting your filters or date range.</p></div>
    <?php elseif ($reportType == 'overdue'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-exclamation-triangle"></i> Overdue Books Report <span class="float-end">Total: <?= count($displayData) ?> | Fine: <?= formatCurrency($overdueTotalFine ?? 0) ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th>#</th><th>Adm No</th><th>Member</th><th>Class/Dept</th><th>Div/Course</th><th>Book</th><th>Author</th><th>Barcode</th><th>Issue Date</th><th>Due Date</th><th>Days</th><th>Fine</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $b): ?><tr class="overdue-row"><td class="text-center"><?= $sn++ ?></td><td class="text-center"><?= htmlspecialchars($b['admno']) ?></td><td><?= htmlspecialchars($b['member_name']) ?></td><td><?= htmlspecialchars($b['class']??'-') ?></td><td><?= htmlspecialchars($b['division']??'-') ?></td><td><?= htmlspecialchars($b['title']??'N/A') ?></td><td><?= htmlspecialchars($b['author']??'-') ?></td><td class="text-center"><?= htmlspecialchars($b['barcode']) ?></td><td class="text-center"><?= formatDate($b['issue_date']) ?></td><td class="text-center"><?= formatDate($b['due_date']) ?> <span class="badge bg-danger ms-1">Overdue</span></td><td class="text-center"><strong><?= $b['days_overdue'] ?></strong></td><td class="text-end text-danger"><?= formatCurrency($b['fine_amount']) ?></td></tr><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="11" class="text-end">Total Fine:</td><td class="text-end text-danger"><?= formatCurrency($overdueTotalFine ?? 0) ?></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php elseif ($reportType == 'computer'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-desktop"></i> Computer Usage Report <span class="float-end">Sessions: <?= $totalSessions ?? 0 ?> | Minutes: <?= $totalMinutes ?? 0 ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th>#</th><th>Member</th><th>Adm No</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Computer</th><th>Login Time</th><th>Logout Time</th><th>Minutes</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $s): ?><tr><td class="text-center"><?= $sn++ ?></td><td><?= htmlspecialchars($s['member_name']??'Unknown') ?><br><small class="text-muted"><?= htmlspecialchars($s['member_category']??'-') ?></small></td><td class="text-center"><?= htmlspecialchars($s['admno']??'-') ?></td><td><?= htmlspecialchars($s['member_category']??'-') ?></td><td><?= htmlspecialchars($s['class']??'-') ?></td><td><?= htmlspecialchars($s['division']??'-') ?></td><td><strong><?= htmlspecialchars($s['computer_name']??'-') ?></strong></td><td class="text-center"><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td><td class="text-center"><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : '<span class="badge bg-warning">Active</span>' ?></td><td class="text-center"><?= $s['duration_minutes']??'-' ?></td><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="9" class="text-end">Total Sessions: <?= $totalSessions ?? 0 ?> | Total Minutes:</td><td class="text-center"><?= $totalMinutes ?? 0 ?></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php elseif ($reportType == 'fines'): ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-hand-holding-usd"></i> Fine Payments Report <span class="float-end">Total: <?= formatCurrency($totalFines ?? 0) ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr><th>#</th><th>Receipt No</th><th>Adm No</th><th>Member</th><th>Category</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th>Notes</th></tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $f): ?><tr><td class="text-center"><?= $sn++ ?></td><td class="text-center"><?= htmlspecialchars($f['receipt_no']??'-') ?></td><td class="text-center"><?= htmlspecialchars($f['admno']) ?></td><td><?= htmlspecialchars($f['member_name']??'Unknown') ?></td><td><?= htmlspecialchars($f['member_category']??'-') ?></td><td class="text-end"><?= formatCurrency($f['amount']) ?></td><td class="text-center"><?= ucfirst($f['payment_method']??'cash') ?></td><td class="text-center"><?= formatDate($f['payment_date']) ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($f['status']??'paid') ?>"><?= ucfirst($f['status']??'paid') ?></span></td><td><?= htmlspecialchars($f['notes']??'') ?></td></tr><?php endforeach; ?></tbody>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="5" class="text-end">Total Collected:</td><td class="text-end"><?= formatCurrency($totalFines ?? 0) ?></td><td colspan="4"></td></tr></tfoot>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card">
        <div class="card-header bg-report fw-bold py-2"><i class="fas fa-chart-line"></i> <?= ucfirst($reportType) ?> Report <span class="float-end">Records: <?= $totalRecords ?></span></div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="reportTable">
                    <thead class="table-dark"><tr>
                        <?php if($reportType == 'members') echo '<th>#</th><th>Adm No</th><th>Name</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Email</th><th>Phone</th><th>Active</th><th>Issued</th><th>Fines</th><th>Status</th>';
                        elseif($reportType == 'books') echo '<th>#</th><th>Barcode</th><th>Title</th><th>Author</th><th>Publisher</th><th>Category</th><th>ISBN</th><th>Qty</th><th>Avail</th><th>Price</th><th>Location</th>';
                        elseif($reportType == 'circulation') echo '<th>#</th><th>Adm No</th><th>Member</th><th>Book</th><th>Author</th><th>Barcode</th><th>Issue</th><th>Return</th><th>Due</th><th>Fine</th><th>Status</th>';
                        elseif($reportType == 'entry_exit') echo '<th>#</th><th>Adm No</th><th>Member</th><th>Category</th><th>Date</th><th>Entry</th><th>Exit</th><th>Purpose</th>';
                        ?>
                    </tr></thead>
                    <tbody><?php $sn=($page-1)*$limit+1; foreach($displayData as $row): ?><tr><td class="text-center"><?= $sn++ ?></td><?php if($reportType == 'members'): ?><td class="text-center"><?= htmlspecialchars($row['admno']) ?></td><td><?= htmlspecialchars($row['name']) ?></td><td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td><td><?= htmlspecialchars($row['class'] ?? '-') ?></td><td><?= htmlspecialchars($row['division'] ?? '-') ?></td><td><?= htmlspecialchars($row['email'] ?? '-') ?></td><td><?= htmlspecialchars($row['phone'] ?? '-') ?></td><td class="text-center"><?= $row['active_books'] ?></td><td class="text-center"><?= $row['total_issued'] ?></td><td class="text-end"><?= formatCurrency($row['total_fines']) ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($row['status']) ?>"><?= ucfirst($row['status'] ?? 'active') ?></span></td><?php elseif($reportType == 'books'): ?><td class="text-center"><?= htmlspecialchars($row['barcode']) ?></td><td><?= htmlspecialchars($row['title']) ?></td><td><?= htmlspecialchars($row['author'] ?? '-') ?></td><td><?= htmlspecialchars($row['publisher'] ?? '-') ?></td><td><?= htmlspecialchars($row['category'] ?? '-') ?></td><td><?= htmlspecialchars($row['isbn'] ?? '-') ?></td><td class="text-center"><?= $row['quantity'] ?></td><td class="text-center"><span class="badge bg-<?= $row['available'] == 0 ? 'danger' : ($row['available'] <= 2 ? 'warning' : 'success') ?>"><?= $row['available'] ?></span></td><td class="text-end"><?= formatCurrency($row['price'] ?? 0) ?></td><td><?= htmlspecialchars($row['location'] ?? '-') ?></td><?php elseif($reportType == 'circulation'): $statusText = $row['return_date'] ? 'Returned' : (strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued'); ?><td class="text-center"><?= htmlspecialchars($row['admno']) ?></td><td><?= htmlspecialchars($row['member_name'] ?? 'N/A') ?></td><td><?= htmlspecialchars($row['book_title'] ?? 'N/A') ?></td><td><?= htmlspecialchars($row['author'] ?? '-') ?></td><td class="text-center"><?= htmlspecialchars($row['barcode']) ?></td><td class="text-center"><?= formatDate($row['issue_date']) ?></td><td class="text-center"><?= $row['return_date'] ? formatDate($row['return_date']) : '-' ?></td><td class="text-center"><?= formatDate($row['due_date']) ?></td><td class="text-end"><?= formatCurrency($row['fine'] ?? 0) ?></td><td class="text-center"><span class="badge bg-<?= getStatusBadge($statusText) ?>"><?= $statusText ?></span></td><?php elseif($reportType == 'entry_exit'): ?><td class="text-center"><?= htmlspecialchars($row['admno']) ?></td><td><?= htmlspecialchars($row['member_name']) ?></td><td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td><td class="text-center"><?= formatDate($row['entry_date']) ?></td><td class="text-center"><?= formatTime($row['entry_time']) ?></td><td class="text-center"><?= $row['exit_time'] ? formatTime($row['exit_time']) : '-' ?></td><td><?= htmlspecialchars($row['purpose'] ?? '-') ?></td><?php endif; ?></tr><?php endforeach; ?></tbody>
                    <?php if($reportType == 'books' && !empty($displayData)): $totalQty = array_sum(array_column($displayData, 'quantity')); $totalAvail = array_sum(array_column($displayData, 'available')); $totalPrice = array_sum(array_column($displayData, 'price')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="7" class="text-end">Totals:</td><td class="text-center"><?= $totalQty ?></td><td class="text-center"><?= $totalAvail ?></td><td class="text-end"><?= formatCurrency($totalPrice) ?></td><td></td></tr></tfoot>
                    <?php elseif($reportType == 'circulation' && !empty($displayData)): $totalFine = array_sum(array_column($displayData, 'fine')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="9" class="text-end">Total Fine:</td><td colspan="2" class="text-end"><?= formatCurrency($totalFine) ?></td></tr></tfoot>
                    <?php elseif($reportType == 'members' && !empty($displayData)): $totalActive = array_sum(array_column($displayData, 'active_books')); $totalIssued = array_sum(array_column($displayData, 'total_issued')); $totalFines = array_sum(array_column($displayData, 'total_fines')); ?>
                    <tfoot class="table-light"><tr class="fw-bold"><td colspan="8" class="text-end">Totals:</td><td class="text-center"><?= $totalActive ?></td><td class="text-center"><?= $totalIssued ?></td><td class="text-end"><?= formatCurrency($totalFines) ?></td><td class="text-center"><?= count($displayData) ?> Members</td></tr></tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Pagination -->
    <?php if ($totalRecords > $limit): ?>
    <div class="pagination-wrapper mt-3 no-print">
        <div>
            Showing <?= ($page-1)*$limit+1 ?> to <?= min($page*$limit, $totalRecords) ?> of <?= $totalRecords ?> records
        </div>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page-1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Prev</a></li>
                <?php for ($p = max(1, $page-3); $p <= min($totalPages, $page+3); $p++): ?>
                <li class="page-item <?= $p == $page ? 'active' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $p ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>"><?= $p ?></a></li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page+1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Next</a></li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <div class="text-center text-muted small mt-3 no-print"><i class="fas fa-info-circle"></i> Report generated on <?= date('Y-m-d H:i:s') ?></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $.fn.select2 !== 'undefined') {
        $('.select2').select2({ theme: 'bootstrap-5', width: '100%', placeholder: 'Select an option' });
    }
});

// ========== PDF Download (AJAX) ==========
function downloadPDFReport() {
    var btn = document.querySelector('.pdf-download-btn');
    var originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating PDF...';
    btn.disabled = true;
    var url = window.location.href.split('?')[0] + '?export=1&format=pdf';
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    fetch(url)
        .then(response => response.blob())
        .then(blob => {
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'report.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        })
        .catch(function(error) {
            console.error('Download failed:', error);
            var iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.src = url;
            document.body.appendChild(iframe);
            setTimeout(function() {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
                setTimeout(function() { if (iframe.parentNode) iframe.parentNode.removeChild(iframe); }, 5000);
            }, 3000);
        });
}

function toggleExportDropdown(e) {
    e.preventDefault();
    e.stopPropagation();
    var menu = document.getElementById('exportDropdownMenu');
    menu.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    var dropdown = document.querySelector('.export-dropdown');
    var menu = document.getElementById('exportDropdownMenu');
    if (dropdown && !dropdown.contains(event.target)) {
        menu.classList.remove('show');
    }
});

function exportReport(format) {
    var url = window.location.href.split('?')[0] + '?export=1&format=' + format;
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    window.location.href = url;
}

window.onbeforeprint = function() { console.log('Printing report...'); };
</script>

<?php renderFooter(); ?>