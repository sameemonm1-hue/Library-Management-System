<?php
/**
 * Advanced Reports Module - Version 10.0 (Unified Design)
 * 
 * Fully respects all report settings from settings.php:
 * - Logo, right logo, logo position
 * - Watermark (text & opacity)
 * - Font size & primary colour
 * - Signature (name, title, image)
 * - All export formats (PDF, Excel, CSV)
 * 
 * UNIFIED DESIGN: Complete gradient color scheme matching all modules
 *
 * @package LibraryERP
 * @author  Sameermon
 * @version 10.0
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

// ==================== CONSTANTS ====================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// ==================== LOAD COMPOSER AUTOLOAD ====================
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

// ==================== ERROR HANDLING ====================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/report_errors.log');

// ==================== REQUIRE LOGIN ====================
requireLogin();

// ==================== DATABASE CONNECTION ====================
$db = getDB();

// ==================== REPORT PARAMETERS ====================
$reportType = $_GET['type'] ?? 'members';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';
$format = $_GET['format'] ?? '';
$limit = (int)($_GET['limit'] ?? 100);
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// Filter variables
$filterClass = $_GET['filter_class'] ?? '';
$filterDivision = $_GET['filter_division'] ?? '';
$overdueMinDays = $_GET['overdue_min_days'] ?? '';
$overdueFromDate = $_GET['overdue_from_date'] ?? date('Y-m-01');
$overdueToDate = $_GET['overdue_to_date'] ?? date('Y-m-d');
$computerMemberSearch = $_GET['computer_member_search'] ?? '';
$computerId = $_GET['computer_id'] ?? '';
$computerFromDate = $_GET['computer_from_date'] ?? date('Y-m-01');
$computerToDate = $_GET['computer_to_date'] ?? date('Y-m-d');
$category = $_GET['category'] ?? 'all';
$status = $_GET['status'] ?? 'all';
$location = $_GET['location'] ?? '';
$memberCategoryFilter = $_GET['member_category'] ?? 'all';
$bookCategoryFilter = $_GET['book_category'] ?? 'all';
$paymentMethod = $_GET['payment_method'] ?? 'all';
$fineFromDate = $_GET['fine_from_date'] ?? date('Y-m-01');
$fineToDate = $_GET['fine_to_date'] ?? date('Y-m-d');

// ==================== SETTINGS ====================
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);
$finePerDay = (float)($settings['fine_per_day'] ?? 2);

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function formatTime($time, $format = 'H:i:s') {
    if (empty($time)) return '';
    try {
        return date($format, strtotime($time));
    } catch (Exception $e) {
        return $time;
    }
}

function formatFileSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}

function getStatusBadge($status) {
    $badges = [
        'active' => 'success',
        'inactive' => 'secondary',
        'suspended' => 'warning',
        'blocked' => 'danger',
        'Returned' => 'success',
        'Overdue' => 'danger',
        'Issued' => 'primary',
        'Available' => 'success',
        'Unavailable' => 'danger',
        'Low Stock' => 'warning',
        'paid' => 'success',
        'pending' => 'warning',
        'refunded' => 'info'
    ];
    return $badges[$status] ?? 'secondary';
}

function getCoverBase64($coverPath) {
    if (empty($coverPath)) return '';
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) return $coverPath;
    $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
    if (!file_exists($fullPath)) return '';
    $data = @file_get_contents($fullPath);
    if ($data === false) return '';
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

// =============================================================================
// REPORT HEADER / FOOTER / WATERMARK
// =============================================================================

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $institutionName = getInstitutionName();
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// DATA FETCHING FUNCTIONS
// =============================================================================

function getMembersData($db, $category = 'all', $class = '', $division = '', $status = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT admno, name, member_category, class, division, email, phone, 
                   active_books, total_issued, total_fines, status 
            FROM members WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND member_category = ?"; $params[] = $category; }
    if (!empty($class)) { $sql .= " AND class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND division LIKE ?"; $params[] = "%$division%"; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $sql .= " ORDER BY name LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getMembersCount($db, $category = 'all', $class = '', $division = '', $status = 'all') {
    $sql = "SELECT COUNT(*) FROM members WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND member_category = ?"; $params[] = $category; }
    if (!empty($class)) { $sql .= " AND class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND division LIKE ?"; $params[] = "%$division%"; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getBooksData($db, $category = 'all', $status = 'all', $location = '', $limit = 100, $offset = 0) {
    $sql = "SELECT barcode, title, author, publisher, category, isbn, 
                   quantity, available, price, call_number, location, year 
            FROM books WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND category = ?"; $params[] = $category; }
    if ($status === 'available') { $sql .= " AND available > 0"; }
    elseif ($status === 'unavailable') { $sql .= " AND available = 0"; }
    elseif ($status === 'lowstock') { $sql .= " AND available > 0 AND available <= 2"; }
    if (!empty($location)) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    $sql .= " ORDER BY title LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getBooksCount($db, $category = 'all', $status = 'all', $location = '') {
    $sql = "SELECT COUNT(*) FROM books WHERE 1=1";
    $params = [];
    if ($category !== 'all') { $sql .= " AND category = ?"; $params[] = $category; }
    if ($status === 'available') { $sql .= " AND available > 0"; }
    elseif ($status === 'unavailable') { $sql .= " AND available = 0"; }
    elseif ($status === 'lowstock') { $sql .= " AND available > 0 AND available <= 2"; }
    if (!empty($location)) { $sql .= " AND location LIKE ?"; $params[] = "%$location%"; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getCirculationData($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT c.*, m.name as member_name, m.class, m.division, m.member_category,
                   b.title as book_title, b.author, b.isbn, b.category as book_category
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE DATE(c.issue_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND c.admno LIKE ?"; $params[] = "%$admno%"; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if ($memberCategory !== 'all') { $sql .= " AND m.member_category = ?"; $params[] = $memberCategory; }
    if ($bookCategory !== 'all') { $sql .= " AND b.category = ?"; $params[] = $bookCategory; }
    if ($type === 'issued') { $sql .= " AND c.return_date IS NULL AND c.due_date >= CURRENT_DATE"; }
    elseif ($type === 'returned') { $sql .= " AND c.return_date IS NOT NULL"; }
    elseif ($type === 'overdue') { $sql .= " AND c.return_date IS NULL AND c.due_date < CURRENT_DATE"; }
    $sql .= " ORDER BY c.issue_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getCirculationCount($db, $from, $to, $admno = '', $class = '', $division = '', $type = 'all', $memberCategory = 'all', $bookCategory = 'all') {
    $sql = "SELECT COUNT(*) FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE DATE(c.issue_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND c.admno LIKE ?"; $params[] = "%$admno%"; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if ($memberCategory !== 'all') { $sql .= " AND m.member_category = ?"; $params[] = $memberCategory; }
    if ($bookCategory !== 'all') { $sql .= " AND b.category = ?"; $params[] = $bookCategory; }
    if ($type === 'issued') { $sql .= " AND c.return_date IS NULL AND c.due_date >= CURRENT_DATE"; }
    elseif ($type === 'returned') { $sql .= " AND c.return_date IS NOT NULL"; }
    elseif ($type === 'overdue') { $sql .= " AND c.return_date IS NULL AND c.due_date < CURRENT_DATE"; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getEntryExitData($db, $from, $to, $admno = '', $category = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT e.*, m.name as member_name, m.member_category
            FROM entry_exit e 
            LEFT JOIN members m ON e.admno = m.admno
            WHERE e.entry_date BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND e.admno LIKE ?"; $params[] = "%$admno%"; }
    if ($category !== 'all') { $sql .= " AND e.member_category = ?"; $params[] = $category; }
    $sql .= " ORDER BY e.entry_date DESC, e.entry_time DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getEntryExitCount($db, $from, $to, $admno = '', $category = 'all') {
    $sql = "SELECT COUNT(*) FROM entry_exit e WHERE e.entry_date BETWEEN ? AND ?";
    $params = [$from, $to];
    if (!empty($admno)) { $sql .= " AND e.admno LIKE ?"; $params[] = "%$admno%"; }
    if ($category !== 'all') { $sql .= " AND e.member_category = ?"; $params[] = $category; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getOverdueData($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '', $limit = 100, $offset = 0) {
    $sql = "SELECT c.*, m.name as member_name, m.class, m.division, 
                   b.title, b.author, b.isbn, b.barcode
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            LEFT JOIN books b ON c.barcode = b.barcode 
            WHERE c.return_date IS NULL AND c.due_date < CURRENT_DATE";
    $params = [];
    if ($fromDate && $toDate) { $sql .= " AND c.due_date BETWEEN ? AND ?"; $params[] = $fromDate; $params[] = $toDate; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if (!empty($minDays) && is_numeric($minDays)) { $sql .= " AND (julianday('now') - julianday(c.due_date)) >= ?"; $params[] = (int)$minDays; }
    $sql .= " ORDER BY c.due_date ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getOverdueCount($db, $fromDate, $toDate, $class = '', $division = '', $minDays = '') {
    $sql = "SELECT COUNT(*) FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            WHERE c.return_date IS NULL AND c.due_date < CURRENT_DATE";
    $params = [];
    if ($fromDate && $toDate) { $sql .= " AND c.due_date BETWEEN ? AND ?"; $params[] = $fromDate; $params[] = $toDate; }
    if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
    if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
    if (!empty($minDays) && is_numeric($minDays)) { $sql .= " AND (julianday('now') - julianday(c.due_date)) >= ?"; $params[] = (int)$minDays; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getComputerData($db, $fromDate, $toDate, $memberSearch = '', $computerId = '', $limit = 100, $offset = 0) {
    $sql = "SELECT cs.*, m.admno, m.name as member_name, m.member_category, 
                   m.class, m.division, c.computer_name 
            FROM computer_sessions cs 
            LEFT JOIN members m ON cs.member_id = m.id 
            LEFT JOIN computers c ON cs.computer_id = c.id 
            WHERE 1=1";
    $params = [];
    if ($fromDate) { $sql .= " AND DATE(cs.login_time) >= ?"; $params[] = $fromDate; }
    if ($toDate) { $sql .= " AND DATE(cs.login_time) <= ?"; $params[] = $toDate; }
    if (!empty($memberSearch)) { $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; $params[] = "%$memberSearch%"; $params[] = "%$memberSearch%"; }
    if (!empty($computerId)) { $sql .= " AND cs.computer_id = ?"; $params[] = $computerId; }
    $sql .= " ORDER BY cs.login_time DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getComputerCount($db, $fromDate, $toDate, $memberSearch = '', $computerId = '') {
    $sql = "SELECT COUNT(*) FROM computer_sessions cs 
            LEFT JOIN members m ON cs.member_id = m.id 
            WHERE 1=1";
    $params = [];
    if ($fromDate) { $sql .= " AND DATE(cs.login_time) >= ?"; $params[] = $fromDate; }
    if ($toDate) { $sql .= " AND DATE(cs.login_time) <= ?"; $params[] = $toDate; }
    if (!empty($memberSearch)) { $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)"; $params[] = "%$memberSearch%"; $params[] = "%$memberSearch%"; }
    if (!empty($computerId)) { $sql .= " AND cs.computer_id = ?"; $params[] = $computerId; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getFinePaymentsData($db, $from, $to, $method = 'all', $status = 'all', $limit = 100, $offset = 0) {
    $sql = "SELECT fp.*, m.name as member_name, m.member_category
            FROM fine_payments fp
            LEFT JOIN members m ON fp.admno = m.admno
            WHERE DATE(fp.payment_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if ($method !== 'all') { $sql .= " AND fp.payment_method = ?"; $params[] = $method; }
    if ($status !== 'all') { $sql .= " AND fp.status = ?"; $params[] = $status; }
    $sql .= " ORDER BY fp.payment_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getFinePaymentsCount($db, $from, $to, $method = 'all', $status = 'all') {
    $sql = "SELECT COUNT(*) FROM fine_payments WHERE DATE(payment_date) BETWEEN ? AND ?";
    $params = [$from, $to];
    if ($method !== 'all') { $sql .= " AND payment_method = ?"; $params[] = $method; }
    if ($status !== 'all') { $sql .= " AND status = ?"; $params[] = $status; }
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

function getTransactionSummary($db, $from, $to) {
    $sql = "SELECT 
                COUNT(*) as total_transactions,
                SUM(CASE WHEN return_date IS NULL THEN 1 ELSE 0 END) as active_loans,
                SUM(CASE WHEN return_date IS NOT NULL THEN 1 ELSE 0 END) as returns_count,
                SUM(fine) as total_fines
            FROM circulation 
            WHERE DATE(issue_date) BETWEEN ? AND ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$from, $to]);
    return $stmt->fetch();
}

// =============================================================================
// EXPORT FUNCTIONS
// =============================================================================

function generatePDFReport($data, $headers, $title, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    global $reportPrimaryColor, $reportFooterText, $currencySymbol, $currencyDecimalPlaces,
           $reportFontSize, $reportLogoPosition;

    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
            .report-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px; }
            .report-title { font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . '; }
            .report-subtitle { font-size: 16px; font-weight: bold; margin: 8px 0; }
            .report-meta { font-size: 10px; margin: 3px 0; color: #555; }
            table { border-collapse: collapse; width: 100%; margin-top: 10px; }
            th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
            th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
            td { text-align: left; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .text-danger { color: #dc3545; }
            .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
            .logo-img { height: 50px; width: auto; object-fit: contain; margin-bottom: 8px; }
            .table-footer { background-color: #f0f0f0; font-weight: bold; }
        </style>
    </head>
    <body>';

    // Header with logos
    $html .= '<div class="report-header">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '<div style="text-align: center;">';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
    }
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        $html .= '<div class="report-meta"><strong>Period:</strong> ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to']) . '</div>';
    }
    $html .= '<div class="report-meta"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';

    // Table
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';

    $sn = 1;
    foreach ($data as $row) {
        $html .= '<tr>';
        $html .= '<td class="text-center">' . $sn++ . '</td>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && $value > 1000) {
                $html .= '<td class="text-right">' . number_format($value) . '</td>';
            } elseif (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '0000-00-00') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }

    $html .= '</tbody>';
    $html .= '<tfoot><tr class="table-footer">';
    $html .= '<td colspan="' . (count($headers) - 1) . '" class="text-right">Total Records:</td>';
    $html .= '<td class="text-center">' . count($data) . '</td>';
    $html .= '</tr></tfoot></table>';

    // Footer
    $html .= '<div class="footer">' . htmlspecialchars($reportFooterText) . '<br>&copy; ' . date('Y') . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.</div>';
    $html .= '</body></html>';
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { error_log("mPDF error: " . $e->getMessage()); }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { error_log("DomPDF error: " . $e->getMessage()); }
    }

    // Ultimate fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToExcel($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    if (class_exists('PhpOffice\PhpSpreadsheet\Spreadsheet')) {
        try {
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $logo = getReportLogo();
            if ($logo && file_exists($logo['path'])) {
                try {
                    $drawing = new \PhpOffice\PhpSpreadsheet\Worksheet\Drawing();
                    $drawing->setName('Logo');
                    $drawing->setDescription('Report Logo');
                    $drawing->setPath($logo['path']);
                    $drawing->setHeight(60);
                    $drawing->setCoordinates('A1');
                    $drawing->setWorksheet($sheet);
                } catch (Exception $e) {}
            }
            $startRow = $logo ? 3 : 1;
            $col = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($col . $startRow, $header);
                $sheet->getColumnDimension($col)->setAutoSize(true);
                $col++;
            }
            $sheet->getStyle('A' . $startRow . ':' . $col . $startRow)->getFont()->setBold(true);
            $row = $startRow + 1;
            foreach ($data as $rowData) {
                $col = 'A';
                foreach ($rowData as $value) {
                    $sheet->setCellValue($col . $row, $value);
                    $col++;
                }
                $row++;
            }
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        } catch (Exception $e) { error_log("Excel export error: " . $e->getMessage()); }
    }
    exportToCSV($data, $headers, $filename);
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['# ' . getInstitutionName()]);
    fputcsv($out, ['# Generated: ' . date('Y-m-d H:i:s')]);
    if (!empty($GLOBALS['from']) && !empty($GLOBALS['to'])) {
        fputcsv($out, ['# Period: ' . formatDate($GLOBALS['from']) . ' to ' . formatDate($GLOBALS['to'])]);
    }
    fputcsv($out, ['#']);
    fputcsv($out, $headers);
    foreach ($data as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
    exit;
}

// =============================================================================
// MAIN EXPORT HANDLER
// =============================================================================

if (isset($_GET['export']) && $_GET['export'] == 1) {
    $format = $_GET['format'] ?? 'excel';
    $exportType = $_GET['type'] ?? $reportType;
    $rawData = [];
    $headers = [];
    $title = '';
    $filename = '';
    $limit = 10000;
    $offset = 0;

    switch ($exportType) {
        case 'members':
            $rawData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Name', 'Category', 'Class/Dept', 'Div/Course', 'Email', 'Phone', 'Active Books', 'Total Issued', 'Total Fines', 'Status'];
            $title = 'Members Report';
            $filename = 'members_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'] ?? '',
                    'Name' => $row['name'] ?? '',
                    'Category' => $row['member_category'] ?? '-',
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Email' => $row['email'] ?? '-',
                    'Phone' => $row['phone'] ?? '-',
                    'Active Books' => (int)($row['active_books'] ?? 0),
                    'Total Issued' => (int)($row['total_issued'] ?? 0),
                    'Total Fines' => formatCurrency($row['total_fines'] ?? 0),
                    'Status' => ucfirst($row['status'] ?? 'active')
                ];
            }
            break;
        case 'books':
            $rawData = getBooksData($db, $category, $status, $location, $limit, $offset);
            $headers = ['Sl No', 'Barcode', 'Title', 'Author', 'Publisher', 'Category', 'ISBN', 'Quantity', 'Available', 'Price', 'Call Number', 'Location', 'Year'];
            $title = 'Books Report';
            $filename = 'books_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Barcode' => $row['barcode'] ?? '',
                    'Title' => $row['title'] ?? '',
                    'Author' => $row['author'] ?? '-',
                    'Publisher' => $row['publisher'] ?? '-',
                    'Category' => $row['category'] ?? '-',
                    'ISBN' => $row['isbn'] ?? '-',
                    'Quantity' => (int)($row['quantity'] ?? 0),
                    'Available' => (int)($row['available'] ?? 0),
                    'Price' => formatCurrency($row['price'] ?? 0),
                    'Call Number' => $row['call_number'] ?? '-',
                    'Location' => $row['location'] ?? '-',
                    'Year' => $row['year'] ?? '-'
                ];
            }
            break;
        case 'circulation':
            $rawData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Book', 'Author', 'Barcode', 'Issue Date', 'Return Date', 'Due Date', 'Fine', 'Status'];
            $title = 'Circulation Report';
            $filename = 'circulation_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $statusText = $row['return_date'] ? 'Returned' : (strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued');
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'] ?? '',
                    'Member' => $row['member_name'] ?? 'N/A',
                    'Book' => $row['book_title'] ?? 'N/A',
                    'Author' => $row['author'] ?? '-',
                    'Barcode' => $row['barcode'] ?? '',
                    'Issue Date' => formatDate($row['issue_date'] ?? ''),
                    'Return Date' => $row['return_date'] ? formatDate($row['return_date']) : '-',
                    'Due Date' => formatDate($row['due_date'] ?? ''),
                    'Fine' => formatCurrency($row['fine'] ?? 0),
                    'Status' => $statusText
                ];
            }
            break;
        case 'entry_exit':
            $rawData = getEntryExitData($db, $from, $to, '', $category, $limit, $offset);
            $headers = ['Sl No', 'Adm No', 'Member', 'Category', 'Entry Date', 'Entry Time', 'Exit Time', 'Purpose'];
            $title = 'Entry/Exit Report';
            $filename = 'entry_exit_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'] ?? '',
                    'Member' => $row['member_name'] ?? '',
                    'Category' => $row['member_category'] ?? '-',
                    'Entry Date' => formatDate($row['entry_date'] ?? ''),
                    'Entry Time' => formatTime($row['entry_time'] ?? ''),
                    'Exit Time' => $row['exit_time'] ? formatTime($row['exit_time']) : '-',
                    'Purpose' => $row['purpose'] ?? '-'
                ];
            }
            break;
        case 'overdue':
            $rawData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
            $finePerDay = (float)($GLOBALS['finePerDay'] ?? 2);
            $headers = ['Sl No', 'Adm No', 'Member', 'Class/Dept', 'Div/Course', 'Book', 'Author', 'Barcode', 'Issue Date', 'Due Date', 'Days Overdue', 'Fine'];
            $title = 'Overdue Books Report';
            $filename = 'overdue_books_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $days = max(1, ceil((time() - strtotime($row['due_date'])) / 86400));
                $fine = $days * $finePerDay;
                $data[] = [
                    'Sl No' => $sn++,
                    'Adm No' => $row['admno'] ?? '',
                    'Member' => $row['member_name'] ?? '',
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Book' => $row['title'] ?? 'N/A',
                    'Author' => $row['author'] ?? '-',
                    'Barcode' => $row['barcode'] ?? '',
                    'Issue Date' => formatDate($row['issue_date'] ?? ''),
                    'Due Date' => formatDate($row['due_date'] ?? ''),
                    'Days Overdue' => $days,
                    'Fine' => formatCurrency($fine)
                ];
            }
            break;
        case 'computer':
            $rawData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
            $headers = ['Sl No', 'Member', 'Adm No', 'Category', 'Class/Dept', 'Div/Course', 'Computer', 'Login Time', 'Logout Time', 'Duration (min)'];
            $title = 'Computer Usage Report';
            $filename = 'computer_usage_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Member' => $row['member_name'] ?? 'Unknown',
                    'Adm No' => $row['admno'] ?? '-',
                    'Category' => $row['member_category'] ?? '-',
                    'Class/Dept' => $row['class'] ?? '-',
                    'Div/Course' => $row['division'] ?? '-',
                    'Computer' => $row['computer_name'] ?? '-',
                    'Login Time' => date('d-m-Y H:i', strtotime($row['login_time'])),
                    'Logout Time' => $row['logout_time'] ? date('d-m-Y H:i', strtotime($row['logout_time'])) : 'Active',
                    'Duration (min)' => $row['duration_minutes'] ?? '-'
                ];
            }
            break;
        case 'fines':
            $rawData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
            $headers = ['Sl No', 'Receipt No', 'Adm No', 'Member', 'Category', 'Amount', 'Method', 'Date', 'Status', 'Notes'];
            $title = 'Fine Payments Report';
            $filename = 'fine_payments_report_' . date('Y-m-d');
            $data = [];
            $sn = 1;
            foreach ($rawData as $row) {
                $data[] = [
                    'Sl No' => $sn++,
                    'Receipt No' => $row['receipt_no'] ?? '-',
                    'Adm No' => $row['admno'] ?? '',
                    'Member' => $row['member_name'] ?? 'Unknown',
                    'Category' => $row['member_category'] ?? '-',
                    'Amount' => formatCurrency($row['amount'] ?? 0),
                    'Method' => ucfirst($row['payment_method'] ?? 'cash'),
                    'Date' => formatDate($row['payment_date'] ?? ''),
                    'Status' => ucfirst($row['status'] ?? 'paid'),
                    'Notes' => $row['notes'] ?? ''
                ];
            }
            break;
        default:
            die("Invalid export type");
    }

    if ($format === 'pdf') {
        $pdfHtml = generatePDFReport($data, $headers, $title, $filename, $paperSize, $orientation);
        exportToPDF($pdfHtml, $filename . '.pdf', $paperSize, $orientation);
    } else {
        $exportData = [];
        foreach ($data as $row) $exportData[] = array_values($row);
        if ($format === 'excel') {
            exportToExcel($exportData, $headers, $filename);
        } elseif ($format === 'csv') {
            exportToCSV($exportData, $headers, $filename);
        } else {
            exportToExcel($exportData, $headers, $filename);
        }
    }
    exit;
}

// =============================================================================
// GET DATA FOR DISPLAY (on-screen) with Pagination
// =============================================================================

$displayData = [];
$totalRecords = 0;
$totalPages = 1;

switch ($reportType) {
    case 'members':
        $totalRecords = getMembersCount($db, $category, $filterClass, $filterDivision, $status);
        $displayData = getMembersData($db, $category, $filterClass, $filterDivision, $status, $limit, $offset);
        break;
    case 'books':
        $totalRecords = getBooksCount($db, $category, $status, $location);
        $displayData = getBooksData($db, $category, $status, $location, $limit, $offset);
        break;
    case 'circulation':
        $totalRecords = getCirculationCount($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter);
        $displayData = getCirculationData($db, $from, $to, '', $filterClass, $filterDivision, $status, $memberCategoryFilter, $bookCategoryFilter, $limit, $offset);
        $summary = getTransactionSummary($db, $from, $to);
        break;
    case 'entry_exit':
        $totalRecords = getEntryExitCount($db, $from, $to, '', $category);
        $displayData = getEntryExitData($db, $from, $to, '', $category, $limit, $offset);
        break;
    case 'overdue':
        $totalRecords = getOverdueCount($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays);
        $displayData = getOverdueData($db, $overdueFromDate, $overdueToDate, $filterClass, $filterDivision, $overdueMinDays, $limit, $offset);
        $overdueTotalFine = 0;
        foreach ($displayData as &$book) {
            $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
            $book['days_overdue'] = $days;
            $book['fine_amount'] = $days * $finePerDay;
            $overdueTotalFine += $book['fine_amount'];
        }
        break;
    case 'computer':
        $totalRecords = getComputerCount($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId);
        $displayData = getComputerData($db, $computerFromDate, $computerToDate, $computerMemberSearch, $computerId, $limit, $offset);
        $totalSessions = $totalRecords;
        $totalMinutes = array_sum(array_column($displayData, 'duration_minutes'));
        break;
    case 'fines':
        $totalRecords = getFinePaymentsCount($db, $fineFromDate, $fineToDate, $paymentMethod, $status);
        $displayData = getFinePaymentsData($db, $fineFromDate, $fineToDate, $paymentMethod, $status, $limit, $offset);
        $totalFines = array_sum(array_column($displayData, 'amount'));
        break;
    default:
        $displayData = [];
        $totalRecords = 0;
}

$totalPages = ($limit > 0) ? ceil($totalRecords / $limit) : 1;
$page = min($page, $totalPages);

// =============================================================================
// GET DROPDOWN DATA
// =============================================================================

function getCategories($db) {
    $stmt = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' AND (status != 'Deleted' OR status IS NULL) ORDER BY category");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
function getMemberCategories($db) {
    $stmt = $db->query("SELECT DISTINCT member_category FROM members WHERE member_category IS NOT NULL AND member_category != '' ORDER BY member_category");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
function getComputers($db) {
    $stmt = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name");
    return $stmt->fetchAll();
}
function getPaymentMethods($db) {
    return ['cash', 'card', 'online', 'cheque'];
}
$bookCategories = getCategories($db);
$memberCategories = getMemberCategories($db);
$computers = getComputers($db);
$paymentMethods = getPaymentMethods($db);

// =============================================================================
// RENDER PAGE - UNIFIED DESIGN WITH GRADIENT CARDS
// =============================================================================

$institutionName = getInstitutionName();
renderHeader('Reports');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
            --gradient-primary: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>dd 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        
        body { 
            background: #f0f2f5; 
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
        }
        
        /* ===== SETTINGS BAR - REMOVED ===== */
        .settings-bar {
            display: none !important;
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: var(--gradient-primary);
            border-radius: var(--radius-card);
            padding: 20px 20px 20px 70px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
            cursor: default;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }
        
        /* ===== MODULE CARDS - UNIFIED GRADIENT ===== */
        .module-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }
        .module-card { 
            cursor: pointer; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
            border: none; 
            border-radius: var(--radius-card);
            overflow: hidden;
            position: relative;
            min-height: 90px;
            max-height: 110px;
            box-shadow: var(--shadow-sm);
            background: var(--gradient-primary);
            color: white;
        }
        .module-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .module-card:active { transform: scale(0.97); }
        .module-card .card-body { 
            padding: 12px 14px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            height: 100%;
            position: relative;
            z-index: 1;
        }
        .module-card .module-icon { 
            font-size: 1.8rem; 
            margin-bottom: 4px;
            display: block;
            transition: transform 0.3s ease;
            line-height: 1.1;
            color: rgba(255,255,255,0.9);
        }
        .module-card:hover .module-icon { transform: scale(1.1); }
        .module-card .module-title { 
            font-size: 0.8rem; 
            font-weight: 600; 
            margin: 0;
            line-height: 1.2;
            letter-spacing: 0.02em;
            color: white;
        }
        .module-card .module-subtitle {
            font-size: 0.6rem;
            opacity: 0.8;
            line-height: 1.1;
            margin: 0;
            color: rgba(255,255,255,0.85);
        }
        .module-card .module-count {
            position: absolute;
            bottom: 4px;
            right: 8px;
            font-size: 0.55rem;
            opacity: 0.8;
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .module-card.active { 
            box-shadow: 0 0 0 3px white, 0 0 0 6px var(--primary-color); 
            transform: scale(1.02);
        }
        
        /* ===== FILTER SECTION ===== */
        .filter-section {
            background: white;
            border-radius: var(--radius-card);
            padding: 15px 20px;
            margin-bottom: 18px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }
        .filter-section:hover {
            box-shadow: var(--shadow-hover);
        }
        .filter-label {
            font-size: 0.65rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 2px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .filter-section .form-control,
        .filter-section .form-select {
            font-size: 0.75rem;
            padding: 4px 8px;
            border-radius: 8px;
            min-height: 32px;
        }
        .filter-section .form-control:focus,
        .filter-section .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(var(--primary-rgb), 0.25);
        }
        
        /* ===== REPORT CARD ===== */
        .report-card { 
            border-radius: var(--radius-card); 
            overflow: hidden; 
            box-shadow: var(--shadow-sm);
            border: none;
            transition: all 0.3s ease;
        }
        .report-card:hover {
            box-shadow: var(--shadow-hover);
        }
        .report-card .card-header {
            padding: 10px 16px;
            font-size: 0.85rem;
            background: var(--gradient-primary);
            color: white;
            border-bottom: none;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .report-card .card-header .badge {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .report-card .table { 
            font-size: 0.75rem; 
            margin-bottom: 0; 
        }
        .report-card .table th { 
            background: #f8f9fa; 
            color: #495057; 
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
            padding: 6px 10px;
            white-space: nowrap;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }
        .report-card .table td { 
            padding: 6px 10px; 
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
        }
        .report-card .table tbody tr:hover {
            background: rgba(var(--primary-rgb), 0.04);
        }
        .report-card .table tfoot td {
            background: #f8f9fa;
            font-weight: 600;
            border-top: 2px solid #dee2e6;
        }
        
        /* ===== OVERDUE ROW ===== */
        .overdue-row { background-color: #fff5f5 !important; }
        .overdue-row:hover { background-color: #ffe8e8 !important; }
        
        /* ===== BADGES ===== */
        .badge { font-size: 0.65rem; padding: 3px 8px; }
        
        /* ===== PAGINATION ===== */
        .pagination-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 0.75rem;
            margin-top: 14px;
        }
        .pagination-wrapper .page-link {
            font-size: 0.7rem;
            padding: 4px 10px;
            color: var(--primary-color);
        }
        .pagination .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ===== LOGO PREVIEW ===== */
        .logo-preview { 
            max-height: 32px; 
            width: auto; 
            object-fit: contain; 
            background: white; 
            padding: 2px 8px; 
            border-radius: 6px; 
        }
        .settings-preview-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 10px 16px;
            margin-bottom: 16px;
            border-left: 4px solid var(--primary-color);
            box-shadow: var(--shadow-sm);
            font-size: 0.75rem;
        }
        
        /* ===== BUTTONS ===== */
        .btn-sm-custom {
            font-size: 0.7rem;
            padding: 4px 12px;
            border-radius: 8px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-success {
            background: linear-gradient(135deg, #28a745, #20c997);
            border: none;
        }
        .btn-success:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }
        .btn-danger {
            background: linear-gradient(135deg, #dc3545, #c82333);
            border: none;
        }
        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
        }
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);
            border: none;
            color: white;
        }
        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
            color: white;
        }
        .pdf-download-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 14px;
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 0.7rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .pdf-download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
            color: white;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .module-grid { grid-template-columns: repeat(3, 1fr); gap: 8px; }
            .module-card { min-height: 75px; max-height: 90px; }
            .module-card .module-icon { font-size: 1.4rem; }
            .module-card .module-title { font-size: 0.65rem; }
            .module-card .module-subtitle { font-size: 0.5rem; }
            .filter-section { padding: 10px 12px; }
            .filter-section .row > div { margin-bottom: 4px; }
            .report-card .table { font-size: 0.65rem; }
            .report-card .table th, .report-card .table td { padding: 4px 6px; }
        }
        @media (max-width: 480px) {
            .stat-card .stat-value { font-size: 18px; }
            .stat-card { padding: 12px 12px 12px 50px; }
            .stat-card .stat-icon-wrapper { width: 28px; height: 28px; font-size: 13px; left: 12px; }
            .module-grid { grid-template-columns: repeat(2, 1fr); }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .module-grid { display: none !important; }
            .filter-section { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .settings-preview-card { display: none !important; }
            .report-card { box-shadow: none !important; border: 1px solid #ddd; }
            .report-card .card-header { background: #e9ecef !important; color: #333 !important; }
            .report-card .card-header .badge { background: #ddd !important; color: #333 !important; }
            .report-card .table th { background: #e9ecef !important; color: #333 !important; }
            .report-card .table tfoot td { background: #e9ecef !important; }
            .badge { border: 1px solid #ddd !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-3">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-2 mb-3">
        <div>
            <h5 style="color: var(--primary-color); margin: 0; font-size: 1.1rem; font-weight: 700;">
                <i class="fas fa-chart-line"></i> <?= htmlspecialchars($institutionName) ?> 
                <span style="font-weight: 400; color: #6c757d; font-size: 0.8rem;">Reports</span>
            </h5>
            <p class="text-muted small mb-0"><?= ucfirst(str_replace('_', ' ', $reportType)) ?> Report</p>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary btn-sm-custom" title="Home"><i class="fas fa-home"></i> Home</a>
            <a href="advanced_reports.php" class="btn btn-secondary btn-sm-custom" title="Advanced"><i class="fas fa-chart-pie"></i> Advanced</a>
        </div>
    </div>

    <!-- ========== LOGO PREVIEW ========== -->
    <?php
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    if ($mainLogo || $rightLogo):
    ?>
    <div class="settings-preview-card no-print">
        <div class="d-flex align-items-center justify-content-between flex-wrap">
            <div>
                <strong><i class="fas fa-image"></i> Logo:</strong>
                <?php if ($mainLogo): ?>
                    <img src="<?= $mainLogo['base64'] ?>" class="logo-preview ms-1" alt="Logo">
                <?php endif; ?>
                <?php if ($rightLogo): ?>
                    <span class="ms-2"><strong>Right:</strong></span>
                    <img src="<?= $rightLogo['base64'] ?>" class="logo-preview ms-1" alt="Right Logo">
                <?php endif; ?>
            </div>
            <span class="text-muted" style="font-size:0.6rem;">
                Position: <?= ucfirst($reportLogoPosition) ?> | 
                Font: <?= $reportFontSize ?>px | 
                Watermark: <?= $reportWatermarkEnabled ? 'On' : 'Off' ?>
            </span>
        </div>
    </div>
    <?php endif; ?>

    <!-- ========== STATISTICS CARDS - UNIFIED GRADIENT ========== -->
    <div class="row g-3 mb-4" id="statsContainer">
        <div class="col-lg-3 col-md-6 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-database"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= number_format($totalRecords) ?></div>
                    <div class="stat-label">Total Records</div>
                    <div class="stat-sub"><i class="fas fa-<?= $reportType == 'overdue' ? 'exclamation-triangle' : 'file-alt' ?>"></i> <?= ucfirst($reportType) ?></div>
                </div>
            </div>
        </div>
        <?php if ($reportType == 'members'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-book-open"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= array_sum(array_column($displayData, 'active_books')) ?></div>
                        <div class="stat-label">Active Books</div>
                        <div class="stat-sub"><i class="fas fa-arrow-right"></i> Currently issued</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-user-check"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count(array_filter($displayData, fn($m) => $m['status'] === 'active')) ?></div>
                        <div class="stat-label">Active Members</div>
                        <div class="stat-sub"><i class="fas fa-users"></i> Active status</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-coins"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= formatCurrency(array_sum(array_column($displayData, 'total_fines'))) ?></div>
                        <div class="stat-label">Total Fines</div>
                        <div class="stat-sub"><i class="fas fa-money-bill"></i> Outstanding</div>
                    </div>
                </div>
            </div>
        <?php elseif ($reportType == 'books'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-copy"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= array_sum(array_column($displayData, 'quantity')) ?></div>
                        <div class="stat-label">Total Copies</div>
                        <div class="stat-sub"><i class="fas fa-layer-group"></i> All copies</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= array_sum(array_column($displayData, 'available')) ?></div>
                        <div class="stat-label">Available</div>
                        <div class="stat-sub"><i class="fas fa-arrow-up"></i> In stock</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-tag"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count(array_unique(array_column($displayData, 'category'))) ?></div>
                        <div class="stat-label">Categories</div>
                        <div class="stat-sub"><i class="fas fa-list"></i> Distinct categories</div>
                    </div>
                </div>
            </div>
        <?php elseif ($reportType == 'circulation'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-exchange-alt"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $summary['total_transactions'] ?? 0 ?></div>
                        <div class="stat-label">Transactions</div>
                        <div class="stat-sub"><i class="fas fa-arrow-right"></i> Total issues</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-book"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $summary['active_loans'] ?? 0 ?></div>
                        <div class="stat-label">Active Loans</div>
                        <div class="stat-sub"><i class="fas fa-clock"></i> Currently issued</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-coins"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= formatCurrency($summary['total_fines'] ?? 0) ?></div>
                        <div class="stat-label">Total Fines</div>
                        <div class="stat-sub"><i class="fas fa-money-bill"></i> From transactions</div>
                    </div>
                </div>
            </div>
        <?php elseif ($reportType == 'overdue'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-clock"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count($displayData) ?></div>
                        <div class="stat-label">Overdue Books</div>
                        <div class="stat-sub"><i class="fas fa-exclamation-triangle"></i> Late returns</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-coins"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= formatCurrency($overdueTotalFine ?? 0) ?></div>
                        <div class="stat-label">Total Fine</div>
                        <div class="stat-sub"><i class="fas fa-money-bill"></i> Outstanding fines</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-calendar-alt"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $overdueMinDays ? $overdueMinDays . '+' : 'All' ?></div>
                        <div class="stat-label">Days Overdue</div>
                        <div class="stat-sub"><i class="fas fa-hourglass"></i> Min days filter</div>
                    </div>
                </div>
            </div>
        <?php elseif ($reportType == 'computer'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-desktop"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $totalSessions ?? 0 ?></div>
                        <div class="stat-label">Sessions</div>
                        <div class="stat-sub"><i class="fas fa-user-clock"></i> Total usage</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-hourglass-half"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $totalMinutes ?? 0 ?></div>
                        <div class="stat-label">Minutes</div>
                        <div class="stat-sub"><i class="fas fa-clock"></i> Total duration</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-users"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count(array_unique(array_column($displayData, 'member_id'))) ?></div>
                        <div class="stat-label">Unique Users</div>
                        <div class="stat-sub"><i class="fas fa-user"></i> Distinct members</div>
                    </div>
                </div>
            </div>
        <?php elseif ($reportType == 'fines'): ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-hand-holding-usd"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= formatCurrency($totalFines ?? 0) ?></div>
                        <div class="stat-label">Collected</div>
                        <div class="stat-sub"><i class="fas fa-coins"></i> Total collected</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-receipt"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count($displayData) ?></div>
                        <div class="stat-label">Payments</div>
                        <div class="stat-sub"><i class="fas fa-file-invoice"></i> Total transactions</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-credit-card"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count(array_unique(array_column($displayData, 'payment_method'))) ?></div>
                        <div class="stat-label">Payment Methods</div>
                        <div class="stat-sub"><i class="fas fa-wallet"></i> Methods used</div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-info-circle"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= number_format($totalRecords) ?></div>
                        <div class="stat-label">Records</div>
                        <div class="stat-sub"><i class="fas fa-database"></i> Total found</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-filter"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= count(array_filter($_GET)) ?></div>
                        <div class="stat-label">Active Filters</div>
                        <div class="stat-sub"><i class="fas fa-sliders-h"></i> Applied filters</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-6">
                <div class="stat-card">
                    <div class="stat-icon-wrapper"><i class="fas fa-file-alt"></i></div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $limit ?></div>
                        <div class="stat-label">Per Page</div>
                        <div class="stat-sub"><i class="fas fa-list"></i> Records per page</div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- ========== COMPACT MODULE CARDS - UNIFIED GRADIENT ========== -->
    <div class="module-grid no-print">
        <!-- Members -->
        <div class="module-card <?= $reportType == 'members' ? 'active' : '' ?>" onclick="location.href='?type=members'" title="View member details">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-users"></i></span>
                <div class="module-title">Members</div>
                <div class="module-subtitle">View details</div>
                <span class="module-count"><?= number_format(getMembersCount($db, 'all', '', '', 'all')) ?></span>
            </div>
        </div>
        
        <!-- Books -->
        <div class="module-card <?= $reportType == 'books' ? 'active' : '' ?>" onclick="location.href='?type=books'" title="Catalog & inventory">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-book"></i></span>
                <div class="module-title">Books</div>
                <div class="module-subtitle">Catalog</div>
                <span class="module-count"><?= number_format(getBooksCount($db, 'all', 'all', '')) ?></span>
            </div>
        </div>
        
        <!-- Books & eBooks -->
        <div class="module-card" onclick="location.href='books_titles_summary.php'" title="Unified summary view">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-book-open"></i></span>
                <div class="module-title">Books &amp; eBooks</div>
                <div class="module-subtitle">Full view</div>
            </div>
        </div>
        
        <!-- Circulation -->
        <div class="module-card <?= $reportType == 'circulation' ? 'active' : '' ?>" onclick="location.href='?type=circulation'" title="Issue/return transactions">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-exchange-alt"></i></span>
                <div class="module-title">Circulation</div>
                <div class="module-subtitle">Transactions</div>
            </div>
        </div>
        
        <!-- Entry/Exit -->
        <div class="module-card <?= $reportType == 'entry_exit' ? 'active' : '' ?>" onclick="location.href='?type=entry_exit'" title="Visitor logs & tracking">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-door-open"></i></span>
                <div class="module-title">Entry/Exit</div>
                <div class="module-subtitle">Visitors</div>
            </div>
        </div>
        
        <!-- Overdues -->
        <div class="module-card <?= $reportType == 'overdue' ? 'active' : '' ?>" onclick="location.href='?type=overdue'" title="Overdue books & fines">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-clock"></i></span>
                <div class="module-title">Overdues</div>
                <div class="module-subtitle">Fines</div>
                <span class="module-count"><?= number_format(getOverdueCount($db, '', '', '', '', '')) ?></span>
            </div>
        </div>
        
        <!-- Computer -->
        <div class="module-card <?= $reportType == 'computer' ? 'active' : '' ?>" onclick="location.href='?type=computer'" title="Computer usage logs">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-desktop"></i></span>
                <div class="module-title">Computer</div>
                <div class="module-subtitle">Usage logs</div>
            </div>
        </div>
        
        <!-- Fine Payments -->
        <div class="module-card <?= $reportType == 'fines' ? 'active' : '' ?>" onclick="location.href='?type=fines'" title="Payment collections">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-hand-holding-usd"></i></span>
                <div class="module-title">Fine Payments</div>
                <div class="module-subtitle">Collections</div>
            </div>
        </div>
        
        <!-- Advanced Reports -->
        <div class="module-card" onclick="location.href='advanced_reports.php'" title="17+ specialized reports">
            <div class="card-body">
                <span class="module-icon"><i class="fas fa-chart-pie"></i></span>
                <div class="module-title">Advanced</div>
                <div class="module-subtitle">17+ reports</div>
            </div>
        </div>
    </div>

    <!-- ========== FILTER SECTION ========== -->
    <div class="filter-section no-print">
        <form method="get" class="row g-1 align-items-end" id="reportFilterForm">
            <input type="hidden" name="type" value="<?= htmlspecialchars($reportType) ?>">

            <?php if ($reportType == 'circulation' || $reportType == 'entry_exit' || $reportType == 'fines'): ?>
                <div class="col-auto"><div class="filter-label">From</div><input type="date" name="<?= ($reportType=='fines')?'fine_from_date':'from' ?>" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars(($reportType=='fines')?$fineFromDate:$from) ?>"></div>
                <div class="col-auto"><div class="filter-label">To</div><input type="date" name="<?= ($reportType=='fines')?'fine_to_date':'to' ?>" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars(($reportType=='fines')?$fineToDate:$to) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'overdue'): ?>
                <div class="col-auto"><div class="filter-label">From</div><input type="date" name="overdue_from_date" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars($overdueFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To</div><input type="date" name="overdue_to_date" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars($overdueToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Min Days</div><select name="overdue_min_days" class="form-select form-select-sm" style="width:90px;"><option value="">All</option><option value="7" <?= $overdueMinDays == '7' ? 'selected' : '' ?>>7+</option><option value="14" <?= $overdueMinDays == '14' ? 'selected' : '' ?>>14+</option><option value="30" <?= $overdueMinDays == '30' ? 'selected' : '' ?>>30+</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'computer'): ?>
                <div class="col-auto"><div class="filter-label">From</div><input type="date" name="computer_from_date" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars($computerFromDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">To</div><input type="date" name="computer_to_date" class="form-control form-control-sm" style="width:120px;" value="<?= htmlspecialchars($computerToDate) ?>"></div>
                <div class="col-auto"><div class="filter-label">Member</div><input type="text" name="computer_member_search" class="form-control form-control-sm" style="width:130px;" placeholder="Search..." value="<?= htmlspecialchars($computerMemberSearch) ?>"></div>
                <div class="col-auto"><div class="filter-label">Computer</div><select name="computer_id" class="form-select form-select-sm" style="width:120px;"><option value="">All</option><?php foreach ($computers as $comp): ?><option value="<?= $comp['id'] ?>" <?= $computerId == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'members' || $reportType == 'circulation' || $reportType == 'overdue'): ?>
                <?php if ($reportType == 'members' || $reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Category</div>
                    <select name="<?= $reportType == 'members' ? 'category' : 'member_category' ?>" class="form-select form-select-sm" style="width:120px;">
                        <option value="all">All</option>
                        <?php foreach ($memberCategories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>" <?= ($reportType == 'members' ? $category : $memberCategoryFilter) == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Book Cat</div><select name="book_category" class="form-select form-select-sm" style="width:110px;"><option value="all">All</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $bookCategoryFilter == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
                <div class="col-auto"><div class="filter-label">Class</div><input type="text" name="filter_class" class="form-control form-control-sm" style="width:100px;" placeholder="Class" value="<?= htmlspecialchars($filterClass) ?>"></div>
                <div class="col-auto"><div class="filter-label">Div</div><input type="text" name="filter_division" class="form-control form-control-sm" style="width:100px;" placeholder="Division" value="<?= htmlspecialchars($filterDivision) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'members'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm" style="width:100px;"><option value="all">All</option><option value="active" <?= $status == 'active' ? 'selected' : '' ?>>Active</option><option value="inactive" <?= $status == 'inactive' ? 'selected' : '' ?>>Inactive</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'books'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm" style="width:120px;"><option value="all">All</option><?php foreach ($bookCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm" style="width:100px;"><option value="all">All</option><option value="available" <?= $status == 'available' ? 'selected' : '' ?>>Available</option><option value="unavailable" <?= $status == 'unavailable' ? 'selected' : '' ?>>Unavailable</option><option value="lowstock" <?= $status == 'lowstock' ? 'selected' : '' ?>>Low Stock</option></select></div>
                <div class="col-auto"><div class="filter-label">Location</div><input type="text" name="location" class="form-control form-control-sm" style="width:120px;" placeholder="Location" value="<?= htmlspecialchars($location) ?>"></div>
            <?php endif; ?>

            <?php if ($reportType == 'circulation'): ?>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm" style="width:100px;"><option value="all">All</option><option value="issued" <?= $status == 'issued' ? 'selected' : '' ?>>Issued</option><option value="returned" <?= $status == 'returned' ? 'selected' : '' ?>>Returned</option><option value="overdue" <?= $status == 'overdue' ? 'selected' : '' ?>>Overdue</option></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'entry_exit'): ?>
                <div class="col-auto"><div class="filter-label">Category</div><select name="category" class="form-select form-select-sm" style="width:120px;"><option value="all">All</option><?php foreach ($memberCategories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>" <?= $category == $cat ? 'selected' : '' ?>><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>

            <?php if ($reportType == 'fines'): ?>
                <div class="col-auto"><div class="filter-label">Method</div><select name="payment_method" class="form-select form-select-sm" style="width:100px;"><option value="all">All</option><?php foreach ($paymentMethods as $m): ?><option value="<?= $m ?>" <?= $paymentMethod == $m ? 'selected' : '' ?>><?= ucfirst($m) ?></option><?php endforeach; ?></select></div>
                <div class="col-auto"><div class="filter-label">Status</div><select name="status" class="form-select form-select-sm" style="width:100px;"><option value="all">All</option><option value="paid" <?= $status == 'paid' ? 'selected' : '' ?>>Paid</option><option value="pending" <?= $status == 'pending' ? 'selected' : '' ?>>Pending</option><option value="refunded" <?= $status == 'refunded' ? 'selected' : '' ?>>Refunded</option></select></div>
            <?php endif; ?>

            <div class="col-auto"><div class="filter-label">Size</div><select name="paper_size" class="form-select form-select-sm" style="width:80px;"><option value="A4" <?= $paperSize == 'A4' ? 'selected' : '' ?>>A4</option><option value="Letter" <?= $paperSize == 'Letter' ? 'selected' : '' ?>>Letter</option><option value="Legal" <?= $paperSize == 'Legal' ? 'selected' : '' ?>>Legal</option></select></div>
            <div class="col-auto"><div class="filter-label">Orient</div><select name="orientation" class="form-select form-select-sm" style="width:90px;"><option value="landscape" <?= $orientation == 'landscape' ? 'selected' : '' ?>>Landscape</option><option value="portrait" <?= $orientation == 'portrait' ? 'selected' : '' ?>>Portrait</option></select></div>
            <div class="col-auto"><div class="filter-label">Limit</div><select name="limit" class="form-select form-select-sm" style="width:80px;"><option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option><option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option><option value="200" <?= $limit == 200 ? 'selected' : '' ?>>200</option><option value="500" <?= $limit == 500 ? 'selected' : '' ?>>500</option></select></div>

            <div class="col-auto">
                <div class="d-flex flex-wrap gap-1">
                    <button type="submit" class="btn btn-primary btn-sm-custom"><i class="fas fa-filter"></i></button>
                    <a href="?type=<?= htmlspecialchars($reportType) ?>" class="btn btn-secondary btn-sm-custom"><i class="fas fa-undo"></i></a>
                    <button type="button" class="pdf-download-btn" onclick="downloadPDFReport()"><i class="fas fa-file-pdf"></i> PDF</button>
                    <div class="dropdown d-inline-block">
                        <button class="btn btn-success btn-sm-custom dropdown-toggle" type="button" onclick="toggleExportDropdown(event)"><i class="fas fa-download"></i></button>
                        <ul class="dropdown-menu dropdown-menu-end" id="exportDropdownMenu" style="font-size:0.7rem;">
                            <li><a class="dropdown-item" href="#" onclick="exportReport('excel')"><i class="fas fa-file-excel text-success"></i> Excel</a></li>
                            <li><a class="dropdown-item" href="#" onclick="exportReport('pdf')"><i class="fas fa-file-pdf text-danger"></i> PDF</a></li>
                            <li><a class="dropdown-item" href="#" onclick="exportReport('csv')"><i class="fas fa-file-csv text-primary"></i> CSV</a></li>
                        </ul>
                    </div>
                    <button type="button" onclick="window.print()" class="btn btn-secondary btn-sm-custom"><i class="fas fa-print"></i></button>
                </div>
            </div>
        </form>
    </div>

    <!-- ========== REPORT CONTENT ========== -->
    <?php if (empty($displayData)): ?>
        <div class="alert alert-info text-center py-4" style="border-radius: var(--radius-card);">
            <i class="fas fa-info-circle fa-3x mb-2 d-block text-primary"></i>
            <h6 style="font-weight:600;">No records found</h6>
            <p class="mb-0 text-muted">Try adjusting your filters or date range.</p>
        </div>
    <?php else: ?>
    <div class="report-card card">
        <div class="card-header">
            <span><i class="fas fa-<?= $reportType == 'overdue' ? 'exclamation-triangle' : 'chart-line' ?>"></i> <?= ucfirst(str_replace('_', ' ', $reportType)) ?> Report</span>
            <span class="badge"><?= number_format($totalRecords) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <?php if($reportType == 'members'): ?>
                                <th>#</th><th>Adm No</th><th>Name</th><th>Category</th><th>Class</th><th>Div</th><th>Email</th><th>Phone</th><th>Active</th><th>Issued</th><th>Fines</th><th>Status</th>
                            <?php elseif($reportType == 'books'): ?>
                                <th>#</th><th>Barcode</th><th>Title</th><th>Author</th><th>Publisher</th><th>Category</th><th>Qty</th><th>Avail</th><th>Price</th><th>Location</th>
                            <?php elseif($reportType == 'circulation'): ?>
                                <th>#</th><th>Adm No</th><th>Member</th><th>Book</th><th>Author</th><th>Issue</th><th>Return</th><th>Due</th><th>Fine</th><th>Status</th>
                            <?php elseif($reportType == 'entry_exit'): ?>
                                <th>#</th><th>Adm No</th><th>Member</th><th>Category</th><th>Date</th><th>Entry</th><th>Exit</th><th>Purpose</th>
                            <?php elseif($reportType == 'overdue'): ?>
                                <th>#</th><th>Adm No</th><th>Member</th><th>Class</th><th>Book</th><th>Author</th><th>Due Date</th><th>Days</th><th>Fine</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn = ($page - 1) * $limit + 1; foreach($displayData as $row): ?>
                        <tr <?= ($reportType == 'overdue') ? 'class="overdue-row"' : '' ?>>
                            <td class="text-center"><?= $sn++ ?></td>
                            <?php if($reportType == 'members'): ?>
                                <td><?= htmlspecialchars($row['admno'] ?? '') ?></td>
                                <td><strong><?= htmlspecialchars($row['name'] ?? '') ?></strong></td>
                                <td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['class'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['division'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['email'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['phone'] ?? '-') ?></td>
                                <td class="text-center"><?= $row['active_books'] ?? 0 ?></td>
                                <td class="text-center"><?= $row['total_issued'] ?? 0 ?></td>
                                <td class="text-end"><?= formatCurrency($row['total_fines'] ?? 0) ?></td>
                                <td><span class="badge bg-<?= getStatusBadge($row['status'] ?? 'active') ?>"><?= ucfirst($row['status'] ?? 'active') ?></span></td>
                            <?php elseif($reportType == 'books'): ?>
                                <td><code><?= htmlspecialchars($row['barcode'] ?? '') ?></code></td>
                                <td><strong><?= htmlspecialchars($row['title'] ?? '') ?></strong></td>
                                <td><?= htmlspecialchars($row['author'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['publisher'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($row['category'] ?? '-') ?></td>
                                <td class="text-center"><?= $row['quantity'] ?? 0 ?></td>
                                <td><span class="badge bg-<?= ($row['available'] ?? 0) == 0 ? 'danger' : (($row['available'] ?? 0) <= 2 ? 'warning' : 'success') ?>"><?= $row['available'] ?? 0 ?></span></td>
                                <td class="text-end"><?= formatCurrency($row['price'] ?? 0) ?></td>
                                <td><?= htmlspecialchars($row['location'] ?? '-') ?></td>
                            <?php elseif($reportType == 'circulation'): 
                                $statusText = !empty($row['return_date']) ? 'Returned' : (!empty($row['due_date']) && strtotime($row['due_date']) < time() ? 'Overdue' : 'Issued');
                            ?>
                                <td><?= htmlspecialchars($row['admno'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['member_name'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($row['book_title'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($row['author'] ?? '-') ?></td>
                                <td class="text-center"><?= formatDate($row['issue_date'] ?? '') ?></td>
                                <td class="text-center"><?= !empty($row['return_date']) ? formatDate($row['return_date']) : '-' ?></td>
                                <td class="text-center"><?= formatDate($row['due_date'] ?? '') ?></td>
                                <td class="text-end"><?= formatCurrency($row['fine'] ?? 0) ?></td>
                                <td><span class="badge bg-<?= getStatusBadge($statusText) ?>"><?= $statusText ?></span></td>
                            <?php elseif($reportType == 'entry_exit'): ?>
                                <td><?= htmlspecialchars($row['admno'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['member_name'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['member_category'] ?? '-') ?></td>
                                <td class="text-center"><?= formatDate($row['entry_date'] ?? '') ?></td>
                                <td class="text-center"><?= formatTime($row['entry_time'] ?? '') ?></td>
                                <td class="text-center"><?= !empty($row['exit_time']) ? formatTime($row['exit_time']) : '-' ?></td>
                                <td><?= htmlspecialchars($row['purpose'] ?? '-') ?></td>
                            <?php elseif($reportType == 'overdue'): ?>
                                <td><?= htmlspecialchars($row['admno'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['member_name'] ?? '') ?></td>
                                <td><?= htmlspecialchars($row['class']??'-') ?></td>
                                <td><strong><?= htmlspecialchars($row['title']??'N/A') ?></strong></td>
                                <td><?= htmlspecialchars($row['author']??'-') ?></td>
                                <td class="text-center"><?= formatDate($row['due_date'] ?? '') ?></td>
                                <td class="text-center"><strong><?= $row['days_overdue'] ?? 0 ?></strong></td>
                                <td class="text-end text-danger"><?= formatCurrency($row['fine_amount'] ?? 0) ?></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <?php if(!empty($displayData)): ?>
                    <tfoot>
                        <tr>
                            <?php if($reportType == 'books'): 
                                $totalQty = array_sum(array_column($displayData, 'quantity'));
                                $totalAvail = array_sum(array_column($displayData, 'available'));
                                $totalPrice = array_sum(array_column($displayData, 'price'));
                            ?>
                                <td colspan="6" class="text-end">Totals:</td>
                                <td class="text-center"><?= $totalQty ?></td>
                                <td class="text-center"><?= $totalAvail ?></td>
                                <td class="text-end"><?= formatCurrency($totalPrice) ?></td>
                                <td></td>
                            <?php elseif($reportType == 'circulation'): 
                                $totalFine = array_sum(array_column($displayData, 'fine'));
                            ?>
                                <td colspan="8" class="text-end">Total Fine:</td>
                                <td colspan="2" class="text-end"><?= formatCurrency($totalFine) ?></td>
                            <?php elseif($reportType == 'members'): 
                                $totalActive = array_sum(array_column($displayData, 'active_books'));
                                $totalIssued = array_sum(array_column($displayData, 'total_issued'));
                                $totalFines = array_sum(array_column($displayData, 'total_fines'));
                            ?>
                                <td colspan="8" class="text-end">Totals:</td>
                                <td class="text-center"><?= $totalActive ?></td>
                                <td class="text-center"><?= $totalIssued ?></td>
                                <td class="text-end"><?= formatCurrency($totalFines) ?></td>
                                <td class="text-center"><?= count($displayData) ?></td>
                            <?php elseif($reportType == 'overdue'): 
                                $totalFine = array_sum(array_column($displayData, 'fine_amount'));
                            ?>
                                <td colspan="8" class="text-end">Total Fine:</td>
                                <td colspan="2" class="text-end text-danger"><?= formatCurrency($totalFine) ?></td>
                            <?php endif; ?>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ========== PAGINATION ========== -->
    <?php if ($totalRecords > $limit): ?>
    <div class="pagination-wrapper no-print">
        <div>Showing <?= ($page-1)*$limit+1 ?> - <?= min($page*$limit, $totalRecords) ?> of <?= number_format($totalRecords) ?></div>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page-1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Prev</a>
                </li>
                <?php for ($p = max(1, $page-3); $p <= min($totalPages, $page+3); $p++): ?>
                <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                    <a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $p ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>"><?= $p ?></a>
                </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?type=<?= urlencode($reportType) ?>&page=<?= $page+1 ?>&<?= http_build_query(array_filter($_GET, fn($k) => $k != 'page', ARRAY_FILTER_USE_KEY)) ?>">Next</a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <!-- ========== FOOTER ========== -->
    <div class="text-center text-muted small mt-3 no-print" style="font-size:0.65rem; border-top:1px solid #e9ecef; padding-top:8px;">
        <i class="fas fa-info-circle"></i> Generated: <?= date('Y-m-d H:i:s') ?> | &copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof $.fn.select2 !== 'undefined') {
        $('.select2').select2({ theme: 'bootstrap-5', width: '100%', placeholder: 'Select an option' });
    }
});

function downloadPDFReport() {
    var btn = document.querySelector('.pdf-download-btn');
    var originalHtml = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    btn.disabled = true;
    var url = window.location.href.split('?')[0] + '?export=1&format=pdf';
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    fetch(url)
        .then(response => response.blob())
        .then(blob => {
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'report.pdf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        })
        .catch(function(error) {
            console.error('Download failed:', error);
            window.open(url, '_blank');
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        });
}

function toggleExportDropdown(e) {
    e.preventDefault();
    e.stopPropagation();
    var menu = document.getElementById('exportDropdownMenu');
    menu.classList.toggle('show');
}

document.addEventListener('click', function(event) {
    var dropdown = document.querySelector('.dropdown');
    var menu = document.getElementById('exportDropdownMenu');
    if (dropdown && !dropdown.contains(event.target)) {
        menu.classList.remove('show');
    }
});

function exportReport(format) {
    var url = window.location.href.split('?')[0] + '?export=1&format=' + format;
    var params = new URLSearchParams(window.location.search);
    for (var [key, value] of params) {
        if (key !== 'export' && key !== 'format') {
            url += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    window.location.href = url;
}

window.onbeforeprint = function() { console.log('Printing report...'); };
</script>

<?php renderFooter(); ?>
</body>
</html>