<?php
/**
 * Circulation Report – Enhanced Version
 * Fully respects all report settings from settings.php:
 * - Logo, right logo, logo position
 * - Watermark (text & opacity)
 * - Font size & primary colour
 * - Signature (name, title, image)
 * - Filters: From/To, Adm/Mem No, Class/Dept, Div/Course, Status
 * - Export: PDF (with mPDF/DOMPDF), Excel (.xls)
 *
 * @package LibraryERP
 * @author  Sameermon
 * @version 5.1
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

// ==================== DATABASE & SETTINGS ====================
$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT PARAMETERS ====================
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$admno = $_GET['admno'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$type = $_GET['type'] ?? 'all';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// =============================================================================
// HELPER FUNCTIONS (identical to main reports module)
// =============================================================================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $symbol = null, $decimalPlaces = null) {
    $settings = getSettings();
    $currencySymbol = $symbol ?? getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $decimals = $decimalPlaces ?? (int)($settings['currency_decimal_places'] ?? 2);
    return $currencySymbol . ' ' . number_format((float)$amount, $decimals);
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function h($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

// =============================================================================
// LOGO, WATERMARK, SIGNATURE FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else { // text only
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) require_once $autoloadPath;

    $html = addWatermarkToHTML($html);

    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) { error_log("mPDF error: " . $e->getMessage()); }
    }

    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) { error_log("DomPDF error: " . $e->getMessage()); }
    }

    // Ultimate fallback: HTML with print option
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . ($GLOBALS['reportFontSize'] ?? 10) . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// =============================================================================
// DATA QUERY
// =============================================================================

$sql = "SELECT 
            c.id, c.admno, c.barcode, c.issue_date, c.return_date, c.due_date, c.fine,
            m.name as member_name, m.class, m.division,
            b.title, b.author
        FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno
        LEFT JOIN books b ON c.barcode = b.barcode
        WHERE c.issue_date BETWEEN ? AND ?";
$params = [$from, $to];
if (!empty($admno)) { $sql .= " AND c.admno LIKE ?"; $params[] = "%$admno%"; }
if (!empty($class)) { $sql .= " AND m.class LIKE ?"; $params[] = "%$class%"; }
if (!empty($division)) { $sql .= " AND m.division LIKE ?"; $params[] = "%$division%"; }
if ($type === 'issued') { $sql .= " AND c.return_date IS NULL AND c.due_date >= date('now')"; }
elseif ($type === 'overdue') { $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')"; }
elseif ($type === 'returned') { $sql .= " AND c.return_date IS NOT NULL"; }
$sql .= " ORDER BY c.issue_date DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

$totalIssued = count($transactions);
$totalReturned = count(array_filter($transactions, fn($t) => $t['return_date']));
$totalOverdue = count(array_filter($transactions, fn($t) => !$t['return_date'] && strtotime($t['due_date']) < time()));
$totalFine = array_sum(array_column($transactions, 'fine'));

// =============================================================================
// EXPORT HANDLING
// =============================================================================

if ($format === 'excel') {
    $institutionName = getInstitutionName();
    $filters = [
        'Adm/Mem No' => $admno ?: 'All',
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Transaction Type' => $type === 'all' ? 'All' : ucfirst($type)
    ];
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Circulation Report</title>
    <style>
        body{font-family:Arial;margin:20px;font-size:10px;}
        h2,h3,p{text-align:center}
        table{margin:0 auto;border-collapse:collapse;width:100%}
        th,td{border:1px solid #ddd;padding:6px;text-align:left}
        th{background:' . $reportPrimaryColor . ';color:white}
    </style>
    </head><body>';
    $html .= '<center><h2>' . htmlspecialchars($institutionName) . '</h2><h3>Circulation Report</h3>';
    $html .= '<p><b>Period:</b> ' . formatDate($from) . ' to ' . formatDate($to) . '</p>';
    foreach ($filters as $label => $value) {
        $html .= '<p><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . '</p>';
    }
    $html .= '<p><b>Generated:</b> ' . date('Y-m-d H:i:s') . '</p><hr></center>';
    $html .= '<table>';
    $html .= '<thead><tr><th>Sl No</th><th>Issue Date</th><th>Return Date</th><th>Adm/Mem No</th><th>Member Name</th><th>Class/Dept</th><th>Div/Course</th><th>Book Title</th><th>Author</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr></thead><tbody>';
    $sn = 1;
    foreach ($transactions as $t) {
        $status = $t['return_date'] ? 'Returned' : (strtotime($t['due_date']) < time() ? 'Overdue' : 'Issued');
        $html .= '<tr>';
        $html .= '<td>' . $sn++ . '</td>';
        $html .= '<td>' . formatDate($t['issue_date']) . '</td>';
        $html .= '<td>' . ($t['return_date'] ? formatDate($t['return_date']) : '-') . '</td>';
        $html .= '<td>' . h($t['admno']) . '</td>';
        $html .= '<td>' . h($t['member_name'] ?? 'N/A') . '</td>';
        $html .= '<td>' . h($t['class'] ?? '-') . '</td>';
        $html .= '<td>' . h($t['division'] ?? '-') . '</td>';
        $html .= '<td>' . h($t['title'] ?? 'N/A') . '</td>';
        $html .= '<td>' . h($t['author'] ?? '-') . '</td>';
        $html .= '<td>' . h($t['barcode']) . '</td>';
        $html .= '<td>' . formatDate($t['due_date']) . '</td>';
        $html .= '<td>' . formatCurrency($t['fine'] ?? 0) . '</td>';
        $html .= '<td>' . $status . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color:#f0f0f0;font-weight:bold;"><td colspan="11" align="right">Total Fine:</td><td colspan="2">' . formatCurrency($totalFine) . '</td></tr></tfoot>';
    $html .= '</table>';
    $html .= '<p align="center"><strong>Summary:</strong> Total: ' . $totalIssued . ' | Returned: ' . $totalReturned . ' | Overdue: ' . $totalOverdue . ' | Fine: ' . formatCurrency($totalFine) . '</p>';
    $html .= '<p align="center">' . htmlspecialchars($reportFooterText) . '</p>';
    $html .= '</body></html>';
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="circulation_report_' . date('Y-m-d') . '.xls"');
    echo $html;
    exit;
}

if ($format === 'pdf') {
    $institutionName = getInstitutionName();
    $filters = [
        'Adm/Mem No' => $admno ?: 'All',
        'Class/Dept' => $class ?: 'All',
        'Div/Course' => $division ?: 'All',
        'Transaction Type' => $type === 'all' ? 'All' : ucfirst($type)
    ];
    // Build data array with 'Sl No' as first key
    $exportData = [];
    $sn = 1;
    foreach ($transactions as $t) {
        $status = $t['return_date'] ? 'Returned' : (strtotime($t['due_date']) < time() ? 'Overdue' : 'Issued');
        $exportData[] = [
            'Sl No' => $sn++,
            'Issue Date' => formatDate($t['issue_date']),
            'Return Date' => $t['return_date'] ? formatDate($t['return_date']) : '-',
            'Adm No' => $t['admno'],
            'Member' => $t['member_name'] ?? 'N/A',
            'Class/Dept' => $t['class'] ?? '-',
            'Div/Course' => $t['division'] ?? '-',
            'Book Title' => $t['title'] ?? 'N/A',
            'Author' => $t['author'] ?? '-',
            'Barcode' => $t['barcode'],
            'Due Date' => formatDate($t['due_date']),
            'Fine' => formatCurrency($t['fine'] ?? 0),
            'Status' => $status
        ];
    }
    $headers = ['Sl No', 'Issue Date', 'Return Date', 'Adm No', 'Member', 'Class/Dept', 'Div/Course', 'Book Title', 'Author', 'Barcode', 'Due Date', 'Fine', 'Status'];
    $title = 'Circulation Report';

    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
        .report-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px; }
        .report-title { font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . '; }
        .report-subtitle { font-size: 16px; font-weight: bold; margin: 8px 0; }
        .report-meta { font-size: 10px; margin: 3px 0; color: #555; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-danger { color: #dc3545; }
        .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
        .logo-img { height: 50px; width: auto; object-fit: contain; margin-bottom: 8px; }
        .table-footer { background-color: #f0f0f0; font-weight: bold; }
    </style>
    </head><body>';

    // Header with logo
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html .= '<div class="report-header">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '<div>' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" class="logo-img">' : '') . '</div>';
        $html .= '</div>';
    } else {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" class="logo-img"><br>';
    }
    $html .= '<div class="report-title">' . htmlspecialchars($institutionName) . '</div>';
    $html .= '<div class="report-subtitle">' . htmlspecialchars($title) . '</div>';
    $html .= '<div class="report-meta"><strong>Period:</strong> ' . formatDate($from) . ' to ' . formatDate($to) . '</div>';
    foreach ($filters as $label => $value) {
        $html .= '<div class="report-meta"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
    }
    $html .= '<div class="report-meta"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';

    // Table
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';

    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . number_format($value, 2) . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }

    $html .= '</tbody>';
    $html .= '<tfoot><tr class="table-footer">';
    $html .= '<td colspan="11" class="text-right">Total Fine:</td>';
    $html .= '<td colspan="2" class="text-right">' . formatCurrency($totalFine) . '</td>';
    $html .= '</tr></tfoot></table>';

    // Summary and footer
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total: ' . $totalIssued . ' | Returned: ' . $totalReturned . ' | Overdue: ' . $totalOverdue . ' | Fine: ' . formatCurrency($totalFine) . '
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';

    exportToPDF($html, 'circulation_report_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
    exit;
}

// =============================================================================
// ON‑SCREEN DISPLAY
// =============================================================================

// Logo preview for filter bar
$logoPreview = '';
$mainLogo = getReportLogo();
if ($mainLogo) {
    $logoPreview = '<img src="' . $mainLogo['base64'] . '" class="filter-bar-logo" alt="Logo">';
} else {
    $logoPreview = '<i class="fas fa-university filter-bar-icon"></i>';
}

renderHeader('Circulation Report');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Circulation Report - <?= h($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .container { max-width: 1400px; margin-top: 20px; }
        .filter-bar-logo { height: 40px; width: auto; max-width: 120px; object-fit: contain; }
        .filter-bar-icon { font-size: 32px; color: <?= $reportPrimaryColor ?>; }
        .overdue-row { background-color: #f8d7da; }
        .settings-info {
            background: linear-gradient(135deg, <?= $reportPrimaryColor ?> 0%, <?= $reportPrimaryColor ?>cc 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .pdf-download-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 14px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .pdf-download-btn:hover {
            background: #c82333;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
        }
        .pdf-download-btn .badge {
            background: rgba(255,255,255,0.3);
            color: white;
            font-size: 10px;
            padding: 2px 8px;
            border-radius: 12px;
        }
        @media (max-width: 768px) {
            .filter-bar-logo { height: 30px; }
            .filter-bar-icon { font-size: 24px; }
            .settings-info { font-size: 0.8rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Settings Preview -->
        <div class="settings-info no-print">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <i class="fas fa-sliders-h"></i> <strong>Report Settings:</strong>
                    Font: <?= $reportFontSize ?>px | Logo: <?= ucfirst($reportLogoPosition) ?> |
                    Watermark: <?= $reportWatermarkEnabled ? 'On' : 'Off' ?> | Signature: <?= $reportSignatureEnabled ? 'On' : 'Off' ?>
                </div>
                <div class="col-md-4 text-end">
                    <a href="../settings.php#report" class="btn btn-sm btn-light"><i class="fas fa-cog"></i> Configure</a>
                </div>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold py-2"><i class="fas fa-exchange-alt"></i> Circulation Report</div>
            <div class="card-body">

                <!-- Filter Form -->
                <form method="get" class="mb-4 no-print">
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <div class="flex-shrink-0"><?= $logoPreview ?></div>

                        <div style="min-width:110px;"><label class="small mb-0">From</label><input type="date" name="from" class="form-control form-control-sm" value="<?= h($from) ?>"></div>
                        <div style="min-width:110px;"><label class="small mb-0">To</label><input type="date" name="to" class="form-control form-control-sm" value="<?= h($to) ?>"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Adm/Mem No</label><input type="text" name="admno" class="form-control form-control-sm" value="<?= h($admno) ?>" placeholder="Adm/Mem No"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Class/Dept</label><input type="text" name="class" class="form-control form-control-sm" value="<?= h($class) ?>" placeholder="Class/Dept"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Div/Course</label><input type="text" name="division" class="form-control form-control-sm" value="<?= h($division) ?>" placeholder="Div/Course"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Status</label><select name="type" class="form-select form-select-sm">
                            <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>All</option>
                            <option value="issued" <?= $type === 'issued' ? 'selected' : '' ?>>Issued (Active)</option>
                            <option value="overdue" <?= $type === 'overdue' ? 'selected' : '' ?>>Overdue</option>
                            <option value="returned" <?= $type === 'returned' ? 'selected' : '' ?>>Returned</option>
                        </select></div>

                        <div style="min-width:110px;"><label class="small mb-0">Paper Size</label><select name="paper_size" class="form-select form-select-sm">
                            <option value="A4" <?= $paperSize=='A4'?'selected':''?>>A4</option>
                            <option value="Letter" <?= $paperSize=='Letter'?'selected':''?>>Letter</option>
                            <option value="Legal" <?= $paperSize=='Legal'?'selected':''?>>Legal</option>
                            <option value="A3" <?= $paperSize=='A3'?'selected':''?>>A3</option>
                        </select></div>
                        <div style="min-width:110px;"><label class="small mb-0">Orientation</label><select name="orientation" class="form-select form-select-sm">
                            <option value="landscape" <?= $orientation=='landscape'?'selected':''?>>Landscape</option>
                            <option value="portrait" <?= $orientation=='portrait'?'selected':''?>>Portrait</option>
                        </select></div>

                        <div><button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button></div>
                        <div><a href="?format=excel&from=<?= urlencode($from) ?>&to=<?= urlencode($to) ?>&admno=<?= urlencode($admno) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&type=<?= $type ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-success btn-sm"><i class="fas fa-file-excel"></i> Excel</a></div>
                        <div>
                            <button type="button" class="pdf-download-btn" onclick="downloadPDFReport()">
                                <i class="fas fa-file-pdf"></i> Download PDF <span class="badge">PDF</span>
                            </button>
                        </div>
                        <div><button type="button" onclick="window.print()" class="btn btn-secondary btn-sm"><i class="fas fa-print"></i> Print</button></div>
                        <div class="flex-shrink-0"><i class="fas fa-book-open filter-bar-icon"></i></div>
                    </div>
                </form>

                <!-- Report Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm">
                        <thead class="table-dark">
                            <tr><th>Sl No</th><th>Issue Date</th><th>Return Date</th><th>Adm/Mem No</th><th>Member Name</th><th>Class/Dept</th><th>Div/Course</th><th>Book Title</th><th>Author</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php $sn = 1; foreach ($transactions as $t):
                                $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
                            ?>
                            <tr class="<?= $isOverdue ? 'overdue-row' : '' ?>">
                                <td><?= $sn++ ?></td>
                                <td><?= formatDate($t['issue_date']) ?></td>
                                <td><?= $t['return_date'] ? formatDate($t['return_date']) : '-' ?></td>
                                <td><?= h($t['admno']) ?></td>
                                <td><?= h($t['member_name'] ?? 'N/A') ?></td>
                                <td><?= h($t['class'] ?? '-') ?></td>
                                <td><?= h($t['division'] ?? '-') ?></td>
                                <td><?= h($t['title'] ?? 'N/A') ?></td>
                                <td><?= h($t['author'] ?? '-') ?></td>
                                <td><?= h($t['barcode']) ?></td>
                                <td><?= formatDate($t['due_date']) ?></td>
                                <td><?= formatCurrency($t['fine'] ?? 0) ?></td>
                                <td><?= $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($transactions)): ?>
                            <tr><td colspan="13" class="text-center">No transactions found</td></tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot class="table-light"><tr class="fw-bold"><td colspan="11" class="text-end">Total Fine:</td><td colspan="2"><?= formatCurrency($totalFine) ?></td></tr></tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    /**
     * Download PDF Report – uses fetch to get the PDF directly
     */
    function downloadPDFReport() {
        var btn = document.querySelector('.pdf-download-btn');
        var originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
        btn.disabled = true;

        // Build URL with all current parameters
        var url = window.location.href.split('?')[0] + '?format=pdf';
        var params = new URLSearchParams(window.location.search);
        for (var [key, value] of params) {
            if (key !== 'format') {
                url += '&' + key + '=' + encodeURIComponent(value);
            }
        }

        fetch(url)
            .then(response => response.blob())
            .then(blob => {
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = 'circulation_report.pdf';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(link.href);
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            })
            .catch(function(error) {
                console.error('Download failed:', error);
                // Fallback: open in new tab
                window.open(url, '_blank');
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            });
    }
    </script>
</body>
</html>
<?php renderFooter(); ?>