<?php
/**
 * Entry/Exit Report
 * Version: 4.3 - Added logo, watermark, signature, fixed PDF duplicate Sl No
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$admno = $_GET['admno'] ?? '';
$category = $_GET['category'] ?? 'all';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = $settings['report_font_size'] ?? 10;
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
$reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== CONSTANTS ====================
define('BASE_PATH', dirname(__DIR__));

// ==================== LOGO, WATERMARK, SIGNATURE FUNCTIONS ====================

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;
    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $settings = getSettings();
    $reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
    $reportLogoPosition = $settings['report_logo_position'] ?? 'left';
    $institutionName = getInstitutionName();
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';
    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div><div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div></div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }
    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    $settings = getSettings();
    $reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
    $reportSignatureEnabled = $settings['report_signature_enabled'] ?? 0;
    $reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
    $reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    $settings = getSettings();
    $reportWatermarkEnabled = $settings['report_watermark_enabled'] ?? 1;
    $reportWatermarkText = $settings['report_watermark_text'] ?? '';
    $reportWatermarkOpacity = $settings['report_watermark_opacity'] ?? 10;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $watermarkStyle = '
    <style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $watermarkStyle . '</head>', $html);
    } else {
        $html = $watermarkStyle . $html;
    }
    return $html;
}

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    $autoloadPath = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoloadPath)) {
        require_once $autoloadPath;
    }
    $html = addWatermarkToHTML($html);
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $GLOBALS['reportFontSize'] ?? 10,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15
            ]);
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->WriteHTML($html);
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            $mpdf->Output($filename, 'D');
            exit;
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            $output = $dompdf->output();
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            echo $output;
            exit;
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>body{font-family:Arial;margin:20px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #000;padding:4px}th{background:#1e3c72;color:white}</style>';
    echo '</head><body>';
    echo '<div style="text-align:center;margin:20px 0;"><button onclick="window.print()">Print / Save as PDF</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

// ==================== BUILD QUERY ====================

$sql = "SELECT e.* FROM entry_exit e WHERE e.entry_date BETWEEN ? AND ?";
$params = [$from, $to];
if (!empty($admno)) { $sql .= " AND e.admno LIKE ?"; $params[] = "%$admno%"; }
if ($category !== 'all') { $sql .= " AND e.member_category = ?"; $params[] = $category; }
$sql .= " ORDER BY e.entry_date DESC, e.entry_time DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$totalEntries = count($logs);
$totalExits = count(array_filter($logs, fn($l) => $l['exit_time']));
$totalInside = count(array_filter($logs, fn($l) => !$l['exit_time']));
$categoryStats = [];
foreach ($logs as $log) { $cat = $log['member_category'] ?? 'Unknown'; $categoryStats[$cat] = ($categoryStats[$cat] ?? 0) + 1; }

// ==================== EXPORT HANDLING ====================

if ($format === 'excel') {
    $institutionName = getInstitutionName();
    $filters = ['Adm/Mem No' => $admno ?: 'All', 'Category' => $category === 'all' ? 'All' : $category];
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Entry/Exit Report</title>
    <style>body{font-family:Arial;margin:20px}h2,h3,p{text-align:center}table{margin:0 auto;border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px;text-align:left}th{background:#1e3c72;color:white}</style>
    </head><body>';
    $html .= '<center><h2>' . htmlspecialchars($institutionName) . '</h2><h3>Entry/Exit Report</h3>';
    $html .= '<p><b>Period:</b> ' . formatDate($from) . ' to ' . formatDate($to) . '</p>';
    foreach ($filters as $label => $value) {
        $html .= '<p><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . '</p>';
    }
    $html .= '<p><b>Generated:</b> ' . date('Y-m-d H:i:s') . '</p><hr></center>';
    $html .= '<table>';
    $html .= '<thead><tr><th>Sl No</th><th>Adm/Mem No</th><th>Member Name</th><th>Entry Date</th><th>Entry Time</th><th>Exit Time</th><th>Purpose</th><th>Duration (Hrs)</th></tr></thead><tbody>';
    $sn = 1;
    foreach ($logs as $log) {
        $duration = '';
        if ($log['exit_time']) {
            $entryTime = strtotime($log['entry_date'] . ' ' . $log['entry_time']);
            $exitTime = strtotime($log['entry_date'] . ' ' . $log['exit_time']);
            $diffSeconds = $exitTime - $entryTime;
            $duration = round($diffSeconds / 3600, 2) . ' hrs';
        } else {
            $duration = 'Still inside';
        }
        $html .= '<tr>';
        $html .= '<td>' . $sn++ . '</td>';
        $html .= '<td>' . h($log['admno']) . '</td>';
        $html .= '<td>' . h($log['member_name']) . '</td>';
        $html .= '<td>' . formatDate($log['entry_date']) . '</td>';
        $html .= '<td>' . formatTime($log['entry_time']) . '</td>';
        $html .= '<td>' . ($log['exit_time'] ? formatTime($log['exit_time']) : '-') . '</td>';
        $html .= '<td>' . h($log['purpose'] ?? '-') . '</td>';
        $html .= '<td>' . $duration . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color:#f0f0f0;font-weight:bold;"><td colspan="7" align="right">Totals:</td><td colspan="1">Entries: ' . $totalEntries . ' | Exits: ' . $totalExits . ' | Inside: ' . $totalInside . '</td></tr></tfoot>';
    $html .= '</table>';
    $html .= '<p align="center"><strong>Summary:</strong> Total Entries: ' . $totalEntries . ' | Exits: ' . $totalExits . ' | Still Inside: ' . $totalInside . '</p>';
    $html .= '<p align="center">This is a system generated report.</p></body></html>';
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="Entry_Exit_Report_' . date('Y-m-d') . '.xls"');
    echo $html;
    exit;
}

if ($format === 'pdf') {
    $institutionName = getInstitutionName();
    $filters = ['Adm/Mem No' => $admno ?: 'All', 'Category' => $category === 'all' ? 'All' : $category];
    $exportData = [];
    $sn = 1;
    foreach ($logs as $log) {
        $duration = '';
        if ($log['exit_time']) {
            $entryTime = strtotime($log['entry_date'] . ' ' . $log['entry_time']);
            $exitTime = strtotime($log['entry_date'] . ' ' . $log['exit_time']);
            $diffSeconds = $exitTime - $entryTime;
            $duration = round($diffSeconds / 3600, 2) . ' hrs';
        } else {
            $duration = 'Still inside';
        }
        $exportData[] = [
            'Sl No' => $sn++,
            'Adm/Mem No' => $log['admno'],
            'Member Name' => $log['member_name'],
            'Entry Date' => formatDate($log['entry_date']),
            'Entry Time' => formatTime($log['entry_time']),
            'Exit Time' => $log['exit_time'] ? formatTime($log['exit_time']) : '-',
            'Purpose' => $log['purpose'] ?? '-',
            'Duration' => $duration
        ];
    }
    $headers = ['Sl No', 'Adm/Mem No', 'Member Name', 'Entry Date', 'Entry Time', 'Exit Time', 'Purpose', 'Duration'];
    $title = 'Entry/Exit Report';
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
        th { background-color: ' . $reportPrimaryColor . '; color: white; font-weight: bold; text-align: center; }
        td { text-align: left; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
    </style>
    </head><body>';
    $html .= getReportHeaderHTML($title, $from, $to, $filters);
    $html .= '<table><thead><tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . htmlspecialchars($header) . '</th>';
    }
    $html .= '</tr></thead><tbody>';
    foreach ($exportData as $row) {
        $html .= '<tr>';
        $first = true;
        foreach ($row as $key => $value) {
            if ($first) { $first = false; continue; }
            if (is_numeric($value) && strpos((string)$value, '.') !== false) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (is_numeric($value)) {
                $html .= '<td class="text-right">' . $value . '</td>';
            } elseif (empty($value) || $value === '-') {
                $html .= '<td class="text-center">-</td>';
            } else {
                $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
    $html .= '<td colspan="7" class="text-right">Entries: ' . $totalEntries . ' | Exits: ' . $totalExits . ' | Inside: ' . $totalInside . '</td>';
    $html .= '<td class="text-center"></td>';
    $html .= '</tr></tfoot></table>';
    $html .= '<div style="margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid ' . $reportPrimaryColor . '; font-size: 10px;">
        <strong>Summary:</strong> Total Entries: ' . $totalEntries . ' | Exits: ' . $totalExits . ' | Still Inside: ' . $totalInside . '
    </div>';
    $html .= getReportFooterHTML();
    $html .= '</body></html>';
    exportToPDF($html, 'Entry_Exit_Report_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
    exit;
}

// ==================== ON‑SCREEN DISPLAY ====================
$categories = $db->query("SELECT DISTINCT member_category FROM entry_exit WHERE member_category IS NOT NULL AND member_category != ''")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Entry/Exit Report - <?= h($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f0f2f5; }
        .container { max-width: 1400px; margin-top: 20px; }
        .filter-bar-logo { height: 40px; width: auto; max-width: 120px; object-fit: contain; }
        .filter-bar-icon { font-size: 32px; color: #1e3c72; }
        @media (max-width: 768px) {
            .filter-bar-logo { height: 30px; }
            .filter-bar-icon { font-size: 24px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold py-2"><i class="fas fa-door-open"></i> Entry/Exit Report</div>
            <div class="card-body">
                <form method="get" class="mb-4">
                    <div class="d-flex flex-wrap align-items-center gap-2">
                        <div class="flex-shrink-0">
                            <?php if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])): ?>
                                <img src="<?= $settings['library_logo'] ?>" class="filter-bar-logo" alt="Logo">
                            <?php else: ?>
                                <i class="fas fa-university filter-bar-icon"></i>
                            <?php endif; ?>
                        </div>
                        <div style="min-width:130px;"><label class="small mb-0">From</label><input type="date" name="from" class="form-control form-control-sm" value="<?= $from ?>"></div>
                        <div style="min-width:130px;"><label class="small mb-0">To</label><input type="date" name="to" class="form-control form-control-sm" value="<?= $to ?>"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Adm/Mem No</label><input type="text" name="admno" class="form-control form-control-sm" value="<?= h($admno) ?>"></div>
                        <div style="min-width:130px;"><label class="small mb-0">Category</label><select name="category" class="form-select form-select-sm">
                            <option value="all">All Categories</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= h($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= h($cat) ?></option>
                            <?php endforeach; ?>
                        </select></div>
                        <div style="min-width:110px;"><label class="small mb-0">Paper Size</label><select name="paper_size" class="form-select form-select-sm">
                            <option value="A4" <?= $paperSize=='A4'?'selected':''?>>A4</option>
                            <option value="Letter" <?= $paperSize=='Letter'?'selected':''?>>Letter</option>
                            <option value="Legal" <?= $paperSize=='Legal'?'selected':''?>>Legal</option>
                            <option value="A3" <?= $paperSize=='A3'?'selected':''?>>A3</option>
                        </select></div>
                        <div style="min-width:110px;"><label class="small mb-0">Orientation</label><select name="orientation" class="form-select form-select-sm">
                            <option value="landscape" <?= $orientation=='landscape'?'selected':''?>>Landscape</option>
                            <option value="portrait" <?= $orientation=='portrait'?'selected':''?>>Portrait</option>
                        </select></div>
                        <div><button type="submit" class="btn btn-primary btn-sm">Filter</button></div>
                        <div><a href="?format=excel&from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&category=<?= urlencode($category) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-success btn-sm">Excel</a></div>
                        <div><a href="?format=pdf&from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&category=<?= urlencode($category) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-danger btn-sm">PDF</a></div>
                        <div><button type="button" onclick="window.print()" class="btn btn-secondary btn-sm">Print</button></div>
                        <div class="flex-shrink-0"><i class="fas fa-book-open filter-bar-icon"></i></div>
                    </div>
                </form>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3"><div class="card bg-primary text-white"><div class="card-body text-center p-2"><h5><?= $totalEntries ?></h5><small>Total Entries</small></div></div></div>
                    <div class="col-md-3"><div class="card bg-success text-white"><div class="card-body text-center p-2"><h5><?= $totalExits ?></h5><small>Total Exits</small></div></div></div>
                    <div class="col-md-3"><div class="card bg-warning text-dark"><div class="card-body text-center p-2"><h5><?= $totalInside ?></h5><small>Still Inside</small></div></div></div>
                    <div class="col-md-3"><div class="card bg-info text-white"><div class="card-body text-center p-2"><h5><?= count($categories) ?></h5><small>Categories</small></div></div></div>
                </div>
                
                <?php if(!empty($logs)): ?>
                <div class="row mb-4 no-print">
                    <div class="col-md-6"><canvas id="categoryChart" style="height:250px;"></canvas></div>
                    <div class="col-md-6"><canvas id="dailyChart" style="height:250px;"></canvas></div>
                </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-sm">
                        <thead class="table-dark">
                            <tr><th>Sl No</th><th>Adm/Mem No</th><th>Member Name</th><th>Entry Date</th><th>Entry Time</th><th>Exit Time</th><th>Purpose</th><th>Duration</th></tr>
                        </thead>
                        <tbody>
                            <?php $sn = 1; foreach ($logs as $log): 
                                $duration = '';
                                if ($log['exit_time']) {
                                    $entryTime = strtotime($log['entry_date'] . ' ' . $log['entry_time']);
                                    $exitTime = strtotime($log['entry_date'] . ' ' . $log['exit_time']);
                                    $diffSeconds = $exitTime - $entryTime;
                                    $hours = floor($diffSeconds / 3600);
                                    $minutes = floor(($diffSeconds % 3600) / 60);
                                    $duration = $hours . 'h ' . $minutes . 'm';
                                } else {
                                    $duration = 'Still inside';
                                }
                            ?>
                            <tr>
                                <td><?= $sn++ ?></td>
                                <td><?= h($log['admno']) ?></td>
                                <td><?= h($log['member_name']) ?></td>
                                <td><?= formatDate($log['entry_date']) ?></td>
                                <td><?= formatTime($log['entry_time']) ?></td>
                                <td><?= $log['exit_time'] ? formatTime($log['exit_time']) : '-' ?></td>
                                <td><?= h($log['purpose'] ?? '-') ?></td>
                                <td><?= $duration ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($logs)): ?>
                            <tr><td colspan="8" class="text-center py-4">No entry/exit records found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php if(!empty($logs)): ?>
    <script>
        const categoryData = <?= json_encode(array_values($categoryStats)) ?>;
        const categoryLabels = <?= json_encode(array_keys($categoryStats)) ?>;
        if(categoryData.length > 0) {
            new Chart(document.getElementById('categoryChart'), { type: 'pie', data: { labels: categoryLabels, datasets: [{ data: categoryData, backgroundColor: ['#1e3c72','#2a5298','#28a745','#ffc107','#dc3545','#17a2b8'] }] } });
        }
        const dailyData = <?php 
            $dailyStats = [];
            $current = strtotime($from);
            $end = strtotime($to);
            while ($current <= $end) {
                $date = date('Y-m-d', $current);
                $count = count(array_filter($logs, function($l) use ($date) { return $l['entry_date'] === $date; }));
                $dailyStats[] = ['date' => formatDate($date), 'count' => $count];
                $current = strtotime('+1 day', $current);
            }
            echo json_encode($dailyStats);
        ?>;
        if(dailyData.length > 0) {
            new Chart(document.getElementById('dailyChart'), { type: 'line', data: { labels: dailyData.map(d => d.date), datasets: [{ label: 'Entries per Day', data: dailyData.map(d => d.count), borderColor: '#1e3c72', fill: false }] } });
        }
    </script>
    <?php endif; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>