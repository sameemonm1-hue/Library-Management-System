<?php
session_start();
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['member_logged_in'])) {
    header("Location: login.php");
    exit;
}

$db = getDB();
$admno = $_SESSION['member_admno'];
$stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
$stmt->execute([$admno]);
$member = $stmt->fetch();

$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';
$logo = !empty($institution['logo_path']) ? getWebImageUrl($institution['logo_path']) : '';

function formatDate($date) {
    return $date ? date('d-m-Y', strtotime($date)) : '-';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar-custom { background: linear-gradient(135deg, #1e3c72, #2a5298); }
        .profile-card { background: white; border-radius: 20px; padding: 2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .profile-photo { width: 120px; height: 120px; object-fit: cover; border-radius: 50%; border: 3px solid #1e3c72; }
        hr { margin: 1.5rem 0; }
        .btn-home { position: fixed; bottom: 20px; right: 20px; z-index: 1000; border-radius: 50px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
    <nav class="navbar navbar-custom navbar-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboard.php">
                <?php if ($logo): ?><img src="/<?= $logo ?>" style="height: 35px;"><?php endif; ?>
                <?= htmlspecialchars($institutionName) ?> – Member Portal
            </a>
            <a href="dashboard.php" class="btn btn-light btn-sm"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>
    </nav>

    <div class="container py-4">
        <div class="profile-card">
            <div class="row">
                <div class="col-md-3 text-center">
                    <?php if (!empty($member['photo_path']) && file_exists($member['photo_path'])): ?>
                        <img src="/<?= getWebImageUrl($member['photo_path']) ?>" class="profile-photo">
                    <?php else: ?>
                        <i class="fas fa-user-circle fa-5x text-secondary"></i>
                    <?php endif; ?>
                </div>
                <div class="col-md-9">
                    <h3><?= htmlspecialchars($member['name']) ?></h3>
                    <p class="text-muted"><?= htmlspecialchars($member['member_category']) ?></p>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <p><strong>Admission No:</strong> <?= htmlspecialchars($member['admno']) ?></p>
                            <p><strong>Class/Dept:</strong> <?= htmlspecialchars($member['class'] ?? '-') ?> / <strong>Div/Course:</strong> <?= htmlspecialchars($member['division'] ?? '-') ?></p>
                            <p><strong>Roll No:</strong> <?= htmlspecialchars($member['roll_no'] ?? '-') ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Email:</strong> <?= htmlspecialchars($member['email'] ?? '-') ?></p>
                            <p><strong>Phone:</strong> <?= htmlspecialchars($member['phone'] ?? '-') ?></p>
                            <p><strong>DOB:</strong> <?= formatDate($member['dob'] ?? '') ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($member['address'] ?? '')) ?></p>
                    <p><strong>Parent/Guardian Phone:</strong> <?= htmlspecialchars($member['parent_phone'] ?? '-') ?></p>
                    <p><strong>Blood Group:</strong> <?= htmlspecialchars($member['blood_group'] ?? '-') ?></p>
                    <p><strong>Admission Date:</strong> <?= formatDate($member['admission_date'] ?? '') ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Back to Home (Main Site) Button -->
    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>