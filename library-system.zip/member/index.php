<?php
/**
 * Member Portal - Unified Index
 * Login | Dashboard | Profile | Password Change | Logout
 * Features:
 * - Unified settings bar with report configuration
 * - Properly aligned report output
 * - Print-ready with clean formatting
 * - Consistent styling across all sections
 */
session_start();
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';
$logo = !empty($institution['logo_path']) ? getWebImageUrl($institution['logo_path']) : '';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ==================== LOGOUT HANDLER ====================
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}

// ==================== PASSWORD CHANGE HANDLER ====================
$passwordMessage = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $passwordMessage = ['type' => 'danger', 'text' => 'Invalid security token'];
    } else {
        $admno = trim($_POST['admno']);
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];
        
        if ($new !== $confirm) {
            $passwordMessage = ['type' => 'danger', 'text' => 'New passwords do not match'];
        } elseif (strlen($new) < 6) {
            $passwordMessage = ['type' => 'danger', 'text' => 'Password must be at least 6 characters'];
        } else {
            $stmt = $db->prepare("SELECT password FROM members WHERE admno = ?");
            $stmt->execute([$admno]);
            $member = $stmt->fetch();
            
            if ($member && password_verify($current, $member['password'])) {
                $newHash = password_hash($new, PASSWORD_DEFAULT);
                $update = $db->prepare("UPDATE members SET password = ? WHERE admno = ?");
                $update->execute([$newHash, $admno]);
                $passwordMessage = ['type' => 'success', 'text' => 'Password changed successfully'];
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } else {
                $passwordMessage = ['type' => 'danger', 'text' => 'Current password is incorrect'];
            }
        }
    }
}

// ==================== LOGIN HANDLER ====================
$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $admno = trim($_POST['admno']);
    $password = $_POST['password'];
    
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    if ($member && password_verify($password, $member['password'])) {
        $_SESSION['member_logged_in'] = true;
        $_SESSION['member_admno'] = $member['admno'];
        $_SESSION['member_name'] = $member['name'];
        $_SESSION['member_category'] = $member['member_category'];
        $_SESSION['member_id'] = $member['id'];
        header("Location: index.php");
        exit;
    } else {
        $loginError = "Invalid Admission Number or Password. If you don't have a password, please contact the library.";
    }
}

// ==================== LOGGED-IN USER DATA ====================
if (isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true) {
    $admno = $_SESSION['member_admno'];
    $member_name = $_SESSION['member_name'];
    
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    // Current loans
    $currentLoans = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NULL ORDER BY issue_date DESC");
    $currentLoans->execute([$admno]);
    $currentList = $currentLoans->fetchAll();
    
    // Overdue count
    $overdue = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now')");
    $overdue->execute([$admno]);
    $overdueCount = $overdue->fetchColumn();
    
    // Borrowing history (last 10)
    $history = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NOT NULL ORDER BY return_date DESC LIMIT 10");
    $history->execute([$admno]);
    $historyList = $history->fetchAll();
    
    // Total fines
    $totalFines = $member['total_fines'] ?? 0;
    if ($totalFines == 0) {
        $fineCalc = $db->prepare("SELECT SUM(fine) FROM circulation WHERE admno = ?");
        $fineCalc->execute([$admno]);
        $totalFines = $fineCalc->fetchColumn() ?: 0;
    }
}

function formatDate($date) {
    return $date ? date('d-m-Y', strtotime($date)) : '-';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($institutionName) ?> – Member Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        
        body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        
        /* ===== SETTINGS BAR - UNIFIED ===== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        @media (max-width: 768px) {
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
        }

        /* ===== NAVBAR ===== */
        .navbar-custom { 
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light)); 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
        }
        .navbar-custom .navbar-brand {
            color: white !important;
        }
        .navbar-custom .btn-light {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
        }
        .navbar-custom .btn-light:hover {
            background: rgba(255,255,255,0.3);
            color: white;
        }
        .navbar-custom .dropdown-menu .dropdown-item:hover {
            background: var(--primary-color);
            color: white;
        }
        .navbar-brand img { height: 35px; margin-right: 10px; }

        /* ===== LOGIN CARD ===== */
        .login-card { 
            max-width: 450px; 
            margin: 80px auto; 
            border-radius: 20px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.1); 
            background: white; 
            border: none;
        }
        .login-card .card-body { padding: 2rem; }
        .login-card .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .login-card .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .institution-logo { max-height: 60px; margin-bottom: 1rem; }

        /* ===== STATS CARDS ===== */
        .stats-card { 
            background: white; 
            border-radius: 15px; 
            padding: 1.5rem; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 
            transition: transform 0.2s; 
            border: none;
        }
        .stats-card:hover { transform: translateY(-3px); }
        .stats-number { font-size: 2rem; font-weight: bold; margin-bottom: 0; }
        .stats-label { color: #6c757d; font-size: 0.9rem; }
        .stats-card .stat-icon { 
            color: var(--primary-color); 
            opacity: 0.7;
        }

        /* ===== SECTION TITLE ===== */
        .section-title { 
            margin: 1.5rem 0 1rem; 
            border-left: 4px solid var(--primary-color); 
            padding-left: 12px; 
        }

        /* ===== TABLES ===== */
        .table-responsive { 
            background: white; 
            border-radius: 12px; 
            padding: 0; 
            overflow: hidden; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .table th { 
            background: var(--primary-color); 
            color: white; 
            border-bottom: none;
            padding: 10px 12px;
        }
        .table td { 
            padding: 10px 12px; 
            vertical-align: middle;
        }
        .table-hover tbody tr:hover {
            background: rgba(var(--primary-rgb), 0.05);
        }
        .table .table-danger td {
            background: #f8d7da;
        }

        /* ===== PROFILE ===== */
        .profile-photo { 
            width: 80px; 
            height: 80px; 
            object-fit: cover; 
            border-radius: 50%; 
            border: 3px solid var(--primary-color); 
        }
        .profile-card .card-body {
            padding: 1.5rem;
        }
        .profile-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-home { 
            position: fixed; 
            bottom: 20px; 
            right: 20px; 
            z-index: 1000; 
            border-radius: 50px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.2); 
        }

        /* ===== MODAL ===== */
        .modal-header {
            background: var(--primary-color);
            color: white;
            border-radius: 12px 12px 0 0 !important;
        }
        .modal-header .btn-close {
            filter: invert(1);
        }

        /* ===== FOOTER ===== */
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 2rem; 
            border-radius: 16px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stats-number { font-size: 1.5rem; }
            .stats-card { padding: 1rem; }
            .profile-photo { width: 60px; height: 60px; }
            .table th, .table td { padding: 6px 8px; font-size: 0.85rem; }
        }

        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .navbar-custom { 
                background: #f8f9fa !important; 
                color: #333 !important;
                box-shadow: none !important;
            }
            .navbar-custom .navbar-brand { color: #333 !important; }
            .navbar-custom .btn-light { display: none !important; }
            .login-card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .stats-card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .table-responsive { box-shadow: none !important; border: 1px solid #ddd !important; }
            .table th { background: #e9ecef !important; color: #333 !important; }
            .table td, .table th { border: 1px solid #ddd !important; }
            .profile-card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .btn-home { display: none !important; }
            .alert { border: 1px solid #ddd !important; }
            .badge { border: 1px solid #ddd !important; }
            .badge.bg-danger { background: #f8d7da !important; color: #721c24 !important; }
            .badge.bg-success { background: #d4edda !important; color: #155724 !important; }
            .footer { border-top: 1px solid #ddd !important; }
            .section-title { border-left-color: #333 !important; }
            .table .table-danger td { background: #f8f9fa !important; }
            .modal { display: none !important; }
            .modal-backdrop { display: none !important; }
            h2, h4, h5 { color: #333 !important; }
            .stats-number { color: #333 !important; }
            .stats-label { color: #555 !important; }
            .stat-icon { color: #333 !important; }
            .profile-photo { border-color: #ddd !important; }
        }
    </style>
</head>
<body>

<?php if (!isset($_SESSION['member_logged_in']) || $_SESSION['member_logged_in'] !== true): ?>
    <!-- ==================== LOGIN PAGE ==================== -->
    <div class="container">
        <!-- Settings Bar -->
        <div class="settings-bar no-print">
            <div class="settings-items-wrap">
                <span class="settings-label"><i class="fas fa-sliders-h"></i> Report Settings:</span>
                <span class="settings-item"><i class="fas fa-font"></i> Font: <?= $reportFontSize ?>px</span>
                <span class="settings-item"><i class="fas fa-palette"></i> Primary: <?= $reportPrimaryColor ?></span>
                <?php if($reportWatermarkEnabled): ?>
                    <span class="settings-item"><i class="fas fa-water"></i> Watermark: <?= $reportWatermarkText ?: 'Enabled' ?></span>
                <?php endif; ?>
                <?php if($reportSignatureEnabled): ?>
                    <span class="settings-item"><i class="fas fa-signature"></i> Signature: <?= $reportSignatureName ?></span>
                <?php endif; ?>
                <span class="settings-item"><i class="fas fa-flag"></i> Footer: <?= $reportFooterText ?></span>
            </div>
            <a href="#" onclick="window.print();" class="no-print"><i class="fas fa-print"></i> Print Report</a>
        </div>

        <div class="card login-card">
            <div class="card-body text-center">
                <?php if ($logo): ?>
                    <img src="/<?= $logo ?>" class="institution-logo" alt="Logo">
                <?php else: ?>
                    <div class="logo"><i class="fas fa-user-circle fa-4x" style="color: var(--primary-color);"></i></div>
                <?php endif; ?>
                <h4 class="mb-3" style="color: var(--primary-color);"><?= htmlspecialchars($institutionName) ?> – Member Portal</h4>
                <?php if ($loginError): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
                <?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Admission / Member Number</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                            <input type="text" name="admno" class="form-control" required autofocus>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
                </form>
                <hr class="my-4">
                <p class="small text-muted">Don't have a password? Contact the library to set one up. Default password: <strong>123456</strong> (if set by admin).</p>
                <a href="../opac/" class="btn btn-link btn-sm no-print">Public Catalog (OPAC)</a>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>. All rights reserved.</p>
            <p class="small text-muted mb-0"><?= htmlspecialchars($reportFooterText) ?></p>
        </div>
    </div>
<?php else: ?>
    <!-- ==================== DASHBOARD / PROFILE PAGE ==================== -->
    <nav class="navbar navbar-custom p-3 no-print">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <?php if ($logo): ?>
                    <img src="/<?= $logo ?>" alt="Logo">
                <?php endif; ?>
                <?= htmlspecialchars($institutionName) ?> – Member Portal
            </a>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle"></i> <?= htmlspecialchars($member_name) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#profile-section"><i class="fas fa-id-card"></i> My Profile</a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../opac/"><i class="fas fa-search"></i> OPAC (Catalog)</a></li>
                    <li><a class="dropdown-item" href="?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Settings Bar -->
        <div class="settings-bar no-print">
            <div class="settings-items-wrap">
                <span class="settings-label"><i class="fas fa-sliders-h"></i> Report Settings:</span>
                <span class="settings-item"><i class="fas fa-font"></i> Font: <?= $reportFontSize ?>px</span>
                <span class="settings-item"><i class="fas fa-palette"></i> Primary: <?= $reportPrimaryColor ?></span>
                <?php if($reportWatermarkEnabled): ?>
                    <span class="settings-item"><i class="fas fa-water"></i> Watermark: <?= $reportWatermarkText ?: 'Enabled' ?></span>
                <?php endif; ?>
                <?php if($reportSignatureEnabled): ?>
                    <span class="settings-item"><i class="fas fa-signature"></i> Signature: <?= $reportSignatureName ?></span>
                <?php endif; ?>
                <span class="settings-item"><i class="fas fa-flag"></i> Footer: <?= $reportFooterText ?></span>
            </div>
            <a href="#" onclick="window.print();" class="no-print"><i class="fas fa-print"></i> Print Report</a>
        </div>

        <?php if ($passwordMessage): ?>
            <div class="alert alert-<?= $passwordMessage['type'] ?> alert-dismissible fade show no-print" role="alert">
                <?= htmlspecialchars($passwordMessage['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="alert alert-info no-print">
            <i class="fas fa-hand-wave"></i> Welcome back, <strong><?= htmlspecialchars($member_name) ?></strong>! 
            <?php if ($overdueCount > 0): ?>
                <span class="badge bg-danger ms-2"><?= $overdueCount ?> overdue book(s)</span>
            <?php endif; ?>
        </div>

        <!-- Statistics Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card text-center">
                    <i class="fas fa-book-open fa-2x stat-icon mb-2"></i>
                    <div class="stats-number" style="color: var(--primary-color);"><?= count($currentList) ?></div>
                    <div class="stats-label">Currently Issued</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card text-center">
                    <i class="fas fa-exclamation-triangle fa-2x stat-icon mb-2" style="color: #ffc107;"></i>
                    <div class="stats-number" style="color: #ffc107;"><?= $overdueCount ?></div>
                    <div class="stats-label">Overdue Books</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card text-center">
                    <i class="fas fa-money-bill fa-2x stat-icon mb-2" style="color: #dc3545;"></i>
                    <div class="stats-number" style="color: #dc3545;"><?= $currencySymbol ?> <?= number_format($totalFines, 2) ?></div>
                    <div class="stats-label">Total Fines</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card text-center">
                    <i class="fas fa-clock fa-2x stat-icon mb-2" style="color: #0dcaf0;"></i>
                    <div class="stats-number" style="color: #0dcaf0;"><?= $member['total_issued'] ?? 0 ?></div>
                    <div class="stats-label">Books Borrowed (Lifetime)</div>
                </div>
            </div>
        </div>

        <!-- Current Loans -->
        <div class="section-title">
            <h5><i class="fas fa-book" style="color: var(--primary-color);"></i> Current Loans</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr><th>Book Title</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($currentList)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No books currently issued. You can borrow books from the library.</td></tr>
                    <?php else: ?>
                        <?php foreach ($currentList as $loan): ?>
                            <?php $isOverdue = strtotime($loan['due_date']) < time(); ?>
                            <tr class="<?= $isOverdue ? 'table-danger' : '' ?>">
                                <td><strong><?= htmlspecialchars($loan['title']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($loan['barcode']) ?></small></td>
                                <td><?= htmlspecialchars($loan['author'] ?? '-') ?></td>
                                <td><?= formatDate($loan['issue_date']) ?></td>
                                <td><?= formatDate($loan['due_date']) ?></td>
                                <td><?= $isOverdue ? '<span class="badge bg-danger">Overdue</span>' : '<span class="badge bg-success">Issued</span>' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Borrowing History -->
        <div class="section-title mt-4">
            <h5><i class="fas fa-history" style="color: var(--primary-color);"></i> Recent Borrowing History</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>Book Title</th><th>Issue Date</th><th>Return Date</th><th>Fine</th></tr></thead>
                <tbody>
                    <?php if (empty($historyList)): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">No borrowing history found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($historyList as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['title']) ?></td>
                                <td><?= formatDate($row['issue_date']) ?></td>
                                <td><?= formatDate($row['return_date']) ?></td>
                                <td><?= $row['fine'] ? $currencySymbol . ' ' . number_format($row['fine'], 2) : '—' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Profile Section -->
        <div id="profile-section" class="section-title mt-4">
            <h5><i class="fas fa-id-card" style="color: var(--primary-color);"></i> My Profile</h5>
        </div>
        <div class="card profile-card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 text-center">
                        <?php if (!empty($member['photo_path']) && file_exists($member['photo_path'])): ?>
                            <img src="/<?= getWebImageUrl($member['photo_path']) ?>" class="profile-photo" alt="Profile Photo">
                        <?php else: ?>
                            <i class="fas fa-user-circle fa-5x" style="color: var(--primary-color); opacity: 0.5;"></i>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-10">
                        <h4 style="color: var(--primary-color);"><?= htmlspecialchars($member['name']) ?></h4>
                        <p class="text-muted"><?= htmlspecialchars($member['member_category']) ?></p>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <p><strong>Admission No:</strong> <?= htmlspecialchars($member['admno']) ?></p>
                                <p><strong>Class/Dept:</strong> <?= htmlspecialchars($member['class'] ?? '-') ?> / <strong>Div/Course:</strong> <?= htmlspecialchars($member['division'] ?? '-') ?></p>
                                <p><strong>Roll No:</strong> <?= htmlspecialchars($member['roll_no'] ?? '-') ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Email:</strong> <?= htmlspecialchars($member['email'] ?? '-') ?></p>
                                <p><strong>Phone:</strong> <?= htmlspecialchars($member['phone'] ?? '-') ?></p>
                                <p><strong>DOB:</strong> <?= formatDate($member['dob'] ?? '') ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($member['address'] ?? '')) ?></p>
                        <p><strong>Parent/Guardian Phone:</strong> <?= htmlspecialchars($member['parent_phone'] ?? '-') ?></p>
                        <p><strong>Blood Group:</strong> <?= htmlspecialchars($member['blood_group'] ?? '-') ?></p>
                        <p><strong>Admission Date:</strong> <?= formatDate($member['admission_date'] ?? '') ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="row mt-2 no-print">
            <div class="col-md-12 text-center">
                <a href="../opac/" class="btn btn-primary me-2"><i class="fas fa-search"></i> Search Catalog (OPAC)</a>
                <button class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</button>
            </div>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade no-print" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-key"></i> Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="admno" value="<?= htmlspecialchars($admno) ?>">
                        <div class="mb-3">
                            <label class="fw-semibold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Back to Home Button -->
    <a href="../index.php" class="btn btn-primary btn