<?php
session_start();
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['member_logged_in']) || $_SESSION['member_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$admno = $_SESSION['member_admno'];
$member_name = $_SESSION['member_name'];

$stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
$stmt->execute([$admno]);
$member = $stmt->fetch();

$currentLoans = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NULL ORDER BY issue_date DESC");
$currentLoans->execute([$admno]);
$currentList = $currentLoans->fetchAll();

$overdue = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now')");
$overdue->execute([$admno]);
$overdueCount = $overdue->fetchColumn();

$history = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NOT NULL ORDER BY return_date DESC LIMIT 10");
$history->execute([$admno]);
$historyList = $history->fetchAll();

$totalFines = $member['total_fines'] ?? 0;
if ($totalFines == 0) {
    $fineCalc = $db->prepare("SELECT SUM(fine) FROM circulation WHERE admno = ?");
    $fineCalc->execute([$admno]);
    $totalFines = $fineCalc->fetchColumn() ?: 0;
}

$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';
$institutionLogo = !empty($institution['logo_path']) ? getWebImageUrl($institution['logo_path']) : '';

// CSRF token for password change form
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check for password change message
$passwordMessage = null;
if (isset($_SESSION['password_message'])) {
    $passwordMessage = $_SESSION['password_message'];
    unset($_SESSION['password_message']);
}

// formatDate() is already defined in functions.php – no need to redeclare
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dashboard - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar-custom { background: linear-gradient(135deg, #1e3c72, #2a5298); box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .navbar-brand img { height: 35px; margin-right: 10px; }
        .stats-card { background: white; border-radius: 15px; padding: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.05); transition: transform 0.2s; }
        .stats-card:hover { transform: translateY(-3px); }
        .stats-number { font-size: 2rem; font-weight: bold; margin-bottom: 0; }
        .stats-label { color: #6c757d; font-size: 0.9rem; }
        .section-title { margin: 1.5rem 0 1rem; border-left: 4px solid #1e3c72; padding-left: 12px; }
        .table-responsive { background: white; border-radius: 12px; padding: 0; overflow: hidden; }
        .table th { background: #f8f9fc; border-bottom: 2px solid #e9ecef; }
        .footer { text-align: center; padding: 20px; color: #6c757d; font-size: 0.8rem; margin-top: 2rem; }
        .btn-home { position: fixed; bottom: 20px; right: 20px; z-index: 1000; border-radius: 50px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
    </style>
</head>
<body>
    <nav class="navbar navbar-custom navbar-dark p-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <?php if ($institutionLogo): ?>
                    <img src="/<?= $institutionLogo ?>" alt="Logo">
                <?php endif; ?>
                <?= htmlspecialchars($institutionName) ?> – Member Portal
            </a>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle"></i> <?= htmlspecialchars($member_name) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../opac/"><i class="fas fa-search"></i> OPAC (Catalog)</a></li>
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <?php if ($passwordMessage): ?>
            <div class="alert alert-<?= $passwordMessage['type'] ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($passwordMessage['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="alert alert-info">
            <i class="fas fa-hand-wave"></i> Welcome back, <strong><?= htmlspecialchars($member_name) ?></strong>! 
            <?php if ($overdueCount > 0): ?>
                <span class="badge bg-danger ms-2"><?= $overdueCount ?> overdue book(s)</span>
            <?php endif; ?>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <i class="fas fa-book-open fa-2x text-primary mb-2"></i>
                    <div class="stats-number"><?= count($currentList) ?></div>
                    <div class="stats-label">Currently Issued</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <i class="fas fa-exclamation-triangle fa-2x text-warning mb-2"></i>
                    <div class="stats-number"><?= $overdueCount ?></div>
                    <div class="stats-label">Overdue Books</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <i class="fas fa-money-bill fa-2x text-danger mb-2"></i>
                    <div class="stats-number"><?= $currencySymbol ?> <?= number_format($totalFines, 2) ?></div>
                    <div class="stats-label">Total Fines</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card text-center">
                    <i class="fas fa-clock fa-2x text-info mb-2"></i>
                    <div class="stats-number"><?= $member['total_issued'] ?? 0 ?></div>
                    <div class="stats-label">Books Borrowed (Lifetime)</div>
                </div>
            </div>
        </div>

        <div class="section-title">
            <h5><i class="fas fa-book"></i> Current Loans</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr><th>Book Title</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($currentList)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No books currently issued. You can borrow books from the library.<?php else: ?>
                        <?php foreach ($currentList as $loan): ?>
                            <?php $isOverdue = strtotime($loan['due_date']) < time(); ?>
                            <tr class="<?= $isOverdue ? 'table-danger' : '' ?>">
                                <td><strong><?= htmlspecialchars($loan['title']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($loan['barcode']) ?></small></td>
                                <td><?= htmlspecialchars($loan['author'] ?? '-') ?></td>
                                <td><?= formatDate($loan['issue_date']) ?></td>
                                <td><?= formatDate($loan['due_date']) ?></td>
                                <td><?= $isOverdue ? '<span class="badge bg-danger">Overdue</span>' : '<span class="badge bg-success">Issued</span>' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="section-title mt-4">
            <h5><i class="fas fa-history"></i> Recent Borrowing History</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>Book Title</th><th>Issue Date</th><th>Return Date</th><th>Fine</th></tr></thead>
                <tbody>
                    <?php if (empty($historyList)): ?>
                        <td><td colspan="4" class="text-center text-muted py-4">No borrowing history found.<?php else: ?>
                        <?php foreach ($historyList as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['title']) ?></td>
                                <td><?= formatDate($row['issue_date']) ?></td>
                                <td><?= formatDate($row['return_date']) ?></td>
                                <td><?= $row['fine'] ? $currencySymbol . ' ' . number_format($row['fine'], 2) : '—' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body text-center">
                        <a href="../opac/" class="btn btn-primary me-2"><i class="fas fa-search"></i> Search Catalog (OPAC)</a>
                        <a href="profile.php" class="btn btn-outline-secondary me-2"><i class="fas fa-id-card"></i> View Profile</a>
                        <button class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post" action="change_password.php">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="admno" value="<?= htmlspecialchars($admno) ?>">
                        <div class="mb-3">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="mb-3">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>

    <div class="footer">
        &copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>. All rights reserved.
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>