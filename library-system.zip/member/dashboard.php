<?php
/**
 * Member Dashboard - Complete Update
 * Features:
 * - Unified settings bar with report configuration
 * - Properly aligned report output
 * - Print-ready with clean formatting
 * - Consistent styling with other modules
 * - Enhanced statistics cards with gradient styling
 * - Responsive and print-friendly design
 */

session_start();
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['member_logged_in']) || $_SESSION['member_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$admno = $_SESSION['member_admno'];
$member_name = $_SESSION['member_name'];

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

$stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
$stmt->execute([$admno]);
$member = $stmt->fetch();

$currentLoans = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NULL ORDER BY issue_date DESC");
$currentLoans->execute([$admno]);
$currentList = $currentLoans->fetchAll();

$overdue = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now')");
$overdue->execute([$admno]);
$overdueCount = $overdue->fetchColumn();

$history = $db->prepare("SELECT * FROM circulation WHERE admno = ? AND return_date IS NOT NULL ORDER BY return_date DESC LIMIT 10");
$history->execute([$admno]);
$historyList = $history->fetchAll();

$totalFines = $member['total_fines'] ?? 0;
if ($totalFines == 0) {
    $fineCalc = $db->prepare("SELECT SUM(fine) FROM circulation WHERE admno = ?");
    $fineCalc->execute([$admno]);
    $totalFines = $fineCalc->fetchColumn() ?: 0;
}

$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';
$institutionLogo = !empty($institution['logo_path']) ? getWebImageUrl($institution['logo_path']) : '';

// CSRF token for password change form
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check for password change message
$passwordMessage = null;
if (isset($_SESSION['password_message'])) {
    $passwordMessage = $_SESSION['password_message'];
    unset($_SESSION['password_message']);
}

// formatDate() is already defined in functions.php – no need to redeclare
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Dashboard - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        
        body { background: #f0f2f5; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        
        /* ===== SETTINGS BAR - UNIFIED ===== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        @media (max-width: 768px) {
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
        }

        /* ===== NAVBAR ===== */
        .navbar-custom { 
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light)); 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
        }
        .navbar-custom .navbar-brand {
            color: white !important;
        }
        .navbar-custom .btn-light {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
        }
        .navbar-custom .btn-light:hover {
            background: rgba(255,255,255,0.3);
            color: white;
        }
        .navbar-custom .dropdown-menu .dropdown-item:hover {
            background: var(--primary-color);
            color: white;
        }
        .navbar-brand img { height: 35px; margin-right: 10px; }

        /* ===== STATS CARDS - UNIFIED GRADIENT ===== */
        .stats-card { 
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            border-radius: 15px; 
            padding: 1.5rem; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 
            transition: transform 0.2s; 
            border: none;
            color: white;
            text-align: center;
        }
        .stats-card:hover { transform: translateY(-3px); }
        .stats-card .stat-icon {
            font-size: 2rem;
            opacity: 0.3;
            color: white;
            margin-bottom: 8px;
        }
        .stats-number { 
            font-size: 2rem; 
            font-weight: 700; 
            margin-bottom: 0; 
            color: white;
        }
        .stats-label { 
            color: rgba(255,255,255,0.9); 
            font-size: 0.9rem; 
            font-weight: 500;
        }

        /* ===== SECTION TITLE ===== */
        .section-title { 
            margin: 1.5rem 0 1rem; 
            border-left: 4px solid var(--primary-color); 
            padding-left: 12px; 
        }
        .section-title h5 {
            color: #333;
            font-weight: 600;
        }

        /* ===== TABLES ===== */
        .table-responsive { 
            background: white; 
            border-radius: 12px; 
            padding: 0; 
            overflow: hidden; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .table th { 
            background: var(--primary-color); 
            color: white; 
            border-bottom: none;
            padding: 10px 12px;
            font-weight: 600;
        }
        .table td { 
            padding: 10px 12px; 
            vertical-align: middle;
        }
        .table-hover tbody tr:hover {
            background: rgba(var(--primary-rgb), 0.05);
        }
        .table .table-danger td {
            background: #f8d7da;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .btn-home { 
            position: fixed; 
            bottom: 20px; 
            right: 20px; 
            z-index: 1000; 
            border-radius: 50px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.2); 
        }

        /* ===== MODAL ===== */
        .modal-header {
            background: var(--primary-color);
            color: white;
            border-radius: 12px 12px 0 0 !important;
        }
        .modal-header .btn-close {
            filter: invert(1);
        }

        /* ===== CARD ===== */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card .card-body {
            padding: 1.5rem;
        }

        /* ===== FOOTER ===== */
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 2rem; 
            border-radius: 16px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stats-number { font-size: 1.5rem; }
            .stats-card { padding: 1rem; }
            .table th, .table td { padding: 6px 8px; font-size: 0.85rem; }
        }

        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .navbar-custom { 
                background: #f8f9fa !important; 
                color: #333 !important;
                box-shadow: none !important;
            }
            .navbar-custom .navbar-brand { color: #333 !important; }
            .navbar-custom .btn-light { display: none !important; }
            .stats-card { 
                background: #f8f9fa !important; 
                color: #333 !important;
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stats-card .stat-number { color: #333 !important; }
            .stats-card .stat-label { color: #555 !important; }
            .stats-card .stat-icon { color: #333 !important; opacity: 0.5; }
            .table-responsive { box-shadow: none !important; border: 1px solid #ddd !important; }
            .table th { background: #e9ecef !important; color: #333 !important; }
            .table td, .table th { border: 1px solid #ddd !important; }
            .card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .btn-home { display: none !important; }
            .alert { border: 1px solid #ddd !important; }
            .badge { border: 1px solid #ddd !important; }
            .badge.bg-danger { background: #f8d7da !important; color: #721c24 !important; }
            .badge.bg-success { background: #d4edda !important; color: #155724 !important; }
            .footer { border-top: 1px solid #ddd !important; }
            .section-title { border-left-color: #333 !important; }
            .table .table-danger td { background: #f8f9fa !important; }
            .modal { display: none !important; }
            .modal-backdrop { display: none !important; }
            h2, h4, h5 { color: #333 !important; }
            .container { max-width: 100% !important; padding: 0 20px !important; }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-custom p-3 no-print">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <?php if ($institutionLogo): ?>
                    <img src="/<?= $institutionLogo ?>" alt="Logo">
                <?php endif; ?>
                <?= htmlspecialchars($institutionName) ?> – Member Portal
            </a>
            <div class="dropdown">
                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle"></i> <?= htmlspecialchars($member_name) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="profile.php"><i class="fas fa-id-card"></i> My Profile</a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="../opac/"><i class="fas fa-search"></i> OPAC (Catalog)</a></li>
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <!-- Settings Bar -->
        <div class="settings-bar no-print">
            <div class="settings-items-wrap">
                <span class="settings-label"><i class="fas fa-sliders-h"></i> Report Settings:</span>
                <span class="settings-item"><i class="fas fa-font"></i> Font: <?= $reportFontSize ?>px</span>
                <span class="settings-item"><i class="fas fa-palette"></i> Primary: <?= $reportPrimaryColor ?></span>
                <?php if($reportWatermarkEnabled): ?>
                    <span class="settings-item"><i class="fas fa-water"></i> Watermark: <?= $reportWatermarkText ?: 'Enabled' ?></span>
                <?php endif; ?>
                <?php if($reportSignatureEnabled): ?>
                    <span class="settings-item"><i class="fas fa-signature"></i> Signature: <?= $reportSignatureName ?></span>
                <?php endif; ?>
                <span class="settings-item"><i class="fas fa-flag"></i> Footer: <?= $reportFooterText ?></span>
            </div>
            <a href="#" onclick="window.print();" class="no-print"><i class="fas fa-print"></i> Print Report</a>
        </div>

        <?php if ($passwordMessage): ?>
            <div class="alert alert-<?= $passwordMessage['type'] ?> alert-dismissible fade show no-print" role="alert">
                <?= htmlspecialchars($passwordMessage['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="alert alert-info no-print">
            <i class="fas fa-hand-wave"></i> Welcome back, <strong><?= htmlspecialchars($member_name) ?></strong>! 
            <?php if ($overdueCount > 0): ?>
                <span class="badge bg-danger ms-2"><?= $overdueCount ?> overdue book(s)</span>
            <?php endif; ?>
        </div>

        <!-- Statistics Cards - Unified Gradient -->
        <div class="row g-4 mb-4">
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card">
                    <div class="stat-icon"><i class="fas fa-book-open"></i></div>
                    <div class="stats-number"><?= count($currentList) ?></div>
                    <div class="stats-label">Currently Issued</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card">
                    <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    <div class="stats-number"><?= $overdueCount ?></div>
                    <div class="stats-label">Overdue Books</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card">
                    <div class="stat-icon"><i class="fas fa-money-bill"></i></div>
                    <div class="stats-number"><?= $currencySymbol ?> <?= number_format($totalFines, 2) ?></div>
                    <div class="stats-label">Total Fines</div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="stats-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stats-number"><?= $member['total_issued'] ?? 0 ?></div>
                    <div class="stats-label">Books Borrowed (Lifetime)</div>
                </div>
            </div>
        </div>

        <!-- Current Loans -->
        <div class="section-title">
            <h5><i class="fas fa-book" style="color: var(--primary-color);"></i> Current Loans</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($currentList)): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                <i class="fas fa-check-circle fa-2x mb-2 d-block text-success"></i>
                                No books currently issued. You can borrow books from the library.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($currentList as $loan): ?>
                            <?php $isOverdue = strtotime($loan['due_date']) < time(); ?>
                            <tr class="<?= $isOverdue ? 'table-danger' : '' ?>">
                                <td>
                                    <strong><?= htmlspecialchars($loan['title']) ?></strong>
                                    <br><small class="text-muted"><?= htmlspecialchars($loan['barcode']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($loan['author'] ?? '-') ?></td>
                                <td><?= formatDate($loan['issue_date']) ?></td>
                                <td><?= formatDate($loan['due_date']) ?></td>
                                <td>
                                    <?= $isOverdue ? 
                                        '<span class="badge bg-danger"><i class="fas fa-exclamation-circle"></i> Overdue</span>' : 
                                        '<span class="badge bg-success"><i class="fas fa-check-circle"></i> Issued</span>' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Borrowing History -->
        <div class="section-title mt-4">
            <h5><i class="fas fa-history" style="color: var(--primary-color);"></i> Recent Borrowing History</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Issue Date</th>
                        <th>Return Date</th>
                        <th>Fine</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($historyList)): ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">
                                <i class="fas fa-history fa-2x mb-2 d-block text-muted"></i>
                                No borrowing history found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($historyList as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['title']) ?></td>
                                <td><?= formatDate($row['issue_date']) ?></td>
                                <td><?= formatDate($row['return_date']) ?></td>
                                <td>
                                    <?= $row['fine'] ? 
                                        '<span class="text-danger">' . $currencySymbol . ' ' . number_format($row['fine'], 2) . '</span>' : 
                                        '<span class="text-muted">—</span>' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Action Buttons -->
        <div class="row mt-4 no-print">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body text-center">
                        <a href="../opac/" class="btn btn-primary me-2"><i class="fas fa-search"></i> Search Catalog (OPAC)</a>
                        <a href="profile.php" class="btn btn-outline-secondary me-2"><i class="fas fa-id-card"></i> View Profile</a>
                        <button class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade no-print" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-key"></i> Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post" action="change_password.php">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="admno" value="<?= htmlspecialchars($admno) ?>">
                        <div class="mb-3">
                            <label class="fw-semibold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="mb-3">
                            <label class="fw-semibold">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Back to Home Button -->
    <a href="../index.php" class="btn btn-primary btn-home no-print"><i class="fas fa-home"></i> Back to Home</a>

    <!-- Footer -->
    <div class="container">
        <div class="footer">
            <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>. All rights reserved.</p>
            <p class="small text-muted mb-0"><?= htmlspecialchars($reportFooterText) ?></p>
            <p class="small mt-2 opacity-75 no-print">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>