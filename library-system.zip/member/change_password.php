<?php
session_start();
require_once __DIR__ . '/../config/functions.php';

if (!isset($_SESSION['member_logged_in'])) {
    header("Location: login.php");
    exit;
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF validation
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['password_message'] = ['type' => 'danger', 'text' => 'Invalid security token'];
        header("Location: dashboard.php");
        exit;
    }

    $admno = $_POST['admno'];
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    if ($new !== $confirm) {
        $_SESSION['password_message'] = ['type' => 'danger', 'text' => 'New passwords do not match'];
        header("Location: dashboard.php");
        exit;
    }
    
    if (strlen($new) < 6) {
        $_SESSION['password_message'] = ['type' => 'danger', 'text' => 'Password must be at least 6 characters'];
        header("Location: dashboard.php");
        exit;
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT password FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    if ($member && password_verify($current, $member['password'])) {
        $newHash = password_hash($new, PASSWORD_DEFAULT);
        $update = $db->prepare("UPDATE members SET password = ? WHERE admno = ?");
        $update->execute([$newHash, $admno]);
        $_SESSION['password_message'] = ['type' => 'success', 'text' => 'Password changed successfully'];
        // Regenerate CSRF token
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['password_message'] = ['type' => 'danger', 'text' => 'Current password is incorrect'];
    }
    header("Location: dashboard.php");
    exit;
}
?>