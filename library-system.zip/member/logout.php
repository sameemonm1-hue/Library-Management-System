<?php
// Prevent "session already started" warning
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Optional: log logout activity for audit (if the user was logged in)
if (isset($_SESSION['user_id'])) {
    // You can log admin/staff logout if you have a logActivity function
    if (function_exists('logActivity')) {
        logActivity($_SESSION['username'] ?? 'Unknown', 'LOGOUT', 'User logged out');
    }
} elseif (isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true) {
    // Optional: log member logout
    if (function_exists('logActivity')) {
        logActivity($_SESSION['member_admno'] ?? 'Unknown', 'MEMBER_LOGOUT', 'Member logged out');
    }
}

// Destroy all session data
$_SESSION = []; // Clear all session variables
session_destroy();

// Redirect to the main login/index page (adjust path if needed)
header("Location: ../index.php");
exit;
?>