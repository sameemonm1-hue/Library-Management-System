<?php
session_start();
require_once __DIR__ . '/../config/functions.php';

if (isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';
$logo = !empty($institution['logo_path']) ? getWebImageUrl($institution['logo_path']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admno = trim($_POST['admno'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $db = getDB();
    // Case‑insensitive match
    $stmt = $db->prepare("SELECT * FROM members WHERE UPPER(admno) = UPPER(?) AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    if ($member && !empty($member['password']) && password_verify($password, $member['password'])) {
        $_SESSION['member_logged_in'] = true;
        $_SESSION['member_admno'] = $member['admno'];
        $_SESSION['member_name'] = $member['name'];
        $_SESSION['member_category'] = $member['member_category'];
        $_SESSION['member_id'] = $member['id'];
        header("Location: dashboard.php");
        exit;
    } else {
        // Optional: log the failure reason
        error_log("Member login failed for $admno - " . ($member ? 'wrong password or missing hash' : 'not found or inactive'));
        $error = "Invalid Admission Number or Password. If you don't have a password, please contact the library.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Login - <?= htmlspecialchars($institutionName) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; }
        .login-card { max-width: 450px; margin: auto; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); background: white; }
        .login-card .card-body { padding: 2rem; }
        .logo { font-size: 48px; margin-bottom: 0.5rem; }
        .institution-logo { max-height: 60px; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card login-card">
            <div class="card-body text-center">
                <?php if ($logo): ?>
                    <img src="<?= $logo ?>" class="institution-logo" alt="Logo">
                <?php else: ?>
                    <div class="logo"><i class="fas fa-user-circle text-primary"></i></div>
                <?php endif; ?>
                <h4 class="mb-3"><?= htmlspecialchars($institutionName) ?> – Member Portal</h4>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Admission / Member Number</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                            <input type="text" name="admno" class="form-control" required autofocus>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
                <hr class="my-4">
                <p class="small text-muted">Default password (if set by admin): <strong>123456</strong></p>
                <a href="../opac/" class="btn btn-link btn-sm">Public Catalog (OPAC)</a>
            </div>
        </div>
    </div>
</body>
</html>