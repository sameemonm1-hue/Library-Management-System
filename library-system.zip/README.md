# 📚 LibERP - Library ERP System for Schools & Colleges

![Version](https://img.shields.io/badge/version-1.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4)
![MySQL](https://img.shields.io/badge/MySQL-5.7+-4479A1)
![Status](https://img.shields.io/badge/status-stable-brightgreen)

> **Lightweight, powerful, and free** – Library ERP software designed specifically for schools and medium-level colleges.

---

## 🎯 Overview

**LibERP** bridges the gap between basic library management systems and expensive commercial ERPs. It handles cataloging, circulation, member management, fines, reporting, and academic integration – all with an intuitive interface that requires minimal training.

| Target Audience | Suitable For |
|----------------|---------------|
| 🏫 Schools (K-12) | 500 - 5,000 students |
| 🎓 Medium Colleges | 5,000 - 10,000 students |
| 🏛️ Educational Trusts | Multiple small libraries |
| 💰 Budget-conscious institutions | Zero licensing cost |

---

## ✨ Key Features

### 📖 Library Management
- **Book Cataloging** – Add/edit/delete books with title, author, ISBN, publisher, edition
- **Barcode & QR Support** – Fast check-in/check-out with standard scanners
- **Multi-Copy Management** – Track multiple copies of same book
- **Subject/Genre Classification** – Organize by curriculum subjects
- **Bulk Import/Export** – CSV/Excel upload for books and members

### 👥 Member Management
- **Role-Based Access** – Admin, Librarian, Teacher, Student
- **Student Integration** – Sync with class, section, roll number, academic year
- **Temporary Memberships** – For summer programs or guest lecturers
- **Digital Member ID** – Printable barcode/QR ID cards

### ⚡ Circulation
- **Issue & Return** – One-click check-in/check-out
- **Auto-Fine Calculation** – Configurable fine per day
- **Renewals** – Online/offline renewal with max limit control
- **Reservations/Holds** – Students can reserve issued books
- **Due Date Alerts** – Email/SMS reminders before and after due date

### 🔍 OPAC (Online Public Access Catalog)
- **Student Self-Service** – Search books by title, author, subject, keyword
- **Availability Status** – Shows in-library, issued, or reserved
- **Personal Dashboard** – View borrowed books, due dates, fines
- **No Login Required for Search** – Guest access available

### 📊 Reports & Analytics
| Report Type | Description |
|-------------|-------------|
| Book Issue History | Track all transactions |
| Popular Books | Most borrowed books ranking |
| Pending Dues | Students with outstanding fines |
| Lost Books | Books marked as lost with penalty |
| Department-wise Usage | Subject/library usage patterns |
| Inventory Report | Complete book list with status |

### 🔔 Notifications
- **Email Alerts** – Issue confirmation, due reminders, fine notice
- **SMS Integration** – Optional via third-party API
- **In-App Notifications** – Dashboard alerts for overdue books

### 🏢 Multi-Branch Support
- Manage main library + departmental libraries
- Cross-branch book transfers
- Centralized member database

---

## 🚀 Benefits for Your Institution

| Benefit | Why It Matters |
|---------|----------------|
| 💰 **100% Free** | No licensing fees – invest in books instead of software |
| 🔒 **Data Privacy** | Self-hosted – your data never leaves your campus |
| ⚡ **Easy to Use** | Librarians learn in 1 day, students in 10 minutes |
| 📈 **Scalable** | Handles 50,000+ books and 10,000+ users smoothly |
| 🎓 **Academic Ready** | Class-wise book issuance, subject-based cataloging |
| 🛠️ **Low Maintenance** | Runs on basic hardware, minimal IT support needed |
| 🌐 **Campus Wide** | Accessible from any device on your network |
| 📤 **Import Ready** | Migrate from Excel/CSV – no manual data entry |

---

## 📋 System Requirements

### Minimum Requirements
| Component | Specification |
|-----------|---------------|
| **Web Server** | Apache 2.4+ / Nginx |
| **PHP** | 7.4 or 8.x |
| **Database** | MySQL 5.7+ / MariaDB 10.2+ / PostgreSQL 12+ |
| **RAM** | 2GB (minimum) |
| **Storage** | 1GB + space for book covers |
| **OS** | Linux (Ubuntu/Debian/CentOS), Windows, macOS |

### Recommended for 5,000+ Users
| Component | Specification |
|-----------|---------------|
| **RAM** | 4GB+ |
| **CPU** | 2+ cores |
| **Storage** | 10GB+ SSD |
| **Network** | Gigabit LAN |

### Browser Support
- Chrome (latest)
- Firefox (latest)
- Edge (latest)
- Safari (latest)

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| **Backend** | PHP 7.4/8.x |
| **Database** | MySQL / MariaDB |
| **Frontend** | HTML5, CSS3, JavaScript |
| **CSS Framework** | Bootstrap 5 |
| **JavaScript** | jQuery, DataTables, Chart.js |
| **Reports** | TCPDF / FPDF |
| **Barcode** | JsBarcode |

---

## 📥 Installation Guide

### Quick Install (5 Minutes)

```bash
# 1. Clone repository
git clone https://github.com/yourusername/LibERP.git
cd LibERP

# 2. Set permissions
chmod 755 -R storage/ uploads/

# 3. Create database
mysql -u root -p
CREATE DATABASE liberp;
EXIT;

# 4. Import schema
mysql -u root -p liberp < database/liberp_schema.sql

# 5. Configure
cp config/config.sample.php config/config.php
# Edit config.php with your database credentials

# 6. Access installer
# Open browser: http://yourdomain.com/LibERP/install