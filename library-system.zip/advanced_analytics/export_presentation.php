<?php
/**
 * Export Analytics Data to PowerPoint Presentation
 * Requires PhpOffice/PhpSpreadsheet library (optional, here we generate HTML)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

$range = $_GET['range'] ?? 'year';
$fromDate = $_GET['from_date'] ?? date('Y-m-01');
$toDate = $_GET['to_date'] ?? date('Y-m-d');
$classFilter = $_GET['class'] ?? '';
$divisionFilter = $_GET['division'] ?? '';

// Build date condition
$dateCondition = "1=1";
if ($range === 'today') {
    $dateCondition = "DATE(issue_date) = DATE('now')";
} elseif ($range === 'week') {
    $dateCondition = "issue_date >= DATE('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCondition = "strftime('%Y-%m', issue_date) = strftime('%Y-%m', 'now')";
} elseif ($range === 'year') {
    $dateCondition = "strftime('%Y', issue_date) = strftime('%Y', 'now')";
} elseif ($range === 'custom') {
    $dateCondition = "issue_date BETWEEN '$fromDate' AND '$toDate'";
}

// Get all data for presentation
$data = [];

// Stats
$stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE $dateCondition");
$stmt->execute();
$data['total_issued'] = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE return_date IS NOT NULL AND $dateCondition");
$stmt->execute();
$data['total_returned'] = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(DISTINCT admno) FROM circulation WHERE $dateCondition");
$stmt->execute();
$data['active_members'] = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT SUM(fine) FROM circulation WHERE $dateCondition");
$stmt->execute();
$data['total_fine'] = $stmt->fetchColumn() ?: 0;

// Class-wise stats
$stmt = $db->prepare("
    SELECT m.class, COUNT(c.id) as total_issued
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE $dateCondition
    GROUP BY m.class
    ORDER BY total_issued DESC
");
$stmt->execute();
$data['class_stats'] = $stmt->fetchAll();

// Top users
$stmt = $db->prepare("
    SELECT m.name, m.admno, m.class, COUNT(c.id) as total_issued
    FROM members m
    LEFT JOIN circulation c ON m.admno = c.admno AND $dateCondition
    WHERE m.status = 'active'
    GROUP BY m.admno
    ORDER BY total_issued DESC
    LIMIT 10
");
$stmt->execute();
$data['top_users'] = $stmt->fetchAll();

// Top books
$stmt = $db->prepare("
    SELECT b.title, b.author, b.category, COUNT(c.id) as issue_count
    FROM books b
    LEFT JOIN circulation c ON b.barcode = c.barcode AND $dateCondition
    GROUP BY b.barcode
    ORDER BY issue_count DESC
    LIMIT 10
");
$stmt->execute();
$data['top_books'] = $stmt->fetchAll();

// Daily trend (last 7 days)
$stmt = $db->prepare("
    SELECT DATE(issue_date) as date, COUNT(*) as issued
    FROM circulation 
    WHERE issue_date >= DATE('now', '-7 days')
    GROUP BY DATE(issue_date)
    ORDER BY date
");
$stmt->execute();
$data['daily_trend'] = $stmt->fetchAll();

// Get settings
$institution = getInstitution();

// Generate HTML presentation
header('Content-Type: text/html');
header('Content-Disposition: attachment; filename="library_analytics_presentation_' . date('Y-m-d') . '.html"');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Library Analytics Presentation</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; padding: 40px; }
        .slide { background: white; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); margin-bottom: 40px; page-break-after: always; overflow: hidden; min-height: 500px; }
        .slide-header { background: linear-gradient(135deg, #1e3c72, #2a5298); color: white; padding: 30px; text-align: center; }
        .slide-header h1 { font-size: 36px; margin-bottom: 10px; }
        .slide-header p { opacity: 0.9; font-size: 16px; }
        .slide-body { padding: 30px; }
        .slide-title { font-size: 28px; color: #1e3c72; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 3px solid #1e3c72; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
        .stat-card { background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 15px; padding: 20px; text-align: center; }
        .stat-value { font-size: 36px; font-weight: bold; color: #1e3c72; }
        .stat-label { color: #6c757d; margin-top: 5px; }
        .data-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .data-table th, .data-table td { padding: 12px; text-align: left; border-bottom: 1px solid #dee2e6; }
        .data-table th { background: #1e3c72; color: white; font-weight: 600; }
        .data-table tr:hover { background: #f8f9fa; }
        .footer { text-align: center; padding: 20px; font-size: 12px; color: #6c757d; background: #f8f9fa; }
        @media print { body { padding: 0; background: white; } .slide { box-shadow: none; border: 1px solid #ddd; page-break-after: always; } }
    </style>
</head>
<body>
    <!-- Slide 1: Title -->
    <div class="slide">
        <div class="slide-header">
            <?php if(!empty($institution['logo_path']) && file_exists($institution['logo_path'])): ?>
                <img src="<?= str_replace(dirname(__DIR__), '', $institution['logo_path']) ?>" style="height: 60px; margin-bottom: 20px;">
            <?php endif; ?>
            <h1>Library Analytics Report</h1>
            <p><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></p>
            <p style="margin-top: 20px;">Generated: <?= date('F j, Y g:i A') ?></p>
            <p>Date Range: <?= ucfirst($range) ?> <?= $range === 'custom' ? "($fromDate to $toDate)" : '' ?></p>
            <?php if($classFilter): ?><p>Class/Dept Filter: <?= htmlspecialchars($classFilter) ?></p><?php endif; ?>
            <?php if($divisionFilter): ?><p>Div/Course Filter: <?= htmlspecialchars($divisionFilter) ?></p><?php endif; ?>
        </div>
        <div class="slide-body">
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-value"><?= number_format($data['total_issued']) ?></div><div class="stat-label">Total Books Issued</div></div>
                <div class="stat-card"><div class="stat-value"><?= number_format($data['total_returned']) ?></div><div class="stat-label">Total Books Returned</div></div>
                <div class="stat-card"><div class="stat-value"><?= number_format($data['active_members']) ?></div><div class="stat-label">Active Members</div></div>
                <div class="stat-card"><div class="stat-value"><?= htmlspecialchars($currencySymbol) ?><?= number_format($data['total_fine'], 2) ?></div><div class="stat-label">Total Fine Collected</div></div>
            </div>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. All rights reserved.</p></div>
    </div>

    <!-- Slide 2: Class-wise Circulation -->
    <div class="slide">
        <div class="slide-header" style="background: linear-gradient(135deg, #28a745, #20c997);"><h1>Class/Dept-wise Circulation</h1><p>Distribution by Class/Department</p></div>
        <div class="slide-body">
            <table class="data-table">
                <thead><tr><th>Class/Dept</th><th>Total Books Issued</th><th>Percentage</th></tr></thead>
                <tbody>
                    <?php $total = array_sum(array_column($data['class_stats'], 'total_issued')); ?>
                    <?php foreach($data['class_stats'] as $stat): $percentage = $total > 0 ? round(($stat['total_issued'] / $total) * 100, 1) : 0; ?>
                    <tr><td><strong><?= htmlspecialchars($stat['class'] ?? 'Unspecified') ?></strong></td><td><?= number_format($stat['total_issued']) ?></td><td><div style="background:#e9ecef; border-radius:10px; overflow:hidden; width:150px; display:inline-block;"><div style="background:#28a745; width:<?= $percentage ?>%; height:20px;"></div></div> <?= $percentage ?>%</td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
    </div>

    <!-- Slide 3: Top 10 Users -->
    <div class="slide">
        <div class="slide-header" style="background: linear-gradient(135deg, #ffc107, #fd7e14);"><h1>Top 10 Library Users</h1><p>Most active members</p></div>
        <div class="slide-body">
            <table class="data-table">
                <thead><tr><th>Rank</th><th>Member Name</th><th>Adm/Mem No</th><th>Class/Dept</th><th>Books Issued</th></tr></thead>
                <tbody><?php foreach($data['top_users'] as $index => $user): ?>
                    <tr><td><?= $index+1 ?></td><td><strong><?= htmlspecialchars($user['name']) ?></strong></td><td><?= htmlspecialchars($user['admno']) ?></td><td><?= htmlspecialchars($user['class'] ?? '-') ?></td><td><span style="background:#1e3c72; color:white; padding:4px 12px; border-radius:20px;"><?= $user['total_issued'] ?></span></td></tr>
                <?php endforeach; ?></tbody>
            </table>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
    </div>

    <!-- Slide 4: Top 10 Most Issued Books -->
    <div class="slide">
        <div class="slide-header" style="background: linear-gradient(135deg, #dc3545, #c82333);"><h1>Most Popular Books</h1><p>Top 10 most issued books</p></div>
        <div class="slide-body">
            <table class="data-table">
                <thead><tr><th>Rank</th><th>Title</th><th>Author</th><th>Category</th><th>Times Issued</th></tr></thead>
                <tbody><?php foreach($data['top_books'] as $index => $book): ?>
                    <tr><td><strong><?= $index+1 ?></strong></td><td><?= htmlspecialchars($book['title']) ?></td><td><?= htmlspecialchars($book['author'] ?? 'Unknown') ?></td><td><?= htmlspecialchars($book['category'] ?? 'Uncategorized') ?></td><td><span style="background:#dc3545; color:white; padding:4px 12px; border-radius:20px;"><?= $book['issue_count'] ?></span></td></tr>
                <?php endforeach; ?></tbody>
            </table>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
    </div>

    <!-- Slide 5: Daily Trend -->
    <div class="slide">
        <div class="slide-header" style="background: linear-gradient(135deg, #17a2b8, #138496);"><h1>Daily Trend</h1><p>Last 7 days circulation</p></div>
        <div class="slide-body">
            <table class="data-table">
                <thead><tr><th>Date</th><th>Books Issued</th></tr></thead>
                <tbody><?php foreach($data['daily_trend'] as $trend): ?>
                    <tr><td><?= date('F j, Y', strtotime($trend['date'])) ?></td><td><span style="background:#17a2b8; color:white; padding:4px 12px; border-radius:20px;"><?= $trend['issued'] ?></span></td></tr>
                <?php endforeach; ?></tbody>
            </table>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
    </div>

    <!-- Slide 6: Key Insights -->
    <div class="slide">
        <div class="slide-header" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6);"><h1>Key Insights</h1><p>Summary and recommendations</p></div>
        <div class="slide-body">
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-value"><?= round(($data['total_returned'] / max($data['total_issued'], 1)) * 100, 1) ?>%</div><div class="stat-label">Return Rate</div></div>
                <div class="stat-card"><div class="stat-value"><?= round(($data['total_issued'] / max($data['active_members'], 1)), 1) ?></div><div class="stat-label">Avg Books Per Member</div></div>
            </div>
            <ul style="margin-top: 30px; line-height: 2;">
                <li>📚 Total circulation: <strong><?= number_format($data['total_issued']) ?></strong> books issued</li>
                <li>✅ Return rate: <strong><?= round(($data['total_returned'] / max($data['total_issued'], 1)) * 100, 1) ?>%</strong></li>
                <li>👥 Active members: <strong><?= number_format($data['active_members']) ?></strong></li>
                <li>💰 Total fines collected: <strong><?= htmlspecialchars($currencySymbol) ?><?= number_format($data['total_fine'], 2) ?></strong></li>
                <li>📖 Most popular category: <strong><?= htmlspecialchars($data['top_books'][0]['category'] ?? 'N/A') ?></strong></li>
                <li>🏆 Top user: <strong><?= htmlspecialchars($data['top_users'][0]['name'] ?? 'N/A') ?></strong></li>
            </ul>
        </div>
        <div class="footer"><p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
    </div>
</body>
</html>