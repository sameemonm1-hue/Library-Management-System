<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

// Fetch data for charts
// Top 10 borrowed books
$topBooks = $db->query("
    SELECT b.title, COUNT(c.id) as borrow_count 
    FROM circulation c 
    JOIN books b ON c.barcode = b.barcode 
    GROUP BY c.barcode 
    ORDER BY borrow_count DESC 
    LIMIT 10
")->fetchAll();

// Monthly circulation (last 12 months)
$monthlyData = $db->query("
    SELECT strftime('%Y-%m', issue_date) as month, COUNT(*) as issued
    FROM circulation 
    WHERE issue_date >= date('now', '-12 months')
    GROUP BY month
    ORDER BY month ASC
")->fetchAll();

// Member status stats
$memberStats = $db->query("
    SELECT status, COUNT(*) as count 
    FROM members 
    GROUP BY status
")->fetchAll();

// Fine collection (last 6 months)
$fineData = $db->query("
    SELECT strftime('%Y-%m', payment_date) as month, SUM(amount) as total
    FROM payment_transactions 
    WHERE payment_type = 'fine' 
    AND payment_date >= date('now', '-6 months')
    GROUP BY month
    ORDER BY month ASC
")->fetchAll();

renderHeader('Advanced Analytics');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-chart-line"></i> Advanced Analytics Dashboard</h2>
        <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
    </div>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">📚 Most Borrowed Books</div>
                <div class="card-body">
                    <canvas id="topBooksChart" height="300"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">📅 Monthly Circulation Trend</div>
                <div class="card-body">
                    <canvas id="monthlyChart" height="300"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-info text-white">👥 Member Status</div>
                <div class="card-body">
                    <canvas id="memberStatusChart" height="300"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-warning text-white">💰 Fine Collection (Last 6 months)</div>
                <div class="card-body">
                    <canvas id="fineChart" height="300"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Real-time KPI cards -->
    <div class="row mt-3">
        <div class="col-md-3">
            <div class="card text-center bg-dark text-white">
                <div class="card-body">
                    <h3><?= number_format($db->query("SELECT COUNT(*) FROM members")->fetchColumn()) ?></h3>
                    <p>Total Members</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center bg-primary text-white">
                <div class="card-body">
                    <h3><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn()) ?></h3>
                    <p>Active Loans</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center bg-danger text-white">
                <div class="card-body">
                    <h3><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn()) ?></h3>
                    <p>Overdue Books</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center bg-success text-white">
                <div class="card-body">
                    <h3><?= $currencySymbol ?><?= number_format($db->query("SELECT COALESCE(SUM(amount),0) FROM payment_transactions WHERE payment_type='fine'")->fetchColumn(), 2) ?></h3>
                    <p>Total Fines Collected</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Top Books Chart (Bar)
const topBooksCtx = document.getElementById('topBooksChart').getContext('2d');
new Chart(topBooksCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($topBooks, 'title')) ?>,
        datasets: [{
            label: 'Times Borrowed',
            data: <?= json_encode(array_column($topBooks, 'borrow_count')) ?>,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: { responsive: true, maintainAspectRatio: true }
});

// Monthly Circulation (Line)
const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
new Chart(monthlyCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($monthlyData, 'month')) ?>,
        datasets: [{
            label: 'Books Issued',
            data: <?= json_encode(array_column($monthlyData, 'issued')) ?>,
            borderColor: 'green',
            backgroundColor: 'rgba(0,128,0,0.1)',
            fill: true,
            tension: 0.3
        }]
    },
    options: { responsive: true }
});

// Member Status (Pie)
const memberCtx = document.getElementById('memberStatusChart').getContext('2d');
new Chart(memberCtx, {
    type: 'pie',
    data: {
        labels: <?= json_encode(array_column($memberStats, 'status')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($memberStats, 'count')) ?>,
            backgroundColor: ['#28a745', '#dc3545', '#ffc107']
        }]
    },
    options: { responsive: true }
});

// Fine Collection (Bar)
const fineCtx = document.getElementById('fineChart').getContext('2d');
new Chart(fineCtx, {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_column($fineData, 'month')) ?>,
        datasets: [{
            label: 'Fines (<?= $currencySymbol ?>)',
            data: <?= json_encode(array_column($fineData, 'total')) ?>,
            backgroundColor: '#f39c12'
        }]
    },
    options: { responsive: true }
});
</script>

<?php renderFooter(); ?>