// Analytics JavaScript with Presentation Export

let charts = {};

function getFilterParams() {
    const params = new URLSearchParams();
    const dateRange = document.getElementById('dateRange')?.value || 'year';
    const fromDate = document.getElementById('fromDate')?.value || '';
    const toDate = document.getElementById('toDate')?.value || '';
    const classFilter = document.getElementById('classFilter')?.value || '';
    const divisionFilter = document.getElementById('divisionFilter')?.value || '';
    
    if (dateRange === 'custom' && fromDate && toDate) {
        params.append('range', 'custom');
        params.append('from_date', fromDate);
        params.append('to_date', toDate);
    } else if (dateRange !== 'all') {
        params.append('range', dateRange);
    }
    if (classFilter) params.append('class', classFilter);
    if (divisionFilter) params.append('division', divisionFilter);
    return params;
}

function loadAnalyticsData() {
    showLoading();
    const params = getFilterParams();
    fetch('data_api.php?' + params.toString())
        .then(response => response.json())
        .then(data => {
            updateDashboard(data);
            hideLoading();
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Failed to load analytics data');
            hideLoading();
        });
}

function updateDashboard(data) {
    document.getElementById('totalIssued').innerText = data.stats?.total_issued || 0;
    document.getElementById('totalReturned').innerText = data.stats?.total_returned || 0;
    document.getElementById('activeMembers').innerText = data.stats?.active_members || 0;
    document.getElementById('totalFine').innerText = '$' + (data.stats?.total_fine || 0).toFixed(2);
    
    updateIssueReturnChart(data.issue_return);
    updateDailyTrendChart(data.daily_trend);
    updateMonthlyChart(data.monthly_trend);
    updateClassChart(data.class_stats);
    updateDivisionChart(data.division_stats);
    updateClassDivisionTable(data.class_division_details);
    updateTopUsersTable(data.top_users);
    updateYearlyTrendChart(data.yearly_trend);
    updateWeeklyTrendChart(data.weekly_trend);
    updateHourlyChart(data.hourly_distribution);
    updateTopBooksChart(data.top_books);
    updateCategoryChart(data.category_stats);
    updateTopBooksTable(data.top_books);
}

function updateIssueReturnChart(data) {
    const ctx = document.getElementById('issueReturnChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.issueReturn) charts.issueReturn.destroy();
    charts.issueReturn = new Chart(ctx, {
        type: 'doughnut',
        data: { labels: ['Books Issued', 'Books Returned'], datasets: [{ data: [data?.issued || 0, data?.returned || 0], backgroundColor: ['#28a745', '#17a2b8'], borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom' } } }
    });
}

function updateDailyTrendChart(data) {
    const ctx = document.getElementById('dailyTrendChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.dailyTrend) charts.dailyTrend.destroy();
    charts.dailyTrend = new Chart(ctx, {
        type: 'line',
        data: { labels: data?.map(d => d.date) || [], datasets: [{ label: 'Issued', data: data?.map(d => d.issued) || [], borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', fill: true, tension: 0.4 }, { label: 'Returned', data: data?.map(d => d.returned) || [], borderColor: '#17a2b8', backgroundColor: 'rgba(23,162,184,0.1)', fill: true, tension: 0.4 }] },
        options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
    });
}

function updateMonthlyChart(data) {
    const ctx = document.getElementById('monthlyChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.monthly) charts.monthly.destroy();
    charts.monthly = new Chart(ctx, {
        type: 'bar',
        data: { labels: data?.map(d => d.month) || [], datasets: [{ label: 'Issued', data: data?.map(d => d.issued) || [], backgroundColor: '#28a745' }, { label: 'Returned', data: data?.map(d => d.returned) || [], backgroundColor: '#17a2b8' }] },
        options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }
    });
}

function updateClassChart(data) {
    const ctx = document.getElementById('classChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.classChart) charts.classChart.destroy();
    charts.classChart = new Chart(ctx, { type: 'bar', data: { labels: data?.map(d => d.class || 'Unspecified') || [], datasets: [{ label: 'Books Issued', data: data?.map(d => d.total_issued) || [], backgroundColor: '#1e3c72' }] }, options: { responsive: true, maintainAspectRatio: true, scales: { y: { beginAtZero: true } } } });
}

function updateDivisionChart(data) {
    const ctx = document.getElementById('divisionChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.divisionChart) charts.divisionChart.destroy();
    charts.divisionChart = new Chart(ctx, { type: 'pie', data: { labels: data?.map(d => d.division || 'No Division') || [], datasets: [{ data: data?.map(d => d.total_issued) || [], backgroundColor: ['#1e3c72', '#2a5298', '#28a745', '#ffc107', '#dc3545', '#17a2b8'] }] }, options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'right' } } } });
}

function updateClassDivisionTable(data) {
    const tbody = document.querySelector('#classDivisionTable tbody');
    if (!tbody) return;
    if (!data || data.length === 0) { tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No data available</td></tr>'; return; }
    let html = '';
    data.forEach(row => { html += `<tr><td><strong>${escapeHtml(row.class || 'All')}</strong></td><td>${escapeHtml(row.division || 'All')}</td><td class="text-center">${row.total_issued}</td><td class="text-center">${row.total_returned}</td><td class="text-center">${row.active_members}</td><td class="text-end">$${(row.total_fine || 0).toFixed(2)}</td></tr>`; });
    tbody.innerHTML = html;
}

function updateTopUsersTable(users) {
    const tbody = document.querySelector('#topUsersTable tbody');
    if (!tbody) return;
    if (!users || users.length === 0) { tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No data available</td></tr>'; return; }
    let html = '';
    users.forEach((user, index) => {
        const rankClass = index === 0 ? 'rank-1' : (index === 1 ? 'rank-2' : (index === 2 ? 'rank-3' : 'rank-other'));
        const rankIcon = index === 0 ? '🥇' : (index === 1 ? '🥈' : (index === 2 ? '🥉' : index + 1));
        const photoHtml = user.photo_path ? `<img src="../${user.photo_path.replace(/^.*?uploads/, 'uploads')}" style="width: 35px; height: 35px; border-radius: 50%; object-fit: cover;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'35\' height=\'35\' viewBox=\'0 0 24 24\' fill=\'%23999\'%3E%3Cpath d=\'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z\'/%3E%3C/svg%3E'">` : '<i class="fas fa-user-circle fa-2x text-muted"></i>';
        html += `<tr><td class="text-center"><span style="display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;${index===0?'background:#FFD700':(index===1?'background:#C0C0C0':(index===2?'background:#CD7F32':'background:#6c757d'))};color:${index<3?'#000':'#fff'}">${rankIcon}</span></td><td class="text-center">${photoHtml}</td><td>${escapeHtml(user.admno)}</td><td><strong>${escapeHtml(user.name)}</strong></td><td>${escapeHtml(user.class || '-')}</td><td>${escapeHtml(user.division || '-')}</td><td class="text-center"><span class="badge bg-primary">${user.total_issued}</span></td><td class="text-center"><span class="badge bg-warning">${user.active_books || 0}</span></td><td class="text-end">$${(user.total_fines || 0).toFixed(2)}</td><td class="text-center"><button class="btn btn-sm btn-info" onclick="viewUserHistory('${escapeHtml(user.admno)}')"><i class="fas fa-history"></i> History</button></td></tr>`;
    });
    tbody.innerHTML = html;
}

function updateYearlyTrendChart(data) {
    const ctx = document.getElementById('yearlyTrendChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.yearlyTrend) charts.yearlyTrend.destroy();
    charts.yearlyTrend = new Chart(ctx, { type: 'line', data: { labels: data?.map(d => d.year) || [], datasets: [{ label: 'Books Issued', data: data?.map(d => d.issued) || [], borderColor: '#1e3c72', fill: true, tension: 0.4 }] }, options: { responsive: true } });
}

function updateWeeklyTrendChart(data) {
    const ctx = document.getElementById('weeklyTrendChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.weeklyTrend) charts.weeklyTrend.destroy();
    charts.weeklyTrend = new Chart(ctx, { type: 'bar', data: { labels: data?.map(d => d.week_label) || [], datasets: [{ label: 'Books Issued', data: data?.map(d => d.issued) || [], backgroundColor: '#ffc107' }] }, options: { responsive: true, scales: { y: { beginAtZero: true } } } });
}

function updateHourlyChart(data) {
    const ctx = document.getElementById('hourlyChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.hourly) charts.hourly.destroy();
    charts.hourly = new Chart(ctx, { type: 'bar', data: { labels: data?.map(d => d.hour + ':00') || [], datasets: [{ label: 'Transactions', data: data?.map(d => d.count) || [], backgroundColor: '#17a2b8' }] }, options: { responsive: true, scales: { y: { beginAtZero: true } } } });
}

function updateTopBooksChart(books) {
    const ctx = document.getElementById('topBooksChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.topBooks) charts.topBooks.destroy();
    const top10 = books?.slice(0, 10) || [];
    charts.topBooks = new Chart(ctx, { type: 'bar', data: { labels: top10.map(b => b.title.length > 25 ? b.title.substring(0, 25) + '...' : b.title), datasets: [{ label: 'Times Issued', data: top10.map(b => b.issue_count), backgroundColor: '#28a745' }] }, options: { responsive: true, indexAxis: 'y', scales: { x: { beginAtZero: true } } } });
}

function updateCategoryChart(data) {
    const ctx = document.getElementById('categoryChart')?.getContext('2d');
    if (!ctx) return;
    if (charts.category) charts.category.destroy();
    charts.category = new Chart(ctx, { type: 'pie', data: { labels: data?.map(d => d.category) || [], datasets: [{ data: data?.map(d => d.count) || [], backgroundColor: ['#1e3c72', '#2a5298', '#28a745', '#ffc107', '#dc3545', '#17a2b8'] }] }, options: { responsive: true, plugins: { legend: { position: 'right' } } } });
}

function updateTopBooksTable(books) {
    const tbody = document.querySelector('#topBooksTable tbody');
    if (!tbody) return;
    if (!books || books.length === 0) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No data available</td></tr>'; return; }
    let html = '';
    books.slice(0, 20).forEach((book, index) => {
        const coverHtml = book.cover_path ? `<img src="../${book.cover_path.replace(/^.*?uploads/, 'uploads')}" style="width: 40px; height: 50px; object-fit: cover; border-radius: 4px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'40\' height=\'50\' viewBox=\'0 0 24 24\' fill=\'%23999\'%3E%3Cpath d=\'M4 6h16v12H4z\'/%3E%3C/svg%3E'">` : '<i class="fas fa-book fa-2x text-muted"></i>';
        html += `<tr><td class="text-center"><strong>${index + 1}</strong></td><td class="text-center">${coverHtml}</td><td><strong>${escapeHtml(book.title)}</strong></td><td>${escapeHtml(book.author || 'Unknown')}</td><td>${escapeHtml(book.publisher || '-')}</td><td><span class="badge bg-secondary">${escapeHtml(book.category || 'Uncategorized')}</span></td><td class="text-center"><span class="badge bg-primary">${book.issue_count}</span></td></tr>`;
    });
    tbody.innerHTML = html;
}

function viewUserHistory(admno) {
    const modalContent = document.getElementById('userHistoryContent');
    modalContent.innerHTML = '<div class="text-center p-4"><div class="spinner-border text-primary"></div><p class="mt-2">Loading user history...</p></div>';
    fetch(`data_api.php?action=user_history&admno=${encodeURIComponent(admno)}`)
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                let html = `<div class="alert alert-info">Total Transactions: <strong>${data.length}</strong></div><div class="table-responsive"><table class="table table-bordered"><thead class="table-light"><tr><th>Book Title</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Return Date</th><th>Fine</th><th>Status</th></tr></thead><tbody>`;
                data.forEach(trans => {
                    let status = !trans.return_date ? (new Date(trans.due_date) < new Date() ? '<span class="badge bg-danger">Overdue</span>' : '<span class="badge bg-warning">Issued</span>') : '<span class="badge bg-success">Returned</span>';
                    html += `<tr><td><strong>${escapeHtml(trans.title)}</strong></td><td>${escapeHtml(trans.author || 'Unknown')}</td><td>${trans.issue_date}</td><td>${trans.due_date}</td><td>${trans.return_date || '-'}</td><td>$${(trans.fine || 0).toFixed(2)}</td><td>${status}</td></tr>`;
                });
                html += `</tbody></table></div>`;
                modalContent.innerHTML = html;
            } else {
                modalContent.innerHTML = '<div class="alert alert-warning">No transaction history found for this user.</div>';
            }
        })
        .catch(error => { modalContent.innerHTML = '<div class="alert alert-danger">Error loading user history</div>'; });
    new bootstrap.Modal(document.getElementById('userHistoryModal')).show();
}

function exportExcel() { const params = getFilterParams(); window.location.href = 'export.php?' + params.toString(); }
function exportPresentation() { const params = getFilterParams(); window.open('export_presentation.php?' + params.toString(), '_blank'); }
function printReport() { window.print(); }
function applyFilters() { loadAnalyticsData(); }
function applyCustomDate() { document.getElementById('dateRange').value = 'custom'; loadAnalyticsData(); }
function showLoading() { document.getElementById('globalLoader').style.display = 'flex'; }
function hideLoading() { document.getElementById('globalLoader').style.display = 'none'; }
function showError(msg) { const toast = document.createElement('div'); toast.className = 'alert alert-danger position-fixed top-0 start-50 translate-middle-x mt-3'; toast.style.zIndex = '9999'; toast.style.minWidth = '300px'; toast.innerHTML = msg + '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'; document.body.appendChild(toast); setTimeout(() => toast.remove(), 5000); }
function escapeHtml(s) { if (!s) return ''; return s.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;')); }

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    loadAnalyticsData();
    document.querySelectorAll('.range-btn').forEach(btn => { btn.addEventListener('click', function() { document.querySelectorAll('.range-btn').forEach(b => b.classList.remove('active')); this.classList.add('active'); const range = this.dataset.range; document.getElementById('dateRange').value = range; document.getElementById('customDateRange').style.display = range === 'custom' ? 'flex' : 'none'; if (range !== 'custom') loadAnalyticsData(); }); });
    document.getElementById('applyFilters')?.addEventListener('click', applyFilters);
    document.getElementById('applyCustomDate')?.addEventListener('click', applyCustomDate);
    document.getElementById('exportExcel')?.addEventListener('click', exportExcel);
    document.getElementById('exportPresentation')?.addEventListener('click', exportPresentation);
    document.getElementById('printReport')?.addEventListener('click', printReport);
});