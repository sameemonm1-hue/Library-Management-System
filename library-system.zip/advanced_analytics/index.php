<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

// Handle AJAX API requests
if (isset($_GET['api'])) {
    header('Content-Type: application/json');
    try {
        $range = $_GET['range'] ?? 'year';
        $fromDate = $_GET['from_date'] ?? '';
        $toDate = $_GET['to_date'] ?? '';
        $class = $_GET['class'] ?? '';
        $division = $_GET['division'] ?? '';
        
        // If custom range provided, use it; else compute based on range presets
        if ($range === 'custom' && !empty($fromDate) && !empty($toDate)) {
            $startDate = $fromDate;
            $endDate = $toDate;
        } else {
            $endDate = date('Y-m-d');
            switch ($range) {
                case 'today': $startDate = $endDate; break;
                case 'week': $startDate = date('Y-m-d', strtotime('-7 days')); break;
                case 'month': $startDate = date('Y-m-01'); break;
                case 'year': $startDate = date('Y-01-01'); break;
                case 'all': $startDate = '2000-01-01'; break;
                default: $startDate = date('Y-01-01'); break;
            }
        }
        
        // Build filter condition for class/division on members
        $filterSql = "";
        $filterParams = [];
        if (!empty($class)) {
            $filterSql .= " AND m.class = ?";
            $filterParams[] = $class;
        }
        if (!empty($division)) {
            $filterSql .= " AND m.division = ?";
            $filterParams[] = $division;
        }
        
        $api = $_GET['api'];
        
        // ========== STATS CARDS ==========
        if ($api === 'stats') {
            $sql = "SELECT COUNT(*) as total FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $totalIssued = $stmt->fetchColumn();
            
            $sql = "SELECT COUNT(*) FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.return_date BETWEEN ? AND ? $filterSql";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $totalReturned = $stmt->fetchColumn();
            
            $sql = "SELECT COUNT(DISTINCT c.admno) FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $activeMembers = $stmt->fetchColumn();
            
            $sql = "SELECT COALESCE(SUM(c.fine),0) FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.return_date BETWEEN ? AND ? $filterSql";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $totalFine = $stmt->fetchColumn();
            
            echo json_encode([
                'totalIssued' => (int)$totalIssued,
                'totalReturned' => (int)$totalReturned,
                'activeMembers' => (int)$activeMembers,
                'totalFine' => (float)$totalFine
            ]);
            exit;
        }
        
        // ========== ISSUE VS RETURN PIE ==========
        if ($api === 'issueReturn') {
            $sql = "SELECT 
                        COUNT(CASE WHEN c.issue_date BETWEEN ? AND ? THEN 1 END) as issued,
                        COUNT(CASE WHEN c.return_date BETWEEN ? AND ? THEN 1 END) as returned
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE 1=1 $filterSql";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate, $startDate, $endDate], $filterParams));
            $row = $stmt->fetch();
            echo json_encode(['issued' => (int)$row['issued'], 'returned' => (int)$row['returned']]);
            exit;
        }
        
        // ========== DAILY TREND (LAST 7 DAYS) ==========
        if ($api === 'dailyTrend') {
            $sql = "SELECT DATE(c.issue_date) as date, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date >= DATE('now', '-6 days') $filterSql
                    GROUP BY DATE(c.issue_date) 
                    ORDER BY date";
            $stmt = $db->prepare($sql);
            $stmt->execute($filterParams);
            $rows = $stmt->fetchAll();
            $labels = [];
            $data = [];
            $start = new DateTime('-6 days');
            for ($i = 0; $i < 7; $i++) {
                $date = $start->modify('+'.($i==0?0:1).' day')->format('Y-m-d');
                $labels[] = $date;
                $found = false;
                foreach ($rows as $r) {
                    if ($r['date'] == $date) {
                        $data[] = $r['count'];
                        $found = true;
                        break;
                    }
                }
                if (!$found) $data[] = 0;
            }
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== MONTHLY CIRCULATION ==========
        if ($api === 'monthly') {
            $sql = "SELECT strftime('%Y-%m', c.issue_date) as month, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql
                    GROUP BY strftime('%Y-%m', c.issue_date) 
                    ORDER BY month";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            $labels = array_column($rows, 'month');
            $data = array_column($rows, 'count');
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== CLASS WISE ==========
        if ($api === 'classWise') {
            $sql = "SELECT m.class, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? AND m.class IS NOT NULL AND m.class != '' $filterSql
                    GROUP BY m.class 
                    ORDER BY count DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            $labels = array_column($rows, 'class');
            $data = array_column($rows, 'count');
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== DIVISION WISE ==========
        if ($api === 'divisionWise') {
            $sql = "SELECT m.division, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? AND m.division IS NOT NULL AND m.division != '' $filterSql
                    GROUP BY m.division 
                    ORDER BY count DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            $labels = array_column($rows, 'division');
            $data = array_column($rows, 'count');
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== CLASS-DIVISION DETAILED TABLE ==========
        if ($api === 'classDivisionTable') {
            $sql = "SELECT m.class, m.division, 
                        COUNT(c.id) as total_issues,
                        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returns,
                        COUNT(DISTINCT c.admno) as active_members,
                        COALESCE(SUM(c.fine),0) as total_fine
                    FROM members m
                    LEFT JOIN circulation c ON c.admno = m.admno AND c.issue_date BETWEEN ? AND ?
                    WHERE m.class IS NOT NULL AND m.class != '' $filterSql
                    GROUP BY m.class, m.division
                    ORDER BY m.class, m.division";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            exit;
        }
        
        // ========== TOP 10 USERS ==========
        if ($api === 'topUsers') {
            $sql = "SELECT m.admno, m.name, m.class, m.division, m.photo_path,
                        COUNT(c.id) as total_books,
                        SUM(CASE WHEN c.return_date IS NULL THEN 1 ELSE 0 END) as currently_borrowed,
                        COALESCE(SUM(c.fine),0) as total_fine
                    FROM members m
                    JOIN circulation c ON c.admno = m.admno
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql
                    GROUP BY m.admno
                    ORDER BY total_books DESC
                    LIMIT 10";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            exit;
        }
        
        // ========== YEARLY TREND ==========
        if ($api === 'yearlyTrend') {
            $sql = "SELECT strftime('%Y', c.issue_date) as year, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql
                    GROUP BY strftime('%Y', c.issue_date) 
                    ORDER BY year";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            $labels = array_column($rows, 'year');
            $data = array_column($rows, 'count');
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== WEEKLY TREND (LAST 4 WEEKS) ==========
        if ($api === 'weeklyTrend') {
            $sql = "SELECT strftime('%W', c.issue_date) as week, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date >= DATE('now', '-28 days') $filterSql
                    GROUP BY strftime('%W', c.issue_date) 
                    ORDER BY week";
            $stmt = $db->prepare($sql);
            $stmt->execute($filterParams);
            $rows = $stmt->fetchAll();
            $labels = ['Week -4', 'Week -3', 'Week -2', 'Last Week'];
            $data = array_fill(0,4,0);
            foreach ($rows as $i => $r) {
                $data[$i] = $r['count'];
            }
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== HOURLY DISTRIBUTION ==========
        if ($api === 'hourly') {
            $sql = "SELECT strftime('%H', c.issue_date) as hour, COUNT(*) as count 
                    FROM circulation c 
                    JOIN members m ON c.admno = m.admno 
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql
                    GROUP BY strftime('%H', c.issue_date) 
                    ORDER BY hour";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            $labels = [];
            $data = [];
            for ($h=0;$h<24;$h++) {
                $labels[] = sprintf("%02d:00", $h);
                $data[] = 0;
            }
            foreach ($rows as $r) {
                $hour = (int)$r['hour'];
                $data[$hour] = (int)$r['count'];
            }
            echo json_encode(['labels' => $labels, 'data' => $data]);
            exit;
        }
        
        // ========== TOP 10 BOOKS ==========
        if ($api === 'topBooks') {
            $sql = "SELECT b.barcode, b.title, b.author, b.publisher, b.category, b.cover_path, COUNT(*) as times_issued
                    FROM circulation c
                    JOIN books b ON c.barcode = b.barcode
                    WHERE c.issue_date BETWEEN ? AND ? $filterSql
                    GROUP BY b.barcode
                    ORDER BY times_issued DESC
                    LIMIT 10";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            exit;
        }
        
        // ========== CATEGORY DISTRIBUTION ==========
        if ($api === 'categoryDist') {
            $sql = "SELECT b.category, COUNT(*) as count
                    FROM circulation c
                    JOIN books b ON c.barcode = b.barcode
                    WHERE c.issue_date BETWEEN ? AND ? AND b.category IS NOT NULL AND b.category != '' $filterSql
                    GROUP BY b.category
                    ORDER BY count DESC
                    LIMIT 10";
            $stmt = $db->prepare($sql);
            $stmt->execute(array_merge([$startDate, $endDate], $filterParams));
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            exit;
        }
        
        // ========== USER HISTORY ==========
        if ($api === 'userHistory') {
            $admno = $_GET['admno'] ?? '';
            if (empty($admno)) throw new Exception("No user specified");
            $sql = "SELECT c.*, b.title, b.author 
                    FROM circulation c 
                    JOIN books b ON c.barcode = b.barcode 
                    WHERE c.admno = ? 
                    ORDER BY c.issue_date DESC 
                    LIMIT 20";
            $stmt = $db->prepare($sql);
            $stmt->execute([$admno]);
            $rows = $stmt->fetchAll();
            echo json_encode($rows);
            exit;
        }
        
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
        exit;
    }
}

// Load initial data for page (default filters)
$dateRange = $_GET['range'] ?? 'year';
$fromDate = $_GET['from_date'] ?? '';
$toDate = $_GET['to_date'] ?? '';
$selectedClass = $_GET['class'] ?? '';
$selectedDivision = $_GET['division'] ?? '';

// Get classes and divisions for filters
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

renderHeader('Advanced Analytics');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Analytics - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0/dist/chartjs-plugin-datalabels.min.js"></script>
    <style>
        .btn-purple { background: linear-gradient(135deg, #6f42c1, #8b5cf6); border: none; color: white; transition: all 0.3s; }
        .btn-purple:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(111,66,193,0.3); color: white; }
        .analytics-container { padding: 20px; background: #f8f9fa; min-height: 100vh; }
        .stat-card { background: white; border-radius: 15px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: transform 0.3s; position: relative; overflow: hidden; }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .stat-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; }
        .stat-card.primary::before { background: linear-gradient(90deg, #1e3c72, #2a5298); }
        .stat-card.success::before { background: linear-gradient(90deg, #28a745, #20c997); }
        .stat-card.warning::before { background: linear-gradient(90deg, #ffc107, #fd7e14); }
        .stat-card.info::before { background: linear-gradient(90deg, #17a2b8, #0dcaf0); }
        .stat-icon { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); font-size: 48px; opacity: 0.1; }
        .stat-value { font-size: 32px; font-weight: 700; margin-bottom: 5px; }
        .stat-label { color: #6c757d; font-size: 14px; font-weight: 500; }
        .filter-bar { background: white; padding: 20px; border-radius: 15px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .chart-card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .chart-title { font-size: 18px; font-weight: 600; color: #1e3c72; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #f0f2f5; }
        .range-btn { padding: 6px 16px; border: 1px solid #ddd; background: white; border-radius: 20px; font-size: 13px; cursor: pointer; transition: all 0.3s; }
        .range-btn:hover { background: #f0f2f5; border-color: #1e3c72; }
        .range-btn.active { background: #1e3c72; color: white; border-color: #1e3c72; }
        .nav-tabs .nav-link { color: #495057; border: none; border-bottom: 2px solid transparent; }
        .nav-tabs .nav-link.active { color: #1e3c72; border-bottom: 2px solid #1e3c72; background: transparent; }
        #globalLoader { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999; display: none; align-items: center; justify-content: center; }
        @media print { .filter-bar, .nav-tabs, .btn, .no-print, #globalLoader { display: none !important; } .chart-card, .stat-card { break-inside: avoid; } }
        .user-photo { width: 40px; height: 40px; object-fit: cover; border-radius: 50%; }
    </style>
</head>
<body>
<div class="analytics-container">
    <div class="container-fluid px-4">
        <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
            <h2><i class="fas fa-chart-line text-primary"></i> Advanced Analytics Dashboard</h2>
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Back to Home</a>
        </div>

        <!-- Filter Bar -->
        <div class="filter-bar">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="range-buttons">
                        <button class="range-btn" data-range="today">Today</button>
                        <button class="range-btn" data-range="week">This Week</button>
                        <button class="range-btn" data-range="month">This Month</button>
                        <button class="range-btn active" data-range="year">This Year</button>
                        <button class="range-btn" data-range="all">All Time</button>
                        <button class="range-btn" data-range="custom">Custom Range</button>
                    </div>
                </div>
                <div class="col-md-4">
                    <div id="customDateRange" style="display: none;" class="row g-2">
                        <div class="col-5"><input type="date" id="fromDate" class="form-control" value="<?= date('Y-m-01') ?>"></div>
                        <div class="col-5"><input type="date" id="toDate" class="form-control" value="<?= date('Y-m-d') ?>"></div>
                        <div class="col-2"><button id="applyCustomDate" class="btn btn-primary w-100">Go</button></div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <select id="classFilter" class="form-select"><option value="">All Classes/Dept</option><?php foreach($classes as $c): ?><option value="<?= htmlspecialchars($c) ?>" <?= $selectedClass==$c?'selected':'' ?>><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select>
                </div>
                <div class="col-md-3">
                    <select id="divisionFilter" class="form-select"><option value="">All Divisions/Courses</option><?php foreach($divisions as $d): ?><option value="<?= htmlspecialchars($d) ?>" <?= $selectedDivision==$d?'selected':'' ?>><?= htmlspecialchars($d) ?></option><?php endforeach; ?></select>
                </div>
                <div class="col-md-2"><button id="applyFilters" class="btn btn-primary w-100"><i class="fas fa-filter"></i> Apply</button></div>
                <div class="col-md-2"><button id="exportExcel" class="btn btn-success w-100"><i class="fas fa-file-excel"></i> Excel</button></div>
                <div class="col-md-2"><button id="exportPresentation" class="btn btn-purple w-100"><i class="fas fa-file-powerpoint"></i> Presentation</button></div>
                <div class="col-md-2"><button id="printReport" class="btn btn-info w-100"><i class="fas fa-print"></i> Print</button></div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3"><div class="stat-card primary"><div class="stat-icon"><i class="fas fa-book"></i></div><div class="stat-value" id="totalIssued">--</div><div class="stat-label">Total Books Issued</div><small class="text-muted">In selected period</small></div></div>
            <div class="col-md-3"><div class="stat-card success"><div class="stat-icon"><i class="fas fa-undo-alt"></i></div><div class="stat-value" id="totalReturned">--</div><div class="stat-label">Total Books Returned</div><small class="text-muted">In selected period</small></div></div>
            <div class="col-md-3"><div class="stat-card warning"><div class="stat-icon"><i class="fas fa-users"></i></div><div class="stat-value" id="activeMembers">--</div><div class="stat-label">Active Members</div><small class="text-muted">Who issued books</small></div></div>
            <div class="col-md-3"><div class="stat-card info"><div class="stat-icon"><i class="fas fa-dollar-sign"></i></div><div class="stat-value" id="totalFine">--</div><div class="stat-label">Total Fine Collected</div><small class="text-muted"><?= htmlspecialchars($currencySymbol) ?> (in period)</small></div></div>
        </div>

        <!-- Tabs -->
        <ul class="nav nav-tabs mb-3" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#overview"><i class="fas fa-chart-pie"></i> Overview</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#classDivision"><i class="fas fa-school"></i> Class & Division</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#topUsers"><i class="fas fa-trophy"></i> Top Users</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#trends"><i class="fas fa-chart-line"></i> Trends</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#books"><i class="fas fa-book"></i> Popular Books</button></li>
        </ul>

        <div class="tab-content">
            <!-- Overview Tab -->
            <div class="tab-pane fade show active" id="overview">
                <div class="row">
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-pie"></i> Issue vs Return</div><canvas id="issueReturnChart" style="height: 300px;"></canvas></div></div>
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-line"></i> Daily Circulation (Last 7 Days)</div><canvas id="dailyTrendChart" style="height: 300px;"></canvas></div></div>
                </div>
                <div class="row"><div class="col-md-12"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-bar"></i> Monthly Circulation</div><canvas id="monthlyChart" style="height: 300px;"></canvas></div></div></div>
            </div>

            <!-- Class & Division Tab -->
            <div class="tab-pane fade" id="classDivision">
                <div class="row">
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-bar"></i> Class/Dept-wise Circulation</div><canvas id="classChart" style="height: 350px;"></canvas></div></div>
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-pie"></i> Div/Course-wise Distribution</div><canvas id="divisionChart" style="height: 350px;"></canvas></div></div>
                </div>
                <div class="row"><div class="col-md-12"><div class="chart-card"><div class="chart-title"><i class="fas fa-table"></i> Class/Dept & Div/Course Detailed Report</div><div class="table-responsive"><table class="table table-bordered table-hover" id="classDivisionTable"><thead class="table-light"><tr><th>Class/Dept</th><th>Div/Course</th><th>Total Issues</th><th>Total Returns</th><th>Active Members</th><th>Total Fine (<?= htmlspecialchars($currencySymbol) ?>)</th></tr></thead><tbody><tr><td colspan="6" class="text-center text-muted">Loading...</td></tr></tbody></table></div></div></div></div>
            </div>

            <!-- Top Users Tab -->
            <div class="tab-pane fade" id="topUsers">
                <div class="row"><div class="col-md-12"><div class="chart-card"><div class="chart-title"><i class="fas fa-trophy"></i> Top 10 Library Users</div><div class="table-responsive"><table class="table table-hover" id="topUsersTable"><thead class="table-light"><tr><th>Rank</th><th>Photo</th><th>Adm/Mem No</th><th>Member Name</th><th>Class/Dept</th><th>Div/Course</th><th>Total Books</th><th>Currently</th><th>Total Fine (<?= htmlspecialchars($currencySymbol) ?>)</th><th>Action</th></tr></thead><tbody><tr><td colspan="10" class="text-center text-muted">Loading...</td></tr></tbody></table></div></div></div></div>
            </div>

            <!-- Trends Tab -->
            <div class="tab-pane fade" id="trends">
                <div class="row">
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-line"></i> Yearly Trend</div><canvas id="yearlyTrendChart" style="height: 300px;"></canvas></div></div>
                    <div class="col-md-6"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-line"></i> Weekly Trend (Last 4 Weeks)</div><canvas id="weeklyTrendChart" style="height: 300px;"></canvas></div></div>
                </div>
                <div class="row"><div class="col-md-12"><div class="chart-card"><div class="chart-title"><i class="fas fa-calendar-alt"></i> Hourly Distribution</div><canvas id="hourlyChart" style="height: 300px;"></canvas></div></div></div>
            </div>

            <!-- Popular Books Tab -->
            <div class="tab-pane fade" id="books">
                <div class="row">
                    <div class="col-md-8"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-bar"></i> Top 10 Most Issued Books</div><canvas id="topBooksChart" style="height: 400px;"></canvas></div></div>
                    <div class="col-md-4"><div class="chart-card"><div class="chart-title"><i class="fas fa-chart-pie"></i> Category Distribution</div><canvas id="categoryChart" style="height: 350px;"></canvas></div></div>
                </div>
                <div class="row mt-3"><div class="col-md-12"><div class="chart-card"><div class="chart-title"><i class="fas fa-list"></i> Top Books Detailed List</div><div class="table-responsive"><table class="table table-hover" id="topBooksTable"><thead class="table-light"><tr><th>Rank</th><th>Cover</th><th>Title</th><th>Author</th><th>Publisher</th><th>Category</th><th>Times Issued</th></tr></thead><tbody><tr><td colspan="7" class="text-center text-muted">Loading...</td></tr></tbody></table></div></div></div></div>
            </div>
        </div>
    </div>
</div>

<!-- User History Modal -->
<div class="modal fade" id="userHistoryModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5 class="modal-title"><i class="fas fa-history"></i> User Transaction History</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body" id="userHistoryContent">Loading...</div>
        </div>
    </div>
</div>

<div id="globalLoader"><div class="spinner-border text-light" style="width: 3rem; height: 3rem;"></div></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Global chart variables
let charts = {};

// Helper: show/hide loader
function showLoader(show) {
    document.getElementById('globalLoader').style.display = show ? 'flex' : 'none';
}

// Get current filter values
function getFilters() {
    let range = document.querySelector('.range-btn.active')?.dataset.range || 'year';
    let fromDate = document.getElementById('fromDate')?.value || '';
    let toDate = document.getElementById('toDate')?.value || '';
    let classVal = document.getElementById('classFilter').value;
    let divisionVal = document.getElementById('divisionFilter').value;
    return { range, fromDate, toDate, class: classVal, division: divisionVal };
}

// Fetch data from API and update charts
async function fetchAllData() {
    showLoader(true);
    const filters = getFilters();
    const queryParams = new URLSearchParams(filters);
    queryParams.append('api', 'stats');
    try {
        // Stats
        let resp = await fetch(`?${queryParams}`);
        let stats = await resp.json();
        document.getElementById('totalIssued').innerText = stats.totalIssued;
        document.getElementById('totalReturned').innerText = stats.totalReturned;
        document.getElementById('activeMembers').innerText = stats.activeMembers;
        document.getElementById('totalFine').innerText = stats.totalFine;
        
        // Issue vs Return Pie
        queryParams.set('api', 'issueReturn');
        resp = await fetch(`?${queryParams}`);
        let ir = await resp.json();
        if (charts.issueReturn) charts.issueReturn.destroy();
        charts.issueReturn = new Chart(document.getElementById('issueReturnChart'), {
            type: 'pie',
            data: { labels: ['Issued', 'Returned'], datasets: [{ data: [ir.issued, ir.returned], backgroundColor: ['#1e3c72', '#28a745'] }] },
            options: { responsive: true, plugins: { legend: { position: 'bottom' }, datalabels: { color: 'white', formatter: (val) => val } } }
        });
        
        // Daily Trend
        queryParams.set('api', 'dailyTrend');
        resp = await fetch(`?${queryParams}`);
        let daily = await resp.json();
        if (charts.daily) charts.daily.destroy();
        charts.daily = new Chart(document.getElementById('dailyTrendChart'), {
            type: 'line', data: { labels: daily.labels, datasets: [{ label: 'Books Issued', data: daily.data, borderColor: '#1e3c72', tension: 0.3, fill: false }] }
        });
        
        // Monthly
        queryParams.set('api', 'monthly');
        resp = await fetch(`?${queryParams}`);
        let monthly = await resp.json();
        if (charts.monthly) charts.monthly.destroy();
        charts.monthly = new Chart(document.getElementById('monthlyChart'), {
            type: 'bar', data: { labels: monthly.labels, datasets: [{ label: 'Issues', data: monthly.data, backgroundColor: '#2a5298' }] }
        });
        
        // Class-wise
        queryParams.set('api', 'classWise');
        resp = await fetch(`?${queryParams}`);
        let classData = await resp.json();
        if (charts.classChart) charts.classChart.destroy();
        charts.classChart = new Chart(document.getElementById('classChart'), {
            type: 'bar', data: { labels: classData.labels, datasets: [{ label: 'Issues', data: classData.data, backgroundColor: '#fd7e14' }] }
        });
        
        // Division-wise
        queryParams.set('api', 'divisionWise');
        resp = await fetch(`?${queryParams}`);
        let divData = await resp.json();
        if (charts.division) charts.division.destroy();
        charts.division = new Chart(document.getElementById('divisionChart'), {
            type: 'pie', data: { labels: divData.labels, datasets: [{ data: divData.data, backgroundColor: ['#17a2b8','#ffc107','#28a745','#dc3545'] }] }
        });
        
        // Class-Division Table
        queryParams.set('api', 'classDivisionTable');
        resp = await fetch(`?${queryParams}`);
        let classDivTable = await resp.json();
        let tableHtml = '';
        classDivTable.forEach(row => {
            tableHtml += `<tr><td>${escapeHtml(row.class)}</td><td>${escapeHtml(row.division)}</td><td>${row.total_issues}</td><td>${row.total_returns}</td><td>${row.active_members}</td><td>${parseFloat(row.total_fine).toFixed(2)}</td></tr>`;
        });
        document.querySelector('#classDivisionTable tbody').innerHTML = tableHtml || '<tr><td colspan="6">No data</td></tr>';
        
        // Top Users
        queryParams.set('api', 'topUsers');
        resp = await fetch(`?${queryParams}`);
        let topUsers = await resp.json();
        let usersHtml = '';
        topUsers.forEach((u, idx) => {
            let photoHtml = u.photo_path && u.photo_path !== '' ? `<img src="../${u.photo_path}" class="user-photo" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23999%22%3E%3Cpath d=%22M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z%22/%3E%3C/svg%3E'>` : '<div class="user-photo d-inline-flex align-items-center justify-content-center bg-secondary text-white rounded-circle" style="width:40px;height:40px"><i class="fas fa-user"></i></div>';
            usersHtml += `<tr><td>${idx+1}</td><td>${photoHtml}</td><td>${escapeHtml(u.admno)}</td><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.class)}</td><td>${escapeHtml(u.division)}</td><td>${u.total_books}</td><td>${u.currently_borrowed}</td><td>${parseFloat(u.total_fine).toFixed(2)}</td><td><button class="btn btn-sm btn-info" onclick="viewUserHistory('${escapeHtml(u.admno)}')">History</button></td></tr>`;
        });
        document.querySelector('#topUsersTable tbody').innerHTML = usersHtml || '<tr><td colspan="10">No data</td></tr>';
        
        // Yearly Trend
        queryParams.set('api', 'yearlyTrend');
        resp = await fetch(`?${queryParams}`);
        let yearly = await resp.json();
        if (charts.yearly) charts.yearly.destroy();
        charts.yearly = new Chart(document.getElementById('yearlyTrendChart'), {
            type: 'line', data: { labels: yearly.labels, datasets: [{ label: 'Issues', data: yearly.data, borderColor: '#1e3c72', fill: false }] }
        });
        
        // Weekly Trend
        queryParams.set('api', 'weeklyTrend');
        resp = await fetch(`?${queryParams}`);
        let weekly = await resp.json();
        if (charts.weekly) charts.weekly.destroy();
        charts.weekly = new Chart(document.getElementById('weeklyTrendChart'), {
            type: 'bar', data: { labels: weekly.labels, datasets: [{ label: 'Issues', data: weekly.data, backgroundColor: '#6f42c1' }] }
        });
        
        // Hourly
        queryParams.set('api', 'hourly');
        resp = await fetch(`?${queryParams}`);
        let hourly = await resp.json();
        if (charts.hourly) charts.hourly.destroy();
        charts.hourly = new Chart(document.getElementById('hourlyChart'), {
            type: 'line', data: { labels: hourly.labels, datasets: [{ label: 'Issues', data: hourly.data, borderColor: '#fd7e14', fill: false }] }
        });
        
        // Top Books (chart and table)
        queryParams.set('api', 'topBooks');
        resp = await fetch(`?${queryParams}`);
        let topBooks = await resp.json();
        let bookTitles = topBooks.map(b => b.title.length > 30 ? b.title.substr(0,27)+'...' : b.title);
        let bookCounts = topBooks.map(b => b.times_issued);
        if (charts.topBooks) charts.topBooks.destroy();
        charts.topBooks = new Chart(document.getElementById('topBooksChart'), {
            type: 'bar', data: { labels: bookTitles, datasets: [{ label: 'Times Issued', data: bookCounts, backgroundColor: '#28a745' }] },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: true }
        });
        
        let booksTableHtml = '';
        topBooks.forEach((b, idx) => {
            let coverHtml = b.cover_path && b.cover_path !== '' ? `<img src="../${b.cover_path}" style="width:40px;height:50px;object-fit:cover;">` : '<i class="fas fa-book fa-2x text-muted"></i>';
            booksTableHtml += `<tr><td>${idx+1}</td><td>${coverHtml}</td><td>${escapeHtml(b.title)}</td><td>${escapeHtml(b.author)}</td><td>${escapeHtml(b.publisher)}</td><td>${escapeHtml(b.category)}</td><td>${b.times_issued}</td></tr>`;
        });
        document.querySelector('#topBooksTable tbody').innerHTML = booksTableHtml || '<tr><td colspan="7">No data</td></tr>';
        
        // Category Distribution
        queryParams.set('api', 'categoryDist');
        resp = await fetch(`?${queryParams}`);
        let categories = await resp.json();
        let catLabels = categories.map(c => c.category);
        let catData = categories.map(c => c.count);
        if (charts.category) charts.category.destroy();
        charts.category = new Chart(document.getElementById('categoryChart'), {
            type: 'pie', data: { labels: catLabels, datasets: [{ data: catData, backgroundColor: ['#ffc107','#fd7e14','#17a2b8','#28a745','#dc3545'] }] }
        });
        
    } catch(e) { console.error(e); alert('Error loading data'); }
    finally { showLoader(false); }
}

function viewUserHistory(admno) {
    const modal = new bootstrap.Modal(document.getElementById('userHistoryModal'));
    document.getElementById('userHistoryContent').innerHTML = '<div class="text-center"><div class="spinner-border"></div> Loading...</div>';
    modal.show();
    fetch(`?api=userHistory&admno=${encodeURIComponent(admno)}&${new URLSearchParams(getFilters())}`)
        .then(res => res.json())
        .then(data => {
            let html = '<div class="table-responsive"><table class="table table-sm"><thead><tr><th>Issue Date</th><th>Return Date</th><th>Title</th><th>Author</th><th>Fine (' + '<?= addslashes($currencySymbol) ?>' + ')</th></tr></thead><tbody>';
            data.forEach(t => {
                html += `<tr><td>${t.issue_date}</td><td>${t.return_date || 'Not returned'}</td><td>${escapeHtml(t.title)}</td><td>${escapeHtml(t.author)}</td><td>${parseFloat(t.fine||0).toFixed(2)}</td></tr>`;
            });
            html += '</tbody></table></div>';
            document.getElementById('userHistoryContent').innerHTML = html;
        })
        .catch(() => document.getElementById('userHistoryContent').innerHTML = '<div class="alert alert-danger">Failed to load history</div>');
}

function escapeHtml(str) { if(!str) return ''; return str.replace(/[&<>]/g, function(m){ if(m==='&') return '&amp;'; if(m==='<') return '&lt;'; if(m==='>') return '&gt;'; return m; }); }

// Export functions
function exportCSV() {
    window.location.href = `export.php?${new URLSearchParams(getFilters())}`;
}
function exportPresentation() {
    window.location.href = `export_presentation.php?${new URLSearchParams(getFilters())}`;
}
function printReport() { window.print(); }

// Event listeners for filters
document.querySelectorAll('.range-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.range-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        let range = this.dataset.range;
        if (range === 'custom') {
            document.getElementById('customDateRange').style.display = 'flex';
        } else {
            document.getElementById('customDateRange').style.display = 'none';
            fetchAllData();
        }
    });
});
document.getElementById('applyCustomDate')?.addEventListener('click', () => fetchAllData());
document.getElementById('applyFilters')?.addEventListener('click', () => fetchAllData());
document.getElementById('exportExcel')?.addEventListener('click', exportCSV);
document.getElementById('exportPresentation')?.addEventListener('click', exportPresentation);
document.getElementById('printReport')?.addEventListener('click', printReport);

// Initial load
fetchAllData();
</script>
<?php renderFooter(); ?>