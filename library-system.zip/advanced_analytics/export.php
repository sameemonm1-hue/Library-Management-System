<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

$range = $_GET['range'] ?? 'all';
$fromDate = $_GET['from_date'] ?? date('Y-m-01');
$toDate = $_GET['to_date'] ?? date('Y-m-d');
$classFilter = $_GET['class'] ?? '';
$divisionFilter = $_GET['division'] ?? '';

// Build date condition
$dateCondition = "1=1";
if ($range === 'today') {
    $dateCondition = "DATE(issue_date) = DATE('now')";
} elseif ($range === 'week') {
    $dateCondition = "issue_date >= DATE('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCondition = "strftime('%Y-%m', issue_date) = strftime('%Y-%m', 'now')";
} elseif ($range === 'year') {
    $dateCondition = "strftime('%Y', issue_date) = strftime('%Y', 'now')";
} elseif ($range === 'custom') {
    $dateCondition = "issue_date BETWEEN '$fromDate' AND '$toDate'";
}

// Get data for export
$stmt = $db->prepare("
    SELECT 
        c.id,
        c.admno,
        c.member_name,
        m.class,
        m.division,
        c.title as book_title,
        c.author,
        c.issue_date,
        c.due_date,
        c.return_date,
        c.fine,
        CASE 
            WHEN c.return_date IS NOT NULL THEN 'Returned'
            WHEN c.due_date < date('now') THEN 'Overdue'
            ELSE 'Issued'
        END as status
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE $dateCondition
    ORDER BY c.issue_date DESC
");
$stmt->execute();
$data = $stmt->fetchAll();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="circulation_report_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

// Create HTML table for Excel
echo '<html>';
echo '<head><meta charset="UTF-8"><title>Circulation Report</title></head>';
echo '<body>';
echo '<h2>Library Circulation Report</h2>';
echo '<p>Generated: ' . date('Y-m-d H:i:s') . '</p>';
echo '<p>Date Range: ' . ($range === 'custom' ? "$fromDate to $toDate" : ucfirst($range)) . '</p>';
if ($classFilter) echo '<p>Class/Dept Filter: ' . htmlspecialchars($classFilter) . '</p>';
if ($divisionFilter) echo '<p>Div/Course Filter: ' . htmlspecialchars($divisionFilter) . '</p>';
echo '<table border="1" cellpadding="5">';
echo '<thead>';
echo '<tr style="background-color: #1e3c72; color: white;">';
echo '<th>ID</th><th>Adm/Mem No</th><th>Member Name</th><th>Class/Dept</th><th>Div/Course</th>';
echo '<th>Book Title</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Return Date</th><th>Fine (' . htmlspecialchars($currencySymbol) . ')</th><th>Status</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

foreach ($data as $row) {
    echo '<tr>';
    echo '<td>' . $row['id'] . '</td>';
    echo '<td>' . htmlspecialchars($row['admno']) . '</td>';
    echo '<td>' . htmlspecialchars($row['member_name']) . '</td>';
    echo '<td>' . htmlspecialchars($row['class'] ?? '-') . '</td>';
    echo '<td>' . htmlspecialchars($row['division'] ?? '-') . '</td>';
    echo '<td>' . htmlspecialchars($row['book_title']) . '</td>';
    echo '<td>' . htmlspecialchars($row['author'] ?? '-') . '</td>';
    echo '<td>' . $row['issue_date'] . '</td>';
    echo '<td>' . $row['due_date'] . '</td>';
    echo '<td>' . ($row['return_date'] ?? '-') . '</td>';
    echo '<td>' . number_format($row['fine'], 2) . '</td>';
    echo '<td>' . $row['status'] . '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
echo '<p>Total Records: ' . count($data) . '</p>';
echo '</body>';
echo '</html>';
?>