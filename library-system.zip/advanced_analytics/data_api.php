<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$range = $_GET['range'] ?? 'all';
$fromDate = $_GET['from_date'] ?? date('Y-m-01');
$toDate = $_GET['to_date'] ?? date('Y-m-d');
$classFilter = $_GET['class'] ?? '';
$divisionFilter = $_GET['division'] ?? '';
$action = $_GET['action'] ?? '';

// Handle user history request
if ($action === 'user_history' && isset($_GET['admno'])) {
    $admno = $_GET['admno'];
    $stmt = $db->prepare("SELECT * FROM circulation WHERE admno = ? ORDER BY issue_date DESC");
    $stmt->execute([$admno]);
    $history = $stmt->fetchAll();
    echo json_encode($history);
    exit;
}

// Build date condition
$dateCondition = "1=1";
if ($range === 'today') {
    $dateCondition = "DATE(issue_date) = DATE('now')";
} elseif ($range === 'week') {
    $dateCondition = "issue_date >= DATE('now', '-7 days')";
} elseif ($range === 'month') {
    $dateCondition = "strftime('%Y-%m', issue_date) = strftime('%Y-%m', 'now')";
} elseif ($range === 'year') {
    $dateCondition = "strftime('%Y', issue_date) = strftime('%Y', 'now')";
} elseif ($range === 'custom') {
    $dateCondition = "issue_date BETWEEN '$fromDate' AND '$toDate'";
}

// Build member filter condition
$memberCondition = "1=1";
if ($classFilter) {
    $memberCondition .= " AND m.class = '$classFilter'";
}
if ($divisionFilter) {
    $memberCondition .= " AND m.division = '$divisionFilter'";
}

// Get statistics
$stats = [];

// Total issued
$stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE $dateCondition");
$stmt->execute();
$stats['total_issued'] = $stmt->fetchColumn();

// Total returned
$stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE return_date IS NOT NULL AND $dateCondition");
$stmt->execute();
$stats['total_returned'] = $stmt->fetchColumn();

// Active members
$stmt = $db->prepare("SELECT COUNT(DISTINCT admno) FROM circulation WHERE $dateCondition");
$stmt->execute();
$stats['active_members'] = $stmt->fetchColumn();

// Total fine
$stmt = $db->prepare("SELECT SUM(fine) FROM circulation WHERE $dateCondition");
$stmt->execute();
$stats['total_fine'] = $stmt->fetchColumn() ?: 0;

// Issue vs Return
$issueReturn = [
    'issued' => $stats['total_issued'],
    'returned' => $stats['total_returned']
];

// Daily trend (last 7 days)
$dailyTrend = [];
$stmt = $db->prepare("
    SELECT 
        DATE(issue_date) as date,
        COUNT(*) as issued,
        SUM(CASE WHEN return_date IS NOT NULL THEN 1 ELSE 0 END) as returned
    FROM circulation 
    WHERE issue_date >= DATE('now', '-7 days')
    GROUP BY DATE(issue_date)
    ORDER BY date
");
$stmt->execute();
$dailyTrend = $stmt->fetchAll();

// Monthly trend
$monthlyTrend = [];
$stmt = $db->prepare("
    SELECT 
        strftime('%Y-%m', issue_date) as month,
        COUNT(*) as issued,
        SUM(CASE WHEN return_date IS NOT NULL THEN 1 ELSE 0 END) as returned
    FROM circulation 
    WHERE issue_date >= DATE('now', '-12 months')
    GROUP BY strftime('%Y-%m', issue_date)
    ORDER BY month
");
$stmt->execute();
$monthlyTrend = $stmt->fetchAll();

// Class-wise statistics
$classStats = [];
$stmt = $db->prepare("
    SELECT 
        m.class,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        COUNT(DISTINCT c.admno) as active_members,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE $dateCondition
    GROUP BY m.class
    ORDER BY total_issued DESC
");
$stmt->execute();
$classStats = $stmt->fetchAll();

// Division-wise statistics
$divisionStats = [];
$stmt = $db->prepare("
    SELECT 
        m.division,
        COUNT(c.id) as total_issued,
        COUNT(DISTINCT c.admno) as active_members
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE $dateCondition AND m.division IS NOT NULL AND m.division != ''
    GROUP BY m.division
    ORDER BY total_issued DESC
");
$stmt->execute();
$divisionStats = $stmt->fetchAll();

// Class & Division detailed report
$classDivisionDetails = [];
$stmt = $db->prepare("
    SELECT 
        m.class,
        m.division,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        COUNT(DISTINCT c.admno) as active_members,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE $dateCondition
    GROUP BY m.class, m.division
    ORDER BY m.class, total_issued DESC
");
$stmt->execute();
$classDivisionDetails = $stmt->fetchAll();

// Top 10 users
$topUsers = [];
$stmt = $db->prepare("
    SELECT 
        m.admno,
        m.name,
        m.class,
        m.division,
        m.photo_path,
        m.active_books,
        m.total_fines,
        COUNT(c.id) as total_issued
    FROM members m
    LEFT JOIN circulation c ON m.admno = c.admno AND $dateCondition
    WHERE m.status = 'active'
    GROUP BY m.admno
    ORDER BY total_issued DESC
    LIMIT 10
");
$stmt->execute();
$topUsers = $stmt->fetchAll();

// Yearly trend
$yearlyTrend = [];
$stmt = $db->prepare("
    SELECT 
        strftime('%Y', issue_date) as year,
        COUNT(*) as issued
    FROM circulation
    GROUP BY strftime('%Y', issue_date)
    ORDER BY year
");
$stmt->execute();
$yearlyTrend = $stmt->fetchAll();

// Weekly trend (last 4 weeks)
$weeklyTrend = [];
$stmt = $db->prepare("
    SELECT 
        strftime('%W', issue_date) as week,
        'Week ' || strftime('%W', issue_date) as week_label,
        COUNT(*) as issued
    FROM circulation
    WHERE issue_date >= DATE('now', '-28 days')
    GROUP BY strftime('%W', issue_date)
    ORDER BY week
");
$stmt->execute();
$weeklyTrend = $stmt->fetchAll();

// Hourly distribution
$hourlyDistribution = [];
$stmt = $db->prepare("
    SELECT 
        strftime('%H', issue_date) as hour,
        COUNT(*) as count
    FROM circulation
    GROUP BY strftime('%H', issue_date)
    ORDER BY hour
");
$stmt->execute();
$hourlyDistribution = $stmt->fetchAll();

// Top 20 books
$topBooks = [];
$stmt = $db->prepare("
    SELECT 
        b.barcode,
        b.title,
        b.author,
        b.publisher,
        b.category,
        b.cover_path,
        COUNT(c.id) as issue_count
    FROM books b
    LEFT JOIN circulation c ON b.barcode = c.barcode
    GROUP BY b.barcode
    ORDER BY issue_count DESC
    LIMIT 20
");
$stmt->execute();
$topBooks = $stmt->fetchAll();

// Category statistics
$categoryStats = [];
$stmt = $db->prepare("
    SELECT 
        b.category,
        COUNT(c.id) as count
    FROM books b
    LEFT JOIN circulation c ON b.barcode = c.barcode
    WHERE b.category IS NOT NULL AND b.category != ''
    GROUP BY b.category
    ORDER BY count DESC
    LIMIT 10
");
$stmt->execute();
$categoryStats = $stmt->fetchAll();

// Return all data
echo json_encode([
    'stats' => $stats,
    'issue_return' => $issueReturn,
    'daily_trend' => $dailyTrend,
    'monthly_trend' => $monthlyTrend,
    'class_stats' => $classStats,
    'division_stats' => $divisionStats,
    'class_division_details' => $classDivisionDetails,
    'top_users' => $topUsers,
    'yearly_trend' => $yearlyTrend,
    'weekly_trend' => $weeklyTrend,
    'hourly_distribution' => $hourlyDistribution,
    'top_books' => $topBooks,
    'category_stats' => $categoryStats
]);
?>