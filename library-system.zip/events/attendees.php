<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$event_id = intval($_GET['id'] ?? 0);
if (!$event_id) die("Invalid event ID.");

// Get event details
$stmt = $db->prepare("SELECT * FROM library_events WHERE id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();
if (!$event) die("Event not found.");

// Handle removal of attendee
if (isset($_GET['remove'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        die("Invalid security token.");
    }
    $attendee_id = intval($_GET['remove']);
    $db->prepare("DELETE FROM event_attendees WHERE id = ? AND event_id = ?")->execute([$attendee_id, $event_id]);
    header("Location: attendees.php?id=$event_id");
    exit;
}

// Handle adding attendee
$add_error = '';
$add_success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_attendee'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $add_error = "Invalid security token. Please refresh and try again.";
    } else {
        $member_admno = trim($_POST['member_admno']);
        // Check if member exists
        $memberStmt = $db->prepare("SELECT admno, name FROM members WHERE admno = ? AND status = 'active'");
        $memberStmt->execute([$member_admno]);
        $member = $memberStmt->fetch();
        if (!$member) {
            $add_error = "Member not found or inactive.";
        } else {
            // Check if already registered
            $checkStmt = $db->prepare("SELECT id FROM event_attendees WHERE event_id = ? AND member_admno = ?");
            $checkStmt->execute([$event_id, $member_admno]);
            $check = $checkStmt->fetch();
            if ($check) {
                $add_error = "Member already registered for this event.";
            } else {
                $db->prepare("INSERT INTO event_attendees (event_id, member_admno) VALUES (?, ?)")->execute([$event_id, $member_admno]);
                $add_success = "Member added successfully.";
                // Regenerate CSRF token after successful action
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        }
    }
}

// Fetch current attendees
$attendeesStmt = $db->prepare("SELECT ea.*, m.name as member_name, m.class, m.division, m.photo_path 
                               FROM event_attendees ea
                               LEFT JOIN members m ON ea.member_admno = m.admno
                               WHERE ea.event_id = ?
                               ORDER BY ea.attended DESC, m.name ASC");
$attendeesStmt->execute([$event_id]);
$attendees = $attendeesStmt->fetchAll();

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Attendees - <?= htmlspecialchars($event['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .card-custom { background: white; border-radius: 16px; padding: 20px; margin-bottom: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-users"></i> Attendees: <?= htmlspecialchars($event['title']) ?></h2>
                <div>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>
            
            <div class="card-custom">
                <h5>Event Details</h5>
                <p><?= date('d-m-Y', strtotime($event['event_date'])) ?> | <?= date('h:i A', strtotime($event['start_time'])) ?> - <?= date('h:i A', strtotime($event['end_time'])) ?><br>Venue: <?= htmlspecialchars($event['venue']) ?></p>
            </div>
            
            <div class="card-custom">
                <h5>Add Attendee (scan member barcode)</h5>
                <?php if ($add_error): ?><div class="alert alert-danger"><?= htmlspecialchars($add_error) ?></div><?php endif; ?>
                <?php if ($add_success): ?><div class="alert alert-success"><?= htmlspecialchars($add_success) ?></div><?php endif; ?>
                <form method="POST" class="row g-2">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <div class="col-md-4">
                        <input type="text" name="member_admno" class="form-control" placeholder="Scan or enter member Admno" required autofocus>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" name="add_attendee" class="btn btn-primary">Add Attendee</button>
                    </div>
                </form>
            </div>
            
            <div class="card-custom">
                <h5>Registered Attendees (<?= count($attendees) ?>)</h5>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Admno</th>
                                <th>Name</th>
                                <th>Class/Dept / Div/Course</th>
                                <th>Attended</th>
                                <th>Check-in Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($attendees as $a): ?>
                            <tr>
                                <td><?= htmlspecialchars($a['member_admno']) ?></div>
                                <td><?= htmlspecialchars($a['member_name']) ?></div>
                                <td><?= htmlspecialchars($a['class']) ?> <?= htmlspecialchars($a['division']) ?></div>
                                <td><?= $a['attended'] ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>' ?></div>
                                <td><?= $a['check_in_time'] ? date('d-m-Y H:i', strtotime($a['check_in_time'])) : '-' ?></div>
                                <td>
                                    <?php if (!$a['attended']): ?>
                                        <a href="checkin.php?event_id=<?= $event_id ?>&member=<?= urlencode($a['member_admno']) ?>" class="btn btn-sm btn-success">Check-in</a>
                                    <?php endif; ?>
                                    <a href="?id=<?= $event_id ?>&remove=<?= $a['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Remove this attendee?')">Remove</a>
                                </div>
                             </div>
                            <?php endforeach; ?>
                        </tbody>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script>
        // Auto-focus the input field
        document.querySelector('input[name="member_admno"]').focus();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>