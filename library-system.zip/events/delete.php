<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$id = intval($_GET['id'] ?? 0);
if(!$id) die("Invalid ID.");

$db = getDB();
$db->prepare("DELETE FROM library_events WHERE id = ?")->execute([$id]);
logActivity($_SESSION['username'], 'EVENT_DELETE', "Deleted event ID: $id");
header("Location: index.php?msg=deleted");
exit;
?>