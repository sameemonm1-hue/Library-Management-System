<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$event_id = intval($_GET['event_id'] ?? 0);
$member_admno = isset($_GET['member']) ? trim($_GET['member']) : '';

if($event_id && $member_admno) {
    // Direct check-in from link
    $stmt = $db->prepare("UPDATE event_attendees SET attended = 1, check_in_time = datetime('now') WHERE event_id = ? AND member_admno = ?");
    $stmt->execute([$event_id, $member_admno]);
    header("Location: attendees.php?id=$event_id");
    exit;
}

// Handle form submission (scan member)
$message = '';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $event_id = intval($_POST['event_id']);
    $member_admno = trim($_POST['member_admno']);
    // Check if attendee exists
    $checkStmt = $db->prepare("SELECT id FROM event_attendees WHERE event_id = ? AND member_admno = ?");
    $checkStmt->execute([$event_id, $member_admno]);
    $check = $checkStmt->fetch();
    if($check) {
        $db->prepare("UPDATE event_attendees SET attended = 1, check_in_time = datetime('now') WHERE event_id = ? AND member_admno = ?")->execute([$event_id, $member_admno]);
        $message = "Check-in successful for $member_admno.";
    } else {
        $message = "Member not registered for this event. Please register first.";
    }
}

// Get all upcoming/ongoing events for dropdown
$eventsStmt = $db->prepare("SELECT id, title, event_date FROM library_events WHERE status IN ('upcoming','ongoing') ORDER BY event_date");
$eventsStmt->execute();
$events = $eventsStmt->fetchAll();

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Check-in</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-check-circle"></i> Event Check-in</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        <?php if($message): ?><div class="alert alert-info"><?= $message ?></div><?php endif; ?>
        <div class="form-card">
            <form method="POST">
                <div class="mb-3">
                    <label>Select Event</label>
                    <select name="event_id" class="form-select" required>
                        <option value="">-- Choose Event --</option>
                        <?php foreach($events as $e): ?>
                            <option value="<?= $e['id'] ?>" <?= ($event_id==$e['id'])?'selected':'' ?>><?= htmlspecialchars($e['title']) ?> (<?= $e['event_date'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label>Member Admno (scan barcode)</label>
                    <input type="text" name="member_admno" class="form-control" autofocus required>
                </div>
                <button type="submit" class="btn btn-primary">Check In</button>
            </form>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script>
        document.querySelector('input[name="member_admno"]').focus();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>