<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
if($month < 1) $month = 1; if($month > 12) $month = 12;

$first_day = mktime(0,0,0, $month, 1, $year);
$days_in_month = date('t', $first_day);
$start_weekday = date('w', $first_day);

$start_date = "$year-$month-01";
$end_date = "$year-$month-$days_in_month";
$events = [];

$tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='library_events'");
if($tableCheck->fetch()) {
    $stmt = $db->prepare("SELECT * FROM library_events WHERE event_date BETWEEN ? AND ? AND status != 'cancelled' ORDER BY event_date");
    $stmt->execute([$start_date, $end_date]);
    $events = $stmt->fetchAll();
}

$events_by_date = [];
foreach($events as $e) {
    $events_by_date[$e['event_date']][] = $e;
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .calendar-table { width: 100%; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .calendar-table th, .calendar-table td { border: 1px solid #dee2e6; padding: 15px; vertical-align: top; height: 120px; }
        .calendar-table th { background: #f8f9fa; text-align: center; }
        .event-item { background: #e7f1ff; margin-bottom: 5px; padding: 3px 6px; border-radius: 8px; font-size: 12px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-calendar-week"></i> Events Calendar: <?= date('F Y', $first_day) ?></h2>
            <div>
                <a href="?month=<?= $month-1 ?>&year=<?= $year ?>" class="btn btn-outline-primary"><i class="fas fa-chevron-left"></i> Prev</a>
                <a href="?month=<?= $month+1 ?>&year=<?= $year ?>" class="btn btn-outline-primary">Next <i class="fas fa-chevron-right"></i></a>
                <a href="index.php" class="btn btn-secondary">List View</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Home</a>
            </div>
        </div>
        
        <table class="calendar-table">
            <thead><tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr></thead>
            <tbody>
                <?php
                $day = 1;
                $current_weekday = $start_weekday;
                while($day <= $days_in_month):
                    echo "<tr>";
                    for($i=0; $i<7; $i++):
                        if($day > $days_in_month || ($i < $current_weekday && $day==1)) {
                            echo "<td></div>";
                        } else {
                            $date_str = sprintf("%04d-%02d-%02d", $year, $month, $day);
                            echo "<td><strong>$day</strong>";
                            if(isset($events_by_date[$date_str])) {
                                foreach($events_by_date[$date_str] as $ev) {
                                    echo "<div class='event-item'><i class='fas fa-calendar-alt'></i> <a href='attendees.php?id={$ev['id']}'>{$ev['title']}</a><br><small>{$ev['start_time']}</small></div>";
                                }
                            }
                            echo "</div>";
                            $day++;
                        }
                    endfor;
                    echo "<tr>";
                endwhile;
                ?>
            </tbody>
        </table>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>