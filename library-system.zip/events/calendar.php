<?php
/**
 * Library Events Calendar
 * Features:
 * - Monthly calendar view with events
 * - Event tooltips and links
 * - Navigation between months
 * - Responsive design
 * - Unified styling
 */

// Fix: Check if session is already active before starting
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/functions.php';

if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
if($month < 1) $month = 1; if($month > 12) $month = 12;

$first_day = mktime(0,0,0, $month, 1, $year);
$days_in_month = date('t', $first_day);
$start_weekday = date('w', $first_day);

$start_date = "$year-$month-01";
$end_date = "$year-$month-$days_in_month";
$events = [];

$tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='library_events'");
if($tableCheck->fetch()) {
    $stmt = $db->prepare("SELECT * FROM library_events WHERE event_date BETWEEN ? AND ? AND status != 'cancelled' ORDER BY event_date");
    $stmt->execute([$start_date, $end_date]);
    $events = $stmt->fetchAll();
}

$events_by_date = [];
foreach($events as $e) {
    $events_by_date[$e['event_date']][] = $e;
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Calendar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
        }
        
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        
        .calendar-table { 
            width: 100%; 
            background: white; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 
        }
        .calendar-table th, .calendar-table td { 
            border: 1px solid #dee2e6; 
            padding: 15px; 
            vertical-align: top; 
            height: 120px; 
        }
        .calendar-table th { 
            background: var(--primary-color); 
            color: white;
            text-align: center; 
            font-weight: 600;
        }
        .calendar-table td:hover {
            background: #f8f9fa;
        }
        .calendar-table td strong {
            color: var(--primary-color);
            font-size: 1.1rem;
        }
        
        .event-item { 
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            color: white;
            margin-bottom: 5px; 
            padding: 3px 8px; 
            border-radius: 8px; 
            font-size: 11px;
            transition: all 0.2s ease;
        }
        .event-item:hover {
            transform: scale(1.02);
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .event-item a {
            color: white;
            text-decoration: none;
            font-weight: 500;
        }
        .event-item a:hover {
            text-decoration: underline;
        }
        .event-item i {
            margin-right: 4px;
            opacity: 0.8;
        }
        .event-item small {
            opacity: 0.9;
            display: block;
            font-size: 10px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 30px; 
            border-radius: 16px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .calendar-table th, .calendar-table td { 
                padding: 8px; 
                height: 80px; 
                font-size: 12px;
            }
            .event-item { 
                font-size: 9px; 
                padding: 2px 4px;
            }
            .calendar-table td strong {
                font-size: 0.9rem;
            }
        }
        @media (max-width: 576px) {
            .calendar-table th, .calendar-table td { 
                padding: 4px; 
                height: 60px; 
                font-size: 10px;
            }
            .event-item { 
                font-size: 7px; 
                padding: 1px 3px;
                border-radius: 4px;
            }
            .event-item i {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <!-- Header -->
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
            <h2 style="color: var(--primary-color);"><i class="fas fa-calendar-week"></i> Events Calendar: <?= date('F Y', $first_day) ?></h2>
            <div class="d-flex flex-wrap gap-2">
                <a href="?month=<?= $month-1 ?>&year=<?= $year ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-chevron-left"></i> Prev</a>
                <a href="?month=<?= $month+1 ?>&year=<?= $year ?>" class="btn btn-outline-primary btn-sm">Next <i class="fas fa-chevron-right"></i></a>
                <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-list"></i> List View</a>
                <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            </div>
        </div>
        
        <!-- Calendar Table -->
        <div class="table-responsive">
            <table class="calendar-table">
                <thead>
                    <tr>
                        <th>Sun</th>
                        <th>Mon</th>
                        <th>Tue</th>
                        <th>Wed</th>
                        <th>Thu</th>
                        <th>Fri</th>
                        <th>Sat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $day = 1;
                    $current_weekday = $start_weekday;
                    while($day <= $days_in_month):
                        echo "<tr>";
                        for($i=0; $i<7; $i++):
                            if($day > $days_in_month || ($i < $current_weekday && $day==1)) {
                                echo "<td></td>";
                            } else {
                                $date_str = sprintf("%04d-%02d-%02d", $year, $month, $day);
                                echo "<td>";
                                echo "<strong>$day</strong>";
                                if(isset($events_by_date[$date_str])) {
                                    foreach($events_by_date[$date_str] as $ev) {
                                        echo "<div class='event-item'>";
                                        echo "<i class='fas fa-calendar-alt'></i> ";
                                        echo "<a href='attendees.php?id={$ev['id']}'>{$ev['title']}</a>";
                                        if(!empty($ev['start_time'])) {
                                            echo "<small>" . date('h:i A', strtotime($ev['start_time'])) . "</small>";
                                        }
                                        echo "</div>";
                                    }
                                }
                                echo "</td>";
                                $day++;
                            }
                        endfor;
                        echo "</tr>";
                    endwhile;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Footer -->
    <div class="container">
        <div class="footer">
            <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
            <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>