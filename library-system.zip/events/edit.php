<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$id = intval($_GET['id'] ?? 0);
if(!$id) die("Invalid event ID.");

$stmt = $db->prepare("SELECT * FROM library_events WHERE id = ?");
$stmt->execute([$id]);
$event = $stmt->fetch();
if(!$event) die("Event not found.");

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $event_date = $_POST['event_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $venue = trim($_POST['venue']);
    $max_attendees = !empty($_POST['max_attendees']) ? intval($_POST['max_attendees']) : null;
    $registration_required = isset($_POST['registration_required']) ? 1 : 0;
    $status = $_POST['status'];
    
    if(!$title || !$event_date || !$start_time || !$end_time) {
        $error = "Please fill all required fields.";
    } elseif(strtotime($end_time) <= strtotime($start_time)) {
        $error = "End time must be after start time.";
    } else {
        try {
            $stmt = $db->prepare("UPDATE library_events SET 
                title=?, description=?, event_date=?, start_time=?, end_time=?, venue=?, 
                max_attendees=?, registration_required=?, status=?
                WHERE id=?");
            $stmt->execute([$title, $description, $event_date, $start_time, $end_time, $venue, 
                           $max_attendees, $registration_required, $status, $id]);
            logActivity($_SESSION['username'], 'EVENT_EDIT', "Updated event ID: $id");
            $success = "Event updated successfully.";
            // Refresh data
            $stmt = $db->prepare("SELECT * FROM library_events WHERE id = ?");
            $stmt->execute([$id]);
            $event = $stmt->fetch();
        } catch(PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Event - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Event</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        <?php if($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert alert-success"><?= $success ?></div><?php endif; ?>
        <div class="form-card">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-8"><label>Title *</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($event['title']) ?>" required></div>
                    <div class="col-md-4"><label>Status</label><select name="status" class="form-select">
                        <option value="upcoming" <?= $event['status']=='upcoming'?'selected':'' ?>>Upcoming</option>
                        <option value="ongoing" <?= $event['status']=='ongoing'?'selected':'' ?>>Ongoing</option>
                        <option value="completed" <?= $event['status']=='completed'?'selected':'' ?>>Completed</option>
                        <option value="cancelled" <?= $event['status']=='cancelled'?'selected':'' ?>>Cancelled</option>
                    </select></div>
                    <div class="col-12"><label>Description</label><textarea name="description" rows="3" class="form-control"><?= htmlspecialchars($event['description']) ?></textarea></div>
                    <div class="col-md-3"><label>Event Date *</label><input type="date" name="event_date" class="form-control" value="<?= $event['event_date'] ?>" required></div>
                    <div class="col-md-3"><label>Start Time *</label><input type="time" name="start_time" class="form-control" value="<?= $event['start_time'] ?>" required></div>
                    <div class="col-md-3"><label>End Time *</label><input type="time" name="end_time" class="form-control" value="<?= $event['end_time'] ?>" required></div>
                    <div class="col-md-3"><label>Venue</label><input type="text" name="venue" class="form-control" value="<?= htmlspecialchars($event['venue']) ?>"></div>
                    <div class="col-md-4"><label>Max Attendees</label><input type="number" name="max_attendees" class="form-control" value="<?= $event['max_attendees'] ?>"></div>
                    <div class="col-md-4"><div class="form-check mt-4"><input class="form-check-input" type="checkbox" name="registration_required" <?= $event['registration_required']?'checked':'' ?>><label>Registration Required</label></div></div>
                    <div class="col-12"><button type="submit" class="btn btn-primary">Update Event</button> <a href="index.php" class="btn btn-secondary">Cancel</a></div>
                </div>
            </form>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>