<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Simple rate limiting
$rate_key = 'ajax_rate_' . $_SESSION['user_id'];
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
if ($_SESSION[$rate_key] > 20) {
    echo json_encode(['error' => 'Too many requests. Please wait.']);
    exit;
}
$_SESSION[$rate_key]++;

$db = getDB();
$action = $_GET['action'] ?? '';

if ($action == 'search_members') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) {
        echo json_encode([]);
        exit;
    }
    $stmt = $db->prepare("SELECT admno, name, class, division, email FROM members WHERE admno LIKE ? OR name LIKE ? LIMIT 10");
    $stmt->execute(["%$q%", "%$q%"]);
    $members = $stmt->fetchAll();
    // Return original field names; frontend will relabel as needed
    echo json_encode($members);
    exit;
}

if ($action == 'get_member') {
    $admno = trim($_GET['admno'] ?? '');
    $stmt = $db->prepare("SELECT admno, name, class, division FROM members WHERE admno = ? AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    echo json_encode($member ?: null);
    exit;
}

echo json_encode(['error' => 'Invalid action']);
?>