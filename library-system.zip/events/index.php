<?php
/**
 * Library Events Module - Complete Update
 * Features:
 * - Event statistics cards (total, upcoming, ongoing, completed)
 * - Enhanced event cards with status badges
 * - Attendee avatars display (first 5 attendees with photos)
 * - Quick search with debounce
 * - Attendee modal with member photos
 * - Responsive design
 * - Improved UI with modern styling
 * - Properly aligned report output
 * - Unified gradient cards
 */

require_once __DIR__ . '/../config/functions.php';

if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== GET STATISTICS ==========
$totalEvents = $db->query("SELECT COUNT(*) FROM library_events")->fetchColumn();
$upcomingEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'upcoming' AND event_date >= date('now')")->fetchColumn();
$ongoingEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'ongoing' AND event_date = date('now')")->fetchColumn();
$completedEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'completed' OR event_date < date('now')")->fetchColumn();

// ========== FILTERS ==========
$status_filter = $_GET['status'] ?? 'upcoming';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// ========== BUILD QUERY ==========
$today = date('Y-m-d');
$sql = "SELECT e.*, 
        (SELECT COUNT(*) FROM event_attendees WHERE event_id = e.id AND attended = 1) as attended_count,
        (SELECT COUNT(*) FROM event_attendees WHERE event_id = e.id) as registered_count
        FROM library_events e
        WHERE 1=1";
$params = [];

if($status_filter != 'all') {
    if($status_filter == 'upcoming') {
        $sql .= " AND e.event_date >= ? AND e.status = 'upcoming'";
        $params[] = $today;
    } elseif($status_filter == 'ongoing') {
        $sql .= " AND e.event_date = ? AND e.status = 'ongoing'";
        $params[] = $today;
    } elseif($status_filter == 'completed') {
        $sql .= " AND e.event_date < ? AND e.status = 'completed'";
        $params[] = $today;
    } else {
        $sql .= " AND e.status = ?";
        $params[] = $status_filter;
    }
}
if($search) {
    $sql .= " AND (e.title LIKE ? OR e.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$sql .= " ORDER BY e.event_date ASC, e.start_time ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

// ========== FETCH ATTENDEES WITH PHOTOS FOR EACH EVENT (limit 5) ==========
foreach ($events as &$event) {
    $attendeesStmt = $db->prepare("
        SELECT a.*, m.name as member_name, m.admno, m.photo_path 
        FROM event_attendees a
        LEFT JOIN members m ON a.member_admno = m.admno
        WHERE a.event_id = ?
        ORDER BY a.attended DESC, a.check_in_time DESC
        LIMIT 5
    ");
    $attendeesStmt->execute([$event['id']]);
    $attendees = $attendeesStmt->fetchAll();
    foreach ($attendees as &$att) {
        $att['photo_base64'] = getImageBase64($att['photo_path'] ?? '');
    }
    $event['attendees'] = $attendees;
}

$logoUrl = '';
if(!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
    $logoUrl = getWebImageUrl($institution['logo_path']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Events - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
        }
        
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            border-radius: 16px;
            padding: 20px 20px 20px 70px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }

        /* ===== FILTER CARD ===== */
        .filter-card { 
            background: white; 
            border-radius: 16px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05); 
            margin-bottom: 25px; 
        }
        
        /* ===== EVENT CARD - PROPERLY ALIGNED ===== */
        .event-card {
            background: white;
            border-radius: 16px;
            padding: 20px 25px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: relative;
            border-left: 4px solid var(--primary-color);
        }
        .event-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
        
        .event-status {
            position: absolute;
            top: 15px;
            right: 20px;
            padding: 4px 16px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        .event-status.primary { background: #cfe2ff; color: #084298; }
        .event-status.success { background: #d1e7dd; color: #0f5132; }
        .event-status.secondary { background: #e2e3e5; color: #383d41; }
        .event-status.danger { background: #f8d7da; color: #721c24; }
        .event-status.warning { background: #fff3cd; color: #856404; }
        .event-status.info { background: #cff4fc; color: #055160; }

        .event-title { 
            font-size: 1.2rem; 
            font-weight: 600; 
            margin-bottom: 4px;
            padding-right: 120px;
        }
        .event-description {
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 8px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .event-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px 25px;
            margin: 8px 0 10px 0;
            font-size: 0.85rem;
            color: #495057;
        }
        .event-meta i { 
            width: 18px; 
            color: #6c757d; 
            margin-right: 4px;
        }

        .event-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin: 6px 0 0 0;
        }
        .event-badges .badge {
            font-weight: 500;
            padding: 4px 12px;
            font-size: 0.75rem;
        }

        /* ===== ATTENDEE AVATARS ===== */
        .attendee-avatars {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 2px;
        }
        .attendee-avatar {
            width: 34px;
            height: 34px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #fff;
            transition: all 0.3s ease;
            margin-left: -4px;
            background: #f8f9fa;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        }
        .attendee-avatar:first-child { margin-left: 0; }
        .attendee-avatar:hover { 
            transform: scale(1.2); 
            border-color: var(--primary-color); 
            z-index: 10; 
            position: relative; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .attendee-avatar-placeholder {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            border: 2px solid #fff;
            margin-left: -4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        }
        .attendee-avatar-placeholder:first-child { margin-left: 0; }
        .attendee-more {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: #e9ecef;
            color: #495057;
            font-size: 0.7rem;
            font-weight: 600;
            margin-left: 4px;
            border: 2px solid #fff;
            cursor: default;
        }

        .event-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            justify-content: flex-end;
            margin-top: 8px;
        }
        .event-actions .btn {
            font-size: 0.75rem;
            padding: 4px 10px;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }

        /* ===== FOOTER ===== */
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 30px; 
            border-radius: 16px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .footer a {
            color: var(--primary-color);
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .content-wrapper { padding: 15px; }
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .event-title { padding-right: 0; font-size: 1rem; }
            .event-status { position: static; display: inline-block; margin-bottom: 8px; }
            .event-meta { font-size: 0.8rem; gap: 8px 15px; }
            .attendee-avatar, .attendee-avatar-placeholder { width: 30px; height: 30px; }
            .event-actions { justify-content: flex-start; }
            .event-card { padding: 15px; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-value { font-size: 18px; }
            .event-badges .badge { font-size: 0.65rem; padding: 2px 8px; }
            .event-actions .btn { font-size: 0.65rem; padding: 2px 8px; }
        }

        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .filter-card { display: none !important; }
            .event-card { 
                box-shadow: none !important; 
                border: 1px solid #ddd !important;
                page-break-inside: avoid;
            }
            .event-actions { display: none !important; }
            .footer { border-top: 1px solid #ddd !important; }
            .attendee-avatar, .attendee-avatar-placeholder { 
                border-color: #ddd !important;
            }
            .event-status { 
                border: 1px solid #ddd !important;
                background: #f8f9fa !important;
                color: #333 !important;
            }
            .event-status.primary { background: #e9ecef !important; color: #333 !important; }
            .event-status.success { background: #e9ecef !important; color: #333 !important; }
            .event-status.secondary { background: #e9ecef !important; color: #333 !important; }
            .event-status.danger { background: #e9ecef !important; color: #333 !important; }
            .event-status.warning { background: #e9ecef !important; color: #333 !important; }
            .event-status.info { background: #e9ecef !important; color: #333 !important; }
            h2 { color: #333 !important; }
            .badge { border: 1px solid #ddd !important; }
            .alert { border: 1px solid #ddd !important; }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <!-- ===== HEADER ===== -->
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                <h2 style="color: var(--primary-color);"><i class="fas fa-calendar-alt me-2"></i> Library Events</h2>
                <div class="d-flex flex-wrap gap-2 no-print">
                    <a href="add.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Create Event</a>
                    <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Home</a>
                    <a href="calendar.php" class="btn btn-outline-info btn-sm"><i class="fas fa-calendar-week"></i> Calendar</a>
                </div>
            </div>

            <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
            <div class="row g-3 mb-4">
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper"><i class="fas fa-calendar-alt"></i></div>
                        <div class="stat-content">
                            <div class="stat-value"><?= number_format($totalEvents) ?></div>
                            <div class="stat-label">Total Events</div>
                            <div class="stat-sub"><i class="fas fa-calendar"></i> All time</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper"><i class="fas fa-clock"></i></div>
                        <div class="stat-content">
                            <div class="stat-value"><?= number_format($upcomingEvents) ?></div>
                            <div class="stat-label">Upcoming</div>
                            <div class="stat-sub"><i class="fas fa-hourglass-start"></i> Scheduled</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper"><i class="fas fa-play"></i></div>
                        <div class="stat-content">
                            <div class="stat-value"><?= number_format($ongoingEvents) ?></div>
                            <div class="stat-label">Ongoing</div>
                            <div class="stat-sub"><i class="fas fa-spinner"></i> In progress</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-6">
                    <div class="stat-card">
                        <div class="stat-icon-wrapper"><i class="fas fa-check-circle"></i></div>
                        <div class="stat-content">
                            <div class="stat-value"><?= number_format($completedEvents) ?></div>
                            <div class="stat-label">Completed</div>
                            <div class="stat-sub"><i class="fas fa-flag-checkered"></i> Finished</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ===== FILTER CARD ===== -->
            <div class="filter-card no-print">
                <form method="GET" id="filterForm" class="row g-3 align-items-end">
                    <div class="col-md-3 col-sm-6">
                        <label class="form-label fw-semibold small"><i class="fas fa-filter me-1"></i> Status</label>
                        <select name="status" class="form-select form-select-sm" id="statusSelect">
                            <option value="upcoming" <?= $status_filter=='upcoming'?'selected':'' ?>>Upcoming</option>
                            <option value="ongoing" <?= $status_filter=='ongoing'?'selected':'' ?>>Ongoing</option>
                            <option value="completed" <?= $status_filter=='completed'?'selected':'' ?>>Completed</option>
                            <option value="cancelled" <?= $status_filter=='cancelled'?'selected':'' ?>>Cancelled</option>
                            <option value="all" <?= $status_filter=='all'?'selected':'' ?>>All Events</option>
                        </select>
                    </div>
                    <div class="col-md-5 col-sm-6">
                        <label class="form-label fw-semibold small"><i class="fas fa-search me-1"></i> Search</label>
                        <div class="input-group input-group-sm">
                            <input type="text" name="search" id="searchInput" class="form-control" placeholder="Title or description..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-search"></i> Filter</button>
                            <a href="index.php" class="btn btn-secondary btn-sm w-100"><i class="fas fa-undo"></i> Reset</a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- ===== EVENTS LIST ===== -->
            <?php if(count($events) == 0): ?>
                <div class="alert alert-info text-center py-5">
                    <i class="fas fa-calendar-times fa-3x mb-2 d-block"></i>
                    <?php if(!empty($search) || $status_filter != 'upcoming'): ?>
                        No events match your filters.
                    <?php else: ?>
                        No events found. <a href="add.php" class="alert-link">Create your first event</a>.
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach($events as $event): 
                    $statusClass = 'secondary';
                    $statusLabel = ucfirst($event['status']);
                    if($event['status'] == 'upcoming') { $statusClass = 'primary'; }
                    elseif($event['status'] == 'ongoing') { $statusClass = 'success'; }
                    elseif($event['status'] == 'completed') { $statusClass = 'secondary'; }
                    elseif($event['status'] == 'cancelled') { $statusClass = 'danger'; }
                    $borderColor = match($event['status']) {
                        'upcoming' => '#0d6efd',
                        'ongoing' => '#198754',
                        'completed' => '#6c757d',
                        'cancelled' => '#dc3545',
                        default => '#1e3c72'
                    };
                ?>
                <div class="event-card" style="border-left-color: <?= $borderColor ?>;">
                    <!-- Status Badge -->
                    <span class="event-status <?= $statusClass ?>"><?= $statusLabel ?></span>
                    
                    <div class="row g-3">
                        <!-- Left Column: Event Info -->
                        <div class="col-md-8 col-12">
                            <div class="event-title"><?= htmlspecialchars($event['title']) ?></div>
                            <?php if(!empty($event['description'])): ?>
                                <div class="event-description"><?= nl2br(htmlspecialchars($event['description'])) ?></div>
                            <?php endif; ?>
                            
                            <div class="event-meta">
                                <span><i class="fas fa-calendar-day"></i> <?= date('d-m-Y', strtotime($event['event_date'])) ?></span>
                                <span><i class="fas fa-clock"></i> <?= date('h:i A', strtotime($event['start_time'])) ?> - <?= date('h:i A', strtotime($event['end_time'])) ?></span>
                                <?php if(!empty($event['venue'])): ?>
                                    <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($event['venue']) ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="event-badges">
                                <span class="badge bg-light text-dark border"><i class="fas fa-users"></i> <?= $event['registered_count'] ?> registered</span>
                                <span class="badge bg-light text-dark border"><i class="fas fa-check-circle"></i> <?= $event['attended_count'] ?> attended</span>
                                <?php if($event['max_attendees']): ?>
                                    <span class="badge bg-light text-dark border"><i class="fas fa-user-plus"></i> Max: <?= $event['max_attendees'] ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Right Column: Attendees & Actions -->
                        <div class="col-md-4 col-12">
                            <?php if(!empty($event['attendees'])): ?>
                                <div class="text-end mb-2">
                                    <span class="fw-semibold small text-muted">Recent attendees</span>
                                    <div class="attendee-avatars">
                                        <?php foreach($event['attendees'] as $att): ?>
                                            <?php if($att['photo_base64']): ?>
                                                <img src="<?= $att['photo_base64'] ?>" class="attendee-avatar" alt="Attendee" title="<?= htmlspecialchars($att['member_name'] ?? 'Attendee') ?>">
                                            <?php else: ?>
                                                <span class="attendee-avatar-placeholder" title="<?= htmlspecialchars($att['member_name'] ?? 'Attendee') ?>"><i class="fas fa-user"></i></span>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                        <?php if($event['registered_count'] > 5): ?>
                                            <span class="attendee-more">+<?= $event['registered_count'] - 5 ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="event-actions no-print">
                                <a href="attendees.php?id=<?= $event['id'] ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-users"></i> Attendees</a>
                                <a href="checkin.php?id=<?= $event['id'] ?>" class="btn btn-outline-success btn-sm"><i class="fas fa-check-circle"></i> Check-in</a>
                                <a href="edit.php?id=<?= $event['id'] ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-edit"></i></a>
                                <a href="delete.php?id=<?= $event['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this event? This will also delete all attendance records.')"><i class="fas fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <div class="container">
        <div class="footer">
            <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
            <p class="small mb-0 no-print">
                <a href="calendar.php" class="btn btn-sm btn-outline-secondary me-1"><i class="fas fa-calendar-week"></i> Calendar</a>
                <a href="../index.php" class="btn btn-sm btn-primary"><i class="fas fa-home"></i> Home</a>
                <a href="#" onclick="window.print();" class="btn btn-sm btn-outline-info"><i class="fas fa-print"></i> Print</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // ========== DEBOUNCE FOR SEARCH ==========
    let searchTimeout = null;
    const searchInput = document.getElementById('searchInput');
    if(searchInput) {
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                document.getElementById('filterForm').submit();
            }, 500);
        });
    }

    // ========== AUTO-SUBMIT ON STATUS CHANGE ==========
    document.getElementById('statusSelect')?.addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });

    // ========== TOOLTIP FOR ATTENDEE AVATARS ==========
    document.querySelectorAll('.attendee-avatar, .attendee-avatar-placeholder').forEach(el => {
        el.addEventListener('mouseenter', function(e) {
            const title = this.getAttribute('title');
            if (title) {
                const tooltip = document.createElement('div');
                tooltip.className = 'position-fixed bg-dark text-white px-2 py-1 rounded small';
                tooltip.style.zIndex = '9999';
                tooltip.style.pointerEvents = 'none';
                tooltip.textContent = title;
                document.body.appendChild(tooltip);
                const rect = this.getBoundingClientRect();
                tooltip.style.top = (rect.top - tooltip.offsetHeight - 8) + 'px';
                tooltip.style.left = (rect.left + rect.width/2 - tooltip.offsetWidth/2) + 'px';
                this._tooltip = tooltip;
            }
        });
        el.addEventListener('mouseleave', function() {
            if (this._tooltip) {
                this._tooltip.remove();
                delete this._tooltip;
            }
        });
    });
    </script>
</body>
</html>
<div class="container">
        <div class="footer">

            <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
        </div>
    </div>