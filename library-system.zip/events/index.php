<?php
/**
 * Library Events Module - Complete Update
 * Features:
 * - Event statistics cards (total, upcoming, ongoing, completed)
 * - Enhanced event cards with status badges
 * - Attendee avatars display (first 5 attendees with photos)
 * - Quick search with debounce
 * - Attendee modal with member photos
 * - Responsive design
 * - Improved UI with modern styling
 */

require_once __DIR__ . '/../config/functions.php';

if(!isset($_SESSION['user_id'])) header("Location: ../index.php");

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== GET STATISTICS ==========
$totalEvents = $db->query("SELECT COUNT(*) FROM library_events")->fetchColumn();
$upcomingEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'upcoming' AND event_date >= date('now')")->fetchColumn();
$ongoingEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'ongoing' AND event_date = date('now')")->fetchColumn();
$completedEvents = $db->query("SELECT COUNT(*) FROM library_events WHERE status = 'completed' OR event_date < date('now')")->fetchColumn();

// ========== FILTERS ==========
$status_filter = $_GET['status'] ?? 'upcoming';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// ========== BUILD QUERY ==========
$today = date('Y-m-d');
$sql = "SELECT e.*, 
        (SELECT COUNT(*) FROM event_attendees WHERE event_id = e.id AND attended = 1) as attended_count,
        (SELECT COUNT(*) FROM event_attendees WHERE event_id = e.id) as registered_count
        FROM library_events e
        WHERE 1=1";
$params = [];

if($status_filter != 'all') {
    if($status_filter == 'upcoming') {
        $sql .= " AND e.event_date >= ? AND e.status = 'upcoming'";
        $params[] = $today;
    } elseif($status_filter == 'ongoing') {
        $sql .= " AND e.event_date = ? AND e.status = 'ongoing'";
        $params[] = $today;
    } elseif($status_filter == 'completed') {
        $sql .= " AND e.event_date < ? AND e.status = 'completed'";
        $params[] = $today;
    } else {
        $sql .= " AND e.status = ?";
        $params[] = $status_filter;
    }
}
if($search) {
    $sql .= " AND (e.title LIKE ? OR e.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$sql .= " ORDER BY e.event_date ASC, e.start_time ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll();

// ========== FETCH ATTENDEES WITH PHOTOS FOR EACH EVENT (limit 5) ==========
foreach ($events as &$event) {
    $attendeesStmt = $db->prepare("
        SELECT a.*, m.name as member_name, m.admno, m.photo_path 
        FROM event_attendees a
        LEFT JOIN members m ON a.member_admno = m.admno
        WHERE a.event_id = ?
        ORDER BY a.attended DESC, a.check_in_time DESC
        LIMIT 5
    ");
    $attendeesStmt->execute([$event['id']]);
    $attendees = $attendeesStmt->fetchAll();
    foreach ($attendees as &$att) {
        $att['photo_base64'] = getImageBase64($att['photo_path'] ?? '');
    }
    $event['attendees'] = $attendees;
}

$logoUrl = '';
if(!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
    $logoUrl = getWebImageUrl($institution['logo_path']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Events - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            text-align: center;
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .stat-card .stat-icon { font-size: 32px; opacity: 0.15; position: absolute; right: 15px; top: 15px; }
        .stat-card .stat-value { font-size: 28px; font-weight: 700; margin-bottom: 2px; }
        .stat-card .stat-label { font-size: 14px; color: #6c757d; }
        .stat-card { position: relative; overflow: hidden; }
        .stat-card .stat-sub { font-size: 11px; color: #adb5bd; margin-top: 4px; }

        .filter-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .event-card {
            background: white;
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: relative;
            border-left: 4px solid #1e3c72;
        }
        .event-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
        .event-status {
            position: absolute;
            top: 15px;
            right: 15px;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .event-status-primary { background: #cfe2ff; color: #084298; }
        .event-status-success { background: #d1e7dd; color: #0f5132; }
        .event-status-secondary { background: #e2e3e5; color: #383d41; }
        .event-status-danger { background: #f8d7da; color: #721c24; }

        .attendee-avatar {
            width: 32px;
            height: 32px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            margin-right: -6px;
            background: #f8f9fa;
        }
        .attendee-avatar:hover { transform: scale(1.2); border-color: #1e3c72; z-index: 10; position: relative; }
        .attendee-avatar-placeholder {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            border: 2px solid #e9ecef;
        }
        .attendee-more {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #e9ecef;
            color: #495057;
            font-size: 0.7rem;
            font-weight: 600;
            margin-left: 2px;
        }

        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }

        @media (max-width: 768px) {
            .stat-card .stat-value { font-size: 22px; }
            .event-status { position: static; display: inline-block; margin-bottom: 10px; }
            .attendee-avatar { width: 28px; height: 28px; }
            .attendee-avatar-placeholder { width: 28px; height: 28px; font-size: 0.6rem; }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-calendar-alt text-primary me-2"></i> Library Events</h2>
                <div class="d-flex flex-wrap gap-2">
                    <a href="add.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create Event</a>
                    <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Home</a>
                    <a href="calendar.php" class="btn btn-outline-info"><i class="fas fa-calendar-week"></i> Calendar</a>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-3 col-6">
                    <div class="stat-card border-start border-4 border-primary">
                        <div class="stat-value text-primary"><?= number_format($totalEvents) ?></div>
                        <div class="stat-label">Total Events</div>
                        <div class="stat-sub"><i class="fas fa-calendar"></i> All time</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card border-start border-4 border-success">
                        <div class="stat-value text-success"><?= number_format($upcomingEvents) ?></div>
                        <div class="stat-label">Upcoming</div>
                        <div class="stat-sub"><i class="fas fa-clock"></i> Scheduled</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card border-start border-4 border-warning">
                        <div class="stat-value text-warning"><?= number_format($ongoingEvents) ?></div>
                        <div class="stat-label">Ongoing</div>
                        <div class="stat-sub"><i class="fas fa-play"></i> In progress</div>
                    </div>
                </div>
                <div class="col-md-3 col-6">
                    <div class="stat-card border-start border-4 border-secondary">
                        <div class="stat-value text-secondary"><?= number_format($completedEvents) ?></div>
                        <div class="stat-label">Completed</div>
                        <div class="stat-sub"><i class="fas fa-check-circle"></i> Finished</div>
                    </div>
                </div>
            </div>

            <!-- Filter Card -->
            <div class="filter-card">
                <form method="GET" class="row g-3 align-items-end" id="filterForm">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Status</label>
                        <select name="status" class="form-select" id="statusSelect">
                            <option value="upcoming" <?= $status_filter=='upcoming'?'selected':'' ?>>Upcoming</option>
                            <option value="ongoing" <?= $status_filter=='ongoing'?'selected':'' ?>>Ongoing</option>
                            <option value="completed" <?= $status_filter=='completed'?'selected':'' ?>>Completed</option>
                            <option value="cancelled" <?= $status_filter=='cancelled'?'selected':'' ?>>Cancelled</option>
                            <option value="all" <?= $status_filter=='all'?'selected':'' ?>>All Events</option>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label fw-semibold">Search</label>
                        <div class="input-group">
                            <input type="text" name="search" id="searchInput" class="form-control" placeholder="Title or description..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Filter</button>
                        <a href="index.php" class="btn btn-secondary w-100">Reset</a>
                    </div>
                </form>
            </div>

            <!-- Events List -->
            <?php if(count($events) == 0): ?>
                <div class="alert alert-info text-center py-5">
                    <i class="fas fa-calendar-times fa-3x mb-2 d-block"></i>
                    <?php if(!empty($search) || $status_filter != 'upcoming'): ?>
                        No events match your filters.
                    <?php else: ?>
                        No events found. <a href="add.php" class="alert-link">Create your first event</a>.
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <?php foreach($events as $event): 
                    $statusClass = 'secondary';
                    $statusLabel = ucfirst($event['status']);
                    if($event['status'] == 'upcoming') { $statusClass = 'primary'; }
                    elseif($event['status'] == 'ongoing') { $statusClass = 'success'; }
                    elseif($event['status'] == 'completed') { $statusClass = 'secondary'; }
                    elseif($event['status'] == 'cancelled') { $statusClass = 'danger'; }
                    $borderColor = match($event['status']) {
                        'upcoming' => '#0d6efd',
                        'ongoing' => '#198754',
                        'completed' => '#6c757d',
                        'cancelled' => '#dc3545',
                        default => '#1e3c72'
                    };
                ?>
                <div class="event-card" style="border-left-color: <?= $borderColor ?>;">
                    <span class="event-status bg-<?= $statusClass ?> text-white"><?= $statusLabel ?></span>
                    <div class="row">
                        <div class="col-md-8">
                            <h4><?= htmlspecialchars($event['title']) ?></h4>
                            <p class="text-muted"><?= nl2br(htmlspecialchars($event['description'] ?? '')) ?></p>
                            <div class="row mt-3">
                                <div class="col-md-4"><i class="fas fa-calendar-day"></i> <?= date('d-m-Y', strtotime($event['event_date'])) ?></div>
                                <div class="col-md-4"><i class="fas fa-clock"></i> <?= date('h:i A', strtotime($event['start_time'])) ?> - <?= date('h:i A', strtotime($event['end_time'])) ?></div>
                                <div class="col-md-4"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($event['venue'] ?? '') ?></div>
                            </div>
                            <div class="mt-3 d-flex flex-wrap align-items-center gap-2">
                                <span class="badge bg-light text-dark"><i class="fas fa-users"></i> <?= $event['registered_count'] ?> registered</span>
                                <span class="badge bg-light text-dark"><i class="fas fa-check-circle"></i> <?= $event['attended_count'] ?> attended</span>
                                <?php if($event['max_attendees']): ?>
                                    <span class="badge bg-light text-dark"><i class="fas fa-users"></i> Max: <?= $event['max_attendees'] ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4 text-end">
                            <!-- Attendee Avatars -->
                            <?php if(!empty($event['attendees'])): ?>
                                <div class="mb-2">
                                    <span class="fw-semibold small">Recent attendees:</span>
                                    <div class="d-flex justify-content-end mt-1">
                                        <?php foreach($event['attendees'] as $att): ?>
                                            <?php if($att['photo_base64']): ?>
                                                <img src="<?= $att['photo_base64'] ?>" class="attendee-avatar" alt="Attendee" title="<?= htmlspecialchars($att['member_name']) ?>">
                                            <?php else: ?>
                                                <span class="attendee-avatar-placeholder" title="<?= htmlspecialchars($att['member_name']) ?>"><i class="fas fa-user"></i></span>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                        <?php if($event['registered_count'] > 5): ?>
                                            <span class="attendee-more">+<?= $event['registered_count'] - 5 ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="btn-group btn-group-sm">
                                <a href="attendees.php?id=<?= $event['id'] ?>" class="btn btn-outline-primary"><i class="fas fa-users"></i> Attendees</a>
                                <a href="checkin.php?id=<?= $event['id'] ?>" class="btn btn-outline-success"><i class="fas fa-check-circle"></i> Check-in</a>
                                <a href="edit.php?id=<?= $event['id'] ?>" class="btn btn-outline-secondary"><i class="fas fa-edit"></i></a>
                                <a href="delete.php?id=<?= $event['id'] ?>" class="btn btn-outline-danger" onclick="return confirm('Delete this event? This will also delete all attendance records.')"><i class="fas fa-trash"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
            <p class="small">
                <a href="calendar.php" class="btn btn-sm btn-outline-secondary"><i class="fas fa-calendar-week"></i> View Calendar</a>
                <a href="../index.php" class="btn btn-sm btn-outline-primary"><i class="fas fa-home"></i> Home</a>
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // ========== DEBOUNCE FOR SEARCH ==========
    let searchTimeout = null;
    document.getElementById('searchInput')?.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.getElementById('filterForm').submit();
        }, 500);
    });

    // ========== AUTO-SUBMIT ON STATUS CHANGE ==========
    document.getElementById('statusSelect')?.addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });

    // ========== TOOLTIP FOR ATTENDEE AVATARS ==========
    document.querySelectorAll('.attendee-avatar, .attendee-avatar-placeholder').forEach(el => {
        el.addEventListener('mouseenter', function(e) {
            const title = this.getAttribute('title');
            if (title) {
                const tooltip = document.createElement('div');
                tooltip.className = 'position-fixed bg-dark text-white px-2 py-1 rounded small';
                tooltip.style.zIndex = '9999';
                tooltip.style.pointerEvents = 'none';
                tooltip.textContent = title;
                document.body.appendChild(tooltip);
                const rect = this.getBoundingClientRect();
                tooltip.style.top = (rect.top - tooltip.offsetHeight - 8) + 'px';
                tooltip.style.left = (rect.left + rect.width/2 - tooltip.offsetWidth/2) + 'px';
                this._tooltip = tooltip;
            }
        });
        el.addEventListener('mouseleave', function() {
            if (this._tooltip) {
                this._tooltip.remove();
                delete this._tooltip;
            }
        });
    });
    </script>
</body>
</html>