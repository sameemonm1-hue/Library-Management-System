<?php
require_once __DIR__ . '/../config/functions.php';
// Session is already started by db.php (included via functions.php)
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $event_date = $_POST['event_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $venue = trim($_POST['venue']);
    $max_attendees = !empty($_POST['max_attendees']) ? intval($_POST['max_attendees']) : null;
    $registration_required = isset($_POST['registration_required']) ? 1 : 0;
    $status = $_POST['status'];
    
    if (!$title || !$event_date || !$start_time || !$end_time) {
        $error = "Please fill all required fields.";
    } elseif (strtotime($end_time) <= strtotime($start_time)) {
        $error = "End time must be after start time.";
    } else {
        try {
            $stmt = $db->prepare("INSERT INTO library_events 
                (title, description, event_date, start_time, end_time, venue, max_attendees, registration_required, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([$title, $description, $event_date, $start_time, $end_time, $venue, $max_attendees, $registration_required, $status]);
            $event_id = $db->lastInsertId();
            logActivity($_SESSION['username'], 'EVENT_ADD', "Created event: $title (ID: $event_id)");
            $success = "Event created successfully.";
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Event - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-plus-circle"></i> Create New Event</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?> <a href="index.php">View Events</a></div><?php endif; ?>
        
        <div class="form-card">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label">Event Title *</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="upcoming">Upcoming</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Description</label>
                        <textarea name="description" rows="3" class="form-control"></textarea>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Event Date *</label>
                        <input type="date" name="event_date" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Start Time *</label>
                        <input type="time" name="start_time" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">End Time *</label>
                        <input type="time" name="end_time" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Venue</label>
                        <input type="text" name="venue" class="form-control" placeholder="Library Hall, Room 101...">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Max Attendees (optional)</label>
                        <input type="number" name="max_attendees" class="form-control" min="0">
                    </div>
                    <div class="col-md-4">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" name="registration_required" id="regRequired" checked>
                            <label class="form-check-label" for="regRequired">Registration Required</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Event</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>