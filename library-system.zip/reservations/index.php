<?php
/**
 * Reservations Queue Module - Integrated with Hold Management
 * Features:
 * - Full integration with book_holds table
 * - Book cover and member photo display
 * - Enhanced statistics with hold counts
 * - Status badges with icons
 * - Queue position calculation
 * - Advanced filtering
 * - Unified gradient color scheme
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Ensure reservations_queue table exists with proper structure
$db->exec("CREATE TABLE IF NOT EXISTS reservations_queue(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    priority INTEGER DEFAULT 1,
    requested_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status TEXT DEFAULT 'waiting',
    notified_at DATETIME,
    processed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    hold_id INTEGER DEFAULT NULL,
    FOREIGN KEY (hold_id) REFERENCES book_holds(id) ON DELETE SET NULL
)");

// Add hold_id column if missing
$cols = $db->query("PRAGMA table_info(reservations_queue)")->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('hold_id', $cols)) {
    $db->exec("ALTER TABLE reservations_queue ADD COLUMN hold_id INTEGER DEFAULT NULL");
}

// Get statistics
$totalReservations = $db->query("SELECT COUNT(*) FROM reservations_queue")->fetchColumn();
$pendingReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'waiting'")->fetchColumn();
$notifiedReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'notified'")->fetchColumn();
$borrowedReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'borrowed'")->fetchColumn();
$expiredReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'expired'")->fetchColumn();
$cancelledReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'cancelled'")->fetchColumn();

// Also get hold statistics
$totalHolds = $db->query("SELECT COUNT(*) FROM book_holds WHERE status IN ('pending', 'available')")->fetchColumn();
$pendingHolds = $db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'pending'")->fetchColumn();
$availableHolds = $db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'available'")->fetchColumn();

// Filter parameters
$status_filter = $_GET['status'] ?? '';
$book_filter = $_GET['book'] ?? '';
$member_filter = $_GET['member'] ?? '';
$show_holds = isset($_GET['show_holds']) && $_GET['show_holds'] == '1';

// Build query - UNION of reservations_queue and book_holds
if ($show_holds) {
    // Show holds from book_holds table
    $sql = "SELECT 
                h.id as id,
                h.book_barcode as book_barcode,
                h.admno as admno,
                h.member_name as member_name,
                1 as priority,
                h.hold_date as requested_date,
                h.expiry_date as expiry_date,
                h.status as status,
                h.created_at as created_at,
                h.notified_at as notified_at,
                NULL as processed_at,
                h.id as hold_id,
                'hold' as source,
                b.title as book_title,
                b.cover_path as cover_path,
                m.photo_path as photo_path
            FROM book_holds h
            LEFT JOIN books b ON h.book_barcode = b.barcode
            LEFT JOIN members m ON h.admno = m.admno
            WHERE 1=1";
} else {
    // Show from reservations_queue
    $sql = "SELECT 
                rq.id as id,
                rq.book_barcode as book_barcode,
                rq.admno as admno,
                rq.member_name as member_name,
                rq.priority as priority,
                rq.requested_date as requested_date,
                rq.expiry_date as expiry_date,
                rq.status as status,
                rq.created_at as created_at,
                rq.notified_at as notified_at,
                rq.processed_at as processed_at,
                rq.hold_id as hold_id,
                'reservation' as source,
                b.title as book_title,
                b.cover_path as cover_path,
                m.photo_path as photo_path
            FROM reservations_queue rq
            LEFT JOIN books b ON rq.book_barcode = b.barcode
            LEFT JOIN members m ON rq.admno = m.admno
            WHERE 1=1";
}

$params = [];

if ($status_filter) {
    if ($show_holds) {
        $sql .= " AND h.status = ?";
    } else {
        $sql .= " AND rq.status = ?";
    }
    $params[] = $status_filter;
}

if ($book_filter) {
    $sql .= " AND (b.title LIKE ? OR b.barcode LIKE ?)";
    $like = "%$book_filter%";
    $params[] = $like;
    $params[] = $like;
}

if ($member_filter) {
    $sql .= " AND (m.name LIKE ? OR rq.admno LIKE ?)";
    $like = "%$member_filter%";
    $params[] = $like;
    $params[] = $like;
}

// Add sorting
if ($show_holds) {
    $sql .= " ORDER BY h.hold_date ASC, h.created_at ASC";
} else {
    $sql .= " ORDER BY rq.priority DESC, rq.requested_date ASC, rq.created_at ASC";
}

$stmt = $db->prepare($sql);
$stmt->execute($params);
$reservations = $stmt->fetchAll();

// Add images and queue positions
foreach ($reservations as &$r) {
    $r['cover_base64'] = getImageBase64($r['cover_path'] ?? '');
    $r['photo_base64'] = getImageBase64($r['photo_path'] ?? '');
    
    // Calculate queue position for pending items
    if ($r['status'] == 'waiting' || $r['status'] == 'pending') {
        $posStmt = $db->prepare("SELECT COUNT(*) + 1 as pos FROM book_holds 
                                 WHERE book_barcode = ? AND status = 'pending' 
                                 AND hold_date < (SELECT hold_date FROM book_holds WHERE id = ?)");
        $posStmt->execute([$r['book_barcode'], $r['hold_id']]);
        $r['queue_position'] = (int)$posStmt->fetchColumn();
    } else {
        $r['queue_position'] = null;
    }
}

$statusMap = [
    'waiting' => ['label' => 'Waiting', 'class' => 'warning', 'icon' => 'fa-clock'],
    'pending' => ['label' => 'Pending', 'class' => 'warning', 'icon' => 'fa-clock'],
    'notified' => ['label' => 'Notified', 'class' => 'info', 'icon' => 'fa-bell'],
    'available' => ['label' => 'Available', 'class' => 'success', 'icon' => 'fa-check-circle'],
    'borrowed' => ['label' => 'Borrowed', 'class' => 'success', 'icon' => 'fa-check-double'],
    'picked_up' => ['label' => 'Picked Up', 'class' => 'success', 'icon' => 'fa-check-double'],
    'expired' => ['label' => 'Expired', 'class' => 'danger', 'icon' => 'fa-times-circle'],
    'cancelled' => ['label' => 'Cancelled', 'class' => 'secondary', 'icon' => 'fa-ban']
];

renderHeader('Reservations & Holds Queue');
?>

<style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
    }
    body { background: #f0f2f5; font-family: 'Inter', sans-serif; }
    .settings-bar { display: none !important; }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border: none;
        border-radius: 12px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
        position: relative;
        overflow: hidden;
        cursor: pointer;
    }
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    .stat-card .stat-icon {
        position: absolute;
        right: 15px;
        top: 15px;
        font-size: 32px;
        opacity: 0.2;
        color: white;
    }
    .stat-card .stat-value {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 2px;
        color: white;
    }
    .stat-card .stat-label {
        font-size: 14px;
        color: rgba(255,255,255,0.9);
    }
    .stat-card.hold-card {
        background: linear-gradient(135deg, #6f42c1, #8b5cf6);
    }
    
    .card-header {
        background: var(--primary-color) !important;
        color: white !important;
        border-radius: 12px 12px 0 0 !important;
    }
    .card-header .badge { background: rgba(255,255,255,0.2); color: white; }
    
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-purple {
        background: linear-gradient(135deg, #6f42c1, #8b5cf6);
        color: #fff;
        border: none;
    }
    .btn-purple:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(111, 66, 193, 0.4);
        color: #fff;
    }
    
    .table thead th {
        background: var(--primary-color);
        color: white;
        border-bottom: none;
        font-weight: 600;
        font-size: 0.85rem;
        white-space: nowrap;
    }
    .table tfoot { background: #f8f9fa; font-weight: 600; }
    
    .member-photo-thumb {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #e9ecef;
        transition: all 0.3s ease;
        flex-shrink: 0;
    }
    .member-photo-thumb:hover {
        transform: scale(1.1);
        border-color: var(--primary-color);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .member-photo-placeholder {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 1.2rem;
        border: 2px solid #e9ecef;
        flex-shrink: 0;
    }
    
    .book-cover-thumb {
        width: 35px;
        height: 50px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
        flex-shrink: 0;
    }
    .book-cover-thumb:hover {
        transform: scale(1.1);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10;
        position: relative;
    }
    .book-cover-placeholder {
        width: 35px;
        height: 50px;
        border-radius: 4px;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.8rem;
        border: 1px solid #e9ecef;
        flex-shrink: 0;
    }
    
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        color: white;
    }
    .status-badge.bg-warning { color: #333; }
    
    .priority-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: 600;
    }
    .priority-high {
        background: #f8d7da;
        color: #721c24;
    }
    .priority-normal {
        background: #e9ecef;
        color: #495057;
    }
    
    .queue-badge {
        display: inline-block;
        background: #e9ecef;
        color: #495057;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .queue-badge.top {
        background: #ffc107;
        color: #856404;
    }
    
    .source-badge {
        font-size: 0.6rem;
        padding: 2px 8px;
        border-radius: 12px;
        font-weight: 600;
        background: #e9ecef;
        color: #495057;
    }
    .source-badge.hold {
        background: #6f42c1;
        color: white;
    }
    .source-badge.reservation {
        background: #17a2b8;
        color: white;
    }
    
    .btn-group-actions {
        display: flex;
        gap: 4px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .btn-group-actions .btn {
        padding: 4px 8px;
        font-size: 0.75rem;
    }
    
    .source-filter {
        display: flex;
        gap: 10px;
        align-items: center;
    }
    .source-filter .btn-check + .btn {
        border-radius: 20px;
        padding: 5px 15px;
        font-size: 0.8rem;
    }
    .source-filter .btn-check:checked + .btn {
        background: var(--primary-color);
        color: white;
    }
    
    @media print {
        .no-print { display: none !important; }
        .settings-bar { display: none !important; }
        .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
        .stat-card .stat-value { color: #333 !important; }
        .stat-card .stat-label { color: #555 !important; }
        .stat-card .stat-icon { display: none !important; }
        .card-header { background: #f8f9fa !important; color: #333 !important; }
        .table thead th { background: #333 !important; color: white !important; }
    }
    @media (max-width: 768px) {
        .stat-card .stat-value { font-size: 22px; }
        .stat-card { padding: 15px; }
        .stat-card .stat-icon { font-size: 28px; }
        .member-photo-thumb { width: 32px; height: 32px; }
        .book-cover-thumb { width: 28px; height: 40px; }
        .btn-group-actions .btn { padding: 3px 6px; font-size: 0.7rem; }
    }
</style>

<div class="container-fluid px-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-calendar-check"></i> Reservations & Holds Queue</h2>
            <p class="text-muted">Manage all book hold requests and reservations in one place</p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="add.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Reservation</a>
            <a href="../circulation/holds.php" class="btn btn-purple btn-sm"><i class="fas fa-hand-paper"></i> Manage Holds</a>
            <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <!-- Statistics Cards - Unified Gradient -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card" onclick="window.location.href='?status=all'">
                <div class="stat-icon"><i class="fas fa-list"></i></div>
                <div class="stat-value"><?= number_format($totalReservations + $totalHolds) ?></div>
                <div class="stat-label">Total Requests</div>
            </div>
        </div>
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card" onclick="window.location.href='?status=waiting'">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= number_format($pendingReservations + $pendingHolds) ?></div>
                <div class="stat-label">Pending</div>
            </div>
        </div>
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card" onclick="window.location.href='?status=available'">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value"><?= number_format($availableHolds) ?></div>
                <div class="stat-label">Available</div>
            </div>
        </div>
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card" onclick="window.location.href='?status=notified'">
                <div class="stat-icon"><i class="fas fa-bell"></i></div>
                <div class="stat-value"><?= number_format($notifiedReservations) ?></div>
                <div class="stat-label">Notified</div>
            </div>
        </div>
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card" onclick="window.location.href='?status=borrowed'">
                <div class="stat-icon"><i class="fas fa-check-double"></i></div>
                <div class="stat-value"><?= number_format($borrowedReservations) ?></div>
                <div class="stat-label">Borrowed</div>
            </div>
        </div>
        <div class="col-md-2 col-4 col-sm-3">
            <div class="stat-card hold-card" onclick="window.location.href='?show_holds=1'">
                <div class="stat-icon"><i class="fas fa-hand-paper"></i></div>
                <div class="stat-value"><?= number_format($totalHolds) ?></div>
                <div class="stat-label">Active Holds</div>
            </div>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card shadow-sm border-0 mb-4 no-print">
        <div class="card-header">
            <h6 class="mb-0"><i class="fas fa-filter"></i> Filters</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All</option>
                        <option value="waiting" <?= $status_filter=='waiting' ? 'selected' : '' ?>>Pending</option>
                        <option value="available" <?= $status_filter=='available' ? 'selected' : '' ?>>Available</option>
                        <option value="notified" <?= $status_filter=='notified' ? 'selected' : '' ?>>Notified</option>
                        <option value="borrowed" <?= $status_filter=='borrowed' ? 'selected' : '' ?>>Borrowed</option>
                        <option value="picked_up" <?= $status_filter=='picked_up' ? 'selected' : '' ?>>Picked Up</option>
                        <option value="expired" <?= $status_filter=='expired' ? 'selected' : '' ?>>Expired</option>
                        <option value="cancelled" <?= $status_filter=='cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Book (Title/Barcode)</label>
                    <input type="text" name="book" class="form-control" value="<?= htmlspecialchars($book_filter) ?>" placeholder="Search by title or barcode">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Member (Name/Adm No)</label>
                    <input type="text" name="member" class="form-control" value="<?= htmlspecialchars($member_filter) ?>" placeholder="Name or admission number">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Show</label>
                    <div class="source-filter">
                        <input type="radio" class="btn-check" name="show_holds" id="show_reservations" value="0" <?= !$show_holds ? 'checked' : '' ?>>
                        <label class="btn btn-outline-secondary btn-sm" for="show_reservations">Reservations</label>
                        <input type="radio" class="btn-check" name="show_holds" id="show_holds" value="1" <?= $show_holds ? 'checked' : '' ?>>
                        <label class="btn btn-outline-secondary btn-sm" for="show_holds">Holds</label>
                    </div>
                </div>
                <div class="col-md-2 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
                    <a href="index.php" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Results Table -->
    <div class="card shadow-sm border-0">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
            <span><i class="fas fa-list"></i> 
                <?= $show_holds ? 'Active Holds' : 'Reservations' ?>
                <span class="badge ms-2"><?= count($reservations) ?> records</span>
            </span>
            <span>
                <?php if ($show_holds): ?>
                    <a href="index.php" class="btn btn-sm btn-light">Switch to Reservations</a>
                <?php else: ?>
                    <a href="?show_holds=1" class="btn btn-sm btn-light">View Holds</a>
                <?php endif; ?>
            </span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center" style="width:50px;">Cover</th>
                            <th>Book</th>
                            <th class="text-center" style="width:50px;">Photo</th>
                            <th>Member</th>
                            <th class="text-center">Priority</th>
                            <th class="text-center">Queue</th>
                            <th class="text-center">Requested</th>
                            <th class="text-center">Expiry</th>
                            <th class="text-center">Source</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reservations)): ?>
                        <tr>
                            <td colspan="12" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                No <?= $show_holds ? 'holds' : 'reservations' ?> found.
                                <?php if (!empty($book_filter) || !empty($member_filter) || !empty($status_filter)): ?>
                                    <br><small>Try adjusting your filters.</small>
                                <?php else: ?>
                                    <br><a href="add.php" class="btn btn-sm btn-primary mt-2">Create your first reservation</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($reservations as $index => $r): 
                                $statusInfo = $statusMap[$r['status']] ?? ['label' => ucfirst($r['status']), 'class' => 'secondary', 'icon' => 'fa-circle'];
                                $isPriority = ($r['priority'] ?? 1) > 1;
                                $isExpired = (strtotime($r['expiry_date']) < time() && in_array($r['status'], ['waiting', 'pending', 'available']));
                                $source = $r['source'] ?? 'reservation';
                                $isHold = $source === 'hold';
                                $queuePos = $r['queue_position'] ?? null;
                            ?>
                            <tr class="<?= $isExpired ? 'table-warning' : '' ?>">
                                <td class="text-center fw-bold"><?= $index + 1 ?></td>
                                <td class="text-center">
                                    <?php if ($r['cover_base64']): ?>
                                        <img src="<?= $r['cover_base64'] ?>" class="book-cover-thumb" alt="Book Cover">
                                    <?php else: ?>
                                        <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div>
                                        <strong><?= htmlspecialchars($r['book_title'] ?? 'Unknown Book') ?></strong>
                                        <br><small class="text-muted"><?= htmlspecialchars($r['book_barcode']) ?></small>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <?php if ($r['photo_base64']): ?>
                                        <img src="<?= $r['photo_base64'] ?>" class="member-photo-thumb" alt="Member Photo">
                                    <?php else: ?>
                                        <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div>
                                        <strong><?= htmlspecialchars($r['member_name'] ?? 'Deleted Member') ?></strong>
                                        <br><small class="text-muted"><?= htmlspecialchars($r['admno']) ?></small>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <?php if (!$isHold): ?>
                                    <span class="priority-badge <?= $isPriority ? 'priority-high' : 'priority-normal' ?>">
                                        <i class="fas fa-<?= $isPriority ? 'exclamation-triangle' : 'circle' ?>"></i>
                                        <?= $r['priority'] ?? 1 ?>
                                    </span>
                                    <?php else: ?>
                                    <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($queuePos && in_array($r['status'], ['waiting', 'pending'])): ?>
                                        <span class="queue-badge <?= $queuePos <= 3 ? 'top' : '' ?>">
                                            #<?= $queuePos ?>
                                            <?php if ($queuePos <= 3): ?>
                                                <i class="fas fa-star text-warning"></i>
                                            <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?= date('d-m-Y', strtotime($r['requested_date'])) ?></td>
                                <td class="text-center">
                                    <?= date('d-m-Y', strtotime($r['expiry_date'])) ?>
                                    <?php if ($isExpired): ?>
                                        <br><span class="badge bg-danger">Expired</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="source-badge <?= $isHold ? 'hold' : 'reservation' ?>">
                                        <i class="fas fa-<?= $isHold ? 'hand-paper' : 'bookmark' ?>"></i>
                                        <?= $isHold ? 'Hold' : 'Reservation' ?>
                                    </span>
                                    <?php if ($r['hold_id']): ?>
                                        <br><small class="text-muted">Hold #<?= $r['hold_id'] ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge bg-<?= $statusInfo['class'] ?>">
                                        <i class="fas <?= $statusInfo['icon'] ?>"></i>
                                        <?= $statusInfo['label'] ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group-actions">
                                        <?php if (in_array($r['status'], ['waiting', 'pending']) && !$isHold): ?>
                                            <a href="notify.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-info" 
                                               title="Mark as Notified" 
                                               onclick="return confirm('Confirm that the member has been notified?')">
                                                <i class="fas fa-bell"></i>
                                            </a>
                                            <a href="process.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-success" 
                                               title="Issue Book" 
                                               onclick="return confirm('Issue this book to the member?')">
                                                <i class="fas fa-book"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($isHold && in_array($r['status'], ['pending'])): ?>
                                            <a href="../circulation/holds.php?mark_available=<?= $r['hold_id'] ?>" 
                                               class="btn btn-sm btn-outline-success" 
                                               title="Mark Available">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (in_array($r['status'], ['waiting', 'pending', 'notified', 'available']) && !$isHold): ?>
                                            <a href="cancel.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               title="Cancel" 
                                               onclick="return confirm('Cancel this request?')">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if ($isHold && in_array($r['status'], ['pending', 'available'])): ?>
                                            <a href="../circulation/holds.php?cancel=<?= $r['hold_id'] ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               title="Cancel Hold">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-outline-secondary" 
                                                title="View Details" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#viewModal"
                                                data-id="<?= $r['id'] ?>"
                                                data-hold-id="<?= $r['hold_id'] ?? '' ?>"
                                                data-source="<?= $source ?>"
                                                data-book="<?= htmlspecialchars($r['book_title'] ?? 'Unknown') ?>"
                                                data-barcode="<?= htmlspecialchars($r['book_barcode']) ?>"
                                                data-cover="<?= $r['cover_base64'] ?? '' ?>"
                                                data-member="<?= htmlspecialchars($r['member_name'] ?? 'Deleted') ?>"
                                                data-admno="<?= htmlspecialchars($r['admno']) ?>"
                                                data-photo="<?= $r['photo_base64'] ?? '' ?>"
                                                data-priority="<?= $r['priority'] ?? 1 ?>"
                                                data-queue="<?= $queuePos ?? 'N/A' ?>"
                                                data-requested="<?= date('d-m-Y', strtotime($r['requested_date'])) ?>"
                                                data-expiry="<?= date('d-m-Y', strtotime($r['expiry_date'])) ?>"
                                                data-status="<?= $statusInfo['label'] ?>"
                                                data-statusclass="<?= $statusInfo['class'] ?>"
                                                data-created="<?= date('d-m-Y H:i', strtotime($r['created_at'])) ?>"
                                                data-notified="<?= $r['notified_at'] ? date('d-m-Y H:i', strtotime($r['notified_at'])) : 'Not yet' ?>"
                                                data-processed="<?= $r['processed_at'] ? date('d-m-Y H:i', strtotime($r['processed_at'])) : 'Not yet' ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($reservations)): ?>
                    <tfoot>
                        <tr class="fw-bold">
                            <td colspan="12" class="text-end">Total: <?= count($reservations) ?> <?= $show_holds ? 'holds' : 'reservations' ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-info-circle"></i> Request Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Populated by JavaScript -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const viewModal = document.getElementById('viewModal');
viewModal.addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    const data = button.dataset;
    
    const coverHtml = data.cover ? `<img src="${data.cover}" style="max-width:120px; max-height:160px; object-fit:contain; border-radius:8px; border:1px solid #e9ecef; padding:4px;">` : 
        `<div style="width:120px;height:160px;background:#e9ecef;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#6c757d;"><i class="fas fa-book fa-4x"></i></div>`;
    
    const photoHtml = data.photo ? `<img src="${data.photo}" style="width:80px;height:80px;object-fit:cover;border-radius:50%;border:2px solid <?= $reportPrimaryColor ?>;">` :
        `<div style="width:80px;height:80px;background:linear-gradient(135deg,#e9ecef,#dee2e6);border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid <?= $reportPrimaryColor ?>;color:#6c757d;"><i class="fas fa-user fa-3x"></i></div>`;
    
    const statusBadge = `<span class="badge bg-${data.statusclass}">${data.status}</span>`;
    const sourceBadge = data.source === 'hold' ? 
        `<span class="badge bg-purple"><i class="fas fa-hand-paper"></i> Hold</span>` :
        `<span class="badge bg-info"><i class="fas fa-bookmark"></i> Reservation</span>`;
    const priorityBadge = data.priority > 1 ? 
        `<span class="badge bg-danger"><i class="fas fa-exclamation-triangle"></i> High (${data.priority})</span>` :
        `<span class="badge bg-secondary">Normal (${data.priority})</span>`;
    
    document.getElementById('viewModalBody').innerHTML = `
        <div class="row g-3">
            <div class="col-md-6 text-center">
                <div class="mb-2"><strong>Book Cover</strong></div>
                ${coverHtml}
                <div class="mt-2">
                    <strong>${data.book}</strong><br>
                    <small class="text-muted">Barcode: ${data.barcode}</small>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="mb-2"><strong>Member Photo</strong></div>
                ${photoHtml}
                <div class="mt-2">
                    <strong>${data.member}</strong><br>
                    <small class="text-muted">Adm No: ${data.admno}</small>
                </div>
            </div>
            <div class="col-12">
                <hr>
                <div class="row">
                    <div class="col-6"><strong>Source:</strong> ${sourceBadge}</div>
                    <div class="col-6"><strong>Status:</strong> ${statusBadge}</div>
                    <div class="col-6"><strong>Priority:</strong> ${priorityBadge}</div>
                    <div class="col-6"><strong>Queue Position:</strong> ${data.queue}</div>
                    <div class="col-6"><strong>Requested Date:</strong> ${data.requested}</div>
                    <div class="col-6"><strong>Expiry Date:</strong> ${data.expiry}</div>
                    <div class="col-6"><strong>Created:</strong> ${data.created}</div>
                    <div class="col-6"><strong>Notified At:</strong> ${data.notified}</div>
                    <div class="col-6"><strong>Processed At:</strong> ${data.processed}</div>
                    ${data.holdId ? `<div class="col-12"><strong>Linked Hold ID:</strong> #${data.holdId}</div>` : ''}
                </div>
            </div>
        </div>
    `;
});

// Auto-dismiss alerts
setTimeout(function() {
    let alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        let bsAlert = new bootstrap.Alert(alert);
        setTimeout(() => bsAlert.close(), 5000);
    });
}, 3000);

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'add.php';
    }
    if (e.ctrlKey && e.key === 'h') {
        e.preventDefault();
        window.location.href = '?show_holds=1';
    }
});
</script>

<?php renderFooter(); ?>