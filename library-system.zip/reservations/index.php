<?php
/**
 * Reservations Queue Module - Complete Update
 * Features:
 * - Book cover display for each reservation
 * - Member photo display
 * - Enhanced statistics cards
 * - Improved status badges with icons
 * - View details modal with full information
 * - Responsive design
 * - Advanced filtering
 * - Priority indicators
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// CSRF token for cancel/notify/process links
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check admin login
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== ENSURE TABLE EXISTS ==========
$db->exec("CREATE TABLE IF NOT EXISTS reservations_queue(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_barcode TEXT NOT NULL,
    admno TEXT NOT NULL,
    member_name TEXT NOT NULL,
    priority INTEGER DEFAULT 1,
    requested_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    status TEXT DEFAULT 'waiting',
    notified_at DATETIME,
    processed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// ========== GET STATISTICS ==========
$totalReservations = $db->query("SELECT COUNT(*) FROM reservations_queue")->fetchColumn();
$pendingReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'waiting'")->fetchColumn();
$notifiedReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'notified'")->fetchColumn();
$expiredReservations = $db->query("SELECT COUNT(*) FROM reservations_queue WHERE status = 'expired'")->fetchColumn();

// ========== GET FILTERS ==========
$status_filter = $_GET['status'] ?? '';
$book_filter = $_GET['book'] ?? '';
$member_filter = $_GET['member'] ?? '';

// ========== BUILD QUERY ==========
$sql = "SELECT rq.*, 
        m.name as member_name, m.admno, m.photo_path,
        b.title as book_title, b.barcode as book_barcode, b.cover_path
        FROM reservations_queue rq
        LEFT JOIN members m ON rq.admno = m.admno
        LEFT JOIN books b ON rq.book_barcode = b.barcode
        WHERE 1=1";
$params = [];

if ($status_filter) {
    $sql .= " AND rq.status = ?";
    $params[] = $status_filter;
}
if ($book_filter) {
    $sql .= " AND (b.title LIKE ? OR b.barcode LIKE ?)";
    $like = "%$book_filter%";
    $params[] = $like;
    $params[] = $like;
}
if ($member_filter) {
    $sql .= " AND (m.name LIKE ? OR rq.admno LIKE ?)";
    $like = "%$member_filter%";
    $params[] = $like;
    $params[] = $like;
}
$sql .= " ORDER BY rq.priority DESC, rq.requested_date ASC, rq.created_at ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$reservations = $stmt->fetchAll();

// Add base64 images
foreach ($reservations as &$r) {
    $r['cover_base64'] = getImageBase64($r['cover_path'] ?? '');
    $r['photo_base64'] = getImageBase64($r['photo_path'] ?? '');
}

// ========== STATUS MAP ==========
$statusMap = [
    'waiting' => ['label' => 'Waiting', 'class' => 'warning', 'icon' => 'fa-clock'],
    'notified' => ['label' => 'Notified', 'class' => 'info', 'icon' => 'fa-bell'],
    'borrowed' => ['label' => 'Borrowed', 'class' => 'success', 'icon' => 'fa-check-circle'],
    'expired' => ['label' => 'Expired', 'class' => 'danger', 'icon' => 'fa-times-circle'],
    'cancelled' => ['label' => 'Cancelled', 'class' => 'secondary', 'icon' => 'fa-ban']
];

renderHeader('Reservations Queue');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Stat Cards */
.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    height: 100%;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
.stat-card .stat-icon {
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 32px;
    opacity: 0.15;
}
.stat-card .stat-value {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 2px;
}
.stat-card .stat-label {
    font-size: 14px;
    color: #6c757d;
}

/* Photo Styles */
.member-photo-thumb {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
    flex-shrink: 0;
}
.member-photo-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.member-photo-placeholder {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 1.2rem;
    border: 2px solid #e9ecef;
    flex-shrink: 0;
}

.book-cover-thumb {
    width: 35px;
    height: 50px;
    object-fit: cover;
    border-radius: 4px;
    border: 1px solid #e9ecef;
    transition: all 0.3s ease;
    flex-shrink: 0;
}
.book-cover-thumb:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10;
    position: relative;
}
.book-cover-placeholder {
    width: 35px;
    height: 50px;
    border-radius: 4px;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 0.8rem;
    border: 1px solid #e9ecef;
    flex-shrink: 0;
}

/* Cell Layouts */
.reservation-book-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.reservation-member-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Status Badge */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

/* Priority Badge */
.priority-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
    font-weight: 600;
}
.priority-high {
    background: #f8d7da;
    color: #721c24;
}
.priority-normal {
    background: #e9ecef;
    color: #495057;
}

/* Action Buttons */
.btn-group-actions {
    display: flex;
    gap: 4px;
    flex-wrap: wrap;
}
.btn-group-actions .btn {
    padding: 4px 8px;
    font-size: 0.75rem;
}

/* Responsive */
@media (max-width: 768px) {
    .stat-card .stat-value { font-size: 22px; }
    .stat-card { padding: 15px; }
    .stat-card .stat-icon { font-size: 28px; }
    .member-photo-thumb { width: 32px; height: 32px; }
    .book-cover-thumb { width: 28px; height: 40px; }
    .reservation-book-cell { gap: 6px; }
    .reservation-member-cell { gap: 6px; }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-calendar-check text-primary"></i> Reservations Queue</h2>
            <p class="text-muted">Manage book hold requests and reservations</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="add.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Reservation</a>
            <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card border-start border-4 border-primary">
                <div class="stat-icon"><i class="fas fa-list"></i></div>
                <div class="stat-value text-primary"><?= number_format($totalReservations) ?></div>
                <div class="stat-label">Total Reservations</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card border-start border-4 border-warning">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value text-warning"><?= number_format($pendingReservations) ?></div>
                <div class="stat-label">Waiting</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card border-start border-4 border-info">
                <div class="stat-icon"><i class="fas fa-bell"></i></div>
                <div class="stat-value text-info"><?= number_format($notifiedReservations) ?></div>
                <div class="stat-label">Notified</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card border-start border-4 border-danger">
                <div class="stat-icon"><i class="fas fa-times-circle"></i></div>
                <div class="stat-value text-danger"><?= number_format($expiredReservations) ?></div>
                <div class="stat-label">Expired</div>
            </div>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white">
            <h6 class="mb-0"><i class="fas fa-filter text-primary"></i> Filters</h6>
        </div>
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All</option>
                        <option value="waiting" <?= $status_filter=='waiting' ? 'selected' : '' ?>>Waiting</option>
                        <option value="notified" <?= $status_filter=='notified' ? 'selected' : '' ?>>Notified</option>
                        <option value="borrowed" <?= $status_filter=='borrowed' ? 'selected' : '' ?>>Borrowed</option>
                        <option value="expired" <?= $status_filter=='expired' ? 'selected' : '' ?>>Expired</option>
                        <option value="cancelled" <?= $status_filter=='cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Book (Title/Barcode)</label>
                    <input type="text" name="book" class="form-control" value="<?= htmlspecialchars($book_filter) ?>" placeholder="Search by title or barcode">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Member (Name/Adm No)</label>
                    <input type="text" name="member" class="form-control" value="<?= htmlspecialchars($member_filter) ?>" placeholder="Name or admission number">
                </div>
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search"></i> Filter</button>
                    <a href="index.php" class="btn btn-secondary w-100">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Reservations Table -->
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
            <span><i class="fas fa-list text-primary"></i> Current Reservations</span>
            <span class="badge bg-secondary"><?= count($reservations) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th style="width:50px;">Cover</th>
                            <th>Book</th>
                            <th style="width:50px;">Photo</th>
                            <th>Member</th>
                            <th>Priority</th>
                            <th>Requested</th>
                            <th>Expiry</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reservations)): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted py-4">
                                <i class="fas fa-inbox fa-3x mb-2 d-block"></i>
                                No reservations found.
                                <?php if (!empty($book_filter) || !empty($member_filter) || !empty($status_filter)): ?>
                                    <br><small>Try adjusting your filters.</small>
                                <?php else: ?>
                                    <br><a href="add.php" class="btn btn-sm btn-primary mt-2">Create your first reservation</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($reservations as $index => $r): 
                                $statusInfo = $statusMap[$r['status']] ?? ['label' => ucfirst($r['status']), 'class' => 'secondary', 'icon' => 'fa-circle'];
                                $isPriority = ($r['priority'] ?? 1) > 1;
                                $isExpired = (strtotime($r['expiry_date']) < time() && $r['status'] == 'waiting');
                            ?>
                            <tr>
                                <td class="text-center fw-bold"><?= $index + 1 ?></td>
                                <td class="text-center">
                                    <?php if ($r['cover_base64']): ?>
                                        <img src="<?= $r['cover_base64'] ?>" class="book-cover-thumb" alt="Book Cover">
                                    <?php else: ?>
                                        <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="reservation-book-cell">
                                        <div>
                                            <strong><?= htmlspecialchars($r['book_title'] ?? 'Unknown Book') ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($r['book_barcode']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <?php if ($r['photo_base64']): ?>
                                        <img src="<?= $r['photo_base64'] ?>" class="member-photo-thumb" alt="Member Photo">
                                    <?php else: ?>
                                        <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="reservation-member-cell">
                                        <div>
                                            <strong><?= htmlspecialchars($r['member_name'] ?? 'Deleted Member') ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($r['admno']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="priority-badge <?= $isPriority ? 'priority-high' : 'priority-normal' ?>">
                                        <i class="fas fa-<?= $isPriority ? 'exclamation-triangle' : 'circle' ?>"></i>
                                        <?= $r['priority'] ?? 1 ?>
                                    </span>
                                </td>
                                <td><?= date('d-m-Y', strtotime($r['requested_date'])) ?></td>
                                <td>
                                    <?= date('d-m-Y', strtotime($r['expiry_date'])) ?>
                                    <?php if ($isExpired): ?>
                                        <br><span class="badge bg-danger">Expired</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-badge bg-<?= $statusInfo['class'] ?> text-white">
                                        <i class="fas <?= $statusInfo['icon'] ?>"></i>
                                        <?= $statusInfo['label'] ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group-actions">
                                        <?php if ($r['status'] == 'waiting'): ?>
                                            <a href="notify.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-info" 
                                               title="Mark as Notified" 
                                               onclick="return confirm('Confirm that the member has been notified?')">
                                                <i class="fas fa-bell"></i>
                                            </a>
                                            <a href="process.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-success" 
                                               title="Issue Book" 
                                               onclick="return confirm('Issue this book to the member?')">
                                                <i class="fas fa-book"></i>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (in_array($r['status'], ['waiting', 'notified'])): ?>
                                            <a href="cancel.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" 
                                               class="btn btn-sm btn-outline-danger" 
                                               title="Cancel Reservation" 
                                               onclick="return confirm('Cancel this reservation?')">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-outline-secondary" 
                                                title="View Details" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#viewModal"
                                                data-id="<?= $r['id'] ?>"
                                                data-book="<?= htmlspecialchars($r['book_title'] ?? 'Unknown') ?>"
                                                data-barcode="<?= htmlspecialchars($r['book_barcode']) ?>"
                                                data-cover="<?= $r['cover_base64'] ?? '' ?>"
                                                data-member="<?= htmlspecialchars($r['member_name'] ?? 'Deleted') ?>"
                                                data-admno="<?= htmlspecialchars($r['admno']) ?>"
                                                data-photo="<?= $r['photo_base64'] ?? '' ?>"
                                                data-priority="<?= $r['priority'] ?? 1 ?>"
                                                data-requested="<?= date('d-m-Y', strtotime($r['requested_date'])) ?>"
                                                data-expiry="<?= date('d-m-Y', strtotime($r['expiry_date'])) ?>"
                                                data-status="<?= $statusInfo['label'] ?>"
                                                data-statusclass="<?= $statusInfo['class'] ?>"
                                                data-created="<?= date('d-m-Y H:i', strtotime($r['created_at'])) ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($reservations)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="10" class="text-end">Total: <?= count($reservations) ?> reservations</td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ========== VIEW DETAILS MODAL ========== -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-info-circle"></i> Reservation Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Populated by JavaScript -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="footer">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== VIEW DETAILS MODAL ==========
const viewModal = document.getElementById('viewModal');
viewModal.addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    const data = button.dataset;
    
    const coverHtml = data.cover ? `<img src="${data.cover}" style="max-width:120px; max-height:160px; object-fit:contain; border-radius:8px; border:1px solid #e9ecef; padding:4px;">` : 
        `<div style="width:120px;height:160px;background:#e9ecef;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#6c757d;"><i class="fas fa-book fa-4x"></i></div>`;
    
    const photoHtml = data.photo ? `<img src="${data.photo}" style="width:80px;height:80px;object-fit:cover;border-radius:50%;border:2px solid #1e3c72;">` :
        `<div style="width:80px;height:80px;background:linear-gradient(135deg,#e9ecef,#dee2e6);border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid #1e3c72;color:#6c757d;"><i class="fas fa-user fa-3x"></i></div>`;
    
    const statusBadge = `<span class="badge bg-${data.statusclass}">${data.status}</span>`;
    const priorityBadge = data.priority > 1 ? 
        `<span class="badge bg-danger"><i class="fas fa-exclamation-triangle"></i> High (${data.priority})</span>` :
        `<span class="badge bg-secondary">Normal (${data.priority})</span>`;
    
    document.getElementById('viewModalBody').innerHTML = `
        <div class="row g-3">
            <div class="col-md-6 text-center">
                <div class="mb-2"><strong>Book Cover</strong></div>
                ${coverHtml}
                <div class="mt-2">
                    <strong>${data.book}</strong><br>
                    <small class="text-muted">Barcode: ${data.barcode}</small>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <div class="mb-2"><strong>Member Photo</strong></div>
                ${photoHtml}
                <div class="mt-2">
                    <strong>${data.member}</strong><br>
                    <small class="text-muted">Adm No: ${data.admno}</small>
                </div>
            </div>
            <div class="col-12">
                <hr>
                <div class="row">
                    <div class="col-6"><strong>Priority:</strong> ${priorityBadge}</div>
                    <div class="col-6"><strong>Status:</strong> ${statusBadge}</div>
                    <div class="col-6"><strong>Requested Date:</strong> ${data.requested}</div>
                    <div class="col-6"><strong>Expiry Date:</strong> ${data.expiry}</div>
                    <div class="col-12"><strong>Created:</strong> ${data.created}</div>
                </div>
            </div>
        </div>
    `;
});

// ========== AUTO-DISMISS ALERTS ==========
setTimeout(function() {
    let alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        let bsAlert = new bootstrap.Alert(alert);
        setTimeout(() => bsAlert.close(), 5000);
    });
}, 3000);

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N for new reservation
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'add.php';
    }
});
</script>

<?php renderFooter(); ?>