<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Rate limiting
$rate_key = 'ajax_rate_' . $_SESSION['user_id'];
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
if ($_SESSION[$rate_key] > 20) {
    echo json_encode(['error' => 'Too many requests. Please wait.']);
    exit;
}
$_SESSION[$rate_key]++;

$db = getDB();
$action = $_GET['action'] ?? '';

// Helper function for image base64
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

if ($action == 'search_books') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) {
        echo json_encode([]);
        exit;
    }
    $stmt = $db->prepare("SELECT barcode, title, author, available, cover_path FROM books 
                          WHERE (barcode LIKE ? OR title LIKE ? OR isbn LIKE ? OR author LIKE ?) 
                          AND available > 0 LIMIT 15");
    $stmt->execute(["%$q%", "%$q%", "%$q%", "%$q%"]);
    $books = $stmt->fetchAll();
    
    // Add cover base64 for display
    foreach ($books as &$book) {
        if (!empty($book['cover_path'])) {
            $book['cover_base64'] = getImageBase64($book['cover_path']);
        }
    }
    echo json_encode($books);
    exit;
}

if ($action == 'search_members') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) {
        echo json_encode([]);
        exit;
    }
    $stmt = $db->prepare("SELECT admno, name, class, division, member_category, photo_path 
                          FROM members 
                          WHERE admno LIKE ? OR name LIKE ? 
                          LIMIT 15");
    $stmt->execute(["%$q%", "%$q%"]);
    $members = $stmt->fetchAll();
    
    // Add photo base64 for display
    foreach ($members as &$member) {
        if (!empty($member['photo_path'])) {
            $member['photo_base64'] = getImageBase64($member['photo_path']);
        }
    }
    echo json_encode($members);
    exit;
}

if ($action == 'check_hold_status') {
    $barcode = $_GET['barcode'] ?? '';
    $admno = $_GET['admno'] ?? '';
    
    if (empty($barcode) || empty($admno)) {
        echo json_encode(['error' => 'Missing parameters']);
        exit;
    }
    
    // Check for existing hold
    $stmt = $db->prepare("SELECT id, status FROM book_holds WHERE book_barcode = ? AND admno = ? AND status IN ('pending', 'available') LIMIT 1");
    $stmt->execute([$barcode, $admno]);
    $hold = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check for existing reservation
    $stmt2 = $db->prepare("SELECT id, status FROM reservations_queue WHERE book_barcode = ? AND admno = ? AND status IN ('waiting', 'notified') LIMIT 1");
    $stmt2->execute([$barcode, $admno]);
    $reservation = $stmt2->fetch(PDO::FETCH_ASSOC);
    
    // Get hold count for member
    $holdCountStmt = $db->prepare("SELECT COUNT(*) FROM book_holds WHERE admno = ? AND status IN ('pending', 'available')");
    $holdCountStmt->execute([$admno]);
    $holdCount = (int)$holdCountStmt->fetchColumn();
    
    echo json_encode([
        'has_hold' => $hold ? true : false,
        'hold_status' => $hold ? $hold['status'] : null,
        'hold_id' => $hold ? $hold['id'] : null,
        'has_reservation' => $reservation ? true : false,
        'reservation_status' => $reservation ? $reservation['status'] : null,
        'reservation_id' => $reservation ? $reservation['id'] : null,
        'total_holds' => $holdCount
    ]);
    exit;
}

if ($action == 'get_hold_queue') {
    $barcode = $_GET['barcode'] ?? '';
    if (empty($barcode)) {
        echo json_encode(['error' => 'Missing barcode']);
        exit;
    }
    
    // Get total pending holds
    $total = $db->prepare("SELECT COUNT(*) FROM book_holds WHERE book_barcode = ? AND status = 'pending'");
    $total->execute([$barcode]);
    $pendingCount = (int)$total->fetchColumn();
    
    // Get available copies
    $avail = $db->prepare("SELECT available FROM books WHERE barcode = ?");
    $avail->execute([$barcode]);
    $available = (int)$avail->fetchColumn();
    
    // Get hold details with positions
    $holdStmt = $db->prepare("SELECT id, admno, member_name, hold_date FROM book_holds 
                              WHERE book_barcode = ? AND status = 'pending' ORDER BY hold_date ASC LIMIT 10");
    $holdStmt->execute([$barcode]);
    $holds = $holdStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Add queue positions
    foreach ($holds as $index => &$hold) {
        $hold['position'] = $index + 1;
    }
    
    echo json_encode([
        'pending_count' => $pendingCount,
        'available_copies' => $available,
        'queue_length' => $pendingCount,
        'queue' => $holds
    ]);
    exit;
}

if ($action == 'get_hold_settings') {
    header('Content-Type: application/json');
    
    $stmt = $db->query("SELECT * FROM hold_settings WHERE id = 1");
    $settings = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$settings) {
        // Default settings
        $settings = [
            'max_holds_per_member' => 3,
            'hold_expiry_days' => 7,
            'hold_auto_cancel_days' => 3,
            'hold_notification_enabled' => 1,
            'hold_notification_days_before_expiry' => 2,
            'hold_max_queue_position' => 10,
            'hold_allow_self_cancel' => 1,
            'hold_pickup_reminder_days' => 2,
            'hold_send_auto_notifications' => 1
        ];
    }
    
    echo json_encode($settings);
    exit;
}

echo json_encode(['error' => 'Invalid action']);
?>