<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = (int)$_GET['id'];
$db = getDB();

// Get reservation details
$res = $db->prepare("SELECT * FROM reservations_queue WHERE id = ? AND status IN ('waiting','notified')");
$res->execute([$id]);
$r = $res->fetch();
if (!$r) {
    echo "<script>alert('Invalid or already processed reservation.'); window.location='index.php';</script>";
    exit;
}

// Update reservation status
$update = $db->prepare("UPDATE reservations_queue SET status = 'borrowed', processed_at = datetime('now') WHERE id = ?");
$update->execute([$id]);

// Optionally, you can also create a circulation record here
// (This part depends on your circulation module structure)

// Regenerate CSRF token
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

header("Location: index.php");
exit;
?>