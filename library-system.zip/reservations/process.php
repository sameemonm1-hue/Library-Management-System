<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = (int)$_GET['id'];
$db = getDB();

try {
    $db->beginTransaction();
    
    // Get reservation details
    $res = $db->prepare("SELECT * FROM reservations_queue WHERE id = ? AND status IN ('waiting','notified')");
    $res->execute([$id]);
    $r = $res->fetch();
    
    if (!$r) {
        throw new Exception("Invalid or already processed reservation.");
    }
    
    // Update reservation status
    $update = $db->prepare("UPDATE reservations_queue SET status = 'borrowed', processed_at = datetime('now') WHERE id = ?");
    $update->execute([$id]);
    
    // If linked to a hold, update hold status
    if (!empty($r['hold_id'])) {
        $holdStmt = $db->prepare("UPDATE book_holds SET status = 'picked_up', picked_up_at = datetime('now') WHERE id = ?");
        $holdStmt->execute([$r['hold_id']]);
        
        // Log activity
        logActivity($_SESSION['username'], 'HOLD_PICKED_UP', "Hold #{$r['hold_id']} picked up via reservation processing");
    }
    
    $db->commit();
    
    // Regenerate CSRF token
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    
    header("Location: index.php?msg=Book issued successfully" . (!empty($r['hold_id']) ? "&hold_id={$r['hold_id']}" : ""));
    
} catch (Exception $e) {
    $db->rollBack();
    header("Location: index.php?msg=Error: " . urlencode($e->getMessage()));
}
exit;
?>