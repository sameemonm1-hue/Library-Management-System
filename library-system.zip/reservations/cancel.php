<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = (int)$_GET['id'];
$db = getDB();

try {
    $db->beginTransaction();
    
    // Get reservation details
    $res = $db->prepare("SELECT * FROM reservations_queue WHERE id = ? AND status IN ('waiting','notified')");
    $res->execute([$id]);
    $r = $res->fetch();
    
    if (!$r) {
        throw new Exception("Reservation not found or cannot be cancelled.");
    }
    
    // Update reservation status
    $stmt = $db->prepare("UPDATE reservations_queue SET status = 'cancelled' WHERE id = ?");
    $stmt->execute([$id]);
    
    // If linked to a hold, cancel the hold too
    if (!empty($r['hold_id'])) {
        $holdStmt = $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ? AND status IN ('pending', 'available')");
        $holdStmt->execute([$r['hold_id']]);
        
        // Log activity
        logActivity($_SESSION['username'], 'HOLD_CANCELLED', "Hold #{$r['hold_id']} cancelled via reservation cancellation");
    }
    
    $db->commit();
    
    header("Location: index.php?msg=Request cancelled successfully");
    
} catch (Exception $e) {
    $db->rollBack();
    header("Location: index.php?msg=Error: " . urlencode($e->getMessage()));
}
exit;
?>