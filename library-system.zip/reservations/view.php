<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

$id = (int)$_GET['id'];
$db = getDB();

// Get reservation with hold information
$stmt = $db->prepare("SELECT rq.*, 
                              m.name as member_name, 
                              m.admno,
                              m.member_category,
                              m.email,
                              m.phone,
                              m.photo_path,
                              b.title as book_title, 
                              b.barcode as book_barcode,
                              b.author as book_author,
                              b.cover_path,
                              h.id as hold_id,
                              h.status as hold_status,
                              h.hold_date as hold_hold_date,
                              h.expiry_date as hold_expiry_date
                       FROM reservations_queue rq
                       LEFT JOIN members m ON rq.admno = m.admno
                       LEFT JOIN books b ON rq.book_barcode = b.barcode
                       LEFT JOIN book_holds h ON rq.hold_id = h.id
                       WHERE rq.id = ?");
$stmt->execute([$id]);
$r = $stmt->fetch();
if (!$r) die("Reservation not found.");

// Get image base64
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

$coverBase64 = getImageBase64($r['cover_path'] ?? '');
$photoBase64 = getImageBase64($r['photo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; font-family: 'Inter', sans-serif; }
        .card-custom { border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .detail-img { max-width: 150px; max-height: 200px; object-fit: contain; border-radius: 8px; border: 1px solid #e9ecef; padding: 4px; }
        .member-photo { width: 80px; height: 80px; object-fit: cover; border-radius: 50%; border: 2px solid #1e3c72; }
        .member-photo-placeholder { width: 80px; height: 80px; border-radius: 50%; background: #e9ecef; display: flex; align-items: center; justify-content: center; border: 2px solid #1e3c72; }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4><i class="fas fa-info-circle text-info"></i> Request Details</h4>
        <div>
            <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to List</a>
            <a href="../admin/holds.php" class="btn btn-purple btn-sm"><i class="fas fa-hand-paper"></i> Admin Holds</a>
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <div class="card card-custom">
        <div class="card-header bg-info text-white">
            <h5 class="mb-0"><i class="fas fa-bookmark"></i> Reservation #<?= $r['id'] ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center">
                    <div class="mb-2"><strong>Book Cover</strong></div>
                    <?php if ($coverBase64): ?>
                        <img src="<?= $coverBase64 ?>" class="detail-img">
                    <?php else: ?>
                        <div style="width:150px;height:200px;background:#e9ecef;border-radius:8px;display:flex;align-items:center;justify-content:center;margin:0 auto;border:1px solid #dee2e6;">
                            <i class="fas fa-book fa-4x text-muted"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-3 text-center">
                    <div class="mb-2"><strong>Member Photo</strong></div>
                    <?php if ($photoBase64): ?>
                        <img src="<?= $photoBase64 ?>" class="member-photo">
                    <?php else: ?>
                        <div class="member-photo-placeholder mx-auto">
                            <i class="fas fa-user fa-3x text-muted"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <table class="table table-bordered">
                        <tr><th style="width:40%;">ID</th><td>#<?= $r['id'] ?></td></tr>
                        <tr><th>Book</th><td><strong><?= htmlspecialchars($r['book_title'] ?? 'Unknown') ?></strong><br><small class="text-muted">Barcode: <?= $r['book_barcode'] ?></small></td></tr>
                        <tr><th>Author</th><td><?= htmlspecialchars($r['book_author'] ?? 'Unknown') ?></td></tr>
                        <tr><th>Member</th><td><strong><?= htmlspecialchars($r['member_name'] ?? 'Deleted') ?></strong><br><small class="text-muted">Adm No: <?= $r['admno'] ?></small></td></tr>
                        <tr><th>Priority</th><td><?= $r['priority'] ?></td></tr>
                        <tr><th>Requested Date</th><td><?= date('d-m-Y', strtotime($r['requested_date'])) ?></td></tr>
                        <tr><th>Expiry Date</th><td><?= date('d-m-Y', strtotime($r['expiry_date'])) ?></td></tr>
                        <tr><th>Status</th><td><span class="badge bg-<?= ($r['status']=='waiting'?'warning':($r['status']=='notified'?'info':($r['status']=='borrowed'?'success':'secondary'))) ?>"><?= ucfirst($r['status']) ?></span></td></tr>
                        <tr><th>Created At</th><td><?= $r['created_at'] ?></td></tr>
                        <?php if($r['notified_at']): ?><tr><th>Notified At</th><td><?= $r['notified_at'] ?></td></tr><?php endif; ?>
                        <?php if($r['processed_at']): ?><tr><th>Processed At</th><td><?= $r['processed_at'] ?></td></tr><?php endif; ?>
                    </table>
                </div>
            </div>
            
            <?php if ($r['hold_id']): ?>
            <div class="mt-3">
                <h6><i class="fas fa-link text-purple"></i> Linked Hold Information</h6>
                <table class="table table-bordered table-sm">
                    <tr><th style="width:30%;">Hold ID</th><td>#<?= $r['hold_id'] ?></td></tr>
                    <tr><th>Hold Status</th><td><span class="badge bg-<?= ($r['hold_status']=='pending'?'warning':($r['hold_status']=='available'?'success':($r['hold_status']=='picked_up'?'info':'secondary'))) ?>"><?= ucfirst($r['hold_status'] ?? 'Unknown') ?></span></td></tr>
                    <tr><th>Hold Date</th><td><?= $r['hold_hold_date'] ?? 'N/A' ?></td></tr>
                    <tr><th>Hold Expiry</th><td><?= $r['hold_expiry_date'] ?? 'N/A' ?></td></tr>
                </table>
                <a href="../admin/holds.php?search=<?= urlencode($r['book_barcode']) ?>" class="btn btn-sm btn-purple">
                    <i class="fas fa-hand-paper"></i> View in Hold Management
                </a>
            </div>
            <?php endif; ?>
            
            <div class="mt-3">
                <a href="index.php" class="btn btn-secondary">Back to List</a>
                <?php if ($r['status'] == 'waiting'): ?>
                    <a href="notify.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-info text-white">
                        <i class="fas fa-bell"></i> Mark Notified
                    </a>
                    <a href="process.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-success">
                        <i class="fas fa-check"></i> Mark Borrowed
                    </a>
                    <a href="cancel.php?id=<?= $r['id'] ?>&token=<?= urlencode($_SESSION['csrf_token']) ?>" class="btn btn-danger" onclick="return confirm('Cancel this reservation?')">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.btn-purple {
    background: linear-gradient(135deg, #6f42c1, #8b5cf6);
    color: #fff;
    border: none;
}
.btn-purple:hover {
    color: #fff;
}
.text-purple { color: #6f42c1; }
</style>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>