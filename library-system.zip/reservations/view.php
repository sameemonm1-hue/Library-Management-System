<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

$id = (int)$_GET['id'];
$db = getDB();
$stmt = $db->prepare("SELECT rq.*, m.name as member_name, m.admno, b.title as book_title, b.barcode as book_barcode 
                       FROM reservations_queue rq
                       LEFT JOIN members m ON rq.admno = m.admno
                       LEFT JOIN books b ON rq.book_barcode = b.barcode
                       WHERE rq.id = ?");
$stmt->execute([$id]);
$r = $stmt->fetch();
if (!$r) die("Reservation not found.");
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Reservation Details</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container mt-5">
    <div class="d-flex justify-content-end mb-3">
        <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Back to Home</a>
    </div>
    <div class="card shadow rounded-4">
        <div class="card-header bg-info text-white"><h4>Reservation Details</h4></div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr><th>ID</th><td><?= $r['id'] ?></div></tr>
                <tr><th>Book</th><td><?= htmlspecialchars($r['book_title']) ?> (<?= $r['book_barcode'] ?>)</div></tr>
                <tr><th>Member</th><td><?= htmlspecialchars($r['member_name']) ?> (<?= $r['admno'] ?>)</div></tr>
                <tr><th>Priority</th><td><?= $r['priority'] ?></div></tr>
                <tr><th>Requested Date</th><td><?= date('d-m-Y', strtotime($r['requested_date'])) ?></div></tr>
                <tr><th>Expiry Date</th><td><?= date('d-m-Y', strtotime($r['expiry_date'])) ?></div></tr>
                <tr><th>Status</th><td><span class="badge bg-<?= ($r['status']=='waiting'?'warning':($r['status']=='notified'?'info':($r['status']=='borrowed'?'success':'secondary'))) ?>"><?= ucfirst($r['status']) ?></span></div></tr>
                <tr><th>Created At</th><td><?= $r['created_at'] ?></div></tr>
                <?php if($r['notified_at']): ?><tr><th>Notified At</th><td><?= $r['notified_at'] ?></div></tr><?php endif; ?>
                <?php if($r['processed_at']): ?><tr><th>Processed At</th><td><?= $r['processed_at'] ?></div></tr><?php endif; ?>
            </table>
            <a href="index.php" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>
</body>
</html>