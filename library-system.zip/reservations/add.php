<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Session is already started in db.php
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$error = '';
$success = '';
$book_title = '';
$member_name = '';

// ==================== GET HOLD SETTINGS ====================
function getHoldSettings() {
    $db = getDB();
    try {
        // Check if hold_settings table exists
        $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='hold_settings'");
        if (!$tableCheck->fetch()) {
            // Create table if it doesn't exist
            $db->exec("CREATE TABLE IF NOT EXISTS hold_settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                max_holds_per_member INTEGER DEFAULT 3,
                hold_expiry_days INTEGER DEFAULT 7,
                hold_auto_cancel_days INTEGER DEFAULT 3,
                hold_notification_enabled INTEGER DEFAULT 1,
                hold_notification_days_before_expiry INTEGER DEFAULT 2,
                hold_max_queue_position INTEGER DEFAULT 10,
                hold_allow_self_cancel INTEGER DEFAULT 1,
                hold_pickup_reminder_days INTEGER DEFAULT 2,
                hold_send_auto_notifications INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            
            // Insert default settings
            $db->exec("INSERT OR IGNORE INTO hold_settings (id) VALUES (1)");
            $db->exec("UPDATE hold_settings SET 
                max_holds_per_member = 3,
                hold_expiry_days = 7,
                hold_auto_cancel_days = 3,
                hold_notification_enabled = 1,
                hold_notification_days_before_expiry = 2,
                hold_max_queue_position = 10,
                hold_allow_self_cancel = 1,
                hold_pickup_reminder_days = 2,
                hold_send_auto_notifications = 1
                WHERE id = 1");
        }
        
        $stmt = $db->query("SELECT * FROM hold_settings WHERE id = 1");
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$settings) {
            // Fallback defaults
            $settings = [
                'max_holds_per_member' => 3,
                'hold_expiry_days' => 7,
                'hold_auto_cancel_days' => 3,
                'hold_notification_enabled' => 1,
                'hold_notification_days_before_expiry' => 2,
                'hold_max_queue_position' => 10,
                'hold_allow_self_cancel' => 1,
                'hold_pickup_reminder_days' => 2,
                'hold_send_auto_notifications' => 1
            ];
        }
        return $settings;
    } catch (Exception $e) {
        // Return defaults on error
        error_log("getHoldSettings error: " . $e->getMessage());
        return [
            'max_holds_per_member' => 3,
            'hold_expiry_days' => 7,
            'hold_auto_cancel_days' => 3,
            'hold_notification_enabled' => 1,
            'hold_notification_days_before_expiry' => 2,
            'hold_max_queue_position' => 10,
            'hold_allow_self_cancel' => 1,
            'hold_pickup_reminder_days' => 2,
            'hold_send_auto_notifications' => 1
        ];
    }
}

// ==================== GET IMAGE BASE64 ====================
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ==================== GET HOLD SETTINGS ====================
$holdSettings = getHoldSettings();
$maxHoldsPerMember = (int)($holdSettings['max_holds_per_member'] ?? 3);
$holdExpiryDays = (int)($holdSettings['hold_expiry_days'] ?? 7);

// ==================== CHECK FOR EXISTING TABLES ====================
try {
    // Ensure book_holds table exists
    $db->exec("CREATE TABLE IF NOT EXISTS book_holds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_barcode TEXT NOT NULL,
        book_title TEXT DEFAULT '',
        book_author TEXT DEFAULT '',
        admno TEXT NOT NULL,
        member_name TEXT NOT NULL,
        member_category TEXT DEFAULT '',
        email TEXT DEFAULT '',
        phone TEXT DEFAULT '',
        hold_date DATE NOT NULL,
        expiry_date DATE NOT NULL,
        status TEXT DEFAULT 'pending',
        notified INTEGER DEFAULT 0,
        notified_at DATETIME,
        picked_up_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Ensure reservations_queue table exists with hold_id
    $db->exec("CREATE TABLE IF NOT EXISTS reservations_queue(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        book_barcode TEXT NOT NULL,
        admno TEXT NOT NULL,
        member_name TEXT NOT NULL,
        priority INTEGER DEFAULT 1,
        requested_date DATE NOT NULL,
        expiry_date DATE NOT NULL,
        status TEXT DEFAULT 'waiting',
        notified_at DATETIME,
        processed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        hold_id INTEGER DEFAULT NULL
    )");

    // Add hold_id column if missing
    $cols = $db->query("PRAGMA table_info(reservations_queue)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('hold_id', $cols)) {
        $db->exec("ALTER TABLE reservations_queue ADD COLUMN hold_id INTEGER DEFAULT NULL");
    }
} catch (Exception $e) {
    error_log("Table creation error: " . $e->getMessage());
}

// ==================== AJAX HANDLERS ====================
if (isset($_GET['ajax_member']) && isset($_GET['admno'])) {
    header('Content-Type: application/json');
    try {
        $admno = trim($_GET['admno']);
        $stmt = $db->prepare("SELECT admno, name, member_category, email, phone, photo_path FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($member && !empty($member['photo_path'])) {
            $member['photo_base64'] = getImageBase64($member['photo_path']);
        }
        echo json_encode($member ?: null);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

if (isset($_GET['ajax_book']) && isset($_GET['barcode'])) {
    header('Content-Type: application/json');
    try {
        $barcode = trim($_GET['barcode']);
        $stmt = $db->prepare("SELECT barcode, title, author, available, cover_path FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($book && !empty($book['cover_path'])) {
            $book['cover_base64'] = getImageBase64($book['cover_path']);
        }
        echo json_encode($book ?: null);
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// ==================== FORM SUBMISSION ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Invalid security token. Please refresh and try again.");
        }
        
        $book_barcode = trim($_POST['book_barcode']);
        $admno = trim($_POST['admno']);
        $priority = (int)($_POST['priority'] ?? 1);
        $requested_date = $_POST['requested_date'] ?? date('Y-m-d');
        $expiry_date = $_POST['expiry_date'] ?? date('Y-m-d', strtotime("+$holdExpiryDays days"));
        $create_hold = isset($_POST['create_hold']) && $_POST['create_hold'] == '1';

        if (empty($book_barcode) || empty($admno)) {
            throw new Exception("Book barcode and member admission number are required.");
        }

        if (strtotime($expiry_date) < strtotime($requested_date)) {
            throw new Exception("Expiry date cannot be earlier than the requested date.");
        }

        // Verify member
        $member = getMemberByAdmno($admno);
        if (!$member || $member['status'] !== 'active') {
            throw new Exception("Member not found or inactive.");
        }
        $member_name = $member['name'];

        // Verify book
        $book = getBookByBarcode($book_barcode);
        if (!$book) {
            throw new Exception("Book not found.");
        }
        $book_title = $book['title'];

        // Check for existing pending reservation
        $check = $db->prepare("SELECT id FROM reservations_queue WHERE book_barcode = ? AND admno = ? AND status IN ('waiting', 'notified')");
        $check->execute([$book_barcode, $admno]);
        if ($check->fetch()) {
            throw new Exception("This member already has a pending reservation for this book.");
        }

        // Check existing hold
        $holdCheck = $db->prepare("SELECT id FROM book_holds WHERE book_barcode = ? AND admno = ? AND status IN ('pending', 'available')");
        $holdCheck->execute([$book_barcode, $admno]);
        if ($holdCheck->fetch()) {
            throw new Exception("This member already has an active hold on this book.");
        }

        // Check max holds
        $holdCount = $db->prepare("SELECT COUNT(*) FROM book_holds WHERE admno = ? AND status IN ('pending', 'available')");
        $holdCount->execute([$admno]);
        if ($holdCount->fetchColumn() >= $maxHoldsPerMember) {
            throw new Exception("Member has reached the maximum holds limit ({$maxHoldsPerMember}).");
        }

        $db->beginTransaction();

        if ($create_hold) {
            // Create hold in book_holds table
            $holdStmt = $db->prepare("INSERT INTO book_holds 
                (book_barcode, book_title, book_author, admno, member_name, member_category, 
                 email, phone, hold_date, expiry_date, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $holdStmt->execute([
                $book_barcode,
                $book['title'],
                $book['author'] ?? '',
                $admno,
                $member['name'],
                $member['member_category'] ?? '',
                $member['email'] ?? '',
                $member['phone'] ?? '',
                date('Y-m-d'),
                $expiry_date
            ]);
            $holdId = $db->lastInsertId();

            // Create reservation record linked to hold
            $stmt = $db->prepare("INSERT INTO reservations_queue 
                (book_barcode, admno, member_name, priority, requested_date, expiry_date, 
                 status, hold_id, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'waiting', ?, datetime('now'))");
            $stmt->execute([$book_barcode, $admno, $member['name'], $priority, $requested_date, $expiry_date, $holdId]);

            logActivity($_SESSION['username'], 'HOLD_CREATE', "Created hold #$holdId and reservation for book $book_barcode, member $admno");
            $success = "Hold and reservation created successfully. Member will be notified when the book becomes available.";
        } else {
            // Just create reservation
            $stmt = $db->prepare("INSERT INTO reservations_queue 
                (book_barcode, admno, member_name, priority, requested_date, expiry_date, 
                 status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'waiting', datetime('now'))");
            $stmt->execute([$book_barcode, $admno, $member['name'], $priority, $requested_date, $expiry_date]);

            logActivity($_SESSION['username'], 'RESERVATION_ADD', "Reserved book $book_barcode for member $admno");
            $success = "Reservation added successfully.";
        }

        $db->commit();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    } catch (Exception $e) {
        if (isset($db) && $db->inTransaction()) {
            $db->rollBack();
        }
        $error = $e->getMessage();
        error_log("Reservation error: " . $e->getMessage());
    }
}

// ==================== RENDER PAGE ====================
renderHeader('New Reservation');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Reservation - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; font-family: 'Inter', sans-serif; }
        .card-custom { border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .card-header { background: <?= $reportPrimaryColor ?> !important; }
        .book-info-preview, .member-info-preview {
            padding: 12px;
            border-radius: 8px;
            background: #f8f9fa;
            margin-top: 8px;
            display: none;
        }
        .book-info-preview.show, .member-info-preview.show {
            display: block;
        }
        .preview-photo {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
        }
        .btn-purple {
            background: linear-gradient(135deg, #6f42c1, #8b5cf6);
            color: #fff;
            border: none;
        }
        .btn-purple:hover {
            color: #fff;
        }
        .hold-info-box {
            background: #f0e6ff;
            border: 1px solid #6f42c1;
            border-radius: 8px;
            padding: 10px;
            margin-top: 8px;
        }
        .hold-info-box i {
            color: #6f42c1;
        }
        .alert-danger {
            border-radius: 10px;
        }
        .alert-success {
            border-radius: 10px;
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4><i class="fas fa-plus-circle text-primary"></i> New Request</h4>
        <div>
            <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
            <a href="../admin/holds.php" class="btn btn-purple btn-sm"><i class="fas fa-hand-paper"></i> Admin Holds</a>
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <div class="card card-custom">
        <div class="card-header text-white">
            <h5 class="mb-0"><i class="fas fa-bookmark"></i> Reservation Details</h5>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    <br><a href="index.php" class="alert-link">View All Requests</a>
                </div>
            <?php endif; ?>

            <form method="post" autocomplete="off" id="reservationForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Book Barcode <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" name="book_barcode" id="bookBarcode" class="form-control" required 
                                   placeholder="Scan or enter barcode" autofocus>
                            <button type="button" class="btn btn-outline-secondary" onclick="fetchBook()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div id="bookInfo" class="book-info-preview"></div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Member Admission Number <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" name="admno" id="admno" class="form-control" required 
                                   placeholder="Enter admno">
                            <button type="button" class="btn btn-outline-secondary" onclick="fetchMember()">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                        <div id="memberInfo" class="member-info-preview"></div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Priority</label>
                        <input type="number" name="priority" class="form-control" value="1" min="1" max="5">
                        <small class="text-muted">Higher = more urgent</small>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Requested Date</label>
                        <input type="date" name="requested_date" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" value="<?= date('Y-m-d', strtotime("+$holdExpiryDays days")) ?>">
                        <small class="text-muted">Holds expire after <?= $holdExpiryDays ?> days</small>
                    </div>
                    <div class="col-md-3">
                        <div class="form-check mt-4">
                            <input type="checkbox" name="create_hold" id="createHold" value="1" class="form-check-input" checked>
                            <label class="form-check-label fw-semibold" for="createHold">
                                <i class="fas fa-hand-paper text-purple"></i> Create Hold
                            </label>
                            <br><small class="text-muted">Creates a hold in the main hold queue</small>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="hold-info-box">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Hold Information:</strong> 
                            Max holds per member: <strong><?= $maxHoldsPerMember ?></strong> | 
                            Hold expiry: <strong><?= $holdExpiryDays ?> days</strong>
                            <?php if ($book_title): ?>
                                <br><i class="fas fa-book"></i> Book: <strong><?= htmlspecialchars($book_title) ?></strong>
                            <?php endif; ?>
                            <?php if ($member_name): ?>
                                <br><i class="fas fa-user"></i> Member: <strong><?= htmlspecialchars($member_name) ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 mt-3">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Request</button>
                        <a href="index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <div class="mt-3 text-center text-muted small">
        <i class="fas fa-info-circle"></i> 
        Maximum holds per member: <strong><?= $maxHoldsPerMember ?></strong> | 
        Hold expiry: <strong><?= $holdExpiryDays ?> days</strong>
        <span class="mx-2">|</span>
        <i class="fas fa-link"></i> Linked to admin holds management
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function fetchBook() {
    let barcode = document.getElementById('bookBarcode').value.trim();
    let infoDiv = document.getElementById('bookInfo');
    if (barcode.length < 3) { 
        infoDiv.innerHTML = ''; 
        infoDiv.classList.remove('show'); 
        return; 
    }
    
    infoDiv.innerHTML = '<div class="text-muted"><i class="fas fa-spinner fa-spin"></i> Searching...</div>';
    infoDiv.classList.add('show');
    
    fetch('add.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            if (data && data.title) {
                let availText = data.available > 0 ? 
                    `<span class="text-success">Available (${data.available} copies)</span>` : 
                    `<span class="text-danger">Not available</span>`;
                let coverHtml = data.cover_base64 ? 
                    `<img src="${data.cover_base64}" style="max-height:60px; max-width:60px; border-radius:4px; margin-right:10px; float:left;">` : '';
                infoDiv.innerHTML = `
                    <div class="alert alert-info mb-0 py-2">
                        ${coverHtml}
                        <strong>📖 ${escapeHtml(data.title)}</strong><br>
                        <small>Author: ${escapeHtml(data.author || 'Unknown')}</small><br>
                        <small>${availText}</small>
                    </div>
                `;
            } else if (data && data.error) {
                infoDiv.innerHTML = `<div class="alert alert-danger py-1 mb-0">⚠ ${escapeHtml(data.error)}</div>`;
            } else {
                infoDiv.innerHTML = `<div class="alert alert-warning py-1 mb-0">⚠ Book not found. It will be added as a new book.</div>`;
            }
        })
        .catch(() => {
            infoDiv.innerHTML = `<div class="alert alert-danger py-1 mb-0">Error fetching book details</div>`;
        });
}

function fetchMember() {
    let admno = document.getElementById('admno').value.trim();
    let infoDiv = document.getElementById('memberInfo');
    if (admno.length < 3) { 
        infoDiv.innerHTML = ''; 
        infoDiv.classList.remove('show'); 
        return; 
    }
    
    infoDiv.innerHTML = '<div class="text-muted"><i class="fas fa-spinner fa-spin"></i> Searching...</div>';
    infoDiv.classList.add('show');
    
    fetch('add.php?ajax_member=1&admno=' + encodeURIComponent(admno))
        .then(r => r.json())
        .then(data => {
            if (data && data.name) {
                let photoHtml = data.photo_base64 ? 
                    `<img src="${data.photo_base64}" style="width:40px;height:40px;object-fit:cover;border-radius:50%;margin-right:10px;float:left;">` : '';
                infoDiv.innerHTML = `
                    <div class="alert alert-success mb-0 py-2">
                        ${photoHtml}
                        <strong>👤 ${escapeHtml(data.name)}</strong><br>
                        <small>Category: ${escapeHtml(data.member_category || 'N/A')}</small><br>
                        <small>📧 ${escapeHtml(data.email || 'No email')}</small>
                    </div>
                `;
            } else if (data && data.error) {
                infoDiv.innerHTML = `<div class="alert alert-danger py-1 mb-0">⚠ ${escapeHtml(data.error)}</div>`;
            } else {
                infoDiv.innerHTML = `<div class="alert alert-danger py-1 mb-0">❌ Member not found or inactive</div>`;
            }
        })
        .catch(() => {
            infoDiv.innerHTML = `<div class="alert alert-danger py-1 mb-0">Error fetching member details</div>`;
        });
}

function escapeHtml(s) {
    if (!s) return '';
    return s.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

// Auto-fetch on blur
document.getElementById('bookBarcode').addEventListener('blur', fetchBook);
document.getElementById('admno').addEventListener('blur', fetchMember);

// Enter key triggers search
document.getElementById('bookBarcode').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); fetchBook(); }
});
document.getElementById('admno').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); fetchMember(); }
});

// Auto-focus book barcode on load
window.addEventListener('load', function() {
    document.getElementById('bookBarcode').focus();
});

// Toggle hold info based on checkbox
document.getElementById('createHold').addEventListener('change', function() {
    let holdInfo = document.querySelector('.hold-info-box');
    if (this.checked) {
        holdInfo.style.display = 'block';
    } else {
        holdInfo.style.display = 'none';
    }
});

// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});
</script>

</body>
</html>
<?php renderFooter(); ?>