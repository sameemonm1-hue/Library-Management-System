<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Session is already started in db.php
if (!isset($_SESSION['username'])) {
    header("Location: ../index.php");
    exit;
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF protection
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh and try again.";
    } else {
        $book_barcode = trim($_POST['book_barcode']);
        $admno = trim($_POST['admno']);
        $priority = (int)($_POST['priority'] ?? 1);
        $requested_date = $_POST['requested_date'] ?? date('Y-m-d');
        $expiry_date = $_POST['expiry_date'] ?? date('Y-m-d', strtotime('+7 days'));

        // Validate dates
        if (strtotime($expiry_date) < strtotime($requested_date)) {
            $error = "Expiry date cannot be earlier than the requested date.";
        } else {
            // Verify member
            $member = getMemberByAdmno($admno);
            if (!$member || $member['status'] !== 'active') {
                $error = "Member not found or inactive.";
            } else {
                // Verify book
                $book = getBookByBarcode($book_barcode);
                if (!$book) {
                    $error = "Book not found.";
                } else {
                    // Check for existing pending reservation for this book and member
                    $check = $db->prepare("SELECT id FROM reservations_queue 
                                           WHERE book_barcode = ? AND admno = ? AND status = 'waiting'");
                    $check->execute([$book_barcode, $admno]);
                    if ($check->fetch()) {
                        $error = "This member already has a pending reservation for this book.";
                    } else {
                        // Insert reservation
                        $stmt = $db->prepare("INSERT INTO reservations_queue 
                            (book_barcode, admno, member_name, priority, requested_date, expiry_date, status, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, 'waiting', datetime('now'))");
                        if ($stmt->execute([$book_barcode, $admno, $member['name'], $priority, $requested_date, $expiry_date])) {
                            $success = "Reservation added successfully.";
                            logActivity($_SESSION['username'], 'RESERVATION_ADD', "Reserved book $book_barcode for member $admno");
                            // Regenerate CSRF token after successful action
                            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                        } else {
                            $error = "Database error. Please try again.";
                        }
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Reservation - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; font-family: 'Inter', sans-serif; }
        .card-custom { border-radius: 20px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4><i class="fas fa-plus-circle text-primary"></i> New Book Reservation</h4>
        <div>
            <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Back to List</a>
            <a href="../index.php" class="btn btn-primary btn-sm btn-home"><i class="fas fa-home"></i> Home</a>
        </div>
    </div>

    <div class="card card-custom">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-bookmark"></i> Reservation Details</h5>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <?= htmlspecialchars($success) ?> <a href="index.php" class="alert-link">View All Reservations</a>
                </div>
            <?php endif; ?>

            <form method="post" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Book Barcode <span class="text-danger">*</span></label>
                        <input type="text" name="book_barcode" class="form-control" required 
                               placeholder="Scan or enter barcode" autofocus>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Member Admission Number <span class="text-danger">*</span></label>
                        <input type="text" name="admno" class="form-control" required 
                               placeholder="Enter admno">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Priority (higher = more urgent)</label>
                        <input type="number" name="priority" class="form-control" value="1" min="1">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Requested Date</label>
                        <input type="date" name="requested_date" class="form-control" value="<?= date('Y-m-d') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>">
                    </div>
                    <div class="col-12 mt-3">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Reservation</button>
                        <a href="index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>