<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['username'])) header("Location: ../index.php");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = (int)$_GET['id'];
$db = getDB();

try {
    $db->beginTransaction();
    
    // Get reservation details including hold_id
    $res = $db->prepare("SELECT * FROM reservations_queue WHERE id = ? AND status = 'waiting'");
    $res->execute([$id]);
    $r = $res->fetch();
    
    if (!$r) {
        throw new Exception("Reservation not found or already processed.");
    }
    
    // Update reservation status
    $stmt = $db->prepare("UPDATE reservations_queue SET status = 'notified', notified_at = datetime('now') WHERE id = ?");
    $stmt->execute([$id]);
    
    // If linked to a hold, update hold status to 'available'
    if (!empty($r['hold_id'])) {
        $holdStmt = $db->prepare("UPDATE book_holds SET status = 'available', expiry_date = date('now', '+7 days') WHERE id = ?");
        $holdStmt->execute([$r['hold_id']]);
        
        // Log activity
        logActivity($_SESSION['username'], 'HOLD_NOTIFIED', "Hold #{$r['hold_id']} marked available via reservation notification");
    }
    
    $db->commit();
    
    // Redirect with success message
    header("Location: index.php?msg=Member notified successfully" . (!empty($r['hold_id']) ? "&hold_id={$r['hold_id']}" : ""));
    
} catch (Exception $e) {
    $db->rollBack();
    header("Location: index.php?msg=Error: " . urlencode($e->getMessage()));
}
exit;
?>