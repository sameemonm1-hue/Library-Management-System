<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Rate limiting
$rate_key = 'ajax_rate_' . $_SESSION['user_id'];
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
if ($_SESSION[$rate_key] > 20) {
    echo json_encode(['error' => 'Too many requests. Please wait.']);
    exit;
}
$_SESSION[$rate_key]++;

$db = getDB();
$action = $_GET['action'] ?? '';

if ($action == 'get_member') {
    $admno = trim($_GET['admno'] ?? '');
    if (!$admno) {
        echo json_encode(['error' => 'No admno provided']);
        exit;
    }
    $stmt = $db->prepare("SELECT admno, name, total_fines, total_paid_fines FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    if (!$member) {
        echo json_encode(['error' => 'Member not found']);
        exit;
    }
    echo json_encode($member);
    exit;
}

echo json_encode(['error' => 'Invalid action']);
?>