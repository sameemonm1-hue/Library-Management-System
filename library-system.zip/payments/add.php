<?php
require_once __DIR__ . '/../config/functions.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyCode = $settings['currency_code'] ?? 'USD';

$error = '';
$success = '';
$payment_id = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh and try again.";
    } else {
        $member_admno = trim($_POST['member_admno'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $payment_type = $_POST['payment_type'] ?? '';
        $payment_method = $_POST['payment_method'] ?? 'cash';
        $reference_id = trim($_POST['reference_id'] ?? '');
        $related_circulation_id = !empty($_POST['circulation_id']) ? intval($_POST['circulation_id']) : null;
        $notes = trim($_POST['notes'] ?? '');
        $currency = $_POST['currency'] ?? $currencyCode;
        
        if (!$member_admno || $amount <= 0 || !$payment_type) {
            $error = "Please fill all required fields.";
        } else {
            try {
                $receipt_no = 'RCPT-' . date('YmdHis') . '-' . rand(100, 999);
                $created_by = $_SESSION['username'];
                
                $stmt = $db->prepare("INSERT INTO payment_transactions 
                    (member_admno, amount, payment_type, reference_id, related_circulation_id, 
                     payment_date, payment_method, receipt_no, notes, created_by, currency)
                    VALUES (?, ?, ?, ?, ?, datetime('now'), ?, ?, ?, ?, ?)");
                $stmt->execute([$member_admno, $amount, $payment_type, $reference_id, $related_circulation_id,
                               $payment_method, $receipt_no, $notes, $created_by, $currency]);
                
                $payment_id = $db->lastInsertId();
                
                if ($payment_type == 'fine') {
                    $db->prepare("UPDATE members SET total_paid_fines = total_paid_fines + ? WHERE admno = ?")
                       ->execute([$amount, $member_admno]);
                }
                
                logActivity($_SESSION['username'], 'PAYMENT_ADD', "Added payment {$receipt_no} for {$member_admno}");
                $success = "Payment recorded successfully. Receipt No: {$receipt_no}";
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

$logoUrl = '';
if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
    $logoUrl = getWebImageUrl($institution['logo_path']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Payment - Library ERP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; display: flex; flex-direction: column; min-height: 100vh; }
        .main-content { flex: 1; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; flex-shrink: 0; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
<div class="main-content">
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-plus-circle"></i> New Payment</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($success) ?> 
                <a href="receipt.php?id=<?= $payment_id ?>" class="alert-link">Print Receipt</a>
            </div>
        <?php endif; ?>
        
        <div class="form-card">
            <form method="POST" id="paymentForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Member Admno *</label>
                        <div class="input-group">
                            <input type="text" name="member_admno" id="member_admno" class="form-control" required autocomplete="off">
                            <button type="button" class="btn btn-outline-secondary" id="fetchMemberBtn"><i class="fas fa-search"></i> Fetch</button>
                        </div>
                        <div id="memberInfo" class="mt-2 small text-muted"></div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Outstanding Fines</label>
                        <input type="text" id="outstanding_fines" class="form-control" readonly>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Currency *</label>
                        <select name="currency" class="form-select" required>
                            <optgroup label="Major International">
                                <option value="USD" <?= $currencyCode == 'USD' ? 'selected' : '' ?>>USD ($)</option>
                                <option value="EUR" <?= $currencyCode == 'EUR' ? 'selected' : '' ?>>EUR (€)</option>
                                <option value="GBP" <?= $currencyCode == 'GBP' ? 'selected' : '' ?>>GBP (£)</option>
                                <option value="CAD" <?= $currencyCode == 'CAD' ? 'selected' : '' ?>>CAD ($)</option>
                                <option value="AUD" <?= $currencyCode == 'AUD' ? 'selected' : '' ?>>AUD ($)</option>
                                <option value="JPY" <?= $currencyCode == 'JPY' ? 'selected' : '' ?>>JPY (¥)</option>
                                <option value="CNY" <?= $currencyCode == 'CNY' ? 'selected' : '' ?>>CNY (¥)</option>
                            </optgroup>
                            <optgroup label="GCC & South Asia">
                                <option value="INR" <?= $currencyCode == 'INR' ? 'selected' : '' ?>>INR (₹)</option>
                                <option value="AED" <?= $currencyCode == 'AED' ? 'selected' : '' ?>>AED (د.إ)</option>
                                <option value="SAR" <?= $currencyCode == 'SAR' ? 'selected' : '' ?>>SAR (﷼)</option>
                                <option value="QAR" <?= $currencyCode == 'QAR' ? 'selected' : '' ?>>QAR (﷼)</option>
                                <option value="KWD" <?= $currencyCode == 'KWD' ? 'selected' : '' ?>>KWD (د.ك)</option>
                                <option value="BHD" <?= $currencyCode == 'BHD' ? 'selected' : '' ?>>BHD (د.ب)</option>
                                <option value="OMR" <?= $currencyCode == 'OMR' ? 'selected' : '' ?>>OMR (ر.ع)</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Payment Type *</label>
                        <select name="payment_type" id="payment_type" class="form-select" required>
                            <option value="">Select</option>
                            <option value="fine">Fine Payment</option>
                            <option value="deposit">Security Deposit</option>
                            <option value="lost_fee">Lost/Damaged Fee</option>
                            <option value="donation">Donation</option>
                            <option value="membership_fee">Membership Fee</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Amount *</label>
                        <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Payment Method</label>
                        <select name="payment_method" class="form-select">
                            <option value="cash">Cash</option>
                            <option value="card">Card</option>
                            <option value="online">Online Transfer</option>
                            <option value="cheque">Cheque</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Reference ID (Cheque/Trans ID)</label>
                        <input type="text" name="reference_id" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Related Circulation ID (if paying fine for a specific issue)</label>
                        <input type="number" name="circulation_id" class="form-control">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" rows="2" class="form-control"></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Record Payment</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container">
    <div class="footer">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $('#fetchMemberBtn').click(function() {
        var admno = $('#member_admno').val().trim();
        if (!admno) { alert('Enter Admno'); return; }
        $.getJSON('ajax.php', { action: 'get_member', admno: admno }, function(data) {
            if (data.error) {
                $('#memberInfo').html('<span class="text-danger">'+data.error+'</span>');
                $('#outstanding_fines').val('');
            } else {
                var currencySymbol = '<?= $currencySymbol ?>';
                $('#memberInfo').html('<strong>'+data.name+'</strong> ('+data.admno+')<br>Total Fines: '+currencySymbol+data.total_fines+' | Paid: '+currencySymbol+data.total_paid_fines);
                var outstanding = (data.total_fines - data.total_paid_fines).toFixed(2);
                $('#outstanding_fines').val(currencySymbol + ' ' + outstanding);
                $('#payment_type').off('change').on('change', function() {
                    if ($(this).val() == 'fine') $('#amount').val(outstanding);
                });
            }
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>