<?php
require_once __DIR__ . '/../config/functions.php';
$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid receipt.");

$db = getDB();
$stmt = $db->prepare("SELECT pt.*, m.name as member_name, m.admno FROM payment_transactions pt LEFT JOIN members m ON pt.member_admno = m.admno WHERE pt.id = ?");
$stmt->execute([$id]);
$payment = $stmt->fetch();
if (!$payment) die("Payment not found.");

$institution = getInstitution();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
if (!empty($payment['currency'])) {
    $currencySymbol = getCurrencySymbol($payment['currency']);
} else {
    $currencySymbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');
}

function getCurrencySymbol($code) {
    $symbols = [
        'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'CAD' => '$', 'AUD' => '$', 'JPY' => '¥', 'CNY' => '¥',
        'INR' => '₹', 'AED' => 'د.إ', 'SAR' => '﷼',
        'QAR' => '﷼', 'KWD' => 'د.ك', 'BHD' => 'د.ب', 'OMR' => 'ر.ع'
    ];
    return $symbols[$code] ?? '$';
}

// Function to generate one receipt HTML
function getReceiptHTML($payment, $institution, $currencySymbol, $copyLabel = '') {
    $copyHtml = $copyLabel ? "<div style='text-align:right; font-size:12px; margin-bottom:5px;'><strong>$copyLabel</strong></div>" : '';
    return '
    <div class="receipt">
        ' . $copyHtml . '
        <div class="header">
            <h3>' . htmlspecialchars($institution['name'] ?? 'Library') . '</h3>
            <p>' . htmlspecialchars($institution['address'] ?? '') . '<br>' . ($institution['contact'] ?? '') . '</p>
            <div class="receipt-title">PAYMENT RECEIPT</div>
        </div>
        <div class="receipt-details">
            <div class="row"><span>Receipt No:</span><span>' . htmlspecialchars($payment['receipt_no']) . '</span></div>
            <div class="row"><span>Date:</span><span>' . date('d-m-Y H:i:s', strtotime($payment['payment_date'])) . '</span></div>
            <div class="row"><span>Member:</span><span>' . htmlspecialchars($payment['member_name']) . ' (' . $payment['member_admno'] . ')</span></div>
            <div class="row"><span>Payment Type:</span><span>' . ucfirst(str_replace('_',' ',$payment['payment_type'])) . '</span></div>
            <div class="row"><span>Method:</span><span>' . ucfirst($payment['payment_method']) . '</span></div>
            ' . ($payment['reference_id'] ? '<div class="row"><span>Reference:</span><span>' . htmlspecialchars($payment['reference_id']) . '</span></div>' : '') . '
            <div class="row total"><span>Amount Paid:</span><span>' . $currencySymbol . ' ' . number_format($payment['amount'],2) . '</span></div>
            ' . ($payment['notes'] ? '<div class="row"><span>Notes:</span><span>' . nl2br(htmlspecialchars($payment['notes'])) . '</span></div>' : '') . '
        </div>
        <div class="footer">
            <p>Thank you for your payment!</p>
            <p>Authorized Signature</p>
        </div>
    </div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt (Duplicate)</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Courier New', monospace;
            background: white;
            margin: 0;
            padding: 15px;
        }
        /* Two receipts in a column (A4 portrait) – 1 inch gap between them */
        .receipts-container {
            display: flex;
            flex-direction: column;
            gap: 1in;  /* 1 inch gap */
            max-width: 400px;
            margin: 0 auto;
        }
        .receipt {
            border: 1px dashed #333;
            padding: 20px;
            border-radius: 8px;
            background: white;
            page-break-inside: avoid;
            break-inside: avoid;
        }
        .separator {
            display: none; /* Hide the dashed line because the gap is now 1 inch */
        }
        .header { text-align: center; margin-bottom: 20px; }
        .receipt-title { font-size: 20px; font-weight: bold; margin-top: 5px; }
        .receipt-details { margin: 15px 0; }
        .row { display: flex; justify-content: space-between; margin: 5px 0; }
        .total { font-size: 18px; font-weight: bold; border-top: 1px solid #000; padding-top: 10px; margin-top: 10px; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; }
        .btn-container {
            text-align: center;
            margin-top: 20px;
        }
        .btn { padding: 8px 16px; margin: 0 5px; cursor: pointer; border: none; border-radius: 4px; font-size: 14px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        @media print {
            body { margin: 0; padding: 0; }
            .btn-container, .no-print { display: none; }
            .receipts-container { gap: 1in; } /* Ensure 1 inch gap in print */
            .receipt { border: 1px solid #ccc; page-break-inside: avoid; break-inside: avoid; margin-bottom: 0; }
            /* Ensure each receipt fits within half of A4 (approx 140mm) */
            .receipt { max-height: 140mm; overflow: hidden; }
        }
    </style>
</head>
<body>
<div class="receipts-container">
    <!-- First copy: Original -->
    <?= getReceiptHTML($payment, $institution, $currencySymbol, 'ORIGINAL') ?>
    <!-- Second copy: Duplicate (separated by 1 inch gap) -->
    <?= getReceiptHTML($payment, $institution, $currencySymbol, 'DUPLICATE') ?>
</div>
<div class="btn-container no-print">
    <button class="btn btn-primary" onclick="window.print()">Print / Save PDF</button>
    <button class="btn btn-secondary" onclick="window.location.href='index.php'">Back to Transactions</button>
    <a href="../index.php" class="btn btn-secondary">Back to Home</a>
</div>
<script>
    // Auto‑print is disabled; user clicks the button.
</script>
</body>
</html>