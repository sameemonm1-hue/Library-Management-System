<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') header("Location: ../index.php");

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid payment ID.");

$stmt = $db->prepare("SELECT * FROM payment_transactions WHERE id = ?");
$stmt->execute([$id]);
$payment = $stmt->fetch();
if (!$payment) die("Payment not found.");

$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token";
    } else {
        $amount = floatval($_POST['amount']);
        $payment_method = $_POST['payment_method'];
        $reference_id = trim($_POST['reference_id']);
        $notes = trim($_POST['notes']);
        $currency = $_POST['currency'] ?? $payment['currency'] ?? 'INR';
        
        if ($amount <= 0) $error = "Amount must be > 0";
        else {
            $stmt = $db->prepare("UPDATE payment_transactions SET amount=?, payment_method=?, reference_id=?, notes=?, currency=? WHERE id=?");
            $stmt->execute([$amount, $payment_method, $reference_id, $notes, $currency, $id]);
            logActivity($_SESSION['username'], 'PAYMENT_EDIT', "Edited payment ID {$id}");
            $success = "Payment updated.";
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            // Refresh data
            $stmt = $db->prepare("SELECT * FROM payment_transactions WHERE id = ?");
            $stmt->execute([$id]);
            $payment = $stmt->fetch();
        }
    }
}

$logoUrl = '';
if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
    $logoUrl = getWebImageUrl($institution['logo_path']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; display: flex; flex-direction: column; min-height: 100vh; }
        .main-content { flex: 1; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; flex-shrink: 0; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
<div class="main-content">
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Edit Payment</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
        <div class="form-card">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-3"><label>Receipt No</label><input class="form-control" value="<?= htmlspecialchars($payment['receipt_no']) ?>" readonly></div>
                <div class="mb-3"><label>Member</label><input class="form-control" value="<?= htmlspecialchars($payment['member_admno']) ?>" readonly></div>
                <div class="mb-3"><label>Payment Type</label><input class="form-control" value="<?= ucfirst($payment['payment_type']) ?>" readonly></div>
                <div class="mb-3"><label>Currency</label>
                    <select name="currency" class="form-select">
                        <optgroup label="Major International">
                            <option value="USD" <?= ($payment['currency']??'')=='USD'?'selected':'' ?>>USD ($)</option>
                            <option value="EUR" <?= ($payment['currency']??'')=='EUR'?'selected':'' ?>>EUR (€)</option>
                            <option value="GBP" <?= ($payment['currency']??'')=='GBP'?'selected':'' ?>>GBP (£)</option>
                            <option value="CAD" <?= ($payment['currency']??'')=='CAD'?'selected':'' ?>>CAD ($)</option>
                            <option value="AUD" <?= ($payment['currency']??'')=='AUD'?'selected':'' ?>>AUD ($)</option>
                            <option value="JPY" <?= ($payment['currency']??'')=='JPY'?'selected':'' ?>>JPY (¥)</option>
                            <option value="CNY" <?= ($payment['currency']??'')=='CNY'?'selected':'' ?>>CNY (¥)</option>
                        </optgroup>
                        <optgroup label="GCC & South Asia">
                            <option value="INR" <?= ($payment['currency']??'')=='INR'?'selected':'' ?>>INR (₹)</option>
                            <option value="AED" <?= ($payment['currency']??'')=='AED'?'selected':'' ?>>AED (د.إ)</option>
                            <option value="SAR" <?= ($payment['currency']??'')=='SAR'?'selected':'' ?>>SAR (﷼)</option>
                            <option value="QAR" <?= ($payment['currency']??'')=='QAR'?'selected':'' ?>>QAR (﷼)</option>
                            <option value="KWD" <?= ($payment['currency']??'')=='KWD'?'selected':'' ?>>KWD (د.ك)</option>
                            <option value="BHD" <?= ($payment['currency']??'')=='BHD'?'selected':'' ?>>BHD (د.ب)</option>
                            <option value="OMR" <?= ($payment['currency']??'')=='OMR'?'selected':'' ?>>OMR (ر.ع)</option>
                        </optgroup>
                    </select>
                </div>
                <div class="mb-3"><label>Amount</label><input type="number" step="0.01" name="amount" class="form-control" value="<?= $payment['amount'] ?>" required></div>
                <div class="mb-3"><label>Payment Method</label>
                    <select name="payment_method" class="form-select">
                        <?php foreach (['cash','card','online','cheque'] as $m): ?>
                            <option value="<?= $m ?>" <?= $payment['payment_method']==$m?'selected':'' ?>><?= ucfirst($m) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3"><label>Reference ID</label><input type="text" name="reference_id" class="form-control" value="<?= htmlspecialchars($payment['reference_id']) ?>"></div>
                <div class="mb-3"><label>Notes</label><textarea name="notes" class="form-control"><?= htmlspecialchars($payment['notes']) ?></textarea></div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>

<div class="container">
    <div class="footer">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>