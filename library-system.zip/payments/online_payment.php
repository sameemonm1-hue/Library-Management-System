<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireLogin();

$db = getDB();
$settings = getSettings();
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencySymbol = getCurrencySymbol($currencyCode);

// Get member details
$member = null;
$outstandingFine = 0;
$memberAdmno = $_GET['member'] ?? $_SESSION['member_admno'] ?? '';

if ($memberAdmno) {
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$memberAdmno]);
    $member = $stmt->fetch();
    if ($member) {
        $outstandingFine = getMemberOutstandingFines($memberAdmno);
    }
}

// Razorpay configuration (get from settings)
$razorpayKey = $settings['razorpay_key_id'] ?? '';
$razorpaySecret = $settings['razorpay_key_secret'] ?? '';

// Process payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['razorpay_payment_id'])) {
    $paymentId = $_POST['razorpay_payment_id'];
    $orderId = $_POST['razorpay_order_id'];
    $signature = $_POST['razorpay_signature'];
    $amount = (float)$_POST['amount'];
    $memberAdmno = $_POST['member_admno'];
    $paymentType = $_POST['payment_type'];
    
    // Verify signature
    $generatedSignature = hash_hmac('sha256', $orderId . '|' . $paymentId, $razorpaySecret);
    
    if ($generatedSignature === $signature) {
        // Payment successful
        $receiptNo = 'ONLINE-' . date('YmdHis') . '-' . rand(100, 999);
        
        $stmt = $db->prepare("INSERT INTO payment_transactions 
            (member_admno, amount, payment_type, payment_method, receipt_no, reference_id, created_by, created_at) 
            VALUES (?, ?, ?, 'online', ?, ?, ?, datetime('now'))");
        $stmt->execute([$memberAdmno, $amount, $paymentType, $receiptNo, $paymentId, $_SESSION['username']]);
        
        // If paying fine, update member fines
        if ($paymentType === 'fine') {
            $db->prepare("UPDATE members SET total_paid_fines = total_paid_fines + ? WHERE admno = ?")->execute([$amount, $memberAdmno]);
        }
        
        logActivity($_SESSION['username'], 'ONLINE_PAYMENT', "Payment of {$currencySymbol}{$amount} received from {$memberAdmno}");
        
        $_SESSION['payment_success'] = true;
        $_SESSION['payment_receipt'] = $receiptNo;
        header("Location: payment_success.php?receipt=" . urlencode($receiptNo));
        exit;
    } else {
        $_SESSION['payment_error'] = "Payment verification failed";
        header("Location: online_payment.php");
        exit;
    }
}

renderHeader('Online Payment');
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-credit-card"></i> Online Payment</h2>
        <a href="../index.php" class="btn btn-secondary">Back to Home</a>
    </div>
    
    <?php if (isset($_SESSION['payment_error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['payment_error']) ?></div>
        <?php unset($_SESSION['payment_error']); ?>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Member Details</h5>
                </div>
                <div class="card-body">
                    <div class="input-group mb-3">
                        <input type="text" id="memberSearch" class="form-control" placeholder="Enter Admission Number" value="<?= htmlspecialchars($memberAdmno) ?>">
                        <button class="btn btn-primary" onclick="searchMember()">Search</button>
                    </div>
                    <div id="memberDetails" style="display: none;">
                        <table class="table table-bordered">
                            <tr><th>Name:</th><td id="memberName"></td></tr>
                            <tr><th>Category:</th><td id="memberCategory"></td></tr>
                            <tr><th>Outstanding Fine:</th><td id="outstandingFine"></td></tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-wallet"></i> Make Payment</h5>
                </div>
                <div class="card-body">
                    <form id="paymentForm">
                        <input type="hidden" id="memberAdmno" name="member_admno">
                        <input type="hidden" id="paymentAmount" name="amount">
                        <input type="hidden" id="paymentType" name="payment_type">
                        
                        <div class="mb-3">
                            <label class="form-label">Payment Type</label>
                            <select id="payType" class="form-select" required>
                                <option value="">Select Payment Type</option>
                                <option value="fine">Fine Payment</option>
                                <option value="deposit">Security Deposit</option>
                                <option value="lost_fee">Lost/Damaged Fee</option>
                                <option value="membership_fee">Membership Fee</option>
                                <option value="donation">Donation</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Amount (<?= $currencySymbol ?>)</label>
                            <input type="number" id="amount" step="0.01" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Description (Optional)</label>
                            <textarea id="description" class="form-control" rows="2" placeholder="Any additional notes..."></textarea>
                        </div>
                        
                        <button type="button" id="payNowBtn" class="btn btn-success btn-lg w-100" onclick="initiatePayment()">
                            <i class="fas fa-credit-card"></i> Pay Now
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Payment Methods Info -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-shield-alt"></i> Secure Payment</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3">
                            <i class="fab fa-cc-visa fa-3x text-primary"></i>
                            <p>Visa</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fab fa-cc-mastercard fa-3x text-danger"></i>
                            <p>Mastercard</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fab fa-cc-amex fa-3x text-info"></i>
                            <p>American Express</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fab fa-cc-paypal fa-3x text-primary"></i>
                            <p>PayPal</p>
                        </div>
                    </div>
                    <hr>
                    <p class="text-muted small text-center mb-0">
                        <i class="fas fa-lock"></i> Your payment information is secure and encrypted.
                        We accept all major credit/debit cards, UPI, NetBanking, and wallets.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Razorpay Script -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script>
function searchMember() {
    let admno = document.getElementById('memberSearch').value.trim();
    if(admno.length < 2) {
        alert('Please enter at least 2 characters');
        return;
    }
    
    fetch('../entry_exit/ajax_member.php?admno=' + encodeURIComponent(admno))
        .then(response => response.json())
        .then(data => {
            if(data && data.name) {
                document.getElementById('memberDetails').style.display = 'block';
                document.getElementById('memberName').innerHTML = escapeHtml(data.name);
                document.getElementById('memberCategory').innerHTML = escapeHtml(data.member_category);
                document.getElementById('outstandingFine').innerHTML = '<?= $currencySymbol ?> ' + (data.total_fines || '0.00');
                document.getElementById('memberAdmno').value = admno;
                
                // Auto-set amount to outstanding fine
                if(data.total_fines > 0) {
                    document.getElementById('amount').value = data.total_fines;
                    document.getElementById('payType').value = 'fine';
                }
            } else {
                alert('Member not found');
                document.getElementById('memberDetails').style.display = 'none';
            }
        })
        .catch(err => {
            console.error(err);
            alert('Error searching member');
        });
}

function initiatePayment() {
    let memberAdmno = document.getElementById('memberAdmno').value;
    let amount = parseFloat(document.getElementById('amount').value);
    let paymentType = document.getElementById('payType').value;
    let description = document.getElementById('description').value;
    
    if(!memberAdmno) {
        alert('Please search and select a member first');
        return;
    }
    if(!amount || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }
    if(!paymentType) {
        alert('Please select payment type');
        return;
    }
    
    // Create order on server
    fetch('create_order.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            amount: amount,
            member_admno: memberAdmno,
            payment_type: paymentType,
            description: description
        })
    })
    .then(response => response.json())
    .then(order => {
        if(order.error) {
            alert(order.error);
            return;
        }
        
        let options = {
            key: '<?= $razorpayKey ?>',
            amount: order.amount,
            currency: order.currency,
            name: 'Library System',
            description: paymentType.toUpperCase() + ' Payment',
            order_id: order.id,
            handler: function(response) {
                // Payment successful
                document.getElementById('paymentForm').innerHTML += `
                    <input type="hidden" name="razorpay_payment_id" value="${response.razorpay_payment_id}">
                    <input type="hidden" name="razorpay_order_id" value="${response.razorpay_order_id}">
                    <input type="hidden" name="razorpay_signature" value="${response.razorpay_signature}">
                    <input type="hidden" name="amount" value="${amount}">
                    <input type="hidden" name="member_admno" value="${memberAdmno}">
                    <input type="hidden" name="payment_type" value="${paymentType}">
                `;
                document.getElementById('paymentForm').submit();
            },
            prefill: {
                name: document.getElementById('memberName').innerText,
                email: '<?= $member['email'] ?? '' ?>',
                contact: '<?= $member['phone'] ?? '' ?>'
            },
            theme: {
                color: '#1e3c72'
            }
        };
        let rzp = new Razorpay(options);
        rzp.open();
    })
    .catch(err => {
        console.error(err);
        alert('Error creating payment order');
    });
}

function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}
</script>

<?php renderFooter(); ?>