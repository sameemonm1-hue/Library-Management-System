<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$amount = $input['amount'] ?? 0;
$memberAdmno = $input['member_admno'] ?? '';
$paymentType = $input['payment_type'] ?? '';
$description = $input['description'] ?? '';

if ($amount <= 0) {
    echo json_encode(['error' => 'Invalid amount']);
    exit;
}

$settings = getSettings();
$razorpayKey = $settings['razorpay_key_id'] ?? '';
$razorpaySecret = $settings['razorpay_key_secret'] ?? '';

if (empty($razorpayKey) || empty($razorpaySecret)) {
    echo json_encode(['error' => 'Payment gateway not configured']);
    exit;
}

// Create order in Razorpay
$amountInPaise = round($amount * 100);
$receipt = 'RCPT_' . uniqid();

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_USERPWD, $razorpayKey . ':' . $razorpaySecret);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    'amount' => $amountInPaise,
    'currency' => $settings['currency_code'] ?? 'INR',
    'receipt' => $receipt,
    'notes' => [
        'member_admno' => $memberAdmno,
        'payment_type' => $paymentType,
        'description' => $description
    ]
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    echo $response;
} else {
    echo json_encode(['error' => 'Failed to create order: ' . $response]);
}
?>