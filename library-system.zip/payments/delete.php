<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') die("Access denied.");

// CSRF token check
if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid ID.");

$db = getDB();
$pay = $db->prepare("SELECT * FROM payment_transactions WHERE id=?");
$pay->execute([$id]);
$payment = $pay->fetch();
if ($payment && $payment['payment_type'] == 'fine') {
    $db->prepare("UPDATE members SET total_paid_fines = total_paid_fines - ? WHERE admno = ?")->execute([$payment['amount'], $payment['member_admno']]);
}
$db->prepare("DELETE FROM payment_transactions WHERE id = ?")->execute([$id]);
logActivity($_SESSION['username'], 'PAYMENT_DELETE', "Deleted payment ID {$id}");
header("Location: index.php?msg=deleted");
exit;
?>