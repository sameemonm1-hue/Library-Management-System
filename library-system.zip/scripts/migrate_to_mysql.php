#!/usr/bin/env php
<?php
// Usage: php scripts/migrate_to_mysql.php

require_once __DIR__ . '/../config/db.php';

define('MYSQL_HOST', 'localhost');
define('MYSQL_DB',   'library_erp');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');

try {
    $sqlite = new PDO("sqlite:" . DB_FILE);
    $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $mysql = new PDO("mysql:host=" . MYSQL_HOST . ";charset=utf8mb4", MYSQL_USER, MYSQL_PASS);
    $mysql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $mysql->exec("CREATE DATABASE IF NOT EXISTS `" . MYSQL_DB . "`");
    $mysql->exec("USE `" . MYSQL_DB . "`");
    
    // Import schema.sql (MySQL version)
    $schema = file_get_contents(__DIR__ . '/../schema_mysql.sql');
    $mysql->exec($schema);
    echo "MySQL schema created.\n";
    
    // Migrate tables
    $tables = ['users', 'members', 'books', 'circulation', 'settings', 'vendors', 'purchase_orders', 
               'ebooks', 'research_databases', 'fine_rates', 'payment_transactions', 'lost_books',
               'notices', 'suggestions', 'entry_exit', 'library_events', 'book_holds', 
               'reservations_queue', 'serial_subscriptions', 'serial_issues', 'computer_sessions',
               'staff_profiles', 'quick_actions', 'activity_logs', 'session_logs', 'daily_stats'];
    
    foreach ($tables as $table) {
        $rows = $sqlite->query("SELECT * FROM $table")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) continue;
        
        $columns = array_keys($rows[0]);
        $placeholders = ':' . implode(', :', $columns);
        $insert = $mysql->prepare("INSERT INTO $table (" . implode(',', $columns) . ") VALUES ($placeholders)");
        
        foreach ($rows as $row) {
            // Convert SQLite date functions to MySQL
            foreach ($row as $key => $value) {
                if ($value === 'now' || $value === 'CURRENT_TIMESTAMP' || strpos($value, 'datetime(') !== false) {
                    $row[$key] = date('Y-m-d H:i:s');
                }
            }
            $insert->execute($row);
        }
        echo "Migrated $table: " . count($rows) . " records.\n";
    }
    echo "Migration completed successfully.\n";
} catch (Exception $e) {
    die("Error: " . $e->getMessage() . "\n");
}