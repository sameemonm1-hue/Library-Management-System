#!/usr/bin/env php
<?php
/**
 * scripts/generate_embeddings.php
 * 
 * Pre‑compute vector embeddings for all books using the Python embedding server.
 * Run this script once after installing the embedding server, then schedule weekly.
 * 
 * Usage: php scripts/generate_embeddings.php [--force] [--batch-size=50]
 *   --force        Re‑generate embeddings even if they already exist
 *   --batch-size   Number of books to process in one batch (default 50)
 * 
 * Requires: Python embedding server running on localhost:5001
 *           Or configure AIEmbedding::setServerUrl() in config/functions.php
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../includes/AIEmbedding.php';

$force = in_array('--force', $argv);
$batchSize = 50;
foreach ($argv as $arg) {
    if (strpos($arg, '--batch-size=') === 0) {
        $batchSize = (int)substr($arg, strlen('--batch-size='));
        break;
    }
}

// Ensure books table has embedding column (if missing)
$db = getDB();
try {
    $db->exec("ALTER TABLE books ADD COLUMN embedding TEXT");
    echo "Added embedding column to books table.\n";
} catch (PDOException $e) {
    // Column already exists
}

// Get all books without embeddings (or all if --force)
if ($force) {
    $stmt = $db->query("SELECT id, title, author, summary FROM books WHERE status != 'Deleted'");
} else {
    $stmt = $db->query("SELECT id, title, author, summary FROM books WHERE (embedding IS NULL OR embedding = '') AND status != 'Deleted'");
}
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($books)) {
    echo "No books need embedding.\n";
    exit(0);
}

echo "Generating embeddings for " . count($books) . " books (batch size: $batchSize)...\n";

AIEmbedding::init();

$total = count($books);
$processed = 0;
$failed = 0;

for ($i = 0; $i < $total; $i += $batchSize) {
    $batch = array_slice($books, $i, $batchSize);
    $texts = [];
    $ids = [];
    foreach ($batch as $book) {
        $text = $book['title'] . ' ' . ($book['author'] ?? '') . ' ' . ($book['summary'] ?? '');
        $text = trim(preg_replace('/\s+/', ' ', $text));
        if (empty($text)) {
            $text = $book['title'];
        }
        $texts[] = mb_substr($text, 0, 8000);
        $ids[] = $book['id'];
    }

    $embeddings = AIEmbedding::batchGetEmbeddings($texts);
    if ($embeddings === null || count($embeddings) !== count($ids)) {
        echo "Batch failed – skipping IDs: " . implode(',', $ids) . "\n";
        $failed += count($ids);
        continue;
    }

    $updateStmt = $db->prepare("UPDATE books SET embedding = ? WHERE id = ?");
    foreach ($ids as $idx => $id) {
        $json = json_encode($embeddings[$idx]);
        $updateStmt->execute([$json, $id]);
        $processed++;
    }

    echo "Progress: $processed / $total\n";
}

echo "Done. Processed: $processed, Failed: $failed\n";