<?php
/**
 * Universal Autoloader for Library ERP
 * 
 * Priority:
 * 1. Composer's native autoloader (vendor/autoload.php)
 * 2. Manual fallbacks for legacy libraries if Composer is missing
 */

// ============================================
// 1. TRY COMPOSER AUTOLOADER (RECOMMENDED)
// ============================================
$composerAutoloadPaths = [
    __DIR__ . '/../vendor/autoload.php',        // typical: project_root/config/../vendor/autoload.php
    __DIR__ . '/../../vendor/autoload.php',     // if autoload.php is deeper
    __DIR__ . '/vendor/autoload.php',           // if autoload.php is in same folder as vendor
];

$composerLoaded = false;
foreach ($composerAutoloadPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        $composerLoaded = true;
        break;
    }
}

// If Composer autoloader is loaded, we are done – it handles everything.
if ($composerLoaded) {
    // Return a dummy object for compatibility (some legacy code expects a return value)
    return new class {
        public function getLoader() {
            return $this;
        }
    };
}

// ============================================
// 2. FALLBACK MANUAL AUTOLOADERS (if Composer not available)
// ============================================
// These are only used when Composer is missing – typically on very old or custom installations.

spl_autoload_register(function ($class) {
    // mPDF Manual Autoloader
    $mpdfPaths = [
        __DIR__ . '/mpdf/mpdf/src/',
        __DIR__ . '/../vendor/mpdf/mpdf/src/',
        __DIR__ . '/../mpdf/mpdf/src/'
    ];
    
    if (strpos($class, 'Mpdf\\') === 0) {
        $relative_class = substr($class, 5);
        foreach ($mpdfPaths as $base_dir) {
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // PhpSpreadsheet Manual Autoloader
    $spreadsheetPaths = [
        __DIR__ . '/phpoffice/phpspreadsheet/src/PhpSpreadsheet/',
        __DIR__ . '/../vendor/phpoffice/phpspreadsheet/src/PhpSpreadsheet/',
        __DIR__ . '/../phpoffice/phpspreadsheet/src/PhpSpreadsheet/'
    ];
    
    if (strpos($class, 'PhpOffice\\PhpSpreadsheet\\') === 0) {
        $relative_class = substr($class, 25);
        foreach ($spreadsheetPaths as $base_dir) {
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // Google API Client Manual Autoloader
    $googlePaths = [
        __DIR__ . '/google/apiclient/src/',
        __DIR__ . '/../vendor/google/apiclient/src/',
        __DIR__ . '/../google/apiclient/src/'
    ];
    
    if (strpos($class, 'Google_') === 0 && $class !== 'Google_Client') {
        $relative_class = substr($class, 7);
        foreach ($googlePaths as $base_dir) {
            $file = $base_dir . str_replace('_', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // Google_Client specific
    $googleClientPaths = [
        __DIR__ . '/google/apiclient/src/Google/Client.php',
        __DIR__ . '/../vendor/google/apiclient/src/Google/Client.php',
        __DIR__ . '/../google/apiclient/src/Google/Client.php'
    ];
    
    if ($class === 'Google_Client') {
        foreach ($googleClientPaths as $file) {
            if (file_exists($file)) {
                require_once $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // Google Service Classes
    $googleServicePaths = [
        __DIR__ . '/google/apiclient-services/src/',
        __DIR__ . '/../vendor/google/apiclient-services/src/',
        __DIR__ . '/../google/apiclient-services/src/'
    ];
    
    if (strpos($class, 'Google_Service_') === 0) {
        $relative_class = substr($class, 15);
        foreach ($googleServicePaths as $base_dir) {
            $file = $base_dir . str_replace('_', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // Monolog
    $monologPaths = [
        __DIR__ . '/monolog/monolog/src/Monolog/',
        __DIR__ . '/../vendor/monolog/monolog/src/Monolog/',
        __DIR__ . '/../monolog/monolog/src/Monolog/'
    ];
    
    if (strpos($class, 'Monolog\\') === 0) {
        $relative_class = substr($class, 8);
        foreach ($monologPaths as $base_dir) {
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // Psr\Log
    $psrLogPaths = [
        __DIR__ . '/psr/log/Psr/Log/',
        __DIR__ . '/../vendor/psr/log/Psr/Log/',
        __DIR__ . '/../psr/log/Psr/Log/'
    ];
    
    if (strpos($class, 'Psr\\Log\\') === 0) {
        $relative_class = substr($class, 8);
        foreach ($psrLogPaths as $base_dir) {
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
            if (file_exists($file)) {
                require $file;
                return true;
            }
        }
    }
    return false;
});

spl_autoload_register(function ($class) {
    // TCPDF
    $tcpdfPaths = [
        __DIR__ . '/tecnickcom/tcpdf/',
        __DIR__ . '/../vendor/tecnickcom/tcpdf/',
        __DIR__ . '/../tcpdf/'
    ];
    
    if (strpos($class, 'TCPDF') === 0) {
        foreach ($tcpdfPaths as $base_dir) {
            $file = $base_dir . str_replace('_', '.php', $class);
            if (file_exists($file)) {
                require $file;
                return true;
            }
            $file2 = $base_dir . 'tcpdf.php';
            if (file_exists($file2)) {
                require $file2;
                return true;
            }
        }
    }
    return false;
});

// ============================================
// Return dummy loader for compatibility
// ============================================
return new class {
    public function getLoader() {
        return $this;
    }
};