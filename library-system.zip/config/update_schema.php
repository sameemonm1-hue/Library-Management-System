#!/usr/bin/env php
<?php
// update_schema.php – CLI schema updater
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/MigrationManager.php';

$db = getDB();
$mgr = new MigrationManager($db, __DIR__ . '/migrations/');

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

$args = $argv;
$command = $args[1] ?? 'run';

switch ($command) {
    case 'run':
        echo "Running pending migrations...\n";
        $result = $mgr->runPending();
        if (!empty($result['run'])) {
            echo "Applied: " . implode(', ', $result['run']) . "\n";
        }
        if (!empty($result['errors'])) {
            echo "Errors:\n";
            foreach ($result['errors'] as $file => $error) {
                echo "  $file: $error\n";
            }
            exit(1);
        }
        echo "Done.\n";
        break;

    case 'status':
        $status = $mgr->getStatus();
        echo "Applied migrations (" . count($status['applied']) . "):\n";
        foreach ($status['applied'] as $f) echo "  ✓ $f\n";
        echo "\nPending migrations (" . count($status['pending']) . "):\n";
        foreach ($status['pending'] as $f) echo "  ○ $f\n";
        break;

    case 'create':
        if (empty($args[2])) {
            echo "Usage: php update_schema.php create <migration_name>\n";
            exit(1);
        }
        $name = preg_replace('/[^a-zA-Z0-9_]/', '_', $args[2]);
        $timestamp = date('Ymd_His');
        $filename = "{$timestamp}_{$name}.sql";
        $path = __DIR__ . "/migrations/{$filename}";
        if (!is_dir(__DIR__ . '/migrations')) mkdir(__DIR__ . '/migrations', 0755, true);
        file_put_contents($path, "-- Migration: {$name}\n-- Created: " . date('Y-m-d H:i:s') . "\n\n");
        echo "Created empty migration: $path\n";
        break;

    default:
        echo "Usage: php update_schema.php {run|status|create <name>}\n";
        exit(1);
}