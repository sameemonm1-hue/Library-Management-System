<?php
/**
 * Redis Connection Manager
 * Returns a Redis instance, or null if extension not loaded / connection fails.
 */

if (!extension_loaded('redis')) {
    error_log('Redis extension not loaded. Caching disabled.');
    return null;
}

try {
    $redis = new Redis();
    $connected = $redis->connect(
        getenv('REDIS_HOST') ?: '127.0.0.1',
        (int)(getenv('REDIS_PORT') ?: 6379),
        2.5 // timeout seconds
    );
    if (!$connected) throw new Exception('Could not connect to Redis server');
    
    $password = getenv('REDIS_PASSWORD') ?: null;
    if ($password) $redis->auth($password);
    
    $redis->select((int)(getenv('REDIS_DB') ?: 0));
    return $redis;
    
} catch (Exception $e) {
    error_log('Redis error: ' . $e->getMessage());
    return null;
}