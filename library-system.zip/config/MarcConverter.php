<?php
/**
 * MARC21 Converter – XML ↔ JSON ↔ Database Array
 * 
 * Features:
 * - Convert MARCXML to JSON (and back)
 * - Convert MARCXML to database array (for book insertion/update)
 * - Convert database array to MARCXML
 * - Validate MARC records against basic rules
 * - Extract specific fields (title, author, ISBN, etc.) with fallbacks
 * - Support for leader, control fields (001-009), and data fields (010-999)
 * 
 * Dependencies:
 * - ext-dom, ext-xml (core PHP)
 * - Optional: scriptotek/marc (Composer) for advanced operations
 * 
 * @author Library ERP
 * @version 1.0
 */

class MarcConverter {
    
    /**
     * @var bool Whether scriptotek/marc library is available
     */
    private static $marcLibAvailable = false;
    
    /**
     * @var array Mapping of MARC tags to database fields (simple)
     */
    private static $fieldMapping = [
        '001' => 'identifier',
        '020' => 'isbn',
        '022' => 'issn',
        '041' => 'language',
        '100' => 'author',
        '110' => 'corporate_author',
        '245' => 'title',
        '246' => 'variant_title',
        '250' => 'edition',
        '260' => 'publisher_info',
        '264' => 'production_info',
        '300' => 'physical_description',
        '490' => 'series_statement',
        '500' => 'general_note',
        '504' => 'bibliography_note',
        '505' => 'contents_note',
        '520' => 'summary',
        '650' => 'subject',
        '700' => 'added_author',
        '710' => 'added_corporate',
        '856' => 'electronic_location',
    ];
    
    /**
     * Initialize: check for available MARC libraries
     */
    public static function init() {
        if (!self::$marcLibAvailable) {
            if (class_exists('Scriptotek\Marc\MarcReader')) {
                self::$marcLibAvailable = true;
            } elseif (class_exists('File_MARC')) {
                self::$marcLibAvailable = true;
            }
        }
    }
    
    /**
     * Convert MARCXML to JSON string
     * 
     * @param string $marcxml MARCXML document
     * @return string JSON representation
     */
    public static function toJson($marcxml) {
        $array = self::marcXmlToArray($marcxml);
        return json_encode($array, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    /**
     * Convert JSON to MARCXML
     * 
     * @param string $json JSON representation of MARC record
     * @return string MARCXML
     */
    public static function toMarc($json) {
        $data = json_decode($json, true);
        if (!$data) return '';
        return self::arrayToMarcXml($data);
    }
    
    /**
     * Convert MARCXML to database array (for books table)
     * 
     * @param string $marcxml MARCXML document
     * @return array Associative array with keys matching books table columns
     */
    public static function toDbArray($marcxml) {
        $result = [
            'title' => '',
            'sub_title' => '',
            'author' => '',
            'author2' => '',
            'collaborator' => '',
            'isbn' => '',
            'issn' => '',
            'publisher' => '',
            'publisher_place' => '',
            'year' => '',
            'edition' => '',
            'pages' => '',
            'language' => 'English',
            'subject' => '',
            'summary' => '',
            'series' => '',
            'call_number' => '',
            'url' => '',
        ];
        
        $array = self::marcXmlToArray($marcxml);
        
        // Title (245$a and $b)
        if (isset($array['245'])) {
            foreach ($array['245'] as $field) {
                $subfields = $field['subfields'];
                if (isset($subfields['a'])) $result['title'] = trim($subfields['a']);
                if (isset($subfields['b'])) $result['sub_title'] = trim($subfields['b']);
                break;
            }
        }
        
        // Author (100$a)
        if (isset($array['100'])) {
            foreach ($array['100'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['author'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // Additional authors (700$a)
        $authors2 = [];
        if (isset($array['700'])) {
            foreach ($array['700'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $authors2[] = trim($field['subfields']['a']);
                }
            }
        }
        if (!empty($authors2)) $result['author2'] = implode('; ', $authors2);
        
        // Collaborator (710$a)
        if (isset($array['710'])) {
            foreach ($array['710'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['collaborator'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // ISBN (020$a)
        if (isset($array['020'])) {
            foreach ($array['020'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['isbn'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // ISSN (022$a)
        if (isset($array['022'])) {
            foreach ($array['022'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['issn'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // Publisher (260$b or 264$b)
        if (isset($array['260'])) {
            foreach ($array['260'] as $field) {
                if (isset($field['subfields']['b'])) $result['publisher'] = trim($field['subfields']['b']);
                if (isset($field['subfields']['a'])) $result['publisher_place'] = trim($field['subfields']['a']);
                break;
            }
        } elseif (isset($array['264'])) {
            foreach ($array['264'] as $field) {
                if (isset($field['subfields']['b'])) $result['publisher'] = trim($field['subfields']['b']);
                if (isset($field['subfields']['a'])) $result['publisher_place'] = trim($field['subfields']['a']);
                break;
            }
        }
        
        // Year (260$c or 264$c)
        $year = '';
        if (isset($array['260'])) {
            foreach ($array['260'] as $field) {
                if (isset($field['subfields']['c'])) $year = trim($field['subfields']['c']);
                break;
            }
        } elseif (isset($array['264'])) {
            foreach ($array['264'] as $field) {
                if (isset($field['subfields']['c'])) $year = trim($field['subfields']['c']);
                break;
            }
        }
        if (preg_match('/\b(19|20)\d{2}\b/', $year, $matches)) {
            $result['year'] = $matches[0];
        }
        
        // Edition (250$a)
        if (isset($array['250'])) {
            foreach ($array['250'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['edition'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // Pages (300$a)
        if (isset($array['300'])) {
            foreach ($array['300'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $pages = trim($field['subfields']['a']);
                    if (preg_match('/(\d+)\s*p\.?/i', $pages, $matches)) {
                        $result['pages'] = (int)$matches[1];
                    }
                    break;
                }
            }
        }
        
        // Language (041$a)
        if (isset($array['041'])) {
            foreach ($array['041'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $lang = trim($field['subfields']['a']);
                    $langMap = ['eng' => 'English', 'fre' => 'French', 'ger' => 'German', 'spa' => 'Spanish', 'ara' => 'Arabic'];
                    $result['language'] = $langMap[strtolower($lang)] ?? strtoupper($lang);
                    break;
                }
            }
        }
        
        // Subject (650$a)
        $subjects = [];
        if (isset($array['650'])) {
            foreach ($array['650'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $subjects[] = trim($field['subfields']['a']);
                }
            }
        }
        if (!empty($subjects)) $result['subject'] = implode('; ', $subjects);
        
        // Summary (520$a)
        if (isset($array['520'])) {
            foreach ($array['520'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['summary'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // Series (490$a)
        if (isset($array['490'])) {
            foreach ($array['490'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['series'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // Call number (050$a or 082$a)
        if (isset($array['050'])) {
            foreach ($array['050'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['call_number'] = trim($field['subfields']['a']);
                    break;
                }
            }
        } elseif (isset($array['082'])) {
            foreach ($array['082'] as $field) {
                if (isset($field['subfields']['a'])) {
                    $result['call_number'] = trim($field['subfields']['a']);
                    break;
                }
            }
        }
        
        // URL (856$u)
        if (isset($array['856'])) {
            foreach ($array['856'] as $field) {
                if (isset($field['subfields']['u'])) {
                    $result['url'] = trim($field['subfields']['u']);
                    break;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Convert database array to MARCXML
     * 
     * @param array $bookData Associative array with keys from books table
     * @param string $leader Optional leader (defaults to standard)
     * @return string MARCXML
     */
    public static function fromDbArray($bookData, $leader = null) {
        $fields = [];
        
        // Leader
        if ($leader === null) {
            $leader = '00000nam a2200000 a 4500';
        }
        
        // Control fields
        if (!empty($bookData['barcode'])) {
            $fields['001'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $bookData['barcode']]]];
        }
        
        // ISBN (020)
        if (!empty($bookData['isbn'])) {
            $fields['020'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $bookData['isbn']]]];
        }
        
        // Title (245)
        $titleSubfields = [];
        if (!empty($bookData['title'])) $titleSubfields['a'] = $bookData['title'];
        if (!empty($bookData['sub_title'])) $titleSubfields['b'] = $bookData['sub_title'];
        if (!empty($titleSubfields)) {
            $fields['245'] = [['ind1' => '1', 'ind2' => '0', 'subfields' => $titleSubfields]];
        }
        
        // Author (100)
        if (!empty($bookData['author'])) {
            $fields['100'] = [['ind1' => '1', 'ind2' => ' ', 'subfields' => ['a' => $bookData['author']]]];
        }
        
        // Additional authors (700)
        if (!empty($bookData['author2'])) {
            $authors = explode(';', $bookData['author2']);
            foreach ($authors as $author) {
                $author = trim($author);
                if ($author) {
                    $fields['700'][] = ['ind1' => '1', 'ind2' => ' ', 'subfields' => ['a' => $author]];
                }
            }
        }
        
        // Collaborator (710)
        if (!empty($bookData['collaborator'])) {
            $fields['710'] = [['ind1' => '2', 'ind2' => ' ', 'subfields' => ['a' => $bookData['collaborator']]]];
        }
        
        // Edition (250)
        if (!empty($bookData['edition'])) {
            $fields['250'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $bookData['edition']]]];
        }
        
        // Publisher info (260)
        $pubSubfields = [];
        if (!empty($bookData['publisher_place'])) $pubSubfields['a'] = $bookData['publisher_place'];
        if (!empty($bookData['publisher'])) $pubSubfields['b'] = $bookData['publisher'];
        if (!empty($bookData['year'])) $pubSubfields['c'] = $bookData['year'];
        if (!empty($pubSubfields)) {
            $fields['260'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => $pubSubfields]];
        }
        
        // Physical description (300)
        $physDesc = '';
        if (!empty($bookData['pages'])) $physDesc .= $bookData['pages'] . ' p.';
        if (!empty($bookData['dimensions'])) $physDesc .= ' ; ' . $bookData['dimensions'];
        if (!empty($physDesc)) {
            $fields['300'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $physDesc]]];
        }
        
        // Series (490)
        if (!empty($bookData['series'])) {
            $fields['490'] = [['ind1' => '0', 'ind2' => ' ', 'subfields' => ['a' => $bookData['series']]]];
        }
        
        // Summary (520)
        if (!empty($bookData['summary'])) {
            $fields['520'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $bookData['summary']]]];
        }
        
        // Subject (650)
        if (!empty($bookData['subject'])) {
            $subjects = explode(';', $bookData['subject']);
            foreach ($subjects as $subject) {
                $subject = trim($subject);
                if ($subject) {
                    $fields['650'][] = ['ind1' => ' ', 'ind2' => '0', 'subfields' => ['a' => $subject]];
                }
            }
        }
        
        // Call number (050)
        if (!empty($bookData['call_number'])) {
            $fields['050'] = [['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $bookData['call_number']]]];
        }
        
        // URL (856)
        if (!empty($bookData['url'])) {
            $fields['856'] = [['ind1' => '4', 'ind2' => '0', 'subfields' => ['u' => $bookData['url']]]];
        }
        
        return self::arrayToMarcXml($fields, $leader);
    }
    
    /**
     * Convert MARCXML to nested array structure
     * 
     * @param string $marcxml MARCXML document
     * @return array Associative array with tags as keys, each containing array of fields
     */
    public static function marcXmlToArray($marcxml) {
        $result = [];
        $dom = new DOMDocument();
        if (!@$dom->loadXML($marcxml)) return $result;
        
        $xpath = new DOMXPath($dom);
        $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');
        
        // Control fields (001-009)
        $controlFields = $xpath->query('//marc:controlfield');
        foreach ($controlFields as $cf) {
            $tag = $cf->getAttribute('tag');
            $value = trim($cf->nodeValue);
            if (!isset($result[$tag])) $result[$tag] = [];
            $result[$tag][] = ['ind1' => ' ', 'ind2' => ' ', 'subfields' => ['a' => $value]];
        }
        
        // Data fields
        $dataFields = $xpath->query('//marc:datafield');
        foreach ($dataFields as $df) {
            $tag = $df->getAttribute('tag');
            $ind1 = $df->getAttribute('ind1');
            $ind2 = $df->getAttribute('ind2');
            $subfields = [];
            $subfieldNodes = $xpath->query('.//marc:subfield', $df);
            foreach ($subfieldNodes as $sf) {
                $code = $sf->getAttribute('code');
                $value = trim($sf->nodeValue);
                if ($value !== '') {
                    $subfields[$code] = $value;
                }
            }
            if (!empty($subfields)) {
                if (!isset($result[$tag])) $result[$tag] = [];
                $result[$tag][] = [
                    'ind1' => $ind1,
                    'ind2' => $ind2,
                    'subfields' => $subfields,
                ];
            }
        }
        
        return $result;
    }
    
    /**
     * Convert array structure to MARCXML
     * 
     * @param array $fields Array with tags as keys (same format as marcXmlToArray output)
     * @param string $leader Leader string (defaults to standard)
     * @return string MARCXML
     */
    public static function arrayToMarcXml($fields, $leader = '00000nam a2200000 a 4500') {
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->formatOutput = true;
        
        $collection = $dom->createElementNS('http://www.loc.gov/MARC21/slim', 'collection');
        $record = $dom->createElement('record');
        
        // Leader
        $leaderElem = $dom->createElement('leader', $leader);
        $record->appendChild($leaderElem);
        
        // Control fields
        foreach ($fields as $tag => $occurrences) {
            if ($tag >= '001' && $tag <= '009') {
                foreach ($occurrences as $occ) {
                    $cf = $dom->createElement('controlfield');
                    $cf->setAttribute('tag', $tag);
                    $value = $occ['subfields']['a'] ?? '';
                    $cf->appendChild($dom->createTextNode($value));
                    $record->appendChild($cf);
                }
            }
        }
        
        // Data fields
        foreach ($fields as $tag => $occurrences) {
            if ($tag < '010') continue; // control fields already handled
            foreach ($occurrences as $occ) {
                $df = $dom->createElement('datafield');
                $df->setAttribute('tag', $tag);
                $df->setAttribute('ind1', $occ['ind1'] ?? ' ');
                $df->setAttribute('ind2', $occ['ind2'] ?? ' ');
                foreach ($occ['subfields'] as $code => $value) {
                    $sf = $dom->createElement('subfield', htmlspecialchars($value, ENT_XML1, 'UTF-8'));
                    $sf->setAttribute('code', $code);
                    $df->appendChild($sf);
                }
                $record->appendChild($df);
            }
        }
        
        $collection->appendChild($record);
        $dom->appendChild($collection);
        return $dom->saveXML();
    }
    
    /**
     * Validate MARCXML against basic rules
     * 
     * @param string $marcxml MARCXML document
     * @return array Array of errors (empty if valid)
     */
    public static function validate($marcxml) {
        $errors = [];
        $array = self::marcXmlToArray($marcxml);
        
        // Check required fields
        if (!isset($array['245']) || empty($array['245'])) {
            $errors[] = 'Missing required field: 245 (Title)';
        }
        
        // Check for duplicate tags (not an error, but warning)
        foreach ($array as $tag => $fields) {
            if (count($fields) > 1 && !in_array($tag, ['650', '700', '710'])) {
                $errors[] = "Multiple occurrences of field $tag (may be valid but verify)";
            }
        }
        
        // Check indicator values
        if (isset($array['245'])) {
            foreach ($array['245'] as $field) {
                $ind1 = $field['ind1'] ?? ' ';
                if ($ind1 !== '1' && $ind1 !== '0' && $ind1 !== ' ') {
                    $errors[] = "Field 245 indicator 1 should be 0, 1, or blank";
                }
            }
        }
        
        return $errors;
    }
    
    /**
     * Extract a specific field from MARCXML
     * 
     * @param string $marcxml MARCXML document
     * @param string $tag MARC tag (e.g., '020')
     * @param string $subfield Optional subfield code
     * @return array Values found
     */
    public static function extractField($marcxml, $tag, $subfield = null) {
        $result = [];
        $array = self::marcXmlToArray($marcxml);
        
        if (!isset($array[$tag])) return $result;
        
        foreach ($array[$tag] as $field) {
            if ($subfield === null) {
                $result[] = $field['subfields'];
            } elseif (isset($field['subfields'][$subfield])) {
                $result[] = $field['subfields'][$subfield];
            }
        }
        
        return $result;
    }
    
    /**
     * Get a human-readable summary of the MARC record
     * 
     * @param string $marcxml MARCXML document
     * @return string HTML/text summary
     */
    public static function getSummary($marcxml) {
        $data = self::toDbArray($marcxml);
        $summary = '';
        if ($data['title']) $summary .= "Title: {$data['title']}\n";
        if ($data['author']) $summary .= "Author: {$data['author']}\n";
        if ($data['isbn']) $summary .= "ISBN: {$data['isbn']}\n";
        if ($data['publisher']) $summary .= "Publisher: {$data['publisher']}\n";
        if ($data['year']) $summary .= "Year: {$data['year']}\n";
        if ($data['pages']) $summary .= "Pages: {$data['pages']}\n";
        return $summary;
    }
}

// Initialize on load
MarcConverter::init();