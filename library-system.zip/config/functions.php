<?php
/**
 * Library Management System - Functions File
 * Version: 3.0 – Fully Enhanced & Unified
 * Comprehensive helper functions for the entire application.
 * Includes caching, authentication, notifications, PDF generation,
 * image handling, fine calculation, multilingual support, and more.
 */

declare(strict_types=1);

require_once __DIR__ . '/db.php';
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

// ============================================================================
// PATHS & CONSTANTS
// ============================================================================

if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}
if (!defined('UPLOAD_DIR')) {
    define('UPLOAD_DIR', BASE_PATH . '/uploads/');
}
if (!defined('BOOK_COVER_DIR')) {
    define('BOOK_COVER_DIR', UPLOAD_DIR . 'book_covers/');
    define('EBOOK_DIR', UPLOAD_DIR . 'ebooks/');
    define('MEMBER_PHOTO_DIR', UPLOAD_DIR . 'member_photos/');
    define('SIGNATURE_DIR', UPLOAD_DIR . 'signatures/');
    define('BACKUP_DIR', BASE_PATH . '/backups/');
    define('CACHE_DIR', BASE_PATH . '/cache/');
    define('REPORT_TEMP_DIR', BASE_PATH . '/temp/reports/');
    define('IMPORT_LOG_DIR', BASE_PATH . '/logs/imports/');
    define('TEMP_IMPORT_DIR', BASE_PATH . '/temp_imports/');
}

// Ensure directories exist
$dirs = [
    UPLOAD_DIR, BOOK_COVER_DIR, EBOOK_DIR, MEMBER_PHOTO_DIR,
    SIGNATURE_DIR, BACKUP_DIR, CACHE_DIR, REPORT_TEMP_DIR,
    IMPORT_LOG_DIR, TEMP_IMPORT_DIR
];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) mkdir($dir, 0755, true);
}

// ============================================================================
// MULTILINGUAL SUPPORT (FULL)
// ============================================================================

if (!function_exists('__t')) {
    /**
     * Translate a string using the current language.
     * Supports English, Hindi, Arabic – fallback to English.
     */
    function __t(string $key, ?string $lang = null): string
    {
        static $translations = null;
        if ($translations === null) {
            // Load translations from a central file or define inline
            $translations = [
                'en' => [
                    'library' => 'Library',
                    'dashboard' => 'Dashboard',
                    'members' => 'Members',
                    'books' => 'Books',
                    'circulation' => 'Circulation',
                    'reports' => 'Reports',
                    'settings' => 'Settings',
                    'logout' => 'Logout',
                    'login' => 'Login',
                    'search' => 'Search',
                    'add' => 'Add',
                    'edit' => 'Edit',
                    'delete' => 'Delete',
                    'save' => 'Save',
                    'cancel' => 'Cancel',
                    'back' => 'Back',
                    'home' => 'Home',
                    'issue_book' => 'Issue Book',
                    'return_book' => 'Return Book',
                    'renew' => 'Renew',
                    'overdue' => 'Overdue',
                    'fine' => 'Fine',
                    'total' => 'Total',
                    'available' => 'Available',
                    'issued' => 'Issued',
                    'whom' => 'Whom',
                    'my_account' => 'My Account',
                    'pay_fines' => 'Pay Fines',
                    'advanced_search' => 'Advanced Search',
                    'semantic_search' => 'Semantic Search (AI)',
                    'thought_of_the_day' => 'Thought of the Day',
                    'quote_author_unknown' => 'Unknown',
                    'refresh_quote' => 'Refresh Quote',
                    'new_arrivals' => 'New Arrivals',
                    'popular_ebooks' => 'Popular eBooks',
                    'latest_ebooks' => 'Latest eBooks',
                    'download' => 'Download',
                    'view_details' => 'View Details',
                    'book_details' => 'Book Details',
                    'author' => 'Author',
                    'publisher' => 'Publisher',
                    'isbn' => 'ISBN',
                    'year' => 'Year',
                    'category' => 'Category',
                    'item_category' => 'Item Category',
                    'book_status' => 'Book Status',
                    'price' => 'Price',
                    'availability' => 'Availability',
                    'available_copies' => 'copies available',
                    'not_available' => 'Not Available',
                    'summary' => 'Summary',
                    'no_summary' => 'No summary available.',
                    'suggest_book' => 'Suggest / Inform',
                    'your_admission_number' => 'Your Admission/Member Number *',
                    'your_full_name' => 'Your Full Name *',
                    'book_title' => 'Book Title *',
                    'author_optional' => 'Author',
                    'isbn_optional' => 'ISBN (if known)',
                    'reason_for_suggestion' => 'Reason for Suggestion *',
                    'why_recommend' => 'Why do you recommend this book?',
                    'suggestion_info' => 'Your suggestion will be reviewed by library staff.',
                    'submit' => 'Submit',
                    'close' => 'Close',
                    'scan_barcode' => 'Scan barcode here...',
                    'processing' => 'Processing...',
                    'network_error' => 'Network error. Please try again.',
                    'enter_valid_id' => 'Please enter a valid search term',
                    'entry_recorded' => 'ENTRY recorded',
                    'exit_recorded' => 'EXIT recorded',
                    'visitors_today' => 'Visitors Today',
                    'currently_inside' => 'Currently Inside',
                    'male_female_inside' => 'Male / Female (inside)',
                    'inside_by_category' => 'Inside by Category',
                    'none' => 'None',
                    'back_to_home' => 'Back to Home',
                    'library_announcements' => 'Library Announcements',
                    'posted' => 'Posted',
                    'library_notice' => 'Library Notice',
                    'designed_by' => 'Designed by',
                    'all_rights_reserved' => 'All rights reserved.',
                    'library_hours' => 'Library Hours',
                    'open_days' => 'Open Days',
                    'hours' => 'Hours',
                    'lunch_break' => 'Lunch Break',
                    'currently_closed' => 'The library is currently closed.',
                    'quick_links' => 'Quick Links',
                    'contact_us' => 'Contact Us',
                    'unknown_author' => 'Unknown Author',
                    'access_database' => 'Access Database',
                    'visit_website' => 'Visit Website',
                    'resource_type' => 'Resource Type',
                    'search_databases' => 'Search Databases',
                    'browse_databases' => 'Browse our research databases',
                    'database_search_placeholder' => 'Search by database name or subject...',
                    'all_database_types' => 'All Database Types',
                    'academic_databases' => 'Academic Databases',
                    'open_access' => 'Open Access',
                    'subscription_based' => 'Subscription Based',
                    'no_databases_found' => 'No databases found',
                    'total_books' => 'Total Books',
                    'total_ebooks' => 'Total eBooks',
                    'total_databases' => 'Research Databases',
                    'total_members' => 'Registered Members',
                    'book_of_the_day' => 'Book of the Day',
                    'library_stats' => 'Library Stats',
                    'place_hold' => 'Place Hold',
                    'hold_placed' => 'Hold placed successfully. You will be notified when available.',
                    'hold_error' => 'Could not place hold. Please try again.',
                    'already_on_hold' => 'You already have a hold on this book.',
                    'recommended_for_you' => 'Recommended for You',
                    'current_loans' => 'Current Loans',
                    'due_date' => 'Due Date',
                    'fine_total' => 'Total Fines',
                    'my_loans' => 'My Loans',
                    'my_holds' => 'My Holds',
                    'my_fines' => 'My Fines',
                    'cancel_hold' => 'Cancel Hold',
                    'no_loans' => 'No active loans',
                    'no_holds' => 'No active holds',
                    'view_all' => 'View All',
                    'account_summary' => 'Account Summary',
                    'loan_count' => 'Active Loans',
                    'hold_count' => 'Pending Holds',
                    'overdue_fines' => 'Overdue Fines',
                    'loading' => 'Loading...',
                    'error_loading' => 'Error loading data',
                    'switch_to_arabic' => 'العربية',
                    'switch_to_english' => 'English',
                    'switch_to_hindi' => 'हिन्दी',
                ],
                'hi' => [
                    'library' => 'पुस्तकालय',
                    'dashboard' => 'डैशबोर्ड',
                    'members' => 'सदस्य',
                    'books' => 'पुस्तकें',
                    'circulation' => 'सर्कुलेशन',
                    'reports' => 'रिपोर्ट',
                    'settings' => 'सेटिंग्स',
                    'logout' => 'लॉगआउट',
                    'login' => 'लॉगिन',
                    'search' => 'खोज',
                    'add' => 'जोड़ें',
                    'edit' => 'संपादित करें',
                    'delete' => 'हटाएं',
                    'save' => 'सहेजें',
                    'cancel' => 'रद्द करें',
                    'back' => 'पीछे',
                    'home' => 'होम',
                    'issue_book' => 'पुस्तक जारी करें',
                    'return_book' => 'पुस्तक वापस करें',
                    'renew' => 'नवीनीकरण',
                    'overdue' => 'अतिदेय',
                    'fine' => 'जुर्माना',
                    'total' => 'कुल',
                    'available' => 'उपलब्ध',
                    'issued' => 'जारी',
                    'whom' => 'किसे',
                    'my_account' => 'मेरा खाता',
                    'pay_fines' => 'जुर्माना भुगतान करें',
                    'advanced_search' => 'उन्नत खोज',
                    'semantic_search' => 'सिमेंटिक खोज (AI)',
                    'thought_of_the_day' => 'दिन का विचार',
                    'quote_author_unknown' => 'अज्ञात',
                    'refresh_quote' => 'उद्धरण ताज़ा करें',
                    'new_arrivals' => 'नई आगमन',
                    'popular_ebooks' => 'लोकप्रिय ई-पुस्तकें',
                    'latest_ebooks' => 'नवीनतम ई-पुस्तकें',
                    'download' => 'डाउनलोड',
                    'view_details' => 'विवरण देखें',
                    'book_details' => 'पुस्तक विवरण',
                    'author' => 'लेखक',
                    'publisher' => 'प्रकाशक',
                    'isbn' => 'ISBN',
                    'year' => 'वर्ष',
                    'category' => 'श्रेणी',
                    'item_category' => 'वस्तु श्रेणी',
                    'book_status' => 'पुस्तक स्थिति',
                    'price' => 'मूल्य',
                    'availability' => 'उपलब्धता',
                    'available_copies' => 'प्रतियाँ उपलब्ध',
                    'not_available' => 'उपलब्ध नहीं',
                    'summary' => 'सारांश',
                    'no_summary' => 'कोई सारांश उपलब्ध नहीं',
                    'suggest_book' => 'सुझाव / जानकारी',
                    'your_admission_number' => 'आपका नामांकन/सदस्य संख्या *',
                    'your_full_name' => 'आपका पूरा नाम *',
                    'book_title' => 'पुस्तक का शीर्षक *',
                    'author_optional' => 'लेखक',
                    'isbn_optional' => 'ISBN (यदि ज्ञात हो)',
                    'reason_for_suggestion' => 'सुझाव का कारण *',
                    'why_recommend' => 'आप इस पुस्तक की सिफारिश क्यों करते हैं?',
                    'suggestion_info' => 'आपका सुझाव पुस्तकालय कर्मचारियों द्वारा समीक्षा किया जाएगा।',
                    'submit' => 'जमा करें',
                    'close' => 'बंद करें',
                    'scan_barcode' => 'बारकोड स्कैन करें...',
                    'processing' => 'प्रक्रिया हो रही है...',
                    'network_error' => 'नेटवर्क त्रुटि। कृपया पुनः प्रयास करें।',
                    'enter_valid_id' => 'कृपया एक मान्य खोज शब्द दर्ज करें',
                    'entry_recorded' => 'प्रवेश दर्ज किया गया',
                    'exit_recorded' => 'निकास दर्ज किया गया',
                    'visitors_today' => 'आज के आगंतुक',
                    'currently_inside' => 'वर्तमान में अंदर',
                    'male_female_inside' => 'पुरुष / महिला (अंदर)',
                    'inside_by_category' => 'श्रेणी के अनुसार अंदर',
                    'none' => 'कोई नहीं',
                    'back_to_home' => 'होम पर वापस जाएं',
                    'library_announcements' => 'पुस्तकालय घोषणाएँ',
                    'posted' => 'पोस्ट किया गया',
                    'library_notice' => 'पुस्तकालय सूचना',
                    'designed_by' => 'द्वारा डिज़ाइन किया गया',
                    'all_rights_reserved' => 'सर्वाधिकार सुरक्षित।',
                    'library_hours' => 'पुस्तकालय समय',
                    'open_days' => 'खुले दिन',
                    'hours' => 'समय',
                    'lunch_break' => 'दोपहर का भोजन अवकाश',
                    'currently_closed' => 'पुस्तकालय वर्तमान में बंद है।',
                    'quick_links' => 'त्वरित लिंक',
                    'contact_us' => 'संपर्क करें',
                    'unknown_author' => 'अज्ञात लेखक',
                    'access_database' => 'डेटाबेस तक पहुँचें',
                    'visit_website' => 'वेबसाइट देखें',
                    'resource_type' => 'संसाधन प्रकार',
                    'search_databases' => 'डेटाबेस खोजें',
                    'browse_databases' => 'हमारे शोध डेटाबेस ब्राउज़ करें',
                    'database_search_placeholder' => 'डेटाबेस नाम या विषय से खोजें...',
                    'all_database_types' => 'सभी डेटाबेस प्रकार',
                    'academic_databases' => 'शैक्षणिक डेटाबेस',
                    'open_access' => 'मुफ्त पहुँच',
                    'subscription_based' => 'सदस्यता आधारित',
                    'no_databases_found' => 'कोई डेटाबेस नहीं मिला',
                    'total_books' => 'कुल पुस्तकें',
                    'total_ebooks' => 'कुल ई-पुस्तकें',
                    'total_databases' => 'शोध डेटाबेस',
                    'total_members' => 'पंजीकृत सदस्य',
                    'book_of_the_day' => 'दिन की पुस्तक',
                    'library_stats' => 'पुस्तकालय आँकड़े',
                    'place_hold' => 'होल्ड करें',
                    'hold_placed' => 'होल्ड सफलतापूर्वक लगाया गया। उपलब्ध होने पर आपको सूचित किया जाएगा।',
                    'hold_error' => 'होल्ड नहीं लगा पाए। कृपया पुनः प्रयास करें।',
                    'already_on_hold' => 'आपने इस पुस्तक पर पहले से होल्ड लगाया है।',
                    'recommended_for_you' => 'आपके लिए अनुशंसित',
                    'current_loans' => 'वर्तमान ऋण',
                    'due_date' => 'देय तिथि',
                    'fine_total' => 'कुल जुर्माना',
                    'my_loans' => 'मेरे ऋण',
                    'my_holds' => 'मेरे होल्ड',
                    'my_fines' => 'मेरा जुर्माना',
                    'cancel_hold' => 'होल्ड रद्द करें',
                    'no_loans' => 'कोई सक्रिय ऋण नहीं',
                    'no_holds' => 'कोई सक्रिय होल्ड नहीं',
                    'view_all' => 'सभी देखें',
                    'account_summary' => 'खाता सारांश',
                    'loan_count' => 'सक्रिय ऋण',
                    'hold_count' => 'लंबित होल्ड',
                    'overdue_fines' => 'अतिदेय जुर्माना',
                    'loading' => 'लोड हो रहा है...',
                    'error_loading' => 'डेटा लोड करने में त्रुटि',
                    'switch_to_arabic' => 'العربية',
                    'switch_to_english' => 'English',
                    'switch_to_hindi' => 'हिन्दी',
                ],
                'ar' => [
                    'library' => 'المكتبة',
                    'dashboard' => 'لوحة التحكم',
                    'members' => 'الأعضاء',
                    'books' => 'الكتب',
                    'circulation' => 'التداول',
                    'reports' => 'التقارير',
                    'settings' => 'الإعدادات',
                    'logout' => 'تسجيل خروج',
                    'login' => 'تسجيل دخول',
                    'search' => 'بحث',
                    'add' => 'إضافة',
                    'edit' => 'تحرير',
                    'delete' => 'حذف',
                    'save' => 'حفظ',
                    'cancel' => 'إلغاء',
                    'back' => 'رجوع',
                    'home' => 'الرئيسية',
                    'issue_book' => 'إعارة كتاب',
                    'return_book' => 'إرجاع كتاب',
                    'renew' => 'تجديد',
                    'overdue' => 'متأخر',
                    'fine' => 'غرامة',
                    'total' => 'الإجمالي',
                    'available' => 'متاح',
                    'issued' => 'مستعار',
                    'whom' => 'لمن',
                    'my_account' => 'حسابي',
                    'pay_fines' => 'دفع الغرامات',
                    'advanced_search' => 'بحث متقدم',
                    'semantic_search' => 'البحث الدلالي (AI)',
                    'thought_of_the_day' => 'فكرة اليوم',
                    'quote_author_unknown' => 'غير معروف',
                    'refresh_quote' => 'تحديث الاقتباس',
                    'new_arrivals' => 'الوافدون الجدد',
                    'popular_ebooks' => 'الكتب الإلكترونية الأكثر شعبية',
                    'latest_ebooks' => 'أحدث الكتب الإلكترونية',
                    'download' => 'تحميل',
                    'view_details' => 'عرض التفاصيل',
                    'book_details' => 'تفاصيل الكتاب',
                    'author' => 'المؤلف',
                    'publisher' => 'الناشر',
                    'isbn' => 'ISBN',
                    'year' => 'السنة',
                    'category' => 'الفئة',
                    'item_category' => 'فئة المادة',
                    'book_status' => 'حالة الكتاب',
                    'price' => 'السعر',
                    'availability' => 'التوفر',
                    'available_copies' => 'نسخ متاحة',
                    'not_available' => 'غير متوفر',
                    'summary' => 'الملخص',
                    'no_summary' => 'لا يوجد ملخص متاح.',
                    'suggest_book' => 'اقتراح / إبلاغ',
                    'your_admission_number' => 'رقم قبولك/عضويتك *',
                    'your_full_name' => 'اسمك الكامل *',
                    'book_title' => 'عنوان الكتاب *',
                    'author_optional' => 'المؤلف',
                    'isbn_optional' => 'ISBN (إن وجد)',
                    'reason_for_suggestion' => 'سبب الاقتراح *',
                    'why_recommend' => 'لماذا توصي بهذا الكتاب؟',
                    'suggestion_info' => 'سيتم مراجعة اقتراحك من قبل موظفي المكتبة.',
                    'submit' => 'إرسال',
                    'close' => 'إغلاق',
                    'scan_barcode' => 'امسح الباركود هنا...',
                    'processing' => 'جاري المعالجة...',
                    'network_error' => 'خطأ في الشبكة. يرجى المحاولة مرة أخرى.',
                    'enter_valid_id' => 'يرجى إدخال مصطلح بحث صحيح',
                    'entry_recorded' => 'تم تسجيل الدخول',
                    'exit_recorded' => 'تم تسجيل الخروج',
                    'visitors_today' => 'زوار اليوم',
                    'currently_inside' => 'المتواجدون حالياً',
                    'male_female_inside' => 'ذكر / أنثى (داخل)',
                    'inside_by_category' => 'الداخلون حسب الفئة',
                    'none' => 'لا شيء',
                    'back_to_home' => 'العودة إلى الرئيسية',
                    'library_announcements' => 'إعلانات المكتبة',
                    'posted' => 'نشر',
                    'library_notice' => 'إشعار المكتبة',
                    'designed_by' => 'صمم بواسطة',
                    'all_rights_reserved' => 'جميع الحقوق محفوظة.',
                    'library_hours' => 'ساعات المكتبة',
                    'open_days' => 'أيام العمل',
                    'hours' => 'الساعات',
                    'lunch_break' => 'استراحة الغداء',
                    'currently_closed' => 'المكتبة مغلقة حالياً.',
                    'quick_links' => 'روابط سريعة',
                    'contact_us' => 'اتصل بنا',
                    'unknown_author' => 'مؤلف غير معروف',
                    'access_database' => 'الوصول إلى قاعدة البيانات',
                    'visit_website' => 'زيارة الموقع',
                    'resource_type' => 'نوع المصدر',
                    'search_databases' => 'البحث في قواعد البيانات',
                    'browse_databases' => 'تصفح قواعد البيانات البحثية لدينا',
                    'database_search_placeholder' => 'ابحث باسم قاعدة البيانات أو الموضوع...',
                    'all_database_types' => 'جميع أنواع قواعد البيانات',
                    'academic_databases' => 'قواعد بيانات أكاديمية',
                    'open_access' => 'وصول مفتوح',
                    'subscription_based' => 'قائم على الاشتراك',
                    'no_databases_found' => 'لم يتم العثور على قواعد بيانات',
                    'total_books' => 'إجمالي الكتب',
                    'total_ebooks' => 'إجمالي الكتب الإلكترونية',
                    'total_databases' => 'قواعد البيانات البحثية',
                    'total_members' => 'الأعضاء المسجلون',
                    'book_of_the_day' => 'كتاب اليوم',
                    'library_stats' => 'إحصائيات المكتبة',
                    'place_hold' => 'وضع حجز',
                    'hold_placed' => 'تم وضع الحجز بنجاح. سيتم إبلاغك عند التوفر.',
                    'hold_error' => 'تعذر وضع الحجز. يرجى المحاولة مرة أخرى.',
                    'already_on_hold' => 'لديك بالفعل حجز على هذا الكتاب.',
                    'recommended_for_you' => 'موصى به لك',
                    'current_loans' => 'القروض الحالية',
                    'due_date' => 'تاريخ الاستحقاق',
                    'fine_total' => 'إجمالي الغرامات',
                    'my_loans' => 'قروضي',
                    'my_holds' => 'حجوزاتي',
                    'my_fines' => 'غراماتي',
                    'cancel_hold' => 'إلغاء الحجز',
                    'no_loans' => 'لا توجد قروض نشطة',
                    'no_holds' => 'لا توجد حجوزات نشطة',
                    'view_all' => 'عرض الكل',
                    'account_summary' => 'ملخص الحساب',
                    'loan_count' => 'القروض النشطة',
                    'hold_count' => 'الحجوزات المعلقة',
                    'overdue_fines' => 'الغرامات المتأخرة',
                    'loading' => 'جاري التحميل...',
                    'error_loading' => 'خطأ في تحميل البيانات',
                    'switch_to_arabic' => 'العربية',
                    'switch_to_english' => 'English',
                    'switch_to_hindi' => 'हिन्दी',
                ]
            ];
        }

        $lang = $lang ?? ($_SESSION['lang'] ?? 'en');
        return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
    }
}

// ============================================================================
// REDIS / CACHE HELPERS (with file fallback)
// ============================================================================

if (!function_exists('getRedis')) {
    function getRedis(): ?Redis {
        static $redis = null;
        if ($redis === null) {
            $redisPath = __DIR__ . '/redis.php';
            if (file_exists($redisPath)) {
                $redis = require $redisPath;
                if ($redis instanceof Redis) {
                    return $redis;
                }
            }
            $redis = false;
        }
        return $redis ?: null;
    }
}

if (!function_exists('cacheGet')) {
    function cacheGet(string $key) {
        $redis = getRedis();
        if ($redis) {
            $value = $redis->get($key);
            if ($value !== false) return json_decode($value, true);
        }
        // File fallback
        $cacheFile = CACHE_DIR . md5($key) . '.cache';
        if (file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true);
            if ($data && $data['expires'] > time()) {
                return $data['value'];
            }
        }
        return null;
    }
}

if (!function_exists('cacheSet')) {
    function cacheSet(string $key, $value, int $ttl = 300): bool {
        $redis = getRedis();
        if ($redis) {
            return $redis->setex($key, $ttl, json_encode($value));
        }
        $cacheFile = CACHE_DIR . md5($key) . '.cache';
        $data = ['expires' => time() + $ttl, 'value' => $value];
        return file_put_contents($cacheFile, json_encode($data)) !== false;
    }
}

if (!function_exists('cacheDelete')) {
    function cacheDelete(string $key): bool {
        $redis = getRedis();
        if ($redis) {
            return $redis->del($key) > 0;
        }
        $cacheFile = CACHE_DIR . md5($key) . '.cache';
        if (file_exists($cacheFile)) {
            return unlink($cacheFile);
        }
        return true;
    }
}

if (!function_exists('cacheClear')) {
    function cacheClear(): bool {
        $redis = getRedis();
        if ($redis) {
            return $redis->flushDB();
        }
        $files = glob(CACHE_DIR . '*.cache');
        foreach ($files as $file) {
            unlink($file);
        }
        return true;
    }
}

if (!function_exists('cacheQuery')) {
    function cacheQuery(string $key, callable $callback, int $ttl = 300) {
        static $memoryCache = [];
        if (isset($memoryCache[$key]) && $memoryCache[$key]['expires'] > time()) {
            return $memoryCache[$key]['data'];
        }
        $cached = cacheGet($key);
        if ($cached !== null) {
            $memoryCache[$key] = ['data' => $cached, 'expires' => time() + $ttl];
            return $cached;
        }
        $data = $callback();
        cacheSet($key, $data, $ttl);
        $memoryCache[$key] = ['data' => $data, 'expires' => time() + $ttl];
        return $data;
    }
}

// ============================================================================
// POLYFILLS
// ============================================================================

if (!function_exists('getallheaders')) {
    function getallheaders(): array {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (str_starts_with($name, 'HTTP_')) {
                $key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
                $headers[$key] = $value;
            }
        }
        return $headers;
    }
}

if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) === 0;
    }
}

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

// ============================================================================
// MEMBER CATEGORY DEFINITIONS
// ============================================================================

if (!function_exists('getMemberCategories')) {
    function getMemberCategories(): array {
        return [
            'Students' => [
                'label' => 'Students',
                'sub_categories' => [
                    'early_years'   => 'Early Years (Pre-K to Grade 1)',
                    'elementary'    => 'Elementary (Grades 2-5)',
                    'middle'        => 'Middle School (Grades 6-8)',
                    'secondary'     => 'Secondary School (Grades 9-12)',
                    'diploma'       => 'Diploma',
                    'graduate'      => 'Graduate',
                    'post_graduate' => 'Post Graduate',
                    'research'      => 'Research Scholar'
                ]
            ],
            'Staff' => [
                'label' => 'Staff',
                'sub_categories' => [
                    'teaching'     => 'Teaching Staff',
                    'non_teaching' => 'Non-Teaching Staff',
                    'management'   => 'Management Level'
                ]
            ]
        ];
    }
}

if (!function_exists('getAllMemberCategories')) {
    function getAllMemberCategories(): array {
        return [
            'early_years'   => 'Early Years (Pre-K to Grade 1)',
            'elementary'    => 'Elementary (Grades 2-5)',
            'middle'        => 'Middle School (Grades 6-8)',
            'secondary'     => 'Secondary School (Grades 9-12)',
            'diploma'       => 'Diploma',
            'graduate'      => 'Graduate',
            'post_graduate' => 'Post Graduate',
            'research'      => 'Research Scholar',
            'teaching'      => 'Teaching Staff',
            'non_teaching'  => 'Non-Teaching Staff',
            'management'    => 'Management Level'
        ];
    }
}

if (!function_exists('getMemberCategoryGroup')) {
    function getMemberCategoryGroup(string $category): string {
        $studentCategories = ['early_years', 'elementary', 'middle', 'secondary', 'diploma', 'graduate', 'post_graduate', 'research'];
        return in_array($category, $studentCategories) ? 'Students' : 'Staff';
    }
}

if (!function_exists('getCategoryLabel')) {
    function getCategoryLabel(string $categoryKey): string {
        $categories = getAllMemberCategories();
        return $categories[$categoryKey] ?? ucwords(str_replace('_', ' ', $categoryKey));
    }
}

// ============================================================================
// CIRCULATION RULES
// ============================================================================

if (!function_exists('getDefaultCirculationRules')) {
    function getDefaultCirculationRules(): array {
        return [
            'early_years'   => ['max_books' => 2, 'loan_days' => 7,  'max_renewals' => 1, 'fine_per_day' => 1,   'max_fine_amount' => 10],
            'elementary'    => ['max_books' => 3, 'loan_days' => 10, 'max_renewals' => 1, 'fine_per_day' => 1,   'max_fine_amount' => 15],
            'middle'        => ['max_books' => 4, 'loan_days' => 14, 'max_renewals' => 2, 'fine_per_day' => 1.5, 'max_fine_amount' => 20],
            'secondary'     => ['max_books' => 5, 'loan_days' => 14, 'max_renewals' => 2, 'fine_per_day' => 1.5, 'max_fine_amount' => 25],
            'diploma'       => ['max_books' => 6, 'loan_days' => 21, 'max_renewals' => 2, 'fine_per_day' => 2,   'max_fine_amount' => 30],
            'graduate'      => ['max_books' => 8, 'loan_days' => 30, 'max_renewals' => 3, 'fine_per_day' => 2,   'max_fine_amount' => 50],
            'post_graduate' => ['max_books' => 10, 'loan_days' => 30, 'max_renewals' => 3, 'fine_per_day' => 2.5, 'max_fine_amount' => 60],
            'research'      => ['max_books' => 15, 'loan_days' => 45, 'max_renewals' => 4, 'fine_per_day' => 2.5, 'max_fine_amount' => 80],
            'teaching'      => ['max_books' => 20, 'loan_days' => 60, 'max_renewals' => 5, 'fine_per_day' => 1,   'max_fine_amount' => 100],
            'non_teaching'  => ['max_books' => 8,  'loan_days' => 30, 'max_renewals' => 2, 'fine_per_day' => 2,   'max_fine_amount' => 40],
            'management'    => ['max_books' => 15, 'loan_days' => 45, 'max_renewals' => 3, 'fine_per_day' => 2,   'max_fine_amount' => 75]
        ];
    }
}

if (!function_exists('getCirculationRules')) {
    function getCirculationRules(): array {
        static $rules = null;
        if ($rules !== null) return $rules;

        $cached = cacheGet('circulation_rules');
        if ($cached !== null) {
            $rules = $cached;
            return $rules;
        }

        $settings = getSettings();
        if (!empty($settings['circulation_rules'])) {
            $rules = json_decode($settings['circulation_rules'], true);
            if (is_array($rules) && !empty($rules)) {
                cacheSet('circulation_rules', $rules, 3600);
                return $rules;
            }
        }
        $rules = getDefaultCirculationRules();
        cacheSet('circulation_rules', $rules, 3600);
        return $rules;
    }
}

if (!function_exists('getCategoryCirculationRules')) {
    function getCategoryCirculationRules(string $category): array {
        $rules = getCirculationRules();
        $defaults = getDefaultCirculationRules();
        if (isset($rules[$category]) && is_array($rules[$category])) {
            return $rules[$category];
        }
        return $defaults[$category] ?? $defaults['elementary'];
    }
}

if (!function_exists('getMemberMaxBooks')) {
    function getMemberMaxBooks(string $memberCategory): int {
        $rules = getCategoryCirculationRules($memberCategory);
        return (int)($rules['max_books'] ?? 5);
    }
}

if (!function_exists('getMemberLoanDays')) {
    function getMemberLoanDays(string $memberCategory): int {
        $rules = getCategoryCirculationRules($memberCategory);
        return (int)($rules['loan_days'] ?? 7);
    }
}

if (!function_exists('getMemberMaxRenewals')) {
    function getMemberMaxRenewals(string $memberCategory): int {
        $rules = getCategoryCirculationRules($memberCategory);
        return (int)($rules['max_renewals'] ?? 0);
    }
}

if (!function_exists('getMemberFinePerDay')) {
    function getMemberFinePerDay(string $memberCategory): float {
        $rules = getCategoryCirculationRules($memberCategory);
        return (float)($rules['fine_per_day'] ?? 2);
    }
}

if (!function_exists('getMemberMaxFineAmount')) {
    function getMemberMaxFineAmount(string $memberCategory): float {
        $rules = getCategoryCirculationRules($memberCategory);
        return (float)($rules['max_fine_amount'] ?? 0);
    }
}

// ============================================================================
// SETTINGS & INSTITUTION
// ============================================================================

if (!function_exists('getSettings')) {
    function getSettings(): array {
        static $settings = null;
        if ($settings !== null) return $settings;

        $cached = cacheGet('system_settings');
        if ($cached !== null) {
            $settings = $cached;
            return $settings;
        }

        $db = getDB();
        $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
        $settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
        // Ensure all required keys exist with defaults
        $defaults = [
            'loan_days' => 7, 'fine_per_day' => 2, 'max_books' => 5,
            'menu_position' => 'top', 'software_header' => 'Library ERP System',
            'library_logo' => '', 'favicon_path' => '', 'backup_email' => '',
            'notify_overdue' => 1, 'auto_logout_minutes' => 30,
            'new_arrivals_count' => 10, 'enable_sms' => 0, 'sms_api_key' => '',
            'enable_email' => 1, 'opac_enabled' => 1,
            'allow_holds' => 1, 'hold_days' => 7,
            'enable_webcam_capture' => 0,
            // ... more defaults as needed
        ];
        foreach ($defaults as $key => $val) {
            if (!array_key_exists($key, $settings)) {
                $settings[$key] = $val;
            }
        }
        cacheSet('system_settings', $settings, 3600);
        return $settings;
    }
}

if (!function_exists('getInstitution')) {
    function getInstitution(): array {
        static $institution = null;
        if ($institution !== null) return $institution;

        $cached = cacheGet('current_institution');
        if ($cached !== null) {
            $institution = $cached;
            return $institution;
        }

        $db = getDB();
        $settings = getSettings();
        $currentId = (int)($settings['current_institution_id'] ?? 1);
        $stmt = $db->prepare("SELECT * FROM institutions WHERE id = ? AND status = 'active'");
        $stmt->execute([$currentId]);
        $institution = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$institution) {
            $institution = ['name' => 'Library', 'address' => '', 'logo_path' => ''];
        }
        cacheSet('current_institution', $institution, 3600);
        return $institution;
    }
}

// ============================================================================
// IMAGE HELPERS (enhanced)
// ============================================================================

if (!function_exists('getCoverBase64')) {
    function getCoverBase64(?string $path): string {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $absPath = str_starts_with($path, '/') ? $path : BASE_PATH . '/' . ltrim($path, '/');
        if (!file_exists($absPath)) return '';
        $ext = strtolower(pathinfo($absPath, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (!in_array($ext, $allowed)) return '';
        $data = @file_get_contents($absPath);
        if ($data === false) return '';
        return 'data:image/' . $ext . ';base64,' . base64_encode($data);
    }
}

if (!function_exists('getWebImageUrlOrBase64')) {
    function getWebImageUrlOrBase64(?string $path): string {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $absPath = BASE_PATH . '/' . ltrim($path, '/');
        if (file_exists($absPath)) {
            $ext = strtolower(pathinfo($absPath, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $data = @file_get_contents($absPath);
                if ($data !== false) {
                    return 'data:image/' . $ext . ';base64,' . base64_encode($data);
                }
            }
            $webPath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $absPath);
            if ($webPath) return $webPath;
        }
        return getWebImageUrl($path);
    }
}

if (!function_exists('getWebImageUrl')) {
    function getWebImageUrl(?string $path): string {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $path = ltrim($path, '/\\');
        $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://')
                   . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/';
        return $baseUrl . $path;
    }
}

if (!function_exists('makeWebPath')) {
    function makeWebPath(?string $path): string {
        if (empty($path)) return '';
        if (preg_match('#^https?://#', $path)) return $path;
        $path = str_replace('\\', '/', $path);
        if (preg_match('#/uploads/.*#', $path, $matches)) return ltrim($matches[0], '/');
        return '';
    }
}

if (!function_exists('getMemberPhotoUrl')) {
    function getMemberPhotoUrl(?string $photoPath): string {
        return getCoverBase64($photoPath);
    }
}

// ============================================================================
// IMAGE RESIZE & GD HELPERS
// ============================================================================

if (!function_exists('isGdAvailable')) {
    function isGdAvailable(): bool {
        return extension_loaded('gd') && function_exists('gd_info');
    }
}

if (!function_exists('autoResizeImage')) {
    function autoResizeImage(string $sourcePath, string $targetPath, int $maxWidth, int $maxHeight, int $quality = 80): bool {
        if (!isGdAvailable()) return copy($sourcePath, $targetPath);
        if (!file_exists($sourcePath)) return false;

        $imageInfo = @getimagesize($sourcePath);
        if (!$imageInfo) return false;
        [$origWidth, $origHeight, $type] = $imageInfo;

        if ($origWidth <= $maxWidth && $origHeight <= $maxHeight) {
            return copy($sourcePath, $targetPath);
        }

        $ratio = min($maxWidth / $origWidth, $maxHeight / $origHeight);
        $newWidth  = max(1, (int)round($origWidth * $ratio));
        $newHeight = max(1, (int)round($origHeight * $ratio));

        $src = null;
        switch ($type) {
            case IMAGETYPE_JPEG: if (function_exists('imagecreatefromjpeg')) $src = @imagecreatefromjpeg($sourcePath); break;
            case IMAGETYPE_PNG:  if (function_exists('imagecreatefrompng'))  $src = @imagecreatefrompng($sourcePath);  break;
            case IMAGETYPE_GIF:  if (function_exists('imagecreatefromgif'))  $src = @imagecreatefromgif($sourcePath);  break;
            case IMAGETYPE_WEBP: if (function_exists('imagecreatefromwebp')) $src = @imagecreatefromwebp($sourcePath); break;
            default: return copy($sourcePath, $targetPath);
        }
        if (!$src) return copy($sourcePath, $targetPath);

        $dst = imagecreatetruecolor($newWidth, $newHeight);
        if ($type == IMAGETYPE_PNG) {
            imagealphablending($dst, false);
            imagesavealpha($dst, true);
            $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
            imagefilledrectangle($dst, 0, 0, $newWidth, $newHeight, $transparent);
        }
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);

        $result = false;
        switch ($type) {
            case IMAGETYPE_JPEG: if (function_exists('imagejpeg')) $result = imagejpeg($dst, $targetPath, $quality); break;
            case IMAGETYPE_PNG:  if (function_exists('imagepng'))  $result = imagepng($dst, $targetPath, 9); break;
            case IMAGETYPE_GIF:  if (function_exists('imagegif'))  $result = imagegif($dst, $targetPath); break;
            case IMAGETYPE_WEBP: if (function_exists('imagewebp')) $result = imagewebp($dst, $targetPath, $quality); break;
        }
        imagedestroy($src);
        imagedestroy($dst);
        return $result ?: copy($sourcePath, $targetPath);
    }
}

// ============================================================================
// DISPLAY HELPERS
// ============================================================================

if (!function_exists('displayMemberPhoto')) {
    function displayMemberPhoto(?string $photoPath, int $size = 50): string {
        $imageUrl = getWebImageUrl($photoPath);
        if (!empty($imageUrl)) {
            $src = (str_starts_with($imageUrl, '/')) ? $imageUrl : '/' . $imageUrl;
            return '<img src="' . $src . '" class="member-photo" style="width: ' . $size . 'px; height: ' . $size . 'px; object-fit: cover; border-radius: 50%;" onerror="this.onerror=null; this.style.display=\'none\'; this.parentElement.querySelector(\'.default-avatar\').style.display=\'flex\';">';
        }
        return '<div class="default-avatar" style="width: ' . $size . 'px; height: ' . $size . 'px; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 50%; color: white;"><i class="fas fa-user fa-' . ($size > 40 ? '2x' : '1x') . '"></i></div>';
    }
}

if (!function_exists('displayBookCover')) {
    function displayBookCover(?string $coverPath, int $width = 50, int $height = 65): string {
        $imageUrl = getWebImageUrl($coverPath);
        if (!empty($imageUrl)) {
            $src = (str_starts_with($imageUrl, '/')) ? $imageUrl : '/' . $imageUrl;
            return '<img src="' . $src . '" class="book-cover-preview" style="width: ' . $width . 'px; height: ' . $height . 'px; object-fit: cover; border-radius: 4px;" onerror="this.onerror=null; this.style.display=\'none\'; this.parentElement.querySelector(\'.default-book-icon\').style.display=\'flex\';">';
        }
        return '<div class="default-book-icon" style="width: ' . $width . 'px; height: ' . $height . 'px; background: #f8f9fa; border-radius: 4px; display: flex; align-items: center; justify-content: center;"><i class="fas fa-book fa-2x text-muted"></i></div>';
    }
}

if (!function_exists('displayLibraryLogo')) {
    function displayLibraryLogo(?string $logoPath, int $height = 40): string {
        $imageUrl = getWebImageUrl($logoPath);
        if (!empty($imageUrl)) {
            $src = (str_starts_with($imageUrl, '/')) ? $imageUrl : '/' . $imageUrl;
            return '<img src="' . $src . '" class="logo-img" style="height: ' . $height . 'px; max-width: 150px; object-fit: contain;" onerror="this.style.display=\'none\'">';
        }
        return '';
    }
}

// ============================================================================
// DATE/TIME HELPERS
// ============================================================================

if (!function_exists('formatDate')) {
    function formatDate(?string $date, string $format = 'd/m/Y'): string {
        if (empty($date)) return '';
        try {
            return (new DateTime($date))->format($format);
        } catch (Exception $e) {
            return $date;
        }
    }
}

if (!function_exists('formatTime')) {
    function formatTime(?string $time, string $format = 'H:i:s'): string {
        if (empty($time)) return '';
        try {
            return (new DateTime($time))->format($format);
        } catch (Exception $e) {
            return $time;
        }
    }
}

if (!function_exists('formatDuration')) {
    function formatDuration(int $minutes): string {
        if ($minutes < 60) return $minutes . ' min';
        $hours = floor($minutes / 60);
        $mins  = $minutes % 60;
        if ($mins == 0) return $hours . ' hr';
        return $hours . ' hr ' . $mins . ' min';
    }
}

// ============================================================================
// CURRENCY HELPERS
// ============================================================================

if (!function_exists('getCurrencySymbol')) {
    function getCurrencySymbol(?string $code = null): string {
        if ($code === null) {
            $settings = getSettings();
            $code = $settings['currency_code'] ?? 'INR';
        }
        $symbols = [
            'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
            'BHD' => '.د.ب', 'OMR' => '﷼', 'USD' => '$', 'EUR' => '€',
            'GBP' => '£', 'INR' => '₹', 'JPY' => '¥', 'CNY' => '¥',
            'CAD' => '$', 'AUD' => '$', 'CHF' => 'CHF', 'MYR' => 'RM', 'SGD' => '$',
        ];
        return $symbols[$code] ?? $code;
    }
}

if (!function_exists('formatCurrency')) {
    function formatCurrency(float $amount, bool $withSymbol = true): string {
        $settings = getSettings();
        $symbol = getCurrencySymbol();
        $code = $settings['currency_code'] ?? 'USD';
        $position = $settings['currency_position'] ?? 'left';
        $decimals = (int)($settings['currency_decimal_places'] ?? 2);
        $formatted = number_format($amount, $decimals);
        if ($withSymbol) {
            return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . $code;
        }
        return $formatted;
    }
}

// ============================================================================
// FINE CALCULATION (enhanced with loan_rules)
// ============================================================================

if (!function_exists('getFineRateByCategory')) {
    function getFineRateByCategory(string $memberCategory): array {
        static $cache = [];
        if (isset($cache[$memberCategory])) return $cache[$memberCategory];

        $db = getDB();
        $stmt = $db->prepare("SELECT fine_per_day, max_fine, grace_period_days FROM fine_rates WHERE member_category = ? AND is_active = 1");
        $stmt->execute([$memberCategory]);
        $rate = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($rate) {
            $cache[$memberCategory] = $rate;
            return $rate;
        }

        $rules = getCategoryCirculationRules($memberCategory);
        $rate = [
            'fine_per_day'      => (float)($rules['fine_per_day'] ?? 2),
            'max_fine'          => (float)($rules['max_fine_amount'] ?? 0),
            'grace_period_days' => 0
        ];
        $cache[$memberCategory] = $rate;
        return $rate;
    }
}

if (!function_exists('calculateFine')) {
    function calculateFine(string $dueDate, string $memberCategory = 'Student', ?string $returnDate = null, ?string $itemCategory = null): float {
        try {
            $due = new DateTime($dueDate);
            $now = $returnDate ? new DateTime($returnDate) : new DateTime();
            if ($now <= $due) return 0.0;

            // Try advanced loan rules first
            if ($memberCategory && $itemCategory) {
                $rule = getLoanRule($memberCategory, $itemCategory);
                if ($rule) {
                    $finePerDay = (float)($rule['fine_per_day'] ?? 2);
                    $gracePeriod = (int)($rule['grace_period'] ?? 0);
                    $maxFine = (float)($rule['max_fine'] ?? 0);
                } else {
                    $rate = getFineRateByCategory($memberCategory);
                    $finePerDay = $rate['fine_per_day'];
                    $gracePeriod = $rate['grace_period_days'];
                    $maxFine = $rate['max_fine'];
                }
            } else {
                $rate = getFineRateByCategory($memberCategory);
                $finePerDay = $rate['fine_per_day'];
                $gracePeriod = $rate['grace_period_days'];
                $maxFine = $rate['max_fine'];
            }

            $dueWithGrace = clone $due;
            if ($gracePeriod > 0) $dueWithGrace->modify("+{$gracePeriod} days");
            if ($now <= $dueWithGrace) return 0.0;

            $diff = $now->diff($dueWithGrace);
            $days = max(1, (int)$diff->days);
            $fine = $days * $finePerDay;
            if ($maxFine > 0 && $fine > $maxFine) $fine = $maxFine;
            return round($fine, 2);
        } catch (Exception $e) {
            return 0.0;
        }
    }
}

if (!function_exists('getAllFineRates')) {
    function getAllFineRates(): array {
        $db = getDB();
        $stmt = $db->query("SELECT member_category, fine_per_day, max_fine, grace_period_days, is_active FROM fine_rates ORDER BY member_category");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('setFineRate')) {
    function setFineRate(string $memberCategory, float $finePerDay, float $maxFine = 0, int $gracePeriodDays = 0, int $isActive = 1): bool {
        $db = getDB();
        $stmt = $db->prepare("INSERT OR REPLACE INTO fine_rates (member_category, fine_per_day, max_fine, grace_period_days, is_active, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))");
        return $stmt->execute([$memberCategory, $finePerDay, $maxFine, $gracePeriodDays, $isActive]);
    }
}

if (!function_exists('deleteFineRate')) {
    function deleteFineRate(string $memberCategory): bool {
        $db = getDB();
        $stmt = $db->prepare("UPDATE fine_rates SET is_active = 0, updated_at = datetime('now') WHERE member_category = ?");
        return $stmt->execute([$memberCategory]);
    }
}

// ============================================================================
// ISBN & BOOK DATA FETCHING (with cache)
// ============================================================================

if (!function_exists('fetchBookByISBN')) {
    function fetchBookByISBN(string $isbn): array {
        $result = [
            'title' => '', 'author' => '', 'publisher' => '', 'year' => '',
            'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => '',
            'error' => ''
        ];
        if (empty($isbn)) {
            $result['error'] = 'No ISBN provided';
            return $result;
        }
        $isbn = preg_replace('/[^0-9X]/i', '', $isbn);

        // Check cache first
        $cached = cacheGet('isbn_' . $isbn);
        if ($cached) {
            return $cached;
        }

        $context = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);

        $url = "https://openlibrary.org/api/books?bibkeys=ISBN:{$isbn}&format=json&jscmd=data";
        $response = @file_get_contents($url, false, $context);
        if ($response !== false) {
            $data = json_decode($response, true);
            $key = "ISBN:" . $isbn;
            if (isset($data[$key])) {
                $book = $data[$key];
                $result['title']    = $book['title'] ?? '';
                $result['author']   = $book['authors'][0]['name'] ?? '';
                $result['publisher']= $book['publishers'][0]['name'] ?? '';
                $result['year']     = $book['publish_date'] ?? '';
                $result['pages']    = (int)($book['number_of_pages'] ?? 0);
                $result['cover_url']= $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
                $result['category'] = $book['subjects'][0]['name'] ?? '';
                if (isset($book['description'])) {
                    $result['summary'] = is_array($book['description']) ? ($book['description']['value'] ?? '') : $book['description'];
                }
                cacheSet('isbn_' . $isbn, $result, 86400); // cache for 24 hours
                return $result;
            }
        }

        $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:{$isbn}";
        $response = @file_get_contents($url, false, $context);
        if ($response !== false) {
            $data = json_decode($response, true);
            if (isset($data['items'][0]['volumeInfo'])) {
                $info = $data['items'][0]['volumeInfo'];
                $result['title']    = $info['title'] ?? '';
                $result['author']   = $info['authors'][0] ?? '';
                $result['publisher']= $info['publisher'] ?? '';
                $result['year']     = $info['publishedDate'] ?? '';
                $result['pages']    = (int)($info['pageCount'] ?? 0);
                $result['summary']  = $info['description'] ?? '';
                $result['category'] = $info['categories'][0] ?? '';
                $result['cover_url']= $info['imageLinks']['thumbnail'] ?? '';
                cacheSet('isbn_' . $isbn, $result, 86400);
                return $result;
            }
        }

        $result['error'] = 'Book not found in online databases. Check the ISBN or add manually.';
        cacheSet('isbn_' . $isbn, $result, 3600);
        return $result;
    }
}

if (!function_exists('downloadCoverImage')) {
    function downloadCoverImage(string $url, string $barcode): ?string {
        if (empty($url)) return null;
        if (!is_dir(BOOK_COVER_DIR)) mkdir(BOOK_COVER_DIR, 0777, true);

        $filename = 'book_cover_' . $barcode . '_' . time() . '.jpg';
        $filepath = BOOK_COVER_DIR . $filename;

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $imageData = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($httpCode == 200 && $imageData !== false && file_put_contents($filepath, $imageData)) {
                return $filepath;
            }
        }

        $imageData = @file_get_contents($url);
        if ($imageData !== false && file_put_contents($filepath, $imageData)) {
            return $filepath;
        }
        return null;
    }
}

// ============================================================================
// ACTIVITY LOGGING (enhanced with detailed audit)
// ============================================================================

if (!function_exists('logActivity')) {
    function logActivity(string $username, string $action, string $details = ''): void {
        try {
            $db = getDB();
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $action, $details, $ip]);
        } catch (Exception $e) {
            error_log("Activity log failed: " . $e->getMessage());
        }
    }
}

if (!function_exists('logDetailedAudit')) {
    function logDetailedAudit(int $userId, string $action, string $tableName, int $recordId, ?array $oldValues = null, ?array $newValues = null): void {
        $settings = getSettings();
        if (empty($settings['detailed_audit_log'])) return;
        try {
            $db = getDB();
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
            $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $stmt = $db->prepare("INSERT INTO audit_trail_detailed (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $userId,
                $action,
                $tableName,
                $recordId,
                $oldValues ? json_encode($oldValues) : null,
                $newValues ? json_encode($newValues) : null,
                $ip,
                $agent
            ]);
        } catch (Exception $e) {
            error_log("Detailed audit log failed: " . $e->getMessage());
        }
    }
}

// ============================================================================
// SESSION & AUTH HELPERS
// ============================================================================

if (!function_exists('isLoggedIn')) {
    function isLoggedIn(): bool {
        return isset($_SESSION['user_id']);
    }
}
if (!function_exists('isAdmin')) {
    function isAdmin(): bool {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }
}
if (!function_exists('requireLogin')) {
    function requireLogin(): void {
        if (!isLoggedIn()) {
            header('Location: ../index.php?login=1');
            exit;
        }
    }
}
if (!function_exists('requireAdmin')) {
    function requireAdmin(): void {
        requireLogin();
        if (!isAdmin()) {
            die('Access denied. Admin privileges required.');
        }
    }
}
if (!function_exists('isTokenVersionValid')) {
    function isTokenVersionValid(int $userId, int $sessionTokenVersion): bool {
        $db = getDB();
        $stmt = $db->prepare("SELECT token_version FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $current = $stmt->fetchColumn();
        return $current == $sessionTokenVersion;
    }
}
if (!function_exists('updateUserTokenVersion')) {
    function updateUserTokenVersion(int $userId): bool {
        $db = getDB();
        $stmt = $db->prepare("UPDATE users SET token_version = token_version + 1 WHERE id = ?");
        return $stmt->execute([$userId]);
    }
}
if (!function_exists('isTokenValid')) {
    function isTokenValid(?string $tokenExpiry): bool {
        if (empty($tokenExpiry)) return false;
        try {
            $expiry = new DateTime($tokenExpiry);
            $now = new DateTime();
            return $now < $expiry;
        } catch (Exception $e) {
            return false;
        }
    }
}

// CSRF helpers
if (!function_exists('generateCSRFToken')) {
    function generateCSRFToken(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('validateCSRFToken')) {
    function validateCSRFToken(string $token): bool {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

// ============================================================================
// API HELPERS
// ============================================================================

if (!function_exists('sendJsonResponse')) {
    function sendJsonResponse($data, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        exit;
    }
}

if (!function_exists('sendJsonError')) {
    function sendJsonError(string $message, int $statusCode = 400): void {
        sendJsonResponse(['error' => $message, 'success' => false], $statusCode);
    }
}

if (!function_exists('sendJsonSuccess')) {
    function sendJsonSuccess($data = null, string $message = 'Success'): void {
        $response = ['success' => true, 'message' => $message];
        if ($data !== null) $response['data'] = $data;
        sendJsonResponse($response);
    }
}

if (!function_exists('validateApiKey')) {
    function validateApiKey(): bool {
        $headers = getallheaders();
        $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? '';
        if (empty($apiKey)) return false;

        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM api_keys WHERE api_key = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > datetime('now'))");
        $stmt->execute([$apiKey]);
        $key = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($key) {
            $db->prepare("UPDATE api_keys SET last_used = datetime('now') WHERE id = ?")->execute([$key['id']]);
            return true;
        }
        return false;
    }
}

if (!function_exists('requireApiKey')) {
    function requireApiKey(): void {
        if (!validateApiKey()) {
            sendJsonError('Invalid or missing API key', 401);
        }
    }
}

// ============================================================================
// NOTIFICATION HELPERS (with templates)
// ============================================================================

if (!function_exists('sendNotification')) {
    function sendNotification(string $recipient, string $type, string $subject, string $message, string $channel = 'email'): bool {
        $settings = getSettings();
        $sent = false;

        if ($channel === 'email' && !empty($settings['enable_email'])) {
            $sent = sendEmail($recipient, $subject, $message);
        } elseif ($channel === 'sms' && !empty($settings['enable_sms'])) {
            $sent = sendSMS($recipient, $message);
        } elseif ($channel === 'whatsapp' && !empty($settings['enable_whatsapp'])) {
            $sent = sendWhatsApp($recipient, $message);
        }

        try {
            $db = getDB();
            $stmt = $db->prepare("INSERT INTO notification_logs (recipient, notification_type, subject, message, channel, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$recipient, $type, $subject, $message, $channel, $sent ? 'sent' : 'failed']);
        } catch (Exception $e) {
            // ignore
        }
        return $sent;
    }
}

if (!function_exists('sendBulkNotification')) {
    function sendBulkNotification(array $recipients, string $type, string $subject, string $message, string $channel = 'email'): int {
        $sent = 0;
        foreach ($recipients as $recipient) {
            if (sendNotification($recipient, $type, $subject, $message, $channel)) $sent++;
        }
        return $sent;
    }
}

if (!function_exists('getNotificationTemplate')) {
    function getNotificationTemplate(string $templateKey, string $channel): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM notification_templates WHERE template_key = ? AND channel = ? AND is_active = 1");
        $stmt->execute([$templateKey, $channel]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }
}

if (!function_exists('renderNotificationTemplate')) {
    function renderNotificationTemplate(string $templateKey, string $channel, array $placeholders): ?string {
        $template = getNotificationTemplate($templateKey, $channel);
        if (!$template) return null;
        $body = $template['body'];
        foreach ($placeholders as $key => $value) {
            $body = str_replace('{' . $key . '}', $value, $body);
        }
        return $body;
    }
}

// ============================================================================
// EMAIL, SMS, WHATSAPP
// ============================================================================

if (!function_exists('sendEmail')) {
    function sendEmail(string $to, string $subject, string $message): bool {
        $settings = getSettings();
        if (!empty($settings['smtp_host']) && class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            try {
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host       = $settings['smtp_host'];
                $mail->Port       = (int)$settings['smtp_port'];
                $enc = strtolower($settings['smtp_encryption'] ?? 'tls');
                if ($enc === 'tls') $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                elseif ($enc === 'ssl') $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                $mail->SMTPAuth   = true;
                $mail->Username   = $settings['smtp_username'];
                $mail->Password   = $settings['smtp_password'];
                $mail->setFrom($settings['mail_from'], $settings['mail_from_name']);
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject    = $subject;
                $mail->Body       = nl2br($message);
                $mail->AltBody    = strip_tags($message);
                return $mail->send();
            } catch (Exception $e) {
                error_log("SMTP email failed: " . $e->getMessage());
                return false;
            }
        }
        $headers = "MIME-Version: 1.0\r\nContent-type:text/html;charset=UTF-8\r\nFrom: noreply@librarysystem.com\r\n";
        return @mail($to, $subject, nl2br($message), $headers);
    }
}

if (!function_exists('sendEmailQueued')) {
    function sendEmailQueued(string $to, string $subject, string $body, string $altBody = '', int $priority = 0): bool {
        try {
            $db = getDB();
            $stmt = $db->prepare("INSERT INTO email_queue (to_email, subject, body, alt_body, priority) VALUES (?, ?, ?, ?, ?)");
            return $stmt->execute([$to, $subject, $body, $altBody, $priority]);
        } catch (Exception $e) {
            error_log("Failed to queue email: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('processEmailQueue')) {
    function processEmailQueue(int $limit = 10): int {
        $sent = 0;
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM email_queue WHERE status = 'pending' ORDER BY priority DESC, created_at ASC LIMIT ?");
            $stmt->execute([$limit]);
            $emails = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($emails as $email) {
                $success = sendEmail($email['to_email'], $email['subject'], $email['body']);
                $status = $success ? 'sent' : 'failed';
                $update = $db->prepare("UPDATE email_queue SET status = ?, attempts = attempts + 1, last_attempt = datetime('now'), error = ? WHERE id = ?");
                $update->execute([$status, $success ? null : 'Mail function returned false', $email['id']]);
                if ($success) $sent++;
            }
        } catch (Exception $e) {
            error_log("Email queue processing error: " . $e->getMessage());
        }
        return $sent;
    }
}

if (!function_exists('sendSMS')) {
    function sendSMS(string $phone, string $message): bool {
        $settings = getSettings();
        if (empty($settings['enable_sms']) || empty($settings['sms_api_key'])) return false;
        // Implement actual SMS gateway integration here
        return true;
    }
}

if (!function_exists('sendWhatsApp')) {
    function sendWhatsApp(string $phone, string $message): bool {
        $settings = getSettings();
        if (empty($settings['enable_whatsapp']) || empty($settings['whatsapp_api_key'])) return false;
        // Implement actual WhatsApp integration here
        return true;
    }
}

if (!function_exists('addWhatsAppMessage')) {
    function addWhatsAppMessage(string $to, string $message, int $priority = 0, ?string $scheduleAt = null): bool {
        try {
            $db = getDB();
            $stmt = $db->prepare("INSERT INTO whatsapp_queue (recipient_number, message_text, priority, scheduled_at, created_at) VALUES (?, ?, ?, ?, datetime('now'))");
            return $stmt->execute([$to, $message, $priority, $scheduleAt ?? date('Y-m-d H:i:s')]);
        } catch (Exception $e) {
            error_log("Failed to add WhatsApp message: " . $e->getMessage());
            return false;
        }
    }
}

// ============================================================================
// FILE UPLOAD HELPER (enhanced)
// ============================================================================

if (!function_exists('uploadFile')) {
    function uploadFile(array $file, string $targetDir, string $prefix, bool $resize = false, int $width = 200, int $height = 200): string {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) return '';
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!in_array($file['type'], $allowedTypes)) return '';

        // Verify MIME with finfo for security
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            if (!in_array($mime, $allowedTypes)) return '';
        }

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $filename = $prefix . '_' . time() . '_' . uniqid() . '.' . $ext;
        $targetPath = $targetDir . $filename;
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            chmod($targetPath, 0644);
            if ($resize && in_array($file['type'], ['image/jpeg', 'image/png', 'image/gif', 'image/webp'])) {
                $resizedPath = $targetDir . $prefix . '_' . time() . '_resized.' . $ext;
                if (autoResizeImage($targetPath, $resizedPath, $width, $height)) {
                    unlink($targetPath);
                    return $resizedPath;
                }
            }
            return $targetPath;
        }
        return '';
    }
}

// ============================================================================
// TEXT EXTRACTION
// ============================================================================

if (!function_exists('extractTextFromPDF')) {
    function extractTextFromPDF(string $filePath): string {
        $text = '';
        if (function_exists('exec') && !ini_get('safe_mode')) {
            $outputFile = tempnam(sys_get_temp_dir(), 'pdftext');
            $cmd = 'pdftotext -layout -nopgbrk "' . escapeshellarg($filePath) . '" "' . escapeshellarg($outputFile) . '" 2>/dev/null';
            exec($cmd, $output, $returnCode);
            if ($returnCode === 0 && file_exists($outputFile)) {
                $text = file_get_contents($outputFile);
                unlink($outputFile);
            }
        }
        return trim($text);
    }
}

if (!function_exists('extractTextFromDOCX')) {
    function extractTextFromDOCX(string $filePath): string {
        $text = '';
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($filePath) === true) {
                $xml = $zip->getFromName('word/document.xml');
                $zip->close();
                if ($xml) {
                    $text = strip_tags(str_replace(['</w:p>', '</w:r>'], "\n", $xml));
                    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
                    $text = preg_replace('/\s+/', ' ', $text);
                }
            }
        }
        return trim($text);
    }
}

// ============================================================================
// PDF GENERATION (enhanced)
// ============================================================================

if (!function_exists('generatePdfFromHtml')) {
    function generatePdfFromHtml(string $html, string $filename, string $orientation = 'portrait', string $size = 'A4', array $margins = [10, 10, 10, 10]): void {
        $reportSettings = getReportSettings();

        // Watermark
        if ($reportSettings['watermark_enabled']) {
            $watermarkText = !empty($reportSettings['watermark_text'])
                ? $reportSettings['watermark_text']
                : (getInstitution()['name'] ?? 'Library Management System');
            $opacity = (int)$reportSettings['watermark_opacity'] / 100;
            $watermarkCss = '
            <style>
                .watermark {
                    position: fixed;
                    bottom: 50%;
                    right: 50%;
                    transform: translate(50%, 50%);
                    opacity: ' . $opacity . ';
                    font-size: 48px;
                    font-weight: bold;
                    color: #000;
                    white-space: nowrap;
                    z-index: 1000;
                    pointer-events: none;
                    text-align: center;
                    width: 100%;
                    font-family: "DejaVu Sans", sans-serif;
                }
            </style>
            <div class="watermark">' . htmlspecialchars($watermarkText) . '</div>';
            $html = str_replace('</head>', $watermarkCss . '</head>', $html);
        }

        // Signature
        if ($reportSettings['signature_enabled']) {
            $signatureImage = getSignatureImageBase64();
            $signatureHtml = '<div style="margin-top: 30px; text-align: right; border-top: 1px solid #ddd; padding-top: 15px;">
                                <div style="margin-bottom: 5px;">';
            if (!empty($signatureImage)) {
                $signatureHtml .= '<img src="' . $signatureImage . '" style="max-height: 50px; margin-bottom: 5px;"><br>';
            }
            $signatureHtml .= '<strong>' . htmlspecialchars($reportSettings['signature_name']) . '</strong><br>
                                <small>' . htmlspecialchars($reportSettings['signature_title']) . '</small>
                              </div>
                            </div>';
            $html = str_replace('</body>', $signatureHtml . '</body>', $html);
        }

        // Footer
        $footerText = $reportSettings['footer_text'];
        $footerCss = '
        <style>
            .report-footer {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                text-align: center;
                font-size: 9px;
                color: #777;
                border-top: 1px solid #ddd;
                padding-top: 5px;
                margin-top: 20px;
            }
        </style>
        <div class="report-footer">' . htmlspecialchars($footerText) . '</div>';
        $html = str_replace('</body>', $footerCss . '</body>', $html);

        // Primary color / font size
        $styleCss = '
        <style>
            body { font-size: ' . (int)$reportSettings['font_size'] . 'px; }
            th { background: ' . $reportSettings['primary_color'] . ' !important; }
            .report-header { border-bottom-color: ' . $reportSettings['primary_color'] . ' !important; }
        </style>';
        $html = str_replace('</head>', $styleCss . '</head>', $html);

        $html = cleanHtmlForPdf($html);

        // Try mPDF
        if (class_exists('Mpdf\Mpdf')) {
            try {
                $mpdf = new \Mpdf\Mpdf([
                    'mode'         => 'utf-8',
                    'format'       => $size,
                    'orientation'  => $orientation,
                    'margin_left'  => $margins[3],
                    'margin_right' => $margins[1],
                    'margin_top'   => $margins[0],
                    'margin_bottom'=> $margins[2],
                    'default_font' => 'dejavusans'
                ]);
                $mpdf->WriteHTML($html);
                $mpdf->Output($filename, 'D');
                exit;
            } catch (Exception $e) {
                error_log("mPDF Error: " . $e->getMessage());
            }
        }

        // Fallback to DOMPDF
        if (class_exists('Dompdf\Dompdf')) {
            try {
                $options = new \Dompdf\Options();
                $options->set('isHtml5ParserEnabled', true);
                $options->set('isRemoteEnabled', true);
                $options->set('defaultPaperSize', $size);
                $options->set('defaultPaperOrientation', $orientation);
                $dompdf = new \Dompdf\Dompdf($options);
                $dompdf->loadHtml($html);
                $dompdf->setPaper($size, $orientation);
                $dompdf->render();
                header('Content-Type: application/pdf');
                header('Content-Disposition: attachment; filename="' . $filename . '"');
                $dompdf->stream($filename, ['Attachment' => true]);
                exit;
            } catch (Exception $e) {
                error_log("Dompdf Error: " . $e->getMessage());
            }
        }

        // Ultimate fallback: print-friendly HTML
        header('Content-Type: text/html');
        echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
        echo '<style>body{font-family:Arial;margin:20px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px}th{background:#f0f0f0}@media print{body{margin:0}.no-print{display:none}}</style>';
        echo '</head><body>' . $html . '<div class="no-print" style="text-align:center;margin-top:20px;"><button onclick="window.print();">Print Report</button><button onclick="window.close();">Close</button></div>';
        echo '<script>setTimeout(function(){window.print();},500);</script></body></html>';
        exit;
    }
}

// ============================================================================
// REPORT SETTINGS
// ============================================================================

if (!function_exists('getReportSettings')) {
    function getReportSettings(): array {
        static $settings = null;
        if ($settings !== null) return $settings;

        $cached = cacheGet('report_settings');
        if ($cached !== null) {
            $settings = $cached;
            return $settings;
        }

        $sysSettings = getSettings();
        $settings = [
            'font_size'          => (int)($sysSettings['report_font_size'] ?? 10),
            'primary_color'      => $sysSettings['report_primary_color'] ?? '#1e3c72',
            'logo_position'      => $sysSettings['report_logo_position'] ?? 'left',
            'logo_right'         => $sysSettings['report_logo_right'] ?? '',
            'watermark_text'     => $sysSettings['report_watermark_text'] ?? '',
            'watermark_enabled'  => (int)($sysSettings['report_watermark_enabled'] ?? 1),
            'watermark_opacity'  => (int)($sysSettings['report_watermark_opacity'] ?? 10),
            'signature_name'     => $sysSettings['report_signature_name'] ?? 'Librarian',
            'signature_title'    => $sysSettings['report_signature_title'] ?? 'Chief Librarian',
            'signature_image'    => $sysSettings['report_signature_image'] ?? '',
            'signature_enabled'  => (int)($sysSettings['report_signature_enabled'] ?? 0),
            'footer_text'        => $sysSettings['report_footer_text'] ?? 'This is a system generated report',
        ];
        cacheSet('report_settings', $settings, 3600);
        return $settings;
    }
}

if (!function_exists('getReportRightLogoBase64')) {
    function getReportRightLogoBase64(): string {
        $settings = getSettings();
        $logoPath = $settings['report_logo_right'] ?? '';
        if (!empty($logoPath) && file_exists($logoPath)) {
            $imageData = base64_encode(file_get_contents($logoPath));
            $imageMime = mime_content_type($logoPath);
            return 'data:' . $imageMime . ';base64,' . $imageData;
        }
        return '';
    }
}

if (!function_exists('getSignatureImageBase64')) {
    function getSignatureImageBase64(): string {
        $settings = getSettings();
        $imagePath = $settings['report_signature_image'] ?? '';
        if (!empty($imagePath) && file_exists($imagePath)) {
            $imageData = base64_encode(file_get_contents($imagePath));
            $imageMime = mime_content_type($imagePath);
            return 'data:' . $imageMime . ';base64,' . $imageData;
        }
        return '';
    }
}

if (!function_exists('getReportHeaderHtml')) {
    function getReportHeaderHtml(array $institution, string $reportTitle, ?string $fromDate = null, ?string $toDate = null, array $filters = []): string {
        $institutionName = htmlspecialchars($institution['name'] ?? 'Library System');
        $logoHtml = '';
        if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
            $logoHtml = '<img src="' . getWebImageUrl($institution['logo_path']) . '" style="height: 60px; margin-right: 15px;">';
        }
        $periodText = '';
        if ($fromDate && $toDate) $periodText = "Period: " . formatDate($fromDate) . " to " . formatDate($toDate);
        elseif ($fromDate) $periodText = "From: " . formatDate($fromDate);
        elseif ($toDate) $periodText = "Until: " . formatDate($toDate);
        $filterText = '';
        foreach ($filters as $label => $value) if (!empty($value)) $filterText .= " | " . htmlspecialchars($label) . ": " . htmlspecialchars($value);
        $generatedDate = date('F j, Y g:i A');
        return <<<HTML
        <div class="report-header" style="text-align: center; border-bottom: 2px solid #1e3c72; margin-bottom: 20px; padding-bottom: 10px;">
            {$logoHtml}
            <h1 style="margin: 5px 0;">{$institutionName}</h1>
            <h2 style="margin: 5px 0;">{$reportTitle}</h2>
            <p style="margin: 3px 0; color: #555;">{$periodText}{$filterText}</p>
            <p style="margin: 3px 0; color: #555;">Generated: {$generatedDate}</p>
        </div>
HTML;
    }
}

if (!function_exists('cleanHtmlForPdf')) {
    function cleanHtmlForPdf(string $html): string {
        $html = preg_replace('/<table[^>]*>\s*<table/', '<table', $html);
        $html = preg_replace('/<\/table>\s*<\/table>/', '</td>·</table>', $html);
        $html = preg_replace('/<td[^>]*>\s*<table/', '<td><div style="overflow-x:auto;"><table', $html);
        $html = preg_replace('/<\/table>\s*<\/td>/', '</table></div></table>', $html);
        $html = preg_replace('/<th([^>]*)>\s*<br\s*\/?>\s*<\/th>/', '<th$1></th>', $html);
        $html = preg_replace('/<td([^>]*)>\s*<br\s*\/?>\s*<\/td>/', '<td$1></td>', $html);
        return $html;
    }
}

// ============================================================================
// OVERDUE CHECK
// ============================================================================

if (!function_exists('checkOverdueBooks')) {
    function checkOverdueBooks(): void {
        try {
            $db = getDB();
            $settings = getSettings();
            if (empty($settings['notify_overdue'])) return;

            $stmt = $db->query("SELECT c.*, m.email, m.phone, m.member_category
                                FROM circulation c
                                LEFT JOIN members m ON c.admno = m.admno
                                WHERE c.return_date IS NULL AND c.due_date < date('now')");
            $overdue = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($overdue as $book) {
                $fine = calculateFine($book['due_date'], $book['member_category'] ?? 'Student');
                $days = (new DateTime())->diff(new DateTime($book['due_date']))->days;
                $message = "Reminder: Book '{$book['title']}' is overdue by {$days} days. Fine: " . formatCurrency($fine);
                if (!empty($settings['enable_email']) && !empty($book['email'])) {
                    sendEmail($book['email'], 'Overdue Book Notice', $message);
                }
            }
        } catch (Exception $e) {
            error_log("Overdue check failed: " . $e->getMessage());
        }
    }
}

// ============================================================================
// USER PREFERENCES
// ============================================================================

if (!function_exists('getUserPreference')) {
    function getUserPreference(PDO $db, int $userId, string $key, $default = null) {
        $stmt = $db->prepare("SELECT preference_value FROM user_preferences WHERE user_id = ? AND preference_key = ?");
        $stmt->execute([$userId, $key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) return json_decode($row['preference_value'], true);
        return $default;
    }
}

if (!function_exists('setUserPreference')) {
    function setUserPreference(PDO $db, int $userId, string $key, $value): bool {
        $valueJson = json_encode($value);
        $stmt = $db->prepare("INSERT OR REPLACE INTO user_preferences (user_id, preference_key, preference_value) VALUES (?, ?, ?)");
        return $stmt->execute([$userId, $key, $valueJson]);
    }
}

// ============================================================================
// QUICK ACTIONS
// ============================================================================

if (!function_exists('getQuickActions')) {
    function getQuickActions(PDO $db): array {
        $stmt = $db->query("SELECT * FROM quick_actions WHERE is_active = 1 ORDER BY sort_order ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('saveQuickActions')) {
    function saveQuickActions(PDO $db, int $userId, array $selectedIds): bool {
        $db->exec("UPDATE quick_actions SET is_active = 0");
        $stmt = $db->prepare("UPDATE quick_actions SET is_active = 1 WHERE id = ?");
        foreach ($selectedIds as $id) $stmt->execute([$id]);
        setUserPreference($db, $userId, 'quick_actions', $selectedIds);
        return true;
    }
}

if (!function_exists('initializeQuickActionsTable')) {
    function initializeQuickActionsTable(PDO $db): void {
        $db->exec("CREATE TABLE IF NOT EXISTS quick_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            icon_class TEXT NOT NULL,
            link_url TEXT NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        $stmt = $db->query("SELECT COUNT(*) FROM quick_actions");
        if ($stmt->fetchColumn() == 0) {
            $defaults = [
                ['title' => 'Issue Book', 'icon' => 'fa-arrow-right', 'link' => 'circulation/issue.php', 'order' => 1],
                ['title' => 'Return Book', 'icon' => 'fa-arrow-left', 'link' => 'circulation/return.php', 'order' => 2],
                ['title' => 'Renew', 'icon' => 'fa-sync-alt', 'link' => 'circulation/renew.php', 'order' => 3],
                ['title' => 'Computer Access', 'icon' => 'fa-desktop', 'link' => 'computer_management/', 'order' => 4],
                ['title' => 'eBooks', 'icon' => 'fa-file-pdf', 'link' => 'ebooks/', 'order' => 5],
                ['title' => 'Utilities Suite', 'icon' => 'fa-toolbox', 'link' => 'utilities/', 'order' => 6],
                ['title' => 'Serial Control', 'icon' => 'fa-newspaper', 'link' => 'serial/', 'order' => 7],
                ['title' => 'Backup & Restore', 'icon' => 'fa-database', 'link' => 'admin/backup.php', 'order' => 8],
                ['title' => 'Reports', 'icon' => 'fa-chart-bar', 'link' => 'reports/', 'order' => 9],
                ['title' => 'Settings', 'icon' => 'fa-cog', 'link' => 'admin/settings.php', 'order' => 10],
            ];
            $insert = $db->prepare("INSERT INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES (?, ?, ?, ?, 1)");
            foreach ($defaults as $item) $insert->execute([$item['title'], $item['icon'], $item['link'], $item['order']]);
        }
    }
}

// ============================================================================
// MODULE PERMISSIONS
// ============================================================================

if (!function_exists('createModulePermissionsTable')) {
    function createModulePermissionsTable(): void {
        $db = getDB();
        $db->exec("CREATE TABLE IF NOT EXISTS module_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            module_key TEXT NOT NULL,
            can_access INTEGER DEFAULT 1,
            UNIQUE(role, module_key)
        )");
        $allModules = [
            'admin_dashboard', 'circulation', 'members', 'books', 'ebooks',
            'acquisitions', 'serial_control', 'system_settings', 'quick_actions_manager',
            'backup_restore', 'data_import', 'utilities', 'stock_verification',
            'lost_damaged', 'payments', 'reservations', 'library_events',
            'member_documents', 'computer_access', 'entry_exit', 'session_logs',
            'bulk_messaging', 'chatbot', 'reports', 'advanced_analytics',
            'opac', 'digital_hub', 'self_kiosk', 'member_portal', 'multi_library',
            'fines_management', 'overdue_reports'
        ];
        $defaultLocks = [
            'librarian' => ['system_settings', 'backup_restore', 'bulk_messaging', 'advanced_analytics'],
            'staff'     => ['acquisitions', 'serial_control', 'system_settings', 'backup_restore', 'data_import', 'payments', 'reservations', 'library_events', 'member_documents', 'session_logs', 'bulk_messaging', 'advanced_analytics', 'digital_hub', 'multi_library', 'fines_management']
        ];
        foreach (['admin', 'librarian', 'staff'] as $role) {
            foreach ($allModules as $moduleKey) {
                $allowed = 1;
                if ($role !== 'admin' && in_array($moduleKey, $defaultLocks[$role] ?? [])) $allowed = 0;
                $stmt = $db->prepare("INSERT OR IGNORE INTO module_permissions (role, module_key, can_access) VALUES (?, ?, ?)");
                $stmt->execute([$role, $moduleKey, $allowed]);
            }
        }
    }
}

if (!function_exists('userCanAccessModule')) {
    function userCanAccessModule(string $moduleKey): bool {
        if (!isset($_SESSION['user_id'])) return false;
        if ($_SESSION['role'] === 'admin') return true;
        $db = getDB();
        $stmt = $db->prepare("SELECT can_access FROM module_permissions WHERE role = ? AND module_key = ?");
        $stmt->execute([$_SESSION['role'], $moduleKey]);
        $result = $stmt->fetchColumn();
        return ($result !== null && (bool)$result);
    }
}

// ============================================================================
// LIBRARY HOURS
// ============================================================================

if (!function_exists('getLibraryHours')) {
    function getLibraryHours(): array {
        static $hours = null;
        if ($hours === null) {
            $settings = getSettings();
            $hours = [
                'open_days'   => explode(',', $settings['library_open_days'] ?? '1,2,3,4,5'),
                'open_time'   => $settings['library_open_time'] ?? '09:00',
                'close_time'  => $settings['library_close_time'] ?? '18:00',
                'lunch_start' => $settings['library_lunch_start'] ?? '',
                'lunch_end'   => $settings['library_lunch_end'] ?? '',
                'timezone'    => $settings['library_timezone'] ?? 'Asia/Kolkata',
            ];
        }
        return $hours;
    }
}

if (!function_exists('isLibraryOpen')) {
    function isLibraryOpen(?string $datetime = null): bool {
        $hours = getLibraryHours();
        if (empty($hours['open_days'])) return false;

        $tz = new DateTimeZone($hours['timezone']);
        $now = $datetime ? new DateTime($datetime, $tz) : new DateTime('now', $tz);
        $currentDay = (int)$now->format('N');
        $currentTime = $now->format('H:i');

        if (!in_array($currentDay, $hours['open_days'])) return false;
        if ($currentTime < $hours['open_time']) return false;
        if ($currentTime > $hours['close_time']) return false;
        if (!empty($hours['lunch_start']) && !empty($hours['lunch_end'])) {
            if ($currentTime >= $hours['lunch_start'] && $currentTime <= $hours['lunch_end']) return false;
        }
        return true;
    }
}

if (!function_exists('getLibraryHoursHTML')) {
    function getLibraryHoursHTML(): string {
        $hours = getLibraryHours();
        $daysMap = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
        $openDays = array_map(function($d) use ($daysMap) { return $daysMap[$d]; }, $hours['open_days']);
        $daysStr = implode(', ', $openDays);
        $html = '<div class="library-hours card mb-4">';
        $html .= '<div class="card-header bg-info text-white"><i class="fas fa-clock"></i> Library Hours</div>';
        $html .= '<div class="card-body">';
        $html .= '<p><strong>Open Days:</strong> ' . htmlspecialchars($daysStr) . '</p>';
        $html .= '<p><strong>Hours:</strong> ' . htmlspecialchars($hours['open_time']) . ' – ' . htmlspecialchars($hours['close_time']) . '</p>';
        if (!empty($hours['lunch_start']) && !empty($hours['lunch_end'])) $html .= '<p><strong>Lunch Break:</strong> ' . htmlspecialchars($hours['lunch_start']) . ' – ' . htmlspecialchars($hours['lunch_end']) . '</p>';
        if (!isLibraryOpen()) $html .= '<div class="alert alert-warning mt-2 mb-0 py-1 small"><i class="fas fa-exclamation-triangle"></i> The library is currently closed.</div>';
        $html .= '</div></div>';
        return $html;
    }
}

// ============================================================================
// ADVANCED LOAN RULES
// ============================================================================

if (!function_exists('getLoanRule')) {
    function getLoanRule(string $patronCategory, string $itemCategory): ?array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = ? AND item_category = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$patronCategory, $itemCategory]);
        $rule = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($rule) return $rule;

        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = ? AND item_category = '*' AND is_active = 1 LIMIT 1");
        $stmt->execute([$patronCategory]);
        $rule = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($rule) return $rule;

        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = '*' AND item_category = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$itemCategory]);
        $rule = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($rule) return $rule;

        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = '*' AND item_category = '*' AND is_active = 1 LIMIT 1");
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// ============================================================================
// ADDITIONAL DB QUERY HELPERS
// ============================================================================

if (!function_exists('getMemberByAdmno')) {
    function getMemberByAdmno(string $admno) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
        $stmt->execute([$admno]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('getBookByBarcode')) {
    function getBookByBarcode(string $barcode) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('getCirculationById')) {
    function getCirculationById(int $id) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM circulation WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('isBookAvailable')) {
    function isBookAvailable(string $barcode): bool {
        $db = getDB();
        $stmt = $db->prepare("SELECT available FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        return $book && $book['available'] > 0;
    }
}

if (!function_exists('getMemberActiveLoansCount')) {
    function getMemberActiveLoansCount(string $admno): int {
        $db = getDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL");
        $stmt->execute([$admno]);
        return (int)$stmt->fetchColumn();
    }
}

if (!function_exists('getBookCurrentStatus')) {
    function getBookCurrentStatus(string $barcode): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT available FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$book) return ['status' => 'not_found', 'holder' => null];
        if ($book['available'] > 0) return ['status' => 'available', 'holder' => null];

        $stmt2 = $db->prepare("SELECT admno, member_name FROM circulation WHERE barcode = ? AND return_date IS NULL LIMIT 1");
        $stmt2->execute([$barcode]);
        $issued = $stmt2->fetch(PDO::FETCH_ASSOC);
        if ($issued) return ['status' => 'issued', 'holder' => $issued['admno'] . ' - ' . $issued['member_name']];

        $stmt3 = $db->prepare("SELECT admno, member_name FROM reservations_queue WHERE book_barcode = ? AND status = 'waiting' ORDER BY priority DESC, requested_date ASC LIMIT 1");
        $stmt3->execute([$barcode]);
        $reserved = $stmt3->fetch(PDO::FETCH_ASSOC);
        if ($reserved) return ['status' => 'reserved', 'holder' => $reserved['admno'] . ' - ' . $reserved['member_name']];

        return ['status' => 'unknown', 'holder' => null];
    }
}

if (!function_exists('quickLog')) {
    function quickLog(string $action, string $details = ''): void {
        if (isset($_SESSION['username'])) {
            logActivity($_SESSION['username'], $action, $details);
        }
    }
}

if (!function_exists('updateLastExportTime')) {
    function updateLastExportTime(): bool {
        $db = getDB();
        $stmt = $db->prepare("UPDATE settings SET last_export = datetime('now') WHERE id = 1");
        return $stmt->execute();
    }
}

if (!function_exists('logExport')) {
    function logExport(?int $userId, string $username, string $exportType, string $reportName, ?string $filters = null, ?int $fileSize = null, string $status = 'success', ?string $errorMessage = null): bool {
        try {
            $db = getDB();
            $stmt = $db->prepare("INSERT INTO export_logs (user_id, username, export_type, report_name, filters, file_size, status, error_message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([$userId, $username, $exportType, $reportName, $filters, $fileSize, $status, $errorMessage]);
        } catch (Exception $e) {
            error_log("Failed to log export: " . $e->getMessage());
            return false;
        }
    }
}

// ============================================================================
// CLOUD STORAGE HELPERS
// ============================================================================

if (!function_exists('uploadToCloud')) {
    function uploadToCloud(string $localPath): array {
        $settings = getSettings();
        $provider = $settings['cloud_storage_provider'] ?? 'local';
        switch ($provider) {
            case 'google_drive': return uploadToGoogleDrive($localPath);
            case 'onedrive': return uploadToOneDrive($localPath);
            case 'dropbox': return uploadToDropbox($localPath);
            default:
                $targetDir = EBOOK_DIR;
                if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
                $filename = 'ebook_' . time() . '_' . uniqid() . '.' . pathinfo($localPath, PATHINFO_EXTENSION);
                $targetPath = $targetDir . $filename;
                if (copy($localPath, $targetPath)) return ['file_id' => $targetPath, 'download_url' => getWebImageUrl($targetPath), 'type' => 'local'];
                throw new Exception("Failed to save file locally");
        }
    }
}

if (!function_exists('uploadToGoogleDrive')) {
    function uploadToGoogleDrive(string $localPath): array {
        // Stub – requires google/apiclient
        throw new Exception("Google Drive upload not configured. Please install google/apiclient via composer and set up service account.");
    }
}

if (!function_exists('uploadToOneDrive')) {
    function uploadToOneDrive(string $localPath): array {
        throw new Exception("OneDrive upload not implemented. Add your own implementation.");
    }
}

if (!function_exists('uploadToDropbox')) {
    function uploadToDropbox(string $localPath): array {
        throw new Exception("Dropbox upload not implemented. Add your own implementation.");
    }
}

if (!function_exists('deleteFromCloud')) {
    function deleteFromCloud(string $fileId, ?string $type = null): bool {
        if ($type === null) {
            $settings = getSettings();
            $type = $settings['cloud_storage_provider'] ?? 'local';
        }
        if ($type === 'local') {
            if (file_exists($fileId)) unlink($fileId);
            return true;
        }
        // Other providers would need their own delete logic
        return true;
    }
}

if (!function_exists('testCloudStorage')) {
    function testCloudStorage(string $provider, array $params): string {
        $tempFile = tempnam(sys_get_temp_dir(), 'cloud_test');
        file_put_contents($tempFile, 'Cloud test content - ' . date('Y-m-d H:i:s'));
        try {
            switch ($provider) {
                case 'google_drive': $result = uploadToGoogleDrive($tempFile); break;
                case 'onedrive': $result = uploadToOneDrive($tempFile); break;
                case 'dropbox': $result = uploadToDropbox($tempFile); break;
                default: throw new Exception("Invalid provider");
            }
            deleteFromCloud($result['file_id'], $provider);
            unlink($tempFile);
            return "Connection successful!";
        } catch (Exception $e) {
            unlink($tempFile);
            throw $e;
        }
    }
}

if (!function_exists('deleteOldBackupsFromGoogleDrive')) {
    function deleteOldBackupsFromGoogleDrive($driveService, string $folderId, string $currentBackupName): int {
        $deletedCount = 0;
        try {
            $optParams = array('q' => "'{$folderId}' in parents and mimeType='application/zip' and name contains 'library_backup_'", 'fields' => 'files(id, name)');
            $results = $driveService->files->listFiles($optParams);
            $files = $results->getFiles();
            foreach ($files as $file) {
                if ($file->getName() !== $currentBackupName) {
                    $driveService->files->delete($file->getId());
                    $deletedCount++;
                    error_log("Deleted old backup from Google Drive: " . $file->getName());
                }
            }
        } catch (Exception $e) {
            error_log("Failed to delete old backups from Google Drive: " . $e->getMessage());
        }
        return $deletedCount;
    }
}

if (!function_exists('uploadToGoogleDriveForBackup')) {
    function uploadToGoogleDriveForBackup(string $localFile, array $settings) {
        if (empty($settings['google_drive_enabled']) || empty($settings['google_drive_client_id']) || empty($settings['google_drive_client_secret']) || empty($settings['google_drive_refresh_token'])) {
            return "Google Drive backup is not fully configured.";
        }
        $autoloadPath = __DIR__ . '/../vendor/autoload.php';
        if (!file_exists($autoloadPath)) return "Google API client not found. Please install google/apiclient via Composer.";
        require_once $autoloadPath;
        try {
            $client = new Google_Client();
            $client->setClientId($settings['google_drive_client_id']);
            $client->setClientSecret($settings['google_drive_client_secret']);
            $client->refreshToken($settings['google_drive_refresh_token']);
            $client->addScope(Google_Service_Drive::DRIVE_FILE);
            $driveService = new Google_Service_Drive($client);
            $fileName = basename($localFile);
            $fileMetadata = new Google_Service_Drive_DriveFile(array('name' => $fileName, 'parents' => !empty($settings['google_drive_folder_id']) ? array($settings['google_drive_folder_id']) : array()));
            $content = file_get_contents($localFile);
            $uploadedFile = $driveService->files->create($fileMetadata, array('data' => $content, 'mimeType' => 'application/zip', 'uploadType' => 'multipart'));
            if ($uploadedFile && !empty($settings['google_drive_folder_id'])) deleteOldBackupsFromGoogleDrive($driveService, $settings['google_drive_folder_id'], $fileName);
            return true;
        } catch (Exception $e) {
            return "Google Drive upload error: " . $e->getMessage();
        }
    }
}

// ============================================================================
// MULTILINGUAL SUPPORT (already defined __t above)
// ============================================================================

// Alias for backward compatibility
if (!function_exists('translateText')) {
    function translateText(string $text, string $lang = 'en'): string {
        return __t($text, $lang);
    }
}

// ============================================================================
// RESPONSIVE LAYOUT HELPERS
// ============================================================================

if (!function_exists('isMobileDevice')) {
    function isMobileDevice(): bool {
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $mobileKeywords = ['Mobile', 'Android', 'iPhone', 'iPad', 'iPod', 'BlackBerry', 'Windows Phone', 'Opera Mini', 'IEMobile'];
        foreach ($mobileKeywords as $keyword) {
            if (stripos($userAgent, $keyword) !== false) return true;
        }
        return false;
    }
}

if (!function_exists('getResponsiveClasses')) {
    function getResponsiveClasses(string $type = 'table'): string {
        if ($type === 'table') return 'table-responsive-wrapper';
        if ($type === 'sidebar') return isMobileDevice() ? 'staff-sidebar-mobile' : '';
        return '';
    }
}

if (!function_exists('renderMobileMenuToggle')) {
    function renderMobileMenuToggle(): string {
        if (isMobileDevice()) {
            return '<button class="mobile-menu-toggle" id="mobileMenuToggle"><i class="fas fa-bars"></i></button>';
        }
        return '';
    }
}

// ============================================================================
// DASHBOARD STATS (cached)
// ============================================================================

if (!function_exists('getDashboardStats')) {
    function getDashboardStats(): array {
        return cacheQuery('dashboard_stats', function() {
            $db = getDB();
            return [
                'members' => (int)$db->query("SELECT COUNT(*) FROM members")->fetchColumn(),
                'books'   => (int)$db->query("SELECT SUM(quantity) FROM books")->fetchColumn(),
                'issued'  => (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn(),
                'overdue' => (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn(),
                // Add more stats as needed
            ];
        }, 60);
    }
}

// ============================================================================
// ADDITIONAL UTILITY FUNCTIONS
// ============================================================================

if (!function_exists('validateEmail')) {
    function validateEmail(string $email): bool {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

if (!function_exists('sanitizeInput')) {
    function sanitizeInput($data, string $type = 'string') {
        if ($type === 'int') return filter_var($data, FILTER_SANITIZE_NUMBER_INT);
        if ($type === 'float') return filter_var($data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        if ($type === 'email') return filter_var($data, FILTER_SANITIZE_EMAIL);
        if ($type === 'url') return filter_var($data, FILTER_SANITIZE_URL);
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('generateRandomString')) {
    function generateRandomString(int $length = 32): string {
        return bin2hex(random_bytes($length / 2));
    }
}

if (!function_exists('getClientIP')) {
    function getClientIP(): string {
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
}

if (!function_exists('isAjaxRequest')) {
    function isAjaxRequest(): bool {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

if (!function_exists('redirect')) {
    function redirect(string $url): void {
        header('Location: ' . $url);
        exit;
    }
}

if (!function_exists('setFlashMessage')) {
    function setFlashMessage(string $key, string $message, string $type = 'success'): void {
        $_SESSION['flash'][$key] = ['message' => $message, 'type' => $type];
    }
}

if (!function_exists('getFlashMessage')) {
    function getFlashMessage(string $key): ?array {
        if (isset($_SESSION['flash'][$key])) {
            $flash = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $flash;
        }
        return null;
    }
}

if (!function_exists('showToast')) {
    function showToast(string $message, string $type = 'success'): void {
        echo '<div class="alert alert-' . $type . ' alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3" style="z-index:9999; min-width:300px;" role="alert"><i class="fas fa-' . ($type === 'success' ? 'check-circle' : ($type === 'danger' ? 'exclamation-circle' : 'info-circle')) . '"></i> ' . htmlspecialchars($message) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}

if (!function_exists('truncateText')) {
    function truncateText(string $text, int $length = 100, string $suffix = '...'): string {
        if (strlen($text) <= $length) return $text;
        return substr($text, 0, $length) . $suffix;
    }
}

if (!function_exists('getFileSize')) {
    function getFileSize(string $path): string {
        if (!file_exists($path)) return '0 B';
        $bytes = filesize($path);
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
}

// ============================================================================
// ADVANCED UTILITY: Array helpers
// ============================================================================

if (!function_exists('array_get')) {
    function array_get(array $array, string $key, $default = null) {
        $keys = explode('.', $key);
        foreach ($keys as $k) {
            if (!is_array($array) || !array_key_exists($k, $array)) {
                return $default;
            }
            $array = $array[$k];
        }
        return $array;
    }
}

if (!function_exists('array_set')) {
    function array_set(array &$array, string $key, $value): void {
        $keys = explode('.', $key);
        $ref = &$array;
        foreach ($keys as $k) {
            if (!is_array($ref)) {
                $ref = [];
            }
            $ref = &$ref[$k];
        }
        $ref = $value;
    }
}

// ============================================================================
// PAGINATION HELPER
// ============================================================================

if (!function_exists('paginate')) {
    function paginate(int $total, int $current, int $perPage = 20): array {
        $totalPages = max(1, ceil($total / $perPage));
        $current = max(1, min($current, $totalPages));
        $offset = ($current - 1) * $perPage;
        return [
            'current' => $current,
            'total_pages' => $totalPages,
            'per_page' => $perPage,
            'offset' => $offset,
            'total' => $total,
            'has_prev' => $current > 1,
            'has_next' => $current < $totalPages,
            'prev_page' => max(1, $current - 1),
            'next_page' => min($totalPages, $current + 1),
        ];
    }
}

// ============================================================================
// LIBRARY STATISTICS FUNCTIONS
// ============================================================================

if (!function_exists('updateLibraryStatistics')) {
    function updateLibraryStatistics(?string $date = null): bool {
        $db = getDB();
        $date = $date ?: date('Y-m-d');

        try {
            $totalMembers = (int)$db->query("SELECT COUNT(*) FROM members")->fetchColumn();
            $totalBooks = (int)$db->query("SELECT SUM(quantity) FROM books")->fetchColumn();
            $totalLoans = (int)$db->query("SELECT COUNT(*) FROM circulation")->fetchColumn();
            $finesCollected = (float)$db->query("SELECT COALESCE(SUM(amount), 0) FROM fine_payments WHERE date(payment_date) = '$date'")->fetchColumn();
            $activeLoans = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
            $overdueCount = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn();

            $stmt = $db->prepare("INSERT OR REPLACE INTO library_statistics (stat_date, total_members, total_books, total_loans, total_fines_collected, active_loans, overdue_count) VALUES (?, ?, ?, ?, ?, ?, ?)");
            return $stmt->execute([$date, $totalMembers, $totalBooks, $totalLoans, $finesCollected, $activeLoans, $overdueCount]);
        } catch (PDOException $e) {
            error_log("Failed to update library statistics: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getLibraryStatistics')) {
    function getLibraryStatistics(?string $startDate = null, ?string $endDate = null): array {
        $db = getDB();
        $sql = "SELECT * FROM library_statistics";
        $where = [];
        if ($startDate) $where[] = "stat_date >= '$startDate'";
        if ($endDate) $where[] = "stat_date <= '$endDate'";
        if ($where) $sql .= " WHERE " . implode(" AND ", $where);
        $sql .= " ORDER BY stat_date DESC";
        return $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}

// ============================================================================
// BUDGET & FINANCE HELPERS
// ============================================================================

if (!function_exists('getBudgetBalance')) {
    function getBudgetBalance(int $budgetId): float {
        $db = getDB();
        $stmt = $db->prepare("SELECT total_amount, allocated_amount, expended_amount, encumbered_amount FROM budgets WHERE id = ?");
        $stmt->execute([$budgetId]);
        $budget = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$budget) return 0;
        return $budget['total_amount'] - $budget['allocated_amount'] - $budget['expended_amount'] - $budget['encumbered_amount'];
    }
}

if (!function_exists('addBudgetTransaction')) {
    function addBudgetTransaction(int $budgetId, string $type, float $amount, string $description = ''): bool {
        $db = getDB();
        $field = $type . '_amount';
        $stmt = $db->prepare("UPDATE budgets SET $field = $field + ? WHERE id = ?");
        return $stmt->execute([$amount, $budgetId]);
    }
}

// ============================================================================
// INTERLIBRARY LOAN HELPERS
// ============================================================================

if (!function_exists('createInterlibraryLoan')) {
    function createInterlibraryLoan(string $memberAdmno, string $title, string $author, string $isbn, string $borrowingInst, string $lendingInst): bool {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO interlibrary_loans (requesting_member_admno, requested_book_title, author, isbn, borrowing_institution, lending_institution, request_date, status) VALUES (?, ?, ?, ?, ?, ?, date('now'), 'requested')");
        return $stmt->execute([$memberAdmno, $title, $author, $isbn, $borrowingInst, $lendingInst]);
    }
}

if (!function_exists('updateInterlibraryLoanStatus')) {
    function updateInterlibraryLoanStatus(int $id, string $status): bool {
        $db = getDB();
        $stmt = $db->prepare("UPDATE interlibrary_loans SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }
}

// ============================================================================
// COURSE RESERVE HELPERS
// ============================================================================

if (!function_exists('addCourseReserve')) {
    function addCourseReserve(string $courseName, string $courseCode, string $instructor, string $academicYear, string $semester): bool {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO course_reserves (course_name, course_code, instructor_name, academic_year, semester, status) VALUES (?, ?, ?, ?, ?, 'active')");
        return $stmt->execute([$courseName, $courseCode, $instructor, $academicYear, $semester]);
    }
}

if (!function_exists('addCourseReserveItem')) {
    function addCourseReserveItem(int $courseReserveId, string $bookBarcode, string $title, string $author, int $loanPeriod = 2): bool {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO course_reserve_items (course_reserve_id, book_barcode, title, author, loan_period) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$courseReserveId, $bookBarcode, $title, $author, $loanPeriod]);
    }
}

// ============================================================================
// DIGITAL ASSET TRACKING
// ============================================================================

if (!function_exists('logDigitalAssetUsage')) {
    function logDigitalAssetUsage(string $assetType, int $assetId, string $memberAdmno, int $duration = 0): bool {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO digital_asset_usage (asset_type, asset_id, member_admno, duration) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$assetType, $assetId, $memberAdmno, $duration]);
    }
}

// ============================================================================
// RATE LIMITING
// ============================================================================

if (!function_exists('checkRateLimit')) {
    function checkRateLimit(string $key, int $limit = 60, int $window = 60): bool {
        $db = getDB();
        $resetAt = date('Y-m-d H:i:s', time() + $window);
        $stmt = $db->prepare("INSERT INTO api_rate_limits (api_key, endpoint, request_count, reset_at) VALUES (?, ?, 1, ?) ON CONFLICT(api_key, endpoint, reset_at) DO UPDATE SET request_count = request_count + 1");
        $stmt->execute([$key, $key, $resetAt]);
        $stmt = $db->prepare("SELECT request_count FROM api_rate_limits WHERE api_key = ? AND endpoint = ? AND reset_at > datetime('now')");
        $stmt->execute([$key, $key]);
        $count = (int)$stmt->fetchColumn();
        return $count <= $limit;
    }
}

// ============================================================================
// DB INITIALIZATION (legacy, kept for compatibility)
// ============================================================================

if (!function_exists('initializeDatabase')) {
    function initializeDatabase(): bool {
        // This function is now obsolete – schema is managed by db.php.
        // Keep for backward compatibility.
        return true;
    }
}

// ============================================================================
// BACKUP FUNCTIONS
// ============================================================================

if (!function_exists('createDatabaseBackup')) {
    function createDatabaseBackup(): ?string {
        if (!is_dir(BACKUP_DIR)) mkdir(BACKUP_DIR, 0777, true);

        $dbFile = BASE_PATH . '/database/library.db';
        if (!file_exists($dbFile)) return null;

        $backupFile = BACKUP_DIR . 'library_backup_' . date('Y-m-d_H-i-s') . '.db';
        if (copy($dbFile, $backupFile)) {
            $backups = glob(BACKUP_DIR . 'library_backup_*.db');
            if (count($backups) > 10) {
                usort($backups, function($a, $b) {
                    return filemtime($a) - filemtime($b);
                });
                $toDelete = array_slice($backups, 0, count($backups) - 10);
                foreach ($toDelete as $file) {
                    @unlink($file);
                }
            }
            return $backupFile;
        }
        return null;
    }
}

// ============================================================================
// RENDER HEADER/FOOTER
// ============================================================================

if (!function_exists('renderHeader')) {
    function renderHeader(string $title = 'Library System'): void {
        $settings = getSettings();
        $institution = getInstitution();
        $logoHtml = displayLibraryLogo($settings['library_logo'] ?? '', 40);
        $faviconPath = '';
        if (!empty($settings['favicon_path']) && file_exists($settings['favicon_path'])) {
            $faviconPath = getWebImageUrl($settings['favicon_path']);
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=yes">
            <title><?= htmlspecialchars($title) ?> - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
            <?php if ($faviconPath): ?>
            <link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>">
            <link rel="shortcut icon" href="<?= $faviconPath ?>">
            <?php endif; ?>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
            <style>
                body { font-family: 'Inter', sans-serif; background: #f0f2f5; }
                .navbar-custom { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
                .card { border: none; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); }
                .btn-primary { background: linear-gradient(135deg, #1e3c72, #2a5298); border: none; }
                .member-photo, .book-cover-preview { border-radius: 8px; object-fit: cover; }
                @media (max-width: 768px) {
                    .container-fluid { padding: 10px; }
                    h2 { font-size: 1.5rem; }
                    .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
                    .quick-modules { grid-template-columns: repeat(2, 1fr); gap: 10px; }
                    .stat-value { font-size: 24px; }
                    .modal-dialog { margin: 10px; }
                    .btn, button { min-height: 44px; }
                    .table-responsive-wrapper { overflow-x: auto; }
                }
                @media (max-width: 480px) {
                    .stats-grid { grid-template-columns: 1fr; }
                    .quick-modules { grid-template-columns: 1fr; }
                }
            </style>
        </head>
        <body>
        <?php
    }
}

if (!function_exists('renderFooter')) {
    function renderFooter(): void {
        echo '
        <footer class="text-center mt-4 py-3 border-top" style="font-size: 0.85rem; color: #6c757d;">
            <span>Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer" style="color: #1e3c72; text-decoration: none;">Sameermon</a></span>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        </body></html>';
    }
}

// ============================================================================
// EXCEPTION HANDLER
// ============================================================================

if (!function_exists('handleException')) {
    function handleException(Throwable $exception): void {
        error_log("Uncaught Exception: " . $exception->getMessage() . " in " . $exception->getFile() . ":" . $exception->getLine());
        if (php_sapi_name() === 'cli') {
            echo "Error: " . $exception->getMessage() . "\n";
        } else {
            if (str_contains($_SERVER['REQUEST_URI'] ?? '', '/api/')) {
                sendJsonError("Internal server error: " . $exception->getMessage(), 500);
            } else {
                die("An error occurred. Please try again later.");
            }
        }
    }
}
set_exception_handler('handleException');

// ============================================================================
// SESSION START
// ============================================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================================================
// BOOK EXIT LOGGING & DETECTION
// ============================================================================

if (!function_exists('logBookExit')) {
    /**
     * Log a book exit event
     * @param string $barcode Book barcode
     * @param bool $isAuthorized Whether the book is currently issued (authorized exit)
     * @param string|null $memberAdmno Member admission number (if linked)
     * @param string|null $memberName Member name (if linked)
     * @param string|null $photoPath Path to captured photo (optional)
     * @param string $notes Additional notes
     * @return bool Success
     */
    function logBookExit(string $barcode, bool $isAuthorized, ?string $memberAdmno = null, ?string $memberName = null, ?string $photoPath = null, string $notes = ''): bool {
        $db = getDB();
        // Get book details
        $bookStmt = $db->prepare("SELECT title, author FROM books WHERE barcode = ?");
        $bookStmt->execute([$barcode]);
        $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
        if (!$book) {
            error_log("logBookExit: Book not found for barcode $barcode");
            return false;
        }
        $stmt = $db->prepare("INSERT INTO book_exit_logs (book_barcode, book_title, book_author, member_admno, member_name, is_authorized, photo_path, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([
            $barcode,
            $book['title'],
            $book['author'] ?? '',
            $memberAdmno,
            $memberName,
            $isAuthorized ? 1 : 0,
            $photoPath,
            $notes
        ]);
    }
}

if (!function_exists('isBookIssued')) {
    /**
     * Check if a book is currently issued (not returned)
     * @param string $barcode Book barcode
     * @return array|false Loan details if issued, false otherwise
     */
    function isBookIssued(string $barcode): array|false {
        $db = getDB();
        $stmt = $db->prepare("SELECT admno, member_name, issue_date, due_date FROM circulation WHERE barcode = ? AND return_date IS NULL LIMIT 1");
        $stmt->execute([$barcode]);
        $loan = $stmt->fetch(PDO::FETCH_ASSOC);
        return $loan ?: false;
    }
}

if (!function_exists('getBookExitLogs')) {
    /**
     * Retrieve book exit logs with pagination
     * @param int $limit Number of records
     * @param int $offset Offset for pagination
     * @return array Log entries
     */
    function getBookExitLogs(int $limit = 100, int $offset = 0): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM book_exit_logs ORDER BY created_at DESC LIMIT ? OFFSET ?");
        $stmt->execute([$limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('getUnauthorizedBookExits')) {
    /**
     * Get unauthorized book exits (is_authorized = 0)
     * @param int $limit Number of records
     * @return array Unauthorized exit logs
     */
    function getUnauthorizedBookExits(int $limit = 100): array {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM book_exit_logs WHERE is_authorized = 0 ORDER BY created_at DESC LIMIT ?");
        $stmt->execute([$limit]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

if (!function_exists('sendBookExitAlert')) {
    /**
     * Send an alert email for unauthorized book exit
     * @param string $barcode Book barcode
     * @param string $title Book title
     * @param string|null $memberAdmno Linked member admission number
     * @param string|null $memberName Linked member name
     */
    function sendBookExitAlert(string $barcode, string $title, ?string $memberAdmno = null, ?string $memberName = null): void {
        $settings = getSettings();
        $adminEmail = $settings['backup_email'] ?? '';
        if (empty($adminEmail)) return;
        $subject = "🚨 UNAUTHORIZED BOOK EXIT: $title";
        $message = "Book: $title\nBarcode: $barcode\nTime: " . date('Y-m-d H:i:s') . "\n";
        if ($memberName) {
            $message .= "Linked Member: $memberName ($memberAdmno)\n";
        } else {
            $message .= "No member linked.\n";
        }
        $message .= "Please investigate immediately.";
        queueEmail($adminEmail, $subject, $message);
    }
}

// ============================================================================
// END OF FILE
// ============================================================================