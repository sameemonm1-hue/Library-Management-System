<?php
declare(strict_types=1);

// ==================== CONFIGURATION ====================
define('BASE_PATH', dirname(__DIR__));
define('DB_FILE', BASE_PATH . '/library_erp.db');
define('UPLOAD_DIR', BASE_PATH . '/uploads/');
define('MEMBER_PHOTO_DIR', UPLOAD_DIR . 'members/');
define('BOOK_COVER_DIR', UPLOAD_DIR . 'books/');
define('LOGO_DIR', UPLOAD_DIR . 'logos/');
define('BACKUP_DIR', BASE_PATH . '/backups/');
define('EBOOK_DIR', UPLOAD_DIR . 'ebooks/');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_TIME', 900);
define('ADMIN_SESSION_TIMEOUT', 1800);

// ==================== ADDITIONAL CONSTANTS ====================
if (!defined('REPORT_TEMP_DIR')) {
    define('REPORT_TEMP_DIR', BASE_PATH . '/temp/reports/');
}
if (!defined('IMPORT_LOG_DIR')) {
    define('IMPORT_LOG_DIR', BASE_PATH . '/logs/imports/');
}
if (!defined('TEMP_IMPORT_DIR')) {
    define('TEMP_IMPORT_DIR', BASE_PATH . '/temp_imports/');
}
if (!defined('CACHE_DIR')) {
    define('CACHE_DIR', BASE_PATH . '/cache/');
}
if (!defined('SIGNATURE_DIR')) {
    define('SIGNATURE_DIR', UPLOAD_DIR . 'signatures/');
}
if (!defined('MAX_BULK_OPERATIONS')) {
    define('MAX_BULK_OPERATIONS', 1000);
}
if (!defined('SEARCH_RESULTS_LIMIT')) {
    define('SEARCH_RESULTS_LIMIT', 100);
}

// Create required directories
foreach ([
    MEMBER_PHOTO_DIR, BOOK_COVER_DIR, LOGO_DIR, BACKUP_DIR, EBOOK_DIR,
    REPORT_TEMP_DIR, IMPORT_LOG_DIR, TEMP_IMPORT_DIR, CACHE_DIR, SIGNATURE_DIR
] as $dir) {
    if (!is_dir($dir)) mkdir($dir, 0777, true);
}

// ==================== DATABASE CLASS ====================
class Database {
    private static $instance = null;
    private $db;
    private $schemaVersion = 15; // Upgraded from 14 with new utilities

    private function __construct() {
        try {
            $this->db = new PDO("sqlite:" . DB_FILE);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $this->db->exec("PRAGMA foreign_keys = ON");
            $this->applyPerformancePragmas();
            $this->initializeSchema();
            $this->ensureMemberPasswords();
            $this->ensureLoansRenewalsColumn();
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    private function applyPerformancePragmas(): void {
        $this->db->exec("PRAGMA journal_mode = WAL");
        $this->db->exec("PRAGMA synchronous = NORMAL");
        $this->db->exec("PRAGMA cache_size = -20000");
        $this->db->exec("PRAGMA mmap_size = 268435456");
        $this->db->exec("PRAGMA temp_store = MEMORY");
        $this->db->exec("PRAGMA busy_timeout = 5000");
        $this->db->exec("PRAGMA case_sensitive_like = OFF");
    }

    public static function getInstance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    public function getConnection() {
        return $this->db;
    }

    /**
     * Close the database connection to release file locks.
     * This is essential before performing a restore or any operation
     * that requires exclusive access to the database file.
     */
    public function closeConnection(): void {
        $this->db = null;
    }

    /**
     * Re‑establish the database connection after it has been closed.
     * This is used after a restore to reconnect to the new database.
     */
    public function reconnect(): void {
        // Close any existing connection (should already be null)
        $this->db = null;
        // Re‑open using the same parameters as the constructor
        try {
            $this->db = new PDO("sqlite:" . DB_FILE);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $this->db->exec("PRAGMA foreign_keys = ON");
            $this->applyPerformancePragmas();
        } catch (PDOException $e) {
            throw new RuntimeException("Failed to reconnect to database: " . $e->getMessage());
        }
    }

    /**
     * Ensure the database schema is at the latest version by running migrations if needed.
     * This is essential after restoring an old backup.
     */
    public function upgradeSchemaIfNeeded(): void {
        // Close and reopen to get a clean state
        $this->closeConnection();
        $this->reconnect();
        // Run the schema initialization (this checks version and applies migrations)
        $this->initializeSchema();
    }

    public function optimizeDatabase(): void {
        $this->db->exec("PRAGMA optimize");
        $this->db->exec("ANALYZE");
        $this->db->exec("PRAGMA wal_checkpoint(TRUNCATE)");
    }

    public function updateSetting($key, $value) {
        $stmt = $this->db->prepare("UPDATE settings SET $key = ? WHERE id = 1");
        $stmt->execute([$value]);
        return true;
    }

    public function runScheduledTasks() {
        $this->optimizeDatabase();
        updateDailyStats();
        runOverdueNotifications();
        processEmailQueue(20);
        $this->processScheduledJobs();
        return true;
    }

    // ========== PRESERVED ORIGINAL METHODS ==========
    private function ensureMemberPasswords(): void {
        try {
            $this->db->exec("ALTER TABLE members ADD COLUMN password TEXT DEFAULT ''");
        } catch (PDOException $e) {}
        $defaultHash = password_hash('123456', PASSWORD_DEFAULT);
        $stmt = $this->db->prepare("UPDATE members SET password = ? WHERE password IS NULL OR password = ''");
        $stmt->execute([$defaultHash]);
    }

    private function ensureLoansRenewalsColumn(): void {
        try {
            $this->db->exec("ALTER TABLE loans ADD COLUMN renewals INTEGER DEFAULT 0");
        } catch (PDOException $e) {}
    }

    // ========== SCHEMA INITIALIZATION ==========
    private function initializeSchema() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY, applied_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $currentVersion = (int)$db->query("SELECT MAX(version) FROM schema_version")->fetchColumn();
        $tableExists = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")->fetch();
        if ($currentVersion === 0 && !$tableExists) {
            $this->createAllTables();
            $this->createFTS5Tables();
            $this->createSessionTables();
            $this->createIndexes();
            $this->insertDefaultData();
            $db->exec("INSERT INTO schema_version (version) VALUES ({$this->schemaVersion})");
            $db->exec("PRAGMA optimize");
        } elseif ($currentVersion === 0 && $tableExists) {
            $db->exec("INSERT INTO schema_version (version) VALUES ({$this->schemaVersion})");
            $this->runMigrations(0);
            $db->exec("PRAGMA optimize");
        } elseif ($currentVersion < $this->schemaVersion) {
            $this->runMigrations($currentVersion);
            $db->exec("INSERT INTO schema_version (version) VALUES ({$this->schemaVersion})");
            $db->exec("PRAGMA optimize");
        }
    }

    // ========== CREATE ALL TABLES (MERGED) ==========
    private function createAllTables() {
        $db = $this->db;
        // Core tables (preserved and enhanced)
        $db->exec("CREATE TABLE IF NOT EXISTS activity_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, action TEXT NOT NULL, details TEXT, ip_address TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS institutions(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, address TEXT, contact TEXT, email TEXT, logo_path TEXT, status TEXT DEFAULT 'active', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, fullname TEXT NOT NULL, email TEXT, role TEXT DEFAULT 'staff', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, last_login DATETIME, login_attempts INTEGER DEFAULT 0, locked_until DATETIME, token_version INTEGER DEFAULT 1, export_count INTEGER DEFAULT 0, totp_secret TEXT DEFAULT '', totp_enabled INTEGER DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT UNIQUE NOT NULL, name TEXT NOT NULL, member_category TEXT DEFAULT 'Student', class TEXT, division TEXT, roll_no TEXT, email TEXT, phone TEXT, parent_phone TEXT, address TEXT, dob DATE, gender TEXT, blood_group TEXT, admission_date DATE DEFAULT CURRENT_DATE, photo_path TEXT, active_books INTEGER DEFAULT 0, total_issued INTEGER DEFAULT 0, total_fines REAL DEFAULT 0, notes TEXT, status TEXT DEFAULT 'active', password TEXT DEFAULT '', reset_token TEXT DEFAULT '', token_expiry DATETIME, security_deposit REAL DEFAULT 0, membership_expiry DATE, total_paid_fines REAL DEFAULT 0, emergency_contact TEXT DEFAULT '', general_id TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, is_email_verified INTEGER DEFAULT 0, verification_token TEXT DEFAULT '', verification_expiry DATETIME, approval_status TEXT DEFAULT 'pending', designation TEXT DEFAULT '')");
        $db->exec("CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT UNIQUE NOT NULL, call_number TEXT, isbn TEXT, title TEXT NOT NULL, sub_title TEXT DEFAULT '', author TEXT, author2 TEXT DEFAULT '', collaborator TEXT DEFAULT '', subject TEXT DEFAULT '', keyword TEXT, category TEXT, sub_category TEXT, publisher TEXT, publisher_place TEXT DEFAULT '', edition TEXT, year TEXT, pages INTEGER, language TEXT DEFAULT 'English', location TEXT, summary TEXT, description TEXT DEFAULT '', cover_path TEXT, quantity INTEGER DEFAULT 1, available INTEGER DEFAULT 1, price REAL DEFAULT 0, price_currency TEXT DEFAULT 'INR', replacement_cost REAL DEFAULT 0, accession_number TEXT DEFAULT '', total_lost INTEGER DEFAULT 0, item_category TEXT DEFAULT '', remarks TEXT DEFAULT '', status TEXT DEFAULT 'Available', book_status TEXT DEFAULT 'Available', binding TEXT DEFAULT '', holding TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, maintenance TEXT DEFAULT '', current_location TEXT DEFAULT '', section TEXT DEFAULT '', ddc TEXT DEFAULT '', udc TEXT DEFAULT '', lcc TEXT DEFAULT '', cutter TEXT DEFAULT '', series TEXT DEFAULT '', volume TEXT DEFAULT '', corporate_author TEXT DEFAULT '', conference_author TEXT DEFAULT '', issn TEXT DEFAULT '', illustrations TEXT DEFAULT '', dimensions TEXT DEFAULT '', country TEXT DEFAULT '', collection_type TEXT DEFAULT '', branch TEXT DEFAULT '', shelf TEXT DEFAULT '', vendor TEXT DEFAULT '', invoice TEXT DEFAULT '', invoice_date DATE, acquisition_date DATE, funding_source TEXT DEFAULT '', po_number TEXT DEFAULT '', ebook_url TEXT DEFAULT '', contents TEXT DEFAULT '', accompanying_material TEXT DEFAULT '', material_type TEXT DEFAULT '', size TEXT DEFAULT '', weight TEXT DEFAULT '', cc TEXT DEFAULT '', other_classification TEXT DEFAULT '')");
        $db->exec("CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL, member_id INTEGER NOT NULL, issue_date DATE NOT NULL, due_date DATE NOT NULL, return_date DATE, status TEXT DEFAULT 'issued' CHECK(status IN ('issued','returned','overdue')), created_at DATETIME DEFAULT CURRENT_TIMESTAMP, renewals INTEGER DEFAULT 0, FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE, FOREIGN KEY(member_id) REFERENCES members(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS circulation(id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, member_name TEXT NOT NULL, class TEXT, division TEXT, barcode TEXT, isbn TEXT, title TEXT, author TEXT, category TEXT, publisher TEXT, issue_date DATE NOT NULL, due_date DATE NOT NULL, return_date DATE, fine REAL DEFAULT 0, notes TEXT, is_manual INTEGER DEFAULT 0, renew_count INTEGER DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_payments(id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER, admno TEXT NOT NULL, amount REAL NOT NULL, payment_date DATE NOT NULL, payment_method TEXT DEFAULT 'cash' CHECK(payment_method IN ('cash','card','online','cheque')), receipt_no TEXT UNIQUE, status TEXT DEFAULT 'paid' CHECK(status IN ('paid','refunded','pending')), notes TEXT, collected_by TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(circulation_id) REFERENCES circulation(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS overdue_notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER NOT NULL, admno TEXT NOT NULL, notification_type TEXT CHECK(notification_type IN ('email','sms','whatsapp')), days_overdue INTEGER, sent_at DATETIME DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'sent', response TEXT, FOREIGN KEY(circulation_id) REFERENCES circulation(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, total_fine REAL NOT NULL, amount_paid REAL DEFAULT 0, amount_waived REAL DEFAULT 0, settlement_date DATE, settled_by TEXT, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS ebooks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, author TEXT, subject TEXT, isbn TEXT, publisher TEXT, year TEXT, description TEXT, cover_path TEXT, file_path TEXT NOT NULL, file_size INTEGER, downloads INTEGER DEFAULT 0, full_text TEXT, cloud_file_id TEXT DEFAULT '', storage_type TEXT DEFAULT 'local', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS entry_exit(id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, member_name TEXT NOT NULL, member_category TEXT, entry_date DATE NOT NULL, entry_time TIME NOT NULL, exit_time TIME, purpose TEXT, status TEXT DEFAULT 'inside', notes TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS stock_verification(id INTEGER PRIMARY KEY AUTOINCREMENT, book_barcode TEXT NOT NULL, expected_status TEXT, actual_status TEXT, verified_date DATE, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS notices(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS book_holds(id INTEGER PRIMARY KEY AUTOINCREMENT, book_barcode TEXT NOT NULL, admno TEXT NOT NULL, member_name TEXT NOT NULL, hold_date DATE NOT NULL, expiry_date DATE NOT NULL, status TEXT DEFAULT 'pending', notified INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS daily_stats(id INTEGER PRIMARY KEY AUTOINCREMENT, stat_date DATE UNIQUE NOT NULL, books_issued INTEGER DEFAULT 0, books_returned INTEGER DEFAULT 0, members_registered INTEGER DEFAULT 0, fines_collected REAL DEFAULT 0, entries_count INTEGER DEFAULT 0, exits_count INTEGER DEFAULT 0, ebook_downloads INTEGER DEFAULT 0, new_books_added INTEGER DEFAULT 0, active_loans INTEGER DEFAULT 0, overdue_count INTEGER DEFAULT 0, total_outstanding_fines REAL DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS opac_reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, book_barcode TEXT NOT NULL, reviewer_name TEXT NOT NULL, rating INTEGER DEFAULT 5, comment TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS search_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, keyword TEXT NOT NULL, book_barcode TEXT, book_title TEXT, search_type TEXT DEFAULT 'books', user_ip TEXT, user_agent TEXT, session_id TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS suggestions(id INTEGER PRIMARY KEY AUTOINCREMENT, member_admno TEXT NOT NULL, member_name TEXT, title TEXT NOT NULL, author TEXT, isbn TEXT, reason TEXT, status TEXT DEFAULT 'pending', admin_notes TEXT, institution_id INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS user_preferences(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, preference_key TEXT NOT NULL, preference_value TEXT, UNIQUE(user_id, preference_key))");
        $db->exec("CREATE TABLE IF NOT EXISTS quick_actions(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, icon_class TEXT NOT NULL, link_url TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS login_cards(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, icon_class TEXT NOT NULL DEFAULT 'fas fa-info-circle', link_url TEXT NOT NULL DEFAULT '#', sort_order INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS staff_profiles(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, designation TEXT NOT NULL, photo_path TEXT DEFAULT '', sort_order INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS research_databases(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT, url TEXT NOT NULL, category TEXT, type TEXT DEFAULT 'academic' CHECK(type IN ('academic', 'open_access', 'subscription')), icon TEXT DEFAULT 'database', is_featured INTEGER DEFAULT 0, sort_order INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME, logo_path TEXT DEFAULT '', subjects TEXT DEFAULT '', expiry_date DATE, last_verified DATE, visits INTEGER DEFAULT 0, proxy_url TEXT DEFAULT '', access_notes TEXT DEFAULT '', contact_email TEXT DEFAULT '', deleted_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS research_database_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, database_id INTEGER NOT NULL, user_id INTEGER, user_type TEXT CHECK(user_type IN ('member','admin','guest')), action TEXT CHECK(action IN ('access','search','download')), search_query TEXT, ip_address TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(database_id) REFERENCES research_databases(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS rate_limits(id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT, endpoint TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK (id = 1), loan_days INTEGER DEFAULT 7, fine_per_day REAL DEFAULT 2, max_books INTEGER DEFAULT 5, menu_position TEXT DEFAULT 'top', software_header TEXT DEFAULT 'Library ERP System', library_logo TEXT DEFAULT '', favicon_path TEXT DEFAULT '', backup_email TEXT, notify_overdue BOOLEAN DEFAULT 1, auto_logout_minutes INTEGER DEFAULT 30, new_arrivals_count INTEGER DEFAULT 10, enable_sms BOOLEAN DEFAULT 0, sms_api_key TEXT, enable_email BOOLEAN DEFAULT 1, backup_password TEXT, opac_enabled BOOLEAN DEFAULT 1, allow_holds BOOLEAN DEFAULT 1, hold_days INTEGER DEFAULT 7, google_drive_enabled BOOLEAN DEFAULT 0, google_drive_folder_id TEXT, google_drive_client_id TEXT DEFAULT '', google_drive_client_secret TEXT DEFAULT '', google_drive_refresh_token TEXT DEFAULT '', smtp_host TEXT DEFAULT '', smtp_port INTEGER DEFAULT 587, smtp_encryption TEXT DEFAULT 'tls', smtp_username TEXT DEFAULT '', smtp_password TEXT DEFAULT '', mail_from TEXT DEFAULT '', mail_from_name TEXT DEFAULT '', backup_schedule TEXT DEFAULT 'daily', backup_time TEXT DEFAULT '00:00', current_institution_id INTEGER DEFAULT 1, opac_show_new_arrivals INTEGER DEFAULT 1, opac_show_popular_ebooks INTEGER DEFAULT 1, opac_show_latest_ebooks INTEGER DEFAULT 1, opac_show_notices INTEGER DEFAULT 1, opac_show_trending INTEGER DEFAULT 1, opac_show_databases INTEGER DEFAULT 1, opac_header_text TEXT DEFAULT '', opac_tagline TEXT DEFAULT '', opac_books_per_page INTEGER DEFAULT 12, opac_ebooks_per_page INTEGER DEFAULT 8, image_base_path TEXT DEFAULT 'uploads/', enable_whatsapp BOOLEAN DEFAULT 0, whatsapp_api_key TEXT DEFAULT '', whatsapp_phone_number TEXT DEFAULT '', whatsapp_api_url TEXT DEFAULT '', right_logo_path TEXT DEFAULT '', opac_notice_title TEXT DEFAULT '', opac_notice_content TEXT DEFAULT '', max_fine_amount REAL DEFAULT 0, enable_self_registration BOOLEAN DEFAULT 0, self_registration_role TEXT DEFAULT 'Student', email_template_overdue TEXT, sms_template_overdue TEXT, whatsapp_template_overdue TEXT, enable_member_password_reset INTEGER DEFAULT 1, reset_token_expiry_hours INTEGER DEFAULT 24, allow_member_password_change INTEGER DEFAULT 1, cloud_storage_provider TEXT DEFAULT 'local', cloud_api_key TEXT DEFAULT '', cloud_api_secret TEXT DEFAULT '', cloud_refresh_token TEXT DEFAULT '', cloud_folder_id TEXT DEFAULT '', google_drive_service_account_json TEXT DEFAULT '', last_export DATETIME DEFAULT NULL, currency_code TEXT DEFAULT 'USD', currency_symbol TEXT DEFAULT '$', currency_position TEXT DEFAULT 'left', opac_header_logo TEXT DEFAULT '', login_bg_color TEXT DEFAULT '#667eea', login_text_color TEXT DEFAULT '#ffffff', login_header_logo TEXT DEFAULT '', login_font_family TEXT DEFAULT 'Inter', login_base_font_size INTEGER DEFAULT 16, staff_display_enabled INTEGER DEFAULT 1, staff_card_bg_color TEXT DEFAULT '#ffffff', currency_decimal_places INT DEFAULT 2, guest_enabled INT DEFAULT 1, guest_prefix VARCHAR(20) DEFAULT 'GUEST-', guest_number_padding INT DEFAULT 4, guest_last_reset DATE DEFAULT NULL, whatsapp_number VARCHAR(20) DEFAULT '', whatsapp_message TEXT DEFAULT 'Hello, I need assistance from the library.', fine_grace_period INTEGER DEFAULT 0, fine_calculation_method TEXT DEFAULT 'daily' CHECK(fine_calculation_method IN ('daily','hourly')), auto_waive_fine_after_return BOOLEAN DEFAULT 0, fine_reminder_days INTEGER DEFAULT 3, enable_overdue_notifications BOOLEAN DEFAULT 1, library_open_days TEXT DEFAULT '1,2,3,4,5', library_open_time TEXT DEFAULT '09:00', library_close_time TEXT DEFAULT '18:00', library_lunch_start TEXT DEFAULT '', library_lunch_end TEXT DEFAULT '', library_timezone TEXT DEFAULT 'Asia/Kolkata', container_max_width INTEGER DEFAULT 1600, container_padding INTEGER DEFAULT 10, opac_font_family TEXT DEFAULT 'Inter', opac_base_font_size INTEGER DEFAULT 16, opac_heading_font_size INTEGER DEFAULT 32, opac_primary_color TEXT DEFAULT '#1e3c72', opac_header_bg_color TEXT DEFAULT '#1e3c72', opac_body_bg TEXT DEFAULT '#f0f2f5', opac_custom_css TEXT DEFAULT '', max_renewals INTEGER DEFAULT 0, enable_audit_log INTEGER DEFAULT 1, audit_log_retention_days INTEGER DEFAULT 90, enable_member_notifications INTEGER DEFAULT 1, default_language TEXT DEFAULT 'en', site_maintenance_mode INTEGER DEFAULT 0, maintenance_message TEXT DEFAULT 'System under maintenance. Please check back later.', razorpay_key_id TEXT DEFAULT '', razorpay_key_secret TEXT DEFAULT '', session_check_ip INTEGER DEFAULT 0, max_concurrent_sessions INTEGER DEFAULT 5, visitor_header_logo TEXT DEFAULT '', visitor_header_text TEXT DEFAULT '', visitor_tagline TEXT DEFAULT 'Visitors Log', visitor_header_bg TEXT DEFAULT '#1e3c72', visitor_body_bg TEXT DEFAULT '#f0f2f5', visitor_footer_bg TEXT DEFAULT '#1e3c72', visitor_font_family TEXT DEFAULT 'Inter', visitor_base_font_size INTEGER DEFAULT 16, visitor_primary_color TEXT DEFAULT '#28a745', report_font_size INTEGER DEFAULT 10, report_primary_color TEXT DEFAULT '#1e3c72', report_logo_position TEXT DEFAULT 'left', report_logo_right TEXT DEFAULT '', report_watermark_text TEXT DEFAULT '', report_watermark_enabled INTEGER DEFAULT 0, report_watermark_opacity INTEGER DEFAULT 10, report_signature_name TEXT DEFAULT 'Librarian', report_signature_title TEXT DEFAULT 'Chief Librarian', report_signature_image TEXT DEFAULT '', report_signature_enabled INTEGER DEFAULT 0, report_footer_text TEXT DEFAULT 'This is a system generated report', opac_show_thought_of_the_day INTEGER DEFAULT 1, opac_show_new_arrivals_in_left INTEGER DEFAULT 1, opac_quote_rotation_interval INTEGER DEFAULT 10, opac_carousel_type TEXT DEFAULT 'cover_flow', openai_api_key TEXT DEFAULT '', google_drive_auto_delete_days INTEGER DEFAULT 30, google_drive_last_cleanup TEXT DEFAULT '', dropbox_access_token TEXT DEFAULT '', dropbox_app_key TEXT DEFAULT '', dropbox_app_secret TEXT DEFAULT '', dropbox_refresh_token TEXT DEFAULT '', onedrive_client_id TEXT DEFAULT '', onedrive_client_secret TEXT DEFAULT '', onedrive_refresh_token TEXT DEFAULT '', pcloud_enabled INTEGER DEFAULT 0, pcloud_access_token TEXT DEFAULT '', pcloud_username TEXT DEFAULT '', pcloud_password_hash TEXT DEFAULT '', internxt_enabled INTEGER DEFAULT 0, internxt_api_key TEXT DEFAULT '', internxt_api_secret TEXT DEFAULT '', internxt_bucket TEXT DEFAULT '', internxt_region TEXT DEFAULT '', mega_enabled INTEGER DEFAULT 0, mega_email TEXT DEFAULT '', mega_password_hash TEXT DEFAULT '', mega_folder_id TEXT DEFAULT '', sync_enabled INTEGER DEFAULT 0, sync_api_key TEXT DEFAULT '', sync_api_secret TEXT DEFAULT '', sync_folder_id TEXT DEFAULT '', terabox_enabled INTEGER DEFAULT 0, terabox_api_key TEXT DEFAULT '', terabox_api_secret TEXT DEFAULT '', terabox_folder_id TEXT DEFAULT '', backblaze_enabled INTEGER DEFAULT 0, backblaze_key_id TEXT DEFAULT '', backblaze_application_key TEXT DEFAULT '', backblaze_bucket_id TEXT DEFAULT '', backblaze_bucket_name TEXT DEFAULT '', wasabi_enabled INTEGER DEFAULT 0, wasabi_access_key TEXT DEFAULT '', wasabi_secret_key TEXT DEFAULT '', wasabi_bucket TEXT DEFAULT '', wasabi_region TEXT DEFAULT 'us-east-1', s3_enabled INTEGER DEFAULT 0, s3_access_key TEXT DEFAULT '', s3_secret_key TEXT DEFAULT '', s3_bucket TEXT DEFAULT '', s3_region TEXT DEFAULT 'us-east-1', s3_endpoint TEXT DEFAULT '', local_backup_retention INTEGER DEFAULT 30, backup_include_uploads INTEGER DEFAULT 1, backup_compress INTEGER DEFAULT 1, backup_notification_email TEXT DEFAULT '', last_backup_time DATETIME DEFAULT NULL, enable_2fa INTEGER DEFAULT 0, session_lifetime INTEGER DEFAULT 7200, failed_login_attempts INTEGER DEFAULT 5, lockout_time INTEGER DEFAULT 15, cookie_secure INTEGER DEFAULT 0, cookie_httponly INTEGER DEFAULT 1, gdpr_enabled INTEGER DEFAULT 0, gdpr_consent_text TEXT DEFAULT '', api_keys TEXT DEFAULT '', custom_css_admin TEXT DEFAULT '', admin_dark_mode INTEGER DEFAULT 0, maintenance_whitelist_ips TEXT DEFAULT '', smtp_timeout INTEGER DEFAULT 30, backup_encryption INTEGER DEFAULT 0, ftp_backup_enabled INTEGER DEFAULT 0, ftp_host TEXT DEFAULT '', ftp_username TEXT DEFAULT '', ftp_password TEXT DEFAULT '', ftp_path TEXT DEFAULT '', sftp_backup_enabled INTEGER DEFAULT 0, sftp_host TEXT DEFAULT '', sftp_username TEXT DEFAULT '', sftp_password TEXT DEFAULT '', sftp_port INTEGER DEFAULT 22, sftp_path TEXT DEFAULT '', webdav_backup_enabled INTEGER DEFAULT 0, webdav_url TEXT DEFAULT '', webdav_username TEXT DEFAULT '', webdav_password TEXT DEFAULT '', backup_retention_days_cloud INTEGER DEFAULT 90, auto_cleanup_temp INTEGER DEFAULT 1, system_health_checks INTEGER DEFAULT 1, opac_social_facebook TEXT DEFAULT '', opac_social_twitter TEXT DEFAULT '', opac_social_instagram TEXT DEFAULT '', opac_custom_html_header TEXT DEFAULT '', opac_custom_html_footer TEXT DEFAULT '', fine_rule_based_on_material INTEGER DEFAULT 0, fine_grace_period_holidays INTEGER DEFAULT 0, notification_bcc_email TEXT DEFAULT '', member_registration_approval INTEGER DEFAULT 0, default_member_expiry_days INTEGER DEFAULT 365, enable_email_verification INTEGER DEFAULT 0, email_verification_subject TEXT DEFAULT '', email_verification_body TEXT DEFAULT '', enable_multi_branch INTEGER DEFAULT 0, enable_budgeting INTEGER DEFAULT 0, enable_interlibrary INTEGER DEFAULT 0, enable_course_reserves INTEGER DEFAULT 0, digital_asset_tracking INTEGER DEFAULT 0, detailed_audit_log INTEGER DEFAULT 0, auto_scheduled_jobs INTEGER DEFAULT 1)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_rates(id INTEGER PRIMARY KEY AUTOINCREMENT, member_category TEXT UNIQUE NOT NULL, fine_per_day REAL NOT NULL DEFAULT 2, max_fine REAL DEFAULT 0, grace_period_days INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS module_permissions(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, module_key TEXT NOT NULL, can_access INTEGER DEFAULT 1, UNIQUE(role, module_key))");
        $db->exec("CREATE TABLE IF NOT EXISTS payment_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, member_admno TEXT NOT NULL, amount REAL NOT NULL, payment_type TEXT CHECK(payment_type IN ('fine','deposit','lost_fee','donation','membership_fee')) NOT NULL, reference_id TEXT, related_circulation_id INTEGER, payment_date DATETIME DEFAULT CURRENT_TIMESTAMP, payment_method TEXT DEFAULT 'cash', receipt_no TEXT UNIQUE, notes TEXT, created_by TEXT, currency TEXT DEFAULT 'INR', FOREIGN KEY(related_circulation_id) REFERENCES circulation(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS reservations_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, book_barcode TEXT NOT NULL, admno TEXT NOT NULL, member_name TEXT NOT NULL, priority INTEGER DEFAULT 1, requested_date DATE NOT NULL, expiry_date DATE NOT NULL, status TEXT DEFAULT 'waiting' CHECK(status IN ('waiting','notified','borrowed','expired','cancelled')), notified_at DATETIME, processed_at DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS library_events(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT, event_date DATE NOT NULL, start_time TIME, end_time TIME, venue TEXT, max_attendees INTEGER, registration_required BOOLEAN DEFAULT 1, status TEXT DEFAULT 'upcoming' CHECK(status IN ('upcoming','ongoing','completed','cancelled')), created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS event_attendees(id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL, member_admno TEXT NOT NULL, check_in_time DATETIME, attended BOOLEAN DEFAULT 0, feedback TEXT, FOREIGN KEY(event_id) REFERENCES library_events(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS vendors(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, contact_person TEXT, email TEXT, phone TEXT, address TEXT, gst_no TEXT, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS purchase_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, order_no TEXT UNIQUE NOT NULL, vendor_id INTEGER, order_date DATE NOT NULL, expected_delivery DATE, status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','shipped','received','cancelled')), total_amount REAL, notes TEXT, created_by TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(vendor_id) REFERENCES vendors(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS purchase_order_items(id INTEGER PRIMARY KEY AUTOINCREMENT, po_id INTEGER NOT NULL, book_title TEXT NOT NULL, isbn TEXT, author TEXT, quantity INTEGER DEFAULT 1, unit_price REAL, received_quantity INTEGER DEFAULT 0, FOREIGN KEY(po_id) REFERENCES purchase_orders(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS lost_books(id INTEGER PRIMARY KEY AUTOINCREMENT, book_barcode TEXT NOT NULL, admno TEXT NOT NULL, circulation_id INTEGER, loss_date DATE NOT NULL, declared_lost_by TEXT, replacement_cost REAL, amount_paid REAL DEFAULT 0, replacement_book_barcode TEXT DEFAULT '', status TEXT DEFAULT 'pending' CHECK(status IN ('pending','paid','waived')), notes TEXT, currency TEXT DEFAULT 'INR', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(circulation_id) REFERENCES circulation(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS member_documents(id INTEGER PRIMARY KEY AUTOINCREMENT, member_admno TEXT NOT NULL, document_type TEXT NOT NULL, file_path TEXT NOT NULL, expiry_date DATE, uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP, verified BOOLEAN DEFAULT 0, verified_by TEXT, notes TEXT)");
        $db->exec("CREATE TABLE IF NOT EXISTS session_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user_type TEXT CHECK(user_type IN ('admin','member')), username TEXT NOT NULL, session_id TEXT, login_time DATETIME DEFAULT CURRENT_TIMESTAMP, logout_time DATETIME, ip_address TEXT, user_agent TEXT)");
        $db->exec("CREATE TABLE IF NOT EXISTS notification_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, recipient_type TEXT DEFAULT 'member' CHECK(recipient_type IN ('member', 'admin', 'staff')), recipient TEXT NOT NULL, notification_type TEXT NOT NULL, subject TEXT, message TEXT, channel TEXT CHECK(channel IN ('email', 'sms', 'whatsapp', 'push')), status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'sent', 'failed')), sent_at DATETIME, error_message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS serial_vendors(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, contact_person TEXT, email TEXT, phone TEXT, address TEXT, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS serial_subscriptions(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, issn TEXT, frequency TEXT CHECK(frequency IN ('daily','weekly','biweekly','monthly','bimonthly','quarterly','halfyearly','yearly')) NOT NULL, vendor_id INTEGER, start_date DATE NOT NULL, end_date DATE, cost REAL, location TEXT, routing_list TEXT, notes TEXT, status TEXT DEFAULT 'active' CHECK(status IN ('active','expired','cancelled')), subscription_type TEXT DEFAULT 'print', access_url TEXT DEFAULT '', access_credentials TEXT DEFAULT '', digital_format TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(vendor_id) REFERENCES serial_vendors(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS serial_issues(id INTEGER PRIMARY KEY AUTOINCREMENT, subscription_id INTEGER NOT NULL, volume TEXT, issue_number TEXT NOT NULL, date_published DATE, date_received DATE, status TEXT DEFAULT 'expected' CHECK(status IN ('expected','received','claimed','missing','late')), notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(subscription_id) REFERENCES serial_subscriptions(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS serial_reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, subscription_id INTEGER NOT NULL, issue_id INTEGER, reminder_type TEXT DEFAULT 'missing_issue', sent_to TEXT NOT NULL, subject TEXT, message TEXT, sent_at DATETIME DEFAULT CURRENT_TIMESTAMP, opened_at DATETIME, clicked_at DATETIME, FOREIGN KEY(subscription_id) REFERENCES serial_subscriptions(id), FOREIGN KEY(issue_id) REFERENCES serial_issues(id))");
        $db->exec("CREATE TABLE IF NOT EXISTS computers(id INTEGER PRIMARY KEY AUTOINCREMENT, computer_name TEXT NOT NULL, ip_address TEXT, location TEXT, status TEXT DEFAULT 'active' CHECK(status IN ('active','maintenance','offline')), notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS computer_policies(id INTEGER PRIMARY KEY AUTOINCREMENT, user_role TEXT NOT NULL UNIQUE, max_minutes_per_day INTEGER DEFAULT 60, max_minutes_per_week INTEGER DEFAULT 240, max_sessions_per_week INTEGER DEFAULT 3, require_attendance BOOLEAN DEFAULT 1, weekly_attendance_required INTEGER DEFAULT 1)");
        $db->exec("CREATE TABLE IF NOT EXISTS computer_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, computer_id INTEGER NOT NULL, member_id INTEGER NOT NULL, login_time DATETIME NOT NULL, logout_time DATETIME, duration_minutes INTEGER DEFAULT 0, FOREIGN KEY(computer_id) REFERENCES computers(id), FOREIGN KEY(member_id) REFERENCES members(id))");
        $db->exec("CREATE TABLE IF NOT EXISTS computer_attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL, week_start_date DATE NOT NULL, sessions_count INTEGER DEFAULT 0, total_minutes INTEGER DEFAULT 0, compliant BOOLEAN DEFAULT 0, UNIQUE(member_id, week_start_date), FOREIGN KEY(member_id) REFERENCES members(id))");
        $db->exec("CREATE TABLE IF NOT EXISTS export_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, username TEXT NOT NULL, export_type TEXT NOT NULL CHECK(export_type IN ('pdf','excel','csv')), report_name TEXT NOT NULL, filters TEXT, file_size INTEGER, status TEXT DEFAULT 'success', error_message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id))");
        $db->exec("CREATE TABLE IF NOT EXISTS report_generations(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, report_type TEXT NOT NULL, period_start DATE, period_end DATE, duration_ms INTEGER, rows_generated INTEGER, status TEXT DEFAULT 'completed', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS email_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, to_email TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL, alt_body TEXT, priority INTEGER DEFAULT 0, attempts INTEGER DEFAULT 0, last_attempt DATETIME, status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed')), error TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS loan_rules (id INTEGER PRIMARY KEY AUTOINCREMENT, patron_category TEXT NOT NULL, item_category TEXT NOT NULL, max_loans INTEGER NOT NULL DEFAULT 5, loan_period INTEGER NOT NULL DEFAULT 14, renewals_allowed INTEGER NOT NULL DEFAULT 1, fine_per_day REAL NOT NULL DEFAULT 1.00, grace_period INTEGER NOT NULL DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_charges (id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER NOT NULL, member_id INTEGER NOT NULL, member_admno TEXT NOT NULL, amount REAL NOT NULL, days_overdue INTEGER NOT NULL, charge_date DATE NOT NULL, status TEXT DEFAULT 'pending' CHECK(status IN ('pending','paid','waived')), created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS book_recommendations (id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL, recommended_book_id INTEGER NOT NULL, score REAL NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(book_id, recommended_book_id), FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE, FOREIGN KEY (recommended_book_id) REFERENCES books(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS faq (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, answer TEXT NOT NULL, category VARCHAR(100), keywords TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT UNIQUE NOT NULL, name TEXT NOT NULL, permissions TEXT NOT NULL DEFAULT 'read', active INTEGER DEFAULT 1, is_active INTEGER DEFAULT 1, expires_at DATETIME, last_used DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS book_suggestions (id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, name TEXT NOT NULL, title TEXT NOT NULL, author TEXT, isbn TEXT, reason TEXT NOT NULL, status TEXT DEFAULT 'pending', admin_notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME, submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, author TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS totp_recovery_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, code TEXT NOT NULL, used INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");

        // ========== ADVANCED TABLES ==========
        $db->exec("CREATE TABLE IF NOT EXISTS library_branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT UNIQUE NOT NULL, address TEXT, phone TEXT, email TEXT, manager TEXT, status TEXT DEFAULT 'active', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS budgets (id INTEGER PRIMARY KEY AUTOINCREMENT, fiscal_year TEXT NOT NULL, fund_code TEXT NOT NULL, description TEXT, total_amount REAL NOT NULL, allocated_amount REAL DEFAULT 0, expended_amount REAL DEFAULT 0, encumbered_amount REAL DEFAULT 0, status TEXT DEFAULT 'active', branch_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(branch_id) REFERENCES library_branches(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS interlibrary_loans (id INTEGER PRIMARY KEY AUTOINCREMENT, requesting_member_admno TEXT NOT NULL, requested_book_title TEXT NOT NULL, author TEXT, isbn TEXT, borrowing_institution TEXT NOT NULL, lending_institution TEXT NOT NULL, request_date DATE NOT NULL, due_date DATE, return_date DATE, status TEXT DEFAULT 'requested' CHECK(status IN ('requested','approved','shipped','received','returned','cancelled')), notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS course_reserves (id INTEGER PRIMARY KEY AUTOINCREMENT, course_name TEXT NOT NULL, course_code TEXT UNIQUE NOT NULL, instructor_name TEXT, academic_year TEXT, semester TEXT, status TEXT DEFAULT 'active', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS course_reserve_items (id INTEGER PRIMARY KEY AUTOINCREMENT, course_reserve_id INTEGER NOT NULL, book_barcode TEXT NOT NULL, title TEXT NOT NULL, author TEXT, loan_period INTEGER DEFAULT 2, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(course_reserve_id) REFERENCES course_reserves(id) ON DELETE CASCADE, FOREIGN KEY(book_barcode) REFERENCES books(barcode) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS digital_asset_usage (id INTEGER PRIMARY KEY AUTOINCREMENT, asset_type TEXT CHECK(asset_type IN ('ebook','database','research_article')) NOT NULL, asset_id INTEGER NOT NULL, member_admno TEXT NOT NULL, accessed_at DATETIME DEFAULT CURRENT_TIMESTAMP, duration INTEGER DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS audit_trail_detailed (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, table_name TEXT NOT NULL, record_id INTEGER, old_values TEXT, new_values TEXT, ip_address TEXT, user_agent TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS scheduled_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, job_name TEXT UNIQUE NOT NULL, last_run DATETIME, next_run DATETIME, status TEXT DEFAULT 'pending' CHECK(status IN ('pending','running','completed','failed')), parameters TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS notification_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, template_key TEXT UNIQUE NOT NULL, channel TEXT CHECK(channel IN ('email','sms','whatsapp','push')) NOT NULL, subject TEXT, body TEXT NOT NULL, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS budget_allocations (id INTEGER PRIMARY KEY AUTOINCREMENT, budget_id INTEGER NOT NULL, allocated_to TEXT NOT NULL, amount REAL NOT NULL, allocated_date DATE DEFAULT CURRENT_DATE, notes TEXT, FOREIGN KEY(budget_id) REFERENCES budgets(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS library_cards (id INTEGER PRIMARY KEY AUTOINCREMENT, member_admno TEXT UNIQUE NOT NULL, card_number TEXT UNIQUE NOT NULL, issue_date DATE DEFAULT CURRENT_DATE, expiry_date DATE, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(member_admno) REFERENCES members(admno) ON DELETE CASCADE)");

        // ========== WHATSAPP AND KIOSK TABLES ==========
        $db->exec("CREATE TABLE IF NOT EXISTS whatsapp_queue (id INTEGER PRIMARY KEY AUTOINCREMENT, recipient_number TEXT NOT NULL, message_text TEXT NOT NULL, priority INTEGER DEFAULT 0, status TEXT DEFAULT 'pending', retry_count INTEGER DEFAULT 0, scheduled_at DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, sent_at DATETIME, error_message TEXT)");
        $db->exec("CREATE TABLE IF NOT EXISTS kiosk_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_time DATETIME DEFAULT CURRENT_TIMESTAMP, user_id TEXT, action TEXT, details TEXT, ip_address TEXT, user_agent TEXT)");

        // ========== ENHANCED TABLES (VERSION 14+) ==========
        $db->exec("CREATE TABLE IF NOT EXISTS notification_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            user_type TEXT CHECK(user_type IN ('admin','member','staff')) NOT NULL,
            notification_type TEXT NOT NULL,
            channel TEXT CHECK(channel IN ('email','sms','whatsapp','push','in_app')) NOT NULL,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME,
            UNIQUE(user_id, user_type, notification_type, channel),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS system_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            check_name TEXT NOT NULL,
            status TEXT CHECK(status IN ('pass','fail','warning')) NOT NULL,
            message TEXT,
            details TEXT,
            checked_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS book_metadata_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            isbn TEXT UNIQUE NOT NULL,
            title TEXT,
            author TEXT,
            publisher TEXT,
            year TEXT,
            pages INTEGER,
            cover_url TEXT,
            summary TEXT,
            subjects TEXT,
            language TEXT,
            last_fetched DATETIME DEFAULT CURRENT_TIMESTAMP,
            fetch_count INTEGER DEFAULT 1
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS user_activity_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            activity_date DATE NOT NULL,
            login_count INTEGER DEFAULT 0,
            searches INTEGER DEFAULT 0,
            books_issued INTEGER DEFAULT 0,
            books_returned INTEGER DEFAULT 0,
            fines_paid REAL DEFAULT 0,
            UNIQUE(user_id, activity_date),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS circulation_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_barcode TEXT NOT NULL,
            month_year TEXT NOT NULL,
            issue_count INTEGER DEFAULT 0,
            return_count INTEGER DEFAULT 0,
            renew_count INTEGER DEFAULT 0,
            UNIQUE(book_barcode, month_year),
            FOREIGN KEY(book_barcode) REFERENCES books(barcode) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS member_reading_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_admno TEXT NOT NULL,
            preferred_categories TEXT,
            preferred_authors TEXT,
            preferred_languages TEXT,
            reading_level TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(member_admno),
            FOREIGN KEY(member_admno) REFERENCES members(admno) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS social_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            provider TEXT NOT NULL CHECK(provider IN ('google','facebook','github','microsoft','linkedin')),
            provider_user_id TEXT NOT NULL,
            email TEXT,
            avatar_url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME,
            UNIQUE(provider, provider_user_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS twofa_backup_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            code TEXT NOT NULL,
            used INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS api_rate_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            request_count INTEGER DEFAULT 1,
            reset_at DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(api_key, endpoint, reset_at)
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS search_analytics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            search_term TEXT NOT NULL,
            search_type TEXT DEFAULT 'books',
            results_count INTEGER DEFAULT 0,
            user_id INTEGER,
            user_type TEXT CHECK(user_type IN ('admin','member','guest')),
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )");

        // ========== VERSION 15 NEW TABLE ==========
        $db->exec("CREATE TABLE IF NOT EXISTS library_statistics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stat_date DATE UNIQUE NOT NULL,
            total_members INTEGER DEFAULT 0,
            total_books INTEGER DEFAULT 0,
            total_loans INTEGER DEFAULT 0,
            total_fines_collected REAL DEFAULT 0,
            active_loans INTEGER DEFAULT 0,
            overdue_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }

    // ========== FTS5 TABLES ==========
    private function createFTS5Tables() {
        $db = $this->db;
        $db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS books_fts USING fts5(title, author, subject, isbn, publisher, description, keyword, content=books, content_rowid=id, tokenize='porter unicode61')");
        $db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS members_fts USING fts5(name, admno, email, phone, address, content=members, content_rowid=id, tokenize='porter unicode61')");
        $db->exec("CREATE VIRTUAL TABLE IF NOT EXISTS circulation_fts USING fts5(title, author, member_name, admno, content=circulation, content_rowid=id, tokenize='porter unicode61')");
        // Triggers
        $db->exec("CREATE TRIGGER IF NOT EXISTS books_ai AFTER INSERT ON books BEGIN INSERT INTO books_fts(rowid, title, author, subject, isbn, publisher, description, keyword) VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keyword); END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS books_ad AFTER DELETE ON books BEGIN DELETE FROM books_fts WHERE rowid = old.id; END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS books_au AFTER UPDATE ON books BEGIN DELETE FROM books_fts WHERE rowid = old.id; INSERT INTO books_fts(rowid, title, author, subject, isbn, publisher, description, keyword) VALUES (new.id, new.title, new.author, new.subject, new.isbn, new.publisher, new.description, new.keyword); END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS members_ai AFTER INSERT ON members BEGIN INSERT INTO members_fts(rowid, name, admno, email, phone, address) VALUES (new.id, new.name, new.admno, new.email, new.phone, new.address); END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS members_ad AFTER DELETE ON members BEGIN DELETE FROM members_fts WHERE rowid = old.id; END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS members_au AFTER UPDATE ON members BEGIN DELETE FROM members_fts WHERE rowid = old.id; INSERT INTO members_fts(rowid, name, admno, email, phone, address) VALUES (new.id, new.name, new.admno, new.email, new.phone, new.address); END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS circulation_ai AFTER INSERT ON circulation BEGIN INSERT INTO circulation_fts(rowid, title, author, member_name, admno) VALUES (new.id, new.title, new.author, new.member_name, new.admno); END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS circulation_ad AFTER DELETE ON circulation BEGIN DELETE FROM circulation_fts WHERE rowid = old.id; END");
        $db->exec("CREATE TRIGGER IF NOT EXISTS circulation_au AFTER UPDATE ON circulation BEGIN DELETE FROM circulation_fts WHERE rowid = old.id; INSERT INTO circulation_fts(rowid, title, author, member_name, admno) VALUES (new.id, new.title, new.author, new.member_name, new.admno); END");
        // Populate FTS tables
        if ($db->query("SELECT COUNT(*) FROM books_fts")->fetchColumn() == 0) {
            $db->exec("INSERT OR REPLACE INTO books_fts(rowid, title, author, subject, isbn, publisher, description, keyword) SELECT id, title, author, subject, isbn, publisher, description, keyword FROM books");
        }
        if ($db->query("SELECT COUNT(*) FROM members_fts")->fetchColumn() == 0) {
            $db->exec("INSERT OR REPLACE INTO members_fts(rowid, name, admno, email, phone, address) SELECT id, name, admno, email, phone, address FROM members");
        }
        if ($db->query("SELECT COUNT(*) FROM circulation_fts")->fetchColumn() == 0) {
            $db->exec("INSERT OR REPLACE INTO circulation_fts(rowid, title, author, member_name, admno) SELECT id, title, author, member_name, admno FROM circulation");
        }
    }

    private function createSessionTables() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS user_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, ip_address TEXT, user_agent TEXT, expires_at DATETIME, last_activity DATETIME DEFAULT CURRENT_TIMESTAMP, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS remember_tokens(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, token TEXT NOT NULL, expires_at DATETIME NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS session_audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, session_id TEXT, action TEXT, reason TEXT, ip_address TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
    }

    // ========== INDEXES (MERGED) ==========
    private function createIndexes() {
        $db = $this->db;
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_books_barcode ON books(barcode)",
            "CREATE INDEX IF NOT EXISTS idx_books_isbn ON books(isbn)",
            "CREATE INDEX IF NOT EXISTS idx_books_title ON books(title)",
            "CREATE INDEX IF NOT EXISTS idx_books_author ON books(author)",
            "CREATE INDEX IF NOT EXISTS idx_books_category ON books(category)",
            "CREATE INDEX IF NOT EXISTS idx_books_status ON books(status)",
            "CREATE INDEX IF NOT EXISTS idx_books_available ON books(available)",
            "CREATE INDEX IF NOT EXISTS idx_books_created_at ON books(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_members_admno ON members(admno)",
            "CREATE INDEX IF NOT EXISTS idx_members_name ON members(name)",
            "CREATE INDEX IF NOT EXISTS idx_members_email ON members(email)",
            "CREATE INDEX IF NOT EXISTS idx_members_phone ON members(phone)",
            "CREATE INDEX IF NOT EXISTS idx_members_status ON members(status)",
            "CREATE INDEX IF NOT EXISTS idx_members_category ON members(member_category)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_admno ON circulation(admno)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_barcode ON circulation(barcode)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_issue_date ON circulation(issue_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_due_date ON circulation(due_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_return_date ON circulation(return_date)",
            "CREATE INDEX IF NOT EXISTS idx_fine_payments_admno ON fine_payments(admno)",
            "CREATE INDEX IF NOT EXISTS idx_fine_payments_status ON fine_payments(status)",
            "CREATE INDEX IF NOT EXISTS idx_entry_exit_admno ON entry_exit(admno)",
            "CREATE INDEX IF NOT EXISTS idx_entry_exit_entry_date ON entry_exit(entry_date)",
            "CREATE INDEX IF NOT EXISTS idx_entry_exit_status ON entry_exit(status)",
            "CREATE INDEX IF NOT EXISTS idx_activity_logs_username ON activity_logs(username)",
            "CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_session_logs_username ON session_logs(username)",
            "CREATE INDEX IF NOT EXISTS idx_session_logs_login_time ON session_logs(login_time)",
            "CREATE INDEX IF NOT EXISTS idx_notification_logs_recipient ON notification_logs(recipient)",
            "CREATE INDEX IF NOT EXISTS idx_notification_logs_status ON notification_logs(status)",
            "CREATE INDEX IF NOT EXISTS idx_email_queue_status ON email_queue(status)",
            "CREATE INDEX IF NOT EXISTS idx_email_queue_priority ON email_queue(priority)",
            "CREATE INDEX IF NOT EXISTS idx_loan_rules_patron_item ON loan_rules(patron_category, item_category)",
            "CREATE INDEX IF NOT EXISTS idx_fine_charges_circulation ON fine_charges(circulation_id)",
            "CREATE INDEX IF NOT EXISTS idx_book_recommendations_book ON book_recommendations(book_id)",
            "CREATE INDEX IF NOT EXISTS idx_faq_active ON faq(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(api_key)",
            "CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_api_keys_expires ON api_keys(expires_at)",
            "CREATE INDEX IF NOT EXISTS idx_book_suggestions_admno ON book_suggestions(admno)",
            "CREATE INDEX IF NOT EXISTS idx_book_suggestions_status ON book_suggestions(status)",
            "CREATE INDEX IF NOT EXISTS idx_quotes_active ON quotes(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_members_verification ON members(verification_token, verification_expiry)",
            "CREATE INDEX IF NOT EXISTS idx_members_approval ON members(approval_status)",
            "CREATE INDEX IF NOT EXISTS idx_totp_recovery_codes_user ON totp_recovery_codes(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_library_branches_code ON library_branches(code)",
            "CREATE INDEX IF NOT EXISTS idx_budgets_fiscal_year ON budgets(fiscal_year)",
            "CREATE INDEX IF NOT EXISTS idx_interlibrary_loans_member ON interlibrary_loans(requesting_member_admno)",
            "CREATE INDEX IF NOT EXISTS idx_course_reserves_code ON course_reserves(course_code)",
            "CREATE INDEX IF NOT EXISTS idx_audit_trail_user ON audit_trail_detailed(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_trail_table ON audit_trail_detailed(table_name)",
            "CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_next_run ON scheduled_jobs(next_run)",
            "CREATE INDEX IF NOT EXISTS idx_notification_templates_key ON notification_templates(template_key)",
            "CREATE INDEX IF NOT EXISTS idx_library_cards_member ON library_cards(member_admno)",
            "CREATE INDEX IF NOT EXISTS idx_library_cards_card ON library_cards(card_number)",
            "CREATE INDEX IF NOT EXISTS idx_whatsapp_queue_status ON whatsapp_queue(status)",
            "CREATE INDEX IF NOT EXISTS idx_whatsapp_queue_created ON whatsapp_queue(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_kiosk_logs_action ON kiosk_logs(action)",
            "CREATE INDEX IF NOT EXISTS idx_kiosk_logs_time ON kiosk_logs(log_time)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_barcode_return ON circulation(barcode, return_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_admno_return ON circulation(admno, return_date)",
            "CREATE INDEX IF NOT EXISTS idx_books_maintenance ON books(maintenance)",
            "CREATE INDEX IF NOT EXISTS idx_books_current_location ON books(current_location)",
            "CREATE INDEX IF NOT EXISTS idx_books_section ON books(section)",
            "CREATE INDEX IF NOT EXISTS idx_books_cc ON books(cc)",
            "CREATE INDEX IF NOT EXISTS idx_members_designation ON members(designation)",
            "CREATE INDEX IF NOT EXISTS idx_members_general_id ON members(general_id)",
            "CREATE INDEX IF NOT EXISTS idx_members_membership_expiry ON members(membership_expiry)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_visits ON research_databases(visits)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_expiry ON research_databases(expiry_date)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_deleted ON research_databases(deleted_at)",
            "CREATE INDEX IF NOT EXISTS idx_members_admission_date ON members(admission_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_member_status ON circulation(admno, return_date)",
            "CREATE INDEX IF NOT EXISTS idx_books_publisher ON books(publisher)",
            "CREATE INDEX IF NOT EXISTS idx_books_year ON books(year)",
            "CREATE INDEX IF NOT EXISTS idx_books_language ON books(language)",
            "CREATE INDEX IF NOT EXISTS idx_loan_rules_active ON loan_rules(is_active)",
            "CREATE INDEX IF NOT EXISTS idx_payment_transactions_date ON payment_transactions(payment_date)",
            "CREATE INDEX IF NOT EXISTS idx_payment_transactions_member ON payment_transactions(member_admno)",
            "CREATE INDEX IF NOT EXISTS idx_lost_books_status ON lost_books(status)",
            "CREATE INDEX IF NOT EXISTS idx_reservations_queue_status ON reservations_queue(status)",
            "CREATE INDEX IF NOT EXISTS idx_serial_issues_status ON serial_issues(status)",
            "CREATE INDEX IF NOT EXISTS idx_computer_sessions_date ON computer_sessions(login_time)",
            "CREATE INDEX IF NOT EXISTS idx_notification_logs_channel ON notification_logs(channel)",
            "CREATE INDEX IF NOT EXISTS idx_email_queue_created ON email_queue(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_ebooks_subject ON ebooks(subject)",
            "CREATE INDEX IF NOT EXISTS idx_ebooks_storage_type ON ebooks(storage_type)",
            "CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON activity_logs(action)",
            "CREATE INDEX IF NOT EXISTS idx_daily_stats_date ON daily_stats(stat_date)",
            "CREATE INDEX IF NOT EXISTS idx_visitor_logs_date ON entry_exit(entry_date, status)",
            "CREATE INDEX IF NOT EXISTS idx_book_recommendations_score ON book_recommendations(score)",
            "CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_status ON scheduled_jobs(status)",
            "CREATE INDEX IF NOT EXISTS idx_audit_trail_created ON audit_trail_detailed(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_issue_date_status ON circulation(issue_date, return_date)",
            "CREATE INDEX IF NOT EXISTS idx_members_status_category ON members(status, member_category)",
            "CREATE INDEX IF NOT EXISTS idx_books_category_status ON books(category, status)",
            "CREATE INDEX IF NOT EXISTS idx_payment_transactions_type ON payment_transactions(payment_type)",
            "CREATE INDEX IF NOT EXISTS idx_notification_preferences_user ON notification_preferences(user_id, user_type)",
            "CREATE INDEX IF NOT EXISTS idx_social_accounts_user ON social_accounts(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_twofa_backup_codes_user ON twofa_backup_codes(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_api_rate_limits_key ON api_rate_limits(api_key, reset_at)",
            "CREATE INDEX IF NOT EXISTS idx_search_analytics_term ON search_analytics(search_term, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_user_activity_summary_date ON user_activity_summary(user_id, activity_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_summary_barcode ON circulation_summary(book_barcode, month_year)",
            "CREATE INDEX IF NOT EXISTS idx_book_metadata_cache_isbn ON book_metadata_cache(isbn)",
            "CREATE INDEX IF NOT EXISTS idx_system_health_checked ON system_health(checked_at)",
            "CREATE INDEX IF NOT EXISTS idx_library_statistics_date ON library_statistics(stat_date)"
        ];
        foreach ($indexes as $sql) {
            try { $db->exec($sql); } catch (PDOException $e) {}
        }
    }

    // ========== DEFAULT DATA (MERGED) ==========
    private function insertDefaultData() {
        $db = $this->db;
        $db->exec("INSERT OR IGNORE INTO institutions (id, name, address, contact, email, status) VALUES (1, 'Main Library', '123 Library Street, City', '+1234567890', 'library@example.com', 'active')");
        $hashedAdmin = password_hash('admin123', PASSWORD_DEFAULT);
        $hashedStaff = password_hash('staff123', PASSWORD_DEFAULT);
        $db->exec("INSERT OR IGNORE INTO users (username, password, fullname, role, token_version) VALUES ('admin', '$hashedAdmin', 'System Administrator', 'admin', 1), ('staff1', '$hashedStaff', 'Library Staff', 'staff', 1)");
        $defaultBackupPassword = password_hash('backup123', PASSWORD_DEFAULT);
        $db->exec("INSERT OR IGNORE INTO settings (id, loan_days, fine_per_day, max_books, menu_position, software_header, backup_email, backup_password, allow_holds, hold_days, google_drive_enabled, google_drive_folder_id, google_drive_client_id, google_drive_client_secret, google_drive_refresh_token, smtp_host, smtp_port, smtp_encryption, smtp_username, smtp_password, mail_from, mail_from_name, backup_schedule, backup_time, new_arrivals_count, opac_enabled, enable_email, notify_overdue, auto_logout_minutes, opac_show_new_arrivals, opac_show_popular_ebooks, opac_show_latest_ebooks, opac_show_notices, opac_show_trending, opac_books_per_page, opac_ebooks_per_page, library_logo, favicon_path, image_base_path, enable_whatsapp, whatsapp_api_key, whatsapp_phone_number, whatsapp_api_url, right_logo_path, opac_notice_title, opac_notice_content, max_fine_amount, enable_self_registration, self_registration_role, enable_member_password_reset, reset_token_expiry_hours, allow_member_password_change, cloud_storage_provider, cloud_api_key, cloud_api_secret, cloud_refresh_token, cloud_folder_id, google_drive_service_account_json, currency_code, currency_symbol, currency_position, opac_header_logo, login_bg_color, login_text_color, login_header_logo, login_font_family, login_base_font_size, staff_display_enabled, staff_card_bg_color, currency_decimal_places, guest_enabled, guest_prefix, guest_number_padding, whatsapp_number, whatsapp_message, fine_grace_period, fine_calculation_method, auto_waive_fine_after_return, fine_reminder_days, enable_overdue_notifications, library_open_days, library_open_time, library_close_time, library_lunch_start, library_lunch_end, library_timezone, container_max_width, container_padding, opac_font_family, opac_base_font_size, opac_heading_font_size, opac_primary_color, opac_header_bg_color, opac_body_bg, max_renewals, enable_audit_log, audit_log_retention_days, enable_member_notifications, default_language, site_maintenance_mode, maintenance_message, razorpay_key_id, razorpay_key_secret, session_check_ip, max_concurrent_sessions, opac_show_thought_of_the_day, opac_show_new_arrivals_in_left, opac_quote_rotation_interval, opac_carousel_type, openai_api_key) VALUES (1, 7, 2, 5, 'top', 'Library ERP System', 'admin@library.com', '$defaultBackupPassword', 1, 7, 0, '', '', '', '', '', 587, 'tls', '', '', '', '', 'daily', '00:00', 10, 1, 1, 1, 30, 1, 1, 1, 1, 1, 12, 8, '', '', 'uploads/', 0, '', '', '', '', '', '', 0, 0, 'Student', 1, 24, 1, 'local', '', '', '', '', '', 'USD', '$', 'left', '', '#667eea', '#ffffff', '', 'Inter', 16, 1, '#ffffff', 2, 1, 'GUEST-', 4, '', 'Hello, I need assistance from the library.', 0, 'daily', 0, 3, 1, '1,2,3,4,5', '09:00', '18:00', '', '', 'Asia/Kolkata', 1600, 10, 'Inter', 16, 32, '#1e3c72', '#1e3c72', '#f0f2f5', 0, 1, 90, 1, 'en', 0, 'System under maintenance. Please check back later.', '', '', 0, 5, 1, 1, 10, 'cover_flow', '')");
        $db->exec("INSERT OR IGNORE INTO computer_policies (user_role, max_minutes_per_day, max_minutes_per_week, max_sessions_per_week, require_attendance, weekly_attendance_required) VALUES ('student', 60, 240, 3, 1, 1), ('teacher', 120, 480, 10, 0, 0), ('staff', 90, 360, 5, 1, 1), ('visitor', 30, 120, 2, 0, 0)");
        $db->exec("INSERT OR IGNORE INTO quick_actions (title, icon_class, link_url, sort_order, is_active) VALUES ('Issue Book', 'fa-arrow-right', 'circulation/issue.php', 1, 1), ('Return Book', 'fa-arrow-left', 'circulation/return.php', 2, 1), ('Renew', 'fa-sync-alt', 'circulation/renew.php', 3, 1), ('Computer Access', 'fa-desktop', 'computer_management/', 4, 1), ('eBooks', 'fa-file-pdf', 'ebooks/', 5, 1), ('Utilities Suite', 'fa-toolbox', 'utilities/', 6, 1), ('Serial Control', 'fa-newspaper', 'serial/', 7, 1), ('Backup & Restore', 'fa-database', 'admin/backup.php', 8, 1), ('Reports', 'fa-chart-bar', 'reports/', 9, 1), ('Settings', 'fa-cog', 'admin/settings.php', 10, 1)");
        $db->exec("INSERT OR IGNORE INTO fine_rates (member_category, fine_per_day, max_fine, grace_period_days, is_active) VALUES ('Student', 2, 100, 0, 1), ('Staff', 5, 0, 3, 1), ('Teacher', 5, 0, 3, 1), ('General', 3, 200, 0, 1), ('Others', 3, 200, 0, 1), ('Visitor', 10, 500, 0, 1)");
        $db->exec("INSERT OR IGNORE INTO login_cards (title, icon_class, link_url, sort_order, is_active) VALUES ('Library Timings', 'fas fa-clock', '#', 1, 1), ('Contact Librarian', 'fas fa-envelope', '#', 2, 1), ('Digital Resources', 'fas fa-database', '../opac/ebooks.php', 3, 1), ('Ask a Question', 'fas fa-question-circle', '../contact.php', 4, 1)");
        $db->exec("INSERT OR IGNORE INTO staff_profiles (name, designation, sort_order, is_active) VALUES ('Librarian', 'Head Librarian', 1, 1), ('Assistant Librarian', 'Staff', 2, 1)");
        $db->exec("INSERT OR IGNORE INTO research_databases (name, description, url, category, type, icon, is_featured, sort_order) VALUES ('JSTOR', 'Digital library of academic journals, books, and primary sources', 'https://www.jstor.org/', 'Academic', 'academic', 'university', 1, 1), ('Google Scholar', 'Free academic search engine', 'https://scholar.google.com/', 'Academic', 'open_access', 'graduation-cap', 1, 2), ('PubMed', 'Biomedical literature database', 'https://pubmed.ncbi.nlm.nih.gov/', 'Medical', 'open_access', 'heartbeat', 1, 3), ('DOAJ', 'Directory of Open Access Journals', 'https://doaj.org/', 'Academic', 'open_access', 'lock-open', 1, 4), ('IEEE Xplore', 'Technical literature in electrical engineering', 'https://ieeexplore.ieee.org/', 'Engineering', 'subscription', 'microchip', 1, 5), ('ScienceDirect', 'Scientific and medical research', 'https://www.sciencedirect.com/', 'Science', 'subscription', 'flask', 1, 6), ('SpringerLink', 'Scientific documents and journals', 'https://link.springer.com/', 'Academic', 'subscription', 'book', 1, 7), ('ERIC', 'Education research database', 'https://eric.ed.gov/', 'Education', 'open_access', 'chalkboard-user', 1, 8), ('ProQuest', 'Multidisciplinary database of academic content', 'https://www.proquest.com/', 'Multidisciplinary', 'subscription', 'search', 0, 9), ('EBSCOhost', 'Full-text databases for academic research', 'https://www.ebsco.com/', 'Multidisciplinary', 'subscription', 'database', 0, 10), ('Scopus', 'Abstract and citation database', 'https://www.scopus.com/', 'Academic', 'subscription', 'quote-right', 0, 11), ('Web of Science', 'Citation indexing database', 'https://www.webofscience.com/', 'Academic', 'subscription', 'globe', 0, 12)");
        $allModules = ['admin_dashboard', 'circulation', 'members', 'books', 'ebooks', 'acquisitions', 'serial_control', 'system_settings', 'quick_actions_manager', 'backup_restore', 'data_import', 'utilities', 'stock_verification', 'lost_damaged', 'payments', 'reservations', 'library_events', 'member_documents', 'computer_access', 'entry_exit', 'session_logs', 'bulk_messaging', 'chatbot', 'reports', 'advanced_analytics', 'opac', 'digital_hub', 'self_kiosk', 'member_portal', 'multi_library', 'fines_management', 'overdue_reports', 'research_databases', 'budget_management', 'interlibrary_loans', 'course_reserves'];
        $roles = ['admin', 'librarian', 'staff'];
        $roleDenyList = ['librarian' => ['system_settings', 'backup_restore', 'bulk_messaging', 'advanced_analytics', 'budget_management'], 'staff' => ['acquisitions', 'serial_control', 'system_settings', 'backup_restore', 'data_import', 'payments', 'reservations', 'library_events', 'member_documents', 'session_logs', 'bulk_messaging', 'advanced_analytics', 'digital_hub', 'multi_library', 'fines_management', 'budget_management', 'interlibrary_loans']];
        $insertPerm = $db->prepare("INSERT OR IGNORE INTO module_permissions (role, module_key, can_access) VALUES (?, ?, ?)");
        foreach ($roles as $role) {
            foreach ($allModules as $mod) {
                $allowed = 1;
                if (isset($roleDenyList[$role]) && in_array($mod, $roleDenyList[$role])) $allowed = 0;
                if ($role === 'admin') $allowed = 1;
                $insertPerm->execute([$role, $mod, $allowed]);
            }
        }
        if ($db->query("SELECT COUNT(*) FROM loan_rules")->fetchColumn() == 0) {
            $db->exec("INSERT INTO loan_rules (patron_category, item_category, max_loans, loan_period, renewals_allowed, fine_per_day, grace_period) VALUES ('Student', 'Book', 5, 14, 1, 1.00, 0), ('Student', 'Reference', 2, 7, 0, 5.00, 0), ('Faculty', 'Book', 15, 30, 3, 0.00, 7), ('Faculty', '*', 20, 30, 5, 0.50, 7), ('*', '*', 3, 14, 1, 2.00, 0)");
        }
        if ($db->query("SELECT COUNT(*) FROM faq")->fetchColumn() == 0) {
            $db->exec("INSERT INTO faq (question, answer, category) VALUES ('What are the library hours?', 'Our library is open Monday to Friday from 9:00 AM to 6:00 PM, Saturday from 10:00 AM to 4:00 PM, and closed on Sundays.', 'hours'), ('How do I renew a book?', 'You can renew a book online by logging into your account and clicking \"Renew\" next to the loan, or by visiting the circulation desk.', 'policies'), ('How do I place a hold?', 'If a book is checked out, you can place a hold by clicking \"Place Hold\" on the book details page. You will be notified via email when the book becomes available.', 'policies'), ('What is the overdue fine?', 'Overdue fines are ₹2 per day for general books, ₹5 per day for reference books, and ₹10 per day for reserved items.', 'fines'), ('How can I become a library member?', 'You can register online through our OPAC registration form. After submitting, your application will be reviewed and approved by staff.', 'membership')");
        }
        if ($db->query("SELECT COUNT(*) FROM api_keys")->fetchColumn() == 0) {
            $db->exec("INSERT INTO api_keys (api_key, name, permissions, is_active) VALUES ('lib-api-key-2024-secure', 'Default API Key', 'read,write', 1)");
        }
        if ($db->query("SELECT COUNT(*) FROM quotes")->fetchColumn() == 0) {
            $db->exec("INSERT INTO quotes (text, author, is_active) VALUES ('The only thing you absolutely have to know is the location of the library.', 'Albert Einstein', 1), ('Reading is to the mind what exercise is to the body.', 'Joseph Addison', 1), ('A library is a hospital for the mind.', 'Unknown', 1)");
        }
        if ($db->query("SELECT COUNT(*) FROM notification_templates")->fetchColumn() == 0) {
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('overdue_email', 'email', 'Overdue Book Notice', 'Dear {name}, the book \"{title}\" is overdue by {days} days. Please return it immediately.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('overdue_sms', 'sms', NULL, 'Book \"{title}\" overdue by {days} days. Return ASAP.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('welcome_email', 'email', 'Welcome to the Library', 'Dear {name}, your library membership has been activated. Enjoy reading!')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('hold_available', 'email', 'Book Hold Available', 'Dear {name}, the book \"{title}\" you requested is now available for pickup.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('interlibrary_request', 'email', 'Interlibrary Loan Request', 'Your interlibrary loan request for \"{title}\" has been {status}.')");
        }
        if ($db->query("SELECT COUNT(*) FROM library_branches")->fetchColumn() == 0) {
            $db->exec("INSERT INTO library_branches (name, code, address, phone, email, manager, status) VALUES ('Central Library', 'CEN', 'Main Campus', '1234567890', 'central@library.com', 'Admin', 'active')");
        }
        if ($db->query("SELECT COUNT(*) FROM scheduled_jobs")->fetchColumn() == 0) {
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('daily_backup', datetime('now', '+1 day'), 'pending', '{\"type\":\"full\"}')");
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('overdue_notifications', datetime('now', '+1 hour'), 'pending', '{\"notify\":true}')");
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('daily_stats', datetime('now', '+1 hour'), 'pending', '{}')");
        }
    }

    // ========== MIGRATIONS ==========
    private function runMigrations($fromVersion) {
        $this->addMissingColumns();
        if ($fromVersion < 4) $this->createVersion4Tables();
        if ($fromVersion < 5) $this->createVersion5Tables();
        if ($fromVersion < 6) $this->createVersion6Tables();
        if ($fromVersion < 7) $this->createVersion7Tables();
        if ($fromVersion < 8) $this->createVersion8Tables();
        if ($fromVersion < 9) $this->upgradeToVersion9();
        if ($fromVersion < 10) $this->upgradeToVersion10();
        if ($fromVersion < 11) $this->upgradeToVersion11();
        if ($fromVersion < 12) $this->upgradeToVersion12();
        if ($fromVersion < 13) $this->upgradeToVersion13();
        if ($fromVersion < 14) $this->upgradeToVersion14();
        if ($fromVersion < 15) $this->upgradeToVersion15();
    }

    // ---------- VERSION 15 UPGRADE ----------
    private function upgradeToVersion15() {
        $db = $this->db;
        // Add new table if not exists
        $db->exec("CREATE TABLE IF NOT EXISTS library_statistics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stat_date DATE UNIQUE NOT NULL,
            total_members INTEGER DEFAULT 0,
            total_books INTEGER DEFAULT 0,
            total_loans INTEGER DEFAULT 0,
            total_fines_collected REAL DEFAULT 0,
            active_loans INTEGER DEFAULT 0,
            overdue_count INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Add new settings columns
        $settingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettings = [
            'enable_library_statistics' => "INTEGER DEFAULT 1",
            'statistics_retention_days' => "INTEGER DEFAULT 365",
            'opac_show_statistics' => "INTEGER DEFAULT 1"
        ];
        foreach ($newSettings as $col => $def) {
            if (!in_array($col, $settingCols)) {
                try { $db->exec("ALTER TABLE settings ADD COLUMN $col $def"); } catch (PDOException $e) {}
            }
        }

        // Index for statistics table
        try {
            $db->exec("CREATE INDEX IF NOT EXISTS idx_library_statistics_date ON library_statistics(stat_date)");
        } catch (PDOException $e) {}
    }

    // ---------- VERSION 4-14 MIGRATION METHODS (PRESERVED) ----------
    private function createVersion4Tables() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS fine_payments(id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER, admno TEXT NOT NULL, amount REAL NOT NULL, payment_date DATE NOT NULL, payment_method TEXT DEFAULT 'cash' CHECK(payment_method IN ('cash','card','online','cheque')), receipt_no TEXT UNIQUE, status TEXT DEFAULT 'paid' CHECK(status IN ('paid','refunded','pending')), notes TEXT, collected_by TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(circulation_id) REFERENCES circulation(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS overdue_notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER NOT NULL, admno TEXT NOT NULL, notification_type TEXT CHECK(notification_type IN ('email','sms','whatsapp')), days_overdue INTEGER, sent_at DATETIME DEFAULT CURRENT_TIMESTAMP, status TEXT DEFAULT 'sent', response TEXT, FOREIGN KEY(circulation_id) REFERENCES circulation(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, total_fine REAL NOT NULL, amount_paid REAL DEFAULT 0, amount_waived REAL DEFAULT 0, settlement_date DATE, settled_by TEXT, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("ALTER TABLE circulation ADD COLUMN renew_count INTEGER DEFAULT 0");
        $existingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettingsCols = ['fine_grace_period' => "INTEGER DEFAULT 0", 'fine_calculation_method' => "TEXT DEFAULT 'daily' CHECK(fine_calculation_method IN ('daily','hourly'))", 'auto_waive_fine_after_return' => "BOOLEAN DEFAULT 0", 'fine_reminder_days' => "INTEGER DEFAULT 3", 'enable_overdue_notifications' => "BOOLEAN DEFAULT 1", 'library_open_days' => "TEXT DEFAULT '1,2,3,4,5'", 'library_open_time' => "TEXT DEFAULT '09:00'", 'library_close_time' => "TEXT DEFAULT '18:00'", 'library_lunch_start' => "TEXT DEFAULT ''", 'library_lunch_end' => "TEXT DEFAULT ''", 'library_timezone' => "TEXT DEFAULT 'Asia/Kolkata'", 'max_renewals' => "INTEGER DEFAULT 0", 'enable_audit_log' => "INTEGER DEFAULT 1", 'audit_log_retention_days' => "INTEGER DEFAULT 90", 'enable_member_notifications' => "INTEGER DEFAULT 1", 'default_language' => "TEXT DEFAULT 'en'", 'site_maintenance_mode' => "INTEGER DEFAULT 0", 'maintenance_message' => "TEXT DEFAULT 'System under maintenance. Please check back later.'"];
        foreach ($newSettingsCols as $col => $typeDef) if (!in_array($col, $existingCols)) try { $db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        $fineRateCols = $db->query("PRAGMA table_info(fine_rates)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('max_fine', $fineRateCols)) try { $db->exec("ALTER TABLE fine_rates ADD COLUMN max_fine REAL DEFAULT 0"); } catch (PDOException $e) {}
        if (!in_array('grace_period_days', $fineRateCols)) try { $db->exec("ALTER TABLE fine_rates ADD COLUMN grace_period_days INTEGER DEFAULT 0"); } catch (PDOException $e) {}
        if (!in_array('updated_at', $fineRateCols)) try { $db->exec("ALTER TABLE fine_rates ADD COLUMN updated_at DATETIME"); } catch (PDOException $e) {}
    }

    private function createVersion5Tables() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS research_databases(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT, url TEXT NOT NULL, category TEXT, type TEXT DEFAULT 'academic' CHECK(type IN ('academic', 'open_access', 'subscription')), icon TEXT DEFAULT 'database', is_featured INTEGER DEFAULT 0, sort_order INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS research_database_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, database_id INTEGER NOT NULL, user_id INTEGER, user_type TEXT CHECK(user_type IN ('member','admin','guest')), action TEXT CHECK(action IN ('access','search','download')), search_query TEXT, ip_address TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(database_id) REFERENCES research_databases(id) ON DELETE CASCADE)");
        $existingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettingsCols = ['opac_show_databases' => "INTEGER DEFAULT 1", 'container_max_width' => "INTEGER DEFAULT 1600", 'container_padding' => "INTEGER DEFAULT 10", 'opac_font_family' => "TEXT DEFAULT 'Inter'", 'opac_base_font_size' => "INTEGER DEFAULT 16", 'opac_heading_font_size' => "INTEGER DEFAULT 32", 'opac_primary_color' => "TEXT DEFAULT '#1e3c72'", 'opac_header_bg_color' => "TEXT DEFAULT '#1e3c72'", 'opac_body_bg' => "TEXT DEFAULT '#f0f2f5'", 'opac_custom_css' => "TEXT DEFAULT ''"];
        foreach ($newSettingsCols as $col => $typeDef) if (!in_array($col, $existingCols)) try { $db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        if ($db->query("SELECT COUNT(*) FROM research_databases")->fetchColumn() == 0) {
            $insertDb = $db->prepare("INSERT INTO research_databases (name, description, url, category, type, icon, is_featured, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $defaultDatabases = [['JSTOR','Digital library of academic journals, books, and primary sources','https://www.jstor.org/','Academic','academic','university',1,1],['Google Scholar','Free academic search engine','https://scholar.google.com/','Academic','open_access','graduation-cap',1,2],['PubMed','Biomedical literature database','https://pubmed.ncbi.nlm.nih.gov/','Medical','open_access','heartbeat',1,3],['DOAJ','Directory of Open Access Journals','https://doaj.org/','Academic','open_access','lock-open',1,4],['IEEE Xplore','Technical literature in electrical engineering','https://ieeexplore.ieee.org/','Engineering','subscription','microchip',1,5],['ScienceDirect','Scientific and medical research','https://www.sciencedirect.com/','Science','subscription','flask',1,6],['SpringerLink','Scientific documents and journals','https://link.springer.com/','Academic','subscription','book',1,7],['ERIC','Education research database','https://eric.ed.gov/','Education','open_access','chalkboard-user',1,8]];
            foreach ($defaultDatabases as $dbData) $insertDb->execute($dbData);
        }
    }

    private function createVersion6Tables() {
        $this->createFTS5Tables();
        $existingCols = $this->db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettingsCols = ['razorpay_key_id' => "TEXT DEFAULT ''", 'razorpay_key_secret' => "TEXT DEFAULT ''"];
        foreach ($newSettingsCols as $col => $typeDef) if (!in_array($col, $existingCols)) try { $this->db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
    }

    private function createVersion7Tables() {
        $this->createSessionTables();
        $existingCols = $this->db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettingsCols = ['session_check_ip' => "INTEGER DEFAULT 0", 'max_concurrent_sessions' => "INTEGER DEFAULT 5"];
        foreach ($newSettingsCols as $col => $typeDef) if (!in_array($col, $existingCols)) try { $this->db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
    }

    private function createVersion8Tables() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS loan_rules (id INTEGER PRIMARY KEY AUTOINCREMENT, patron_category TEXT NOT NULL, item_category TEXT NOT NULL, max_loans INTEGER DEFAULT 5, loan_period INTEGER DEFAULT 14, renewals_allowed INTEGER DEFAULT 1, fine_per_day REAL DEFAULT 1.00, grace_period INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS fine_charges (id INTEGER PRIMARY KEY AUTOINCREMENT, circulation_id INTEGER NOT NULL, member_id INTEGER NOT NULL, member_admno TEXT NOT NULL, amount REAL NOT NULL, days_overdue INTEGER NOT NULL, charge_date DATE NOT NULL, status TEXT DEFAULT 'pending', created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (circulation_id) REFERENCES circulation(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS book_recommendations (id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER NOT NULL, recommended_book_id INTEGER NOT NULL, score REAL NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(book_id, recommended_book_id))");
        $db->exec("CREATE TABLE IF NOT EXISTS faq (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, answer TEXT NOT NULL, category VARCHAR(100), keywords TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, api_key TEXT UNIQUE NOT NULL, name TEXT NOT NULL, permissions TEXT NOT NULL DEFAULT 'read', active INTEGER DEFAULT 1, last_used DATETIME, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        if ($db->query("SELECT COUNT(*) FROM loan_rules")->fetchColumn() == 0) {
            $db->exec("INSERT INTO loan_rules (patron_category, item_category, max_loans, loan_period, renewals_allowed, fine_per_day, grace_period) VALUES ('Student', 'Book', 5, 14, 1, 1.00, 0), ('Student', 'Reference', 2, 7, 0, 5.00, 0), ('Faculty', 'Book', 15, 30, 3, 0.00, 7), ('Faculty', '*', 20, 30, 5, 0.50, 7), ('*', '*', 3, 14, 1, 2.00, 0)");
        }
        if ($db->query("SELECT COUNT(*) FROM faq")->fetchColumn() == 0) {
            $db->exec("INSERT INTO faq (question, answer, category) VALUES ('What are the library hours?', 'Our library is open Monday to Friday from 9:00 AM to 6:00 PM, Saturday from 10:00 AM to 4:00 PM, and closed on Sundays.', 'hours'), ('How do I renew a book?', 'You can renew a book online by logging into your account and clicking \"Renew\" next to the loan, or by visiting the circulation desk.', 'policies'), ('How do I place a hold?', 'If a book is checked out, you can place a hold by clicking \"Place Hold\" on the book details page. You will be notified via email when the book becomes available.', 'policies'), ('What is the overdue fine?', 'Overdue fines are ₹2 per day for general books, ₹5 per day for reference books, and ₹10 per day for reserved items.', 'fines'), ('How can I become a library member?', 'You can register online through our OPAC registration form. After submitting, your application will be reviewed and approved by staff.', 'membership')");
        }
        if ($db->query("SELECT COUNT(*) FROM api_keys")->fetchColumn() == 0) {
            $db->exec("INSERT INTO api_keys (api_key, name, permissions) VALUES ('lib-api-key-2024-secure', 'Default API Key', 'read,write')");
        }
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_loan_rules_patron_item ON loan_rules(patron_category, item_category)",
            "CREATE INDEX IF NOT EXISTS idx_fine_charges_circulation ON fine_charges(circulation_id)",
            "CREATE INDEX IF NOT EXISTS idx_book_recommendations_book ON book_recommendations(book_id)",
            "CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(api_key)"
        ];
        foreach ($indexes as $sql) try { $db->exec($sql); } catch (PDOException $e) {}
    }

    private function upgradeToVersion9() {
        $db = $this->db;
        $cols = $db->query("PRAGMA table_info(api_keys)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('is_active', $cols)) { $db->exec("ALTER TABLE api_keys ADD COLUMN is_active INTEGER DEFAULT 1"); if (in_array('active', $cols)) $db->exec("UPDATE api_keys SET is_active = active WHERE active IS NOT NULL"); }
        if (!in_array('expires_at', $cols)) $db->exec("ALTER TABLE api_keys ADD COLUMN expires_at DATETIME");
        $oldExists = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='notification_logs'")->fetch();
        if ($oldExists) {
            $db->exec("CREATE TABLE notification_logs_temp (id INTEGER PRIMARY KEY AUTOINCREMENT, recipient_type TEXT DEFAULT 'member' CHECK(recipient_type IN ('member', 'admin', 'staff')), recipient TEXT NOT NULL, notification_type TEXT NOT NULL, subject TEXT, message TEXT, channel TEXT CHECK(channel IN ('email', 'sms', 'whatsapp', 'push')), status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'sent', 'failed')), sent_at DATETIME, error_message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
            $db->exec("INSERT INTO notification_logs_temp SELECT id, IFNULL(recipient_type, 'member'), recipient, notification_type, subject, message, channel, status, sent_at, error_message, created_at FROM notification_logs");
            $db->exec("DROP TABLE notification_logs");
            $db->exec("ALTER TABLE notification_logs_temp RENAME TO notification_logs");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_notification_logs_recipient ON notification_logs(recipient)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_notification_logs_type ON notification_logs(notification_type)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_notification_logs_status ON notification_logs(status)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_notification_logs_created ON notification_logs(created_at)");
            $db->exec("CREATE INDEX IF NOT EXISTS idx_notification_logs_status_channel ON notification_logs(status, channel)");
        }
        $db->exec("CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(api_key)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_api_keys_expires ON api_keys(expires_at)");
    }

    private function upgradeToVersion10() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS book_suggestions (id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, name TEXT NOT NULL, title TEXT NOT NULL, author TEXT, isbn TEXT, reason TEXT NOT NULL, status TEXT DEFAULT 'pending', admin_notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME, submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, author TEXT, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $existingSettingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $missingSettingCols = [
            'opac_show_thought_of_the_day' => "INTEGER DEFAULT 1",
            'opac_show_new_arrivals_in_left' => "INTEGER DEFAULT 1",
            'opac_quote_rotation_interval' => "INTEGER DEFAULT 10",
            'opac_carousel_type' => "TEXT DEFAULT 'cover_flow'",
            'openai_api_key' => "TEXT DEFAULT ''",
            'google_drive_auto_delete_days' => "INTEGER DEFAULT 30",
            'google_drive_last_cleanup' => "TEXT DEFAULT ''",
            'dropbox_access_token' => "TEXT DEFAULT ''",
            'dropbox_app_key' => "TEXT DEFAULT ''",
            'dropbox_app_secret' => "TEXT DEFAULT ''",
            'dropbox_refresh_token' => "TEXT DEFAULT ''",
            'onedrive_client_id' => "TEXT DEFAULT ''",
            'onedrive_client_secret' => "TEXT DEFAULT ''",
            'onedrive_refresh_token' => "TEXT DEFAULT ''",
            'pcloud_enabled' => "INTEGER DEFAULT 0",
            'pcloud_access_token' => "TEXT DEFAULT ''",
            'pcloud_username' => "TEXT DEFAULT ''",
            'pcloud_password_hash' => "TEXT DEFAULT ''",
            'internxt_enabled' => "INTEGER DEFAULT 0",
            'internxt_api_key' => "TEXT DEFAULT ''",
            'internxt_api_secret' => "TEXT DEFAULT ''",
            'internxt_bucket' => "TEXT DEFAULT ''",
            'internxt_region' => "TEXT DEFAULT ''",
            'mega_enabled' => "INTEGER DEFAULT 0",
            'mega_email' => "TEXT DEFAULT ''",
            'mega_password_hash' => "TEXT DEFAULT ''",
            'mega_folder_id' => "TEXT DEFAULT ''",
            'sync_enabled' => "INTEGER DEFAULT 0",
            'sync_api_key' => "TEXT DEFAULT ''",
            'sync_api_secret' => "TEXT DEFAULT ''",
            'sync_folder_id' => "TEXT DEFAULT ''",
            'terabox_enabled' => "INTEGER DEFAULT 0",
            'terabox_api_key' => "TEXT DEFAULT ''",
            'terabox_api_secret' => "TEXT DEFAULT ''",
            'terabox_folder_id' => "TEXT DEFAULT ''",
            'backblaze_enabled' => "INTEGER DEFAULT 0",
            'backblaze_key_id' => "TEXT DEFAULT ''",
            'backblaze_application_key' => "TEXT DEFAULT ''",
            'backblaze_bucket_id' => "TEXT DEFAULT ''",
            'backblaze_bucket_name' => "TEXT DEFAULT ''",
            'wasabi_enabled' => "INTEGER DEFAULT 0",
            'wasabi_access_key' => "TEXT DEFAULT ''",
            'wasabi_secret_key' => "TEXT DEFAULT ''",
            'wasabi_bucket' => "TEXT DEFAULT ''",
            'wasabi_region' => "TEXT DEFAULT 'us-east-1'",
            's3_enabled' => "INTEGER DEFAULT 0",
            's3_access_key' => "TEXT DEFAULT ''",
            's3_secret_key' => "TEXT DEFAULT ''",
            's3_bucket' => "TEXT DEFAULT ''",
            's3_region' => "TEXT DEFAULT 'us-east-1'",
            's3_endpoint' => "TEXT DEFAULT ''",
            'local_backup_retention' => "INTEGER DEFAULT 30",
            'backup_include_uploads' => "INTEGER DEFAULT 1",
            'backup_compress' => "INTEGER DEFAULT 1",
            'backup_notification_email' => "TEXT DEFAULT ''",
            'last_backup_time' => "DATETIME DEFAULT NULL",
            'visitor_header_logo' => "TEXT DEFAULT ''",
            'visitor_header_text' => "TEXT DEFAULT ''",
            'visitor_tagline' => "TEXT DEFAULT 'Visitors Log'",
            'visitor_header_bg' => "TEXT DEFAULT '#1e3c72'",
            'visitor_body_bg' => "TEXT DEFAULT '#f0f2f5'",
            'visitor_footer_bg' => "TEXT DEFAULT '#1e3c72'",
            'visitor_font_family' => "TEXT DEFAULT 'Inter'",
            'visitor_base_font_size' => "INTEGER DEFAULT 16",
            'visitor_primary_color' => "TEXT DEFAULT '#28a745'",
            'report_font_size' => "INTEGER DEFAULT 10",
            'report_primary_color' => "TEXT DEFAULT '#1e3c72'",
            'report_logo_position' => "TEXT DEFAULT 'left'",
            'report_logo_right' => "TEXT DEFAULT ''",
            'report_watermark_text' => "TEXT DEFAULT ''",
            'report_watermark_enabled' => "INTEGER DEFAULT 0",
            'report_watermark_opacity' => "INTEGER DEFAULT 10",
            'report_signature_name' => "TEXT DEFAULT 'Librarian'",
            'report_signature_title' => "TEXT DEFAULT 'Chief Librarian'",
            'report_signature_image' => "TEXT DEFAULT ''",
            'report_signature_enabled' => "INTEGER DEFAULT 0",
            'report_footer_text' => "TEXT DEFAULT 'This is a system generated report'"
        ];
        foreach ($missingSettingCols as $col => $typeDef) if (!in_array($col, $existingSettingCols)) try { $db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        if ($db->query("SELECT COUNT(*) FROM quotes")->fetchColumn() == 0) {
            $db->exec("INSERT INTO quotes (text, author, is_active) VALUES ('The only thing you absolutely have to know is the location of the library.', 'Albert Einstein', 1), ('Reading is to the mind what exercise is to the body.', 'Joseph Addison', 1), ('A library is a hospital for the mind.', 'Unknown', 1)");
        }
        $db->exec("CREATE INDEX IF NOT EXISTS idx_book_suggestions_admno ON book_suggestions(admno)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_book_suggestions_status ON book_suggestions(status)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_quotes_active ON quotes(is_active)");
    }

    private function upgradeToVersion11() {
        $db = $this->db;
        $userCols = $db->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('totp_secret', $userCols)) $db->exec("ALTER TABLE users ADD COLUMN totp_secret TEXT DEFAULT ''");
        if (!in_array('totp_enabled', $userCols)) $db->exec("ALTER TABLE users ADD COLUMN totp_enabled INTEGER DEFAULT 0");
        $db->exec("CREATE TABLE IF NOT EXISTS totp_recovery_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, code TEXT NOT NULL, used INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)");
        $memberCols = $db->query("PRAGMA table_info(members)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('is_email_verified', $memberCols)) $db->exec("ALTER TABLE members ADD COLUMN is_email_verified INTEGER DEFAULT 0");
        if (!in_array('verification_token', $memberCols)) $db->exec("ALTER TABLE members ADD COLUMN verification_token TEXT DEFAULT ''");
        if (!in_array('verification_expiry', $memberCols)) $db->exec("ALTER TABLE members ADD COLUMN verification_expiry DATETIME");
        if (!in_array('approval_status', $memberCols)) $db->exec("ALTER TABLE members ADD COLUMN approval_status TEXT DEFAULT 'pending'");
        $settingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettings = [
            'enable_2fa' => "INTEGER DEFAULT 0", 'session_lifetime' => "INTEGER DEFAULT 7200", 'failed_login_attempts' => "INTEGER DEFAULT 5", 'lockout_time' => "INTEGER DEFAULT 15",
            'cookie_secure' => "INTEGER DEFAULT 0", 'cookie_httponly' => "INTEGER DEFAULT 1", 'gdpr_enabled' => "INTEGER DEFAULT 0", 'gdpr_consent_text' => "TEXT DEFAULT ''",
            'api_keys' => "TEXT DEFAULT ''", 'custom_css_admin' => "TEXT DEFAULT ''", 'admin_dark_mode' => "INTEGER DEFAULT 0", 'maintenance_whitelist_ips' => "TEXT DEFAULT ''",
            'smtp_timeout' => "INTEGER DEFAULT 30", 'backup_encryption' => "INTEGER DEFAULT 0", 'ftp_backup_enabled' => "INTEGER DEFAULT 0", 'ftp_host' => "TEXT DEFAULT ''",
            'ftp_username' => "TEXT DEFAULT ''", 'ftp_password' => "TEXT DEFAULT ''", 'ftp_path' => "TEXT DEFAULT ''", 'sftp_backup_enabled' => "INTEGER DEFAULT 0",
            'sftp_host' => "TEXT DEFAULT ''", 'sftp_username' => "TEXT DEFAULT ''", 'sftp_password' => "TEXT DEFAULT ''", 'sftp_port' => "INTEGER DEFAULT 22", 'sftp_path' => "TEXT DEFAULT ''",
            'webdav_backup_enabled' => "INTEGER DEFAULT 0", 'webdav_url' => "TEXT DEFAULT ''", 'webdav_username' => "TEXT DEFAULT ''", 'webdav_password' => "TEXT DEFAULT ''",
            'backup_retention_days_cloud' => "INTEGER DEFAULT 90", 'auto_cleanup_temp' => "INTEGER DEFAULT 1", 'system_health_checks' => "INTEGER DEFAULT 1",
            'opac_social_facebook' => "TEXT DEFAULT ''", 'opac_social_twitter' => "TEXT DEFAULT ''", 'opac_social_instagram' => "TEXT DEFAULT ''", 'opac_custom_html_header' => "TEXT DEFAULT ''",
            'opac_custom_html_footer' => "TEXT DEFAULT ''", 'fine_rule_based_on_material' => "INTEGER DEFAULT 0", 'fine_grace_period_holidays' => "INTEGER DEFAULT 0",
            'notification_bcc_email' => "TEXT DEFAULT ''", 'member_registration_approval' => "INTEGER DEFAULT 0", 'default_member_expiry_days' => "INTEGER DEFAULT 365",
            'enable_email_verification' => "INTEGER DEFAULT 0", 'email_verification_subject' => "TEXT DEFAULT ''", 'email_verification_body' => "TEXT DEFAULT ''"
        ];
        foreach ($newSettings as $col => $typeDef) if (!in_array($col, $settingCols)) try { $db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        $db->exec("CREATE INDEX IF NOT EXISTS idx_members_verification ON members(verification_token, verification_expiry)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_members_approval ON members(approval_status)");
        $db->exec("CREATE INDEX IF NOT EXISTS idx_totp_recovery_codes_user ON totp_recovery_codes(user_id)");
    }

    private function upgradeToVersion12() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS library_branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, code TEXT UNIQUE NOT NULL, address TEXT, phone TEXT, email TEXT, manager TEXT, status TEXT DEFAULT 'active', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS budgets (id INTEGER PRIMARY KEY AUTOINCREMENT, fiscal_year TEXT NOT NULL, fund_code TEXT NOT NULL, description TEXT, total_amount REAL NOT NULL, allocated_amount REAL DEFAULT 0, expended_amount REAL DEFAULT 0, encumbered_amount REAL DEFAULT 0, status TEXT DEFAULT 'active', branch_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(branch_id) REFERENCES library_branches(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS interlibrary_loans (id INTEGER PRIMARY KEY AUTOINCREMENT, requesting_member_admno TEXT NOT NULL, requested_book_title TEXT NOT NULL, author TEXT, isbn TEXT, borrowing_institution TEXT NOT NULL, lending_institution TEXT NOT NULL, request_date DATE NOT NULL, due_date DATE, return_date DATE, status TEXT DEFAULT 'requested' CHECK(status IN ('requested','approved','shipped','received','returned','cancelled')), notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS course_reserves (id INTEGER PRIMARY KEY AUTOINCREMENT, course_name TEXT NOT NULL, course_code TEXT UNIQUE NOT NULL, instructor_name TEXT, academic_year TEXT, semester TEXT, status TEXT DEFAULT 'active', created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS course_reserve_items (id INTEGER PRIMARY KEY AUTOINCREMENT, course_reserve_id INTEGER NOT NULL, book_barcode TEXT NOT NULL, title TEXT NOT NULL, author TEXT, loan_period INTEGER DEFAULT 2, notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(course_reserve_id) REFERENCES course_reserves(id) ON DELETE CASCADE, FOREIGN KEY(book_barcode) REFERENCES books(barcode) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS digital_asset_usage (id INTEGER PRIMARY KEY AUTOINCREMENT, asset_type TEXT CHECK(asset_type IN ('ebook','database','research_article')) NOT NULL, asset_id INTEGER NOT NULL, member_admno TEXT NOT NULL, accessed_at DATETIME DEFAULT CURRENT_TIMESTAMP, duration INTEGER DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS audit_trail_detailed (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL, table_name TEXT NOT NULL, record_id INTEGER, old_values TEXT, new_values TEXT, ip_address TEXT, user_agent TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
        $db->exec("CREATE TABLE IF NOT EXISTS scheduled_jobs (id INTEGER PRIMARY KEY AUTOINCREMENT, job_name TEXT UNIQUE NOT NULL, last_run DATETIME, next_run DATETIME, status TEXT DEFAULT 'pending' CHECK(status IN ('pending','running','completed','failed')), parameters TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        $db->exec("CREATE TABLE IF NOT EXISTS notification_templates (id INTEGER PRIMARY KEY AUTOINCREMENT, template_key TEXT UNIQUE NOT NULL, channel TEXT CHECK(channel IN ('email','sms','whatsapp','push')) NOT NULL, subject TEXT, body TEXT NOT NULL, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        $db->exec("CREATE TABLE IF NOT EXISTS budget_allocations (id INTEGER PRIMARY KEY AUTOINCREMENT, budget_id INTEGER NOT NULL, allocated_to TEXT NOT NULL, amount REAL NOT NULL, allocated_date DATE DEFAULT CURRENT_DATE, notes TEXT, FOREIGN KEY(budget_id) REFERENCES budgets(id) ON DELETE CASCADE)");
        $db->exec("CREATE TABLE IF NOT EXISTS library_cards (id INTEGER PRIMARY KEY AUTOINCREMENT, member_admno TEXT UNIQUE NOT NULL, card_number TEXT UNIQUE NOT NULL, issue_date DATE DEFAULT CURRENT_DATE, expiry_date DATE, is_active INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(member_admno) REFERENCES members(admno) ON DELETE CASCADE)");
        $settingCols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $newSettingsCols = [
            'enable_multi_branch' => "INTEGER DEFAULT 0",
            'enable_budgeting' => "INTEGER DEFAULT 0",
            'enable_interlibrary' => "INTEGER DEFAULT 0",
            'enable_course_reserves' => "INTEGER DEFAULT 0",
            'digital_asset_tracking' => "INTEGER DEFAULT 0",
            'detailed_audit_log' => "INTEGER DEFAULT 0",
            'auto_scheduled_jobs' => "INTEGER DEFAULT 1"
        ];
        foreach ($newSettingsCols as $col => $typeDef) if (!in_array($col, $settingCols)) try { $db->exec("ALTER TABLE settings ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        if ($db->query("SELECT COUNT(*) FROM notification_templates")->fetchColumn() == 0) {
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('overdue_email', 'email', 'Overdue Book Notice', 'Dear {name}, the book \"{title}\" is overdue by {days} days. Please return it immediately.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('overdue_sms', 'sms', NULL, 'Book \"{title}\" overdue by {days} days. Return ASAP.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('welcome_email', 'email', 'Welcome to the Library', 'Dear {name}, your library membership has been activated. Enjoy reading!')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('hold_available', 'email', 'Book Hold Available', 'Dear {name}, the book \"{title}\" you requested is now available for pickup.')");
            $db->exec("INSERT INTO notification_templates (template_key, channel, subject, body) VALUES ('interlibrary_request', 'email', 'Interlibrary Loan Request', 'Your interlibrary loan request for \"{title}\" has been {status}.')");
        }
        if ($db->query("SELECT COUNT(*) FROM library_branches")->fetchColumn() == 0) {
            $db->exec("INSERT INTO library_branches (name, code, address, phone, email, manager, status) VALUES ('Central Library', 'CEN', 'Main Campus', '1234567890', 'central@library.com', 'Admin', 'active')");
        }
        if ($db->query("SELECT COUNT(*) FROM scheduled_jobs")->fetchColumn() == 0) {
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('daily_backup', datetime('now', '+1 day'), 'pending', '{\"type\":\"full\"}')");
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('overdue_notifications', datetime('now', '+1 hour'), 'pending', '{\"notify\":true}')");
            $db->exec("INSERT INTO scheduled_jobs (job_name, next_run, status, parameters) VALUES ('daily_stats', datetime('now', '+1 hour'), 'pending', '{}')");
        }
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_library_branches_code ON library_branches(code)",
            "CREATE INDEX IF NOT EXISTS idx_budgets_fiscal_year ON budgets(fiscal_year)",
            "CREATE INDEX IF NOT EXISTS idx_interlibrary_loans_member ON interlibrary_loans(requesting_member_admno)",
            "CREATE INDEX IF NOT EXISTS idx_course_reserves_code ON course_reserves(course_code)",
            "CREATE INDEX IF NOT EXISTS idx_audit_trail_user ON audit_trail_detailed(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_trail_table ON audit_trail_detailed(table_name)",
            "CREATE INDEX IF NOT EXISTS idx_scheduled_jobs_next_run ON scheduled_jobs(next_run)",
            "CREATE INDEX IF NOT EXISTS idx_notification_templates_key ON notification_templates(template_key)",
            "CREATE INDEX IF NOT EXISTS idx_library_cards_member ON library_cards(member_admno)",
            "CREATE INDEX IF NOT EXISTS idx_library_cards_card ON library_cards(card_number)"
        ];
        foreach ($indexes as $sql) try { $db->exec($sql); } catch (PDOException $e) {}
    }

    private function upgradeToVersion13() {
        $db = $this->db;
        $memberCols = $db->query("PRAGMA table_info(members)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $memberNewCols = [
            'designation' => "TEXT DEFAULT ''", 'emergency_contact' => "TEXT DEFAULT ''", 'general_id' => "TEXT DEFAULT ''",
            'security_deposit' => "REAL DEFAULT 0", 'membership_expiry' => "DATE", 'total_paid_fines' => "REAL DEFAULT 0",
            'is_email_verified' => "INTEGER DEFAULT 0", 'verification_token' => "TEXT DEFAULT ''", 'verification_expiry' => "DATETIME", 'approval_status' => "TEXT DEFAULT 'pending'"
        ];
        foreach ($memberNewCols as $col => $def) if (!in_array($col, $memberCols)) try { $db->exec("ALTER TABLE members ADD COLUMN $col $def"); } catch (PDOException $e) {}
        $bookCols = $db->query("PRAGMA table_info(books)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $bookNewCols = [
            'maintenance' => "TEXT DEFAULT ''", 'current_location' => "TEXT DEFAULT ''", 'section' => "TEXT DEFAULT ''",
            'ddc' => "TEXT DEFAULT ''", 'udc' => "TEXT DEFAULT ''", 'lcc' => "TEXT DEFAULT ''", 'cutter' => "TEXT DEFAULT ''",
            'series' => "TEXT DEFAULT ''", 'volume' => "TEXT DEFAULT ''", 'corporate_author' => "TEXT DEFAULT ''",
            'conference_author' => "TEXT DEFAULT ''", 'issn' => "TEXT DEFAULT ''", 'illustrations' => "TEXT DEFAULT ''",
            'dimensions' => "TEXT DEFAULT ''", 'country' => "TEXT DEFAULT ''", 'collection_type' => "TEXT DEFAULT ''",
            'branch' => "TEXT DEFAULT ''", 'shelf' => "TEXT DEFAULT ''", 'vendor' => "TEXT DEFAULT ''", 'invoice' => "TEXT DEFAULT ''",
            'invoice_date' => "DATE", 'acquisition_date' => "DATE", 'funding_source' => "TEXT DEFAULT ''", 'po_number' => "TEXT DEFAULT ''",
            'ebook_url' => "TEXT DEFAULT ''", 'contents' => "TEXT DEFAULT ''", 'accompanying_material' => "TEXT DEFAULT ''",
            'material_type' => "TEXT DEFAULT ''", 'size' => "TEXT DEFAULT ''", 'weight' => "TEXT DEFAULT ''", 'cc' => "TEXT DEFAULT ''",
            'other_classification' => "TEXT DEFAULT ''"
        ];
        foreach ($bookNewCols as $col => $def) if (!in_array($col, $bookCols)) try { $db->exec("ALTER TABLE books ADD COLUMN $col $def"); } catch (PDOException $e) {}
        $dbCols = $db->query("PRAGMA table_info(research_databases)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $dbNewCols = [
            'logo_path' => "TEXT DEFAULT ''", 'subjects' => "TEXT DEFAULT ''", 'expiry_date' => "DATE", 'last_verified' => "DATE",
            'visits' => "INTEGER DEFAULT 0", 'proxy_url' => "TEXT DEFAULT ''", 'access_notes' => "TEXT DEFAULT ''",
            'contact_email' => "TEXT DEFAULT ''", 'deleted_at' => "DATETIME"
        ];
        foreach ($dbNewCols as $col => $def) if (!in_array($col, $dbCols)) try { $db->exec("ALTER TABLE research_databases ADD COLUMN $col $def"); } catch (PDOException $e) {}
        $notifCols = $db->query("PRAGMA table_info(overdue_notifications)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('sent_at', $notifCols)) try { $db->exec("ALTER TABLE overdue_notifications ADD COLUMN sent_at DATETIME DEFAULT CURRENT_TIMESTAMP"); } catch (PDOException $e) {}
        $reminderCols = $db->query("PRAGMA table_info(serial_reminders)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('opened_at', $reminderCols)) try { $db->exec("ALTER TABLE serial_reminders ADD COLUMN opened_at DATETIME"); } catch (PDOException $e) {}
        if (!in_array('clicked_at', $reminderCols)) try { $db->exec("ALTER TABLE serial_reminders ADD COLUMN clicked_at DATETIME"); } catch (PDOException $e) {}
        $ebookCols = $db->query("PRAGMA table_info(ebooks)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('full_text', $ebookCols)) try { $db->exec("ALTER TABLE ebooks ADD COLUMN full_text TEXT"); } catch (PDOException $e) {}
        if (!in_array('cloud_file_id', $ebookCols)) try { $db->exec("ALTER TABLE ebooks ADD COLUMN cloud_file_id TEXT DEFAULT ''"); } catch (PDOException $e) {}
        if (!in_array('storage_type', $ebookCols)) try { $db->exec("ALTER TABLE ebooks ADD COLUMN storage_type TEXT DEFAULT 'local'"); } catch (PDOException $e) {}
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_books_maintenance ON books(maintenance)",
            "CREATE INDEX IF NOT EXISTS idx_books_current_location ON books(current_location)",
            "CREATE INDEX IF NOT EXISTS idx_books_section ON books(section)",
            "CREATE INDEX IF NOT EXISTS idx_books_cc ON books(cc)",
            "CREATE INDEX IF NOT EXISTS idx_members_designation ON members(designation)",
            "CREATE INDEX IF NOT EXISTS idx_members_general_id ON members(general_id)",
            "CREATE INDEX IF NOT EXISTS idx_members_membership_expiry ON members(membership_expiry)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_visits ON research_databases(visits)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_expiry ON research_databases(expiry_date)",
            "CREATE INDEX IF NOT EXISTS idx_research_databases_deleted ON research_databases(deleted_at)"
        ];
        foreach ($indexes as $sql) try { $db->exec($sql); } catch (PDOException $e) {}
    }

    private function upgradeToVersion14() {
        $db = $this->db;
        $db->exec("CREATE TABLE IF NOT EXISTS notification_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            user_type TEXT CHECK(user_type IN ('admin','member','staff')) NOT NULL,
            notification_type TEXT NOT NULL,
            channel TEXT CHECK(channel IN ('email','sms','whatsapp','push','in_app')) NOT NULL,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME,
            UNIQUE(user_id, user_type, notification_type, channel),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS system_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            check_name TEXT NOT NULL,
            status TEXT CHECK(status IN ('pass','fail','warning')) NOT NULL,
            message TEXT,
            details TEXT,
            checked_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS book_metadata_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            isbn TEXT UNIQUE NOT NULL,
            title TEXT,
            author TEXT,
            publisher TEXT,
            year TEXT,
            pages INTEGER,
            cover_url TEXT,
            summary TEXT,
            subjects TEXT,
            language TEXT,
            last_fetched DATETIME DEFAULT CURRENT_TIMESTAMP,
            fetch_count INTEGER DEFAULT 1
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS user_activity_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            activity_date DATE NOT NULL,
            login_count INTEGER DEFAULT 0,
            searches INTEGER DEFAULT 0,
            books_issued INTEGER DEFAULT 0,
            books_returned INTEGER DEFAULT 0,
            fines_paid REAL DEFAULT 0,
            UNIQUE(user_id, activity_date),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS circulation_summary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_barcode TEXT NOT NULL,
            month_year TEXT NOT NULL,
            issue_count INTEGER DEFAULT 0,
            return_count INTEGER DEFAULT 0,
            renew_count INTEGER DEFAULT 0,
            UNIQUE(book_barcode, month_year),
            FOREIGN KEY(book_barcode) REFERENCES books(barcode) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS member_reading_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_admno TEXT NOT NULL,
            preferred_categories TEXT,
            preferred_authors TEXT,
            preferred_languages TEXT,
            reading_level TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(member_admno),
            FOREIGN KEY(member_admno) REFERENCES members(admno) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS social_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            provider TEXT NOT NULL CHECK(provider IN ('google','facebook','github','microsoft','linkedin')),
            provider_user_id TEXT NOT NULL,
            email TEXT,
            avatar_url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login DATETIME,
            UNIQUE(provider, provider_user_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS twofa_backup_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            code TEXT NOT NULL,
            used INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS api_rate_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            request_count INTEGER DEFAULT 1,
            reset_at DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(api_key, endpoint, reset_at)
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS search_analytics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            search_term TEXT NOT NULL,
            search_type TEXT DEFAULT 'books',
            results_count INTEGER DEFAULT 0,
            user_id INTEGER,
            user_type TEXT CHECK(user_type IN ('admin','member','guest')),
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )");
        $this->addMissingColumns();
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_notification_preferences_user ON notification_preferences(user_id, user_type)",
            "CREATE INDEX IF NOT EXISTS idx_social_accounts_user ON social_accounts(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_twofa_backup_codes_user ON twofa_backup_codes(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_api_rate_limits_key ON api_rate_limits(api_key, reset_at)",
            "CREATE INDEX IF NOT EXISTS idx_search_analytics_term ON search_analytics(search_term, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_user_activity_summary_date ON user_activity_summary(user_id, activity_date)",
            "CREATE INDEX IF NOT EXISTS idx_circulation_summary_barcode ON circulation_summary(book_barcode, month_year)",
            "CREATE INDEX IF NOT EXISTS idx_book_metadata_cache_isbn ON book_metadata_cache(isbn)",
            "CREATE INDEX IF NOT EXISTS idx_system_health_checked ON system_health(checked_at)"
        ];
        foreach ($indexes as $sql) try { $db->exec($sql); } catch (PDOException $e) {}
    }

    private function addMissingColumns() {
        $db = $this->db;
        $columnsToAdd = [
            'books' => ['price_currency' => "TEXT DEFAULT 'INR'", 'book_status' => "TEXT DEFAULT 'Available'", 'binding' => "TEXT DEFAULT ''", 'holding' => "TEXT DEFAULT ''", 'sub_title' => "TEXT DEFAULT ''", 'author2' => "TEXT DEFAULT ''", 'collaborator' => "TEXT DEFAULT ''", 'subject' => "TEXT DEFAULT ''", 'maintenance' => "TEXT DEFAULT ''", 'current_location' => "TEXT DEFAULT ''", 'section' => "TEXT DEFAULT ''", 'ddc' => "TEXT DEFAULT ''", 'udc' => "TEXT DEFAULT ''", 'lcc' => "TEXT DEFAULT ''", 'cutter' => "TEXT DEFAULT ''", 'series' => "TEXT DEFAULT ''", 'volume' => "TEXT DEFAULT ''", 'corporate_author' => "TEXT DEFAULT ''", 'conference_author' => "TEXT DEFAULT ''", 'issn' => "TEXT DEFAULT ''", 'illustrations' => "TEXT DEFAULT ''", 'dimensions' => "TEXT DEFAULT ''", 'country' => "TEXT DEFAULT ''", 'collection_type' => "TEXT DEFAULT ''", 'branch' => "TEXT DEFAULT ''", 'shelf' => "TEXT DEFAULT ''", 'vendor' => "TEXT DEFAULT ''", 'invoice' => "TEXT DEFAULT ''", 'invoice_date' => "DATE", 'acquisition_date' => "DATE", 'funding_source' => "TEXT DEFAULT ''", 'po_number' => "TEXT DEFAULT ''", 'ebook_url' => "TEXT DEFAULT ''", 'contents' => "TEXT DEFAULT ''", 'accompanying_material' => "TEXT DEFAULT ''", 'material_type' => "TEXT DEFAULT ''", 'size' => "TEXT DEFAULT ''", 'weight' => "TEXT DEFAULT ''", 'cc' => "TEXT DEFAULT ''", 'other_classification' => "TEXT DEFAULT ''"],
            'members' => ['security_deposit' => "REAL DEFAULT 0", 'membership_expiry' => "DATE", 'total_paid_fines' => "REAL DEFAULT 0", 'emergency_contact' => "TEXT DEFAULT ''", 'general_id' => "TEXT DEFAULT ''", 'designation' => "TEXT DEFAULT ''", 'is_email_verified' => "INTEGER DEFAULT 0", 'verification_token' => "TEXT DEFAULT ''", 'verification_expiry' => "DATETIME", 'approval_status' => "TEXT DEFAULT 'pending'"],
            'settings' => ['max_fine_amount' => "REAL DEFAULT 0", 'enable_self_registration' => "BOOLEAN DEFAULT 0", 'self_registration_role' => "TEXT DEFAULT 'Student'", 'email_template_overdue' => "TEXT", 'sms_template_overdue' => "TEXT", 'whatsapp_template_overdue' => "TEXT", 'enable_member_password_reset' => "INTEGER DEFAULT 1", 'reset_token_expiry_hours' => "INTEGER DEFAULT 24", 'allow_member_password_change' => "INTEGER DEFAULT 1", 'cloud_storage_provider' => "TEXT DEFAULT 'local'", 'currency_code' => "TEXT DEFAULT 'USD'", 'currency_symbol' => "TEXT DEFAULT '$'", 'max_renewals' => "INTEGER DEFAULT 0", 'enable_audit_log' => "INTEGER DEFAULT 1", 'audit_log_retention_days' => "INTEGER DEFAULT 90", 'enable_member_notifications' => "INTEGER DEFAULT 1", 'default_language' => "TEXT DEFAULT 'en'", 'site_maintenance_mode' => "INTEGER DEFAULT 0", 'maintenance_message' => "TEXT DEFAULT 'System under maintenance. Please check back later.'", 'razorpay_key_id' => "TEXT DEFAULT ''", 'razorpay_key_secret' => "TEXT DEFAULT ''", 'session_check_ip' => "INTEGER DEFAULT 0", 'max_concurrent_sessions' => "INTEGER DEFAULT 5", 'opac_show_databases' => "INTEGER DEFAULT 1", 'container_max_width' => "INTEGER DEFAULT 1600", 'container_padding' => "INTEGER DEFAULT 10", 'opac_font_family' => "TEXT DEFAULT 'Inter'", 'opac_base_font_size' => "INTEGER DEFAULT 16", 'opac_heading_font_size' => "INTEGER DEFAULT 32", 'opac_primary_color' => "TEXT DEFAULT '#1e3c72'", 'opac_header_bg_color' => "TEXT DEFAULT '#1e3c72'", 'opac_body_bg' => "TEXT DEFAULT '#f0f2f5'", 'opac_custom_css' => "TEXT DEFAULT ''", 'opac_show_thought_of_the_day' => "INTEGER DEFAULT 1", 'opac_show_new_arrivals_in_left' => "INTEGER DEFAULT 1", 'opac_quote_rotation_interval' => "INTEGER DEFAULT 10", 'opac_carousel_type' => "TEXT DEFAULT 'cover_flow'", 'openai_api_key' => "TEXT DEFAULT ''"],
            'ebooks' => ['full_text' => "TEXT", 'cloud_file_id' => "TEXT DEFAULT ''", 'storage_type' => "TEXT DEFAULT 'local'"],
            'payment_transactions' => ['currency' => "TEXT DEFAULT 'INR'"],
            'lost_books' => ['currency' => "TEXT DEFAULT 'INR'"],
            'entry_exit' => ['notes' => "TEXT DEFAULT ''"],
            'users' => ['token_version' => "INTEGER DEFAULT 1", 'export_count' => "INTEGER DEFAULT 0", 'totp_secret' => "TEXT DEFAULT ''", 'totp_enabled' => "INTEGER DEFAULT 0"],
            'serial_subscriptions' => ['subscription_type' => "TEXT DEFAULT 'print'", 'access_url' => "TEXT DEFAULT ''", 'access_credentials' => "TEXT DEFAULT ''", 'digital_format' => "TEXT DEFAULT ''"],
            'circulation' => ['fine' => "REAL DEFAULT 0", 'renew_count' => "INTEGER DEFAULT 0"],
            'overdue_notifications' => ['sent_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP"],
            'serial_reminders' => ['opened_at' => "DATETIME", 'clicked_at' => "DATETIME"],
            'research_databases' => ['logo_path' => "TEXT DEFAULT ''", 'subjects' => "TEXT DEFAULT ''", 'expiry_date' => "DATE", 'last_verified' => "DATE", 'visits' => "INTEGER DEFAULT 0", 'proxy_url' => "TEXT DEFAULT ''", 'access_notes' => "TEXT DEFAULT ''", 'contact_email' => "TEXT DEFAULT ''", 'deleted_at' => "DATETIME"],
            'book_suggestions' => ['submitted_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP"]
        ];
        foreach ($columnsToAdd as $table => $columns) {
            if (!$this->tableExists($table)) continue;
            $existingCols = $db->query("PRAGMA table_info($table)")->fetchAll(PDO::FETCH_COLUMN, 1);
            foreach ($columns as $col => $typeDef) if (!in_array($col, $existingCols)) try { $db->exec("ALTER TABLE $table ADD COLUMN $col $typeDef"); } catch (PDOException $e) {}
        }
    }

    // ========== NEW DATABASE UTILITY METHODS ==========
    public function getVersion(): int {
        return $this->schemaVersion;
    }

    public function tableExists(string $tableName): bool {
        $stmt = $this->db->prepare("SELECT name FROM sqlite_master WHERE type='table' AND name = ?");
        $stmt->execute([$tableName]);
        return (bool)$stmt->fetch();
    }

    public function columnExists(string $tableName, string $columnName): bool {
        if (!$this->tableExists($tableName)) return false;
        $stmt = $this->db->prepare("PRAGMA table_info($tableName)");
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN, 1);
        return in_array($columnName, $columns);
    }

    public function addColumnIfNotExists(string $tableName, string $columnName, string $definition): bool {
        if ($this->columnExists($tableName, $columnName)) return true;
        try {
            $this->db->exec("ALTER TABLE $tableName ADD COLUMN $columnName $definition");
            return true;
        } catch (PDOException $e) {
            error_log("Failed to add column $columnName to $tableName: " . $e->getMessage());
            return false;
        }
    }

    public function countRows(string $tableName, string $where = '', array $params = []): int {
        $sql = "SELECT COUNT(*) FROM $tableName";
        if ($where) {
            $sql .= " WHERE $where";
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    }

    public function executeBatch(array $statements): array {
        $results = [];
        $this->db->beginTransaction();
        try {
            foreach ($statements as $key => $sql) {
                $results[$key] = $this->db->exec($sql);
            }
            $this->db->commit();
            return ['success' => true, 'results' => $results];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    public function getDatabaseSize(): int {
        return file_exists(DB_FILE) ? filesize(DB_FILE) : 0;
    }

    public function getDatabaseSizeHuman(): string {
        $size = $this->getDatabaseSize();
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($size >= 1024 && $i < 4) {
            $size /= 1024;
            $i++;
        }
        return round($size, 2) . ' ' . $units[$i];
    }

    public function getTableStats(): array {
        $tables = $this->db->query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
        $stats = [];
        foreach ($tables as $table) {
            if (strpos($table, 'sqlite_') === 0) continue;
            $count = $this->countRows($table);
            $stats[$table] = $count;
        }
        return $stats;
    }

    public function vacuumDatabase(): bool {
        try {
            $this->db->exec("VACUUM");
            return true;
        } catch (PDOException $e) {
            error_log("Vacuum failed: " . $e->getMessage());
            return false;
        }
    }

    public function lastInsertId(): int {
        return (int)$this->db->lastInsertId();
    }

    public function escapeLike(string $value): string {
        return str_replace(['%', '_'], ['\%', '\_'], $value);
    }

    public function beginTransaction(): bool {
        return $this->db->beginTransaction();
    }

    public function commit(): bool {
        return $this->db->commit();
    }

    public function rollBack(): bool {
        return $this->db->rollBack();
    }

    public function inTransaction(): bool {
        return $this->db->inTransaction();
    }

    public function quote(string $value): string {
        return $this->db->quote($value);
    }

    public function processScheduledJobs(): void {
        $db = $this->db;
        $now = date('Y-m-d H:i:s');
        $jobs = $db->query("SELECT * FROM scheduled_jobs WHERE next_run <= '$now' AND status = 'pending'")->fetchAll();
        foreach ($jobs as $job) {
            $db->prepare("UPDATE scheduled_jobs SET status = 'running', last_run = '$now' WHERE id = ?")->execute([$job['id']]);
            try {
                switch ($job['job_name']) {
                    case 'daily_backup':
                        backupDatabase();
                        break;
                    case 'overdue_notifications':
                        runOverdueNotifications();
                        break;
                    case 'daily_stats':
                        updateDailyStats();
                        break;
                }
                $next = date('Y-m-d H:i:s', strtotime('+1 day'));
                $db->prepare("UPDATE scheduled_jobs SET status = 'completed', next_run = '$next' WHERE id = ?")->execute([$job['id']]);
            } catch (Exception $e) {
                $db->prepare("UPDATE scheduled_jobs SET status = 'failed' WHERE id = ?")->execute([$job['id']]);
            }
        }
    }
}

// ==================== GLOBAL HELPER FUNCTIONS ====================
if (!function_exists('getDB')) {
    function getDB() { return Database::getInstance()->getConnection(); }
}

if (!function_exists('getInstitution')) {
    function getInstitution() {
        static $institution = null;
        if ($institution === null) { $db = getDB(); $stmt = $db->query("SELECT * FROM institutions WHERE status = 'active' LIMIT 1"); $institution = $stmt->fetch() ?: ['name' => 'Library System']; }
        return $institution;
    }
}

if (!function_exists('getSettings')) {
    function getSettings() {
        static $settings = null;
        if ($settings === null) {
            $db = getDB();
            $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
            $settings = $stmt->fetch() ?: [];
            $defaults = [
                'loan_days' => 7, 'fine_per_day' => 2, 'max_books' => 5,
                'menu_position' => 'top', 'software_header' => 'Library ERP System',
                'library_logo' => '', 'favicon_path' => '', 'backup_email' => '',
                'notify_overdue' => 1, 'auto_logout_minutes' => 30,
                'new_arrivals_count' => 10, 'enable_sms' => 0, 'sms_api_key' => '',
                'enable_email' => 1, 'backup_password' => '', 'opac_enabled' => 1,
                'allow_holds' => 1, 'hold_days' => 7, 'google_drive_enabled' => 0,
                'google_drive_folder_id' => '', 'google_drive_client_id' => '',
                'google_drive_client_secret' => '', 'google_drive_refresh_token' => '',
                'smtp_host' => '', 'smtp_port' => 587, 'smtp_encryption' => 'tls',
                'smtp_username' => '', 'smtp_password' => '', 'mail_from' => '',
                'mail_from_name' => '', 'backup_schedule' => 'daily',
                'backup_time' => '00:00', 'current_institution_id' => 1,
                'opac_show_new_arrivals' => 1, 'opac_show_popular_ebooks' => 1,
                'opac_show_latest_ebooks' => 1, 'opac_show_notices' => 1,
                'opac_show_trending' => 1, 'opac_show_databases' => 1,
                'opac_header_text' => '', 'opac_tagline' => '',
                'opac_books_per_page' => 12, 'opac_ebooks_per_page' => 8,
                'image_base_path' => 'uploads/', 'enable_whatsapp' => 0,
                'whatsapp_api_key' => '', 'whatsapp_phone_number' => '',
                'whatsapp_api_url' => '', 'right_logo_path' => '',
                'opac_notice_title' => '', 'opac_notice_content' => '',
                'max_fine_amount' => 0, 'enable_self_registration' => 0,
                'self_registration_role' => 'Student', 'email_template_overdue' => '',
                'sms_template_overdue' => '', 'whatsapp_template_overdue' => '',
                'enable_member_password_reset' => 1, 'reset_token_expiry_hours' => 24,
                'allow_member_password_change' => 1, 'cloud_storage_provider' => 'local',
                'cloud_api_key' => '', 'cloud_api_secret' => '',
                'cloud_refresh_token' => '', 'cloud_folder_id' => '',
                'google_drive_service_account_json' => '', 'last_export' => null,
                'currency_code' => 'USD', 'currency_symbol' => '$',
                'currency_position' => 'left', 'opac_header_logo' => '',
                'login_bg_color' => '#667eea', 'login_text_color' => '#ffffff',
                'login_header_logo' => '', 'login_font_family' => 'Inter',
                'login_base_font_size' => 16, 'staff_display_enabled' => 1,
                'staff_card_bg_color' => '#ffffff', 'currency_decimal_places' => 2,
                'guest_enabled' => 1, 'guest_prefix' => 'GUEST-',
                'guest_number_padding' => 4, 'guest_last_reset' => null,
                'whatsapp_number' => '', 'whatsapp_message' => 'Hello, I need assistance from the library.',
                'fine_grace_period' => 0, 'fine_calculation_method' => 'daily',
                'auto_waive_fine_after_return' => 0, 'fine_reminder_days' => 3,
                'enable_overdue_notifications' => 1, 'library_open_days' => '1,2,3,4,5',
                'library_open_time' => '09:00', 'library_close_time' => '18:00',
                'library_lunch_start' => '', 'library_lunch_end' => '',
                'library_timezone' => 'Asia/Kolkata', 'container_max_width' => 1600,
                'container_padding' => 10, 'opac_font_family' => 'Inter',
                'opac_base_font_size' => 16, 'opac_heading_font_size' => 32,
                'opac_primary_color' => '#1e3c72', 'opac_header_bg_color' => '#1e3c72',
                'opac_body_bg' => '#f0f2f5', 'opac_custom_css' => '',
                'max_renewals' => 0, 'enable_audit_log' => 1,
                'audit_log_retention_days' => 90, 'enable_member_notifications' => 1,
                'default_language' => 'en', 'site_maintenance_mode' => 0,
                'maintenance_message' => 'System under maintenance. Please check back later.',
                'razorpay_key_id' => '', 'razorpay_key_secret' => '',
                'session_check_ip' => 0, 'max_concurrent_sessions' => 5,
                'visitor_header_logo' => '', 'visitor_header_text' => '',
                'visitor_tagline' => 'Visitors Log', 'visitor_header_bg' => '#1e3c72',
                'visitor_body_bg' => '#f0f2f5', 'visitor_footer_bg' => '#1e3c72',
                'visitor_font_family' => 'Inter', 'visitor_base_font_size' => 16,
                'visitor_primary_color' => '#28a745',
                'report_font_size' => 10, 'report_primary_color' => '#1e3c72',
                'report_logo_position' => 'left', 'report_logo_right' => '',
                'report_watermark_text' => '', 'report_watermark_enabled' => 0,
                'report_watermark_opacity' => 10, 'report_signature_name' => 'Librarian',
                'report_signature_title' => 'Chief Librarian', 'report_signature_image' => '',
                'report_signature_enabled' => 0, 'report_footer_text' => 'This is a system generated report',
                'opac_show_thought_of_the_day' => 1, 'opac_show_new_arrivals_in_left' => 1,
                'opac_quote_rotation_interval' => 10, 'opac_carousel_type' => 'cover_flow',
                'openai_api_key' => '',
                'enable_2fa' => 0, 'session_lifetime' => 7200, 'failed_login_attempts' => 5, 'lockout_time' => 15,
                'cookie_secure' => 0, 'cookie_httponly' => 1, 'gdpr_enabled' => 0, 'gdpr_consent_text' => '',
                'api_keys' => '', 'custom_css_admin' => '', 'admin_dark_mode' => 0,
                'maintenance_whitelist_ips' => '', 'smtp_timeout' => 30, 'backup_encryption' => 0,
                'ftp_backup_enabled' => 0, 'ftp_host' => '', 'ftp_username' => '', 'ftp_password' => '', 'ftp_path' => '',
                'sftp_backup_enabled' => 0, 'sftp_host' => '', 'sftp_username' => '', 'sftp_password' => '', 'sftp_port' => 22, 'sftp_path' => '',
                'webdav_backup_enabled' => 0, 'webdav_url' => '', 'webdav_username' => '', 'webdav_password' => '',
                'backup_retention_days_cloud' => 90, 'auto_cleanup_temp' => 1, 'system_health_checks' => 1,
                'opac_social_facebook' => '', 'opac_social_twitter' => '', 'opac_social_instagram' => '',
                'opac_custom_html_header' => '', 'opac_custom_html_footer' => '',
                'fine_rule_based_on_material' => 0, 'fine_grace_period_holidays' => 0,
                'notification_bcc_email' => '', 'member_registration_approval' => 0,
                'default_member_expiry_days' => 365, 'enable_email_verification' => 0,
                'email_verification_subject' => '', 'email_verification_body' => '',
                'enable_multi_branch' => 0, 'enable_budgeting' => 0, 'enable_interlibrary' => 0,
                'enable_course_reserves' => 0, 'digital_asset_tracking' => 0, 'detailed_audit_log' => 0,
                'auto_scheduled_jobs' => 1,
                'enable_library_statistics' => 1,
                'statistics_retention_days' => 365,
                'opac_show_statistics' => 1
            ];
            foreach ($defaults as $key => $val) if (!isset($settings[$key])) $settings[$key] = $val;
        }
        return $settings;
    }
}

if (!function_exists('getLoanRule')) {
    function getLoanRule($patronCategory, $itemCategory) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = ? AND item_category = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$patronCategory, $itemCategory]);
        $rule = $stmt->fetch();
        if ($rule) return $rule;
        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = ? AND item_category = '*' AND is_active = 1 LIMIT 1");
        $stmt->execute([$patronCategory]);
        $rule = $stmt->fetch();
        if ($rule) return $rule;
        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = '*' AND item_category = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$itemCategory]);
        $rule = $stmt->fetch();
        if ($rule) return $rule;
        $stmt = $db->prepare("SELECT * FROM loan_rules WHERE patron_category = '*' AND item_category = '*' AND is_active = 1 LIMIT 1");
        $stmt->execute();
        return $stmt->fetch();
    }
}

if (!function_exists('getWebImageUrl')) {
    function getWebImageUrl($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $path = ltrim($path, '/');
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $protocol . $host . '/' . $path;
    }
}

if (!function_exists('requireLogin')) {
    function requireLogin() { if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; } }
}

if (!function_exists('requireAdmin')) {
    function requireAdmin() { if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { header('Location: ../login.php'); exit; } }
}

if (!function_exists('requirePermission')) {
    function requirePermission($moduleKey) {
        if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit; }
        $role = $_SESSION['role'] ?? 'staff';
        if ($role === 'admin') return;
        $db = getDB();
        $stmt = $db->prepare("SELECT can_access FROM module_permissions WHERE role = ? AND module_key = ?");
        $stmt->execute([$role, $moduleKey]);
        if (!$stmt->fetchColumn()) { http_response_code(403); die("Access denied to module: $moduleKey"); }
    }
}

if (!function_exists('logActivity')) {
    function logActivity($username, $action, $details = '') { $db = getDB(); $ip = $_SERVER['REMOTE_ADDR'] ?? ''; $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address) VALUES (?, ?, ?, ?)"); $stmt->execute([$username, $action, $details, $ip]); }
}

if (!function_exists('logDetailedAudit')) {
    function logDetailedAudit($userId, $action, $tableName, $recordId, $oldValues = null, $newValues = null) {
        $settings = getSettings();
        if (!$settings['detailed_audit_log']) return;
        $db = getDB();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $stmt = $db->prepare("INSERT INTO audit_trail_detailed (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $action, $tableName, $recordId, $oldValues ? json_encode($oldValues) : null, $newValues ? json_encode($newValues) : null, $ip, $agent]);
    }
}

if (!function_exists('showToast')) {
    function showToast($message, $type = 'success') { $_SESSION['toast'] = ['message' => $message, 'type' => $type]; }
}

if (!function_exists('generateCSRFToken')) {
    function generateCSRFToken() { if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); return $_SESSION['csrf_token']; }
}

if (!function_exists('validateCSRFToken')) {
    function validateCSRFToken($token) { return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token); }
}

if (!function_exists('calculateFine')) {
    function calculateFine($dueDate, $returnDate = null, $memberCategory = null, $itemCategory = null) {
        $due = new DateTime($dueDate);
        $return = $returnDate ? new DateTime($returnDate) : new DateTime();
        if ($return <= $due) return 0.0;
        $daysOverdue = $return->diff($due)->days;
        $settings = getSettings();
        if ($memberCategory && $itemCategory) { $rule = getLoanRule($memberCategory, $itemCategory); $finePerDay = $rule['fine_per_day'] ?? $settings['fine_per_day']; $gracePeriod = $rule['grace_period'] ?? $settings['fine_grace_period'] ?? 0; }
        else { $finePerDay = $settings['fine_per_day']; $gracePeriod = $settings['fine_grace_period'] ?? 0; }
        $chargeableDays = max(0, $daysOverdue - $gracePeriod);
        return $chargeableDays * $finePerDay;
    }
}

if (!function_exists('getMemberById')) {
    function getMemberById($id) { $db = getDB(); $stmt = $db->prepare("SELECT * FROM members WHERE id = ?"); $stmt->execute([$id]); return $stmt->fetch(); }
}

if (!function_exists('getMemberByAdmno')) {
    function getMemberByAdmno($admno) { $db = getDB(); $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?"); $stmt->execute([$admno]); return $stmt->fetch(); }
}

if (!function_exists('getBookByBarcode')) {
    function getBookByBarcode($barcode) { $db = getDB(); $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?"); $stmt->execute([$barcode]); return $stmt->fetch(); }
}

if (!function_exists('getBookById')) {
    function getBookById($id) { $db = getDB(); $stmt = $db->prepare("SELECT * FROM books WHERE id = ?"); $stmt->execute([$id]); return $stmt->fetch(); }
}

if (!function_exists('isBookAvailable')) {
    function isBookAvailable($barcode, $quantity = 1) { $db = getDB(); $stmt = $db->prepare("SELECT available FROM books WHERE barcode = ?"); $stmt->execute([$barcode]); $avail = (int)$stmt->fetchColumn(); return $avail >= $quantity; }
}

if (!function_exists('updateBookAvailability')) {
    function updateBookAvailability($barcode, $change) { $db = getDB(); $stmt = $db->prepare("UPDATE books SET available = available + ? WHERE barcode = ?"); $stmt->execute([$change, $barcode]); return $stmt->rowCount() > 0; }
}

if (!function_exists('getOverdueLoans')) {
    function getOverdueLoans($daysThreshold = 0) { $db = getDB(); $sql = "SELECT c.*, m.name as member_name, m.email as member_email, m.phone as member_phone, b.title as book_title FROM circulation c JOIN members m ON c.admno = m.admno JOIN books b ON c.barcode = b.barcode WHERE c.return_date IS NULL AND c.due_date < date('now', '-' || ? || ' days') ORDER BY c.due_date ASC"; $stmt = $db->prepare($sql); $stmt->execute([$daysThreshold]); return $stmt->fetchAll(); }
}

if (!function_exists('queueEmail')) {
    function queueEmail($to, $subject, $body, $priority = 0) { $db = getDB(); $stmt = $db->prepare("INSERT INTO email_queue (to_email, subject, body, priority, status) VALUES (?, ?, ?, ?, 'pending')"); return $stmt->execute([$to, $subject, $body, $priority]); }
}

if (!function_exists('processEmailQueue')) {
    function processEmailQueue($limit = 10) { $settings = getSettings(); if (!$settings['enable_email'] || empty($settings['smtp_host'])) return 0; $db = getDB(); $stmt = $db->prepare("SELECT * FROM email_queue WHERE status = 'pending' ORDER BY priority DESC, created_at ASC LIMIT ?"); $stmt->execute([$limit]); $emails = $stmt->fetchAll(); $sent = 0; foreach ($emails as $email) { try { if (mail($email['to_email'], $email['subject'], $email['body'], "From: {$settings['mail_from']}")) { $db->prepare("UPDATE email_queue SET status = 'sent', last_attempt = CURRENT_TIMESTAMP WHERE id = ?")->execute([$email['id']]); $sent++; } else { $db->prepare("UPDATE email_queue SET attempts = attempts + 1, last_attempt = CURRENT_TIMESTAMP, error = 'mail() failed' WHERE id = ?")->execute([$email['id']]); } } catch (Exception $e) { $db->prepare("UPDATE email_queue SET attempts = attempts + 1, error = ? WHERE id = ?")->execute([$e->getMessage(), $email['id']]); } } return $sent; }
}

if (!function_exists('runOverdueNotifications')) {
    function runOverdueNotifications() { $settings = getSettings(); if (!$settings['enable_overdue_notifications']) return 0; $overdueLoans = getOverdueLoans(); $notified = 0; $db = getDB(); foreach ($overdueLoans as $loan) { $days = (new DateTime())->diff(new DateTime($loan['due_date']))->days; if ($settings['enable_email'] && !empty($loan['member_email'])) { $subject = "Overdue Book: {$loan['book_title']}"; $body = "Dear {$loan['member_name']},\n\nThe book \"{$loan['book_title']}\" is overdue by $days days. Please return it as soon as possible.\n\nRegards,\nLibrary"; queueEmail($loan['member_email'], $subject, $body); $db->prepare("INSERT INTO overdue_notifications (circulation_id, admno, notification_type, days_overdue, status) VALUES (?, ?, 'email', ?, 'pending')")->execute([$loan['id'], $loan['admno'], $days]); $notified++; } } return $notified; }
}

if (!function_exists('updateDailyStats')) {
    function updateDailyStats($date = null) { $db = getDB(); $date = $date ?: date('Y-m-d'); $db->exec("INSERT OR REPLACE INTO daily_stats (stat_date, books_issued, books_returned, members_registered, fines_collected, entries_count, exits_count, ebook_downloads, new_books_added, active_loans, overdue_count, total_outstanding_fines) SELECT '$date', (SELECT COUNT(*) FROM circulation WHERE date(issue_date) = '$date'), (SELECT COUNT(*) FROM circulation WHERE date(return_date) = '$date'), (SELECT COUNT(*) FROM members WHERE date(created_at) = '$date'), (SELECT COALESCE(SUM(amount),0) FROM fine_payments WHERE date(payment_date) = '$date'), (SELECT COUNT(*) FROM entry_exit WHERE date(entry_date) = '$date' AND status = 'inside'), (SELECT COUNT(*) FROM entry_exit WHERE date(exit_time) = '$date'), (SELECT COALESCE(SUM(downloads),0) FROM ebooks WHERE date(created_at) = '$date'), (SELECT COUNT(*) FROM books WHERE date(created_at) = '$date'), (SELECT COUNT(*) FROM circulation WHERE return_date IS NULL), (SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')), (SELECT COALESCE(SUM(total_fines),0) FROM members)"); return true; }
}

if (!function_exists('backupDatabase')) {
    function backupDatabase($outputFile = null) { if (!$outputFile) { if (!is_dir(BACKUP_DIR)) mkdir(BACKUP_DIR, 0777, true); $outputFile = BACKUP_DIR . 'backup_' . date('Y-m-d_H-i-s') . '.sql'; } $db = getDB(); $backup = ''; $tables = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")->fetchAll(PDO::FETCH_COLUMN); foreach ($tables as $table) { $backup .= "DROP TABLE IF EXISTS $table;\n"; $create = $db->query("SELECT sql FROM sqlite_master WHERE type='table' AND name='$table'")->fetchColumn(); $backup .= "$create;\n"; $rows = $db->query("SELECT * FROM $table")->fetchAll(); foreach ($rows as $row) { $columns = implode(',', array_keys($row)); $values = array_map(function($v) use ($db) { return $db->quote($v); }, array_values($row)); $backup .= "INSERT INTO $table ($columns) VALUES (" . implode(',', $values) . ");\n"; } $backup .= "\n"; } file_put_contents($outputFile, $backup); return $outputFile; }
}

if (!function_exists('restoreDatabase')) {
    function restoreDatabase($backupFile) { if (!file_exists($backupFile)) return false; $sql = file_get_contents($backupFile); $db = getDB(); $db->exec("PRAGMA foreign_keys = OFF"); $db->exec($sql); $db->exec("PRAGMA foreign_keys = ON"); return true; }
}

if (!function_exists('getSystemHealth')) {
    function getSystemHealth() { $checks = []; $checks['db_writable'] = is_writable(DB_FILE); $checks['upload_dir'] = is_writable(UPLOAD_DIR); $checks['backup_dir'] = is_writable(BACKUP_DIR); $checks['disk_free'] = disk_free_space(BASE_PATH) > 100 * 1024 * 1024; $checks['php_version'] = version_compare(PHP_VERSION, '7.4.0', '>='); $checks['pdo_sqlite'] = extension_loaded('pdo_sqlite'); $checks['gd'] = extension_loaded('gd'); $checks['zip'] = extension_loaded('zip'); $overdueCount = getDB()->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn(); $checks['overdue_books'] = $overdueCount; return $checks; }
}

// ========== ADDITIONAL HELPER FUNCTIONS ==========
if (!function_exists('addWhatsAppMessage')) {
    function addWhatsAppMessage($to, $message, $priority = 0, $scheduleAt = null) {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO whatsapp_queue (recipient_number, message_text, priority, scheduled_at, created_at) VALUES (?, ?, ?, ?, datetime('now'))");
        return $stmt->execute([$to, $message, $priority, $scheduleAt ?? date('Y-m-d H:i:s')]);
    }
}

if (!function_exists('createInterlibraryLoan')) {
    function createInterlibraryLoan($memberAdmno, $title, $author, $isbn, $borrowingInst, $lendingInst) {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO interlibrary_loans (requesting_member_admno, requested_book_title, author, isbn, borrowing_institution, lending_institution, request_date, status) VALUES (?, ?, ?, ?, ?, ?, date('now'), 'requested')");
        return $stmt->execute([$memberAdmno, $title, $author, $isbn, $borrowingInst, $lendingInst]);
    }
}

if (!function_exists('addCourseReserve')) {
    function addCourseReserve($courseName, $courseCode, $instructor, $academicYear, $semester) {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO course_reserves (course_name, course_code, instructor_name, academic_year, semester, status) VALUES (?, ?, ?, ?, ?, 'active')");
        return $stmt->execute([$courseName, $courseCode, $instructor, $academicYear, $semester]);
    }
}

if (!function_exists('getBudgetBalance')) {
    function getBudgetBalance($budgetId) {
        $db = getDB();
        $stmt = $db->prepare("SELECT total_amount, allocated_amount, expended_amount, encumbered_amount FROM budgets WHERE id = ?");
        $stmt->execute([$budgetId]);
        $budget = $stmt->fetch();
        if (!$budget) return 0;
        return $budget['total_amount'] - $budget['allocated_amount'] - $budget['expended_amount'] - $budget['encumbered_amount'];
    }
}

if (!function_exists('logDigitalAssetUsage')) {
    function logDigitalAssetUsage($assetType, $assetId, $memberAdmno, $duration = 0) {
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO digital_asset_usage (asset_type, asset_id, member_admno, duration) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$assetType, $assetId, $memberAdmno, $duration]);
    }
}

// ==================== NEW DATABASE UTILITY FUNCTIONS ====================
if (!function_exists('getDBVersion')) {
    function getDBVersion(): int {
        return Database::getInstance()->getVersion();
    }
}

if (!function_exists('tableExists')) {
    function tableExists(string $tableName): bool {
        return Database::getInstance()->tableExists($tableName);
    }
}

if (!function_exists('columnExists')) {
    function columnExists(string $tableName, string $columnName): bool {
        return Database::getInstance()->columnExists($tableName, $columnName);
    }
}

if (!function_exists('getTableStats')) {
    function getTableStats(): array {
        return Database::getInstance()->getTableStats();
    }
}

if (!function_exists('getDatabaseSize')) {
    function getDatabaseSize(): string {
        return Database::getInstance()->getDatabaseSizeHuman();
    }
}

if (!function_exists('vacuumDatabase')) {
    function vacuumDatabase(): bool {
        return Database::getInstance()->vacuumDatabase();
    }
}

if (!function_exists('getActiveSessionsCount')) {
    function getActiveSessionsCount(): int {
        $db = getDB();
        try {
            $stmt = $db->query("SELECT COUNT(*) FROM user_sessions WHERE expires_at > datetime('now')");
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('getOverdueCount')) {
    function getOverdueCount(): int {
        $db = getDB();
        try {
            $stmt = $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')");
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('getAvailableBooksCount')) {
    function getAvailableBooksCount(): int {
        $db = getDB();
        try {
            $stmt = $db->query("SELECT SUM(available) FROM books");
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('getMemberCountByCategory')) {
    function getMemberCountByCategory(string $category): int {
        $db = getDB();
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM members WHERE member_category = ? AND status = 'active'");
            $stmt->execute([$category]);
            return (int)$stmt->fetchColumn();
        } catch (PDOException $e) {
            return 0;
        }
    }
}

if (!function_exists('getTodayCirculation')) {
    function getTodayCirculation(): array {
        $db = getDB();
        try {
            $today = date('Y-m-d');
            $issued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(issue_date) = '$today'")->fetchColumn();
            $returned = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(return_date) = '$today'")->fetchColumn();
            return ['issued' => $issued, 'returned' => $returned];
        } catch (PDOException $e) {
            return ['issued' => 0, 'returned' => 0];
        }
    }
}

if (!function_exists('getRecentActivity')) {
    function getRecentActivity(int $limit = 20): array {
        $db = getDB();
        try {
            $stmt = $db->prepare("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT ?");
            $stmt->execute([$limit]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }
}

if (!function_exists('logSystemHealth')) {
    function logSystemHealth(string $checkName, string $status, string $message = '', string $details = ''): bool {
        $db = getDB();
        try {
            $stmt = $db->prepare("INSERT INTO system_health (check_name, status, message, details) VALUES (?, ?, ?, ?)");
            return $stmt->execute([$checkName, $status, $message, $details]);
        } catch (PDOException $e) {
            error_log("Failed to log system health: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getLatestSystemHealth')) {
    function getLatestSystemHealth(int $limit = 50): array {
        $db = getDB();
        try {
            $stmt = $db->query("SELECT * FROM system_health ORDER BY checked_at DESC LIMIT $limit");
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            return [];
        }
    }
}

if (!function_exists('cacheBookMetadata')) {
    function cacheBookMetadata(string $isbn, array $metadata): bool {
        $db = getDB();
        try {
            $stmt = $db->prepare("INSERT OR REPLACE INTO book_metadata_cache 
                (isbn, title, author, publisher, year, pages, cover_url, summary, subjects, language, last_fetched, fetch_count) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), COALESCE((SELECT fetch_count + 1 FROM book_metadata_cache WHERE isbn = ?), 1))");
            return $stmt->execute([
                $isbn,
                $metadata['title'] ?? '',
                $metadata['author'] ?? '',
                $metadata['publisher'] ?? '',
                $metadata['year'] ?? '',
                $metadata['pages'] ?? 0,
                $metadata['cover_url'] ?? '',
                $metadata['summary'] ?? '',
                $metadata['subjects'] ?? '',
                $metadata['language'] ?? '',
                $isbn
            ]);
        } catch (PDOException $e) {
            error_log("Failed to cache book metadata: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getCachedBookMetadata')) {
    function getCachedBookMetadata(string $isbn): ?array {
        $db = getDB();
        try {
            $stmt = $db->prepare("SELECT * FROM book_metadata_cache WHERE isbn = ?");
            $stmt->execute([$isbn]);
            $result = $stmt->fetch();
            return $result ?: null;
        } catch (PDOException $e) {
            return null;
        }
    }
}

if (!function_exists('truncateTable')) {
    function truncateTable(string $tableName): bool {
        $db = getDB();
        try {
            $db->exec("DELETE FROM $tableName");
            $db->exec("VACUUM");
            return true;
        } catch (PDOException $e) {
            error_log("Failed to truncate table $tableName: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('getSearchSuggestions')) {
    function getSearchSuggestions(string $query, string $type = 'books', int $limit = 10): array {
        $db = getDB();
        try {
            $like = '%' . $query . '%';
            $results = [];
            if ($type === 'books' || $type === 'all') {
                $stmt = $db->prepare("SELECT id, title, author, 'book' as source FROM books 
                    WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? 
                    LIMIT ?");
                $stmt->execute([$like, $like, $like, $limit]);
                $books = $stmt->fetchAll();
                $results = array_merge($results, $books);
            }
            if ($type === 'members' || $type === 'all') {
                $stmt = $db->prepare("SELECT id, name, admno, 'member' as source FROM members 
                    WHERE name LIKE ? OR admno LIKE ? 
                    LIMIT ?");
                $stmt->execute([$like, $like, $limit]);
                $members = $stmt->fetchAll();
                $results = array_merge($results, $members);
            }
            if ($type === 'ebooks' || $type === 'all') {
                $stmt = $db->prepare("SELECT id, title, author, 'ebook' as source FROM ebooks 
                    WHERE title LIKE ? OR author LIKE ? 
                    LIMIT ?");
                $stmt->execute([$like, $like, $limit]);
                $ebooks = $stmt->fetchAll();
                $results = array_merge($results, $ebooks);
            }
            return array_slice($results, 0, $limit);
        } catch (PDOException $e) {
            error_log("Search suggestions error: " . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('generateUniqueBarcode')) {
    function generateUniqueBarcode(string $prefix = '', int $length = 10): string {
        $db = getDB();
        $maxAttempts = 10;
        $attempts = 0;
        do {
            if ($prefix) {
                $number = str_pad(rand(1, 99999), $length - strlen($prefix), '0', STR_PAD_LEFT);
                $barcode = $prefix . $number;
            } else {
                $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $barcode = '';
                for ($i = 0; $i < $length; $i++) {
                    $barcode .= $characters[rand(0, strlen($characters) - 1)];
                }
            }
            $attempts++;
            $stmt = $db->prepare("SELECT COUNT(*) FROM books WHERE barcode = ?");
            $stmt->execute([$barcode]);
            $exists = $stmt->fetchColumn() > 0;
        } while ($exists && $attempts < $maxAttempts);
        return $barcode;
    }
}

if (!function_exists('generateUniqueAccessionNumber')) {
    function generateUniqueAccessionNumber(): string {
        $db = getDB();
        $year = date('Y');
        try {
            $stmt = $db->query("SELECT COUNT(*) FROM books WHERE accession_number LIKE '$year-%'");
            $count = (int)$stmt->fetchColumn();
            return $year . '-' . str_pad($count + 1, 6, '0', STR_PAD_LEFT);
        } catch (PDOException $e) {
            return $year . '-000001';
        }
    }
}

if (!function_exists('validateISBN')) {
    function validateISBN(string $isbn): bool {
        $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
        $length = strlen($isbn);
        if ($length == 10) return validateISBN10($isbn);
        elseif ($length == 13) return validateISBN13($isbn);
        return false;
    }
}

if (!function_exists('validateISBN10')) {
    function validateISBN10(string $isbn): bool {
        if (strlen($isbn) != 10) return false;
        $sum = 0;
        for ($i = 0; $i < 9; $i++) {
            $sum += (int)$isbn[$i] * (10 - $i);
        }
        $checkChar = $isbn[9];
        $checkDigit = $checkChar === 'X' ? 10 : (int)$checkChar;
        $sum += $checkDigit;
        return $sum % 11 === 0;
    }
}

if (!function_exists('validateISBN13')) {
    function validateISBN13(string $isbn): bool {
        if (strlen($isbn) != 13) return false;
        $sum = 0;
        for ($i = 0; $i < 13; $i++) {
            $digit = (int)$isbn[$i];
            $sum += ($i % 2 == 0) ? $digit : $digit * 3;
        }
        return $sum % 10 === 0;
    }
}

if (!function_exists('getPaginationData')) {
    function getPaginationData(int $total, int $current, int $perPage = 20): array {
        $totalPages = max(1, ceil($total / $perPage));
        $current = max(1, min($current, $totalPages));
        $start = ($current - 1) * $perPage;
        $end = min($total, $start + $perPage);
        $pages = [];
        for ($i = 1; $i <= $totalPages; $i++) {
            $pages[] = $i;
        }
        return [
            'current' => $current,
            'total_pages' => $totalPages,
            'per_page' => $perPage,
            'start' => $start,
            'end' => $end,
            'total' => $total,
            'pages' => $pages,
            'has_prev' => $current > 1,
            'has_next' => $current < $totalPages,
            'prev_page' => max(1, $current - 1),
            'next_page' => min($totalPages, $current + 1),
            'offset' => $start
        ];
    }
}

if (!function_exists('formatBytes')) {
    function formatBytes(int $bytes, int $decimals = 2): string {
        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        $i = 0;
        while ($bytes >= 1024 && $i < 5) {
            $bytes /= 1024;
            $i++;
        }
        return number_format($bytes, $decimals) . ' ' . $units[$i];
    }
}

if (!function_exists('getClientIP')) {
    function getClientIP(): string {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
        return $ip;
    }
}

if (!function_exists('isLocalhost')) {
    function isLocalhost(): bool {
        $ip = getClientIP();
        return $ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0;
    }
}

if (!function_exists('getBrowserInfo')) {
    function getBrowserInfo(): string {
        $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($agent, 'Chrome') !== false) return 'Chrome';
        if (strpos($agent, 'Firefox') !== false) return 'Firefox';
        if (strpos($agent, 'Safari') !== false) return 'Safari';
        if (strpos($agent, 'Edge') !== false) return 'Edge';
        if (strpos($agent, 'Opera') !== false) return 'Opera';
        if (strpos($agent, 'MSIE') !== false || strpos($agent, 'Trident') !== false) return 'Internet Explorer';
        return 'Unknown';
    }
}

if (!function_exists('getOSInfo')) {
    function getOSInfo(): string {
        $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (strpos($agent, 'Windows') !== false) return 'Windows';
        if (strpos($agent, 'Mac') !== false) return 'macOS';
        if (strpos($agent, 'Linux') !== false) return 'Linux';
        if (strpos($agent, 'Android') !== false) return 'Android';
        if (strpos($agent, 'iPhone') !== false || strpos($agent, 'iPad') !== false) return 'iOS';
        return 'Unknown';
    }
}

if (!function_exists('generateUUID')) {
    function generateUUID(): string {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

// ==================== SESSION & TIMEZONE INITIALIZATION ====================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$settings = getSettings();
date_default_timezone_set($settings['library_timezone'] ?? 'Asia/Kolkata');

// ==================== ERROR HANDLING ====================
if (!function_exists('handleDBError')) {
    function handleDBError(Exception $e): void {
        error_log("Database Error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
        if (php_sapi_name() === 'cli') {
            echo "Error: " . $e->getMessage() . "\n";
            return;
        }
        $settings = getSettings();
        if (!empty($settings['site_maintenance_mode'])) {
            http_response_code(503);
            echo json_encode(['error' => 'Service temporarily unavailable']);
            exit;
        }
        if (strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
            http_response_code(500);
            echo json_encode(['error' => 'Internal server error', 'message' => $e->getMessage()]);
            exit;
        }
        if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
            echo "<div style='padding:20px;background:#f8d7da;border:1px solid #f5c6cb;border-radius:8px;'>";
            echo "<strong>Database Error:</strong> " . htmlspecialchars($e->getMessage());
            echo "</div>";
        } else {
            echo "<div style='padding:20px;background:#f8d7da;border:1px solid #f5c6cb;border-radius:8px;'>";
            echo "A system error occurred. Please try again later.";
            echo "</div>";
        }
    }
}

if (!function_exists('dbExceptionHandler')) {
    function dbExceptionHandler($e) {
        handleDBError($e);
    }
}

set_exception_handler(function($e) {
    if ($e instanceof PDOException) {
        handleDBError($e);
    } else {
        error_log("Uncaught Exception: " . $e->getMessage());
        throw $e;
    }
});

?>