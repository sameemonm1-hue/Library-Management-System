<?php
/**
 * AJAX Book Fetcher - Fetch book details from online APIs by ISBN
 * Used by books.php and circulation/issue.php for auto-filling book details
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

header('Content-Type: application/json');

$isbn = $_GET['isbn'] ?? $_POST['isbn'] ?? '';

if(empty($isbn)) {
    echo json_encode(['error' => 'No ISBN provided']);
    exit;
}

// Clean ISBN (remove hyphens and spaces)
$isbn = preg_replace('/[^0-9X]/i', '', $isbn);

$result = [
    'title' => '',
    'author' => '',
    'publisher' => '',
    'year' => '',
    'pages' => 0,
    'summary' => '',
    'category' => '',
    'cover_url' => ''
];

// Try OpenLibrary API first
$openLibraryUrl = "https://openlibrary.org/api/books?bibkeys=ISBN:" . $isbn . "&format=json&jscmd=data";
$ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);

$response = @file_get_contents($openLibraryUrl, false, $ctx);
if($response) {
    $data = json_decode($response, true);
    $key = "ISBN:" . $isbn;
    if(isset($data[$key])) {
        $book = $data[$key];
        $result['title'] = $book['title'] ?? '';
        if(isset($book['authors'][0]['name'])) {
            $result['author'] = $book['authors'][0]['name'];
        }
        if(isset($book['publishers'][0]['name'])) {
            $result['publisher'] = $book['publishers'][0]['name'];
        }
        $result['year'] = $book['publish_date'] ?? '';
        $result['pages'] = $book['number_of_pages'] ?? 0;
        $result['cover_url'] = $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
        
        // Try to extract category from subjects
        if(isset($book['subjects']) && is_array($book['subjects']) && count($book['subjects']) > 0) {
            $result['category'] = $book['subjects'][0]['name'] ?? '';
        }
    }
}

// If OpenLibrary didn't return title, try Google Books API
if(empty($result['title'])) {
    $googleUrl = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . $isbn;
    $response = @file_get_contents($googleUrl, false, $ctx);
    if($response) {
        $data = json_decode($response, true);
        if(isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $result['title'] = $info['title'] ?? '';
            $result['author'] = isset($info['authors'][0]) ? $info['authors'][0] : '';
            $result['publisher'] = $info['publisher'] ?? '';
            $result['year'] = $info['publishedDate'] ?? '';
            $result['pages'] = $info['pageCount'] ?? 0;
            $result['summary'] = $info['description'] ?? '';
            $result['category'] = isset($info['categories'][0]) ? $info['categories'][0] : '';
            $result['cover_url'] = $info['imageLinks']['thumbnail'] ?? $info['imageLinks']['smallThumbnail'] ?? '';
        }
    }
}

// Return as JSON
echo json_encode($result);
?>