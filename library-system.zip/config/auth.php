<?php
/**
 * Authentication Handler – Unified for Staff, Members, and API
 * 
 * Features:
 * - Staff login (users table) with lockout
 * - Member login (members table) with password hashing
 * - API key authentication (api_keys table)
 * - Session management with timeout and regeneration
 * - Permission checking using module_permissions table
 * - CSRF token helper
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

// ==================== CONSTANTS ====================
if (!defined('MAX_LOGIN_ATTEMPTS')) {
    define('MAX_LOGIN_ATTEMPTS', 5);
}
if (!defined('LOCKOUT_TIME')) {
    define('LOCKOUT_TIME', 900);
}
if (!defined('CSRF_TOKEN_LENGTH')) {
    define('CSRF_TOKEN_LENGTH', 32);
}

// ==================== STAFF AUTHENTICATION ====================

/**
 * Authenticate staff user (admin/librarian/staff)
 *
 * @param string $username
 * @param string $password
 * @return array ['success' => bool, 'role' => string|null, 'error' => string|null]
 */
function authenticateStaff($username, $password) {
    $db = getDB();
    
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        return ['success' => false, 'error' => 'Invalid username or password'];
    }
    
    // Check if account is locked
    if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
        return ['success' => false, 'error' => 'Account locked. Try again after ' . date('H:i:s', strtotime($user['locked_until']))];
    }
    
    // Verify password
    if (password_verify($password, $user['password'])) {
        // Reset login attempts
        $db->prepare("UPDATE users SET login_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = ?")
           ->execute([$user['id']]);
        
        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);
        
        $_SESSION['user_id']    = $user['id'];
        $_SESSION['username']   = $user['username'];
        $_SESSION['role']       = $user['role'];
        $_SESSION['fullname']   = $user['fullname'];
        $_SESSION['user_type']  = 'staff';
        $_SESSION['login_time'] = time();
        
        logActivity($user['username'], 'LOGIN', 'Staff logged in successfully');
        
        // Log session if table exists
        try {
            $db = getDB();
            $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
            if ($tableCheck->fetch()) {
                $sessionId = session_id();
                $ip        = $_SERVER['REMOTE_ADDR'] ?? '';
                $agent     = $_SERVER['HTTP_USER_AGENT'] ?? '';
                $stmtLog   = $db->prepare("INSERT INTO session_logs (user_type, username, session_id, ip_address, user_agent, login_time) VALUES ('admin', ?, ?, ?, ?, datetime('now'))");
                $stmtLog->execute([$user['username'], $sessionId, $ip, $agent]);
            }
        } catch (Exception $e) {
            // Non-critical
        }
        
        return ['success' => true, 'role' => $user['role']];
    } else {
        // Increment login attempts
        $attempts = ($user['login_attempts'] ?? 0) + 1;
        
        if ($attempts >= MAX_LOGIN_ATTEMPTS) {
            $lockedUntil = date('Y-m-d H:i:s', time() + LOCKOUT_TIME);
            $db->prepare("UPDATE users SET login_attempts = ?, locked_until = ? WHERE id = ?")
               ->execute([$attempts, $lockedUntil, $user['id']]);
            return ['success' => false, 'error' => 'Too many failed attempts. Account locked for 15 minutes.'];
        } else {
            $db->prepare("UPDATE users SET login_attempts = ? WHERE id = ?")
               ->execute([$attempts, $user['id']]);
            $remaining = MAX_LOGIN_ATTEMPTS - $attempts;
            return ['success' => false, 'error' => "Invalid password. $remaining attempts remaining."];
        }
    }
}

/**
 * Logout staff user
 */
function logoutStaff() {
    if (isset($_SESSION['username'])) {
        logActivity($_SESSION['username'], 'LOGOUT', 'Staff logged out');
        try {
            $db = getDB();
            $sessionId = session_id();
            $db->prepare("UPDATE session_logs SET logout_time = datetime('now') WHERE session_id = ? AND logout_time IS NULL")
               ->execute([$sessionId]);
        } catch (Exception $e) {}
    }
    unset($_SESSION['user_id']);
    unset($_SESSION['username']);
    unset($_SESSION['role']);
    unset($_SESSION['fullname']);
    unset($_SESSION['user_type']);
    unset($_SESSION['login_time']);
}

// ==================== MEMBER AUTHENTICATION ====================

/**
 * Authenticate member (patron)
 *
 * @param string $admno Admission number
 * @param string $password
 * @return array ['success' => bool, 'member' => array|null, 'error' => string|null]
 */
function authenticateMember($admno, $password) {
    $db = getDB();
    // Note: 'approved' column may not exist in all tables – adapt
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    
    if (!$member) {
        return ['success' => false, 'error' => 'Invalid admission number or account not approved.'];
    }
    
    // If password is not set (legacy from import), force reset
    if (empty($member['password'])) {
        return ['success' => false, 'error' => 'Please set a password first. Contact library staff.'];
    }
    
    if (password_verify($password, $member['password'])) {
        // Regenerate session ID to prevent fixation
        session_regenerate_id(true);
        
        $_SESSION['member_logged_in'] = true;
        $_SESSION['member_admno']     = $member['admno'];
        $_SESSION['member_name']      = $member['name'];
        $_SESSION['member_category']  = $member['member_category'];
        $_SESSION['member_id']        = $member['id'];
        $_SESSION['user_type']        = 'member';
        $_SESSION['login_time']       = time();
        
        logActivity($member['admno'], 'MEMBER_LOGIN', 'Member logged in');
        
        // Log session
        try {
            $db = getDB();
            $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='session_logs'");
            if ($tableCheck->fetch()) {
                $sessionId = session_id();
                $ip        = $_SERVER['REMOTE_ADDR'] ?? '';
                $agent     = $_SERVER['HTTP_USER_AGENT'] ?? '';
                $stmtLog   = $db->prepare("INSERT INTO session_logs (user_type, username, session_id, ip_address, user_agent, login_time) VALUES ('member', ?, ?, ?, ?, datetime('now'))");
                $stmtLog->execute([$member['admno'], $sessionId, $ip, $agent]);
            }
        } catch (Exception $e) {}
        
        return ['success' => true, 'member' => $member];
    } else {
        return ['success' => false, 'error' => 'Invalid password.'];
    }
}

/**
 * Logout member
 */
function logoutMember() {
    if (isset($_SESSION['member_admno'])) {
        logActivity($_SESSION['member_admno'], 'MEMBER_LOGOUT', 'Member logged out');
        try {
            $db = getDB();
            $sessionId = session_id();
            $db->prepare("UPDATE session_logs SET logout_time = datetime('now') WHERE session_id = ? AND logout_time IS NULL")
               ->execute([$sessionId]);
        } catch (Exception $e) {}
    }
    unset($_SESSION['member_logged_in']);
    unset($_SESSION['member_admno']);
    unset($_SESSION['member_name']);
    unset($_SESSION['member_category']);
    unset($_SESSION['member_id']);
    unset($_SESSION['user_type']);
    unset($_SESSION['login_time']);
}

// ==================== API AUTHENTICATION ====================

/**
 * Authenticate API request using X-API-Key header or query parameter.
 *
 * @return array Associative array with 'id', 'name', 'permissions' of the API key.
 * @throws Exception (outputs JSON error and exits on failure)
 */
function authenticateAPI() {
    $headers = getallheaders();
    $apiKey = $headers['X-API-Key'] ?? $_GET['api_key'] ?? '';
    
    if (empty($apiKey)) {
        sendAPIError('API key required', 401);
    }
    
    $db = getDB();
    
    // Validate API key
    $stmt = $db->prepare("SELECT id, name, permissions FROM api_keys WHERE api_key = ? AND active = 1");
    $stmt->execute([$apiKey]);
    $keyData = $stmt->fetch();
    
    if (!$keyData) {
        sendAPIError('Invalid API key', 401);
    }
    
    // Update last used timestamp
    try {
        $db->prepare("UPDATE api_keys SET last_used = datetime('now') WHERE api_key = ?")
           ->execute([$apiKey]);
    } catch (PDOException $e) {
        // Column may not exist – ignore
    }
    
    // Parse permissions (comma-separated list)
    $permissions = array_map('trim', explode(',', $keyData['permissions'] ?? ''));
    return [
        'id'          => $keyData['id'],
        'name'        => $keyData['name'],
        'permissions' => $permissions
    ];
}

/**
 * Check if the authenticated API key has a specific permission.
 *
 * @param string $permission Required permission (e.g., 'read', 'write', 'admin')
 * @return void (exits with 403 on failure)
 */
function checkAPIPermission($permission) {
    $auth = $GLOBALS['api_auth'] ?? null;
    if (!$auth || !in_array($permission, $auth['permissions'])) {
        sendAPIError('Insufficient permissions', 403);
    }
}

/**
 * Send JSON error response for API and exit.
 *
 * @param string $message Error message
 * @param int $statusCode HTTP status code
 */
function sendAPIError($message, $statusCode = 400) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message, 'status' => $statusCode]);
    exit;
}

// ==================== SESSION MANAGEMENT ====================

/**
 * Check if staff is logged in
 *
 * @return bool
 */
function isStaffLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

/**
 * Check if member is logged in
 *
 * @return bool
 */
function isMemberLoggedIn() {
    return isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true;
}

// isLoggedIn() already defined in functions.php – do not redeclare
if (!function_exists('isLoggedIn')) {
    /**
     * Check if any user (staff or member) is logged in
     *
     * @return bool
     */
    function isLoggedIn() {
        return isStaffLoggedIn() || isMemberLoggedIn();
    }
}

/**
 * Require staff login (redirects if not)
 */
function requireStaffLogin() {
    if (!isStaffLoggedIn()) {
        header("Location: ../index.php");
        exit;
    }
    // Also check session timeout
    if (!checkSessionTimeout()) {
        header("Location: ../index.php?timeout=1");
        exit;
    }
}

/**
 * Require member login (redirects to OPAC login)
 */
function requireMemberLogin() {
    if (!isMemberLoggedIn()) {
        header("Location: ../opac/login.php");
        exit;
    }
    // Check session timeout for members
    if (!checkSessionTimeout()) {
        logoutMember();
        header("Location: ../opac/login.php?timeout=1");
        exit;
    }
}

// requireAdmin() already defined in functions.php – do not redeclare
if (!function_exists('requireAdmin')) {
    /**
     * Require admin role (staff only)
     */
    function requireAdmin() {
        requireStaffLogin();
        if ($_SESSION['role'] !== 'admin') {
            header("Location: ../index.php?error=access_denied");
            exit;
        }
    }
}

/**
 * Check session timeout for both staff and members
 *
 * @return bool
 */
function checkSessionTimeout() {
    $settings = getSettings();
    $timeout = (int)($settings['auto_logout_minutes'] ?? 30);
    
    if ($timeout > 0 && isset($_SESSION['login_time'])) {
        $inactive = time() - $_SESSION['login_time'];
        if ($inactive > ($timeout * 60)) {
            // Logout based on user type
            if (isStaffLoggedIn()) {
                logoutStaff();
            } elseif (isMemberLoggedIn()) {
                logoutMember();
            }
            return false;
        }
        $_SESSION['login_time'] = time();
    }
    return true;
}

/**
 * Logout current user (staff or member)
 */
function logout() {
    if (isStaffLoggedIn()) {
        logoutStaff();
    } elseif (isMemberLoggedIn()) {
        logoutMember();
    }
    
    // Clear all session data
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// ==================== PERMISSION CHECKING ====================

// userCanAccessModule() already defined in functions.php – do not redeclare
if (!function_exists('userCanAccessModule')) {
    /**
     * Check if current staff user has a specific module permission
     *
     * @param string $moduleKey Module identifier (e.g., 'books', 'circulation', 'settings')
     * @return bool
     */
    function userCanAccessModule($moduleKey) {
        if (!isStaffLoggedIn()) {
            return false;
        }
        if ($_SESSION['role'] === 'admin') {
            return true;
        }
        
        $db = getDB();
        $stmt = $db->prepare("SELECT can_access FROM module_permissions WHERE role = ? AND module_key = ?");
        $stmt->execute([$_SESSION['role'], $moduleKey]);
        $result = $stmt->fetchColumn();
        return ($result !== null && (bool)$result);
    }
}

/**
 * Alias for backward compatibility
 */
if (!function_exists('hasPermission')) {
    function hasPermission($permission) {
        return userCanAccessModule($permission);
    }
}

/**
 * Get current user (staff) data
 *
 * @return array|null
 */
function getCurrentUser() {
    if (!isStaffLoggedIn()) {
        return null;
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, role, fullname, email FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

/**
 * Get current member data
 *
 * @return array|null
 */
function getCurrentMember() {
    if (!isMemberLoggedIn()) {
        return null;
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT id, admno, name, member_category, email, phone, total_fines, total_paid_fines FROM members WHERE admno = ?");
    $stmt->execute([$_SESSION['member_admno']]);
    return $stmt->fetch();
}

// ==================== CSRF PROTECTION ====================

/**
 * Generate or retrieve CSRF token
 *
 * @return string
 */
function getCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(CSRF_TOKEN_LENGTH));
    }
    return $_SESSION['csrf_token'];
}

// validateCSRFToken() already defined in functions.php – do not redeclare
if (!function_exists('validateCSRFToken')) {
    /**
     * Validate CSRF token from request
     *
     * @param string $token Token to validate (usually from POST or GET)
     * @return bool
     */
    function validateCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

/**
 * Require valid CSRF token (exits with error if invalid)
 *
 * @param string $token
 */
function requireCSRFToken($token = null) {
    if ($token === null) {
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    }
    if (!validateCSRFToken($token)) {
        die("Invalid security token. Please refresh the page and try again.");
    }
}

// ==================== LEGACY COMPATIBILITY ====================
// The original authenticate() function is kept for backward compatibility
if (!function_exists('authenticate')) {
    function authenticate($username, $password) {
        return authenticateStaff($username, $password);
    }
}