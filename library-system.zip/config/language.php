<?php
/**
 * Multi‑Language System – Standalone Language Switch
 * Version: 2.0 – Supports both underscore keys and title‑case keys.
 * All sidebar menu items can be called directly with their display text.
 *
 * @package LibraryERP
 * @author  Sameermon
 */

// ==================== CONFIGURATION ====================
$availableLanguages = ['en', 'hi', 'ar'];
$defaultLanguage = 'en';

// ==================== LANGUAGE DETECTION ====================
function detectLanguage(): string {
    global $availableLanguages, $defaultLanguage;
    if (isset($_GET['lang']) && in_array($_GET['lang'], $availableLanguages)) {
        $_SESSION['lang'] = $_GET['lang'];
        return $_GET['lang'];
    }
    if (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $availableLanguages)) {
        return $_SESSION['lang'];
    }
    if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
        $browserLangs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
        foreach ($browserLangs as $browserLang) {
            $langCode = substr(trim($browserLang), 0, 2);
            if (in_array($langCode, $availableLanguages)) {
                $_SESSION['lang'] = $langCode;
                return $langCode;
            }
        }
    }
    $_SESSION['lang'] = $defaultLanguage;
    return $defaultLanguage;
}

function getCurrentLanguage(): string {
    return detectLanguage();
}

// ==================== TRANSLATION LOADING ====================
function loadTranslations(string $lang): array {
    $langFile = __DIR__ . "/../lang/{$lang}.json";
    if (file_exists($langFile)) {
        $translations = json_decode(file_get_contents($langFile), true);
        if (is_array($translations) && !empty($translations)) {
            return $translations;
        }
    }
    return getEmbeddedTranslations()[$lang] ?? getEmbeddedTranslations()['en'];
}

/**
 * Embedded translations – includes both underscore keys and title‑case keys
 * for direct usage like __('Admin Dashboard').
 */
function getEmbeddedTranslations(): array {
    return [
        // ============================================================
        // ENGLISH (Title Case)
        // ============================================================
        'en' => [
            // ---- General ----
            'welcome' => 'Welcome To',
            'subtitle' => 'Complete Library Management Solution With Ease',
            'staff_login' => 'Staff Login',
            'username' => 'Username',
            'password' => 'Password',
            'login' => 'Login',
            'secure_login' => 'Secure Login With',
            'timeout_msg' => 'Your Session Timed Out. Please Log In Again.',
            'invalid_credentials' => 'Invalid Username Or Password',
            'login_failed' => 'Login Failed: ',
            'no_staff_profiles' => 'No Staff Profiles Configured. Please Go To <strong>Admin → Staff Profiles</strong> To Add Librarians And Staff.',
            'logout' => 'Logout',
            'my_profile' => 'My Profile',
            'member_portal' => 'Member Portal',
            'footer_copyright' => 'All Rights Reserved.',
            'maintenance_title' => 'Maintenance Mode',
            'maintenance_body' => 'We Are Currently Performing Scheduled Maintenance. Please Check Back Later.',
            'greeting_morning' => 'Good Morning',
            'greeting_afternoon' => 'Good Afternoon',
            'greeting_evening' => 'Good Evening',
            'today_is' => 'Today Is',
            'time' => 'Time',
            'visitors_inside' => 'Currently Inside',
            'total_members' => 'Total Members',
            'total_books' => 'Total Books',
            'currently_issued' => 'Currently Issued',
            'overdue_books' => 'Overdue Books',
            'ebooks_available' => 'eBooks Available',
            'pending_reservations' => 'Pending Reservations',
            'upcoming_events' => 'Upcoming Events',
            'fines_today' => 'Fines Collected Today',
            'quick_actions' => 'Quick Actions',
            'no_quick_actions' => 'No Quick Actions Defined. Please Add Some In <a href="admin/quick_actions.php">Quick Actions Manager</a>.',
            'issue_book' => 'Issue Book',
            'issue_desc' => 'Scan Member & Book Barcode',
            'return_book' => 'Return Book',
            'return_desc' => 'Process Returns & Fines',
            'renew' => 'Renew',
            'renew_desc' => 'Extend Due Dates',
            'computer_access' => 'Computer Access',
            'computer_desc' => 'Manage PC Bookings',
            'ebooks' => 'eBooks',
            'ebooks_desc' => 'Digital Collection',
            'utilities' => 'Utilities Suite',
            'utilities_desc' => 'Tools & Helpers',
            'serial_control' => 'Serial Control',
            'serial_desc' => 'Manage Periodicals',
            'backup_restore' => 'Backup & Restore',
            'backup_desc' => 'Data Safety',
            'reports' => 'Reports',
            'reports_desc' => 'Generate Statistics',
            'settings' => 'Settings',
            'settings_desc' => 'System Configuration',
            'quick_access' => 'Quick Access',
            'dark' => 'Dark',
            'light' => 'Light',

            // ---- Sidebar (Title‑Case Keys) ----
            'Main' => 'Main',
            'Admin Dashboard' => 'Admin Dashboard',
            'Circulation' => 'Circulation',
            'Members' => 'Members',
            'Books' => 'Books',
            'eBooks' => 'eBooks',
            'Research' => 'Research',
            'Research Databases' => 'Research Databases',
            'Acquisitions & Serials' => 'Acquisitions & Serials',
            'Acquisitions' => 'Acquisitions',
            'Serials Control' => 'Serials Control',
            'Administration' => 'Administration',
            'System Settings' => 'System Settings',
            'Quick Actions Manager' => 'Quick Actions Manager',
            'Loan Rules' => 'Loan Rules',
            'Staff Profiles' => 'Staff Profiles',
            'Manage Notices' => 'Manage Notices',
            'Suggestions' => 'Suggestions',
            'Fine Rates' => 'Fine Rates',
            'Backup & Restore' => 'Backup & Restore',
            'Utilities Suite' => 'Utilities Suite',
            'Stock Verification' => 'Stock Verification',
            'Lost & Damaged' => 'Lost & Damaged',
            'Payments' => 'Payments',
            'Reservations' => 'Reservations',
            'Library Events' => 'Library Events',
            'Member Documents' => 'Member Documents',
            'Computer Access' => 'Computer Access',
            'Data Import' => 'Data Import',
            'Entry/Exit' => 'Entry/Exit',
            'Session Logs' => 'Session Logs',
            'Communication' => 'Communication',
            'Bulk Messaging' => 'Bulk Messaging',
            'Chatbot' => 'Chatbot',
            'Reports & Analytics' => 'Reports & Analytics',
            'Reports' => 'Reports',
            'Advanced Analytics' => 'Advanced Analytics',
            'Cron' => 'Cron',
            'Public Interfaces' => 'Public Interfaces',
            'OPAC' => 'OPAC',
            'Digital Library Hub' => 'Digital Library Hub',
            'Self Kiosk' => 'Self Kiosk',
            'Member Portal' => 'Member Portal',
            'Multi‑Library' => 'Multi‑Library',
            'Institutions' => 'Institutions',
            'API' => 'API',
            'REST API' => 'REST API',
            'Account' => 'Account',

            // ---- Underscore keys (for compatibility) ----
            'main' => 'Main',
            'admin_dashboard' => 'Admin Dashboard',
            'circulation' => 'Circulation',
            'members' => 'Members',
            'books' => 'Books',
            'research' => 'Research',
            'research_databases' => 'Research Databases',
            'acquisitions_serials' => 'Acquisitions & Serials',
            'acquisitions' => 'Acquisitions',
            'serial_control_menu' => 'Serials Control',
            'administration' => 'Administration',
            'system_settings' => 'System Settings',
            'quick_actions_manager' => 'Quick Actions Manager',
            'loan_rules' => 'Loan Rules',
            'staff_profiles' => 'Staff Profiles',
            'manage_notices' => 'Manage Notices',
            'suggestions' => 'Suggestions',
            'fine_rates' => 'Fine Rates',
            'backup_restore_menu' => 'Backup & Restore',
            'utilities_suite' => 'Utilities Suite',
            'stock_verification' => 'Stock Verification',
            'lost_damaged' => 'Lost & Damaged',
            'payments' => 'Payments',
            'reservations' => 'Reservations',
            'events' => 'Library Events',
            'member_docs' => 'Member Documents',
            'computer_management' => 'Computer Access',
            'data_import' => 'Data Import',
            'entry_exit' => 'Entry/Exit',
            'session_logs' => 'Session Logs',
            'communication' => 'Communication',
            'bulk_messaging' => 'Bulk Messaging',
            'chatbot' => 'Chatbot',
            'reports_analytics' => 'Reports & Analytics',
            'reports_menu' => 'Reports',
            'advanced_analytics' => 'Advanced Analytics',
            'cron' => 'Cron',
            'public_interfaces' => 'Public Interfaces',
            'opac' => 'OPAC',
            'digital_hub' => 'Digital Library Hub',
            'self_kiosk' => 'Self Kiosk',
            'multi_library' => 'Multi‑Library',
            'institutions' => 'Institutions',
            'api' => 'API',
            'rest_api' => 'REST API',
            'account' => 'Account',
        ],

        // ============================================================
        // HINDI
        // ============================================================
        'hi' => [
            // General
            'welcome' => 'में आपका स्वागत है',
            'subtitle' => 'सरलता के साथ संपूर्ण पुस्तकालय प्रबंधन समाधान',
            'staff_login' => 'स्टाफ लॉगिन',
            'username' => 'उपयोगकर्ता नाम',
            'password' => 'पासवर्ड',
            'login' => 'लॉगिन',
            'secure_login' => 'सुरक्षित लॉगिन',
            'timeout_msg' => 'आपका सत्र समाप्त हो गया। कृपया पुनः लॉगिन करें।',
            'invalid_credentials' => 'उपयोगकर्ता नाम या पासवर्ड गलत है',
            'login_failed' => 'लॉगिन विफल: ',
            'no_staff_profiles' => 'कोई स्टाफ प्रोफ़ाइल कॉन्फ़िगर नहीं की गई है। कृपया <strong>प्रशासन → स्टाफ प्रोफ़ाइल</strong> पर जाकर पुस्तकालयाध्यक्षों और कर्मचारियों को जोड़ें।',
            'logout' => 'लॉगआउट',
            'my_profile' => 'मेरी प्रोफ़ाइल',
            'member_portal' => 'सदस्य पोर्टल',
            'footer_copyright' => 'सर्वाधिकार सुरक्षित।',
            'maintenance_title' => 'रखरखाव मोड',
            'maintenance_body' => 'हम वर्तमान में निर्धारित रखरखाव कर रहे हैं। कृपया बाद में वापस आएँ।',
            'greeting_morning' => 'सुप्रभात',
            'greeting_afternoon' => 'शुभ अपराह्न',
            'greeting_evening' => 'शुभ संध्या',
            'today_is' => 'आज',
            'time' => 'समय',
            'visitors_inside' => 'वर्तमान में अंदर',
            'total_members' => 'कुल सदस्य',
            'total_books' => 'कुल पुस्तकें',
            'currently_issued' => 'वर्तमान में जारी',
            'overdue_books' => 'अतिदेय पुस्तकें',
            'ebooks_available' => 'उपलब्ध ई-पुस्तकें',
            'pending_reservations' => 'लंबित आरक्षण',
            'upcoming_events' => 'आगामी कार्यक्रम',
            'fines_today' => 'आज एकत्रित जुर्माना',
            'quick_actions' => 'त्वरित क्रियाएँ',
            'no_quick_actions' => 'कोई त्वरित क्रिया परिभाषित नहीं है। कृपया <a href="admin/quick_actions.php">त्वरित क्रियाएँ प्रबंधक</a> में जोड़ें।',
            'issue_book' => 'पुस्तक जारी करें',
            'issue_desc' => 'सदस्य और पुस्तक बारकोड स्कैन करें',
            'return_book' => 'पुस्तक वापस लें',
            'return_desc' => 'वापसी और जुर्माना प्रक्रिया करें',
            'renew' => 'नवीनीकरण',
            'renew_desc' => 'देय तिथि बढ़ाएँ',
            'computer_access' => 'कंप्यूटर पहुँच',
            'computer_desc' => 'पीसी बुकिंग प्रबंधित करें',
            'ebooks' => 'ई-पुस्तकें',
            'ebooks_desc' => 'डिजिटल संग्रह',
            'utilities' => 'उपयोगिता सुइट',
            'utilities_desc' => 'उपकरण और सहायक',
            'serial_control' => 'सीरियल नियंत्रण',
            'serial_desc' => 'पत्रिकाएँ प्रबंधित करें',
            'backup_restore' => 'बैकअप और पुनर्स्थापना',
            'backup_desc' => 'डेटा सुरक्षा',
            'reports' => 'रिपोर्ट',
            'reports_desc' => 'आँकड़े उत्पन्न करें',
            'settings' => 'सेटिंग्स',
            'settings_desc' => 'सिस्टम विन्यास',
            'quick_access' => 'त्वरित पहुँच',
            'dark' => 'डार्क',
            'light' => 'लाइट',

            // Sidebar (Title‑Case Keys)
            'Main' => 'मुख्य',
            'Admin Dashboard' => 'डैशबोर्ड',
            'Circulation' => 'परिसंचरण',
            'Members' => 'सदस्य',
            'Books' => 'पुस्तकें',
            'eBooks' => 'ई-पुस्तकें',
            'Research' => 'अनुसंधान',
            'Research Databases' => 'अनुसंधान डेटाबेस',
            'Acquisitions & Serials' => 'अधिग्रहण और सीरियल',
            'Acquisitions' => 'अधिग्रहण',
            'Serials Control' => 'सीरियल नियंत्रण',
            'Administration' => 'प्रशासन',
            'System Settings' => 'सिस्टम सेटिंग्स',
            'Quick Actions Manager' => 'त्वरित क्रियाएँ प्रबंधक',
            'Loan Rules' => 'ऋण नियम',
            'Staff Profiles' => 'स्टाफ प्रोफ़ाइल',
            'Manage Notices' => 'सूचनाएँ प्रबंधित करें',
            'Suggestions' => 'सुझाव',
            'Fine Rates' => 'जुर्माना दरें',
            'Backup & Restore' => 'बैकअप और पुनर्स्थापना',
            'Utilities Suite' => 'उपयोगिता सुइट',
            'Stock Verification' => 'स्टॉक सत्यापन',
            'Lost & Damaged' => 'खोई हुई और क्षतिग्रस्त पुस्तकें',
            'Payments' => 'भुगतान',
            'Reservations' => 'आरक्षण',
            'Library Events' => 'पुस्तकालय कार्यक्रम',
            'Member Documents' => 'सदस्य दस्तावेज़',
            'Computer Access' => 'कंप्यूटर पहुँच',
            'Data Import' => 'डेटा आयात',
            'Entry/Exit' => 'प्रवेश/निकास',
            'Session Logs' => 'सत्र लॉग',
            'Communication' => 'संचार',
            'Bulk Messaging' => 'सामूहिक SMS/WhatsApp',
            'Chatbot' => 'पुस्तकालय चैटबॉट',
            'Reports & Analytics' => 'रिपोर्ट और विश्लेषण',
            'Reports' => 'रिपोर्ट',
            'Advanced Analytics' => 'उन्नत विश्लेषण',
            'Cron' => 'Cron',
            'Public Interfaces' => 'सार्वजनिक इंटरफ़ेस',
            'OPAC' => 'OPAC',
            'Digital Library Hub' => 'डिजिटल लाइब्रेरी हब',
            'Self Kiosk' => 'सेल्फ कियोस्क',
            'Member Portal' => 'सदस्य पोर्टल',
            'Multi‑Library' => 'बहु-पुस्तकालय',
            'Institutions' => 'संस्थान',
            'API' => 'API',
            'REST API' => 'REST API',
            'Account' => 'खाता',

            // Underscore keys (compatibility)
            'main' => 'मुख्य',
            'admin_dashboard' => 'डैशबोर्ड',
            'circulation' => 'परिसंचरण',
            'members' => 'सदस्य',
            'books' => 'पुस्तकें',
            'research' => 'अनुसंधान',
            'research_databases' => 'अनुसंधान डेटाबेस',
            'acquisitions_serials' => 'अधिग्रहण और सीरियल',
            'acquisitions' => 'अधिग्रहण',
            'serial_control_menu' => 'सीरियल नियंत्रण',
            'administration' => 'प्रशासन',
            'system_settings' => 'सिस्टम सेटिंग्स',
            'quick_actions_manager' => 'त्वरित क्रियाएँ प्रबंधक',
            'loan_rules' => 'ऋण नियम',
            'staff_profiles' => 'स्टाफ प्रोफ़ाइल',
            'manage_notices' => 'सूचनाएँ प्रबंधित करें',
            'suggestions' => 'सुझाव',
            'fine_rates' => 'जुर्माना दरें',
            'backup_restore_menu' => 'बैकअप और पुनर्स्थापना',
            'utilities_suite' => 'उपयोगिता सुइट',
            'stock_verification' => 'स्टॉक सत्यापन',
            'lost_damaged' => 'खोई हुई और क्षतिग्रस्त पुस्तकें',
            'payments' => 'भुगतान',
            'reservations' => 'आरक्षण',
            'events' => 'पुस्तकालय कार्यक्रम',
            'member_docs' => 'सदस्य दस्तावेज़',
            'computer_management' => 'कंप्यूटर पहुँच',
            'data_import' => 'डेटा आयात',
            'entry_exit' => 'प्रवेश/निकास',
            'session_logs' => 'सत्र लॉग',
            'communication' => 'संचार',
            'bulk_messaging' => 'सामूहिक SMS/WhatsApp',
            'chatbot' => 'पुस्तकालय चैटबॉट',
            'reports_analytics' => 'रिपोर्ट और विश्लेषण',
            'reports_menu' => 'रिपोर्ट',
            'advanced_analytics' => 'उन्नत विश्लेषण',
            'cron' => 'Cron',
            'public_interfaces' => 'सार्वजनिक इंटरफ़ेस',
            'opac' => 'OPAC',
            'digital_hub' => 'डिजिटल लाइब्रेरी हब',
            'self_kiosk' => 'सेल्फ कियोस्क',
            'multi_library' => 'बहु-पुस्तकालय',
            'institutions' => 'संस्थान',
            'api' => 'API',
            'rest_api' => 'REST API',
            'account' => 'खाता',
        ],

        // ============================================================
        // ARABIC
        // ============================================================
        'ar' => [
            // General
            'welcome' => 'مرحباً بكم في',
            'subtitle' => 'حل متكامل لإدارة المكتبات بكل سهولة',
            'staff_login' => 'تسجيل دخول الموظفين',
            'username' => 'اسم المستخدم',
            'password' => 'كلمة المرور',
            'login' => 'تسجيل الدخول',
            'secure_login' => 'تسجيل دخول آمن عبر',
            'timeout_msg' => 'انتهت مدة الجلسة. يرجى تسجيل الدخول مجدداً.',
            'invalid_credentials' => 'اسم المستخدم أو كلمة المرور غير صحيحة',
            'login_failed' => 'فشل تسجيل الدخول: ',
            'no_staff_profiles' => 'لم يتم تكوين ملفات تعريف الموظفين. يرجى الانتقال إلى <strong>الإدارة ← ملفات تعريف الموظفين</strong> لإضافة أمناء المكتبات والموظفين.',
            'logout' => 'تسجيل الخروج',
            'my_profile' => 'ملفي الشخصي',
            'member_portal' => 'بوابة الأعضاء',
            'footer_copyright' => 'جميع الحقوق محفوظة.',
            'maintenance_title' => 'وضع الصيانة',
            'maintenance_body' => 'نقوم حالياً بصيانة مجدولة. يرجى العودة لاحقاً.',
            'greeting_morning' => 'صباح الخير',
            'greeting_afternoon' => 'مساء الخير',
            'greeting_evening' => 'مساء الخير',
            'today_is' => 'اليوم هو',
            'time' => 'الوقت',
            'visitors_inside' => 'المتواجدون حالياً',
            'total_members' => 'إجمالي الأعضاء',
            'total_books' => 'إجمالي الكتب',
            'currently_issued' => 'المستعارة حالياً',
            'overdue_books' => 'الكتب المتأخرة',
            'ebooks_available' => 'الكتب الإلكترونية المتاحة',
            'pending_reservations' => 'الحجوزات المعلقة',
            'upcoming_events' => 'الفعاليات القادمة',
            'fines_today' => 'الغرامات المحصلة اليوم',
            'quick_actions' => 'الإجراءات السريعة',
            'no_quick_actions' => 'لا توجد إجراءات سريعة. يرجى إضافتها في <a href="admin/quick_actions.php">مدير الإجراءات السريعة</a>.',
            'issue_book' => 'إعارة كتاب',
            'issue_desc' => 'مسح باركود العضو والكتاب',
            'return_book' => 'إرجاع كتاب',
            'return_desc' => 'معالجة الإرجاع والغرامات',
            'renew' => 'تجديد',
            'renew_desc' => 'تمديد موعد الاستحقاق',
            'computer_access' => 'الوصول إلى الحاسوب',
            'computer_desc' => 'إدارة حجوزات الحاسوب',
            'ebooks' => 'الكتب الإلكترونية',
            'ebooks_desc' => 'المجموعة الرقمية',
            'utilities' => 'مجموعة الأدوات',
            'utilities_desc' => 'الأدوات والمساعدات',
            'serial_control' => 'التحكم في الدوريات',
            'serial_desc' => 'إدارة الدوريات',
            'backup_restore' => 'النسخ الاحتياطي والاستعادة',
            'backup_desc' => 'أمان البيانات',
            'reports' => 'التقارير',
            'reports_desc' => 'إنشاء الإحصائيات',
            'settings' => 'الإعدادات',
            'settings_desc' => 'تكوين النظام',
            'quick_access' => 'وصول سريع',
            'dark' => 'مظلم',
            'light' => 'فاتح',

            // Sidebar (Title‑Case Keys)
            'Main' => 'الرئيسية',
            'Admin Dashboard' => 'لوحة التحكم',
            'Circulation' => 'الإعارة والإرجاع',
            'Members' => 'الأعضاء',
            'Books' => 'الكتب',
            'eBooks' => 'الكتب الإلكترونية',
            'Research' => 'البحث العلمي',
            'Research Databases' => 'قواعد البيانات البحثية',
            'Acquisitions & Serials' => 'الاقتناء والدوريات',
            'Acquisitions' => 'الاقتناء',
            'Serials Control' => 'التحكم في الدوريات',
            'Administration' => 'الإدارة',
            'System Settings' => 'إعدادات النظام',
            'Quick Actions Manager' => 'مدير الإجراءات السريعة',
            'Loan Rules' => 'قواعد الإعارة',
            'Staff Profiles' => 'ملفات تعريف الموظفين',
            'Manage Notices' => 'إدارة الإشعارات',
            'Suggestions' => 'الاقتراحات',
            'Fine Rates' => 'أسعار الغرامات',
            'Backup & Restore' => 'النسخ الاحتياطي والاستعادة',
            'Utilities Suite' => 'مجموعة الأدوات',
            'Stock Verification' => 'جرد المخزون',
            'Lost & Damaged' => 'الكتب المفقودة والتالفة',
            'Payments' => 'المدفوعات',
            'Reservations' => 'الحجوزات',
            'Library Events' => 'فعاليات المكتبة',
            'Member Documents' => 'وثائق الأعضاء',
            'Computer Access' => 'الوصول إلى الحاسوب',
            'Data Import' => 'استيراد البيانات',
            'Entry/Exit' => 'الدخول/الخروج',
            'Session Logs' => 'سجلات الجلسات',
            'Communication' => 'التواصل',
            'Bulk Messaging' => 'رسائل جماعية (SMS/WhatsApp)',
            'Chatbot' => 'المساعد الآلي للمكتبة',
            'Reports & Analytics' => 'التقارير والتحليلات',
            'Reports' => 'التقارير',
            'Advanced Analytics' => 'التحليلات المتقدمة',
            'Cron' => 'المهام المجدولة (Cron)',
            'Public Interfaces' => 'الواجهات العامة',
            'OPAC' => 'الفهرس العام',
            'Digital Library Hub' => 'المركز الرقمي',
            'Self Kiosk' => 'الخدمة الذاتية',
            'Member Portal' => 'بوابة الأعضاء',
            'Multi‑Library' => 'المكتبات المتعددة',
            'Institutions' => 'المؤسسات',
            'API' => 'واجهة البرمجة (API)',
            'REST API' => 'REST API',
            'Account' => 'الحساب',

            // Underscore keys (compatibility)
            'main' => 'الرئيسية',
            'admin_dashboard' => 'لوحة التحكم',
            'circulation' => 'الإعارة والإرجاع',
            'members' => 'الأعضاء',
            'books' => 'الكتب',
            'research' => 'البحث العلمي',
            'research_databases' => 'قواعد البيانات البحثية',
            'acquisitions_serials' => 'الاقتناء والدوريات',
            'acquisitions' => 'الاقتناء',
            'serial_control_menu' => 'التحكم في الدوريات',
            'administration' => 'الإدارة',
            'system_settings' => 'إعدادات النظام',
            'quick_actions_manager' => 'مدير الإجراءات السريعة',
            'loan_rules' => 'قواعد الإعارة',
            'staff_profiles' => 'ملفات تعريف الموظفين',
            'manage_notices' => 'إدارة الإشعارات',
            'suggestions' => 'الاقتراحات',
            'fine_rates' => 'أسعار الغرامات',
            'backup_restore_menu' => 'النسخ الاحتياطي والاستعادة',
            'utilities_suite' => 'مجموعة الأدوات',
            'stock_verification' => 'جرد المخزون',
            'lost_damaged' => 'الكتب المفقودة والتالفة',
            'payments' => 'المدفوعات',
            'reservations' => 'الحجوزات',
            'events' => 'فعاليات المكتبة',
            'member_docs' => 'وثائق الأعضاء',
            'computer_management' => 'الوصول إلى الحاسوب',
            'data_import' => 'استيراد البيانات',
            'entry_exit' => 'الدخول/الخروج',
            'session_logs' => 'سجلات الجلسات',
            'communication' => 'التواصل',
            'bulk_messaging' => 'رسائل جماعية (SMS/WhatsApp)',
            'chatbot' => 'المساعد الآلي للمكتبة',
            'reports_analytics' => 'التقارير والتحليلات',
            'reports_menu' => 'التقارير',
            'advanced_analytics' => 'التحليلات المتقدمة',
            'cron' => 'المهام المجدولة (Cron)',
            'public_interfaces' => 'الواجهات العامة',
            'opac' => 'الفهرس العام',
            'digital_hub' => 'المركز الرقمي',
            'self_kiosk' => 'الخدمة الذاتية',
            'multi_library' => 'المكتبات المتعددة',
            'institutions' => 'المؤسسات',
            'api' => 'واجهة البرمجة (API)',
            'rest_api' => 'REST API',
            'account' => 'الحساب',
        ]
    ];
}

// ==================== TRANSLATION FUNCTION ====================
function __(string $key): string {
    global $translations;
    // If the key exists, return the translation; otherwise return the key itself.
    return $translations[$key] ?? $key;
}

// ==================== RTL DETECTION ====================
function isRTL(): bool {
    return getCurrentLanguage() === 'ar';
}

function getDirAttribute(): string {
    return isRTL() ? 'rtl' : 'ltr';
}

// ==================== LANGUAGE SWITCHER UI ====================
function renderLanguageSwitcher(string $style = 'dropdown', string $extraClasses = ''): string {
    $currentLang = getCurrentLanguage();
    $available = ['en' => '🇬🇧 English', 'hi' => '🇮🇳 हिन्दी', 'ar' => '🇸🇦 العربية'];

    if ($style === 'simple') {
        $html = '<div class="language-switcher-simple ' . $extraClasses . '">';
        foreach ($available as $code => $label) {
            $active = ($code === $currentLang) ? ' active fw-bold' : '';
            $html .= '<a href="?lang=' . $code . '" class="lang-link' . $active . '">' . $label . '</a>';
            if ($code !== array_key_last($available)) {
                $html .= ' | ';
            }
        }
        $html .= '</div>';
        return $html;
    }

    // Bootstrap dropdown
    $html = '<div class="dropdown ' . $extraClasses . '">';
    $html .= '<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
    $html .= '<i class="fas fa-globe"></i> ' . strtoupper($currentLang);
    $html .= '</button>';
    $html .= '<ul class="dropdown-menu dropdown-menu-end">';
    foreach ($available as $code => $label) {
        $active = ($code === $currentLang) ? ' active' : '';
        $html .= '<li><a class="dropdown-item' . $active . '" href="?lang=' . $code . '">' . $label . '</a></li>';
    }
    $html .= '</ul></div>';
    return $html;
}

// ==================== INLINE LANGUAGE SWITCHER ====================
function renderLanguageSwitcherInline(): string {
    $currentLang = getCurrentLanguage();
    $flags = ['en' => '🇬🇧', 'hi' => '🇮🇳', 'ar' => '🇸🇦'];
    $labels = ['en' => 'English', 'hi' => 'हिन्दी', 'ar' => 'العربية'];

    $html = '<div class="lang-switch-inline" style="display: flex; gap: 8px; align-items: center;">';
    foreach ($flags as $code => $flag) {
        $active = ($code === $currentLang) ? ' style="font-weight:bold; text-decoration:underline;"' : '';
        $html .= '<a href="?lang=' . $code . '"' . $active . ' title="' . $labels[$code] . '" style="text-decoration:none; font-size:1.2rem;">' . $flag . '</a>';
    }
    $html .= '</div>';
    return $html;
}

// ==================== SESSION INITIALIZATION ====================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$lang = getCurrentLanguage();
$translations = loadTranslations($lang);

// ==================== FLAG ICON HELPERS ====================
function getLanguageFlag(string $lang): string {
    return ['en' => '🇬🇧', 'hi' => '🇮🇳', 'ar' => '🇸🇦'][$lang] ?? '🌐';
}

function getLanguageName(string $lang): string {
    return ['en' => 'English', 'hi' => 'हिन्दी', 'ar' => 'العربية'][$lang] ?? $lang;
}