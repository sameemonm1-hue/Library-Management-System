// In any PHP file after including config/db.php and functions.php
require_once __DIR__ . '/config/Mailer.php';

$mailer = new Mailer();
if ($mailer->send('user@example.com', 'Welcome!', '<p>Thank you for registering.</p>')) {
    echo "Email sent successfully";
} else {
    echo "Failed: " . $mailer->getError();
}

// Test SMTP connection (from admin settings page)
if ($mailer->testConnection('admin@example.com')) {
    showToast("Test email sent", "success");
} else {
    showToast("SMTP error: " . $mailer->getError(), "danger");
}