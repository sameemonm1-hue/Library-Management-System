<?php
/**
 * SQLite Migration Manager – Improved version
 */
class MigrationManager {
    private $db;
    private $migrationsTable = 'migrations';
    private $migrationsDir;
    private $cacheClearCallback = null;

    public function __construct($db, $migrationsDir = __DIR__ . '/../migrations/', $cacheClearCallback = null) {
        $this->db = $db;
        $this->migrationsDir = rtrim($migrationsDir, '/') . '/';
        $this->cacheClearCallback = $cacheClearCallback;
        $this->ensureMigrationsTable();
    }

    private function ensureMigrationsTable() {
        $this->db->exec("CREATE TABLE IF NOT EXISTS {$this->migrationsTable} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            migration_file TEXT NOT NULL UNIQUE,
            applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }

    private function getAppliedMigrations() {
        $stmt = $this->db->query("SELECT migration_file FROM {$this->migrationsTable} ORDER BY id");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    private function markApplied($file) {
        $stmt = $this->db->prepare("INSERT INTO {$this->migrationsTable} (migration_file) VALUES (?)");
        $stmt->execute([$file]);
    }

    /**
     * Split SQL into statements, respecting semicolons inside quotes.
     */
    private function splitSql($sql) {
        $statements = [];
        $len = strlen($sql);
        $inSingleQuote = false;
        $inDoubleQuote = false;
        $inBacktick = false;
        $current = '';

        for ($i = 0; $i < $len; $i++) {
            $char = $sql[$i];
            $nextChar = $i + 1 < $len ? $sql[$i + 1] : '';

            // Toggle quote states
            if ($char === "'" && !$inDoubleQuote && !$inBacktick && ($i === 0 || $sql[$i-1] !== '\\')) {
                $inSingleQuote = !$inSingleQuote;
            } elseif ($char === '"' && !$inSingleQuote && !$inBacktick) {
                $inDoubleQuote = !$inDoubleQuote;
            } elseif ($char === '`' && !$inSingleQuote && !$inDoubleQuote) {
                $inBacktick = !$inBacktick;
            }

            // If we're not inside quotes and we encounter a semicolon that is not part of ';;' (empty statement)
            if (!$inSingleQuote && !$inDoubleQuote && !$inBacktick && $char === ';' && $nextChar !== ';') {
                $stmt = trim($current);
                if ($stmt !== '') {
                    $statements[] = $stmt;
                }
                $current = '';
            } else {
                $current .= $char;
            }
        }

        // Last statement (if no trailing semicolon)
        $last = trim($current);
        if ($last !== '') {
            $statements[] = $last;
        }

        return $statements;
    }

    public function runPending() {
        $applied = $this->getAppliedMigrations();
        $files = glob($this->migrationsDir . '*.sql');
        natsort($files);

        $result = ['run' => [], 'errors' => []];

        foreach ($files as $filepath) {
            $filename = basename($filepath);
            if (in_array($filename, $applied)) {
                continue;
            }

            $sql = file_get_contents($filepath);
            if ($sql === false) {
                $result['errors'][$filename] = "Failed to read file.";
                continue;
            }

            try {
                $statements = $this->splitSql($sql);
                $this->db->beginTransaction();
                foreach ($statements as $stmt) {
                    if (!empty($stmt)) {
                        $this->db->exec($stmt);
                    }
                }
                $this->db->commit();
                $this->markApplied($filename);
                $result['run'][] = $filename;
            } catch (PDOException $e) {
                $this->db->rollBack();
                $result['errors'][$filename] = $e->getMessage();
            }
        }

        // If any migrations were applied, clear the application cache (if callback provided)
        if (!empty($result['run']) && is_callable($this->cacheClearCallback)) {
            call_user_func($this->cacheClearCallback);
        }

        return $result;
    }

    public function getStatus() {
        $applied = $this->getAppliedMigrations();
        $all = glob($this->migrationsDir . '*.sql');
        $pending = array_diff(array_map('basename', $all), $applied);
        return [
            'applied' => $applied,
            'pending' => array_values($pending)
        ];
    }
}