<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$action = $_GET['action'] ?? '';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_vendor'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token.";
    } else {
        $name = trim($_POST['name']);
        $contact = trim($_POST['contact_person']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $gst = trim($_POST['gst_no']);
        $notes = trim($_POST['notes']);
        
        if (!$name) {
            $error = "Vendor name is required.";
        } else {
            $stmt = $db->prepare("INSERT INTO vendors (name, contact_person, email, phone, address, gst_no, notes) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$name, $contact, $email, $phone, $address, $gst, $notes]);
            $success = "Vendor added successfully.";
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }
}

if ($action == 'delete' && isset($_GET['id'])) {
    if (!isset($_GET['token']) || $_GET['token'] !== $_SESSION['csrf_token']) {
        die("Invalid security token.");
    }
    $id = intval($_GET['id']);
    $stmt = $db->prepare("DELETE FROM vendors WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: vendors.php?msg=deleted");
    exit;
}

$vendors = $db->query("SELECT * FROM vendors ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vendors - Acquisitions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .card-custom { background: white; border-radius: 16px; padding: 20px; margin-bottom: 25px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-truck"></i> Vendors</h2>
                <div>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Orders</a>
                    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <div class="card-custom">
                <h5>Add New Vendor</h5>
                <form method="POST" class="row g-3">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <div class="col-md-4"><input type="text" name="name" class="form-control" placeholder="Vendor Name *" required></div>
                    <div class="col-md-4"><input type="text" name="contact_person" class="form-control" placeholder="Contact Person"></div>
                    <div class="col-md-4"><input type="email" name="email" class="form-control" placeholder="Email"></div>
                    <div class="col-md-3"><input type="text" name="phone" class="form-control" placeholder="Phone"></div>
                    <div class="col-md-3"><input type="text" name="gst_no" class="form-control" placeholder="GST No."></div>
                    <div class="col-md-6"><input type="text" name="address" class="form-control" placeholder="Address"></div>
                    <div class="col-12"><textarea name="notes" class="form-control" rows="2" placeholder="Notes"></textarea></div>
                    <div class="col-12"><button type="submit" name="add_vendor" class="btn btn-primary">Add Vendor</button></div>
                </form>
            </div>

            <div class="card-custom">
                <h5>Existing Vendors</h5>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Email</th><th>Phone</th><th>GST</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach($vendors as $v): ?>
                            <tr>
                                <td><?= $v['id'] ?></td>
                                <td><?= htmlspecialchars($v['name']) ?></td>
                                <td><?= htmlspecialchars($v['contact_person']) ?></td>
                                <td><?= htmlspecialchars($v['email']) ?></td>
                                <td><?= htmlspecialchars($v['phone']) ?></td>
                                <td><?= htmlspecialchars($v['gst_no']) ?></td>
                                <td>
                                    <a href="edit_vendor.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <a href="?action=delete&id=<?= $v['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this vendor?')">Delete</a>
                                 </div>
                             </div>
                            <?php endforeach; ?>
                        </tbody>
                     </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>