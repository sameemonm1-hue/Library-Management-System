<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$id = intval($_GET['id']);
$stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) die("Order not found.");
if ($order['status'] == 'received') die("Order already fully received.");

$stmt2 = $db->prepare("SELECT * FROM purchase_order_items WHERE po_id = ?");
$stmt2->execute([$id]);
$items = $stmt2->fetchAll();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token.";
    } else {
        $all_received = true;
        $db->beginTransaction();
        try {
            foreach ($items as $item) {
                $received_qty = intval($_POST["received_qty_{$item['id']}"] ?? 0);
                if ($received_qty > $item['quantity']) $received_qty = $item['quantity'];
                if ($received_qty > 0) {
                    $db->prepare("UPDATE purchase_order_items SET received_quantity = received_quantity + ? WHERE id = ?")->execute([$received_qty, $item['id']]);
                    
                    $barcode_pattern = $settings['barcode_pattern'] ?? 'BK-{DATE}-{RAND}';
                    for ($i = 0; $i < $received_qty; $i++) {
                        $barcode = str_replace(['{DATE}', '{RAND}'], [date('Ymd'), rand(10000, 99999)], $barcode_pattern);
                        $ins = $db->prepare("INSERT INTO books (barcode, title, author, isbn, quantity, available, price) VALUES (?,?,?,?,1,1,?)");
                        $ins->execute([$barcode, $item['book_title'], $item['author'], $item['isbn'], $item['unit_price']]);
                    }
                }
                $upd = $db->prepare("SELECT received_quantity, quantity FROM purchase_order_items WHERE id = ?");
                $upd->execute([$item['id']]);
                $updated_item = $upd->fetch();
                if ($updated_item['received_quantity'] < $updated_item['quantity']) $all_received = false;
            }
            if ($all_received) {
                $db->prepare("UPDATE purchase_orders SET status = 'received' WHERE id = ?")->execute([$id]);
            }
            $db->commit();
            logActivity($_SESSION['username'], 'PO_RECEIVE', "Received items for order {$order['order_no']}");
            $success = "Items received successfully.";
            $stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ?");
            $stmt->execute([$id]);
            $order = $stmt->fetch();
            $stmt2 = $db->prepare("SELECT * FROM purchase_order_items WHERE po_id = ?");
            $stmt2->execute([$id]);
            $items = $stmt2->fetchAll();
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } catch (PDOException $e) {
            $db->rollBack();
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Receive Order</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Receive Order: <?= htmlspecialchars($order['order_no']) ?></h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        <?php if($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
        <div class="form-card">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <table class="table table-bordered">
                    <thead><tr><th>Title</th><th>Author</th><th>Ordered</th><th>Already Received</th><th>Receive Now</th></tr></thead>
                    <tbody>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['book_title']) ?></td>
                            <td><?= htmlspecialchars($item['author']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td><?= $item['received_quantity'] ?></td>
                            <td><input type="number" name="received_qty_<?= $item['id'] ?>" class="form-control" min="0" max="<?= $item['quantity'] - $item['received_quantity'] ?>" value="0"></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-primary">Receive Checked Items</button>
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>