<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['csrf_token'] ?? '')) {
    die("Invalid security token.");
}

$db = getDB();
$id = intval($_GET['id']);
$stmt = $db->prepare("SELECT status FROM purchase_orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();
if (!$order) die("Order not found.");
if ($order['status'] == 'received') die("Cannot delete a received order.");

$db->prepare("DELETE FROM purchase_order_items WHERE po_id = ?")->execute([$id]);
$db->prepare("DELETE FROM purchase_orders WHERE id = ?")->execute([$id]);
logActivity($_SESSION['username'], 'PO_DELETE', "Deleted order ID: $id");
header("Location: index.php?msg=deleted");
exit;
?>