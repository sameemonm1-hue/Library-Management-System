<?php
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in functions.php

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currency_symbol = $settings['currency_symbol'] ?? '$';
$currency_code = $settings['currency_code'] ?? 'USD';

$status_filter = $_GET['status'] ?? '';
$vendor_filter = $_GET['vendor'] ?? '';

$sql = "SELECT po.*, v.name as vendor_name 
        FROM purchase_orders po
        LEFT JOIN vendors v ON po.vendor_id = v.id
        WHERE 1=1";
$params = [];
if ($status_filter) {
    $sql .= " AND po.status = ?";
    $params[] = $status_filter;
}
if ($vendor_filter) {
    $sql .= " AND po.vendor_id = ?";
    $params[] = $vendor_filter;
}
$sql .= " ORDER BY po.order_date DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$vendors = $db->query("SELECT id, name FROM vendors ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Purchase Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .card-custom { background: white; border-radius: 16px; padding: 20px; margin-bottom: 25px; }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-shopping-cart"></i> Purchase Orders</h2>
                <div>
                    <a href="add_order.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Order</a>
                    <a href="vendors.php" class="btn btn-outline-secondary"><i class="fas fa-truck"></i> Manage Vendors</a>
                    <a href="../index.php" class="btn btn-secondary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <div class="card-custom">
                <form method="GET" class="row g-3">
                    <div class="col-md-3"><label>Status</label><select name="status" class="form-select"><option value="">All</option>
                        <option value="pending" <?= $status_filter=='pending'?'selected':'' ?>>Pending</option>
                        <option value="approved" <?= $status_filter=='approved'?'selected':'' ?>>Approved</option>
                        <option value="shipped" <?= $status_filter=='shipped'?'selected':'' ?>>Shipped</option>
                        <option value="received" <?= $status_filter=='received'?'selected':'' ?>>Received</option>
                        <option value="cancelled" <?= $status_filter=='cancelled'?'selected':'' ?>>Cancelled</option>
                    </select></div>
                    <div class="col-md-3"><label>Vendor</label><select name="vendor" class="form-select"><option value="">All</option>
                        <?php foreach($vendors as $v): ?>
                            <option value="<?= $v['id'] ?>" <?= $vendor_filter==$v['id']?'selected':'' ?>><?= htmlspecialchars($v['name']) ?></option>
                        <?php endforeach; ?>
                    </select></div>
                    <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-primary">Filter</button> <a href="index.php" class="btn btn-secondary ms-2">Reset</a></div>
                </form>
            </div>

            <div class="card-custom">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead><tr><th>Order No.</th><th>Date</th><th>Vendor</th><th>Total Amount</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach($orders as $o): ?>
                            <tr>
                                <td><?= htmlspecialchars($o['order_no']) ?></td>
                                <td><?= date('d-m-Y', strtotime($o['order_date'])) ?></td>
                                <td><?= htmlspecialchars($o['vendor_name']) ?></td>
                                <td><?= $currency_symbol ?> <?= number_format($o['total_amount'],2) ?> <?= $currency_code ?></td>
                                <td><span class="badge bg-<?= $o['status']=='pending'?'warning':($o['status']=='approved'?'info':($o['status']=='received'?'success':'secondary')) ?>"><?= ucfirst($o['status']) ?></span></td>
                                <td>
                                    <a href="po_print.php?id=<?= $o['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary"><i class="fas fa-print"></i></a>
                                    <?php if($o['status'] != 'received' && $o['status'] != 'cancelled'): ?>
                                        <a href="receive.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-success">Receive</a>
                                        <a href="edit_order.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                        <a href="delete_order.php?id=<?= $o['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this order?')">Delete</a>
                                    <?php endif; ?>
                                 </div>
                             </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?></p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>