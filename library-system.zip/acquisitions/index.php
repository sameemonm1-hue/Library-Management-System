<?php
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in functions.php

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currency_symbol = $settings['currency_symbol'] ?? '$';
$currency_code = $settings['currency_code'] ?? 'USD';

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

$status_filter = $_GET['status'] ?? '';
$vendor_filter = $_GET['vendor'] ?? '';

$sql = "SELECT po.*, v.name as vendor_name 
        FROM purchase_orders po
        LEFT JOIN vendors v ON po.vendor_id = v.id
        WHERE 1=1";
$params = [];
if ($status_filter) {
    $sql .= " AND po.status = ?";
    $params[] = $status_filter;
}
if ($vendor_filter) {
    $sql .= " AND po.vendor_id = ?";
    $params[] = $vendor_filter;
}
$sql .= " ORDER BY po.order_date DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

$vendors = $db->query("SELECT id, name FROM vendors ORDER BY name")->fetchAll();

// Statistics
$totalOrders = count($orders);
$totalAmount = array_sum(array_column($orders, 'total_amount'));
$pendingOrders = count(array_filter($orders, fn($o) => $o['status'] == 'pending'));
$receivedOrders = count(array_filter($orders, fn($o) => $o['status'] == 'received'));
?>
<!DOCTYPE html>
<html>
<head>
    <title>Purchase Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        
        /* ========== SETTINGS BAR - REMOVED ========== */
        .settings-bar {
            display: none !important;
        }
        
        /* ========== CARD STYLES ========== */
        .card-custom { 
            background: white; 
            border-radius: 12px; 
            padding: 20px; 
            margin-bottom: 25px; 
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        .card-custom:hover {
            transform: translateY(-2px);
        }
        .card-header-custom {
            padding: 15px 20px;
            background: var(--primary-color);
            color: white;
            border-radius: 12px 12px 0 0;
            margin: -20px -20px 20px -20px;
        }
        
        /* ========== STAT CARDS - UNIFIED GRADIENT ========== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .stat-card {
            border: none;
            border-radius: 12px;
            padding: 15px 20px;
            text-align: center;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            cursor: default;
            position: relative;
            overflow: hidden;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card .stat-icon {
            font-size: 2rem;
            opacity: 0.2;
            position: absolute;
            right: 15px;
            top: 15px;
            color: white;
        }
        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            line-height: 1.2;
        }
        .stat-card .stat-label {
            color: rgba(255,255,255,0.9);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        /* ========== TABLE STYLES ========== */
        .table thead th {
            background: var(--primary-color);
            color: white;
            font-weight: 600;
            border-bottom: none;
            white-space: nowrap;
            padding: 10px 12px;
        }
        .table td {
            padding: 10px 12px;
            vertical-align: middle;
        }
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        .table tfoot {
            background: #f8f9fa;
            font-weight: 600;
        }
        
        /* ========== BUTTONS ========== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ========== PAGINATION ========== */
        .pagination .page-link {
            color: var(--primary-color);
        }
        .pagination .page-item.active .page-link {
            background: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        /* ========== BADGE STYLES ========== */
        .badge {
            font-weight: 500;
            padding: 5px 12px;
            border-radius: 20px;
        }
        
        /* ========== FOOTER ========== */
        .footer { 
            text-align: center; 
            padding: 20px; 
            color: #6c757d; 
            background: white; 
            margin-top: 30px; 
            border-radius: 12px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .footer a { color: var(--primary-color); text-decoration: none; }
        .footer a:hover { text-decoration: underline; }
        
        /* ========== RESPONSIVE ========== */
        @media (max-width: 768px) {
            .content-wrapper { padding: 15px; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
            .stat-card .stat-number { font-size: 1.3rem; }
        }
        
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
            .stat-card .stat-number { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-icon { display: none !important; }
            .table thead th { background: #333 !important; color: white !important; }
            .footer { border-top: 1px solid #ddd !important; }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <!-- ========== HEADER ========== -->
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
                <h2 style="color: var(--primary-color);"><i class="fas fa-shopping-cart"></i> Purchase Orders</h2>
                <div class="no-print d-flex flex-wrap gap-2">
                    <a href="add_order.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Order</a>
                    <a href="vendors.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-truck"></i> Manage Vendors</a>
                    <a href="../index.php" class="btn btn-secondary btn-sm"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <!-- ========== STATISTICS CARDS - UNIFIED GRADIENT ========== -->
            <div class="stats-grid no-print">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-shopping-cart"></i></div>
                    <div class="stat-number"><?= number_format($totalOrders) ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-number"><?= number_format($pendingOrders) ?></div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?= number_format($receivedOrders) ?></div>
                    <div class="stat-label">Received</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-money-bill"></i></div>
                    <div class="stat-number"><?= $currency_symbol ?> <?= number_format($totalAmount, 0) ?></div>
                    <div class="stat-label">Total Value</div>
                </div>
            </div>

            <!-- ========== FILTER SECTION ========== -->
            <div class="card-custom no-print">
                <div class="card-header-custom">
                    <h6 class="mb-0"><i class="fas fa-filter"></i> Filter Orders</h6>
                </div>
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-bold small">Status</label>
                        <select name="status" class="form-select form-select-sm">
                            <option value="">All Status</option>
                            <option value="pending" <?= $status_filter=='pending'?'selected':'' ?>>Pending</option>
                            <option value="approved" <?= $status_filter=='approved'?'selected':'' ?>>Approved</option>
                            <option value="shipped" <?= $status_filter=='shipped'?'selected':'' ?>>Shipped</option>
                            <option value="received" <?= $status_filter=='received'?'selected':'' ?>>Received</option>
                            <option value="cancelled" <?= $status_filter=='cancelled'?'selected':'' ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold small">Vendor</label>
                        <select name="vendor" class="form-select form-select-sm">
                            <option value="">All Vendors</option>
                            <?php foreach($vendors as $v): ?>
                                <option value="<?= $v['id'] ?>" <?= $vendor_filter==$v['id']?'selected':'' ?>><?= htmlspecialchars($v['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 d-flex align-items-end gap-2">
                        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Filter</button>
                        <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-undo"></i> Reset</a>
                    </div>
                </form>
            </div>

            <!-- ========== ORDERS TABLE ========== -->
            <div class="card-custom">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0"><i class="fas fa-list"></i> Orders List</h6>
                    <span class="badge bg-secondary"><?= count($orders) ?> orders</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Order No.</th>
                                <th>Date</th>
                                <th>Vendor</th>
                                <th style="text-align:right;">Total Amount</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($orders)): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-4 text-muted">
                                        <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                        No purchase orders found.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($orders as $o): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($o['order_no']) ?></strong></td>
                                    <td><?= date('d-m-Y', strtotime($o['order_date'])) ?></td>
                                    <td><?= htmlspecialchars($o['vendor_name']) ?></td>
                                    <td style="text-align:right;font-weight:600;"><?= $currency_symbol ?> <?= number_format($o['total_amount'],2) ?></td>
                                    <td class="text-center">
                                        <span class="badge <?= $o['status']=='pending'?'bg-warning':($o['status']=='approved'?'bg-info':($o['status']=='received'?'bg-success':'bg-secondary')) ?>">
                                            <?= ucfirst($o['status']) ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm">
                                            <a href="po_print.php?id=<?= $o['id'] ?>" target="_blank" class="btn btn-outline-secondary" title="Print"><i class="fas fa-print"></i></a>
                                            <?php if($o['status'] != 'received' && $o['status'] != 'cancelled'): ?>
                                                <a href="receive.php?id=<?= $o['id'] ?>" class="btn btn-outline-success" title="Receive"><i class="fas fa-check"></i></a>
                                                <a href="edit_order.php?id=<?= $o['id'] ?>" class="btn btn-outline-primary" title="Edit"><i class="fas fa-edit"></i></a>
                                                <a href="delete_order.php?id=<?= $o['id'] ?>&token=<?= $_SESSION['csrf_token'] ?>" class="btn btn-outline-danger" onclick="return confirm('Delete this order?')" title="Delete"><i class="fas fa-trash"></i></a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <?php if (!empty($orders)): ?>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Totals:</strong></td>
                                <td style="text-align:right;font-weight:700;"><?= $currency_symbol ?> <?= number_format(array_sum(array_column($orders, 'total_amount')), 2) ?></td>
                                <td colspan="2"></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>

            <!-- ========== FOOTER ========== -->
            <div class="footer">
                <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
                <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>