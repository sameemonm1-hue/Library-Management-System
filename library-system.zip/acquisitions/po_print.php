<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

$id = intval($_GET['id']);
$db = getDB();
$settings = getSettings();
$currency_symbol = $settings['currency_symbol'] ?? '$';

$stmt = $db->prepare("SELECT po.*, v.name as vendor_name, v.address as vendor_address, v.contact_person, v.phone 
                      FROM purchase_orders po 
                      LEFT JOIN vendors v ON po.vendor_id = v.id 
                      WHERE po.id = ?");
$stmt->execute([$id]);
$po = $stmt->fetch();
if (!$po) die("Order not found.");

$stmt2 = $db->prepare("SELECT * FROM purchase_order_items WHERE po_id = ?");
$stmt2->execute([$id]);
$items = $stmt2->fetchAll();

$institution = getInstitution();
?>
<!DOCTYPE html>
<html>
<head><title>Purchase Order - <?= htmlspecialchars($po['order_no']) ?></title>
<style>
    body { font-family: 'Inter', sans-serif; margin: 20px; }
    .po-container { max-width: 800px; margin: auto; padding: 20px; border: 1px solid #ddd; }
    .header { text-align: center; margin-bottom: 30px; }
    .order-details { margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background: #f4f6f9; }
    .total { text-align: right; font-weight: bold; }
    @media print { .no-print { display: none; } }
    .btn-home { position: fixed; bottom: 20px; right: 20px; }
</style>
</head>
<body>
<div class="po-container">
    <div class="header">
        <h2><?= htmlspecialchars($institution['name'] ?? 'Library') ?></h2>
        <p><?= $institution['address'] ?? '' ?></p>
        <h3>PURCHASE ORDER</h3>
        <p><strong>Order No:</strong> <?= htmlspecialchars($po['order_no']) ?> | <strong>Date:</strong> <?= date('d-m-Y', strtotime($po['order_date'])) ?></p>
    </div>
    <div class="order-details">
        <p><strong>Vendor:</strong> <?= htmlspecialchars($po['vendor_name']) ?><br>
        <?= nl2br(htmlspecialchars($po['vendor_address'])) ?><br>
        Contact: <?= htmlspecialchars($po['contact_person']) ?> | Phone: <?= htmlspecialchars($po['phone']) ?></p>
        <p><strong>Expected Delivery:</strong> <?= $po['expected_delivery'] ? date('d-m-Y', strtotime($po['expected_delivery'])) : 'Not specified' ?></p>
    </div>
    <table>
        <thead><tr><th>#</th><th>Title</th><th>Author</th><th>ISBN</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
        <tbody>
            <?php $i=1; $grand=0; foreach($items as $it): $total = $it['quantity'] * $it['unit_price']; $grand += $total; ?>
            <tr><td><?= $i++ ?></td><td><?= htmlspecialchars($it['book_title']) ?></td><td><?= htmlspecialchars($it['author']) ?></td><td><?= htmlspecialchars($it['isbn']) ?></td><td><?= $it['quantity'] ?></td><td><?= $currency_symbol ?> <?= number_format($it['unit_price'],2) ?></td><td><?= $currency_symbol ?> <?= number_format($total,2) ?></td></tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot><tr><td colspan="6" class="total">Grand Total:</td><td><?= $currency_symbol ?> <?= number_format($grand,2) ?></td></tr>
        </tfoot>
    </table>
    <p><strong>Notes:</strong> <?= nl2br(htmlspecialchars($po['notes'])) ?></p>
    <p>Authorized Signature: ______________________</p>
    <div class="no-print" style="text-align:center; margin-top:20px;">
        <button onclick="window.print()" class="btn btn-primary">Print / PDF</button>
        <a href="index.php" class="btn btn-secondary">Back</a>
        <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Home</a>
    </div>
</div>
<script>window.onload = function() { window.print(); }</script>
</body>
</html>