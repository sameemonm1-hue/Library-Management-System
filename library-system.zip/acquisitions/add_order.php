<?php
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in db.php (included via functions.php)

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyCode = $settings['currency_code'] ?? 'USD';

$error = '';
$success = '';
$vendors = $db->query("SELECT id, name FROM vendors ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh and try again.";
    } else {
        $vendor_id = intval($_POST['vendor_id']);
        $order_date = $_POST['order_date'];
        $expected_delivery = $_POST['expected_delivery'] ?: null;
        $notes = trim($_POST['notes']);
        $status = 'pending';
        $created_by = $_SESSION['username'];
        
        $order_no = 'PO-' . date('Ymd') . '-' . rand(1000, 9999);
        $total_amount = 0;
        
        $items = [];
        foreach ($_POST['title'] as $key => $title) {
            if (trim($title) == '') continue;
            $isbn = trim($_POST['isbn'][$key]);
            $author = trim($_POST['author'][$key]);
            $quantity = intval($_POST['quantity'][$key]);
            $unit_price = floatval($_POST['unit_price'][$key]);
            if ($quantity <= 0 || $unit_price <= 0) continue;
            $items[] = [
                'title' => $title,
                'isbn' => $isbn,
                'author' => $author,
                'quantity' => $quantity,
                'unit_price' => $unit_price
            ];
            $total_amount += $quantity * $unit_price;
        }
        
        if ($vendor_id <= 0 || count($items) == 0) {
            $error = "Please select a vendor and add at least one item.";
        } else {
            try {
                $db->beginTransaction();
                $stmt = $db->prepare("INSERT INTO purchase_orders (order_no, vendor_id, order_date, expected_delivery, status, total_amount, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$order_no, $vendor_id, $order_date, $expected_delivery, $status, $total_amount, $notes, $created_by]);
                $po_id = $db->lastInsertId();
                
                foreach ($items as $item) {
                    $stmt = $db->prepare("INSERT INTO purchase_order_items (po_id, book_title, isbn, author, quantity, unit_price) VALUES (?,?,?,?,?,?)");
                    $stmt->execute([$po_id, $item['title'], $item['isbn'], $item['author'], $item['quantity'], $item['unit_price']]);
                }
                $db->commit();
                logActivity($_SESSION['username'], 'PO_ADD', "Created purchase order: $order_no");
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                header("Location: index.php?msg=created&order_no=" . urlencode($order_no));
                exit;
            } catch (PDOException $e) {
                $db->rollBack();
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Purchase Order - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .form-card { background: white; border-radius: 20px; padding: 30px; margin-top: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .btn-home { margin-left: 10px; }
        .item-row { background: #f8f9fa; padding: 10px; border-radius: 8px; margin-bottom: 10px; }
        .required-field::after { content: " *"; color: red; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-shopping-cart text-primary"></i> Create Purchase Order</h2>
            <div>
                <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Orders</a>
                <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
            </div>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle"></i> <?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="form-card">
            <form method="POST" id="poForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold required-field">Vendor</label>
                        <select name="vendor_id" class="form-select" required>
                            <option value="">-- Select Vendor --</option>
                            <?php foreach($vendors as $v): ?>
                                <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold required-field">Order Date</label>
                        <input type="date" name="order_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Expected Delivery</label>
                        <input type="date" name="expected_delivery" class="form-control">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Order Notes</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Any special instructions or notes..."></textarea>
                </div>
                
                <hr>
                <h5 class="mt-3"><i class="fas fa-boxes"></i> Order Items</h5>
                <p class="text-muted small"><i class="fas fa-info-circle"></i> ISBN field supports barcode scanning</p>
                
                <div id="itemsContainer">
                    <div class="item-row row g-2 mb-2">
                        <div class="col-4">
                            <input type="text" name="title[]" class="form-control" placeholder="Book Title *" required>
                        </div>
                        <div class="col-2">
                            <input type="text" name="isbn[]" class="form-control isbn-input" placeholder="ISBN / Barcode" autocomplete="off">
                            <small class="text-muted" style="font-size: 10px;">Scan or enter</small>
                        </div>
                        <div class="col-2">
                            <input type="text" name="author[]" class="form-control" placeholder="Author">
                        </div>
                        <div class="col-1">
                            <input type="number" name="quantity[]" class="form-control" placeholder="Qty" required min="1" value="1">
                        </div>
                        <div class="col-2">
                            <div class="input-group">
                                <span class="input-group-text"><?= $currencySymbol ?></span>
                                <input type="number" step="0.01" name="unit_price[]" class="form-control" placeholder="Unit Price" required min="0">
                            </div>
                        </div>
                        <div class="col-1">
                            <button type="button" class="btn btn-danger remove-row" title="Remove item">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3 mb-4">
                    <button type="button" id="addRow" class="btn btn-sm btn-secondary">
                        <i class="fas fa-plus"></i> Add Another Item
                    </button>
                </div>
                
                <hr>
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Create Purchase Order
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Add new row
            $('#addRow').click(function() {
                var newRow = $('.item-row:first').clone();
                newRow.find('input').val('');
                newRow.find('.isbn-input').val(''); // Clear ISBN
                newRow.find('input[name="quantity[]"]').val('1'); // Default quantity to 1
                $('#itemsContainer').append(newRow);
                updateRowNumbers();
            });
            
            // Remove row
            $(document).on('click', '.remove-row', function() {
                if($('.item-row').length > 1) {
                    $(this).closest('.item-row').remove();
                    updateRowNumbers();
                } else {
                    alert("At least one item is required.");
                }
            });
            
            // Update row numbers for better UX
            function updateRowNumbers() {
                $('.item-row').each(function(index) {
                    $(this).find('.row-number').remove();
                    $(this).prepend('<div class="col-1"><span class="badge bg-secondary row-number">#' + (index + 1) + '</span></div>');
                });
            }
            
            // Fetch book details by ISBN (barcode)
            $(document).on('blur', '.isbn-input', function() {
                var isbn = $(this).val().trim();
                var $row = $(this).closest('.item-row');
                
                if(isbn.length >= 10) {
                    // Show loading indicator
                    var $titleField = $row.find('input[name="title[]"]');
                    var $authorField = $row.find('input[name="author[]"]');
                    var originalTitle = $titleField.val();
                    
                    $titleField.val('Fetching...');
                    
                    // AJAX call to fetch book details from OpenLibrary API or local DB
                    $.ajax({
                        url: 'https://openlibrary.org/api/books?bibkeys=ISBN:' + isbn + '&format=json&jscmd=data',
                        method: 'GET',
                        timeout: 5000,
                        success: function(data) {
                            var key = 'ISBN:' + isbn;
                            if(data[key]) {
                                var book = data[key];
                                $titleField.val(book.title || '');
                                $authorField.val(book.authors ? book.authors.map(function(a) { return a.name; }).join(', ') : '');
                            } else {
                                $titleField.val(originalTitle || '');
                                // Try local database lookup
                                $.getJSON('../books/ajax_book.php?isbn=' + encodeURIComponent(isbn), function(localData) {
                                    if(localData && localData.title) {
                                        $titleField.val(localData.title);
                                        $authorField.val(localData.author || '');
                                    }
                                }).fail(function() {
                                    // Not found, keep original
                                });
                            }
                        },
                        error: function() {
                            $titleField.val(originalTitle || '');
                        }
                    });
                }
            });
            
            // Auto-calculate total on form submit (optional)
            $('#poForm').on('submit', function() {
                var hasValidItems = false;
                $('.item-row').each(function() {
                    var title = $(this).find('input[name="title[]"]').val().trim();
                    var qty = $(this).find('input[name="quantity[]"]').val();
                    var price = $(this).find('input[name="unit_price[]"]').val();
                    if(title && qty > 0 && price > 0) {
                        hasValidItems = true;
                    }
                });
                
                if(!hasValidItems) {
                    alert('Please add at least one valid item with title, quantity, and price.');
                    return false;
                }
                return true;
            });
            
            // Initialize row numbers
            updateRowNumbers();
        });
    </script>
</body>
</html>