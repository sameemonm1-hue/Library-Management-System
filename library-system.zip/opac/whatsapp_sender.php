#!/usr/bin/env php
<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

// Fetch pending messages with retries < 3 and scheduled time <= now
$stmt = $db->prepare("SELECT * FROM whatsapp_queue WHERE status IN ('pending','retry') AND retry_count < 3 AND (scheduled_at IS NULL OR scheduled_at <= datetime('now')) ORDER BY priority DESC, created_at ASC LIMIT 50");
$stmt->execute();
$messages = $stmt->fetchAll();

foreach ($messages as $msg) {
    // Replace with actual WhatsApp API call (Twilio, WhatsApp Business, etc.)
    $sent = sendWhatsAppMessage($msg['recipient_number'], $msg['message_text']);
    
    if ($sent) {
        $update = $db->prepare("UPDATE whatsapp_queue SET status = 'sent', sent_at = datetime('now') WHERE id = ?");
        $update->execute([$msg['id']]);
    } else {
        $newRetry = $msg['retry_count'] + 1;
        $newStatus = $newRetry >= 3 ? 'failed' : 'retry';
        $update = $db->prepare("UPDATE whatsapp_queue SET retry_count = ?, status = ?, error_message = ? WHERE id = ?");
        $update->execute([$newRetry, $newStatus, 'API send failed', $msg['id']]);
    }
}

function sendWhatsAppMessage($to, $message) {
    // Implement your WhatsApp API integration here
    // Example using Twilio or custom gateway
    // Return true on success, false on failure
    // For now, simulate success (log only)
    error_log("WhatsApp to $to: $message");
    return true;
}