<?php
/**
 * Semantic Search Page
 * Uses OpenAI embeddings for semantic similarity search (fallback to FTS5)
 * Header now matches OPAC index.php (reliable logo URL, same layout)
 */
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

$settings = getSettings();
$institution = getInstitution();

// ========== Multi-language support ==========
$availableLanguages = ['en', 'ar'];
$lang = $_SESSION['lang'] ?? ($settings['default_language'] ?? 'en');
if (isset($_GET['lang']) && in_array($_GET['lang'], $availableLanguages)) {
    $_SESSION['lang'] = $_GET['lang'];
    $lang = $_GET['lang'];
}
$langFile = __DIR__ . "/../lang/{$lang}.json";
$translations = file_exists($langFile) ? json_decode(file_get_contents($langFile), true) : [];

function __($key) {
    global $translations;
    return $translations[$key] ?? $key;
}

// ========== OpenAI API Key from settings ==========
$openaiApiKey = $settings['openai_api_key'] ?? '';
$useEmbeddings = !empty($openaiApiKey) && function_exists('curl_init');

// ========== Helper: Get embedding vector from OpenAI ==========
function getEmbedding($text, $apiKey) {
    $url = 'https://api.openai.com/v1/embeddings';
    $data = [
        'model' => 'text-embedding-3-small',
        'input' => $text
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode === 200) {
        $result = json_decode($response, true);
        return $result['data'][0]['embedding'] ?? null;
    }
    return null;
}

// ========== Cosine similarity between two vectors ==========
function cosineSimilarity($vecA, $vecB) {
    $dot = 0;
    $normA = 0;
    $normB = 0;
    $len = count($vecA);
    for ($i = 0; $i < $len; $i++) {
        $dot += $vecA[$i] * $vecB[$i];
        $normA += $vecA[$i] * $vecA[$i];
        $normB += $vecB[$i] * $vecB[$i];
    }
    $normA = sqrt($normA);
    $normB = sqrt($normB);
    if ($normA == 0 || $normB == 0) return 0;
    return $dot / ($normA * $normB);
}

// ========== Semantic search using embeddings ==========
function semanticSearch($query, $db, $apiKey, $limit = 20) {
    $queryEmbedding = getEmbedding($query, $apiKey);
    if (!$queryEmbedding) return null;
    
    $stmt = $db->query("SELECT id, barcode, title, author, isbn, publisher, year, category, subject, summary, cover_path, available FROM books WHERE status != 'Deleted' LIMIT 500");
    $books = $stmt->fetchAll();
    
    $results = [];
    foreach ($books as $book) {
        $text = $book['title'] . ' ' . ($book['author'] ?? '') . ' ' . ($book['subject'] ?? '') . ' ' . ($book['summary'] ?? '');
        $text = mb_substr($text, 0, 8000);
        $bookEmbedding = getEmbedding($text, $apiKey);
        if ($bookEmbedding) {
            $score = cosineSimilarity($queryEmbedding, $bookEmbedding);
            $results[] = ['book' => $book, 'score' => $score];
        }
    }
    usort($results, function($a, $b) { return $b['score'] <=> $a['score']; });
    return array_slice($results, 0, $limit);
}

// ========== Fallback: FTS5 full‑text search ==========
function fts5Search($query, $db, $limit = 20) {
    $stmt = $db->prepare("SELECT b.*, rank FROM books_fts ft JOIN books b ON ft.rowid = b.id WHERE books_fts MATCH ? ORDER BY rank LIMIT ?");
    $stmt->execute([$query, $limit]);
    $books = $stmt->fetchAll();
    $results = [];
    foreach ($books as $book) {
        $results[] = ['book' => $book, 'score' => 1.0 / ($book['rank'] ?? 1)];
    }
    return $results;
}

// ========== Process search query ==========
$searchQuery = $_GET['q'] ?? '';
$results = [];
$error = '';
$searchType = $_GET['type'] ?? 'semantic';

if (!empty($searchQuery)) {
    if ($useEmbeddings && $searchType === 'semantic') {
        $results = semanticSearch($searchQuery, $db, $openaiApiKey, 30);
        if ($results === null) {
            $error = "Semantic search failed. Falling back to keyword search.";
            $results = fts5Search($searchQuery, $db, 30);
        }
    } else {
        $results = fts5Search($searchQuery, $db, 30);
    }
}

// ========== Header text and logo (same as OPAC) ==========
$displayHeaderText = !empty($settings['opac_header_text']) ? $settings['opac_header_text'] : ($institution['name'] ?? 'Library System');
$displayTagline = $settings['opac_tagline'] ?? __('find_books_ebooks_databases');

// ==================== RELIABLE HEADER LOGO URL FUNCTION (same as OPAC index.php) ====================
function getHeaderLogoUrl() {
    global $settings, $institution;
    
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        if (defined('BASE_URL') && BASE_URL) {
            return rtrim(BASE_URL, '/') . '/' . $cleanPath;
        }
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    
    $logoKeys = ['opac_header_logo', 'library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) {
                return $url;
            }
        }
    }
    
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) {
            return $url;
        }
    }
    
    $fallbackFiles = ['uploads/logo.png', 'uploads/logo.jpg', 'logo.png', 'logo.jpg'];
    foreach ($fallbackFiles as $file) {
        $fullFsPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $file;
        if (file_exists($fullFsPath)) {
            return $resolveUrl($file);
        }
    }
    
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%231e3c72\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}

$logoUrl = getHeaderLogoUrl();

// ========== Styling variables ==========
$opacPrimaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
$opacHeaderBgColor = $settings['opac_header_bg_color'] ?? '#1e3c72';
$opacBodyBg = $settings['opac_body_bg'] ?? '#f0f2f5';
$fontFamily = $settings['opac_font_family'] ?? 'Inter';
$baseFontSize = $settings['opac_base_font_size'] ?? 16;
$containerMaxWidth = $settings['container_max_width'] ?? 1600;
$containerPadding = $settings['container_padding'] ?? 10;
$opacHeadingFontSize = (int)($settings['opac_heading_font_size'] ?? 32);

?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('Semantic Search') ?> - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($fontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $opacPrimaryColor ?>;
            --header-bg: <?= $opacHeaderBgColor ?>;
            --body-bg: <?= $opacBodyBg ?>;
            --container-max-width: <?= $containerMaxWidth ?>px;
            --container-padding: <?= $containerPadding ?>px;
        }
        * { font-family: '<?= $fontFamily ?>', 'Inter', sans-serif; }
        body { background: var(--body-bg); font-size: <?= $baseFontSize ?>px; }
        
        /* Header styles exactly matching OPAC */
        .header-bg {
            background: linear-gradient(135deg, var(--header-bg), #2a5298);
            color: white;
            padding: 20px 0;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .header-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1%, transparent 1%);
            background-size: 50px 50px;
            animation: shimmer 60s linear infinite;
            pointer-events: none;
        }
        @keyframes shimmer {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }
        .header-bg::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #ffd700, #ff8c00, #ffd700);
        }
        .header-container {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 20px;
            max-width: var(--container-max-width);
            margin: 0 auto;
            padding: 0 var(--container-padding);
            position: relative;
            z-index: 2;
        }
        .header-left {
            justify-self: start;
        }
        .header-left img {
            height: 70px;
            width: auto;
            max-width: 200px;
            object-fit: contain;
            background: white;
            border-radius: 12px;
            padding: 5px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            transition: transform 0.3s;
        }
        .header-left img:hover { transform: scale(1.02); }
        .header-title {
            text-align: center;
            justify-self: center;
            width: 100%;
        }
        .header-title h1 {
            font-size: <?= $opacHeadingFontSize ?>px;
            font-weight: 800;
            margin-bottom: 0.25rem;
            text-shadow: 2px 2px 6px rgba(0,0,0,0.15);
        }
        .header-title p {
            font-size: <?= round($opacHeadingFontSize * 0.4) ?>px;
            opacity: 0.95;
        }
        .header-right {
            justify-self: end;
            display: flex;
            gap: 10px;
        }
        .lang-switch {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.4);
            border-radius: 40px;
            padding: 10px 18px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            backdrop-filter: blur(5px);
        }
        .lang-switch:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.05);
            color: white;
        }
        @media (max-width: 768px) {
            .header-container {
                display: flex;
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            .header-left, .header-right {
                justify-self: auto;
            }
            .header-title h1 {
                font-size: 1.6rem !important;
            }
        }
        
        /* Search box and results styling */
        .search-container { background: white; border-radius: 60px; padding: 5px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); max-width: 800px; margin: 0 auto 30px; }
        .search-container input, .search-container select { border: none; background: transparent; font-size: 1rem; padding: 12px 20px; }
        .search-container input:focus, .search-container select:focus { outline: none; box-shadow: none; }
        .search-container button { border-radius: 50px; padding: 10px 25px; background: var(--primary-color); border: none; color: white; }
        .result-card { background: white; border-radius: 16px; margin-bottom: 20px; padding: 20px; transition: transform 0.2s; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .result-card:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .book-cover { width: 80px; height: 110px; object-fit: cover; border-radius: 8px; background: #f8f9fa; }
        .score-badge { background: #e9ecef; color: #495057; border-radius: 20px; padding: 3px 10px; font-size: 0.7rem; }
        .no-results { text-align: center; padding: 60px 20px; background: white; border-radius: 20px; }
        .chatbot-btn { position: fixed; bottom: 25px; right: 25px; width: 55px; height: 55px; background: #25D366; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; cursor: pointer; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 1000; transition: all 0.3s; border: none; }
        .chatbot-btn:hover { transform: scale(1.1); background: #128C7E; }
        .chat-window { position: fixed; bottom: 100px; right: 25px; width: 350px; height: 500px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); display: none; flex-direction: column; z-index: 1001; overflow: hidden; }
        .chat-header { background: var(--primary-color); color: white; padding: 15px; font-weight: bold; display: flex; justify-content: space-between; }
        .chat-messages { flex: 1; overflow-y: auto; padding: 15px; background: #f1f1f1; }
        .chat-input-area { display: flex; padding: 10px; border-top: 1px solid #ddd; background: white; }
        .chat-input-area input { flex: 1; border: 1px solid #ddd; border-radius: 25px; padding: 8px 15px; outline: none; }
        .chat-input-area button { background: var(--primary-color); border: none; color: white; border-radius: 25px; padding: 0 15px; margin-left: 8px; }
        .message { margin-bottom: 12px; display: flex; }
        .message.user { justify-content: flex-end; }
        .message.bot { justify-content: flex-start; }
        .message .bubble { max-width: 80%; padding: 8px 12px; border-radius: 18px; font-size: 0.85rem; }
        .message.user .bubble { background: var(--primary-color); color: white; }
        .message.bot .bubble { background: #e9ecef; color: #333; }
        @media (max-width: 768px) { .book-cover { width: 60px; height: 85px; } .search-container { border-radius: 30px; } .chat-window { width: 300px; height: 450px; right: 10px; bottom: 80px; } .chatbot-btn { width: 50px; height: 50px; font-size: 24px; bottom: 15px; right: 15px; } }
    </style>
</head>
<body>

<div class="header-bg">
    <div class="header-container">
        <div class="header-left"><img src="<?= htmlspecialchars($logoUrl) ?>" alt="Library Logo" loading="lazy"></div>
        <div class="header-title">
            <h1><?= htmlspecialchars($displayHeaderText) ?></h1>
            <p><?= htmlspecialchars($displayTagline) ?></p>
        </div>
        <div class="header-right">
            <a href="?lang=<?= $lang == 'en' ? 'ar' : 'en' ?><?= $searchQuery ? '&q=' . urlencode($searchQuery) : '' ?><?= $searchType ? '&type=' . urlencode($searchType) : '' ?>" class="lang-switch"><i class="fas fa-globe"></i> <?= $lang == 'en' ? 'عربي' : 'English' ?></a>
            <a href="index.php" class="lang-switch" style="background:#ffc107; color:#333;"><i class="fas fa-home"></i> <?= __('Back to OPAC') ?></a>
        </div>
    </div>
</div>

<div class="container" style="max-width: var(--container-max-width); padding: 0 var(--container-padding);">
    <div class="search-container">
        <form method="get" action="" class="d-flex flex-wrap align-items-center">
            <input type="text" name="q" class="flex-grow-1" placeholder="<?= __('Search by meaning, not just keywords...') ?>" value="<?= htmlspecialchars($searchQuery) ?>" autocomplete="off">
            <select name="type" class="form-select w-auto mx-2">
                <option value="semantic" <?= $searchType == 'semantic' ? 'selected' : '' ?>><?= __('Semantic (AI)') ?></option>
                <option value="keyword" <?= $searchType == 'keyword' ? 'selected' : '' ?>><?= __('Keyword (FTS)') ?></option>
            </select>
            <button type="submit"><i class="fas fa-brain"></i> <?= __('Search') ?></button>
        </form>
    </div>

    <?php if (!empty($searchQuery)): ?>
        <div class="mb-3 text-muted">
            <i class="fas fa-info-circle"></i> 
            <?php if ($useEmbeddings && $searchType == 'semantic'): ?>
                <?= __('Semantic search using AI embeddings. Results are ranked by meaning similarity.') ?>
            <?php else: ?>
                <?= __('Keyword search using full‑text index.') ?>
            <?php endif; ?>
            <?php if ($error): ?><span class="text-warning ms-2"><?= htmlspecialchars($error) ?></span><?php endif; ?>
        </div>
        
        <?php if (count($results) > 0): ?>
            <h4 class="mb-3"><?= count($results) ?> <?= __('results found') ?></h4>
            <?php foreach ($results as $item): $book = $item['book']; $score = isset($item['score']) ? round($item['score'] * 100, 1) : 0; ?>
                <div class="result-card">
                    <div class="row">
                        

<div class="col-auto">
    <?php $coverBase64 = getCoverBase64($book['cover_path'] ?? ''); ?>
    <?php if ($coverBase64): ?>
        <img src="<?= $coverBase64 ?>" class="book-cover" alt="Cover">
    <?php else: ?>
        <div class="book-cover d-flex align-items-center justify-content-center bg-light"><i class="fas fa-book fa-2x text-muted"></i></div>
    <?php endif; ?>
</div>




                        <div class="col">
                            <h5 class="mb-1"><?= htmlspecialchars($book['title']) ?></h5>
                            <p class="mb-1 text-muted small">
                                <?= htmlspecialchars($book['author'] ?? 'Unknown Author') ?> 
                                <?php if (!empty($book['year'])): ?> (<?= htmlspecialchars($book['year']) ?>)<?php endif; ?>
                            </p>
                            <p class="mb-2 small"><?= htmlspecialchars(substr($book['summary'] ?? '', 0, 200)) ?>...</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="badge bg-secondary me-1"><?= htmlspecialchars($book['category'] ?? 'Uncategorized') ?></span>
                                    <span class="badge bg-<?= ($book['available'] ?? 0) > 0 ? 'success' : 'danger' ?>">
                                        <?= ($book['available'] ?? 0) > 0 ? __('Available') : __('Not Available') ?>
                                    </span>
                                    <?php if ($searchType == 'semantic' && isset($score) && $score > 0): ?>
                                        <span class="score-badge ms-2"><i class="fas fa-chart-line"></i> <?= $score ?>% match</span>
                                    <?php endif; ?>
                                </div>
                                <a href="book_details.php?barcode=<?= urlencode($book['barcode']) ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-info-circle"></i> <?= __('View Details') ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-results">
                <i class="fas fa-search fa-4x text-muted mb-3"></i>
                <h4><?= __('No results found') ?></h4>
                <p class="text-muted"><?= __('Try different keywords or use the keyword search option.') ?></p>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="fas fa-brain fa-4x text-primary mb-3"></i>
            <h3><?= __('Semantic Search') ?></h3>
            <p class="text-muted"><?= __('Enter a phrase, question, or concept – our AI will find the most relevant books.') ?></p>
            <?php if (!$useEmbeddings): ?>
                <div class="alert alert-warning d-inline-block mt-3">
                    <i class="fas fa-exclamation-triangle"></i> <?= __('OpenAI API key not configured. Using keyword search only.') ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Chatbot Widget (same as OPAC) -->
<button class="chatbot-btn" id="chatbotToggle"><i class="fab fa-whatsapp"></i></button>
<div class="chat-window" id="chatWindow">
    <div class="chat-header"><span><i class="fas fa-robot"></i> <?= __('Library Assistant') ?></span><button class="btn-close btn-close-white" id="closeChat">&times;</button></div>
    <div class="chat-messages" id="chatMessages"><div class="message bot"><div class="bubble"><?= __('Hello! I can help you find books. Try asking about a topic or title.') ?></div></div></div>
    <div class="chat-input-area"><input type="text" id="chatInput" placeholder="<?= __('Type your question...') ?>"><button id="sendChat"><i class="fas fa-paper-plane"></i></button></div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Chatbot logic (unchanged)
    const toggleBtn = document.getElementById('chatbotToggle');
    const chatWindow = document.getElementById('chatWindow');
    const closeChat = document.getElementById('closeChat');
    const sendBtn = document.getElementById('sendChat');
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');

    toggleBtn.addEventListener('click', () => { chatWindow.style.display = 'flex'; toggleBtn.style.display = 'none'; });
    closeChat.addEventListener('click', () => { chatWindow.style.display = 'none'; toggleBtn.style.display = 'flex'; });
    function addMessage(text, isUser) {
        const div = document.createElement('div');
        div.className = `message ${isUser ? 'user' : 'bot'}`;
        div.innerHTML = `<div class="bubble">${text}</div>`;
        chatMessages.appendChild(div);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    async function sendMessage() {
        const msg = chatInput.value.trim();
        if (!msg) return;
        addMessage(msg, true);
        chatInput.value = '';
        let reply = `Try searching for "${msg}" using the semantic search box above. I'll find the most relevant books for you.`;
        setTimeout(() => addMessage(reply, false), 500);
    }
    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });
</script>
</body>
</html>