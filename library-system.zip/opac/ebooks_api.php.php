<?php
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$keyword = trim($_GET['keyword'] ?? '');
$subject = trim($_GET['subject'] ?? '');

$sql = "SELECT id, title, author, subject, description, cover_path, file_path, downloads FROM ebooks WHERE 1=1";
$params = [];

if (!empty($keyword)) {
    $sql .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR description LIKE ?)";
    $like = "%$keyword%";
    $params = [$like, $like, $like, $like];
}

if (!empty($subject) && $subject !== 'all') {
    $sql .= " AND subject = ?";
    $params[] = $subject;
}

$sql .= " ORDER BY title LIMIT 100";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$ebooks = $stmt->fetchAll();

// Add cover URL for each ebook
foreach ($ebooks as &$ebook) {
    if (!empty($ebook['cover_path']) && file_exists($ebook['cover_path'])) {
        $ebook['cover_url'] = getWebImageUrl($ebook['cover_path']);
        $ext = pathinfo($ebook['cover_path'], PATHINFO_EXTENSION);
        $ebook['cover_base64'] = 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($ebook['cover_path']));
    } else {
        $ebook['cover_url'] = '';
        $ebook['cover_base64'] = '';
    }
}

echo json_encode($ebooks);
exit;