<?php
/**
 * Visitor API Endpoint
 * Used by admin dashboard to get real-time visitor count
 * Also handles entry/exit operations for self-service kiosk
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// ==================== GET STATISTICS (for dashboard) ====================
if ($action === 'stats') {
    try {
        // Get current inside count
        $insideCount = $db->query("SELECT COUNT(*) FROM entry_exit WHERE exit_time IS NULL AND status = 'inside'")->fetchColumn();
        
        // Get today's visitors
        $todayVisitors = $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date = date('now')")->fetchColumn();
        
        // Get male/female count (if gender data available)
        $maleInside = $db->query("SELECT COUNT(*) FROM entry_exit e JOIN members m ON e.admno = m.admno WHERE e.exit_time IS NULL AND m.gender = 'Male'")->fetchColumn();
        $femaleInside = $db->query("SELECT COUNT(*) FROM entry_exit e JOIN members m ON e.admno = m.admno WHERE e.exit_time IS NULL AND m.gender = 'Female'")->fetchColumn();
        
        // Get inside by category
        $categoryStats = $db->query("SELECT m.member_category, COUNT(*) as count 
                                     FROM entry_exit e 
                                     JOIN members m ON e.admno = m.admno 
                                     WHERE e.exit_time IS NULL 
                                     GROUP BY m.member_category 
                                     ORDER BY count DESC")->fetchAll();
        
        echo json_encode([
            'success' => true,
            'insideCount' => (int)$insideCount,
            'todayVisitors' => (int)$todayVisitors,
            'maleInside' => (int)$maleInside,
            'femaleInside' => (int)$femaleInside,
            'categoryStats' => $categoryStats
        ]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'insideCount' => 0, 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== ENTRY OPERATION ====================
if ($action === 'entry' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $admno = trim($_POST['admno'] ?? '');
        $member_name = trim($_POST['member_name'] ?? '');
        $member_category = trim($_POST['member_category'] ?? '');
        $purpose = trim($_POST['purpose'] ?? '');
        
        if (empty($admno) || empty($member_name)) {
            echo json_encode(['success' => false, 'message' => 'Member ID and Name are required']);
            exit;
        }
        
        // Check if already inside
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM entry_exit WHERE admno = ? AND exit_time IS NULL AND status = 'inside'");
        $checkStmt->execute([$admno]);
        if ($checkStmt->fetchColumn() > 0) {
            echo json_encode(['success' => false, 'message' => 'Member is already inside the library']);
            exit;
        }
        
        $stmt = $db->prepare("INSERT INTO entry_exit (admno, member_name, member_category, entry_date, entry_time, purpose, status, created_at) 
                              VALUES (?, ?, ?, date('now'), time('now'), ?, 'inside', datetime('now'))");
        $stmt->execute([$admno, $member_name, $member_category, $purpose]);
        
        echo json_encode(['success' => true, 'message' => 'Entry recorded successfully']);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        exit;
    }
}

// ==================== EXIT OPERATION ====================
if ($action === 'exit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $admno = trim($_POST['admno'] ?? '');
        
        if (empty($admno)) {
            echo json_encode(['success' => false, 'message' => 'Member ID is required']);
            exit;
        }
        
        $stmt = $db->prepare("UPDATE entry_exit 
                              SET exit_time = time('now'), status = 'exited' 
                              WHERE admno = ? AND exit_time IS NULL AND status = 'inside'");
        $stmt->execute([$admno]);
        
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Exit recorded successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No active entry found for this member']);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        exit;
    }
}

// ==================== SEARCH MEMBER (for kiosk) ====================
if ($action === 'search' && isset($_GET['q'])) {
    try {
        $query = trim($_GET['q']) . '%';
        $stmt = $db->prepare("SELECT admno, name, member_category FROM members WHERE status = 'active' AND (admno LIKE ? OR name LIKE ?) LIMIT 10");
        $stmt->execute([$query, $query]);
        $members = $stmt->fetchAll();
        echo json_encode(['success' => true, 'members' => $members]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'members' => []]);
        exit;
    }
}

// ==================== GET MEMBER DETAILS ====================
if ($action === 'get_member' && isset($_GET['admno'])) {
    try {
        $admno = trim($_GET['admno']);
        $stmt = $db->prepare("SELECT admno, name, member_category, phone, email FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch();
        if ($member) {
            echo json_encode(['success' => true, 'member' => $member]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Member not found']);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error']);
        exit;
    }
}

// ==================== DEFAULT RESPONSE ====================
echo json_encode(['success' => false, 'message' => 'Invalid action']);
?>