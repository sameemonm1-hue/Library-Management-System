<?php
/**
 * Visitor API Endpoint - Unified Update
 * Version: 2.0
 * 
 * Features:
 * - Real-time visitor count for dashboard
 * - Entry/Exit operations for self-service kiosk
 * - Member search and validation
 * - Advanced statistics with categories and trends
 * - Activity logging for audit trail
 * - Comprehensive error handling
 * - Support for visitor purpose, guest entries, and more
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Set JSON header
header('Content-Type: application/json');

// Ensure only POST/GET as needed
$db = getDB();
$settings = getSettings();
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// ==================== VALIDATE ACTION ====================
if (empty($action)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Action parameter is required']);
    exit;
}

// ==================== GET STATISTICS (for dashboard) ====================
if ($action === 'stats') {
    try {
        // Get current inside count (active visitors)
        $insideCount = $db->query("SELECT COUNT(*) FROM entry_exit WHERE exit_time IS NULL AND status = 'inside'")->fetchColumn();
        
        // Today's visitors (total entries today)
        $todayVisitors = $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date = date('now')")->fetchColumn();
        
        // Today's unique members
        $todayUnique = $db->query("SELECT COUNT(DISTINCT admno) FROM entry_exit WHERE entry_date = date('now')")->fetchColumn();
        
        // Current inside by gender (if gender data available)
        $maleInside = $db->query("SELECT COUNT(*) FROM entry_exit e 
                                  LEFT JOIN members m ON e.admno = m.admno 
                                  WHERE e.exit_time IS NULL AND m.gender = 'Male'")->fetchColumn();
        $femaleInside = $db->query("SELECT COUNT(*) FROM entry_exit e 
                                    LEFT JOIN members m ON e.admno = m.admno 
                                    WHERE e.exit_time IS NULL AND m.gender = 'Female'")->fetchColumn();
        
        // Inside by category
        $categoryStats = $db->query("SELECT 
                                        COALESCE(m.member_category, 'Guest') as category, 
                                        COUNT(*) as count 
                                     FROM entry_exit e 
                                     LEFT JOIN members m ON e.admno = m.admno 
                                     WHERE e.exit_time IS NULL 
                                     GROUP BY category 
                                     ORDER BY count DESC")->fetchAll();
        
        // Recent entries (last 10)
        $recentEntries = $db->query("SELECT 
                                        e.id, e.admno, e.member_name, e.member_category, 
                                        e.entry_date, e.entry_time, e.purpose, e.status,
                                        m.photo_path
                                     FROM entry_exit e 
                                     LEFT JOIN members m ON e.admno = m.admno 
                                     WHERE e.exit_time IS NULL 
                                     ORDER BY e.entry_date DESC, e.entry_time DESC 
                                     LIMIT 10")->fetchAll();
        
        // Peak hour today (hour with most entries)
        $peakHour = $db->query("SELECT 
                                   strftime('%H', entry_time) as hour, 
                                   COUNT(*) as count 
                                FROM entry_exit 
                                WHERE entry_date = date('now') 
                                GROUP BY hour 
                                ORDER BY count DESC 
                                LIMIT 1")->fetch();
        
        // Today's total time inside (average minutes per visitor)
        $avgTime = $db->query("SELECT 
                                   AVG((strftime('%s', exit_time) - strftime('%s', entry_time)) / 60) as avg_minutes 
                                FROM entry_exit 
                                WHERE entry_date = date('now') AND exit_time IS NOT NULL")->fetchColumn();
        
        // Total visitors all time
        $totalAllTime = $db->query("SELECT COUNT(*) FROM entry_exit")->fetchColumn();
        
        // Most frequent visitors (top 5)
        $topVisitors = $db->query("SELECT 
                                      admno, member_name, COUNT(*) as visits 
                                   FROM entry_exit 
                                   WHERE entry_date >= date('now', '-30 days')
                                   GROUP BY admno, member_name 
                                   ORDER BY visits DESC 
                                   LIMIT 5")->fetchAll();
        
        echo json_encode([
            'success' => true,
            'insideCount' => (int)$insideCount,
            'todayVisitors' => (int)$todayVisitors,
            'todayUnique' => (int)$todayUnique,
            'maleInside' => (int)$maleInside,
            'femaleInside' => (int)$femaleInside,
            'categoryStats' => $categoryStats,
            'recentEntries' => $recentEntries,
            'peakHour' => $peakHour ? ['hour' => $peakHour['hour'], 'count' => $peakHour['count']] : null,
            'avgTimeMinutes' => round($avgTime ?: 0, 1),
            'totalAllTime' => (int)$totalAllTime,
            'topVisitors' => $topVisitors
        ]);
        exit;
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== ENTRY OPERATION ====================
if ($action === 'entry' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate required fields
        $admno = trim($_POST['admno'] ?? '');
        $member_name = trim($_POST['member_name'] ?? '');
        $member_category = trim($_POST['member_category'] ?? 'Guest');
        $purpose = trim($_POST['purpose'] ?? '');
        $is_guest = isset($_POST['is_guest']) ? (int)$_POST['is_guest'] : 0;
        
        if (empty($admno)) {
            throw new Exception('Member ID is required');
        }
        if (empty($member_name)) {
            throw new Exception('Member name is required');
        }
        
        // Check if member is already inside
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM entry_exit WHERE admno = ? AND exit_time IS NULL AND status = 'inside'");
        $checkStmt->execute([$admno]);
        if ($checkStmt->fetchColumn() > 0) {
            throw new Exception('Member is already inside the library');
        }
        
        // Insert entry
        $stmt = $db->prepare("INSERT INTO entry_exit 
                              (admno, member_name, member_category, entry_date, entry_time, purpose, status, is_guest, created_at) 
                              VALUES (?, ?, ?, date('now'), time('now'), ?, 'inside', ?, datetime('now'))");
        $stmt->execute([$admno, $member_name, $member_category, $purpose, $is_guest]);
        $entryId = $db->lastInsertId();
        
        // Log activity
        logActivity($_SESSION['username'] ?? 'kiosk', 'VISITOR_ENTRY', "Visitor entry: $admno ($member_name)");
        
        echo json_encode([
            'success' => true, 
            'message' => 'Entry recorded successfully',
            'entry_id' => $entryId,
            'admno' => $admno,
            'member_name' => $member_name,
            'entry_time' => date('H:i:s'),
            'entry_date' => date('Y-m-d')
        ]);
        exit;
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// ==================== EXIT OPERATION ====================
if ($action === 'exit' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $admno = trim($_POST['admno'] ?? '');
        
        if (empty($admno)) {
            throw new Exception('Member ID is required');
        }
        
        // Get the entry record to log details
        $entryStmt = $db->prepare("SELECT id, member_name FROM entry_exit WHERE admno = ? AND exit_time IS NULL AND status = 'inside' ORDER BY entry_date DESC, entry_time DESC LIMIT 1");
        $entryStmt->execute([$admno]);
        $entry = $entryStmt->fetch();
        
        if (!$entry) {
            throw new Exception('No active entry found for this member');
        }
        
        // Update exit
        $stmt = $db->prepare("UPDATE entry_exit 
                              SET exit_time = time('now'), status = 'exited' 
                              WHERE id = ?");
        $stmt->execute([$entry['id']]);
        
        if ($stmt->rowCount() > 0) {
            // Log activity
            logActivity($_SESSION['username'] ?? 'kiosk', 'VISITOR_EXIT', "Visitor exit: $admno ({$entry['member_name']})");
            
            echo json_encode([
                'success' => true,
                'message' => 'Exit recorded successfully',
                'admno' => $admno,
                'member_name' => $entry['member_name'],
                'exit_time' => date('H:i:s')
            ]);
        } else {
            throw new Exception('Failed to update exit');
        }
        exit;
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// ==================== SEARCH MEMBER (for kiosk) ====================
if ($action === 'search' && isset($_GET['q'])) {
    try {
        $query = trim($_GET['q']);
        if (strlen($query) < 2) {
            echo json_encode(['success' => true, 'members' => []]);
            exit;
        }
        
        $searchTerm = '%' . $query . '%';
        $stmt = $db->prepare("SELECT admno, name, member_category, phone, email, status 
                              FROM members 
                              WHERE status = 'active' AND (admno LIKE ? OR name LIKE ?) 
                              LIMIT 15");
        $stmt->execute([$searchTerm, $searchTerm]);
        $members = $stmt->fetchAll();
        
        // Check if any are currently inside
        $insideMap = [];
        if (!empty($members)) {
            $admnos = array_column($members, 'admno');
            $placeholders = implode(',', array_fill(0, count($admnos), '?'));
            $insideStmt = $db->prepare("SELECT admno FROM entry_exit WHERE admno IN ($placeholders) AND exit_time IS NULL AND status = 'inside'");
            $insideStmt->execute($admnos);
            $insideAdmnos = $insideStmt->fetchAll(PDO::FETCH_COLUMN);
            $insideMap = array_flip($insideAdmnos);
        }
        
        // Add inside status
        foreach ($members as &$member) {
            $member['is_inside'] = isset($insideMap[$member['admno']]);
        }
        
        echo json_encode(['success' => true, 'members' => $members]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'members' => [], 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== GET MEMBER DETAILS ====================
if ($action === 'get_member' && isset($_GET['admno'])) {
    try {
        $admno = trim($_GET['admno']);
        $stmt = $db->prepare("SELECT admno, name, member_category, phone, email, photo_path, status 
                              FROM members WHERE admno = ?");
        $stmt->execute([$admno]);
        $member = $stmt->fetch();
        
        if ($member) {
            // Check if inside
            $insideStmt = $db->prepare("SELECT COUNT(*) FROM entry_exit WHERE admno = ? AND exit_time IS NULL AND status = 'inside'");
            $insideStmt->execute([$admno]);
            $member['is_inside'] = $insideStmt->fetchColumn() > 0;
            
            echo json_encode(['success' => true, 'member' => $member]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Member not found']);
        }
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error']);
        exit;
    }
}

// ==================== RECENT ACTIVITY (for kiosk or dashboard) ====================
if ($action === 'recent') {
    try {
        $limit = isset($_GET['limit']) ? min((int)$_GET['limit'], 50) : 20;
        $stmt = $db->prepare("SELECT 
                                  e.id, e.admno, e.member_name, e.member_category, 
                                  e.entry_date, e.entry_time, e.exit_time, e.purpose, e.status,
                                  m.photo_path,
                                  CASE 
                                      WHEN e.exit_time IS NOT NULL THEN 'exited'
                                      ELSE 'inside'
                                  END as current_status
                               FROM entry_exit e
                               LEFT JOIN members m ON e.admno = m.admno
                               ORDER BY e.entry_date DESC, e.entry_time DESC
                               LIMIT ?");
        $stmt->execute([$limit]);
        $entries = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'entries' => $entries]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== TODAY'S INSIDE LIST ====================
if ($action === 'inside_list') {
    try {
        $stmt = $db->query("SELECT 
                               e.id, e.admno, e.member_name, e.member_category, 
                               e.entry_date, e.entry_time, e.purpose,
                               m.photo_path
                            FROM entry_exit e
                            LEFT JOIN members m ON e.admno = m.admno
                            WHERE e.exit_time IS NULL AND e.status = 'inside'
                            ORDER BY e.entry_time DESC");
        $inside = $stmt->fetchAll();
        
        echo json_encode(['success' => true, 'inside' => $inside]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== CLEAR STALE ENTRIES (auto cleanup) ====================
if ($action === 'cleanup' && isset($_GET['token']) && $_GET['token'] === 'internal_cleanup') {
    try {
        // Remove entries older than 7 days that are still marked as 'inside' (stale)
        $stmt = $db->prepare("UPDATE entry_exit 
                              SET exit_time = time('now'), status = 'exited' 
                              WHERE exit_time IS NULL 
                              AND status = 'inside' 
                              AND entry_date < date('now', '-7 days')");
        $stmt->execute();
        $count = $stmt->rowCount();
        
        echo json_encode(['success' => true, 'cleaned' => $count]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

// ==================== DEFAULT RESPONSE ====================
http_response_code(400);
echo json_encode(['success' => false, 'message' => 'Invalid action or missing parameters']);
exit;
?>
