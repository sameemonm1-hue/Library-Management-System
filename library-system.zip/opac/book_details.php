<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$barcode = isset($_GET['barcode']) ? trim($_GET['barcode']) : '';

if ($id === 0 && empty($barcode)) {
    echo json_encode(['error' => 'No book identifier provided (id or barcode required)']);
    exit;
}

try {
    if ($id > 0) {
        $stmt = $db->prepare("SELECT * FROM books WHERE id = ? AND status != 'Deleted'");
        $stmt->execute([$id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ? AND status != 'Deleted'");
        $stmt->execute([$barcode]);
    }
    
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        echo json_encode(['error' => 'Book not found']);
        exit;
    }
    
    $book['available'] = (int)$book['available'];
    $book['cover_base64'] = getCoverBase64($book['cover_path'] ?? '');
    
    $book['author']    = $book['author'] ?? '';
    $book['publisher'] = $book['publisher'] ?? '';
    $book['isbn']      = $book['isbn'] ?? '';
    $book['category']  = $book['category'] ?? '';
    $book['year']      = $book['year'] ?? '';
    $book['summary']   = $book['summary'] ?? '';
    
    echo json_encode($book);
    
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>