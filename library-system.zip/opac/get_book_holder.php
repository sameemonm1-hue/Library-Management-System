<?php
session_start();
require_once '../config/db.php';
require_once '../config/functions.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

try {
    $book_id = isset($_GET['book_id']) ? (int)$_GET['book_id'] : 0;
    if (!$book_id) {
        throw new Exception('Invalid book ID');
    }

    $db = getDB();

    // Get book barcode
    $bookStmt = $db->prepare("SELECT barcode FROM books WHERE id = ?");
    $bookStmt->execute([$book_id]);
    $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
    if (!$book) {
        throw new Exception('Book not found');
    }
    $barcode = $book['barcode'];

    // Query circulation table for active loan
    $stmt = $db->prepare("
        SELECT 
            c.issue_date, 
            c.due_date, 
            COALESCE(c.renew_count, 0) as renew_count,
            m.id as member_id, 
            m.admno, 
            m.name, 
            m.email, 
            m.phone as mobile,
            m.photo_path,
            '' as class_section,
            '' as department,
            '' as employee_id
        FROM circulation c
        INNER JOIN members m ON c.admno = m.admno
        WHERE c.barcode = ? AND c.return_date IS NULL
        ORDER BY c.issue_date DESC
        LIMIT 1
    ");
    $stmt->execute([$barcode]);
    $loan = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$loan) {
        throw new Exception('Book is currently available, no holder.');
    }

    // Date calculations
    $due = new DateTime($loan['due_date']);
    $now = new DateTime();
    $diff = $now->diff($due);
    $daysRemaining = $due > $now ? $diff->days : -$diff->days;
    $isOverdue = $due < $now;

    // Process photo – use absolute path with BASE_PATH
    $photoBase64 = '';
    if (!empty($loan['photo_path'])) {
        $absolutePhotoPath = BASE_PATH . '/' . ltrim($loan['photo_path'], '/');
        if (file_exists($absolutePhotoPath)) {
            $ext = strtolower(pathinfo($absolutePhotoPath, PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $data = @file_get_contents($absolutePhotoPath);
                if ($data !== false) {
                    $photoBase64 = 'data:image/' . $ext . ';base64,' . base64_encode($data);
                }
            }
        }
    }

    $response = [
        'success' => true,
        'member' => [
            'photo' => $photoBase64,
            'name' => htmlspecialchars($loan['name']),
            'member_id' => htmlspecialchars($loan['admno']),
            'employee_id' => '',
            'class_section' => '',
            'department' => '',
            'mobile' => htmlspecialchars($loan['mobile']),
            'email' => htmlspecialchars($loan['email'] ?? ''),
            'issue_date' => date('d-M-Y', strtotime($loan['issue_date'])),
            'due_date' => date('d-M-Y', strtotime($loan['due_date'])),
            'renewals' => (int)$loan['renew_count'],
            'days_remaining' => $isOverdue ? -$daysRemaining : $daysRemaining,
            'is_overdue' => $isOverdue
        ]
    ];
    echo json_encode($response);
    exit;

} catch (Exception $e) {
    error_log("WHOM Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
    exit;
}
?>