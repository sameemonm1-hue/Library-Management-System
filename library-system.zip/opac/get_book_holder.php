<?php
/**
 * get_book_holder.php
 * Fetches member details for a book holder (WHOM feature)
 * Version: 2.4 - Fixed column names and optimized performance
 */

session_start();
require_once '../config/db.php';
require_once '../config/functions.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

try {
    // Check if user is logged in (member or admin)
    $isLoggedIn = isset($_SESSION['member_id']) || isset($_SESSION['user_id']);
    if (!$isLoggedIn) {
        echo json_encode([
            'success' => false,
            'error' => 'Please login to view this information'
        ]);
        exit;
    }

    $book_id = isset($_GET['book_id']) ? (int)$_GET['book_id'] : 0;
    if ($book_id <= 0) {
        echo json_encode([
            'success' => false,
            'error' => 'Invalid book ID'
        ]);
        exit;
    }

    $db = getDB();

    // Get book details
    $bookStmt = $db->prepare("SELECT id, barcode, title, available FROM books WHERE id = ?");
    $bookStmt->execute([$book_id]);
    $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        echo json_encode([
            'success' => false,
            'error' => 'Book not found'
        ]);
        exit;
    }

    // If book is available, no holder
    if ($book['available'] > 0) {
        echo json_encode([
            'success' => true,
            'available' => true,
            'message' => 'Book is currently available. No holder.'
        ]);
        exit;
    }

    $barcode = $book['barcode'];

    // Get member columns dynamically
    $colStmt = $db->query("PRAGMA table_info(members)");
    $memberCols = $colStmt->fetchAll(PDO::FETCH_COLUMN, 1);

    // Build the SELECT query with correct column names
    $selectFields = [
        'c.admno',
        'c.member_name',
        'c.issue_date',
        'c.due_date',
        'COALESCE(c.renew_count, 0) as renew_count'
    ];

    // Check for photo column (members table uses 'photo_path' not 'photo')
    if (in_array('photo_path', $memberCols)) {
        $selectFields[] = 'm.photo_path';
    } elseif (in_array('photo', $memberCols)) {
        $selectFields[] = 'm.photo as photo_path';
    } else {
        $selectFields[] = "'' as photo_path";
    }

    // Check for name column
    if (in_array('name', $memberCols)) {
        $selectFields[] = 'm.name';
    } else {
        $selectFields[] = "'' as name";
    }

    // Check for phone column
    if (in_array('phone', $memberCols)) {
        $selectFields[] = 'm.phone';
    } else {
        $selectFields[] = "'' as phone";
    }

    // Check for email column
    if (in_array('email', $memberCols)) {
        $selectFields[] = 'm.email';
    } else {
        $selectFields[] = "'' as email";
    }

    // Check for class column
    if (in_array('class', $memberCols)) {
        $selectFields[] = 'm.class';
    } else {
        $selectFields[] = "'' as class";
    }

    // Check for division column
    if (in_array('division', $memberCols)) {
        $selectFields[] = 'm.division';
    } else {
        $selectFields[] = "'' as division";
    }

    // Check for designation column
    if (in_array('designation', $memberCols)) {
        $selectFields[] = 'm.designation';
    } else {
        $selectFields[] = "'' as designation";
    }

    // Check for general_id column
    if (in_array('general_id', $memberCols)) {
        $selectFields[] = 'm.general_id as employee_id';
    } else {
        $selectFields[] = "'' as employee_id";
    }

    // Check for member_category column
    if (in_array('member_category', $memberCols)) {
        $selectFields[] = 'm.member_category';
    } else {
        $selectFields[] = "'' as member_category";
    }

    // Check for member id
    if (in_array('id', $memberCols)) {
        $selectFields[] = 'm.id as member_id';
    } else {
        $selectFields[] = '0 as member_id';
    }

    $selectSQL = "SELECT " . implode(", ", $selectFields) . " 
                  FROM circulation c 
                  LEFT JOIN members m ON c.admno = m.admno 
                  WHERE c.barcode = ? AND c.return_date IS NULL 
                  ORDER BY c.issue_date DESC 
                  LIMIT 1";
    
    $stmt = $db->prepare($selectSQL);
    $stmt->execute([$barcode]);
    $loan = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$loan) {
        echo json_encode([
            'success' => true,
            'available' => true,
            'message' => 'Book is currently available. No holder found.'
        ]);
        exit;
    }

    // Use member_name from circulation if member not found
    $memberName = !empty($loan['name']) ? $loan['name'] : ($loan['member_name'] ?? 'Unknown Member');

    // Date calculations
    try {
        $due = new DateTime($loan['due_date']);
        $now = new DateTime();
        $diff = $now->diff($due);
        $daysRemaining = $due > $now ? $diff->days : -$diff->days;
        $isOverdue = $due < $now;
    } catch (Exception $e) {
        $daysRemaining = 0;
        $isOverdue = false;
    }

    // Process photo
    $photoBase64 = '';
    $photoPath = $loan['photo_path'] ?? '';
    
    if (!empty($photoPath) && file_exists($photoPath)) {
        $ext = strtolower(pathinfo($photoPath, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($ext, $allowed)) {
            $data = @file_get_contents($photoPath);
            if ($data !== false) {
                $photoBase64 = 'data:image/' . $ext . ';base64,' . base64_encode($data);
            }
        }
    }

    // Try alternative paths if photo not found
    if (empty($photoBase64) && !empty($photoPath)) {
        $altPaths = [
            BASE_PATH . '/' . ltrim($photoPath, '/'),
            BASE_PATH . '/uploads/member_photos/' . basename($photoPath),
            BASE_PATH . '/uploads/members/' . basename($photoPath),
            BASE_PATH . '/uploads/' . ltrim($photoPath, '/')
        ];
        foreach ($altPaths as $path) {
            if (file_exists($path)) {
                $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($ext, $allowed)) {
                    $data = @file_get_contents($path);
                    if ($data !== false) {
                        $photoBase64 = 'data:image/' . $ext . ';base64,' . base64_encode($data);
                        break;
                    }
                }
            }
        }
    }

    // Build class/section string
    $classSection = '';
    if (!empty($loan['class'])) {
        $classSection = $loan['class'];
        if (!empty($loan['division'])) {
            $classSection .= ' ' . $loan['division'];
        }
    }

    // Department
    $department = !empty($loan['designation']) ? $loan['designation'] : ($loan['member_category'] ?? '');

    $response = [
        'success' => true,
        'member' => [
            'photo' => $photoBase64,
            'name' => htmlspecialchars($memberName),
            'member_id' => htmlspecialchars($loan['admno'] ?? 'N/A'),
            'employee_id' => htmlspecialchars($loan['employee_id'] ?? ''),
            'class_section' => htmlspecialchars($classSection),
            'department' => htmlspecialchars($department),
            'mobile' => htmlspecialchars($loan['phone'] ?? 'N/A'),
            'email' => htmlspecialchars($loan['email'] ?? ''),
            'issue_date' => isset($loan['issue_date']) ? date('d-M-Y', strtotime($loan['issue_date'])) : 'N/A',
            'due_date' => isset($loan['due_date']) ? date('d-M-Y', strtotime($loan['due_date'])) : 'N/A',
            'renewals' => (int)($loan['renew_count'] ?? 0),
            'days_remaining' => $daysRemaining,
            'is_overdue' => $isOverdue
        ]
    ];
    
    echo json_encode($response);
    exit;

} catch (PDOException $e) {
    error_log("WHOM Database Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
    exit;
} catch (Exception $e) {
    error_log("WHOM Error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
    exit;
}
?>