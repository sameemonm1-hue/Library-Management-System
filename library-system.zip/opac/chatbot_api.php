<?php
/**
 * AI Chatbot API – RAG + LLM
 * 
 * Endpoint: POST /opac/chatbot_api.php
 * 
 * Input (JSON):
 * {
 *   "message": "How do I renew a book?",
 *   "session_id": "optional-session-id",
 *   "conversation_history": [] // optional, for context
 * }
 * 
 * Output:
 * {
 *   "success": true,
 *   "answer": "You can renew books online by logging into your account...",
 *   "sources": ["FAQ: How do I renew a book?", "Book: The Library Book"],
 *   "confidence": 0.95
 * }
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../includes/AIEmbedding.php';

header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// ==================== GET INPUT ====================
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
    exit;
}

$message = trim($input['message'] ?? '');
$sessionId = $input['session_id'] ?? session_id();
$history = $input['conversation_history'] ?? []; // optional

if (empty($message)) {
    echo json_encode(['success' => false, 'error' => 'Message is required']);
    exit;
}

// ==================== DATABASE ====================
$db = getDB();
$settings = getSettings();

// ==================== RAG: RETRIEVE RELEVANT CONTENT ====================
// Get embedding for user message
AIEmbedding::init();
$queryEmbedding = AIEmbedding::getEmbedding($message);
$useRag = true;
$retrieved = []; // array of ['type', 'title', 'content', 'score', 'id']

// If embedding is available, perform semantic search
if ($queryEmbedding !== null) {
    // 1. Search FAQ table (using embeddings if available, else fallback to keywords)
    $faqs = [];
    $faqStmt = $db->query("SELECT id, question, answer FROM faq WHERE is_active = 1");
    $allFaqs = $faqStmt->fetchAll();
    
    if (!empty($allFaqs)) {
        // Check if FAQ table has embedding column
        $faqCols = $db->query("PRAGMA table_info(faq)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (in_array('embedding', $faqCols)) {
            // Use embeddings for FAQ
            $faqWithEmbed = [];
            foreach ($allFaqs as $faq) {
                if (!empty($faq['embedding'])) {
                    $faqEmbed = json_decode($faq['embedding'], true);
                    if ($faqEmbed) {
                        $similarity = AIEmbedding::cosineSimilarity($queryEmbedding, $faqEmbed);
                        $faqWithEmbed[] = [
                            'id' => $faq['id'],
                            'question' => $faq['question'],
                            'answer' => $faq['answer'],
                            'similarity' => $similarity
                        ];
                    }
                }
            }
            usort($faqWithEmbed, fn($a, $b) => $b['similarity'] <=> $a['similarity']);
            $faqs = array_slice($faqWithEmbed, 0, 3);
        } else {
            // Fallback to keyword search (simple)
            foreach ($allFaqs as $faq) {
                $similarity = 0;
                $words = explode(' ', strtolower($message));
                $question = strtolower($faq['question']);
                foreach ($words as $word) {
                    if (strlen($word) > 2 && strpos($question, $word) !== false) {
                        $similarity += 0.2;
                    }
                }
                if ($similarity > 0) {
                    $faqs[] = [
                        'id' => $faq['id'],
                        'question' => $faq['question'],
                        'answer' => $faq['answer'],
                        'similarity' => min($similarity, 1)
                    ];
                }
            }
            usort($faqs, fn($a, $b) => $b['similarity'] <=> $a['similarity']);
            $faqs = array_slice($faqs, 0, 3);
        }
        
        foreach ($faqs as $f) {
            $retrieved[] = [
                'type' => 'faq',
                'title' => $f['question'],
                'content' => $f['answer'],
                'score' => $f['similarity'] ?? 0.5,
                'id' => $f['id']
            ];
        }
    }
    
    // 2. Search books (titles, summaries) – limit to top 5
    $bookStmt = $db->prepare("SELECT id, title, author, summary FROM books WHERE status != 'Deleted' AND embedding IS NOT NULL LIMIT 1000");
    $bookStmt->execute();
    $books = $bookStmt->fetchAll();
    $bookMatches = [];
    foreach ($books as $book) {
        if (!empty($book['embedding'])) {
            $embed = json_decode($book['embedding'], true);
            if ($embed) {
                $similarity = AIEmbedding::cosineSimilarity($queryEmbedding, $embed);
                if ($similarity > 0.4) {
                    $bookMatches[] = [
                        'id' => $book['id'],
                        'title' => $book['title'],
                        'author' => $book['author'],
                        'summary' => $book['summary'],
                        'similarity' => $similarity
                    ];
                }
            }
        }
    }
    usort($bookMatches, fn($a, $b) => $b['similarity'] <=> $a['similarity']);
    $bookMatches = array_slice($bookMatches, 0, 3);
    
    foreach ($bookMatches as $b) {
        $content = "Title: {$b['title']}";
        if ($b['author']) $content .= " by {$b['author']}";
        if ($b['summary']) $content .= ". Summary: " . substr($b['summary'], 0, 200);
        $retrieved[] = [
            'type' => 'book',
            'title' => $b['title'],
            'content' => $content,
            'score' => $b['similarity'],
            'id' => $b['id']
        ];
    }
} else {
    // Fallback: simple keyword search if embeddings unavailable
    $useRag = false;
    $like = "%$message%";
    $stmt = $db->prepare("SELECT question, answer FROM faq WHERE question LIKE ? OR answer LIKE ? LIMIT 3");
    $stmt->execute([$like, $like]);
    $faqs = $stmt->fetchAll();
    foreach ($faqs as $f) {
        $retrieved[] = [
            'type' => 'faq',
            'title' => $f['question'],
            'content' => $f['answer'],
            'score' => 0.5
        ];
    }
}

// ==================== BUILD CONTEXT FOR LLM ====================
$context = "You are a helpful library assistant. Answer the user's question using the provided context.\n\n";
if (empty($retrieved)) {
    $context .= "No specific context found. Answer generally based on library policies (hours, renewals, holds, fines, membership).\n";
} else {
    $context .= "Relevant information:\n";
    foreach ($retrieved as $i => $item) {
        $context .= ($i+1) . ". [{$item['type']}] {$item['title']}\n   {$item['content']}\n\n";
    }
}
$context .= "User question: $message\n\nAssistant: ";

// ==================== GENERATE RESPONSE VIA LLM ====================
$llmProvider = $settings['llm_provider'] ?? 'ollama'; // 'ollama' or 'huggingface'
$answer = "";
$sourceUsed = [];

if ($llmProvider === 'ollama') {
    $ollamaUrl = $settings['ollama_url'] ?? 'http://localhost:11434';
    $ollamaModel = $settings['ollama_model'] ?? 'llama2';
    
    $ch = curl_init("$ollamaUrl/api/generate");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'model' => $ollamaModel,
        'prompt' => $context,
        'stream' => false
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        $answer = trim($data['response'] ?? '');
    } else {
        $answer = "I'm sorry, I'm having trouble connecting to the AI service. Please try again later.";
    }
} elseif ($llmProvider === 'huggingface') {
    $apiKey = $settings['hf_api_key'] ?? '';
    $hfModel = $settings['hf_model'] ?? 'HuggingFaceH4/zephyr-7b-beta';
    
    if (empty($apiKey)) {
        $answer = "Hugging Face API key not configured. Please contact library administrator.";
    } else {
        $ch = curl_init("https://api-inference.huggingface.co/models/$hfModel");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            'inputs' => $context,
            'parameters' => ['max_new_tokens' => 250, 'temperature' => 0.7]
        ]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $response) {
            $data = json_decode($response, true);
            $answer = trim($data[0]['generated_text'] ?? '');
            // Remove the input prompt from the response if present
            $answer = str_replace($context, '', $answer);
        } else {
            $answer = "I'm sorry, I couldn't generate a response. Please try again later.";
        }
    }
} else {
    // Fallback to simple keyword-based answers (no LLM)
    $answer = "I'm a simple assistant. For detailed answers, please contact the library staff.";
}

// Clean up answer (remove extra whitespace)
$answer = preg_replace('/\s+/', ' ', $answer);
$answer = trim($answer);

// ==================== PREPARE SOURCES FOR OUTPUT ====================
$sourceUsed = [];
foreach ($retrieved as $item) {
    $sourceUsed[] = $item['type'] . ': ' . $item['title'];
}
$sourceUsed = array_slice(array_unique($sourceUsed), 0, 3);

// ==================== RETURN JSON ====================
echo json_encode([
    'success' => true,
    'answer' => $answer,
    'sources' => $sourceUsed,
    'rag_used' => $useRag,
    'confidence' => !empty($retrieved) ? $retrieved[0]['score'] : 0.5
], JSON_UNESCAPED_UNICODE);