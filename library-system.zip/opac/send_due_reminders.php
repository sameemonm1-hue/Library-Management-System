#!/usr/bin/env php
<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();

// Get loans due in 2 days
$stmt = $db->prepare("
    SELECT l.id, l.due_date, m.mobile, m.name, b.title
    FROM loans l
    JOIN members m ON l.member_id = m.id
    JOIN books b ON l.book_id = b.id
    WHERE l.return_date IS NULL AND date(l.due_date) = date('now', '+2 days')
");
$stmt->execute();
$dueLoans = $stmt->fetchAll();

foreach ($dueLoans as $loan) {
    $message = "Reminder: The book '{$loan['title']}' is due on {$loan['due_date']}. Please return or renew to avoid fines.";
    addWhatsAppMessage($loan['mobile'], $message);
}

// Also handle overdue
$stmt2 = $db->prepare("
    SELECT l.id, l.due_date, m.mobile, m.name, b.title
    FROM loans l
    JOIN members m ON l.member_id = m.id
    JOIN books b ON l.book_id = b.id
    WHERE l.return_date IS NULL AND date(l.due_date) < date('now')
");
$stmt2->execute();
$overdueLoans = $stmt2->fetchAll();

foreach ($overdueLoans as $loan) {
    $message = "Overdue Alert: The book '{$loan['title']}' is overdue since {$loan['due_date']}. Please return immediately to avoid additional fines.";
    addWhatsAppMessage($loan['mobile'], $message);
}