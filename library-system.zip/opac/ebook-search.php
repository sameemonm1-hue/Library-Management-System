<?php
/**
 * OPAC - eBook Search Module
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$settings = getSettings();
$db = getDB();

$searchResults = null;
$searchKeyword = '';

if (isset($_GET['search']) && !empty($_GET['keyword'])) {
    $keyword = trim($_GET['keyword']);
    $searchKeyword = $keyword;
    
    $sql = "SELECT * FROM ebooks WHERE title LIKE ? OR author LIKE ? OR subject LIKE ? OR description LIKE ?";
    $like = "%$keyword%";
    $stmt = $db->prepare($sql);
    $stmt->execute([$like, $like, $like, $like]);
    $searchResults = $stmt->fetchAll();
}

$subjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' LIMIT 10")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eBook Search - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { font-family: 'Inter', sans-serif; }
        body { background: #f0f2f5; }
        .hero { background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 40px 0; }
        .search-card { background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-top: -30px; }
        .ebook-card { transition: all 0.3s; border-radius: 15px; overflow: hidden; }
        .ebook-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
    </style>
</head>
<body>
<div class="hero">
    <div class="container text-center">
        <?php if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])): ?>
            <img src="<?= htmlspecialchars($settings['library_logo']) ?>" style="height: 60px;" class="mb-3">
        <?php endif; ?>
        <h1 class="display-5 fw-bold">Digital eBook Collection</h1>
        <p class="lead">Search and download eBooks from our digital library</p>
        <a href="/library-system/opac/" class="btn btn-outline-light mt-2">← Back to OPAC</a>
    </div>
</div>

<div class="container">
    <div class="search-card p-4 mb-4">
        <form method="get" action="">
            <div class="row g-3">
                <div class="col-md-10">
                    <div class="input-group input-group-lg">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="keyword" class="form-control" 
                               placeholder="Search eBooks by Title, Author, Subject or Description..."
                               value="<?= htmlspecialchars($searchKeyword) ?>" required autofocus>
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" name="search" class="btn btn-danger btn-lg w-100">Search</button>
                </div>
            </div>
            <div class="text-muted mt-2 small">
                <i class="fas fa-info-circle"></i> Enter keywords to search the eBook collection. Results will appear below.
            </div>
        </form>
    </div>

    <?php if (isset($_GET['search']) && !empty($_GET['keyword'])): ?>
        <div class="mb-4">
            <h4><i class="fas fa-search"></i> Search Results for: "<?= htmlspecialchars($searchKeyword) ?>"</h4>
            <p class="text-muted">Found <?= count($searchResults ?? []) ?> eBook(s)</p>
        </div>

        <?php if (empty($searchResults)): ?>
            <div class="alert alert-info text-center p-5">
                <i class="fas fa-book-open fa-3x mb-3"></i>
                <h5>No eBooks found matching your search criteria.</h5>
                <p>Please try different keywords or browse our collection.</p>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($searchResults as $ebook): ?>
                    <?php $coverBase64 = getCoverBase64($ebook['cover_path'] ?? ''); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card ebook-card h-100">
                            <div class="card-body">
                                <div class="d-flex align-items-start mb-3">
                                    <div class="flex-shrink-0">
                                        <?php if ($coverBase64): ?>
                                            <img src="<?= $coverBase64 ?>" style="width: 60px; height: 80px; object-fit: cover; border-radius: 8px;">
                                        <?php else: ?>
                                            <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 60px; height: 80px;">
                                                <i class="fas fa-file-pdf fa-3x text-danger"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="card-title fw-bold mb-1"><?= htmlspecialchars($ebook['title']) ?></h6>
                                        <p class="card-text small text-muted mb-1">
                                            <i class="fas fa-user-edit"></i> <?= htmlspecialchars($ebook['author'] ?? 'Unknown') ?>
                                        </p>
                                        <p class="card-text small text-muted">
                                            <i class="fas fa-tag"></i> <?= htmlspecialchars($ebook['subject'] ?? 'Uncategorized') ?>
                                        </p>
                                    </div>
                                </div>
                                <p class="card-text small"><?= htmlspecialchars(substr($ebook['description'] ?? '', 0, 100)) ?>...</p>
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <small class="text-muted">
                                        <i class="fas fa-file"></i> <?= strtoupper(pathinfo($ebook['file_path'], PATHINFO_EXTENSION)) ?>
                                        | <i class="fas fa-download"></i> <?= $ebook['downloads'] ?> downloads
                                    </small>
                                    <a href="download_ebook.php?id=<?= $ebook['id'] ?>" class="btn btn-sm btn-danger download-btn">
                                        <i class="fas fa-download"></i> Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="text-center p-5 bg-light rounded mb-4">
            <i class="fas fa-search fa-4x text-muted mb-3"></i>
            <h4>Search the eBook Collection</h4>
            <p class="text-muted">Use the search box above to find digital books by title, author, or subject</p>
            <hr class="w-50 mx-auto">
            <div class="row mt-4">
                <div class="col-md-4">
                    <i class="fas fa-book fa-2x text-danger mb-2"></i>
                    <p><strong>Browse by Subject</strong></p>
                    <div class="d-flex flex-wrap gap-2 justify-content-center">
                        <?php foreach ($subjects as $s): ?>
                            <a href="?search=1&keyword=<?= urlencode($s) ?>" class="btn btn-sm btn-outline-danger"><?= htmlspecialchars($s) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <i class="fas fa-file-pdf fa-2x text-danger mb-2"></i>
                    <p><strong>PDF Format</strong></p>
                    <small>All eBooks are available in PDF format for easy reading</small>
                </div>
                <div class="col-md-4">
                    <i class="fas fa-download fa-2x text-danger mb-2"></i>
                    <p><strong>Free Downloads</strong></p>
                    <small>Download eBooks directly after search</small>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="index.php" class="text-decoration-none">
            <i class="fas fa-arrow-left"></i> Back to Book Catalog
        </a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>