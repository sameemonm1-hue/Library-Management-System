<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'my_holds' => 'My Holds',
        'book' => 'Book',
        'hold_date' => 'Hold Date',
        'expiry_date' => 'Expiry Date',
        'status' => 'Status',
        'action' => 'Action',
        'cancel' => 'Cancel',
        'no_holds' => 'No holds placed.',
        'hold_cancelled' => 'Hold cancelled.',
        'back_to_account' => 'Back to Account',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'my_holds' => 'मेरे होल्ड',
        'book' => 'पुस्तक',
        'hold_date' => 'होल्ड तिथि',
        'expiry_date' => 'समाप्ति तिथि',
        'status' => 'स्थिति',
        'action' => 'कार्रवाई',
        'cancel' => 'रद्द करें',
        'no_holds' => 'कोई होल्ड नहीं लगाया गया।',
        'hold_cancelled' => 'होल्ड रद्द कर दिया गया।',
        'back_to_account' => 'खाते पर वापस जाएं',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'my_holds' => 'حجوزاتي',
        'book' => 'الكتاب',
        'hold_date' => 'تاريخ الحجز',
        'expiry_date' => 'تاريخ الانتهاء',
        'status' => 'الحالة',
        'action' => 'إجراء',
        'cancel' => 'إلغاء',
        'no_holds' => 'لا توجد حجوزات.',
        'hold_cancelled' => 'تم إلغاء الحجز.',
        'back_to_account' => 'العودة إلى الحساب',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

$db = getDB();
if (!isset($_SESSION['member_id'])) { header('Location: login.php'); exit; }
$memberId = $_SESSION['member_id'];
$memberAdmno = $_SESSION['member_admno'] ?? null;
if (!$memberAdmno) {
    $stmt = $db->prepare("SELECT admno FROM members WHERE id = ?")->execute([$memberId])->fetch();
    $memberAdmno = $stmt['admno'];
    $_SESSION['member_admno'] = $memberAdmno;
}

if (isset($_GET['cancel'])) {
    $holdId = (int)$_GET['cancel'];
    $db->prepare("DELETE FROM book_holds WHERE id = ? AND admno = ? AND status = 'pending'")->execute([$holdId, $memberAdmno]);
    header('Location: holds.php?msg=cancelled');
    exit;
}

$holds = $db->prepare("SELECT h.*, b.title FROM book_holds h JOIN books b ON h.book_barcode = b.barcode WHERE h.admno = ? ORDER BY h.hold_date DESC");
$holds->execute([$memberAdmno]);
$holds = $holds->fetchAll();
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <title><?= __('my_holds') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><i class="fas fa-hand-paper"></i> <?= __('my_holds') ?></h2>
        <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
            </ul>
        </div>
    </div>
    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'cancelled'): ?>
        <div class="alert alert-info"><?= __('hold_cancelled') ?></div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-light"><tr><th><?= __('book') ?></th><th><?= __('hold_date') ?></th><th><?= __('expiry_date') ?></th><th><?= __('status') ?></th><th><?= __('action') ?></th></tr></thead>
            <tbody>
            <?php if (empty($holds)): ?><tr><td colspan="5" class="text-center text-muted"><?= __('no_holds') ?></td></tr>
            <?php else: foreach ($holds as $hold): ?>
            <tr>
                <td><?= htmlspecialchars($hold['title']) ?></td>
                <td><?= $hold['hold_date'] ?></td>
                <td><?= $hold['expiry_date'] ?></td>
                <td><span class="badge <?= $hold['status'] == 'pending' ? 'bg-warning' : ($hold['status'] == 'available' ? 'bg-success' : 'bg-secondary') ?>"><?= $hold['status'] ?></span></td>
                <td><?php if ($hold['status'] == 'pending'): ?><a href="?cancel=<?= $hold['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Cancel this hold?')"><?= __('cancel') ?></a><?php else: ?>—<?php endif; ?></td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <a href="account.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> <?= __('back_to_account') ?></a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>