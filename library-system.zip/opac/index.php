<?php
/**
 * OPAC - Online Public Access Catalog
 * Version: 7.6 – Visitor Counter, Enhanced UI, AM/PM Time
 * Language switcher hardcoded with three languages (EN, HI, AR).
 */
session_start();

// ==================== ERROR REPORTING ====================
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/opac_errors.log');

// ==================== PATHS ====================
define('ROOT_PATH', realpath(__DIR__ . '/..'));
require_once ROOT_PATH . '/config/db.php';
require_once ROOT_PATH . '/config/functions.php';

// ==================== CACHE DIR ====================
$cacheDir = __DIR__ . '/cache';
if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);

// ==================== VISITOR COUNTER ====================
function initVisitorTable($db) {
    $db->exec("CREATE TABLE IF NOT EXISTS visitor_counts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date DATE UNIQUE NOT NULL,
        count INTEGER DEFAULT 0,
        total INTEGER DEFAULT 0
    )");
    // also ensure total column exists (for older versions)
    $cols = $db->query("PRAGMA table_info(visitor_counts)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('total', $cols)) {
        $db->exec("ALTER TABLE visitor_counts ADD COLUMN total INTEGER DEFAULT 0");
    }
}

function getVisitorStats($db) {
    $today = date('Y-m-d');
    $stmt = $db->prepare("SELECT count, total FROM visitor_counts WHERE date = ?");
    $stmt->execute([$today]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        return ['today' => (int)$row['count'], 'total' => (int)$row['total']];
    }
    return ['today' => 0, 'total' => 0];
}

function incrementVisitor($db) {
    $today = date('Y-m-d');
    // Check if we already counted this session today
    if (isset($_SESSION['visited_today']) && $_SESSION['visited_today'] === $today) {
        return;
    }
    // Use transaction to avoid race conditions
    $db->beginTransaction();
    try {
        $stmt = $db->prepare("INSERT INTO visitor_counts (date, count, total) VALUES (?, 1, 1)
                               ON CONFLICT(date) DO UPDATE SET count = count + 1, total = total + 1");
        $stmt->execute([$today]);
        $db->commit();
        $_SESSION['visited_today'] = $today;
    } catch (Exception $e) {
        $db->rollBack();
    }
}

$db = getDB();
initVisitorTable($db);
// Increment visitor count for this request (if new)
incrementVisitor($db);
// Get stats for display
$visitorStats = getVisitorStats($db);
$visitorsToday = $visitorStats['today'];
$totalVisitors = $visitorStats['total'];

// ==================== ENSURE SERIAL COVER COLUMN ====================
function ensureSerialCoverColumn($db) {
    $cols = $db->query("PRAGMA table_info(serial_subscriptions)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('cover_path', $cols)) {
        $db->exec("ALTER TABLE serial_subscriptions ADD COLUMN cover_path TEXT DEFAULT ''");
    }
}
ensureSerialCoverColumn($db);

// ==================== COVER FUNCTION ====================
function getCoverImageSrc($coverPath) {
    if (empty($coverPath)) return '';
    if (filter_var($coverPath, FILTER_VALIDATE_URL)) return $coverPath;
    $cleanPath = ltrim($coverPath, '/');
    $cleanPath = preg_replace('#^(\.\./)+#', '', $cleanPath);
    $absPath = ROOT_PATH . '/' . $cleanPath;
    if (file_exists($absPath)) {
        $ext = strtolower(pathinfo($absPath, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($ext, $allowed)) {
            $data = @file_get_contents($absPath);
            if ($data !== false) return 'data:image/' . $ext . ';base64,' . base64_encode($data);
        }
        $webPath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $absPath);
        if ($webPath && file_exists($absPath)) return $webPath;
    }
    if (function_exists('getWebImageUrl')) {
        $webUrl = getWebImageUrl($coverPath);
        if ($webUrl) return $webUrl;
    }
    return '';
}
function getMemberPhotoUrl($photoPath) { return getCoverImageSrc($photoPath); }

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

// ==================== TRANSLATIONS (Full for English, Hindi, Arabic) ====================
$translations = [
    'en' => [
        'opac_title' => 'Online Public Access Catalog',
        'member_login' => 'Member Login',
        'my_account' => 'My Account',
        'logout' => 'Logout',
        'suggest_inform' => 'Suggest / Inform',
        'search_all_resources' => 'Search All Resources',
        'find_books_ebooks_databases' => 'Find books, eBooks, and research databases in one place',
        'search_by_title_author_subject' => 'Search by title, author, subject...',
        'all_resources' => 'All Resources',
        'books' => 'Books',
        'ebooks' => 'eBooks',
        'research_databases' => 'Research Databases',
        'journals' => 'Journals',
        'articles' => 'Articles',
        'search' => 'Search',
        'searching' => 'Searching...',
        'no_results' => 'No results found',
        'results_found' => 'results found for',
        'error_searching' => 'Error searching',
        'trending_resources' => 'Trending Resources',
        'most_popular_books' => 'Most Popular Books',
        'most_issued_this_month' => 'Most issued this month',
        'most_downloaded_ebooks' => 'Most Downloaded eBooks',
        'top_picks' => 'Top picks',
        'featured_databases' => 'Featured Databases',
        'recommended_resources' => 'Recommended resources',
        'search_physical_books' => 'Search Physical Books',
        'browse_printed_books' => 'Browse our collection of printed books',
        'search_by_title_author_isbn' => 'Search by title, author, ISBN...',
        'all_categories' => 'All Categories',
        'search_ebooks' => 'Search eBooks',
        'explore_digital_collection' => 'Explore our digital collection',
        'all_subjects' => 'All Subjects',
        'digital_hub' => 'Digital Hub',
        'new_arrivals' => 'New Arrivals',
        'auto_sliding' => 'Auto-sliding →',
        'most_popular_ebooks' => 'Most Popular eBooks',
        'latest_ebooks' => 'Latest eBooks',
        'download' => 'Download',
        'view_details' => 'View Details',
        'book_details' => 'Book Details',
        'author' => 'Author',
        'publisher' => 'Publisher',
        'isbn' => 'ISBN',
        'year' => 'Year',
        'category' => 'Category',
        'item_category' => 'Item Category',
        'book_status' => 'Book Status',
        'price' => 'Price',
        'availability' => 'Availability',
        'available_copies' => 'copies available',
        'not_available' => 'Not Available',
        'summary' => 'Summary',
        'no_summary' => 'No summary available.',
        'suggest_book' => 'Suggest / Inform',
        'your_admission_number' => 'Your Admission/Member Number *',
        'your_full_name' => 'Your Full Name *',
        'book_title' => 'Book Title *',
        'author_optional' => 'Author',
        'isbn_optional' => 'ISBN (if known)',
        'reason_for_suggestion' => 'Reason for Suggestion *',
        'why_recommend' => 'Why do you recommend this book?',
        'suggestion_info' => 'Your suggestion will be reviewed by library staff.',
        'submit' => 'Submit',
        'cancel' => 'Cancel',
        'close' => 'Close',
        'scan_barcode' => 'Scan barcode here...',
        'processing' => 'Processing...',
        'network_error' => 'Network error. Please try again.',
        'enter_valid_id' => 'Please enter a valid search term',
        'entry_recorded' => 'ENTRY recorded',
        'exit_recorded' => 'EXIT recorded',
        'visitors_today' => 'Visitors Today',
        'currently_inside' => 'Currently Inside',
        'male_female_inside' => 'Male / Female (inside)',
        'inside_by_category' => 'Inside by Category',
        'none' => 'None',
        'back_to_home' => 'Back to Home',
        'library_announcements' => 'Library Announcements',
        'posted' => 'Posted',
        'library_notice' => 'Library Notice',
        'designed_by' => 'Designed by',
        'all_rights_reserved' => 'All rights reserved.',
        'library_hours' => 'Library Hours',
        'open_days' => 'Open Days',
        'hours' => 'Hours',
        'lunch_break' => 'Lunch Break',
        'currently_closed' => 'The library is currently closed.',
        'quick_links' => 'Quick Links',
        'contact_us' => 'Contact Us',
        'unknown_author' => 'Unknown Author',
        'access_database' => 'Access Database',
        'visit_website' => 'Visit Website',
        'resource_type' => 'Resource Type',
        'search_databases' => 'Search Databases',
        'browse_databases' => 'Browse our research databases',
        'database_search_placeholder' => 'Search by database name or subject...',
        'all_database_types' => 'All Database Types',
        'academic_databases' => 'Academic Databases',
        'open_access' => 'Open Access',
        'subscription_based' => 'Subscription Based',
        'no_databases_found' => 'No databases found',
        'thought_of_the_day' => 'Thought of the Day',
        'quote_author_unknown' => 'Unknown',
        'refresh_quote' => 'Refresh Quote',
        'total_books' => 'Total Books',
        'total_ebooks' => 'Total eBooks',
        'total_databases' => 'Research Databases',
        'total_members' => 'Registered Members',
        'book_of_the_day' => 'Book of the Day',
        'library_stats' => 'Library Stats',
        'place_hold' => 'Place Hold',
        'hold_placed' => 'Hold placed successfully. You will be notified when available.',
        'hold_error' => 'Could not place hold. Please try again.',
        'already_on_hold' => 'You already have a hold on this book.',
        'recommended_for_you' => 'Recommended for You',
        'semantic_search' => 'Semantic Search (AI)',
        'pay_fines' => 'Pay Fines',
        'current_loans' => 'Current Loans',
        'due_date' => 'Due Date',
        'renew' => 'Renew',
        'fine_total' => 'Total Fines',
        'advanced_search' => 'Advanced Search',
        'search_books_advanced' => 'Advanced Book Search',
        'keyword' => 'Keyword',
        'chat_with_librarian' => 'Chat with Librarian',
        'ask_question' => 'Ask a question...',
        'library_assistant' => 'Library Assistant',
        'hello_chat' => 'Hello! I am your library assistant. Ask me about library hours, book availability, or how to search.',
        'type_question' => 'Type your question...',
        'year_from' => 'Year From',
        'year_to' => 'Year To',
        'language' => 'Language',
        'curriculum' => 'Curriculum',
        'available' => 'AVAILABLE',
        'issued' => 'ISSUED',
        'whom' => 'WHOM',
        'my_loans' => 'My Loans',
        'my_holds' => 'My Holds',
        'my_fines' => 'My Fines',
        'cancel_hold' => 'Cancel Hold',
        'no_loans' => 'No active loans',
        'no_holds' => 'No active holds',
        'view_all' => 'View All',
        'account_summary' => 'Account Summary',
        'loan_count' => 'Active Loans',
        'hold_count' => 'Pending Holds',
        'overdue_fines' => 'Overdue Fines',
        'loading' => 'Loading...',
        'error_loading' => 'Error loading data',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'total_visitors' => 'Total Visitors',
        // NEW: for serials section
        'recent_serials' => 'Recent Serials / Periodicals',
        'no_serials_found' => 'No serials found',
    ],
    'hi' => [
        'opac_title' => 'ऑनलाइन सार्वजनिक पहुँच सूची',
        'member_login' => 'सदस्य लॉगिन',
        'my_account' => 'मेरा खाता',
        'logout' => 'लॉगआउट',
        'suggest_inform' => 'सुझाव / जानकारी',
        'search_all_resources' => 'सभी संसाधन खोजें',
        'find_books_ebooks_databases' => 'किताबें, ई-पुस्तकें और शोध डेटाबेस एक ही जगह खोजें',
        'search_by_title_author_subject' => 'शीर्षक, लेखक, विषय से खोजें...',
        'all_resources' => 'सभी संसाधन',
        'books' => 'पुस्तकें',
        'ebooks' => 'ई-पुस्तकें',
        'research_databases' => 'शोध डेटाबेस',
        'journals' => 'पत्रिकाएँ',
        'articles' => 'लेख',
        'search' => 'खोजें',
        'searching' => 'खोज हो रही है...',
        'no_results' => 'कोई परिणाम नहीं मिला',
        'results_found' => 'परिणाम मिले',
        'error_searching' => 'खोज में त्रुटि',
        'trending_resources' => 'ट्रेंडिंग संसाधन',
        'most_popular_books' => 'सबसे लोकप्रिय पुस्तकें',
        'most_issued_this_month' => 'इस महीने सबसे अधिक जारी',
        'most_downloaded_ebooks' => 'सबसे अधिक डाउनलोड की गई ई-पुस्तकें',
        'top_picks' => 'शीर्ष चयन',
        'featured_databases' => 'विशेष डेटाबेस',
        'recommended_resources' => 'अनुशंसित संसाधन',
        'search_physical_books' => 'भौतिक पुस्तकें खोजें',
        'browse_printed_books' => 'हमारे मुद्रित पुस्तकों के संग्रह को ब्राउज़ करें',
        'search_by_title_author_isbn' => 'शीर्षक, लेखक, ISBN से खोजें...',
        'all_categories' => 'सभी श्रेणियाँ',
        'search_ebooks' => 'ई-पुस्तकें खोजें',
        'explore_digital_collection' => 'हमारे डिजिटल संग्रह का अन्वेषण करें',
        'all_subjects' => 'सभी विषय',
        'digital_hub' => 'डिजिटल हब',
        'new_arrivals' => 'नई आगमन',
        'auto_sliding' => 'स्वचालित स्लाइडिंग →',
        'most_popular_ebooks' => 'सबसे लोकप्रिय ई-पुस्तकें',
        'latest_ebooks' => 'नवीनतम ई-पुस्तकें',
        'download' => 'डाउनलोड',
        'view_details' => 'विवरण देखें',
        'book_details' => 'पुस्तक विवरण',
        'author' => 'लेखक',
        'publisher' => 'प्रकाशक',
        'isbn' => 'ISBN',
        'year' => 'वर्ष',
        'category' => 'श्रेणी',
        'item_category' => 'वस्तु श्रेणी',
        'book_status' => 'पुस्तक स्थिति',
        'price' => 'मूल्य',
        'availability' => 'उपलब्धता',
        'available_copies' => 'प्रतियाँ उपलब्ध',
        'not_available' => 'उपलब्ध नहीं',
        'summary' => 'सारांश',
        'no_summary' => 'कोई सारांश उपलब्ध नहीं।',
        'suggest_book' => 'सुझाव / जानकारी',
        'your_admission_number' => 'आपका नामांकन/सदस्य संख्या *',
        'your_full_name' => 'आपका पूरा नाम *',
        'book_title' => 'पुस्तक का शीर्षक *',
        'author_optional' => 'लेखक',
        'isbn_optional' => 'ISBN (यदि ज्ञात हो)',
        'reason_for_suggestion' => 'सुझाव का कारण *',
        'why_recommend' => 'आप इस पुस्तक की सिफारिश क्यों करते हैं?',
        'suggestion_info' => 'आपका सुझाव पुस्तकालय कर्मचारियों द्वारा समीक्षा किया जाएगा।',
        'submit' => 'जमा करें',
        'cancel' => 'रद्द करें',
        'close' => 'बंद करें',
        'scan_barcode' => 'बारकोड स्कैन करें...',
        'processing' => 'प्रक्रिया हो रही है...',
        'network_error' => 'नेटवर्क त्रुटि। कृपया पुनः प्रयास करें।',
        'enter_valid_id' => 'कृपया एक मान्य खोज शब्द दर्ज करें',
        'entry_recorded' => 'प्रवेश दर्ज किया गया',
        'exit_recorded' => 'निकास दर्ज किया गया',
        'visitors_today' => 'आज के आगंतुक',
        'currently_inside' => 'वर्तमान में अंदर',
        'male_female_inside' => 'पुरुष / महिला (अंदर)',
        'inside_by_category' => 'श्रेणी के अनुसार अंदर',
        'none' => 'कोई नहीं',
        'back_to_home' => 'होम पर वापस जाएं',
        'library_announcements' => 'पुस्तकालय घोषणाएँ',
        'posted' => 'पोस्ट किया गया',
        'library_notice' => 'पुस्तकालय सूचना',
        'designed_by' => 'द्वारा डिज़ाइन किया गया',
        'all_rights_reserved' => 'सर्वाधिकार सुरक्षित।',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'library_hours' => 'पुस्तकालय समय',
        'open_days' => 'खुले दिन',
        'hours' => 'समय',
        'lunch_break' => 'दोपहर का भोजन अवकाश',
        'currently_closed' => 'पुस्तकालय वर्तमान में बंद है।',
        'quick_links' => 'त्वरित लिंक',
        'contact_us' => 'संपर्क करें',
        'unknown_author' => 'अज्ञात लेखक',
        'access_database' => 'डेटाबेस तक पहुँचें',
        'visit_website' => 'वेबसाइट देखें',
        'resource_type' => 'संसाधन प्रकार',
        'search_databases' => 'डेटाबेस खोजें',
        'browse_databases' => 'हमारे शोध डेटाबेस ब्राउज़ करें',
        'database_search_placeholder' => 'डेटाबेस नाम या विषय से खोजें...',
        'all_database_types' => 'सभी डेटाबेस प्रकार',
        'academic_databases' => 'शैक्षणिक डेटाबेस',
        'open_access' => 'मुफ्त पहुँच',
        'subscription_based' => 'सदस्यता आधारित',
        'no_databases_found' => 'कोई डेटाबेस नहीं मिला',
        'thought_of_the_day' => 'दिन का विचार',
        'quote_author_unknown' => 'अज्ञात',
        'refresh_quote' => 'उद्धरण ताज़ा करें',
        'total_books' => 'कुल पुस्तकें',
        'total_ebooks' => 'कुल ई-पुस्तकें',
        'total_databases' => 'शोध डेटाबेस',
        'total_members' => 'पंजीकृत सदस्य',
        'book_of_the_day' => 'दिन की पुस्तक',
        'library_stats' => 'पुस्तकालय आँकड़े',
        'place_hold' => 'होल्ड करें',
        'hold_placed' => 'होल्ड सफलतापूर्वक लगाया गया। उपलब्ध होने पर आपको सूचित किया जाएगा।',
        'hold_error' => 'होल्ड नहीं लगा पाए। कृपया पुनः प्रयास करें।',
        'already_on_hold' => 'आपने इस पुस्तक पर पहले से होल्ड लगाया है।',
        'recommended_for_you' => 'आपके लिए अनुशंसित',
        'semantic_search' => 'सिमेंटिक खोज (AI)',
        'pay_fines' => 'जुर्माना भुगतान करें',
        'current_loans' => 'वर्तमान ऋण',
        'due_date' => 'देय तिथि',
        'renew' => 'नवीनीकरण',
        'fine_total' => 'कुल जुर्माना',
        'advanced_search' => 'उन्नत खोज',
        'search_books_advanced' => 'उन्नत पुस्तक खोज',
        'keyword' => 'कीवर्ड',
        'chat_with_librarian' => 'पुस्तकालयाध्यक्ष से चैट करें',
        'ask_question' => 'प्रश्न पूछें...',
        'library_assistant' => 'पुस्तकालय सहायक',
        'hello_chat' => 'नमस्ते! मैं आपका पुस्तकालय सहायक हूँ। मुझसे पुस्तकालय समय, पुस्तक उपलब्धता, या खोजने के तरीके के बारे में पूछें।',
        'type_question' => 'अपना प्रश्न टाइप करें...',
        'year_from' => 'वर्ष से',
        'year_to' => 'वर्ष तक',
        'language' => 'भाषा',
        'curriculum' => 'पाठ्यक्रम',
        'available' => 'उपलब्ध',
        'issued' => 'जारी',
        'whom' => 'किसे',
        'my_loans' => 'मेरे ऋण',
        'my_holds' => 'मेरे होल्ड',
        'my_fines' => 'मेरा जुर्माना',
        'cancel_hold' => 'होल्ड रद्द करें',
        'no_loans' => 'कोई सक्रिय ऋण नहीं',
        'no_holds' => 'कोई सक्रिय होल्ड नहीं',
        'view_all' => 'सभी देखें',
        'account_summary' => 'खाता सारांश',
        'loan_count' => 'सक्रिय ऋण',
        'hold_count' => 'लंबित होल्ड',
        'overdue_fines' => 'अतिदेय जुर्माना',
        'loading' => 'लोड हो रहा है...',
        'error_loading' => 'डेटा लोड करने में त्रुटि',
        'total_visitors' => 'कुल आगंतुक',
        // NEW:
        'recent_serials' => 'हाल की सीरियल / पीरियोडिकल्स',
        'no_serials_found' => 'कोई सीरियल नहीं मिला',
    ],
    'ar' => [
        'opac_title' => 'الفهرس العام للوصول عبر الإنترنت',
        'member_login' => 'دخول الأعضاء',
        'my_account' => 'حسابي',
        'logout' => 'تسجيل خروج',
        'suggest_inform' => 'اقتراح / إبلاغ',
        'search_all_resources' => 'البحث في جميع المصادر',
        'find_books_ebooks_databases' => 'ابحث عن الكتب والكتب الإلكترونية وقواعد البيانات البحثية في مكان واحد',
        'search_by_title_author_subject' => 'ابحث بالعنوان، المؤلف، الموضوع...',
        'all_resources' => 'جميع المصادر',
        'books' => 'الكتب',
        'ebooks' => 'الكتب الإلكترونية',
        'research_databases' => 'قواعد البيانات البحثية',
        'journals' => 'الدوريات',
        'articles' => 'المقالات',
        'search' => 'بحث',
        'searching' => 'جاري البحث...',
        'no_results' => 'لم يتم العثور على نتائج',
        'results_found' => 'نتائج وجدت لـ',
        'error_searching' => 'خطأ في البحث',
        'trending_resources' => 'المصادر الرائجة',
        'most_popular_books' => 'الكتب الأكثر شعبية',
        'most_issued_this_month' => 'الأكثر إعارة هذا الشهر',
        'most_downloaded_ebooks' => 'الكتب الإلكترونية الأكثر تحميلاً',
        'top_picks' => 'اختيارات مميزة',
        'featured_databases' => 'قواعد بيانات مميزة',
        'recommended_resources' => 'مصادر موصى بها',
        'search_physical_books' => 'البحث في الكتب المادية',
        'browse_printed_books' => 'تصفح مجموعة الكتب المطبوعة لدينا',
        'search_by_title_author_isbn' => 'ابحث بالعنوان، المؤلف، ISBN...',
        'all_categories' => 'جميع الفئات',
        'search_ebooks' => 'البحث في الكتب الإلكترونية',
        'explore_digital_collection' => 'استكشف مجموعتنا الرقمية',
        'all_subjects' => 'جميع المواضيع',
        'digital_hub' => 'المركز الرقمي',
        'new_arrivals' => 'الوافدون الجدد',
        'auto_sliding' => 'تمرير تلقائي ←',
        'most_popular_ebooks' => 'الكتب الإلكترونية الأكثر شعبية',
        'latest_ebooks' => 'أحدث الكتب الإلكترونية',
        'download' => 'تحميل',
        'view_details' => 'عرض التفاصيل',
        'book_details' => 'تفاصيل الكتاب',
        'author' => 'المؤلف',
        'publisher' => 'الناشر',
        'isbn' => 'ISBN',
        'year' => 'السنة',
        'category' => 'الفئة',
        'item_category' => 'فئة المادة',
        'book_status' => 'حالة الكتاب',
        'price' => 'السعر',
        'availability' => 'التوفر',
        'available_copies' => 'نسخ متاحة',
        'not_available' => 'غير متوفر',
        'summary' => 'الملخص',
        'no_summary' => 'لا يوجد ملخص متاح.',
        'suggest_book' => 'اقتراح / إبلاغ',
        'your_admission_number' => 'رقم قبولك/عضويتك *',
        'your_full_name' => 'اسمك الكامل *',
        'book_title' => 'عنوان الكتاب *',
        'author_optional' => 'المؤلف',
        'isbn_optional' => 'ISBN (إن وجد)',
        'reason_for_suggestion' => 'سبب الاقتراح *',
        'why_recommend' => 'لماذا توصي بهذا الكتاب؟',
        'suggestion_info' => 'سيتم مراجعة اقتراحك من قبل موظفي المكتبة.',
        'submit' => 'إرسال',
        'cancel' => 'إلغاء',
        'close' => 'إغلاق',
        'scan_barcode' => 'امسح الباركود هنا...',
        'processing' => 'جاري المعالجة...',
        'network_error' => 'خطأ في الشبكة. يرجى المحاولة مرة أخرى.',
        'enter_valid_id' => 'يرجى إدخال مصطلح بحث صحيح',
        'entry_recorded' => 'تم تسجيل الدخول',
        'exit_recorded' => 'تم تسجيل الخروج',
        'visitors_today' => 'زوار اليوم',
        'currently_inside' => 'المتواجدون حالياً',
        'male_female_inside' => 'ذكر / أنثى (داخل)',
        'inside_by_category' => 'الداخلون حسب الفئة',
        'none' => 'لا شيء',
        'back_to_home' => 'العودة إلى الرئيسية',
        'library_announcements' => 'إعلانات المكتبة',
        'posted' => 'نشر',
        'library_notice' => 'إشعار المكتبة',
        'designed_by' => 'صمم بواسطة',
        'all_rights_reserved' => 'جميع الحقوق محفوظة.',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'library_hours' => 'ساعات المكتبة',
        'open_days' => 'أيام العمل',
        'hours' => 'الساعات',
        'lunch_break' => 'استراحة الغداء',
        'currently_closed' => 'المكتبة مغلقة حالياً.',
        'quick_links' => 'روابط سريعة',
        'contact_us' => 'اتصل بنا',
        'unknown_author' => 'مؤلف غير معروف',
        'access_database' => 'الوصول إلى قاعدة البيانات',
        'visit_website' => 'زيارة الموقع',
        'resource_type' => 'نوع المصدر',
        'search_databases' => 'البحث في قواعد البيانات',
        'browse_databases' => 'تصفح قواعد البيانات البحثية لدينا',
        'database_search_placeholder' => 'ابحث باسم قاعدة البيانات أو الموضوع...',
        'all_database_types' => 'جميع أنواع قواعد البيانات',
        'academic_databases' => 'قواعد بيانات أكاديمية',
        'open_access' => 'وصول مفتوح',
        'subscription_based' => 'قائم على الاشتراك',
        'no_databases_found' => 'لم يتم العثور على قواعد بيانات',
        'thought_of_the_day' => 'فكرة اليوم',
        'quote_author_unknown' => 'غير معروف',
        'refresh_quote' => 'تحديث الاقتباس',
        'total_books' => 'إجمالي الكتب',
        'total_ebooks' => 'إجمالي الكتب الإلكترونية',
        'total_databases' => 'قواعد البيانات البحثية',
        'total_members' => 'الأعضاء المسجلون',
        'book_of_the_day' => 'كتاب اليوم',
        'library_stats' => 'إحصائيات المكتبة',
        'place_hold' => 'وضع حجز',
        'hold_placed' => 'تم وضع الحجز بنجاح. سيتم إبلاغك عند التوفر.',
        'hold_error' => 'تعذر وضع الحجز. يرجى المحاولة مرة أخرى.',
        'already_on_hold' => 'لديك بالفعل حجز على هذا الكتاب.',
        'recommended_for_you' => 'موصى به لك',
        'semantic_search' => 'البحث الدلالي (AI)',
        'pay_fines' => 'دفع الغرامات',
        'current_loans' => 'القروض الحالية',
        'due_date' => 'تاريخ الاستحقاق',
        'renew' => 'تجديد',
        'fine_total' => 'إجمالي الغرامات',
        'advanced_search' => 'بحث متقدم',
        'search_books_advanced' => 'بحث متقدم عن الكتب',
        'keyword' => 'كلمة مفتاحية',
        'chat_with_librarian' => 'الدردشة مع أمين المكتبة',
        'ask_question' => 'اطرح سؤالاً...',
        'library_assistant' => 'مساعد المكتبة',
        'hello_chat' => 'مرحباً! أنا مساعد المكتبة. اسألني عن ساعات العمل، توفر الكتب، أو كيفية البحث.',
        'type_question' => 'اكتب سؤالك...',
        'year_from' => 'من سنة',
        'year_to' => 'إلى سنة',
        'language' => 'اللغة',
        'curriculum' => 'المنهج',
        'available' => 'متاح',
        'issued' => 'مستعار',
        'whom' => 'لمن',
        'my_loans' => 'قروضي',
        'my_holds' => 'حجوزاتي',
        'my_fines' => 'غراماتي',
        'cancel_hold' => 'إلغاء الحجز',
        'no_loans' => 'لا توجد قروض نشطة',
        'no_holds' => 'لا توجد حجوزات نشطة',
        'view_all' => 'عرض الكل',
        'account_summary' => 'ملخص الحساب',
        'loan_count' => 'القروض النشطة',
        'hold_count' => 'الحجوزات المعلقة',
        'overdue_fines' => 'الغرامات المتأخرة',
        'loading' => 'جاري التحميل...',
        'error_loading' => 'خطأ في تحميل البيانات',
        'total_visitors' => 'إجمالي الزوار',
        // NEW:
        'recent_serials' => 'أحدث السلاسل / الدوريات',
        'no_serials_found' => 'لم يتم العثور على سلاسل',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

// ==================== CSRF ====================
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$csrf_token = $_SESSION['csrf_token'];

// ==================== Database ====================
$db = getDB();
$cacheFile = __DIR__ . '/cache/opac_cache.json';

function getCached($key, $ttl = 300) {
    global $cacheFile;
    if (!file_exists($cacheFile)) return null;
    $data = json_decode(file_get_contents($cacheFile), true);
    if (isset($data[$key]) && (time() - $data[$key]['time']) < $ttl) return $data[$key]['value'];
    return null;
}
function setCached($key, $value) {
    global $cacheFile;
    $dir = dirname($cacheFile);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $data = file_exists($cacheFile) ? json_decode(file_get_contents($cacheFile), true) : [];
    $data[$key] = ['time' => time(), 'value' => $value];
    file_put_contents($cacheFile, json_encode($data));
}

$settings = getCached('settings');
if (!$settings) { $settings = getSettings(); setCached('settings', $settings); }
$institution = getCached('institution');
if (!$institution) { $institution = getInstitution(); setCached('institution', $institution); }

// OPAC settings
$opacEnabled               = (int)($settings['opac_enabled'] ?? 1);
$opacShowNewArrivals       = (int)($settings['opac_show_new_arrivals'] ?? 1);
$opacShowPopularEbooks     = (int)($settings['opac_show_popular_ebooks'] ?? 1);
$opacShowLatestEbooks      = (int)($settings['opac_show_latest_ebooks'] ?? 1);
$opacShowNotices           = (int)($settings['opac_show_notices'] ?? 1);
$opacShowTrending          = (int)($settings['opac_show_trending'] ?? 1);
$opacShowDatabases         = (int)($settings['opac_show_databases'] ?? 1);
$opacShowThoughtOfTheDay   = (int)($settings['opac_show_thought_of_the_day'] ?? 1);
$opacShowNewArrivalsInLeft = (int)($settings['opac_show_new_arrivals_in_left'] ?? 1);
$opacQuoteRotationInterval = (int)($settings['opac_quote_rotation_interval'] ?? 10);
$opacCarouselType          = $settings['opac_carousel_type'] ?? 'cover_flow';
$opacHeaderText            = $settings['opac_header_text'] ?? '';
$opacTagline               = $settings['opac_tagline'] ?? __('find_books_ebooks_databases');
$opacBooksPerPage          = (int)($settings['opac_books_per_page'] ?? 12);
$opacEbooksPerPage         = (int)($settings['opac_ebooks_per_page'] ?? 8);
$opacNoticeTitle           = $settings['opac_notice_title'] ?? '';
$opacNoticeContent         = $settings['opac_notice_content'] ?? '';
$opacHeaderLogo            = $settings['opac_header_logo'] ?? '';
$opacFontFamily            = $settings['opac_font_family'] ?? 'Inter';
$opacBaseFontSize          = (int)($settings['opac_base_font_size'] ?? 16);
$opacHeadingFontSize       = (int)($settings['opac_heading_font_size'] ?? 32);
$opacFontWeight            = $settings['opac_font_weight'] ?? '400';
$opacPrimaryColor          = $settings['opac_primary_color'] ?? '#1e3c72';
$opacHeaderBgColor         = $settings['opac_header_bg_color'] ?? '#1e3c72';
$opacBodyBg                = $settings['opac_body_bg'] ?? '#f0f2f5';
$opacCustomCss             = $settings['opac_custom_css'] ?? '';
$containerMaxWidth         = (int)($settings['container_max_width'] ?? 1600);
$containerPadding          = (int)($settings['container_padding'] ?? 10);
$openaiApiKey              = $settings['openai_api_key'] ?? '';

$displayHeaderText = !empty($opacHeaderText) ? $opacHeaderText : ($institution['name'] ?? $settings['software_header'] ?? 'Library System');
$displayTagline = $opacTagline;

// Header logo
function getHeaderLogoUrl() {
    global $settings, $institution, $opacHeaderLogo;
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    if (!empty($opacHeaderLogo)) {
        $url = $resolveUrl($opacHeaderLogo);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    $logoKeys = ['library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
        }
    }
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%23'.$opacPrimaryColor.'\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}
$logoUrl = getHeaderLogoUrl();

// Member session
$memberLoggedIn = false;
$memberData = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) die('Invalid CSRF token');
    unset($_SESSION['member_id']); session_destroy(); session_start(); $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    header("Location: index.php"); exit;
}
if (isset($_SESSION['member_id'])) {
    $stmt = $db->prepare("SELECT id, admno, name, email, total_fines, phone, photo_path FROM members WHERE id = ? AND status = 'active'");
    $stmt->execute([$_SESSION['member_id']]);
    $memberData = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($memberData) { $memberLoggedIn = true; $_SESSION['member_name'] = $memberData['name']; }
    else { unset($_SESSION['member_id']); }
}

// AJAX handlers
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ajax']) && $_GET['ajax'] === 'account_data' && $memberLoggedIn) {
    header('Content-Type: application/json');
    try {
        $loans = $db->prepare("SELECT c.id, c.barcode, c.title, c.due_date, CASE WHEN c.return_date IS NOT NULL THEN 'returned' WHEN c.due_date < date('now') THEN 'overdue' ELSE 'issued' END as status FROM circulation c WHERE c.admno = ? AND c.return_date IS NULL ORDER BY c.due_date ASC");
        $loans->execute([$memberData['admno']]);
        $activeLoans = $loans->fetchAll(PDO::FETCH_ASSOC);
        $holds = $db->prepare("SELECT h.id, h.book_barcode, b.title, h.status, h.expiry_date FROM book_holds h LEFT JOIN books b ON h.book_barcode = b.barcode WHERE h.admno = ? AND h.status IN ('pending', 'available')");
        $holds->execute([$memberData['admno']]);
        $activeHolds = $holds->fetchAll(PDO::FETCH_ASSOC);
        $fines = $memberData['total_fines'] ?? 0;
        echo json_encode(['success' => true, 'loans' => $activeLoans, 'holds' => $activeHolds, 'fines' => $fines]);
    } catch (Exception $e) { echo json_encode(['success' => false, 'error' => $e->getMessage()]); }
    exit;
}

// Place Hold
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_hold'])) {
    header('Content-Type: application/json');
    try {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) throw new Exception('Invalid security token');
        if (!$memberLoggedIn) throw new Exception('You must be logged in to place a hold.');
        $book_id = (int)$_POST['book_id'];
        $bookCheck = $db->prepare("SELECT available, title, barcode FROM books WHERE id = ?");
        $bookCheck->execute([$book_id]);
        $book = $bookCheck->fetch();
        if (!$book) throw new Exception('Book not found.');
        $stmt = $db->prepare("SELECT id FROM book_holds WHERE book_barcode = ? AND admno = ? AND status IN ('pending', 'available')");
        $stmt->execute([$book['barcode'], $memberData['admno']]);
        if ($stmt->fetch()) throw new Exception(__('already_on_hold'));
        $insert = $db->prepare("INSERT INTO book_holds (book_barcode, admno, member_name, hold_date, expiry_date, status) VALUES (?, ?, ?, DATE('now'), DATE('now', '+' || ? || ' days'), 'pending')");
        $insert->execute([$book['barcode'], $memberData['admno'], $memberData['name'], $settings['hold_days'] ?? 7]);
        echo json_encode(['success' => true, 'message' => __('hold_placed')]);
    } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
    exit;
}

// Cancel Hold
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_hold'])) {
    header('Content-Type: application/json');
    try {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) throw new Exception('Invalid security token');
        if (!$memberLoggedIn) throw new Exception('Not logged in');
        $hold_id = (int)$_POST['hold_id'];
        $stmt = $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ? AND admno = ?");
        $stmt->execute([$hold_id, $memberData['admno']]);
        echo json_encode(['success' => true, 'message' => 'Hold cancelled successfully']);
    } catch (Exception $e) { echo json_encode(['success' => false, 'error' => $e->getMessage()]); }
    exit;
}

// Submit Suggestion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_suggestion'])) {
    header('Content-Type: application/json');
    try {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) throw new Exception('Invalid security token');
        $admno = trim($_POST['member_admno'] ?? '');
        $name = trim($_POST['member_name'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $author = trim($_POST['author'] ?? '');
        $isbn = trim($_POST['isbn'] ?? '');
        $reason = trim($_POST['reason'] ?? '');
        if (empty($admno) || empty($name) || empty($title) || empty($reason)) throw new Exception('Please fill all required fields.');
        $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='book_suggestions'");
        if (!$tableCheck->fetch()) {
            $db->exec("CREATE TABLE IF NOT EXISTS book_suggestions (id INTEGER PRIMARY KEY AUTOINCREMENT, admno TEXT NOT NULL, name TEXT NOT NULL, title TEXT NOT NULL, author TEXT, isbn TEXT, reason TEXT NOT NULL, status TEXT DEFAULT 'pending', admin_notes TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME)");
        }
        $stmt = $db->prepare("INSERT INTO book_suggestions (admno, name, title, author, isbn, reason, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', datetime('now'))");
        $stmt->execute([$admno, $name, $title, $author, $isbn, $reason]);
        echo json_encode(['success' => true, 'message' => 'Suggestion submitted successfully. Thank you!']);
    } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
    exit;
}

// Statistics
$statsCache = getCached('stats');
if (!$statsCache) {
    $totalBooks     = $db->query("SELECT COUNT(*) FROM books WHERE status != 'Deleted'")->fetchColumn();
    $totalEbooks    = $db->query("SELECT COUNT(*) FROM ebooks")->fetchColumn();
    $totalDatabases = $db->query("SELECT COUNT(*) FROM research_databases WHERE is_active = 1")->fetchColumn();
    $totalMembers   = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
    $statsCache = ['totalBooks' => $totalBooks, 'totalEbooks' => $totalEbooks, 'totalDatabases' => $totalDatabases, 'totalMembers' => $totalMembers];
    setCached('stats', $statsCache);
} else {
    $totalBooks = $statsCache['totalBooks'];
    $totalEbooks = $statsCache['totalEbooks'];
    $totalDatabases = $statsCache['totalDatabases'];
    $totalMembers = $statsCache['totalMembers'];
}

// Current date and time for cards
$todayDate = date('d M Y');
$currentTime = date('h:i:s A'); // AM/PM format
$dayOfWeek = date('l');
$timezone = date('T'); // kept for reference but not displayed

// ==================== FETCH RECENT SERIALS & CHECK RECENCY ====================
$showSerials = false;
$recentSerials = [];
$bookOfTheDay = null;

// Try to get latest serial creation date
$latestSerialDate = $db->query("SELECT MAX(created_at) FROM serial_subscriptions WHERE status = 'active'")->fetchColumn();
if ($latestSerialDate) {
    $latestDate = new DateTime($latestSerialDate);
    $now = new DateTime();
    $diff = $now->diff($latestDate);
    if ($diff->days <= 14) {
        $showSerials = true;
        // Fetch up to 20 active serials, ordered by created_at DESC
        $stmt = $db->prepare("SELECT id, title, cover_path, frequency, subscription_type, created_at FROM serial_subscriptions WHERE status = 'active' ORDER BY created_at DESC LIMIT 20");
        $stmt->execute();
        $recentSerials = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($recentSerials as &$serial) {
            $serial['cover_base64'] = getCoverImageSrc($serial['cover_path'] ?? '');
        }
    }
}

// If serials are not recent, fetch Book of the Day as fallback
if (!$showSerials) {
    $bookOfTheDay = getCached('book_of_the_day');
    if (!$bookOfTheDay) {
        $stmt = $db->query("SELECT id, barcode, title, author, publisher, year, cover_path, summary, available, book_status FROM books WHERE status != 'Deleted' AND cover_path IS NOT NULL AND cover_path != '' ORDER BY RANDOM() LIMIT 1");
        $bookOfTheDay = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($bookOfTheDay) $bookOfTheDay['cover_base64'] = getCoverImageSrc($bookOfTheDay['cover_path'] ?? '');
        else $bookOfTheDay = null;
        setCached('book_of_the_day', $bookOfTheDay);
    }
}

// Notices
$notices = [];
if ($opacShowNotices) $notices = $db->query("SELECT * FROM notices WHERE is_active = 1 ORDER BY created_at DESC LIMIT 10")->fetchAll();

// New Arrivals
$newArrivals = [];
if ($opacShowNewArrivals) {
    $stmt = $db->prepare("SELECT id, barcode, title, author, publisher, category, item_category, created_at, cover_path, book_status, available FROM books WHERE status != 'Deleted' ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$newArrivalsCount = (int)($settings['new_arrivals_count'] ?? 12)]);
    $newArrivals = $stmt->fetchAll();
}

// eBooks
$newEbooks = [];
if ($opacShowLatestEbooks) $newEbooks = $db->query("SELECT * FROM ebooks ORDER BY created_at DESC LIMIT 20")->fetchAll();
$popularEbooks = [];
if ($opacShowPopularEbooks) $popularEbooks = $db->query("SELECT * FROM ebooks WHERE downloads > 0 ORDER BY downloads DESC LIMIT 20")->fetchAll();

// Categories & Subjects
$categories    = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' AND status != 'Deleted' ORDER BY category LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
$ebookSubjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject LIMIT 30")->fetchAll(PDO::FETCH_COLUMN);

// Trending
$popularBooks = $db->query("SELECT b.title, b.author, COUNT(l.id) as count FROM loans l JOIN books b ON l.book_id = b.id WHERE l.return_date IS NOT NULL AND l.issue_date >= DATE('now', '-30 days') GROUP BY b.id ORDER BY count DESC LIMIT 5")->fetchAll();
$popularEbooksData = $db->query("SELECT title, author, downloads FROM ebooks WHERE downloads > 0 ORDER BY downloads DESC LIMIT 5")->fetchAll();

// Featured Databases
$featuredDatabases = [];
$allDatabases = [];
if ($opacShowDatabases) {
    $allDatabases = $db->query("SELECT * FROM research_databases WHERE is_active = 1 ORDER BY is_featured DESC, sort_order ASC")->fetchAll();
    $featuredDatabases = $db->query("SELECT * FROM research_databases WHERE is_active = 1 AND is_featured = 1 ORDER BY sort_order ASC LIMIT 6")->fetchAll();
}

// Recommendations
$recommendations = [];
if ($memberLoggedIn) {
    $stmt = $db->prepare("SELECT DISTINCT barcode FROM circulation WHERE admno = ? AND return_date IS NOT NULL LIMIT 10");
    $stmt->execute([$memberData['admno']]);
    $borrowedBarcodes = $stmt->fetchAll(PDO::FETCH_COLUMN);
    if (!empty($borrowedBarcodes)) {
        $placeholders = implode(',', array_fill(0, count($borrowedBarcodes), '?'));
        $stmt = $db->prepare("SELECT DISTINCT b.* FROM book_recommendations r JOIN books b ON r.recommended_book_id = b.id WHERE r.book_id IN (SELECT id FROM books WHERE barcode IN ($placeholders)) AND b.barcode NOT IN ($placeholders) ORDER BY r.score DESC LIMIT 6");
        $stmt->execute(array_merge($borrowedBarcodes, $borrowedBarcodes));
        $recommendations = $stmt->fetchAll();
    }
    if (empty($recommendations)) $recommendations = $db->query("SELECT id, barcode, title, author, cover_path, available, book_status FROM books WHERE status != 'Deleted' ORDER BY RANDOM() LIMIT 6")->fetchAll();
}

// Quotes
$quotes = getCached('quotes');
if (!$quotes) {
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='quotes'")->fetch();
    if ($tableCheck) $quotes = $db->query("SELECT text, author FROM quotes WHERE is_active = 1 ORDER BY RANDOM() LIMIT 30")->fetchAll();
    if (empty($quotes)) {
        $quotes = [
            ['text' => 'The only thing you absolutely have to know is the location of the library.', 'author' => 'Albert Einstein'],
            ['text' => 'Reading is to the mind what exercise is to the body.', 'author' => 'Joseph Addison'],
        ];
    }
    setCached('quotes', $quotes);
}

// OPAC Enabled Check
if (!$opacEnabled) {
    echo '<!DOCTYPE html><html><head><title>Maintenance</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container text-center py-5"><div class="card shadow mx-auto" style="max-width:500px"><div class="card-body"><i class="fas fa-tools fa-4x text-warning mb-3"></i><h2>OPAC Temporarily Unavailable</h2><p>Under maintenance. Please check back later.</p><a href="../index.php" class="btn btn-primary">Back to Home</a></div></div></div></body></html>';
    exit;
}

?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title><?= htmlspecialchars($displayHeaderText) ?> - OPAC</title>
    <?php
    $faviconPath = '';
    if (!empty($settings['favicon_path']) && file_exists($settings['favicon_path'])) {
        $faviconPath = getWebImageUrl($settings['favicon_path']);
    }
    ?>
    <?php if ($faviconPath): ?>
    <link rel="icon" type="image/x-icon" href="<?= htmlspecialchars($faviconPath) ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($opacFontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <?php if (isRTL()): ?>
    <style>
        body, .header-title, .search-card, .nav-link, .btn, .modal, .card-body, .trending-card { direction: rtl; text-align: right; }
        .section-title { padding-left: 0; padding-right: 15px; }
        .section-title::before { left: auto; right: 0; }
        .swiper-button-next, .swiper-button-prev { transform: scaleX(-1); }
        .me-2 { margin-right: 0 !important; margin-left: 0.5rem !important; }
        .ms-2 { margin-left: 0 !important; margin-right: 0.5rem !important; }
        .stats-card i { margin-left: 10px; margin-right: 0; }
        .quote-text:before { left: auto; right: -10px; }
        .quote-author { text-align: left; }
        .stats-card-inner .front, .stats-card-inner .back { transform-style: preserve-3d; }
        .stats-card-inner.flipped { transform: rotateY(-180deg); }
        .stats-card:hover .stats-card-inner { transform: rotateY(-180deg); }
    </style>
    <?php endif; ?>

    <style>
        :root {
            --primary-color: <?= htmlspecialchars($opacPrimaryColor) ?>;
            --header-bg: <?= htmlspecialchars($opacHeaderBgColor) ?>;
            --body-bg: <?= htmlspecialchars($opacBodyBg) ?>;
            --container-max-width: <?= (int)$containerMaxWidth ?>px;
            --container-padding: <?= (int)$containerPadding ?>px;
            --font-family: '<?= htmlspecialchars($opacFontFamily) ?>', 'Inter', sans-serif;
            --font-weight: <?= (int)$opacFontWeight ?>;
        }
        * { font-family: var(--font-family); font-weight: var(--font-weight); }
        body { background: var(--body-bg); font-size: <?= (int)$opacBaseFontSize ?>px; line-height: 1.6; }
        .main-layout { display: flex; flex-wrap: wrap; gap: 30px; margin-bottom: 40px; }
        .left-column { flex: 0 0 calc(70% - 15px); width: calc(70% - 15px); }
        .right-column { flex: 0 0 calc(30% - 15px); width: calc(30% - 15px); }
        .container-custom { max-width: var(--container-max-width); margin: 0 auto; padding: 0 var(--container-padding); }

        /* ========== STATS FLIP CARDS (enhanced) ========== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }
        .stats-card {
            background: transparent;
            border-radius: 24px;
            padding: 0;
            text-align: center;
            box-shadow: none;
            transition: all 0.3s;
            height: 100%;
            perspective: 800px;
            cursor: default;
            min-height: 130px;
        }
        .stats-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            min-height: 130px;
            transition: transform 0.8s cubic-bezier(0.4, 0.2, 0.2, 1);
            transform-style: preserve-3d;
            border-radius: 24px;
        }
        .stats-card-inner.flipped {
            transform: rotateY(180deg);
        }
        .stats-card:hover .stats-card-inner {
            transform: rotateY(180deg);
        }
        .stats-card .front,
        .stats-card .back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 18px 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.06);
            border: 1px solid rgba(255,255,255,0.3);
        }
        .stats-card .front {
            background: white;
            z-index: 2;
        }
        .stats-card .back {
            background: linear-gradient(145deg, var(--primary-color), #2a5298);
            color: white;
            transform: rotateY(180deg);
            padding: 18px 10px;
        }
        .stats-card .back p {
            font-size: 0.7rem;
            margin-bottom: 0;
            opacity: 0.9;
        }
        .stats-card .back .small-icon {
            font-size: 1.6rem;
            margin-bottom: 4px;
        }
        .stats-card i {
            font-size: 2rem;
            margin-bottom: 6px;
        }
        .stats-card h3 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
            line-height: 1.2;
        }
        .stats-card .front h3 {
            background: linear-gradient(135deg, var(--primary-color), #2a5298);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        .stats-card .back h3 {
            color: white;
        }
        .stats-card p {
            margin: 0;
            font-size: 0.75rem;
            color: #6c757d;
            font-weight: 500;
        }
        .stats-card .back p {
            color: rgba(255,255,255,0.85);
        }
        .stats-card .back i {
            color: #ffd700;
        }
        .stats-card.auto-flip-paused .stats-card-inner {
            transition: transform 0.6s;
        }
        /* End flip cards */

        /* Search card, etc. – existing styles */
        .search-card { background: white; border-radius: 24px; padding: 25px; box-shadow: 0 15px 40px rgba(0,0,0,0.08); transition: transform 0.3s; margin-bottom: 30px; }
        .search-card:hover { transform: translateY(-5px); box-shadow: 0 20px 50px rgba(0,0,0,0.12); }
        .hours-card, .thought-card, .member-info-container, .book-of-day-card, .serial-card { background: white; border-radius: 24px; padding: 20px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); margin-bottom: 25px; transition: all 0.3s; }
        .hours-card:hover, .thought-card:hover, .serial-card:hover { transform: translateY(-3px); }
        .hours-card h5, .thought-card h5, .serial-card h5 { font-size: 1.3rem; color: var(--primary-color); border-left: 4px solid var(--primary-color); padding-left: 12px; margin-bottom: 15px; }
        .quote-text { font-size: 1.1rem; font-style: italic; line-height: 1.5; color: #2c3e50; margin-bottom: 15px; position: relative; padding: 0 20px; }
        .quote-text:before { content: '"'; font-size: 3rem; position: absolute; left: -10px; top: -10px; opacity: 0.3; font-family: serif; }
        .quote-author { text-align: right; font-size: 0.9rem; color: #6c757d; margin-top: 10px; border-top: 1px solid #e9ecef; padding-top: 10px; }
        .refresh-quote-btn { background: none; border: 1px solid var(--primary-color); color: var(--primary-color); border-radius: 30px; padding: 5px 15px; font-size: 0.8rem; transition: all 0.3s; }
        .refresh-quote-btn:hover { background: var(--primary-color); color: white; }
        .database-card { background: white; border-radius: 20px; padding: 20px; transition: all 0.3s; height: 100%; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .database-card:hover { transform: translateY(-5px); box-shadow: 0 15px 35px rgba(0,0,0,0.12); }
        .database-icon { width: 60px; height: 60px; background: linear-gradient(135deg, var(--primary-color), #2a5298); border-radius: 16px; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; }
        .database-icon i { font-size: 28px; color: white; }

        /* ========== HEADER FIX: allow dropdown to be visible ========== */
        .header-bg {
            background: linear-gradient(135deg, var(--header-bg), #2a5298);
            color: white;
            padding: 20px 0;
            margin-bottom: 30px;
            position: relative;
            overflow: visible; /* changed from hidden */
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .header-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1%, transparent 1%);
            background-size: 50px 50px;
            animation: shimmer 60s linear infinite;
            pointer-events: none;
        }
        @keyframes shimmer {
            0% { background-position: 0 0; }
            100% { background-position: 50px 50px; }
        }
        .header-bg::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #ffd700, #ff8c00, #ffd700);
        }

        /* Improved dropdown styling */
        .header-right .dropdown-menu {
            z-index: 1060;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: none;
            margin-top: 8px;
            padding: 0.5rem 0;
        }
        .dropdown-item {
            padding: 0.5rem 1.5rem;
            transition: 0.2s;
        }
        .dropdown-item.active {
            background-color: var(--primary-color);
            color: white;
        }
        .dropdown-item:hover {
            background-color: #f0f2f5;
        }

        .header-container {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            gap: 20px;
            max-width: var(--container-max-width);
            margin: 0 auto;
            padding: 0 var(--container-padding);
            position: relative;
            z-index: 2;
        }
        .header-left { justify-self: start; }
        .header-title { text-align: center; justify-self: center; width: 100%; }
        .header-right { justify-self: end; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        @media (max-width: 768px) {
            .header-container { display: flex; flex-direction: column; gap: 15px; text-align: center; }
            .header-left, .header-right { justify-self: auto; }
            .header-title h1 { font-size: 1.6rem !important; }
        }
        .header-left img { height: 70px; width: auto; max-width: 200px; object-fit: contain; background: white; border-radius: 12px; padding: 5px; box-shadow: 0 4px 15px rgba(0,0,0,0.15); transition: transform 0.3s; }
        .header-left img:hover { transform: scale(1.02); }
        .header-title h1 { font-size: <?= (int)$opacHeadingFontSize ?>px; font-weight: 800; margin-bottom: 0.25rem; text-shadow: 2px 2px 6px rgba(0,0,0,0.15); }
        .header-title p { font-size: <?= round($opacHeadingFontSize * 0.4) ?>px; opacity: 0.95; }
        .lang-switch { background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.4); border-radius: 40px; padding: 10px 18px; color: white; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.3s; display: inline-flex; align-items: center; gap: 8px; backdrop-filter: blur(5px); }
        .lang-switch:hover { background: rgba(255,255,255,0.3); transform: scale(1.05); color: white; }

        .swiper { padding: 30px 0 50px !important; margin-bottom: 10px; }
        .swiper-slide { background: transparent; border-radius: 20px; transition: transform 0.3s; width: 260px; height: auto; }
        .book-card, .ebook-card { background: white; border-radius: 24px; overflow: hidden; box-shadow: 0 15px 30px rgba(0,0,0,0.1); transition: all 0.3s; cursor: pointer; height: 100%; }
        .book-card:hover, .ebook-card:hover { transform: translateY(-8px); box-shadow: 0 25px 40px rgba(0,0,0,0.15); }
        .book-cover, .ebook-cover {
            height: 320px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #f5f7fa, #e9ecef);
            padding: 10px;
        }
        .book-cover img, .ebook-cover img {
            max-height: 100%;
            max-width: 100%;
            object-fit: contain;
            border-radius: 12px;
            border: none;
            box-shadow: none;
        }
        .ebook-cover { background: linear-gradient(135deg, #667eea, #764ba2); }
        .book-cover .fa-book, .ebook-cover .fa-file-pdf { font-size: 4rem; color: #adb5bd; }

        .results-scroll-container {
            max-height: 600px;
            overflow-y: auto;
            padding-right: 5px;
        }
        .results-scroll-container::-webkit-scrollbar { width: 6px; }
        .results-scroll-container::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 10px; }
        .results-scroll-container::-webkit-scrollbar-thumb { background: var(--primary-color); border-radius: 10px; }

        .book-of-day-img {
            max-height: 280px !important;
            width: auto !important;
            max-width: 100%;
            object-fit: contain;
            border-radius: 16px;
            border: none;
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
            display: block;
            margin: 0 auto 15px auto;
            background: #f8f9fa;
            padding: 10px;
        }

        .member-info-card .whom-photo {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 50%;
            border: 3px solid var(--primary-color);
            background: #f8f9fa;
            flex-shrink: 0;
        }
        .member-info-card .whom-photo-placeholder {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid var(--primary-color);
            flex-shrink: 0;
            font-size: 2.5rem;
            color: #6c757d;
        }

        .section-title-center { text-align: center; font-size: 2rem; color: var(--primary-color); font-weight: 700; position: relative; display: inline-block; padding-bottom: 12px; margin-bottom: 25px; width: 100%; }
        .section-title-center:after { content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 70px; height: 4px; background: linear-gradient(90deg, var(--primary-color), #ffc107); border-radius: 3px; }
        .nav-tabs { border-bottom: 2px solid #e9ecef; margin-bottom: 25px; }
        .nav-tabs .nav-link { border: none; color: #6c757d; padding: 12px 28px; font-weight: 600; transition: all 0.3s; border-radius: 30px; margin: 0 5px; }
        .nav-tabs .nav-link:hover { color: var(--primary-color); background: #f8f9fa; }
        .nav-tabs .nav-link.active { color: var(--primary-color); background: linear-gradient(135deg, #fff, #f0f2f5); border-bottom: 3px solid var(--primary-color); }
        .btn-primary { background: linear-gradient(135deg, var(--primary-color), #2a5298); border: none; padding: 10px 28px; border-radius: 40px; font-weight: 600; transition: all 0.3s; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.2); filter: brightness(1.05); }
        .member-info-container { background: white; border-radius: 24px; padding: 20px; margin-bottom: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); transition: all 0.3s; }
        .footer { background: linear-gradient(135deg, #1a1a2e, #16213e); color: #eee; padding: 40px 0 25px; margin-top: 60px; border-radius: 30px 30px 0 0; }
        .footer a { color: #ffd700; text-decoration: none; transition: 0.3s; }
        .footer a:hover { color: #ffed4a; text-decoration: underline; }
        .loader { display: none; text-align: center; padding: 30px; }
        .loader.show { display: block; }
        .spinner { width: 45px; height: 45px; border: 4px solid #e9ecef; border-top: 4px solid var(--primary-color); border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 15px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .whatsapp-float { position: fixed; bottom: 25px; right: 25px; background: linear-gradient(135deg, #25d366, #20b359); color: white; border-radius: 50px; width: 55px; height: 55px; display: flex; align-items: center; justify-content: center; font-size: 28px; box-shadow: 0 6px 20px rgba(0,0,0,0.25); z-index: 1000; transition: all 0.3s; text-decoration: none; }
        .whatsapp-float:hover { transform: scale(1.1); background: #20b359; color: white; }
        .chatbot-btn { position: fixed; bottom: 100px; right: 25px; width: 55px; height: 55px; background: #25D366; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 28px; cursor: pointer; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 1001; transition: all 0.3s; border: none; }
        .chatbot-btn:hover { transform: scale(1.1); background: #128C7E; }
        .chat-window { position: fixed; bottom: 170px; right: 25px; width: 350px; height: 500px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); display: none; flex-direction: column; z-index: 1002; overflow: hidden; font-family: sans-serif; }
        .chat-header { background: var(--primary-color); color: white; padding: 15px; font-weight: bold; display: flex; justify-content: space-between; }
        .chat-messages { flex: 1; overflow-y: auto; padding: 15px; background: #f1f1f1; }
        .chat-input-area { display: flex; padding: 10px; border-top: 1px solid #ddd; background: white; }
        .chat-input-area input { flex: 1; border: 1px solid #ddd; border-radius: 25px; padding: 8px 15px; outline: none; }
        .chat-input-area button { background: var(--primary-color); border: none; color: white; border-radius: 25px; padding: 0 15px; margin-left: 8px; }
        .message { margin-bottom: 12px; display: flex; }
        .message.user { justify-content: flex-end; }
        .message.bot { justify-content: flex-start; }
        .message .bubble { max-width: 80%; padding: 8px 12px; border-radius: 18px; font-size: 0.85rem; }
        .message.user .bubble { background: var(--primary-color); color: white; }
        .message.bot .bubble { background: #e9ecef; color: #333; }

        .modal-body .book-detail-cover { text-align: center; }
        .modal-body .book-detail-cover img { max-height: 320px; width: auto; object-fit: contain; border-radius: 16px; border: none; box-shadow: 0 8px 20px rgba(0,0,0,0.1); }

        .book-card .card-body, .ebook-card .card-body { display: flex; flex-direction: column; justify-content: space-between; }
        .book-card .card-body .btn, .ebook-card .card-body .btn { align-self: center; }

        #backToTop {
            position: fixed;
            bottom: 90px;
            left: 25px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: all 0.3s;
            opacity: 0;
            visibility: hidden;
            z-index: 999;
        }
        #backToTop.visible { opacity: 1; visibility: visible; }
        #backToTop:hover { transform: translateY(-5px); background: #2a5298; }

        /* Serial item styles */
        .serial-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 0;
            border-bottom: 1px solid #f1f3f5;
            transition: background 0.2s;
        }
        .serial-item:last-child { border-bottom: none; }
        .serial-item:hover { background: #f8f9fa; }
        .serial-thumb {
            width: 50px;
            height: 70px;
            flex-shrink: 0;
            background: #f1f3f5;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .serial-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .serial-thumb .fa-newspaper {
            font-size: 24px;
            color: #adb5bd;
        }
        .serial-info {
            flex: 1;
            min-width: 0;
        }
        .serial-info .title {
            font-weight: 600;
            font-size: 0.85rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .serial-info .meta {
            font-size: 0.7rem;
            color: #6c757d;
        }
        .serial-info .meta i {
            margin-right: 4px;
        }
        .serial-scroll {
            max-height: 350px;
            overflow-y: auto;
            padding-right: 5px;
        }
        .serial-scroll::-webkit-scrollbar { width: 4px; }
        .serial-scroll::-webkit-scrollbar-thumb { background: var(--primary-color); border-radius: 4px; }

        @media (max-width: 1200px) { .book-cover, .ebook-cover { height: 280px; } .swiper-slide { width: 220px; } }
        @media (max-width: 992px) { .main-layout { flex-direction: column; } .left-column, .right-column { flex: 0 0 100%; width: 100%; } }
        @media (max-width: 768px) {
            .book-cover, .ebook-cover { height: 240px; } .swiper-slide { width: 190px; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
            .stats-card h3 { font-size: 1.2rem; }
            .quote-text { font-size: 1rem; }
            .chat-window { width: 300px; height: 450px; right: 10px; bottom: 140px; }
            .chatbot-btn { width: 50px; height: 50px; font-size: 24px; bottom: 80px; right: 15px; }
            .book-of-day-img { max-height: 200px !important; }
            .serial-thumb { width: 40px; height: 56px; }
            .serial-info .title { font-size: 0.75rem; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr 1fr; }
        }
        <?= $opacCustomCss ?>
    </style>
</head>
<body data-aos-easing="ease-out-back" data-aos-duration="800">

<button id="backToTop" title="Back to top"><i class="fas fa-chevron-up"></i></button>

<!-- ==================== HEADER ==================== -->
<div class="header-bg">
    <div class="header-container">
        <div class="header-left"><img src="<?= htmlspecialchars($logoUrl) ?>" alt="Library Logo" loading="lazy"></div>
        <div class="header-title"><h1><?= htmlspecialchars($displayHeaderText) ?></h1><p><?= htmlspecialchars($displayTagline) ?></p></div>
        <div class="header-right">
            <a href="semantic_search.php" class="lang-switch me-2" style="background:#ffc107; color:#333;"><i class="fas fa-brain"></i> <?= __('semantic_search') ?></a>
            <!-- LANGUAGE SWITCHER -->
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-custom text-center mt-3">
        <?php if ($memberLoggedIn): ?>
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" id="memberDropdownBtn">
                    <i class="fas fa-user-circle"></i> <?= htmlspecialchars($memberData['name']) ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" id="viewAccountBtn"><i class="fas fa-user"></i> <?= __('my_account') ?></a></li>
                    <li><a class="dropdown-item" href="pay_fines.php"><i class="fas fa-money-bill-wave"></i> <?= __('pay_fines') ?></a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                            <button type="submit" name="logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i> <?= __('logout') ?></button>
                        </form>
                    </li>
                </ul>
            </div>
        <?php else: ?>
            <a href="login.php" class="btn btn-outline-light btn-sm me-2"><i class="fas fa-user-circle"></i> <?= __('member_login') ?></a>
        <?php endif; ?>
        <button type="button" class="btn btn-outline-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#suggestionModal"><i class="fas fa-lightbulb"></i> <?= __('suggest_inform') ?></button>
        <button class="btn btn-outline-info btn-sm me-2" data-bs-toggle="modal" data-bs-target="#advancedSearchModal"><i class="fas fa-search-plus"></i> <?= __('advanced_search') ?></button>
    </div>
</div>

<!-- ==================== MAIN CONTENT ==================== -->
<div class="container-custom">
    <!-- Notice -->
    <?php if ($opacShowNotices && !empty($opacNoticeContent)): ?>
    <div class="alert alert-warning alert-dismissible fade show mb-3 shadow-sm" role="alert">
        <strong><i class="fas fa-bullhorn"></i> <?= htmlspecialchars($opacNoticeTitle ?: __('library_notice')) ?>:</strong>
        <?= nl2br(htmlspecialchars($opacNoticeContent)) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="main-layout">
        <!-- LEFT COLUMN -->
        <div class="left-column">
            <div class="search-card" data-aos="fade-up">
                <ul class="nav nav-tabs justify-content-center flex-wrap" role="tablist">
                    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#generalTab" type="button"><i class="fas fa-layer-group me-1"></i><?= __('search_all_resources') ?></button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#booksTab" type="button"><i class="fas fa-book me-1"></i><?= __('books') ?></button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#ebooksTab" type="button"><i class="fas fa-file-pdf me-1"></i><?= __('ebooks') ?></button></li>
                    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#databasesTab" type="button"><i class="fas fa-database me-1"></i><?= __('research_databases') ?></button></li>
                </ul>

                <div class="tab-content">
                    <!-- General Search -->
                    <div class="tab-pane fade show active" id="generalTab" role="tabpanel">
                        <div class="text-center mb-3"><h4><?= __('search_all_resources') ?></h4><p class="text-muted small"><?= $displayTagline ?></p></div>
                        <div class="row g-2 mb-3">
                            <div class="col-md-8"><input type="text" id="generalSearchKeyword" class="form-control form-control-lg" placeholder="<?= __('search_by_title_author_subject') ?>" autocomplete="off"></div>
                            <div class="col-md-3"><select id="generalResourceType" class="form-select"><option value="all"><?= __('all_resources') ?></option><option value="books">📖 <?= __('books') ?></option><option value="ebooks">📱 <?= __('ebooks') ?></option><option value="databases">🗄️ <?= __('research_databases') ?></option></select></div>
                            <div class="col-md-1"><button class="btn btn-primary w-100 h-100" onclick="searchGeneral()"><i class="fas fa-search"></i></button></div>
                        </div>
                        <div class="row mb-2"><div class="col-12 text-center"><a href="semantic_search.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-brain"></i> <?= __('semantic_search') ?></a></div></div>
                        <div class="loader" id="generalLoader"><div class="spinner"></div><p><?= __('searching') ?></p></div>
                        <div id="generalResults" class="mt-3" style="display:none"></div>

                        <?php if ($opacShowTrending): ?>
                        <hr class="my-4">
                        <div class="section-header"><h5 class="section-title"><i class="fas fa-fire me-1" style="color:#ff6b6b"></i><?= __('trending_resources') ?></h5><span class="text-muted small"><?= __('auto_sliding') ?></span></div>
                        <div class="swiper swiper-trending">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide"><div class="trending-card p-3"><div class="d-flex align-items-center mb-3"><div class="rounded-3 p-2 me-2" style="background: var(--primary-color);"><i class="fas fa-book text-white fa-lg"></i></div><div><h6 class="mb-0 fw-bold"><?= __('most_popular_books') ?></h6><small class="text-muted"><?= __('most_issued_this_month') ?></small></div></div><?php foreach ($popularBooks as $book): ?><div class="d-flex justify-content-between align-items-center small py-2 border-bottom"><div><i class="fas fa-book text-primary me-1"></i><?= htmlspecialchars(substr($book['title'], 0, 35)) ?></div><span class="badge bg-primary rounded-pill"><?= $book['count'] ?></span></div><?php endforeach; ?></div></div>
                                <div class="swiper-slide"><div class="trending-card p-3"><div class="d-flex align-items-center mb-3"><div class="rounded-3 p-2 me-2" style="background:#dc3545;"><i class="fas fa-file-pdf text-white fa-lg"></i></div><div><h6 class="mb-0 fw-bold"><?= __('most_downloaded_ebooks') ?></h6><small class="text-muted"><?= __('top_picks') ?></small></div></div><?php foreach ($popularEbooksData as $ebook): ?><div class="d-flex justify-content-between align-items-center small py-2 border-bottom"><div><i class="fas fa-file-pdf text-danger me-1"></i><?= htmlspecialchars(substr($ebook['title'], 0, 35)) ?></div><span class="badge bg-danger rounded-pill"><?= $ebook['downloads'] ?></span></div><?php endforeach; ?></div></div>
                                <div class="swiper-slide"><div class="trending-card p-3"><div class="d-flex align-items-center mb-3"><div class="rounded-3 p-2 me-2" style="background:#17a2b8;"><i class="fas fa-database text-white fa-lg"></i></div><div><h6 class="mb-0 fw-bold"><?= __('featured_databases') ?></h6><small class="text-muted"><?= __('recommended_resources') ?></small></div></div><?php foreach (array_slice($featuredDatabases, 0, 4) as $dbItem): ?><div class="d-flex justify-content-between align-items-center small py-2 border-bottom"><div><i class="fas fa-database text-info me-1"></i><?= htmlspecialchars(substr($dbItem['name'], 0, 30)) ?></div><a href="<?= htmlspecialchars($dbItem['url']) ?>" target="_blank" class="btn btn-xs btn-link p-0"><i class="fas fa-external-link-alt"></i></a></div><?php endforeach; ?></div></div>
                            </div>
                            <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Books Search -->
                    <div class="tab-pane fade" id="booksTab" role="tabpanel">
                        <div class="text-center mb-3"><h4><?= __('search_physical_books') ?></h4><p class="text-muted small"><?= __('browse_printed_books') ?></p></div>
                        <div class="row g-2 mb-3">
                            <div class="col-md-8"><input type="text" id="searchKeyword" class="form-control" placeholder="<?= __('search_by_title_author_isbn') ?>" autocomplete="off"></div>
                            <div class="col-md-3"><select id="searchCategory" class="form-select"><option value="all"><?= __('all_categories') ?></option><?php foreach ($categories as $cat): ?><option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option><?php endforeach; ?></select></div>
                            <div class="col-md-1"><button class="btn btn-primary w-100" onclick="searchBooks()"><i class="fas fa-search"></i></button></div>
                        </div>
                        <div class="loader" id="bookLoader"><div class="spinner"></div><p><?= __('searching') ?></p></div>
                        <div id="bookResults" class="row g-3 mt-2 results-scroll-container" style="display:none"></div>
                    </div>

                    <!-- eBooks Search -->
                    <div class="tab-pane fade" id="ebooksTab" role="tabpanel">
                        <div class="text-center mb-3"><h4><?= __('search_ebooks') ?></h4><p class="text-muted small"><?= __('explore_digital_collection') ?></p></div>
                        <div class="row g-2 mb-3">
                            <div class="col-md-8"><input type="text" id="ebookSearchKeyword" class="form-control" placeholder="<?= __('search_by_title_author_subject') ?>" autocomplete="off"></div>
                            <div class="col-md-3"><select id="ebookSubject" class="form-select"><option value="all"><?= __('all_subjects') ?></option><?php foreach ($ebookSubjects as $subj): ?><option value="<?= htmlspecialchars($subj) ?>"><?= htmlspecialchars($subj) ?></option><?php endforeach; ?></select></div>
                            <div class="col-md-1"><button class="btn btn-primary w-100" onclick="searchEbooks()"><i class="fas fa-search"></i></button></div>
                        </div>
                        <div class="loader" id="ebookLoader"><div class="spinner"></div><p><?= __('searching') ?></p></div>
                        <div id="ebookResults" class="row g-3 mt-2 results-scroll-container" style="display:none"></div>
                    </div>

                    <!-- Databases Search -->
                    <div class="tab-pane fade" id="databasesTab" role="tabpanel">
                        <div class="text-center mb-3"><h4><?= __('search_databases') ?></h4><p class="text-muted small"><?= __('browse_databases') ?></p></div>
                        <div class="row g-2 mb-4">
                            <div class="col-md-8"><input type="text" id="databaseSearchKeyword" class="form-control" placeholder="<?= __('database_search_placeholder') ?>" autocomplete="off"></div>
                            <div class="col-md-3"><select id="databaseType" class="form-select"><option value="all"><?= __('all_database_types') ?></option><option value="academic"><?= __('academic_databases') ?></option><option value="open_access"><?= __('open_access') ?></option><option value="subscription"><?= __('subscription_based') ?></option></select></div>
                            <div class="col-md-1"><button class="btn btn-primary w-100" onclick="searchDatabases()"><i class="fas fa-search"></i></button></div>
                        </div>
                        <?php if ($opacShowDatabases && !empty($featuredDatabases)): ?>
                        <div class="section-header mt-3"><h5 class="section-title"><i class="fas fa-star me-1" style="color:#ffc107;"></i> <?= __('featured_databases') ?></h5></div>
                        <div class="row g-3 mb-4" id="featuredDatabases">
                            <?php foreach ($featuredDatabases as $database): ?>
                            <div class="col-md-6 col-lg-4"><div class="database-card"><div class="database-icon"><i class="fas fa-<?= htmlspecialchars($database['icon'] ?: 'database') ?>"></i></div><h6 class="fw-bold mb-2"><?= htmlspecialchars($database['name']) ?></h6><p class="small text-muted mb-2"><?= htmlspecialchars(substr($database['description'], 0, 80)) ?>...</p><span class="type-badge type-<?= $database['type'] ?> mb-2 d-inline-block"><?= $database['type'] == 'academic' ? __('academic_databases') : ($database['type'] == 'open_access' ? __('open_access') : __('subscription_based')) ?></span><div class="mt-2"><a href="<?= htmlspecialchars($database['url']) ?>" target="_blank" class="btn btn-database btn-sm w-100"><i class="fas fa-external-link-alt me-1"></i> <?= __('access_database') ?></a></div></div></div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                        <div class="loader" id="databaseLoader"><div class="spinner"></div><p><?= __('searching') ?></p></div>
                        <div id="databaseResults" class="row g-3 mt-2" style="display:none"></div>
                    </div>
                </div>
            </div>

            <!-- New Arrivals in Left -->
            <?php if ($opacShowNewArrivals && $opacShowNewArrivalsInLeft && !empty($newArrivals)): ?>
            <div class="mt-4" data-aos="fade-up">
                <h3 class="section-title-center"><i class="fas fa-star me-2" style="color:#ffc107;"></i> <?= __('new_arrivals') ?></h3>
                <div class="swiper swiper-new-arrivals" data-aos="fade-up" data-aos-delay="100">
                    <div class="swiper-wrapper">
                        <?php foreach ($newArrivals as $book): 
                            $coverBase64 = getCoverImageSrc($book['cover_path'] ?? '');
                            $isAvailable = ($book['available'] > 0);
                            $statusBadge = $isAvailable ? '<span class="badge bg-success">'.__('available').'</span>' : '<span class="badge bg-danger">'.__('issued').'</span>';
                            $whomBtn = !$isAvailable ? '<button class="btn btn-sm btn-outline-secondary whom-btn mt-1" data-book-id="'.$book['id'].'" data-book-title="'.htmlspecialchars($book['title']).'">'.__('whom').'</button>' : '';
                        ?>
                        <div class="swiper-slide">
                            <div class="book-card" onclick="viewBook(<?= $book['id'] ?>)">
                                <div class="book-cover"><?php if ($coverBase64): ?><img src="<?= htmlspecialchars($coverBase64) ?>" alt="<?= htmlspecialchars($book['title']) ?>" loading="lazy"><?php else: ?><i class="fas fa-book fa-4x text-muted"></i><?php endif; ?></div>
                                <div class="card-body p-3 text-center">
                                    <h6 class="card-title fw-semibold fs-6 mb-1"><?= htmlspecialchars(substr($book['title'], 0, 35)) ?></h6>
                                    <p class="small text-muted mb-2"><?= htmlspecialchars($book['author'] ?? __('unknown_author')) ?></p>
                                    <div class="d-flex justify-content-center gap-2"><?= $statusBadge ?><?= $whomBtn ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- RIGHT COLUMN – STATS WITH AUTO-FLIP (VISITOR COUNTER) -->
        <div class="right-column">
            <div class="stats-grid" data-aos="fade-up" data-aos-delay="100">
                <!-- Card 1: Today's Date ↔ Day of Week -->
                <div class="stats-card" id="statCard1">
                    <div class="stats-card-inner">
                        <div class="front">
                            <i class="fas fa-calendar-alt" style="color: #28a745;"></i>
                            <h3><?= htmlspecialchars($todayDate) ?></h3>
                            <p><?= __('today') ?></p>
                        </div>
                        <div class="back">
                            <i class="fas fa-calendar-check small-icon"></i>
                            <h3><?= htmlspecialchars($dayOfWeek) ?></h3>
                            <p><?= __('day_of_week') ?></p>
                        </div>
                    </div>
                </div>
                <!-- Card 2: Current Time (AM/PM) ↔ Visitor Counter -->
                <div class="stats-card" id="statCard2">
                    <div class="stats-card-inner">
                        <div class="front">
                            <i class="fas fa-clock" style="color: #ffc107;"></i>
                            <h3><?= htmlspecialchars($currentTime) ?></h3>
                            <p><?= __('current_time') ?></p>
                        </div>
                        <div class="back">
                            <i class="fas fa-user-friends small-icon"></i>
                            <h3><?= number_format($visitorsToday) ?></h3>
                            <p><?= __('visitors_today') ?></p>
                            <small style="font-size:0.7rem; opacity:0.8;"><?= __('total_visitors') ?>: <?= number_format($totalVisitors) ?></small>
                        </div>
                    </div>
                </div>
                <!-- Card 3: Total Books ↔ Total eBooks -->
                <div class="stats-card" id="statCard3">
                    <div class="stats-card-inner">
                        <div class="front">
                            <i class="fas fa-book" style="color: #007bff;"></i>
                            <h3><?= number_format($totalBooks) ?></h3>
                            <p><?= __('total_books') ?></p>
                        </div>
                        <div class="back">
                            <i class="fas fa-file-pdf small-icon"></i>
                            <h3><?= number_format($totalEbooks) ?></h3>
                            <p><?= __('total_ebooks') ?></p>
                        </div>
                    </div>
                </div>
                <!-- Card 4: Research Databases ↔ Registered Members -->
                <div class="stats-card" id="statCard4">
                    <div class="stats-card-inner">
                        <div class="front">
                            <i class="fas fa-database" style="color: #17a2b8;"></i>
                            <h3><?= number_format($totalDatabases) ?></h3>
                            <p><?= __('total_databases') ?></p>
                        </div>
                        <div class="back">
                            <i class="fas fa-users small-icon"></i>
                            <h3><?= number_format($totalMembers) ?></h3>
                            <p><?= __('total_members') ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($memberLoggedIn && $memberData['total_fines'] > 0): ?>
            <div class="alert alert-danger text-center" data-aos="fade-up" data-aos-delay="150">
                <i class="fas fa-rupee-sign"></i> <?= __('fine_total') ?>: ₹<?= number_format($memberData['total_fines'], 2) ?>
                <a href="pay_fines.php" class="btn btn-sm btn-warning ms-2"><?= __('pay_fines') ?></a>
            </div>
            <?php endif; ?>

            <!-- ========== SERIALS or BOOK OF THE DAY ========== -->
            <?php if ($showSerials && !empty($recentSerials)): ?>
            <div class="serial-card" data-aos="fade-up" data-aos-delay="150" id="serialCard">
                <h5><i class="fas fa-newspaper text-primary"></i> <?= __('recent_serials') ?></h5>
                <div class="serial-scroll">
                    <?php foreach ($recentSerials as $serial): ?>
                        <div class="serial-item">
                            <div class="serial-thumb">
                                <?php if (!empty($serial['cover_base64'])): ?>
                                    <img src="<?= htmlspecialchars($serial['cover_base64']) ?>" alt="<?= htmlspecialchars($serial['title']) ?>" loading="lazy">
                                <?php else: ?>
                                    <i class="fas fa-newspaper"></i>
                                <?php endif; ?>
                            </div>
                            <div class="serial-info">
                                <div class="title" title="<?= htmlspecialchars($serial['title']) ?>"><?= htmlspecialchars($serial['title']) ?></div>
                                <div class="meta">
                                    <?php if (!empty($serial['frequency'])): ?>
                                        <span><i class="fas fa-calendar-alt"></i> <?= ucfirst($serial['frequency']) ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($serial['subscription_type'])): ?>
                                        <span class="ms-2"><i class="fas fa-<?= $serial['subscription_type'] == 'online' ? 'globe' : ($serial['subscription_type'] == 'print' ? 'print' : 'exchange-alt') ?>"></i> <?= ucfirst($serial['subscription_type']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (count($recentSerials) >= 20): ?>
                    <div class="text-center mt-2">
                        <a href="serials.php" class="btn btn-sm btn-outline-primary"><?= __('view_all') ?></a>
                    </div>
                <?php endif; ?>
            </div>
            <?php elseif ($bookOfTheDay && !empty($bookOfTheDay['title'])): ?>
            <!-- Book of the Day (fallback) -->
            <div class="book-of-day-card" data-aos="fade-up" data-aos-delay="150" id="bookOfDayCard">
                <h6><i class="fas fa-crown text-warning"></i> <?= __('book_of_the_day') ?></h6>
                <div class="text-center">
                    <?php if (!empty($bookOfTheDay['cover_base64'])): ?>
                        <img src="<?= htmlspecialchars($bookOfTheDay['cover_base64']) ?>" class="book-of-day-img" alt="Book cover" loading="lazy">
                    <?php else: ?>
                        <div style="height:200px; display:flex; align-items:center; justify-content:center; background:#f8f9fa; border-radius:16px;"><i class="fas fa-book fa-6x text-muted"></i></div>
                    <?php endif; ?>
                    <h6 class="mt-2 fw-bold"><?= htmlspecialchars($bookOfTheDay['title']) ?></h6>
                    <p class="small text-muted"><?= htmlspecialchars($bookOfTheDay['author'] ?? __('unknown_author')) ?><br><?= htmlspecialchars($bookOfTheDay['year'] ?? '') ?></p>
                    <button class="btn btn-sm btn-outline-primary" onclick="viewBook(<?= $bookOfTheDay['id'] ?>)"><?= __('view_details') ?></button>
                </div>
            </div>
            <?php endif; ?>

            <!-- New Arrivals in Right -->
            <?php if ($opacShowNewArrivals && !$opacShowNewArrivalsInLeft && !empty($newArrivals)): ?>
            <div class="mt-4" data-aos="fade-up">
                <h5 class="section-title"><i class="fas fa-star me-1" style="color:#ffc107;"></i> <?= __('new_arrivals') ?></h5>
                <div class="swiper swiper-new-arrivals-right" data-aos="fade-up" data-aos-delay="100">
                    <div class="swiper-wrapper">
                        <?php foreach ($newArrivals as $book):
                            $coverBase64 = getCoverImageSrc($book['cover_path'] ?? '');
                            $isAvailable = ($book['available'] > 0);
                            $statusBadge = $isAvailable ? '<span class="badge bg-success">'.__('available').'</span>' : '<span class="badge bg-danger">'.__('issued').'</span>';
                            $whomBtn = !$isAvailable ? '<button class="btn btn-sm btn-outline-secondary whom-btn mt-1" data-book-id="'.$book['id'].'" data-book-title="'.htmlspecialchars($book['title']).'">'.__('whom').'</button>' : '';
                        ?>
                        <div class="swiper-slide">
                            <div class="book-card" onclick="viewBook(<?= $book['id'] ?>)">
                                <div class="book-cover" style="height:200px;"><?php if ($coverBase64): ?><img src="<?= htmlspecialchars($coverBase64) ?>" alt="<?= htmlspecialchars($book['title']) ?>" loading="lazy"><?php else: ?><i class="fas fa-book fa-3x text-muted"></i><?php endif; ?></div>
                                <div class="card-body p-2 text-center">
                                    <h6 class="card-title fw-semibold fs-6 mb-0"><?= htmlspecialchars(substr($book['title'], 0, 30)) ?></h6>
                                    <p class="small text-muted mb-1"><?= htmlspecialchars($book['author'] ?? __('unknown_author')) ?></p>
                                    <div class="d-flex justify-content-center gap-1"><?= $statusBadge ?><?= $whomBtn ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Member Info Panel -->
            <div id="memberInfoPanel" class="member-info-container" style="display: none;"></div>
            <div id="memberAccountPanel" class="member-info-container" style="display: none;">
                <h6><i class="fas fa-user-circle"></i> <?= __('account_summary') ?></h6>
                <div id="accountSummaryContent"><?= __('loading') ?></div>
            </div>

            <div class="hours-card" data-aos="fade-up" data-aos-delay="200">
                <?= getLibraryHoursHTML() ?>
            </div>

            <?php if ($opacShowThoughtOfTheDay && !empty($quotes)): ?>
            <div class="thought-card" data-aos="fade-up" data-aos-delay="250" id="thoughtCard">
                <h5><i class="fas fa-lightbulb text-warning"></i> <?= __('thought_of_the_day') ?></h5>
                <div id="quoteContainer">
                    <div class="quote-text" id="quoteText"><?= htmlspecialchars($quotes[0]['text']) ?></div>
                    <div class="quote-author" id="quoteAuthor">— <?= htmlspecialchars($quotes[0]['author'] ?? __('quote_author_unknown')) ?></div>
                </div>
                <div class="text-center mt-3"><button class="refresh-quote-btn" onclick="refreshQuote()"><i class="fas fa-sync-alt"></i> <?= __('refresh_quote') ?></button></div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recommendations -->
    <?php if ($memberLoggedIn && !empty($recommendations)): ?>
    <div class="section-header-center mt-5" data-aos="fade-up"><h3 class="section-title-center"><i class="fas fa-thumbs-up me-2" style="color:#28a745;"></i> <?= __('recommended_for_you') ?></h3></div>
    <div class="swiper swiper-recommendations" data-aos="fade-up" data-aos-delay="100">
        <div class="swiper-wrapper">
            <?php foreach ($recommendations as $rec):
                $cover = getCoverImageSrc($rec['cover_path'] ?? '');
                $isAvailable = ($rec['available'] > 0);
                $statusBadge = $isAvailable ? '<span class="badge bg-success">'.__('available').'</span>' : '<span class="badge bg-danger">'.__('issued').'</span>';
                $whomBtn = !$isAvailable ? '<button class="btn btn-sm btn-outline-secondary whom-btn mt-1" data-book-id="'.$rec['id'].'" data-book-title="'.htmlspecialchars($rec['title']).'">'.__('whom').'</button>' : '';
            ?>
            <div class="swiper-slide">
                <div class="book-card" onclick="viewBook(<?= $rec['id'] ?>)">
                    <div class="book-cover"><?= $cover ? '<img src="'.htmlspecialchars($cover).'" loading="lazy">' : '<i class="fas fa-book fa-4x text-muted"></i>' ?></div>
                    <div class="card-body p-3 text-center">
                        <h6 class="card-title fw-semibold fs-6 mb-1"><?= htmlspecialchars(substr($rec['title'], 0, 35)) ?></h6>
                        <p class="small text-muted"><?= htmlspecialchars($rec['author'] ?? __('unknown_author')) ?></p>
                        <div class="d-flex justify-content-center gap-2"><?= $statusBadge ?><?= $whomBtn ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
    </div>
    <?php endif; ?>

    <!-- Popular eBooks -->
    <?php if ($opacShowPopularEbooks && !empty($popularEbooks)): ?>
    <div class="section-header mt-4" data-aos="fade-up"><h5 class="section-title"><i class="fas fa-fire me-1" style="color:#ff6b6b;"></i> <?= __('most_popular_ebooks') ?></h5><span class="text-muted small"><?= __('auto_sliding') ?></span></div>
    <div class="swiper swiper-popular-ebooks" data-aos="fade-up" data-aos-delay="100">
        <div class="swiper-wrapper">
            <?php foreach ($popularEbooks as $ebook):
                $coverBase64 = getCoverImageSrc($ebook['cover_path'] ?? '');
            ?>
            <div class="swiper-slide"><div class="ebook-card h-100"><div class="ebook-cover"><?php if ($coverBase64): ?><img src="<?= htmlspecialchars($coverBase64) ?>" alt="<?= htmlspecialchars($ebook['title']) ?>" loading="lazy"><?php else: ?><i class="fas fa-file-pdf fa-4x text-white"></i><?php endif; ?></div><div class="card-body p-3 text-center"><h6 class="card-title fw-semibold fs-6 mb-1"><?= htmlspecialchars(substr($ebook['title'], 0, 35)) ?></h6><p class="small text-muted mb-2"><?= htmlspecialchars($ebook['author'] ?? __('unknown_author')) ?></p><button class="btn btn-danger btn-sm rounded-pill px-3" onclick="event.stopPropagation(); downloadEbook(<?= $ebook['id'] ?>, '<?= htmlspecialchars($ebook['title']) ?>')"><i class="fas fa-download me-1"></i> <?= __('download') ?></button></div></div></div>
            <?php endforeach; ?>
        </div>
        <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
    </div>
    <?php endif; ?>

    <!-- Latest eBooks -->
    <?php if ($opacShowLatestEbooks && !empty($newEbooks)): ?>
    <div class="section-header mt-4" data-aos="fade-up"><h5 class="section-title"><i class="fas fa-newspaper me-1" style="color:#17a2b8;"></i> <?= __('latest_ebooks') ?></h5><span class="text-muted small"><?= __('auto_sliding') ?></span></div>
    <div class="swiper swiper-latest-ebooks" data-aos="fade-up" data-aos-delay="100">
        <div class="swiper-wrapper">
            <?php foreach ($newEbooks as $ebook):
                $coverBase64 = getCoverImageSrc($ebook['cover_path'] ?? '');
            ?>
            <div class="swiper-slide"><div class="ebook-card h-100"><div class="ebook-cover"><?php if ($coverBase64): ?><img src="<?= htmlspecialchars($coverBase64) ?>" alt="<?= htmlspecialchars($ebook['title']) ?>" loading="lazy"><?php else: ?><i class="fas fa-file-pdf fa-4x text-white"></i><?php endif; ?></div><div class="card-body p-3 text-center"><h6 class="card-title fw-semibold fs-6 mb-1"><?= htmlspecialchars(substr($ebook['title'], 0, 35)) ?></h6><p class="small text-muted mb-2"><?= htmlspecialchars($ebook['author'] ?? __('unknown_author')) ?></p><button class="btn btn-primary btn-sm rounded-pill px-3" onclick="event.stopPropagation(); downloadEbook(<?= $ebook['id'] ?>, '<?= htmlspecialchars($ebook['title']) ?>')"><i class="fas fa-download me-1"></i> <?= __('download') ?></button></div></div></div>
            <?php endforeach; ?>
        </div>
        <div class="swiper-button-next"></div><div class="swiper-button-prev"></div><div class="swiper-pagination"></div>
    </div>
    <?php endif; ?>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="container-custom">
        <div class="row">
            <div class="col-md-4 mb-3"><h6><i class="fas fa-building"></i> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></h6><?php if (!empty($institution['address'])): ?><p class="small"><?= nl2br(htmlspecialchars($institution['address'])) ?></p><?php endif; ?></div>
            <div class="col-md-4 mb-3"><h6><i class="fas fa-link"></i> <?= __('quick_links') ?></h6><ul class="list-unstyled small">
                <li><a href="new_arrivals.php"><i class="fas fa-star"></i> <?= __('new_arrivals') ?></a></li>
                <li><a href="ebooks.php"><i class="fas fa-file-pdf"></i> <?= __('ebooks') ?></a></li>
                <li><a href="digital_hub.php"><i class="fas fa-globe"></i> <?= __('digital_hub') ?></a></li>
            </ul></div>
            <div class="col-md-4 mb-3"><h6><i class="fas fa-clock"></i> <?= __('library_hours') ?></h6><?php $hours = getLibraryHours(); $daysMap = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun']; $openDays = array_map(function($d) use ($daysMap) { return $daysMap[$d]; }, $hours['open_days']); ?><p class="small mb-1"><strong><?= __('open_days') ?>:</strong> <?= implode(', ', $openDays) ?></p><p class="small mb-0"><strong><?= __('hours') ?>:</strong> <?= $hours['open_time'] ?> - <?= $hours['close_time'] ?></p></div>
        </div>
        <hr class="opacity-25"><div class="text-center"><p class="small mb-0">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. <?= __('all_rights_reserved') ?></p><p class="small mt-1"><?= __('designed_by') ?> <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank">Sameermon</a></p></div>
    </div>
</footer>

<!-- Modals -->
<div class="modal fade" id="bookModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4 border-0"><div class="modal-header bg-gradient text-white" style="background: linear-gradient(135deg, #1e3c72, #2a5298)"><h5 class="modal-title"><i class="fas fa-book me-2"></i><?= __('book_details') ?></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div id="bookDetailsContent" class="modal-body p-4"></div></div></div></div>

<div class="modal fade" id="suggestionModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4"><div class="modal-header bg-warning text-dark"><h5 class="modal-title"><i class="fas fa-lightbulb"></i> <?= __('suggest_book') ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><form id="suggestionForm"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>"><input type="hidden" name="submit_suggestion" value="1"><div class="mb-3"><label class="form-label"><?= __('your_admission_number') ?></label><input type="text" class="form-control" name="member_admno" required placeholder="e.g., MEM001"></div><div class="mb-3"><label class="form-label"><?= __('your_full_name') ?></label><input type="text" class="form-control" name="member_name" required></div><div class="mb-3"><label class="form-label"><?= __('book_title') ?></label><input type="text" class="form-control" name="title" required></div><div class="mb-3"><label class="form-label"><?= __('author_optional') ?></label><input type="text" class="form-control" name="author"></div><div class="mb-3"><label class="form-label"><?= __('isbn_optional') ?></label><input type="text" class="form-control" name="isbn"></div><div class="mb-3"><label class="form-label"><?= __('reason_for_suggestion') ?></label><textarea class="form-control" name="reason" rows="3" required placeholder="<?= __('why_recommend') ?>"></textarea></div><div class="alert alert-info small py-2"><i class="fas fa-info-circle"></i> <?= __('suggestion_info') ?></div></form></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?= __('cancel') ?></button><button type="button" class="btn btn-warning" id="submitSuggestionBtn"><?= __('submit') ?></button></div></div></div></div>

<div class="modal fade" id="advancedSearchModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5 class="modal-title"><i class="fas fa-search-plus"></i> <?= __('search_books_advanced') ?></h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <form id="advancedSearchForm">
                    <div class="row g-3">
                        <div class="col-md-12"><label class="form-label"><?= __('keyword') ?></label><input type="text" id="adv_keyword" class="form-control" placeholder="<?= __('search_by_title_author_subject') ?>"></div>
                        <div class="col-md-6"><label class="form-label"><?= __('author') ?></label><input type="text" id="adv_author" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label"><?= __('publisher') ?></label><input type="text" id="adv_publisher" class="form-control"></div>
                        <div class="col-md-4"><label class="form-label"><?= __('year_from') ?></label><input type="number" id="adv_year_from" class="form-control" min="1900" max="<?= date('Y') ?>"></div>
                        <div class="col-md-4"><label class="form-label"><?= __('year_to') ?></label><input type="number" id="adv_year_to" class="form-control" min="1900" max="<?= date('Y') ?>"></div>
                        <div class="col-md-4"><label class="form-label"><?= __('language') ?></label><select id="adv_language" class="form-select"><option value="">All</option><option>English</option><option>Arabic</option><option>French</option><option>German</option><option>Spanish</option></select></div>
                        <div class="col-md-12"><label class="form-label"><?= __('curriculum') ?></label><input type="text" id="adv_curriculum" class="form-control" placeholder="e.g., CBSE, ICSE"></div>
                        <div class="col-md-12"><label class="form-label"><?= __('isbn') ?></label><input type="text" id="adv_isbn" class="form-control"></div>
                    </div>
                </form>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?= __('cancel') ?></button><button type="button" class="btn btn-primary" id="doAdvancedSearch"><i class="fas fa-search"></i> <?= __('search') ?></button></div>
        </div>
    </div>
</div>

<!-- Toast -->
<div class="toast-container position-fixed bottom-0 end-0 p-3"><div id="suggestionToast" class="toast align-items-center text-white bg-success border-0" role="alert" data-bs-autohide="true" data-bs-delay="5000"><div class="d-flex"><div class="toast-body small"></div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div></div>

<!-- Chatbot -->
<button class="chatbot-btn" id="chatbotToggle"><i class="fab fa-whatsapp"></i></button>
<div class="chat-window" id="chatWindow">
    <div class="chat-header"><span><i class="fas fa-robot"></i> <?= __('library_assistant') ?></span><button class="btn-close btn-close-white" id="closeChat" style="background: none; border: none; font-size: 20px;">&times;</button></div>
    <div class="chat-messages" id="chatMessages"><div class="message bot"><div class="bubble"><?= __('hello_chat') ?></div></div></div>
    <div class="chat-input-area"><input type="text" id="chatInput" placeholder="<?= __('type_question') ?>" autocomplete="off"><button id="sendChat"><i class="fas fa-paper-plane"></i></button></div>
</div>

<!-- WhatsApp -->
<?php $whatsappNumber = $settings['whatsapp_number'] ?? ''; $whatsappMessage = urlencode($settings['whatsapp_message'] ?? 'Hello, I need assistance from the library.'); if (!empty($whatsappNumber)): ?><a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsappNumber) ?>?text=<?= $whatsappMessage ?>" class="whatsapp-float" target="_blank"><i class="fab fa-whatsapp"></i></a><?php endif; ?>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
AOS.init({ once: true, offset: 20 });

// ==================== QUOTE ROTATION ====================
const quotesList = <?php echo json_encode($quotes); ?>;
let currentQuoteIndex = Math.floor(Math.random() * quotesList.length);
let quoteRotationInterval = null;
function displayQuote(index) {
    if (!quotesList[index]) return;
    document.getElementById('quoteText').innerHTML = escapeHtml(quotesList[index].text);
    document.getElementById('quoteAuthor').innerHTML = '— ' + escapeHtml(quotesList[index].author || '<?= __('quote_author_unknown') ?>');
}
function refreshQuote() {
    if (quotesList.length <= 1) return;
    currentQuoteIndex = (currentQuoteIndex + 1) % quotesList.length;
    displayQuote(currentQuoteIndex);
    if (quoteRotationInterval) {
        clearInterval(quoteRotationInterval);
        quoteRotationInterval = setInterval(() => {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotesList.length;
            displayQuote(currentQuoteIndex);
        }, <?= (int)($opacQuoteRotationInterval * 1000) ?>);
    }
}
if (quotesList.length > 0) {
    displayQuote(currentQuoteIndex);
    if (<?= $opacQuoteRotationInterval ?> > 0 && quotesList.length > 1) {
        quoteRotationInterval = setInterval(() => {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotesList.length;
            displayQuote(currentQuoteIndex);
        }, <?= (int)($opacQuoteRotationInterval * 1000) ?>);
    }
}

// ==================== MEMBER ACCOUNT ====================
function loadAccountSummary() {
    const panel = document.getElementById('accountSummaryContent');
    if (!panel) return;
    panel.innerHTML = '<div class="text-center"><div class="spinner-border spinner-border-sm text-primary"></div> <?= __('loading') ?></div>';
    fetch('?ajax=account_data')
        .then(res => res.json())
        .then(data => {
            if (!data.success) { panel.innerHTML = '<div class="alert alert-danger"><?= __('error_loading') ?></div>'; return; }
            let html = `<div class="small"><strong><?= __('loan_count') ?>:</strong> ${data.loans.length}</div>`;
            if (data.loans.length > 0) {
                html += '<ul class="list-unstyled small mt-2">';
                data.loans.forEach(loan => {
                    const statusText = loan.status === 'overdue' ? '⚠️ Overdue' : '📖 Issued';
                    html += `<li><i class="fas fa-book"></i> ${escapeHtml(loan.title)} <span class="text-muted"><?= __('due_date') ?>: ${loan.due_date}</span> <span class="badge ${loan.status === 'overdue' ? 'bg-danger' : 'bg-primary'}">${statusText}</span></li>`;
                });
                html += '</ul>';
            } else { html += '<p class="text-muted small mt-1"><?= __('no_loans') ?></p>'; }
            html += `<div><strong><?= __('hold_count') ?>:</strong> ${data.holds.length}</div>`;
            if (data.holds.length > 0) {
                html += '<ul class="list-unstyled small mt-2">';
                data.holds.forEach(hold => {
                    html += `<li><i class="fas fa-hand-paper"></i> ${escapeHtml(hold.title)} (${hold.status}) <button class="btn btn-link btn-sm p-0 cancel-hold-btn" data-hold-id="${hold.id}"><?= __('cancel_hold') ?></button></li>`;
                });
                html += '</ul>';
            } else { html += '<p class="text-muted small mt-1"><?= __('no_holds') ?></p>'; }
            html += `<div><strong><?= __('fine_total') ?>:</strong> ₹${parseFloat(data.fines).toFixed(2)} <a href="pay_fines.php" class="btn btn-link btn-sm"><?= __('pay_fines') ?></a></div>`;
            panel.innerHTML = html;
            document.querySelectorAll('.cancel-hold-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const holdId = btn.getAttribute('data-hold-id');
                    if (confirm('Cancel this hold?')) {
                        fetch(window.location.href, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: `cancel_hold=1&hold_id=${holdId}&csrf_token=<?= $csrf_token ?>`
                        }).then(r => r.json()).then(res => {
                            if (res.success) loadAccountSummary();
                            else alert(res.error);
                        });
                    }
                });
            });
        })
        .catch(() => panel.innerHTML = '<div class="alert alert-danger"><?= __('error_loading') ?></div>');
}

document.getElementById('viewAccountBtn')?.addEventListener('click', (e) => {
    e.preventDefault();
    const panel = document.getElementById('memberAccountPanel');
    if (panel.style.display === 'none') { panel.style.display = 'block'; loadAccountSummary(); }
    else { panel.style.display = 'none'; }
});

// ==================== CHATBOT ====================
const toggleBtn = document.getElementById('chatbotToggle');
const chatWindow = document.getElementById('chatWindow');
const closeChat = document.getElementById('closeChat');
const sendBtn = document.getElementById('sendChat');
const chatInput = document.getElementById('chatInput');
const chatMessages = document.getElementById('chatMessages');
toggleBtn.addEventListener('click', () => { chatWindow.style.display = 'flex'; toggleBtn.style.display = 'none'; });
closeChat.addEventListener('click', () => { chatWindow.style.display = 'none'; toggleBtn.style.display = 'flex'; });
function addMessage(text, isUser) {
    const div = document.createElement('div');
    div.className = `message ${isUser ? 'user' : 'bot'}`;
    div.innerHTML = `<div class="bubble">${text}</div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
async function sendMessage() {
    const msg = chatInput.value.trim();
    if (!msg) return;
    addMessage(msg, true);
    chatInput.value = '';
    const lower = msg.toLowerCase();
    let reply = '';
    if (lower.includes('hour') || lower.includes('timing')) {
        reply = "<?= addslashes(strip_tags(getLibraryHoursHTML())) ?>";
    } else if (lower.includes('book') || lower.includes('search')) {
        reply = "You can use the search bar above. For semantic search, select 'Semantic Search' from the dropdown or click the button in the header.";
    } else if (lower.includes('fine') || lower.includes('overdue')) {
        reply = "Overdue fines are calculated per day. Please contact the circulation desk for exact amount.";
    } else {
        reply = "Thank you for your message. A librarian will get back to you shortly. Meanwhile, you can search our catalog above.";
    }
    setTimeout(() => addMessage(reply, false), 500);
}
sendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });

// ==================== HELPER FUNCTIONS ====================
function escapeHtml(s) { if (!s) return ''; return s.replace(/[&<>]/g, function(m) { if (m === '&') return '&amp;'; if (m === '<') return '&lt;'; if (m === '>') return '&gt;'; return m; }); }

// ==================== WHOM ====================
let memberPanelTimeout = null;
let currentBookIdForPanel = null;

function showMemberInfo(bookId, bookTitle) {
    if (memberPanelTimeout) clearTimeout(memberPanelTimeout);
    currentBookIdForPanel = bookId;
    const memberPanelDiv = document.getElementById('memberInfoPanel');
    if (!memberPanelDiv) return;
    
    // Determine which card to hide (serial or book-of-day)
    const serialCard = document.getElementById('serialCard');
    const bookOfDayCard = document.getElementById('bookOfDayCard');
    let targetCard = serialCard || bookOfDayCard;
    
    if (targetCard) {
        targetCard.style.transition = 'opacity 0.3s ease';
        targetCard.style.opacity = '0';
        setTimeout(() => {
            if (targetCard) targetCard.style.display = 'none';
            memberPanelDiv.style.display = 'block';
            memberPanelDiv.style.opacity = '0';
            memberPanelDiv.style.transition = 'opacity 0.3s ease';
            memberPanelDiv.style.opacity = '1';
        }, 300);
    } else { memberPanelDiv.style.display = 'block'; }
    
    memberPanelDiv.innerHTML = `<div class="text-center p-4"><div class="spinner-border text-primary"></div><p>Loading member info...</p></div>`;
    fetch(`get_book_holder.php?book_id=${bookId}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                memberPanelDiv.innerHTML = `<div class="alert alert-danger">${escapeHtml(data.error)}</div>`;
                memberPanelTimeout = setTimeout(restoreOriginalCard, 5000);
                return;
            }
            const m = data.member;
            const overdueClass = m.is_overdue ? 'text-danger fw-bold' : 'text-success';
            const daysText = m.is_overdue ? `Overdue by ${m.days_remaining} days` : `${m.days_remaining} days remaining`;
            let photoHtml = '';
            if (m.photo) {
                const photoUrl = getMemberPhotoUrl(m.photo);
                if (photoUrl) photoHtml = `<img src="${photoUrl}" class="whom-photo" alt="Member Photo" loading="lazy">`;
                else photoHtml = `<div class="whom-photo-placeholder"><i class="fas fa-user"></i></div>`;
            } else { photoHtml = `<div class="whom-photo-placeholder"><i class="fas fa-user"></i></div>`; }
            memberPanelDiv.innerHTML = `
                <div class="member-info-card">
                    <div class="d-flex align-items-start gap-3">
                        ${photoHtml}
                        <div style="flex:1;">
                            <h5 class="mb-1">${escapeHtml(m.name)}</h5>
                            <p class="small text-muted mb-0">ID: ${escapeHtml(m.member_id)}</p>
                            ${m.employee_id ? `<p class="small text-muted">Emp ID: ${escapeHtml(m.employee_id)}</p>` : ''}
                            ${m.class_section ? `<p class="small">Class: ${escapeHtml(m.class_section)}</p>` : ''}
                            ${m.department ? `<p class="small">Dept: ${escapeHtml(m.department)}</p>` : ''}
                            <p class="small"><i class="fas fa-phone-alt"></i> ${escapeHtml(m.mobile)}</p>
                            ${m.email ? `<p class="small"><i class="fas fa-envelope"></i> ${escapeHtml(m.email)}</p>` : ''}
                        </div>
                    </div>
                    <hr>
                    <div class="row small">
                        <div class="col-6"><strong>Issued:</strong> ${m.issue_date}</div>
                        <div class="col-6"><strong>Due:</strong> ${m.due_date}</div>
                        <div class="col-12 mt-2"><strong>Renewals:</strong> ${m.renewals}</div>
                        <div class="col-12 mt-1 ${overdueClass}"><strong>${daysText}</strong></div>
                    </div>
                </div>
            `;
            fetch('log_action.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=whom_click&book_id=${bookId}&member_holder=${encodeURIComponent(m.name)}`
            }).catch(e => console.warn);
            memberPanelTimeout = setTimeout(restoreOriginalCard, 10000);
        })
        .catch(err => {
            console.error('WHOM AJAX error:', err);
            memberPanelDiv.innerHTML = `<div class="alert alert-danger">Network error. Please try again.</div>`;
            memberPanelTimeout = setTimeout(restoreOriginalCard, 5000);
        });
}

function restoreOriginalCard() {
    const memberPanelDiv = document.getElementById('memberInfoPanel');
    if (!memberPanelDiv) return;
    const serialCard = document.getElementById('serialCard');
    const bookOfDayCard = document.getElementById('bookOfDayCard');
    let targetCard = serialCard || bookOfDayCard;
    
    if (targetCard) {
        memberPanelDiv.style.transition = 'opacity 0.3s ease';
        memberPanelDiv.style.opacity = '0';
        setTimeout(() => {
            memberPanelDiv.style.display = 'none';
            targetCard.style.display = 'block';
            targetCard.style.opacity = '0';
            targetCard.style.transition = 'opacity 0.3s ease';
            targetCard.style.opacity = '1';
        }, 300);
    } else { memberPanelDiv.style.display = 'none'; }
    if (memberPanelTimeout) clearTimeout(memberPanelTimeout);
    memberPanelTimeout = null;
    currentBookIdForPanel = null;
}

function attachWhomListeners() {
    document.querySelectorAll('.whom-btn').forEach(btn => {
        btn.removeEventListener('click', whomClick);
        btn.addEventListener('click', whomClick);
        btn.addEventListener('click', function(e) { e.stopPropagation(); });
    });
}
function whomClick(e) {
    e.stopPropagation();
    const bookId = this.getAttribute('data-book-id');
    const bookTitle = this.getAttribute('data-book-title');
    if (bookId) showMemberInfo(bookId, bookTitle);
}
function getMemberPhotoUrl(photoPath) { return photoPath; }

// ==================== SEARCH FUNCTIONS ====================
function searchGeneral() { 
    let keyword = document.getElementById('generalSearchKeyword').value; 
    let resourceType = document.getElementById('generalResourceType').value; 
    if (!keyword) { alert('<?= __('enter_valid_id') ?>'); return; } 
    document.getElementById('generalLoader').classList.add('show'); 
    document.getElementById('generalResults').style.display = 'none'; 
    let promises = []; 
    if (resourceType === 'all' || resourceType === 'books') promises.push(fetch(`search_books.php?keyword=${encodeURIComponent(keyword)}&category=all&limit=<?= $opacBooksPerPage ?>`).then(r => r.json())); 
    else promises.push(Promise.resolve([])); 
    if (resourceType === 'all' || resourceType === 'ebooks') promises.push(fetch(`search_ebooks.php?keyword=${encodeURIComponent(keyword)}&subject=all&limit=<?= $opacEbooksPerPage ?>`).then(r => r.json())); 
    else promises.push(Promise.resolve([])); 
    if (resourceType === 'all' || resourceType === 'databases') promises.push(fetch(`search_databases.php?keyword=${encodeURIComponent(keyword)}&type=all`).then(r => r.json())); 
    else promises.push(Promise.resolve([])); 
    Promise.all(promises).then(([books, ebooks, databases]) => { 
        document.getElementById('generalLoader').classList.remove('show'); 
        let totalResults = books.length + ebooks.length + databases.length; 
        let html = '<div class="alert alert-info small py-2"><strong>' + totalResults + '</strong> <?= __('results_found') ?> "' + escapeHtml(keyword) + '"</div>'; 
        if (totalResults === 0) html += '<div class="alert alert-light text-center py-5"><i class="fas fa-search fa-3x text-muted mb-2"></i><p><?= __('no_results') ?></p></div>'; 
        else { 
            if (books.length > 0) { 
                html += '<h6 class="mt-2"><i class="fas fa-book text-primary"></i> <?= __('books') ?> (' + books.length + ')</h6><div class="results-scroll-container row g-3">'; 
                books.forEach(book => { 
                    let isAvailable = book.available > 0;
                    let statusBadge = isAvailable ? '<span class="badge bg-success"><?= __('available') ?></span>' : '<span class="badge bg-danger"><?= __('issued') ?></span>';
                    let whomBtn = !isAvailable ? `<button class="btn btn-sm btn-outline-secondary whom-btn mt-1" data-book-id="${book.id}" data-book-title="${escapeHtml(book.title)}"><?= __('whom') ?></button>` : '';
                    let cover = book.cover_path ? `<img src="${escapeHtml(book.cover_path)}" style="max-height:60px; max-width:60px; object-fit:contain; border-radius:6px; margin-bottom:5px;" loading="lazy">` : '';
                    html += `<div class="col-md-4 col-lg-3 mb-3"><div class="card h-100 shadow-sm" onclick="viewBook(${book.id})" style="cursor:pointer;"><div class="card-body p-3 text-center">${cover}<small><strong>${escapeHtml(book.title.substring(0, 45))}</strong></small><br><small class="text-muted">${escapeHtml(book.author || 'Unknown')}</small><br><div class="d-flex justify-content-between align-items-center mt-2">${statusBadge} ${whomBtn}</div></div></div></div>`; 
                }); 
                html += '</div>'; 
            } 
            if (ebooks.length > 0) { 
                html += '<h6 class="mt-3"><i class="fas fa-file-pdf text-danger"></i> <?= __('ebooks') ?> (' + ebooks.length + ')</h6><div class="results-scroll-container row g-3">'; 
                ebooks.forEach(ebook => { 
                    let cover = ebook.cover_path ? `<img src="${escapeHtml(ebook.cover_path)}" style="max-height:60px; max-width:60px; object-fit:contain; border-radius:6px; margin-bottom:5px;" loading="lazy">` : '';
                    html += `<div class="col-md-4 col-lg-3 mb-3"><div class="card h-100 shadow-sm"><div class="card-body p-3 text-center">${cover}<small><strong>${escapeHtml(ebook.title.substring(0, 45))}</strong></small><br><small class="text-muted">${escapeHtml(ebook.author || 'Unknown')}</small><br><button class="btn btn-danger btn-sm mt-2" onclick="event.stopPropagation(); downloadEbook(${ebook.id}, '${escapeHtml(ebook.title)}')"><i class="fas fa-download"></i> <?= __('download') ?></button></div></div></div>`; 
                }); 
                html += '</div>'; 
            } 
            if (databases.length > 0) { 
                html += '<h6 class="mt-3"><i class="fas fa-database text-info"></i> <?= __('research_databases') ?> (' + databases.length + ')</h6><div class="results-scroll-container row g-3">'; 
                databases.forEach(db => { 
                    html += `<div class="col-md-4 col-lg-3 mb-3"><div class="card h-100 shadow-sm"><div class="card-body p-3"><small><strong>${escapeHtml(db.name.substring(0, 45))}</strong></small><br><small class="text-muted">${escapeHtml(db.category || 'General')}</small><br><a href="${escapeHtml(db.url)}" target="_blank" class="btn btn-info btn-sm mt-2"><i class="fas fa-external-link-alt"></i> <?= __('access_database') ?></a></div></div></div>`; 
                }); 
                html += '</div>'; 
            } 
        } 
        document.getElementById('generalResults').innerHTML = html; 
        document.getElementById('generalResults').style.display = 'block'; 
        attachWhomListeners();
    }).catch(() => { 
        document.getElementById('generalLoader').classList.remove('show'); 
        document.getElementById('generalResults').innerHTML = '<div class="alert alert-danger"><?= __('error_searching') ?></div>'; 
        document.getElementById('generalResults').style.display = 'block'; 
    }); 
}

function searchBooks() { 
    let keyword = document.getElementById('searchKeyword').value; 
    let category = document.getElementById('searchCategory').value; 
    if (!keyword && category === 'all') { alert('<?= __('enter_valid_id') ?>'); return; } 
    document.getElementById('bookLoader').classList.add('show'); 
    document.getElementById('bookResults').style.display = 'none'; 
    fetch(`search_books.php?keyword=${encodeURIComponent(keyword)}&category=${encodeURIComponent(category)}&limit=<?= $opacBooksPerPage ?>`).then(r => r.json()).then(books => { 
        document.getElementById('bookLoader').classList.remove('show'); 
        let html = '<div class="col-12 mb-3"><h5>Search Results (' + books.length + ')</h5><hr></div>'; 
        if (books.length === 0) html += '<div class="alert alert-info"><?= __('no_results') ?></div>'; 
        else { 
            html += '<div class="results-scroll-container row g-3">';
            books.forEach(book => { 
                let isAvailable = book.available > 0;
                let statusBadge = isAvailable ? '<span class="badge bg-success"><?= __('available') ?></span>' : '<span class="badge bg-danger"><?= __('issued') ?></span>';
                let whomBtn = !isAvailable ? `<button class="btn btn-sm btn-outline-secondary whom-btn mt-1" data-book-id="${book.id}" data-book-title="${escapeHtml(book.title)}"><?= __('whom') ?></button>` : '';
                let cover = book.cover_path ? `<img src="${escapeHtml(book.cover_path)}" style="max-height:60px; max-width:60px; object-fit:contain; border-radius:6px; margin-bottom:5px;" loading="lazy">` : '';
                html += `<div class="col-md-4 col-lg-3 mb-3"><div class="card h-100 shadow-sm" onclick="viewBook(${book.id})" style="cursor:pointer;"><div class="card-body p-3 text-center">${cover}<h6 class="card-title fw-semibold">${escapeHtml(book.title.substring(0, 40))}</h6><p class="small text-muted mb-1">${escapeHtml(book.author || 'Unknown')}</p><div class="d-flex justify-content-between align-items-center mt-2">${statusBadge} ${whomBtn}</div></div></div></div>`; 
            }); 
            html += '</div>';
        } 
        document.getElementById('bookResults').innerHTML = html; 
        document.getElementById('bookResults').style.display = 'flex'; 
        attachWhomListeners();
    }).catch(() => { 
        document.getElementById('bookLoader').classList.remove('show'); 
        document.getElementById('bookResults').innerHTML = '<div class="alert alert-danger"><?= __('error_searching') ?></div>'; 
        document.getElementById('bookResults').style.display = 'flex'; 
    }); 
}

function searchEbooks() { 
    let keyword = document.getElementById('ebookSearchKeyword').value; 
    let subject = document.getElementById('ebookSubject').value; 
    if (!keyword && subject === 'all') { alert('<?= __('enter_valid_id') ?>'); return; } 
    document.getElementById('ebookLoader').classList.add('show'); 
    document.getElementById('ebookResults').style.display = 'none'; 
    fetch(`search_ebooks.php?keyword=${encodeURIComponent(keyword)}&subject=${encodeURIComponent(subject)}&limit=<?= $opacEbooksPerPage ?>`).then(r => r.json()).then(ebooks => { 
        document.getElementById('ebookLoader').classList.remove('show'); 
        let html = '<div class="col-12 mb-3"><h5>eBook Search Results (' + ebooks.length + ')</h5><hr></div>'; 
        if (ebooks.length === 0) html += '<div class="alert alert-info"><?= __('no_results') ?></div>'; 
        else { 
            html += '<div class="results-scroll-container row g-3">';
            ebooks.forEach(ebook => { 
                let cover = ebook.cover_path ? `<img src="${escapeHtml(ebook.cover_path)}" style="max-height:60px; max-width:60px; object-fit:contain; border-radius:6px; margin-bottom:5px;" loading="lazy">` : '';
                html += `<div class="col-md-4 col-lg-3 mb-3"><div class="card h-100 shadow-sm"><div class="card-body p-3 text-center">${cover}<h6 class="card-title fw-semibold">${escapeHtml(ebook.title.substring(0, 40))}</h6><p class="small text-muted">${escapeHtml(ebook.author || 'Unknown')}</p><button class="btn btn-danger btn-sm" onclick="downloadEbook(${ebook.id}, '${escapeHtml(ebook.title)}')"><i class="fas fa-download"></i> <?= __('download') ?></button></div></div></div>`; 
            }); 
            html += '</div>';
        } 
        document.getElementById('ebookResults').innerHTML = html; 
        document.getElementById('ebookResults').style.display = 'flex'; 
    }).catch(() => { 
        document.getElementById('ebookLoader').classList.remove('show'); 
        document.getElementById('ebookResults').innerHTML = '<div class="alert alert-danger"><?= __('error_searching') ?></div>'; 
        document.getElementById('ebookResults').style.display = 'flex'; 
    }); 
}

function searchDatabases() { 
    let keyword = document.getElementById('databaseSearchKeyword').value; 
    let type = document.getElementById('databaseType').value; 
    document.getElementById('databaseLoader').classList.add('show'); 
    document.getElementById('databaseResults').style.display = 'none'; 
    fetch(`search_databases.php?keyword=${encodeURIComponent(keyword)}&type=${encodeURIComponent(type)}`).then(r => r.json()).then(databases => { 
        document.getElementById('databaseLoader').classList.remove('show'); 
        let html = '<div class="col-12 mb-3"><h5>Database Search Results (' + databases.length + ')</h5><hr></div>'; 
        if (databases.length === 0) html += '<div class="alert alert-info"><?= __('no_databases_found') ?></div>'; 
        else { 
            html += '<div class="results-scroll-container row g-3">';
            databases.forEach(db => { 
                let typeLabel = db.type == 'academic' ? '<?= __('academic_databases') ?>' : (db.type == 'open_access' ? '<?= __('open_access') ?>' : '<?= __('subscription_based') ?>'); 
                html += `<div class="col-md-6 col-lg-4 mb-3"><div class="database-card"><div class="database-icon"><i class="fas fa-${db.icon || 'database'}"></i></div><h6 class="fw-bold mb-2">${escapeHtml(db.name)}</h6><p class="small text-muted mb-2">${escapeHtml(db.description ? db.description.substring(0, 80) : 'No description')}...</p><span class="type-badge type-${db.type} mb-2 d-inline-block">${typeLabel}</span><div class="mt-2"><a href="${escapeHtml(db.url)}" target="_blank" class="btn btn-database btn-sm w-100"><i class="fas fa-external-link-alt me-1"></i> <?= __('access_database') ?></a></div></div></div>`; 
            }); 
            html += '</div>';
        } 
        document.getElementById('databaseResults').innerHTML = html; 
        document.getElementById('databaseResults').style.display = 'flex'; 
    }).catch(() => { 
        document.getElementById('databaseLoader').classList.remove('show'); 
        document.getElementById('databaseResults').innerHTML = '<div class="alert alert-danger"><?= __('error_searching') ?></div>'; 
        document.getElementById('databaseResults').style.display = 'flex'; 
    }); 
}

function advancedSearch() {
    let keyword = document.getElementById('adv_keyword').value;
    let author = document.getElementById('adv_author').value;
    let publisher = document.getElementById('adv_publisher').value;
    let yearFrom = document.getElementById('adv_year_from').value;
    let yearTo = document.getElementById('adv_year_to').value;
    let language = document.getElementById('adv_language').value;
    let curriculum = document.getElementById('adv_curriculum').value;
    let isbn = document.getElementById('adv_isbn').value;
    let params = new URLSearchParams();
    if (keyword) params.append('keyword', keyword);
    if (author) params.append('author', author);
    if (publisher) params.append('publisher', publisher);
    if (yearFrom) params.append('year_from', yearFrom);
    if (yearTo) params.append('year_to', yearTo);
    if (language) params.append('language', language);
    if (curriculum) params.append('curriculum', curriculum);
    if (isbn) params.append('isbn', isbn);
    window.location.href = 'advanced_search.php?' + params.toString();
}
document.getElementById('doAdvancedSearch')?.addEventListener('click', advancedSearch);

function viewBook(bookId) {
    fetch(`book_details.php?id=${bookId}`)
        .then(res => res.json())
        .then(book => {
            if (book && !book.error) {
                let coverHtml = book.cover_base64 ? `<div class="book-detail-cover"><img src="${book.cover_base64}" alt="Book Cover" class="img-fluid" loading="lazy"></div>` : '<div class="text-center mb-3"><i class="fas fa-book fa-5x text-muted"></i></div>';
                let isAvailable = (book.available > 0);
                let statusBadge = isAvailable ? '<span class="badge bg-success"><?= __('available') ?></span>' : '<span class="badge bg-danger"><?= __('issued') ?></span>';
                let holdButton = '';
                if (!isAvailable) {
                    holdButton = `<button class="btn btn-warning mt-3 whom-btn" data-book-id="${book.id}" data-book-title="${escapeHtml(book.title)}"><i class="fas fa-hand-paper"></i> <?= __('whom') ?></button>`;
                    if (<?= $memberLoggedIn ? 'true' : 'false' ?>) holdButton += `<button class="btn btn-outline-secondary mt-3 ms-2" onclick="placeHold(${book.id})"><?= __('place_hold') ?></button>`;
                    else holdButton += `<a href="login.php" class="btn btn-outline-secondary mt-3 ms-2"><?= __('member_login') ?> to place hold</a>`;
                } else {
                    if (<?= $memberLoggedIn ? 'true' : 'false' ?>) holdButton = `<button class="btn btn-warning mt-3" onclick="placeHold(${book.id})"><?= __('place_hold') ?></button>`;
                    else holdButton = `<a href="login.php" class="btn btn-outline-secondary mt-3"><?= __('member_login') ?> to place hold</a>`;
                }
                document.getElementById('bookDetailsContent').innerHTML = `
                    <div class="row">
                        <div class="col-md-5 text-center mb-3 mb-md-0">${coverHtml}</div>
                        <div class="col-md-7">
                            <h4 class="mb-2">${escapeHtml(book.title)}</h4><hr class="my-2">
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('author') ?>:</div><div class="col-8">${escapeHtml(book.author || 'Unknown')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('publisher') ?>:</div><div class="col-8">${escapeHtml(book.publisher || 'Unknown')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('isbn') ?>:</div><div class="col-8">${escapeHtml(book.isbn || 'N/A')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('category') ?>:</div><div class="col-8">${escapeHtml(book.category || 'Uncategorized')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('year') ?>:</div><div class="col-8">${escapeHtml(book.year || 'N/A')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold small"><?= __('availability') ?>:</div><div class="col-8">${statusBadge}</div></div>
                            <div class="mt-3"><strong class="small"><?= __('summary') ?>:</strong><p class="small mt-1">${escapeHtml(book.summary || '<?= __('no_summary') ?>')}</p></div>
                            <div class="mt-3">${holdButton}</div>
                        </div>
                    </div>`;
                new bootstrap.Modal(document.getElementById('bookModal')).show();
                attachWhomListeners();
            } else alert('Book details could not be loaded.');
        })
        .catch(() => alert('Network error loading book details.'));
}

function placeHold(bookId) {
    fetch(window.location.href, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `place_hold=1&book_id=${bookId}&csrf_token=<?= $csrf_token ?>`
    }).then(r => r.json()).then(data => {
        if (data.success) { alert(data.message); location.reload(); } else alert(data.message);
    }).catch(() => alert('<?= __('network_error') ?>'));
}

function downloadEbook(id, title) { if (confirm(`Download "${title}"?`)) window.open(`download_ebook.php?id=${id}`, '_blank'); }

document.getElementById('submitSuggestionBtn')?.addEventListener('click', function() { 
    const form = document.getElementById('suggestionForm'); 
    const formData = new FormData(form); 
    const btn = this; 
    btn.disabled = true; 
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...'; 
    fetch(window.location.href, { method: 'POST', body: formData }).then(r => r.json()).then(data => { 
        let toast = document.getElementById('suggestionToast');
        toast.classList.remove('bg-success', 'bg-danger');
        toast.classList.add(data.success ? 'bg-success' : 'bg-danger');
        toast.querySelector('.toast-body').textContent = data.message;
        new bootstrap.Toast(toast).show();
        if (data.success) form.reset(); 
        setTimeout(() => { const modal = bootstrap.Modal.getInstance(document.getElementById('suggestionModal')); if (modal) modal.hide(); }, 1500); 
        btn.disabled = false; btn.innerHTML = '<?= __('submit') ?>'; 
    }).catch(() => { alert('<?= __('network_error') ?>'); btn.disabled = false; btn.innerHTML = '<?= __('submit') ?>'; }); 
});

// ==================== POLL BOOK STATUS ====================
function pollBookStatusUpdates() {
    let bookElements = document.querySelectorAll('[data-book-id]');
    let ids = [...new Set(Array.from(bookElements).map(el => el.getAttribute('data-book-id')))];
    if (ids.length === 0) return;
    fetch('check_book_statuses.php?ids=' + ids.join(','))
        .then(r => r.json())
        .then(data => {
            for (let [id, status] of Object.entries(data)) {
                let badges = document.querySelectorAll(`.book-status-badge-${id}`);
                badges.forEach(badge => {
                    badge.textContent = status.available ? '<?= __('available') ?>' : '<?= __('issued') ?>';
                    badge.className = `badge ${status.available ? 'bg-success' : 'bg-danger'} book-status-badge-${id}`;
                });
                let whomBtn = document.querySelector(`.whom-btn[data-book-id="${id}"]`);
                if (whomBtn) whomBtn.style.display = !status.available ? 'inline-block' : 'none';
            }
        });
}
setInterval(pollBookStatusUpdates, 30000);

// ==================== BACK TO TOP ====================
const backToTopBtn = document.getElementById('backToTop');
window.addEventListener('scroll', function() {
    if (window.scrollY > 200) backToTopBtn.classList.add('visible');
    else backToTopBtn.classList.remove('visible');
});
backToTopBtn.addEventListener('click', function() { window.scrollTo({ top: 0, behavior: 'smooth' }); });

// ==================== AUTO-FLIP STATS CARDS ====================
let autoFlipInterval = null;

function startAutoFlip() {
    if (autoFlipInterval) clearInterval(autoFlipInterval);
    const cards = document.querySelectorAll('.stats-card');
    cards.forEach(card => {
        const inner = card.querySelector('.stats-card-inner');
        if (inner) inner.classList.remove('flipped');
    });

    autoFlipInterval = setInterval(() => {
        document.querySelectorAll('.stats-card:not(.auto-flip-paused) .stats-card-inner').forEach(el => {
            el.classList.toggle('flipped');
        });
    }, 4000);

    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('auto-flip-paused');
        });
        card.addEventListener('mouseleave', function() {
            this.classList.remove('auto-flip-paused');
        });
    });
}

// ==================== INIT SWIPERS ====================
document.addEventListener('DOMContentLoaded', function() {
    startAutoFlip();

    const autoplayConfig = { delay: 4000, disableOnInteraction: false, pauseOnMouseEnter: true };
    const carouselType = <?= json_encode($opacCarouselType) ?>;

    function getBaseConfig() {
        let base = {
            spaceBetween: 25,
            loop: true,
            autoplay: autoplayConfig,
            navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
            pagination: { el: '.swiper-pagination', clickable: true },
            breakpoints: { 0: { slidesPerView: 1 }, 640: { slidesPerView: 2 }, 1024: { slidesPerView: 3 }, 1280: { slidesPerView: 4 } }
        };
        switch(carouselType) {
            case 'cover_flow': base.effect = 'coverflow'; base.coverflowEffect = { rotate: 35, stretch: 15, depth: 200, modifier: 1.8, slideShadows: true }; base.grabCursor = true; base.centeredSlides = true; base.slidesPerView = 3; break;
            case 'cube': base.effect = 'cube'; base.cubeEffect = { shadow: true, slideShadows: true, shadowOffset: 20, shadowScale: 0.94 }; base.grabCursor = true; base.centeredSlides = true; base.slidesPerView = 1; break;
            case 'fade': base.effect = 'fade'; base.fadeEffect = { crossFade: true }; base.slidesPerView = 1; break;
            case 'flip': base.effect = 'flip'; base.flipEffect = { slideShadows: true, limitRotation: true }; base.grabCursor = true; base.slidesPerView = 1; break;
            case 'zoom': base.effect = 'coverflow'; base.coverflowEffect = { rotate: 20, stretch: 50, depth: 400, modifier: 2, slideShadows: true }; base.grabCursor = true; base.centeredSlides = true; base.slidesPerView = 2; break;
            case 'stack': base.effect = 'cards'; base.cardsEffect = { slideShadows: true }; base.grabCursor = true; base.centeredSlides = true; base.slidesPerView = 1; break;
            case 'rotating': base.effect = 'coverflow'; base.coverflowEffect = { rotate: 50, stretch: 30, depth: 500, modifier: 2, slideShadows: true }; base.grabCursor = true; base.centeredSlides = true; base.slidesPerView = 3; break;
            default: base.effect = 'slide'; base.slidesPerView = 4; base.breakpoints[1024] = { slidesPerView: 4 }; base.breakpoints[640] = { slidesPerView: 2 }; base.breakpoints[0] = { slidesPerView: 1 }; break;
        }
        return base;
    }

    const newArrivalsEl = document.querySelector('.swiper-new-arrivals');
    if (newArrivalsEl) new Swiper(newArrivalsEl, getBaseConfig());

    const newArrivalsRightEl = document.querySelector('.swiper-new-arrivals-right');
    if (newArrivalsRightEl) {
        let cfg = getBaseConfig();
        cfg.slidesPerView = 2;
        cfg.breakpoints = { 0: { slidesPerView: 1 }, 640: { slidesPerView: 2 } };
        new Swiper(newArrivalsRightEl, cfg);
    }

    const popularEbooksEl = document.querySelector('.swiper-popular-ebooks');
    if (popularEbooksEl) new Swiper(popularEbooksEl, { effect: 'slide', grabCursor: true, spaceBetween: 20, loop: true, autoplay: autoplayConfig, navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }, pagination: { el: '.swiper-pagination', clickable: true }, breakpoints: { 0: { slidesPerView: 1 }, 640: { slidesPerView: 2 }, 1024: { slidesPerView: 4 } } });

    const latestEbooksEl = document.querySelector('.swiper-latest-ebooks');
    if (latestEbooksEl) new Swiper(latestEbooksEl, { effect: 'slide', grabCursor: true, spaceBetween: 20, loop: true, autoplay: autoplayConfig, navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }, pagination: { el: '.swiper-pagination', clickable: true }, breakpoints: { 0: { slidesPerView: 1 }, 640: { slidesPerView: 2 }, 1024: { slidesPerView: 4 } } });

    const trendingEl = document.querySelector('.swiper-trending');
    if (trendingEl) new Swiper(trendingEl, { effect: 'slide', grabCursor: true, centeredSlides: true, spaceBetween: 20, loop: true, autoplay: autoplayConfig, navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }, pagination: { el: '.swiper-pagination', clickable: true }, breakpoints: { 0: { slidesPerView: 1 }, 768: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } } });

    const recommendationsEl = document.querySelector('.swiper-recommendations');
    if (recommendationsEl) new Swiper(recommendationsEl, { effect: 'slide', grabCursor: true, spaceBetween: 20, loop: true, autoplay: autoplayConfig, navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' }, pagination: { el: '.swiper-pagination', clickable: true }, breakpoints: { 0: { slidesPerView: 1 }, 640: { slidesPerView: 2 }, 1024: { slidesPerView: 4 } } });

    attachWhomListeners();

    document.getElementById('searchKeyword')?.addEventListener('keypress', e => { if (e.key === 'Enter') searchBooks(); });
    document.getElementById('ebookSearchKeyword')?.addEventListener('keypress', e => { if (e.key === 'Enter') searchEbooks(); });
    document.getElementById('generalSearchKeyword')?.addEventListener('keypress', e => { if (e.key === 'Enter') searchGeneral(); });
    document.getElementById('databaseSearchKeyword')?.addEventListener('keypress', e => { if (e.key === 'Enter') searchDatabases(); });
});
</script>
</body>
</html>