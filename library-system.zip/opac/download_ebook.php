<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$id = (int)($_GET['id'] ?? 0);

if($id <= 0) {
    header('Location: index.php?error=invalid_id');
    exit;
}

try {
    // Increment download count and get file path
    $db->beginTransaction();
    
    $update = $db->prepare("UPDATE ebooks SET downloads = downloads + 1 WHERE id = ?");
    $update->execute([$id]);
    
    $stmt = $db->prepare("SELECT file_path, title FROM ebooks WHERE id = ?");
    $stmt->execute([$id]);
    $ebook = $stmt->fetch();
    
    $db->commit();
    
    if($ebook && !empty($ebook['file_path']) && file_exists($ebook['file_path'])) {
        $fileExt = pathinfo($ebook['file_path'], PATHINFO_EXTENSION);
        $safeTitle = preg_replace('/[^a-zA-Z0-9_-]/', '_', $ebook['title']);
        $filename = $safeTitle . '.' . $fileExt;
        
        // Set headers for download
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($ebook['file_path']));
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: public');
        
        // Clear output buffer
        if (ob_get_level()) ob_end_clean();
        
        // Read file and output
        readfile($ebook['file_path']);
        exit;
    } else {
        header('Location: index.php?error=file_not_found');
        exit;
    }
} catch(Exception $e) {
    if($db->inTransaction()) $db->rollBack();
    error_log("Download error: " . $e->getMessage());
    header('Location: index.php?error=' . urlencode($e->getMessage()));
    exit;
}
?>