<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'member_login' => 'Member Login',
        'admission_number' => 'Admission Number',
        'password' => 'Password',
        'default_password' => 'Default password : 123456',
        'login' => 'Login',
        'register' => 'Register as new member',
        'invalid_credentials' => 'Invalid admission number or password.',
        'back_to_home' => 'Back to Home',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'member_login' => 'सदस्य लॉगिन',
        'admission_number' => 'नामांकन संख्या',
        'password' => 'पासवर्ड',
        'default_password' => 'डिफ़ॉल्ट पासवर्ड : 123456',
        'login' => 'लॉगिन',
        'register' => 'नए सदस्य के रूप में पंजीकरण करें',
        'invalid_credentials' => 'अमान्य नामांकन संख्या या पासवर्ड।',
        'back_to_home' => 'होम पर वापस जाएं',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'member_login' => 'دخول الأعضاء',
        'admission_number' => 'رقم القبول',
        'password' => 'كلمة المرور',
        'default_password' => 'كلمة المرور الافتراضية: 123456',
        'login' => 'تسجيل الدخول',
        'register' => 'التسجيل كعضو جديد',
        'invalid_credentials' => 'رقم القبول أو كلمة المرور غير صحيحة.',
        'back_to_home' => 'العودة إلى الرئيسية',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admno = trim($_POST['admno'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
    $stmt->execute([$admno]);
    $member = $stmt->fetch();
    if ($member && password_verify($password, $member['password'])) {
        $_SESSION['member_id'] = $member['id'];
        $_SESSION['member_name'] = $member['name'];
        $_SESSION['member_admno'] = $member['admno'];
        header('Location: account.php');
        exit;
    } else {
        $error = __('invalid_credentials');
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <title><?= __('member_login') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>body{background:#f0f2f5;}</style>
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow border-0 rounded-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="mb-0"><i class="fas fa-user-circle"></i> <?= __('member_login') ?></h2>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                    </ul>
                </div>
            </div>
            <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <form method="post">
                <div class="mb-3"><label class="form-label"><?= __('admission_number') ?></label><input type="text" name="admno" class="form-control" required autofocus></div>
                <div class="mb-3"><label class="form-label"><?= __('password') ?></label><input type="password" name="password" class="form-control" required></div>
                <button type="submit" class="btn btn-primary w-100 py-2"><?= __('login') ?></button>
                <center><?= __('default_password') ?></center>
                <div class="text-center mt-3"><a href="register.php"><?= __('register') ?></a></div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>