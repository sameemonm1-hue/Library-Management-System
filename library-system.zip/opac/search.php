<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$keyword = trim($_GET['keyword'] ?? '');
$category = trim($_GET['category'] ?? '');

$sql = "SELECT barcode, title, author, publisher, category, available, quantity, isbn, cover_path FROM books WHERE 1=1";
$params = [];

if(!empty($keyword)) {
    $sql .= " AND (title LIKE ? OR author LIKE ? OR isbn LIKE ? OR barcode LIKE ? OR category LIKE ? OR keyword LIKE ?)";
    $like = "%$keyword%";
    $params = [$like, $like, $like, $like, $like, $like];
}

if(!empty($category) && $category !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
}

$sql .= " ORDER BY title LIMIT 100";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Add cover base64 for display
foreach($books as &$book) {
    if($book['cover_path'] && file_exists($book['cover_path'])) {
        $ext = pathinfo($book['cover_path'], PATHINFO_EXTENSION);
        $book['cover_base64'] = 'data:image/' . $ext . ';base64,' . base64_encode(file_get_contents($book['cover_path']));
    }
}

header('Content-Type: application/json');
echo json_encode($books);
?>