<?php
/**
 * Book Details Page - OPAC
 * Version: 2.0
 * 
 * Features:
 * - Display full book details with cover image
 * - Show availability (total copies, available, issued, reserved)
 * - Place hold with CSRF protection
 * - Display similar books by category/author
 * - Show book reviews and ratings (if available)
 * - Responsive design with unified styling
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();

// ==================== GET BOOK ====================
$db = getDB();
$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: index.php');
    exit;
}

// Fetch book with joins if needed (e.g., category, author details)
$stmt = $db->prepare("SELECT * FROM books WHERE id = ? AND status != 'Deleted'");
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
    header('Location: index.php');
    exit;
}

// ==================== COVER HELPER (if not defined) ====================
if (!function_exists('getBookCoverBase64')) {
    function getBookCoverBase64($coverPath) {
        if (empty($coverPath)) return '';
        $fullPath = BASE_PATH . '/' . ltrim($coverPath, '/');
        if (!file_exists($fullPath)) return '';
        $data = @file_get_contents($fullPath);
        if ($data === false) return '';
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_buffer($finfo, $data);
        finfo_close($finfo);
        return 'data:' . $mime . ';base64,' . base64_encode($data);
    }
}

$coverBase64 = getBookCoverBase64($book['cover_path'] ?? '');

// ==================== AVAILABILITY ====================
// Get total copies, available, issued, reserved
$totalCopies = (int)$book['quantity'];
$availableCopies = (int)$book['available'];
$issuedCopies = $totalCopies - $availableCopies;
$reservedCopies = 0; // Could be fetched from holds table if exists

// Check if user is logged in (for hold)
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admno']);
$userAdmno = $_SESSION['admno'] ?? $_SESSION['user_id'] ?? '';

// ==================== HOLD LOGIC ====================
$holdError = '';
$holdSuccess = '';
$csrf_token = $_SESSION['csrf_token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_hold'])) {
    // CSRF protection
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $holdError = 'Invalid security token. Please try again.';
    } elseif (!$isLoggedIn) {
        $holdError = 'Please login to place a hold.';
    } elseif ($availableCopies > 0) {
        $holdError = 'This book is currently available. Please borrow it directly.';
    } else {
        // Check if user already has a hold on this book
        $checkHold = $db->prepare("SELECT COUNT(*) FROM holds WHERE book_id = ? AND user_id = ? AND status = 'pending'");
        $checkHold->execute([$id, $userAdmno]);
        if ($checkHold->fetchColumn() > 0) {
            $holdError = 'You already have a pending hold on this book.';
        } else {
            // Place hold
            $holdStmt = $db->prepare("INSERT INTO holds (book_id, user_id, hold_date, status) VALUES (?, ?, datetime('now'), 'pending')");
            if ($holdStmt->execute([$id, $userAdmno])) {
                $holdSuccess = 'Hold placed successfully. You will be notified when the book becomes available.';
                logActivity($_SESSION['username'] ?? $userAdmno, 'PLACE_HOLD', "Placed hold on book ID: $id");
            } else {
                $holdError = 'Failed to place hold. Please try again.';
            }
        }
    }
}

// ==================== SIMILAR BOOKS ====================
$similarBooks = [];
$similarStmt = $db->prepare("SELECT id, title, author, isbn, cover_path, year 
                             FROM books 
                             WHERE id != ? AND status != 'Deleted' 
                             AND (category = ? OR author = ? OR subject LIKE ?) 
                             ORDER BY RANDOM() 
                             LIMIT 4");
$category = $book['category'] ?? '';
$author = $book['author'] ?? '';
$subject = $book['subject'] ?? '';
$similarStmt->execute([$id, $category, $author, '%' . $subject . '%']);
$similarBooks = $similarStmt->fetchAll();

// ==================== BOOK REVIEWS (if any) ====================
$reviews = [];
// Optional: if reviews table exists, fetch them
// $reviewsStmt = $db->prepare("SELECT * FROM reviews WHERE book_id = ? ORDER BY created_at DESC LIMIT 5");
// $reviewsStmt->execute([$id]);
// $reviews = $reviewsStmt->fetchAll();

// ==================== RENDER ====================
// Use OPAC header (this file should be in a public directory)
include '../includes/opac_header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($book['title']) ?> - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        
        .book-cover-large {
            max-width: 100%;
            max-height: 450px;
            object-fit: contain;
            border-radius: 12px;
            box-shadow: var(--shadow-hover);
            background: white;
            padding: 10px;
            transition: transform 0.3s;
        }
        .book-cover-large:hover { transform: scale(1.02); }
        
        .default-cover-large {
            width: 100%;
            height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            border-radius: 12px;
            color: white;
            font-size: 6rem;
        }
        
        .detail-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 25px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: box-shadow 0.3s;
        }
        .detail-card:hover { box-shadow: var(--shadow-hover); }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
        }
        .status-available { background: #d4edda; color: #155724; }
        .status-issued { background: #f8d7da; color: #721c24; }
        .status-reserved { background: #fff3cd; color: #856404; }
        
        .similar-card {
            transition: all 0.3s;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            height: 100%;
            background: white;
        }
        .similar-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
        }
        .similar-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        
        @media (max-width: 768px) {
            .book-cover-large { max-height: 300px; }
            .default-cover-large { height: 250px; font-size: 4rem; }
        }
        @media print {
            .no-print { display: none !important; }
            .detail-card { box-shadow: none !important; border: 1px solid #ddd; }
        }
    </style>
</head>
<body>
<div class="container my-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="no-print">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="catalog.php">Catalog</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars(substr($book['title'], 0, 50)) ?>...</li>
        </ol>
    </nav>

    <!-- Main Book Details -->
    <div class="row g-4">
        <!-- Cover Column -->
        <div class="col-md-4">
            <div class="text-center">
                <?php if ($coverBase64): ?>
                    <img src="<?= $coverBase64 ?>" class="book-cover-large" alt="Cover of <?= htmlspecialchars($book['title']) ?>">
                <?php else: ?>
                    <div class="default-cover-large">
                        <i class="fas fa-book"></i>
                    </div>
                <?php endif; ?>
                <!-- QR Code for quick access (optional) -->
                <div class="mt-3 no-print">
                    <img src="https://quickchart.io/qr?text=<?= urlencode('https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) ?>&size=150&margin=0" 
                         alt="QR Code" style="width:100px; height:100px; border-radius:8px; border:1px solid #e9ecef;">
                    <p class="text-muted small mt-1">Scan to view this book</p>
                </div>
            </div>
        </div>

        <!-- Details Column -->
        <div class="col-md-8">
            <div class="detail-card">
                <h1 class="mb-2" style="color: var(--primary-color);"><?= htmlspecialchars($book['title']) ?></h1>
                <?php if (!empty($book['sub_title'])): ?>
                    <h5 class="text-muted"><?= htmlspecialchars($book['sub_title']) ?></h5>
                <?php endif; ?>
                
                <hr>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <p><strong><i class="fas fa-user-edit"></i> Author:</strong> <?= htmlspecialchars($book['author'] ?: 'Unknown') ?></p>
                        <?php if (!empty($book['author2'])): ?>
                            <p><strong>Co-author:</strong> <?= htmlspecialchars($book['author2']) ?></p>
                        <?php endif; ?>
                        <p><strong><i class="fas fa-building"></i> Publisher:</strong> <?= htmlspecialchars($book['publisher'] ?: 'N/A') ?></p>
                        <p><strong><i class="fas fa-calendar-alt"></i> Year:</strong> <?= htmlspecialchars($book['year'] ?: 'N/A') ?></p>
                        <p><strong><i class="fas fa-code"></i> ISBN:</strong> <?= htmlspecialchars($book['isbn'] ?: 'N/A') ?></p>
                        <p><strong><i class="fas fa-tag"></i> Category:</strong> <?= htmlspecialchars($book['category'] ?: 'Uncategorized') ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong><i class="fas fa-bookmark"></i> Call Number:</strong> <?= htmlspecialchars($book['call_number'] ?: 'N/A') ?></p>
                        <p><strong><i class="fas fa-barcode"></i> Barcode:</strong> <?= htmlspecialchars($book['barcode'] ?: 'N/A') ?></p>
                        <p><strong><i class="fas fa-language"></i> Language:</strong> <?= htmlspecialchars($book['language'] ?: 'English') ?></p>
                        <p><strong><i class="fas fa-file-alt"></i> Pages:</strong> <?= $book['pages'] ?: 'N/A' ?></p>
                        <?php if (!empty($book['edition'])): ?>
                            <p><strong><i class="fas fa-edit"></i> Edition:</strong> <?= htmlspecialchars($book['edition']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($book['series'])): ?>
                            <p><strong><i class="fas fa-layer-group"></i> Series:</strong> <?= htmlspecialchars($book['series']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!empty($book['summary'])): ?>
                    <div class="mt-3">
                        <h6><i class="fas fa-align-left"></i> Summary</h6>
                        <p class="text-muted" style="text-align:justify;"><?= nl2br(htmlspecialchars($book['summary'])) ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($book['subject'])): ?>
                    <div class="mt-2">
                        <h6><i class="fas fa-tags"></i> Subjects</h6>
                        <p><?= htmlspecialchars($book['subject']) ?></p>
                    </div>
                <?php endif; ?>
                
                <!-- Availability -->
                <div class="mt-3 p-3 bg-light rounded">
                    <h6><i class="fas fa-info-circle"></i> Availability</h6>
                    <div class="row text-center">
                        <div class="col-3">
                            <span class="badge bg-primary fs-5 w-100 py-2"><?= $totalCopies ?></span>
                            <div class="small text-muted">Total Copies</div>
                        </div>
                        <div class="col-3">
                            <span class="badge <?= $availableCopies > 0 ? 'bg-success' : 'bg-danger' ?> fs-5 w-100 py-2"><?= $availableCopies ?></span>
                            <div class="small text-muted">Available</div>
                        </div>
                        <div class="col-3">
                            <span class="badge bg-warning fs-5 w-100 py-2"><?= $issuedCopies ?></span>
                            <div class="small text-muted">Issued</div>
                        </div>
                        <div class="col-3">
                            <span class="badge bg-secondary fs-5 w-100 py-2"><?= $reservedCopies ?></span>
                            <div class="small text-muted">Reserved</div>
                        </div>
                    </div>
                </div>

                <!-- Hold Form -->
                <div class="mt-3 no-print">
                    <?php if ($holdSuccess): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($holdSuccess) ?></div>
                    <?php endif; ?>
                    <?php if ($holdError): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($holdError) ?></div>
                    <?php endif; ?>
                    
                    <?php if ($isLoggedIn && $availableCopies == 0): ?>
                        <form method="post" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                            <button type="submit" name="place_hold" class="btn btn-warning">
                                <i class="fas fa-clock"></i> Place Hold
                            </button>
                            <small class="text-muted ms-2">You will be notified when available.</small>
                        </form>
                    <?php elseif ($isLoggedIn && $availableCopies > 0): ?>
                        <a href="borrow.php?book_id=<?= $id ?>" class="btn btn-success">
                            <i class="fas fa-hand-holding-heart"></i> Borrow Now
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt"></i> Login to Borrow or Hold
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Similar Books Section -->
    <?php if (!empty($similarBooks)): ?>
        <div class="detail-card mt-4">
            <h4><i class="fas fa-book-open"></i> Similar Books You Might Like</h4>
            <div class="row g-3 mt-2">
                <?php foreach ($similarBooks as $similar): 
                    $similarCover = getBookCoverBase64($similar['cover_path'] ?? '');
                ?>
                    <div class="col-md-3 col-6">
                        <div class="similar-card">
                            <a href="details.php?id=<?= $similar['id'] ?>" class="text-decoration-none text-dark">
                                <div style="height:180px; overflow:hidden; background:#f8f9fa; display:flex; align-items:center; justify-content:center;">
                                    <?php if ($similarCover): ?>
                                        <img src="<?= $similarCover ?>" style="width:100%; height:100%; object-fit:cover;" alt="<?= htmlspecialchars($similar['title']) ?>">
                                    <?php else: ?>
                                        <i class="fas fa-book fa-3x text-secondary"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="p-2">
                                    <h6 class="mb-0 text-truncate"><?= htmlspecialchars($similar['title']) ?></h6>
                                    <small class="text-muted"><?= htmlspecialchars($similar['author'] ?: 'Unknown') ?></small>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Reviews Section (placeholder) -->
    <?php if (!empty($reviews)): ?>
        <div class="detail-card mt-4">
            <h4><i class="fas fa-star"></i> Reviews</h4>
            <?php foreach ($reviews as $review): ?>
                <div class="border-bottom py-2">
                    <strong><?= htmlspecialchars($review['user_name']) ?></strong>
                    <span class="text-warning"><?= str_repeat('⭐', $review['rating']) ?></span>
                    <p class="mb-0"><?= htmlspecialchars($review['comment']) ?></p>
                    <small class="text-muted"><?= $review['created_at'] ?></small>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Footer -->
<?php include '../includes/opac_footer.php'; ?>
</body>
</html>
