<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();

$db = getDB();
$id = (int)($_GET['id'] ?? 0);
$book = $db->prepare("SELECT * FROM books WHERE id = ? AND status != 'Deleted'")->execute([$id])->fetch();
if (!$book) { header('Location: index.php'); exit; }

$holdError = '';
$holdSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_hold'])) {
    // ... hold logic unchanged ...
}

$coverBase64 = getCoverBase64($book['cover_path'] ?? '');
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($book['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include '../includes/opac_header.php'; ?>
<div class="container my-4">
    <div class="row">
        <div class="col-md-4">
            <?php if ($coverBase64): ?>
                <img src="<?= $coverBase64 ?>" class="img-fluid rounded shadow" alt="Cover">
            <?php else: ?>
                <div class="bg-light p-5 text-center rounded"><i class="fas fa-book fa-5x text-secondary"></i></div>
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <!-- rest of book details unchanged -->
        </div>
    </div>
</div>
<?php include '../includes/opac_footer.php'; ?>
</body>
</html>