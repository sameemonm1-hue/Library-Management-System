<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'new_arrivals' => 'New Arrivals',
        'books' => 'Books',
        'ebooks' => 'eBooks',
        'all' => 'All',
        'author' => 'Author',
        'publisher' => 'Publisher',
        'category' => 'Category',
        'isbn' => 'ISBN',
        'year' => 'Year',
        'available' => 'Available',
        'not_available' => 'Not Available',
        'copies_available' => 'copies available',
        'view_details' => 'View Details',
        'search' => 'Search',
        'filter_by_category' => 'Filter by Category',
        'all_categories' => 'All Categories',
        'no_books_found' => 'No books found',
        'back_to_home' => 'Back to Home',
        'opac' => 'OPAC',
        'library_hours' => 'Library Hours',
        'designed_by' => 'Designed by',
        'all_rights_reserved' => 'All rights reserved.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'new_arrivals' => 'नई आगमन',
        'books' => 'पुस्तकें',
        'ebooks' => 'ई-पुस्तकें',
        'all' => 'सभी',
        'author' => 'लेखक',
        'publisher' => 'प्रकाशक',
        'category' => 'श्रेणी',
        'isbn' => 'ISBN',
        'year' => 'वर्ष',
        'available' => 'उपलब्ध',
        'not_available' => 'उपलब्ध नहीं',
        'copies_available' => 'प्रतियाँ उपलब्ध',
        'view_details' => 'विवरण देखें',
        'search' => 'खोजें',
        'filter_by_category' => 'श्रेणी के अनुसार फ़िल्टर करें',
        'all_categories' => 'सभी श्रेणियाँ',
        'no_books_found' => 'कोई पुस्तक नहीं मिली',
        'back_to_home' => 'होम पर वापस जाएं',
        'opac' => 'OPAC',
        'library_hours' => 'पुस्तकालय समय',
        'designed_by' => 'द्वारा डिज़ाइन किया गया',
        'all_rights_reserved' => 'सर्वाधिकार सुरक्षित।',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'new_arrivals' => 'الوافدون الجدد',
        'books' => 'الكتب',
        'ebooks' => 'الكتب الإلكترونية',
        'all' => 'الكل',
        'author' => 'المؤلف',
        'publisher' => 'الناشر',
        'category' => 'التصنيف',
        'isbn' => 'الترقيم الدولي',
        'year' => 'السنة',
        'available' => 'متوفر',
        'not_available' => 'غير متوفر',
        'copies_available' => 'نسخ متاحة',
        'view_details' => 'عرض التفاصيل',
        'search' => 'بحث',
        'filter_by_category' => 'تصفية حسب التصنيف',
        'all_categories' => 'جميع التصنيفات',
        'no_books_found' => 'لم يتم العثور على كتب',
        'back_to_home' => 'العودة إلى الرئيسية',
        'opac' => 'الفهرس العام',
        'library_hours' => 'ساعات المكتبة',
        'designed_by' => 'تصميم',
        'all_rights_reserved' => 'جميع الحقوق محفوظة.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

function getHeaderLogoUrl() {
    global $settings, $institution;
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    $logoKeys = ['opac_header_logo', 'library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
        }
    }
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%231e3c72\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}
$logoUrl = getHeaderLogoUrl();

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = (int)($settings['opac_books_per_page'] ?? 12);
$offset = ($page - 1) * $perPage;
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$whereConditions = ["status != 'Deleted'"];
$params = [];
if (!empty($category)) {
    $whereConditions[] = "category = ?";
    $params[] = $category;
}
if (!empty($search)) {
    $whereConditions[] = "(title LIKE ? OR author LIKE ? OR isbn LIKE ? OR publisher LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$whereClause = count($whereConditions) > 0 ? "WHERE " . implode(" AND ", $whereConditions) : "";
$countStmt = $db->prepare("SELECT COUNT(*) FROM books $whereClause");
$countStmt->execute($params);
$totalBooks = $countStmt->fetchColumn();
$totalPages = ceil($totalBooks / $perPage);
$stmt = $db->prepare("SELECT * FROM books $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->execute(array_merge($params, [$perPage, $offset]));
$books = $stmt->fetchAll();
$categories = $db->query("SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category != '' AND status != 'Deleted' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

$opacHeaderBgColor = $settings['opac_header_bg_color'] ?? '#1e3c72';
$opacPrimaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
$opacFontFamily = $settings['opac_font_family'] ?? 'Inter';
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('new_arrivals') ?> - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($opacFontFamily) ?>:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: '<?= $opacFontFamily ?>', 'Inter', sans-serif; }
        body { background: #f0f2f5; }
        .header-bg { background: <?= $opacHeaderBgColor ?>; color: white; padding: 15px 0; margin-bottom: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header-container { display: flex; align-items: center; justify-content: space-between; max-width: 1400px; margin: 0 auto; padding: 0 20px; }
        .header-left img { height: 60px; width: auto; max-width: 130px; object-fit: contain; background: white; border-radius: 8px; padding: 5px; }
        .header-title h1 { font-size: 1.8rem; font-weight: 600; margin: 0; }
        .header-title p { margin: 0; opacity: 0.9; }
        .lang-switch { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 30px; padding: 6px 15px; color: white; text-decoration: none; font-size: 13px; transition: all 0.3s; }
        .lang-switch:hover { background: rgba(255,255,255,0.25); color: white; }
        .book-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: all 0.3s; cursor: pointer; height: 100%; }
        .book-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.15); }
        .book-cover { height: 220px; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #f5f7fa, #e9ecef); }
        .book-cover img { max-height: 180px; width: auto; object-fit: contain; }
        .book-status { position: absolute; top: 10px; right: 10px; }
        .pagination .page-link { color: <?= $opacPrimaryColor ?>; }
        .pagination .active .page-link { background: <?= $opacPrimaryColor ?>; border-color: <?= $opacPrimaryColor ?>; color: white; }
        .filter-sidebar { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); position: sticky; top: 20px; }
        .category-list { list-style: none; padding: 0; }
        .category-list li { margin-bottom: 10px; }
        .category-list a { color: #333; text-decoration: none; display: block; padding: 5px 10px; border-radius: 6px; transition: all 0.3s; }
        .category-list a:hover, .category-list a.active { background: <?= $opacPrimaryColor ?>; color: white; }
        .footer { background: #1a1a2e; color: #eee; padding: 30px 0 20px; margin-top: 50px; }
        .footer a { color: #ffd700; text-decoration: none; }
        [dir="rtl"] .me-2 { margin-right: 0 !important; margin-left: 0.5rem !important; }
        [dir="rtl"] .ms-2 { margin-left: 0 !important; margin-right: 0.5rem !important; }
        @media (max-width: 768px) { .header-container { flex-direction: column; gap: 10px; text-align: center; } .header-title h1 { font-size: 1.3rem; } .book-cover { height: 180px; } }
    </style>
</head>
<body>

<div class="header-bg">
    <div class="header-container">
        <div class="header-left"><img src="<?= htmlspecialchars($logoUrl) ?>" alt="Logo"></div>
        <div class="header-title text-center"><h1><?= __('new_arrivals') ?></h1><p><?= htmlspecialchars($institution['name'] ?? 'Library System') ?></p></div>
        <div>
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container mt-2">
        <a href="index.php" class="btn btn-outline-light btn-sm"><i class="fas fa-arrow-left"></i> <?= __('back_to_home') ?></a>
        <a href="ebooks.php" class="btn btn-outline-warning btn-sm ms-2"><i class="fas fa-file-pdf"></i> <?= __('ebooks') ?></a>
    </div>
</div>

<div class="container">
    <div class="row g-4">
        <div class="col-lg-3">
            <div class="filter-sidebar">
                <h5><i class="fas fa-filter"></i> <?= __('filter_by_category') ?></h5><hr>
                <ul class="category-list">
                    <li><a href="new_arrivals.php" class="<?= empty($category) ? 'active' : '' ?>"><?= __('all_categories') ?> (<?= $totalBooks ?>)</a></li>
                    <?php foreach ($categories as $cat): 
                        $catCount = $db->prepare("SELECT COUNT(*) FROM books WHERE category = ? AND status != 'Deleted'")->execute([$cat])->fetchColumn();
                    ?>
                    <li><a href="?category=<?= urlencode($cat) ?>" class="<?= $category == $cat ? 'active' : '' ?>"><?= htmlspecialchars($cat) ?> (<?= $catCount ?>)</a></li>
                    <?php endforeach; ?>
                </ul>
                <hr>
                <h5><i class="fas fa-search"></i> <?= __('search') ?></h5>
                <form method="GET" action="">
                    <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search books..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </form>
                <?php if (function_exists('getLibraryHoursHTML')): ?><hr><?= getLibraryHoursHTML() ?><?php endif; ?>
            </div>
        </div>
        <div class="col-lg-9">
            <?php if (empty($books)): ?>
                <div class="alert alert-info text-center py-5"><i class="fas fa-book-open fa-3x mb-3"></i><h5><?= __('no_books_found') ?></h5></div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($books as $book): 
                        $coverBase64 = getCoverBase64($book['cover_path'] ?? '');
                    ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="book-card" onclick="viewBook('<?= htmlspecialchars($book['barcode']) ?>')">
                            <div class="book-cover position-relative">
                                <?php if ($coverBase64): ?><img src="<?= $coverBase64 ?>" alt="<?= htmlspecialchars($book['title']) ?>"><?php else: ?><i class="fas fa-book fa-4x text-muted"></i><?php endif; ?>
                                <div class="book-status"><span class="badge <?= $book['available'] > 0 ? 'bg-success' : 'bg-danger' ?>"><?= $book['available'] > 0 ? __('available') : __('not_available') ?></span></div>
                            </div>
                            <div class="card-body p-3">
                                <h6 class="card-title fw-semibold mb-1"><?= htmlspecialchars(substr($book['title'], 0, 50)) ?></h6>
                                <p class="small text-muted mb-1"><i class="fas fa-user"></i> <?= htmlspecialchars($book['author'] ?? 'Unknown') ?></p>
                                <?php if (!empty($book['publisher'])): ?><p class="small text-muted mb-1"><i class="fas fa-building"></i> <?= htmlspecialchars(substr($book['publisher'], 0, 30)) ?></p><?php endif; ?>
                                <div class="mt-2">
                                    <small class="text-muted"><i class="fas fa-calendar"></i> <?= formatDate($book['created_at'], 'd M Y') ?></small>
                                    <?php if ($book['available'] > 0): ?><span class="badge bg-info float-end"><?= $book['available'] ?> <?= __('copies_available') ?></span><?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php if ($totalPages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page-1 ?>&category=<?= urlencode($category) ?>&search=<?= urlencode($search) ?>">«</a></li>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="?page=<?= $i ?>&category=<?= urlencode($category) ?>&search=<?= urlencode($search) ?>"><?= $i ?></a></li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="?page=<?= $page+1 ?>&category=<?= urlencode($category) ?>&search=<?= urlencode($search) ?>">»</a></li>
                    </ul>
                </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container text-center">
        <p class="small mb-0">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. <?= __('all_rights_reserved') ?></p>
        <p class="small mt-1"><?= __('designed_by') ?> <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank">Sameermon</a></p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function viewBook(barcode) {
    fetch(`book_details.php?barcode=${encodeURIComponent(barcode)}`)
        .then(r => r.json())
        .then(book => {
            if (book) {
                let coverHtml = book.cover_base64 ? `<img src="${book.cover_base64}" class="img-fluid mb-3" style="max-height:250px; border-radius:10px;">` : '<div class="text-center mb-3"><i class="fas fa-book fa-5x text-muted"></i></div>';
                let statusBadge = book.available > 0 ? '<span class="badge bg-success">' + book.available + ' <?= __('copies_available') ?></span>' : '<span class="badge bg-danger"><?= __('not_available') ?></span>';
                document.getElementById('bookDetailsContent').innerHTML = `
                    <div class="row">
                        <div class="col-md-4 text-center">${coverHtml}</div>
                        <div class="col-md-8">
                            <h4 class="mb-2">${escapeHtml(book.title)}</h4><hr>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('author') ?>:</div><div class="col-8">${escapeHtml(book.author || 'Unknown')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('publisher') ?>:</div><div class="col-8">${escapeHtml(book.publisher || 'Unknown')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('isbn') ?>:</div><div class="col-8">${escapeHtml(book.isbn || 'N/A')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('category') ?>:</div><div class="col-8">${escapeHtml(book.category || 'Uncategorized')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('year') ?>:</div><div class="col-8">${escapeHtml(book.year || 'N/A')}</div></div>
                            <div class="row mb-2"><div class="col-4 fw-bold"><?= __('available') ?>:</div><div class="col-8">${statusBadge}</div></div>
                            <div class="mt-3"><strong><?= __('summary') ?>:</strong><p class="mt-1">${escapeHtml(book.summary || '<?= __('no_summary') ?>')}</p></div>
                        </div>
                    </div>`;
                new bootstrap.Modal(document.getElementById('bookModal')).show();
            }
        });
}
function escapeHtml(s) { if (!s) return ''; return s.replace(/[&<>]/g, function(m) { if (m === '&') return '&amp;'; if (m === '<') return '&lt;'; if (m === '>') return '&gt;'; return m; }); }
</script>
</body>
</html>