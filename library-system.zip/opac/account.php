<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php'; // FIXED: Added for getSettings() and other helpers

// Start session only if not already active (prevents warning)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

$db = getDB();
$memberId = $_SESSION['member_id'];

// Ensure loans table has renewals column
$colCheck = $db->query("PRAGMA table_info(loans)")->fetchAll(PDO::FETCH_COLUMN, 1);
if (!in_array('renewals', $colCheck)) {
    $db->exec("ALTER TABLE loans ADD COLUMN renewals INTEGER DEFAULT 0");
}

// Current loans from loans table
$loans = $db->prepare("SELECT l.*, b.title, b.author, b.barcode FROM loans l JOIN books b ON l.book_id = b.id WHERE l.member_id = ? AND l.return_date IS NULL ORDER BY l.due_date");
$loans->execute([$memberId]);
$loans = $loans->fetchAll();

// Holds from book_holds table
$holds = $db->prepare("SELECT h.*, b.title FROM book_holds h JOIN books b ON h.book_barcode = b.barcode WHERE h.admno = (SELECT admno FROM members WHERE id = ?) ORDER BY h.hold_date");
$holds->execute([$memberId]);
$holds = $holds->fetchAll();

// Fines
$memberStmt = $db->prepare("SELECT total_fines FROM members WHERE id = ?");
$memberStmt->execute([$memberId]);
$member = $memberStmt->fetch();
$totalFines = $member['total_fines'] ?? 0;

// Renew loan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['renew_id'])) {
    $loanId = (int)$_POST['renew_id'];
    $settings = getSettings();
    $maxRenewals = (int)($settings['max_renewals'] ?? 2);
    $extraDays = (int)($settings['renewal_days'] ?? 14);
    $stmt = $db->prepare("SELECT renewals, due_date FROM loans WHERE id = ? AND member_id = ? AND return_date IS NULL");
    $stmt->execute([$loanId, $memberId]);
    $loan = $stmt->fetch();
    if ($loan && $loan['renewals'] < $maxRenewals) {
        $newDue = date('Y-m-d', strtotime($loan['due_date'] . " +$extraDays days"));
        $db->prepare("UPDATE loans SET due_date = ?, renewals = renewals + 1 WHERE id = ?")->execute([$newDue, $loanId]);
        header('Location: account.php?renewed=1');
        exit;
    } else {
        header('Location: account.php?error=max_renewals');
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Account</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include '../includes/opac_header.php'; ?>
<div class="container my-4">
    <h2>Welcome, <?= htmlspecialchars($_SESSION['member_name']) ?></h2>
    <?php if (isset($_GET['renewed'])): ?>
        <div class="alert alert-success">Loan renewed successfully.</div>
    <?php elseif (isset($_GET['error']) && $_GET['error'] == 'max_renewals'): ?>
        <div class="alert alert-warning">Maximum renewals reached for this item.</div>
    <?php elseif (isset($_GET['paid'])): ?>
        <div class="alert alert-success">Payment received. Thank you.</div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="fas fa-book"></i> Current Loans</h5></div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light"><tr><th>Title</th><th>Due Date</th><th>Renew</th></tr></thead>
                        <tbody>
                        <?php if (empty($loans)): ?>
                            <tr><td colspan="3" class="text-center text-muted">No active loans</td></tr>
                        <?php else: ?>
                            <?php foreach ($loans as $loan): ?>
                            <tr>
                                <td><?= htmlspecialchars($loan['title']) ?></td>
                                <td><?= $loan['due_date'] ?></td>
                                <td>
                                    <form method="post">
                                        <input type="hidden" name="renew_id" value="<?= $loan['id'] ?>">
                                        <button class="btn btn-sm btn-success">Renew</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-info text-white"><h5 class="mb-0"><i class="fas fa-hand-paper"></i> Holds</h5></div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <?php if (empty($holds)): ?>
                            <li class="list-group-item text-muted">No active holds</li>
                        <?php else: ?>
                            <?php foreach ($holds as $hold): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?= htmlspecialchars($hold['title']) ?>
                                <span class="badge bg-secondary"><?= $hold['status'] ?></span>
                                <?php if ($hold['status'] == 'pending'): ?>
                                    <a href="holds.php?cancel=<?= $hold['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Cancel hold?')">Cancel</a>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="card shadow-sm">
                <div class="card-header bg-danger text-white"><h5 class="mb-0"><i class="fas fa-rupee-sign"></i> Fines</h5></div>
                <div class="card-body text-center">
                    <h3>₹<?= number_format($totalFines, 2) ?></h3>
                    <?php if ($totalFines > 0): ?>
                        <a href="pay.php" class="btn btn-warning"><i class="fas fa-credit-card"></i> Pay Online</a>
                    <?php else: ?>
                        <p class="text-muted">No outstanding fines.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include '../includes/opac_footer.php'; ?>
</body>
</html>