<?php
/**
 * OPAC Member Account Page
 * Shows profile, current loans, holds, fines, and password change.
 * Uses circulation table for loans.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Start session if not already active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit;
}

$db = getDB();
$memberId = $_SESSION['member_id'];
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '₹';
$basePath = BASE_PATH;

// Fetch member details
$memberStmt = $db->prepare("SELECT * FROM members WHERE id = ?");
$memberStmt->execute([$memberId]);
$member = $memberStmt->fetch();
if (!$member) {
    session_destroy();
    header('Location: login.php');
    exit;
}
$admno = $member['admno'];

// CSRF token for password change
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if renew_count column exists in circulation
$cols = $db->query("PRAGMA table_info(circulation)")->fetchAll(PDO::FETCH_COLUMN, 1);
$hasRenewCount = in_array('renew_count', $cols);

// Get settings for renewal limits
$maxRenewals = (int)($settings['max_renewals'] ?? 2);
$renewalDays = (int)($settings['renewal_days'] ?? 14);

// Handle loan renewal
$renewMessage = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['renew_id'])) {
    $loanId = (int)$_POST['renew_id'];
    $loanCheck = $db->prepare("SELECT id, barcode, due_date, renew_count FROM circulation WHERE id = ? AND admno = ? AND return_date IS NULL");
    $loanCheck->execute([$loanId, $admno]);
    $loan = $loanCheck->fetch();
    if ($loan) {
        $currentRenew = (int)($loan['renew_count'] ?? 0);
        if ($hasRenewCount && $currentRenew < $maxRenewals) {
            $newDue = date('Y-m-d', strtotime($loan['due_date'] . " +$renewalDays days"));
            $update = $db->prepare("UPDATE circulation SET due_date = ?, renew_count = renew_count + 1 WHERE id = ?");
            $update->execute([$newDue, $loanId]);
            $renewMessage = ['type' => 'success', 'text' => 'Loan renewed successfully. New due date: ' . date('d-m-Y', strtotime($newDue))];
        } else {
            $renewMessage = ['type' => 'warning', 'text' => 'Maximum renewals reached for this item.'];
        }
    } else {
        $renewMessage = ['type' => 'danger', 'text' => 'Invalid loan.'];
    }
}

// Handle password change
$passwordMessage = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $passwordMessage = ['type' => 'danger', 'text' => 'Invalid security token'];
    } else {
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];

        if ($new !== $confirm) {
            $passwordMessage = ['type' => 'danger', 'text' => 'New passwords do not match'];
        } elseif (strlen($new) < 6) {
            $passwordMessage = ['type' => 'danger', 'text' => 'Password must be at least 6 characters'];
        } else {
            $stmt = $db->prepare("SELECT password FROM members WHERE admno = ?");
            $stmt->execute([$admno]);
            $memberPass = $stmt->fetch();
            if ($memberPass && password_verify($current, $memberPass['password'])) {
                $newHash = password_hash($new, PASSWORD_DEFAULT);
                $update = $db->prepare("UPDATE members SET password = ? WHERE admno = ?");
                $update->execute([$newHash, $admno]);
                $passwordMessage = ['type' => 'success', 'text' => 'Password changed successfully'];
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } else {
                $passwordMessage = ['type' => 'danger', 'text' => 'Current password is incorrect'];
            }
        }
    }
}

// Fetch active loans from circulation
$loansStmt = $db->prepare("
    SELECT c.id, c.barcode, c.title, c.author, c.due_date, c.issue_date, c.renew_count,
           b.cover_path
    FROM circulation c
    LEFT JOIN books b ON c.barcode = b.barcode
    WHERE c.admno = ? AND c.return_date IS NULL
    ORDER BY c.due_date ASC
");
$loansStmt->execute([$admno]);
$loans = $loansStmt->fetchAll();

// Fetch holds from book_holds
$holdsStmt = $db->prepare("
    SELECT h.id, h.book_barcode, h.hold_date, h.expiry_date, h.status,
           b.title, b.author
    FROM book_holds h
    LEFT JOIN books b ON h.book_barcode = b.barcode
    WHERE h.admno = ? AND h.status IN ('pending', 'available')
    ORDER BY h.hold_date ASC
");
$holdsStmt->execute([$admno]);
$holds = $holdsStmt->fetchAll();

$totalFines = (float)($member['total_fines'] ?? 0);
$overdueCount = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now')");
$overdueCount->execute([$admno]);
$overdueCount = $overdueCount->fetchColumn();

// ========== IMAGE HELPERS ==========
/**
 * Get a web-accessible URL for a stored image path.
 * Handles both relative and absolute paths, and ensures it works in subdirectories.
 */
function getImageUrl($path) {
    if (empty($path)) return '';
    // If it's already a full URL, return it
    if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
    // Use the existing getWebImageUrl from functions.php
    // It prepends the base URL (http://host/) to the path (after ltrim)
    return getWebImageUrl($path);
}

/**
 * Check if an image file exists on the server.
 * Handles paths relative to BASE_PATH or absolute.
 */
function imageFileExists($path) {
    if (empty($path)) return false;
    // If it's a full URL, we can't check file existence, assume it's valid
    if (filter_var($path, FILTER_VALIDATE_URL)) return true;
    // Build full filesystem path
    $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    return file_exists($fullPath);
}

// Format date helper
function formatDate($date) {
    return $date ? date('d-m-Y', strtotime($date)) : '-';
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Library OPAC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .container { max-width: 1100px; }
        .card { border: none; border-radius: 16px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); }
        .card-header { background: #1e3c72; color: white; border-radius: 16px 16px 0 0 !important; }
        .card-header.bg-info { background: #17a2b8 !important; }
        .card-header.bg-danger { background: #dc3545 !important; }
        .btn-renew { background: #28a745; color: white; }
        .btn-renew:hover { background: #218838; color: white; }
        .btn-pay { background: #ffc107; color: #212529; }
        .btn-pay:hover { background: #e0a800; color: #212529; }
        .fine-amount { font-size: 2rem; font-weight: bold; color: #dc3545; }
        .book-cover-small { width: 50px; height: 68px; object-fit: cover; border-radius: 6px; border: 1px solid #ddd; background: #f8f9fa; }
        .book-cover-placeholder { width: 50px; height: 68px; background: #f1f3f5; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: #adb5bd; border: 1px solid #ddd; }
        .profile-photo { width: 120px; height: 120px; object-fit: cover; border-radius: 50%; border: 3px solid #1e3c72; background: #f8f9fa; }
        .profile-photo-placeholder { width: 120px; height: 120px; border-radius: 50%; background: #e9ecef; display: flex; align-items: center; justify-content: center; color: #6c757d; font-size: 4rem; border: 3px solid #1e3c72; }
        .back-link { text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
        .stats-number { font-size: 1.8rem; font-weight: bold; }
        .stats-label { color: #6c757d; font-size: 0.9rem; }
        .section-title { border-left: 4px solid #1e3c72; padding-left: 12px; margin: 1.5rem 0 1rem; }
        .table-responsive { background: white; border-radius: 12px; overflow: hidden; }
        .table th { background: #f8f9fc; border-bottom: 2px solid #e9ecef; }
        .alert { border-radius: 12px; }
    </style>
</head>
<body>
    <!-- OPAC Header (if available) -->
    <?php if (file_exists('../includes/opac_header.php')): ?>
        <?php include '../includes/opac_header.php'; ?>
    <?php else: ?>
        <!-- Fallback header -->
        <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #1e3c72, #2a5298);">
            <div class="container">
                <a class="navbar-brand fw-bold" href="index.php"><i class="fas fa-book-open"></i> Library OPAC</a>
                <div class="ms-auto">
                    <a href="index.php" class="btn btn-outline-light btn-sm"><i class="fas fa-home"></i> Home</a>
                    <a href="logout.php" class="btn btn-outline-light btn-sm ms-2"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <div class="container my-4">
        <?php if ($renewMessage): ?>
            <div class="alert alert-<?= $renewMessage['type'] ?> alert-dismissible fade show">
                <?= htmlspecialchars($renewMessage['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if ($passwordMessage): ?>
            <div class="alert alert-<?= $passwordMessage['type'] ?> alert-dismissible fade show">
                <?= htmlspecialchars($passwordMessage['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Welcome + Quick Stats -->
        <div class="alert alert-info">
            <i class="fas fa-hand-wave"></i> Welcome back, <strong><?= htmlspecialchars($member['name']) ?></strong>!
            <?php if ($overdueCount > 0): ?>
                <span class="badge bg-danger ms-2"><?= $overdueCount ?> overdue book(s)</span>
            <?php endif; ?>
        </div>

        <!-- Profile Section -->
        <div class="card mb-4">
            <div class="card-header"><i class="fas fa-id-card"></i> My Profile</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2 text-center">
                        <?php 
                        $photoPath = $member['photo_path'] ?? '';
                        $photoExists = imageFileExists($photoPath);
                        if ($photoExists && $photoPath):
                            $photoUrl = getImageUrl($photoPath);
                        ?>
                            <img src="<?= htmlspecialchars($photoUrl) ?>" class="profile-photo" alt="Profile Photo">
                        <?php else: ?>
                            <div class="profile-photo-placeholder"><i class="fas fa-user-circle"></i></div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-10">
                        <h4><?= htmlspecialchars($member['name']) ?></h4>
                        <p class="text-muted"><?= htmlspecialchars($member['member_category'] ?? '') ?></p>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <p><strong>Admission No:</strong> <?= htmlspecialchars($member['admno']) ?></p>
                                <p><strong>Class/Dept:</strong> <?= htmlspecialchars($member['class'] ?? '-') ?> / <strong>Div/Course:</strong> <?= htmlspecialchars($member['division'] ?? '-') ?></p>
                                <p><strong>Roll No:</strong> <?= htmlspecialchars($member['roll_no'] ?? '-') ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Email:</strong> <?= htmlspecialchars($member['email'] ?? '-') ?></p>
                                <p><strong>Phone:</strong> <?= htmlspecialchars($member['phone'] ?? '-') ?></p>
                                <p><strong>DOB:</strong> <?= formatDate($member['dob'] ?? '') ?></p>
                            </div>
                        </div>
                        <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($member['address'] ?? '')) ?></p>
                    </div>
                </div>
                <hr>
                <div class="row g-3">
                    <div class="col-md-3 col-6">
                        <div class="stats-card text-center p-2">
                            <div class="stats-number"><?= count($loans) ?></div>
                            <div class="stats-label">Currently Issued</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stats-card text-center p-2">
                            <div class="stats-number text-danger"><?= $overdueCount ?></div>
                            <div class="stats-label">Overdue</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stats-card text-center p-2">
                            <div class="stats-number" style="color: #dc3545;"><?= $currencySymbol . number_format($totalFines, 2) ?></div>
                            <div class="stats-label">Total Fines</div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6">
                        <div class="stats-card text-center p-2">
                            <div class="stats-number"><?= (int)($member['total_issued'] ?? 0) ?></div>
                            <div class="stats-label">Lifetime Borrowed</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Current Loans -->
        <div class="section-title">
            <h5><i class="fas fa-book"></i> Current Loans</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr><th>Book</th><th>Author</th><th>Issue Date</th><th>Due Date</th><th>Renew</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($loans)): ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No books currently issued.</td></tr>
                    <?php else: ?>
                        <?php foreach ($loans as $loan): 
                            $coverPath = $loan['cover_path'] ?? '';
                            $coverExists = imageFileExists($coverPath);
                            $isOverdue = strtotime($loan['due_date']) < time();
                            $currentRenew = (int)($loan['renew_count'] ?? 0);
                            $canRenew = $hasRenewCount && ($currentRenew < $maxRenewals);
                        ?>
                        <tr class="<?= $isOverdue ? 'table-danger' : '' ?>">
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <?php if ($coverExists && $coverPath): ?>
                                        <img src="<?= htmlspecialchars(getImageUrl($coverPath)) ?>" class="book-cover-small" alt="Cover">
                                    <?php else: ?>
                                        <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="fw-semibold"><?= htmlspecialchars($loan['title']) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($loan['barcode']) ?></small>
                                    </div>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($loan['author'] ?? '-') ?></td>
                            <td><?= formatDate($loan['issue_date']) ?></td>
                            <td class="<?= $isOverdue ? 'text-danger fw-bold' : '' ?>">
                                <?= formatDate($loan['due_date']) ?>
                                <?php if ($isOverdue): ?>
                                    <span class="badge bg-danger">Overdue</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($hasRenewCount): ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="renew_id" value="<?= $loan['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-renew" <?= !$canRenew ? 'disabled' : '' ?>>
                                            <i class="fas fa-sync-alt"></i> Renew
                                        </button>
                                    </form>
                                    <br><small class="text-muted">Renewals: <?= $currentRenew ?>/<?= $maxRenewals ?></small>
                                <?php else: ?>
                                    <span class="text-muted small">Renewals not available</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Holds -->
        <div class="section-title mt-4">
            <h5><i class="fas fa-hand-paper"></i> Holds</h5>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>Title</th><th>Author</th><th>Status</th></tr></thead>
                <tbody>
                    <?php if (empty($holds)): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">No active holds.</td></tr>
                    <?php else: ?>
                        <?php foreach ($holds as $hold): ?>
                        <tr>
                            <td><?= htmlspecialchars($hold['title']) ?></td>
                            <td><?= htmlspecialchars($hold['author'] ?? '-') ?></td>
                            <td><span class="badge bg-<?= $hold['status'] == 'available' ? 'success' : 'secondary' ?>"><?= ucfirst($hold['status']) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Fines & Actions -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger"><i class="fas fa-rupee-sign"></i> Fines</div>
                    <div class="card-body text-center">
                        <div class="fine-amount"><?= $currencySymbol . number_format($totalFines, 2) ?></div>
                        <?php if ($totalFines > 0): ?>
                            <a href="pay.php" class="btn btn-pay btn-lg mt-2"><i class="fas fa-credit-card"></i> Pay Online</a>
                        <?php else: ?>
                            <p class="text-muted">No outstanding fines.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-warning text-dark"><i class="fas fa-key"></i> Account Actions</div>
                    <div class="card-body text-center">
                        <button class="btn btn-outline-warning" data-bs-toggle="modal" data-bs-target="#changePasswordModal"><i class="fas fa-key"></i> Change Password</button>
                        <a href="../opac/" class="btn btn-primary"><i class="fas fa-search"></i> Search Catalog</a>
                        <a href="logout.php" class="btn btn-outline-secondary"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <a href="index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to OPAC</a>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="admno" value="<?= htmlspecialchars($admno) ?>">
                        <div class="mb-3">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="mb-3">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- OPAC Footer (if available) -->
    <?php if (file_exists('../includes/opac_footer.php')): ?>
        <?php include '../includes/opac_footer.php'; ?>
    <?php else: ?>
        <!-- Fallback footer -->
        <footer class="text-center py-3 mt-4" style="border-top: 1px solid #dee2e6; color: #6c757d; font-size: 0.9rem;">
            &copy; <?= date('Y') ?> Library OPAC. All rights reserved.
        </footer>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>