<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$keyword = trim($_GET['keyword'] ?? '');
$subject = trim($_GET['subject'] ?? '');

logSearch($db, $keyword, null, 'ebooks');

$sql = "SELECT id, title, author, subject, isbn, publisher, year, description, cover_path, file_path, downloads 
        FROM ebooks WHERE 1=1";
$params = [];

if(!empty($keyword)) {
    $sql .= " AND (title LIKE ? OR author LIKE ? OR subject LIKE ? OR isbn LIKE ? OR publisher LIKE ?)";
    $like = "%$keyword%";
    $params = [$like, $like, $like, $like, $like];
}

if(!empty($subject) && $subject !== 'all') {
    $sql .= " AND subject = ?";
    $params[] = $subject;
}

$sql .= " ORDER BY title LIMIT 50";

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $ebooks = $stmt->fetchAll();
    
    foreach($ebooks as &$ebook) {
        $ebook['cover_base64'] = getCoverBase64($ebook['cover_path'] ?? '');
    }
    
    echo json_encode($ebooks);
    
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

function logSearch($db, $keyword, $bookBarcode = null, $searchType = 'books') {
    // same as before
}
?>