<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== RELIABLE HEADER LOGO URL FUNCTION (same as OPAC) ====================
function getHeaderLogoUrl() {
    global $settings, $institution;
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        if (defined('BASE_URL') && BASE_URL) return rtrim(BASE_URL, '/') . '/' . $cleanPath;
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    $logoKeys = ['opac_header_logo', 'library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
        }
    }
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%231e3c72\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}
$logoUrl = getHeaderLogoUrl();

// Get favicon path
$faviconPath = '';
if(!empty($settings['favicon_path']) && file_exists($settings['favicon_path'])) {
    $faviconPath = str_replace(dirname(__DIR__), '', $settings['favicon_path']);
}

// Digital Libraries Database
$digitalLibraries = [
    // KG Section (Early Learners)
    ['name' => 'Oxford Owl', 'url' => 'https://www.oxfordowl.co.uk', 'age_group' => 'KG', 'category' => 'Early Learning', 'language' => 'English', 'description' => 'Free eBooks for children ages 3-11 with reading activities', 'icon' => '🦉', 'color' => '#FF6B6B', 'features' => ['300+ free eBooks', 'Reading activities', 'Parent guides']],
    ['name' => 'Khan Academy Kids', 'url' => 'https://learn.khanacademy.org/khan-academy-kids', 'age_group' => 'KG', 'category' => 'Interactive Learning', 'language' => 'English', 'description' => 'Joyful learning app for ages 2-8 with thousands of activities', 'icon' => '🎨', 'color' => '#4ECDC4', 'features' => ['Interactive books', 'Math & reading', 'Progress tracking']],
    ['name' => 'StoryPlace', 'url' => 'https://www.storyplace.org', 'age_group' => 'KG', 'category' => 'Storytelling', 'language' => 'English/Spanish', 'description' => 'Virtual storytime and interactive activities', 'icon' => '📖', 'color' => '#45B7D1', 'features' => ['Virtual storytime', 'Interactive games', 'Take-home activities']],
    ['name' => 'Starfall', 'url' => 'https://www.starfall.com', 'age_group' => 'KG', 'category' => 'Phonics', 'language' => 'English', 'description' => 'Learn to read with phonics', 'icon' => '⭐', 'color' => '#F7B32B', 'features' => ['Phonics learning', 'Reading games', 'Printable resources']],
    
    // Primary Section (Grades 1-5)
    ['name' => 'StoryWeaver', 'url' => 'https://storyweaver.org.in', 'age_group' => 'Primary', 'category' => 'Multilingual', 'language' => 'Multiple Languages', 'description' => '50,000+ free children\'s books in 300+ languages', 'icon' => '📚', 'color' => '#20B2AA', 'features' => ['50,000+ books', '300+ languages', 'Create stories']],
    ['name' => 'Epic!', 'url' => 'https://www.getepic.com', 'age_group' => 'Primary', 'category' => 'Digital Library', 'language' => 'English', 'description' => '40,000+ high-quality books for kids 12 and under', 'icon' => '📱', 'color' => '#E63946', 'features' => ['40,000+ books', 'Read-to-me', 'Quizzes']],
    ['name' => 'International Children\'s Library', 'url' => 'https://en.childrenslibrary.org', 'age_group' => 'Primary', 'category' => 'Multicultural', 'language' => 'Multiple Languages', 'description' => 'Children\'s books from around the world', 'icon' => '🌍', 'color' => '#2A9D8F', 'features' => ['Global collection', 'Cultural diversity', 'Free access']],
    ['name' => 'ReadWorks', 'url' => 'https://www.readworks.org', 'age_group' => 'Primary', 'category' => 'Reading Comprehension', 'language' => 'English', 'description' => 'Reading comprehension passages and activities', 'icon' => '📝', 'color' => '#E9C46A', 'features' => ['Teacher resources', 'Differentiated passages', 'Question sets']],
    ['name' => 'CommonLit', 'url' => 'https://www.commonlit.org', 'age_group' => 'Primary', 'category' => 'Literacy', 'language' => 'English', 'description' => 'Reading program with thousands of literacy lessons', 'icon' => '💡', 'color' => '#F4A261', 'features' => ['2,000+ lessons', 'Progress tracking', 'Parent portal']],
    ['name' => 'National Geographic Kids', 'url' => 'https://kids.nationalgeographic.com', 'age_group' => 'Primary', 'category' => 'STEM', 'language' => 'English', 'description' => 'Amazing facts, games, and videos about nature and science', 'icon' => '🦁', 'color' => '#6D6875', 'features' => ['Nature articles', 'Science videos', 'Educational games']],
    
    // Secondary Section (Grades 6-10)
    ['name' => 'Open Library', 'url' => 'https://openlibrary.org', 'age_group' => 'Secondary', 'category' => 'General', 'language' => 'English', 'description' => 'Millions of free books - one web page for every book ever published', 'icon' => '📖', 'color' => '#6A4C93', 'features' => ['3+ million books', 'Borrow online', 'Reading lists']],
    ['name' => 'Project Gutenberg', 'url' => 'https://www.gutenberg.org', 'age_group' => 'Secondary', 'category' => 'Classics', 'language' => 'English', 'description' => '70,000+ free eBooks - world\'s greatest literature', 'icon' => '📕', 'color' => '#9C89B8', 'features' => ['70,000+ eBooks', 'Public domain', 'Multiple formats']],
    ['name' => 'LibriVox', 'url' => 'https://librivox.org', 'age_group' => 'Secondary', 'category' => 'Audiobooks', 'language' => 'English', 'description' => 'Free public domain audiobooks read by volunteers', 'icon' => '🎧', 'color' => '#B8F2E6', 'features' => ['Audiobooks', 'Volunteer narrated', 'MP3 downloads']],
    ['name' => 'Internet Archive', 'url' => 'https://archive.org', 'age_group' => 'Secondary', 'category' => 'Multimedia', 'language' => 'English', 'description' => 'Digital library of books, movies, music, and websites', 'icon' => '🗄️', 'color' => '#AED9E0', 'features' => ['Books, movies & music', 'Web archive', 'Research materials']],
    ['name' => 'Junky Books', 'url' => 'https://www.junkybooks.com', 'age_group' => 'Secondary', 'category' => 'Classic Literature', 'language' => 'English', 'description' => 'Free classic literature eBooks and novels', 'icon' => '📘', 'color' => '#FFE66D', 'features' => ['Classic novels', 'Free downloads', 'No registration']],
    
    // Higher Secondary & College
    ['name' => 'LibreTexts', 'url' => 'https://www.libretexts.org', 'age_group' => 'Higher', 'category' => 'STEM', 'language' => 'English', 'description' => 'Free textbooks and learning materials for STEM subjects', 'icon' => '🔬', 'color' => '#1D3557', 'features' => ['Free textbooks', 'STEM focus', 'Interactive tools']],
    ['name' => 'Google Books', 'url' => 'https://books.google.com', 'age_group' => 'Higher', 'category' => 'General', 'language' => 'English', 'description' => 'Search millions of books from libraries and publishers worldwide', 'icon' => '🔍', 'color' => '#4285F4', 'features' => ['Preview millions', 'Full view classics', 'Research tools']],
    ['name' => 'PDF Drive', 'url' => 'https://www.pdfdrive.com', 'age_group' => 'Higher', 'category' => 'Academic', 'language' => 'English', 'description' => '70+ million PDF eBooks and academic papers', 'icon' => '📑', 'color' => '#E94F37', 'features' => ['70M+ PDFs', 'Academic papers', 'Direct download']],
    ['name' => 'HathiTrust', 'url' => 'https://www.hathitrust.org', 'age_group' => 'Higher', 'category' => 'Research', 'language' => 'English', 'description' => 'Digital library of research materials from academic institutions', 'icon' => '🎓', 'color' => '#2B2D42', 'features' => ['Academic research', 'Digitized collections', 'Public domain']],
    ['name' => 'DOAJ', 'url' => 'https://doaj.org', 'age_group' => 'Higher', 'category' => 'Journals', 'language' => 'English', 'description' => 'Directory of Open Access Journals', 'icon' => '📰', 'color' => '#F25F5C', 'features' => ['Open access journals', 'Peer-reviewed', 'Free articles']],
    ['name' => 'PubMed Central', 'url' => 'https://www.ncbi.nlm.nih.gov/pmc', 'age_group' => 'Higher', 'category' => 'Medical', 'language' => 'English', 'description' => 'Biomedical and life sciences journal literature', 'icon' => '🩺', 'color' => '#008080', 'features' => ['Medical research', 'Life sciences', 'Free access']],
    ['name' => 'Smashwords', 'url' => 'https://www.smashwords.com', 'age_group' => 'Higher', 'category' => 'Independent Publishing', 'language' => 'English', 'description' => 'Indie author eBooks, many free', 'icon' => '✍️', 'color' => '#FF6B6B', 'features' => ['Indie authors', 'Free previews', 'Multiple formats']],
    
    // Research & Specialized
    ['name' => 'Europeana', 'url' => 'https://www.europeana.eu', 'age_group' => 'Research', 'category' => 'Cultural Heritage', 'language' => 'Multilingual', 'description' => 'Digital cultural heritage of Europe', 'icon' => '🏛️', 'color' => '#003C8F', 'features' => ['Art & culture', 'Historical documents', 'Museum collections']],
    ['name' => 'DPLA', 'url' => 'https://dp.la', 'age_group' => 'Research', 'category' => 'Digital Collections', 'language' => 'English', 'description' => 'Digital Public Library of America', 'icon' => '🇺🇸', 'color' => '#FD7E14', 'features' => ['US digital collections', '30M+ items', 'Free access']],
    ['name' => 'Cambridge Digital Library', 'url' => 'https://cudl.lib.cam.ac.uk', 'age_group' => 'Research', 'category' => 'Historical', 'language' => 'English', 'description' => 'Historic manuscripts and rare books', 'icon' => '📜', 'color' => '#8B4513', 'features' => ['Rare manuscripts', 'Historical texts', 'Digitized archives']],
    
    // STEAM & Special Interest
    ['name' => 'NASA STEM', 'url' => 'https://www.nasa.gov/stem', 'age_group' => 'STEAM', 'category' => 'Space Science', 'language' => 'English', 'description' => 'Space science resources and educational materials', 'icon' => '🚀', 'color' => '#0B3D91', 'features' => ['Space articles', 'Educational resources', 'Student activities']],
    ['name' => 'CK-12 Foundation', 'url' => 'https://www.ck12.org', 'age_group' => 'STEAM', 'category' => 'Math & Science', 'language' => 'English', 'description' => 'Free interactive STEM textbooks', 'icon' => '⚡', 'color' => '#3CB371', 'features' => ['FlexBooks', 'Interactive simulations', 'Practice questions']],
    ['name' => 'Code.org', 'url' => 'https://code.org', 'age_group' => 'STEAM', 'category' => 'Coding', 'language' => 'English', 'description' => 'Computer science tutorials and coding games', 'icon' => '💻', 'color' => '#00ADB5', 'features' => ['Coding tutorials', 'Hour of Code', 'Games and apps']],
    ['name' => 'MIT OpenCourseWare', 'url' => 'https://ocw.mit.edu', 'age_group' => 'STEAM', 'category' => 'University', 'language' => 'English', 'description' => 'MIT course materials for free', 'icon' => '🏫', 'color' => '#A31F34', 'features' => ['University courses', 'Lecture notes', 'Video lectures']]
];

// Get unique age groups for filter
$ageGroups = array_unique(array_column($digitalLibraries, 'age_group'));
sort($ageGroups);

// Get categories
$categories = array_unique(array_column($digitalLibraries, 'category'));
sort($categories);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Library Hub - <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></title>
    <?php if($faviconPath): ?>
    <link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>">
    <link rel="shortcut icon" href="<?= $faviconPath ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #003c8f;
            --primary-dark: #002a6a;
            --secondary: #00b4d8;
            --accent: #ff6b6b;
            --success: #4ecdc4;
            --warning: #ffd93d;
            --dark: #2d3436;
            --light: #f8f9fa;
            --gradient: linear-gradient(135deg, #003c8f 0%, #00b4d8 100%);
            --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
            --shadow-md: 0 5px 20px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 30px rgba(0,0,0,0.15);
            --shadow-xl: 0 20px 40px rgba(0,0,0,0.2);
        }
        
        * { font-family: 'Inter', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
        
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
        
        /* Hero Section */
        .hero-section {
            background: var(--gradient);
            color: white;
            padding: 60px 0;
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 70%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(25deg);
            pointer-events: none;
        }
        
        .hero-title {
            font-size: 48px;
            font-weight: 800;
            margin-bottom: 20px;
            animation: fadeInUp 0.8s ease;
        }
        
        .hero-subtitle {
            font-size: 20px;
            opacity: 0.9;
            margin-bottom: 30px;
            animation: fadeInUp 0.8s ease 0.1s backwards;
        }
        
        .hero-stats {
            display: flex;
            gap: 40px;
            justify-content: center;
            margin-top: 40px;
            animation: fadeInUp 0.8s ease 0.2s backwards;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 36px;
            font-weight: 800;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.8;
        }
        
        /* Filter Bar */
        .filter-bar {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-top: -30px;
            margin-bottom: 40px;
            box-shadow: var(--shadow-lg);
            position: relative;
            z-index: 10;
        }
        
        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }
        
        .filter-item {
            flex: 1;
            min-width: 150px;
        }
        
        .filter-label {
            font-size: 12px;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .filter-select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s;
            background: white;
        }
        
        .filter-select:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(0,180,216,0.1);
        }
        
        .search-box {
            position: relative;
        }
        
        .search-box input {
            width: 100%;
            padding: 10px 12px;
            padding-left: 40px;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .search-box input:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(0,180,216,0.1);
        }
        
        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        
        /* Library Grid */
        .libraries-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 50px;
        }
        
        .library-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: var(--shadow-sm);
            position: relative;
            cursor: pointer;
        }
        
        .library-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }
        
        .card-color-bar {
            height: 5px;
            background: var(--primary);
        }
        
        .card-content {
            padding: 20px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }
        
        .library-icon {
            font-size: 48px;
        }
        
        .library-name {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 5px;
        }
        
        .library-url {
            font-size: 11px;
            color: #6c757d;
            word-break: break-all;
        }
        
        .badge-group {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            margin: 2px;
        }
        
        .badge-age { background: #e8f0fe; color: var(--primary); }
        .badge-category { background: #fef3c7; color: #d97706; }
        .badge-lang { background: #dcfce7; color: #16a34a; }
        
        .library-description {
            font-size: 13px;
            color: #6c757d;
            margin: 12px 0;
            line-height: 1.5;
        }
        
        .features-list {
            list-style: none;
            padding: 0;
            margin: 15px 0;
        }
        
        .features-list li {
            font-size: 12px;
            padding: 5px 0;
            color: #495057;
        }
        
        .features-list li i {
            color: var(--success);
            width: 20px;
            margin-right: 8px;
        }
        
        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
        }
        
        .visit-btn {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .visit-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0,60,143,0.3);
            color: white;
        }
        
        .qr-code {
            width: 50px;
            height: 50px;
            cursor: pointer;
            transition: transform 0.3s;
            border-radius: 8px;
        }
        
        .qr-code:hover {
            transform: scale(1.1);
        }
        
        /* QR Modal */
        .qr-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        
        .qr-modal.show {
            opacity: 1;
            visibility: visible;
        }
        
        .qr-modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            max-width: 400px;
            width: 90%;
        }
        
        .qr-modal img {
            width: 250px;
            height: 250px;
            margin: 20px 0;
        }
        
        /* Footer */
        .footer {
            background: var(--primary-dark);
            color: white;
            text-align: center;
            padding: 30px;
            margin-top: 50px;
        }
        
        .footer a {
            color: var(--secondary);
            text-decoration: none;
        }
        
        /* No Results */
        .no-results {
            text-align: center;
            padding: 60px;
            background: white;
            border-radius: 20px;
        }
        
        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero-title { font-size: 32px; }
            .hero-subtitle { font-size: 16px; }
            .hero-stats { gap: 20px; }
            .stat-number { font-size: 24px; }
            .libraries-grid { grid-template-columns: 1fr; }
            .filter-group { flex-direction: column; }
            .filter-item { width: 100%; }
        }
        
        @media (max-width: 480px) {
            .hero-stats { flex-direction: column; gap: 10px; }
            .card-header { flex-direction: column; }
        }
    </style>
</head>
<body>

<!-- Hero Section -->
<div class="hero-section">
    <div class="container">
        <div class="text-center">
            <h1 class="hero-title">
                <i class="fas fa-globe"></i> Digital Library Hub
            </h1>
            <p class="hero-subtitle">
                Your Gateway to 30+ Digital Libraries • Free Educational Resources • Global Knowledge Access
            </p>
            <div class="hero-stats">
                <div class="stat-item">
                    <div class="stat-number"><?= count($digitalLibraries) ?>+</div>
                    <div class="stat-label">Digital Libraries</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">200k+</div>
                    <div class="stat-label">Free Books</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">50+</div>
                    <div class="stat-label">Languages</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">All Ages</div>
                    <div class="stat-label">From KG to Research</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <!-- Filter Bar -->
    <div class="filter-bar">
        <div class="filter-group">
            <div class="filter-item">
                <div class="filter-label"><i class="fas fa-search"></i> Search</div>
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search by name, description, or features...">
                </div>
            </div>
            <div class="filter-item">
                <div class="filter-label"><i class="fas fa-graduation-cap"></i> Age Group</div>
                <select id="ageFilter" class="filter-select">
                    <option value="all">All Ages</option>
                    <?php foreach($ageGroups as $age): ?>
                        <option value="<?= htmlspecialchars($age) ?>"><?= htmlspecialchars($age) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-item">
                <div class="filter-label"><i class="fas fa-tag"></i> Category</div>
                <select id="categoryFilter" class="filter-select">
                    <option value="all">All Categories</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-item">
                <div class="filter-label"><i class="fas fa-flag"></i> Quick Links</div>
                <select id="quickFilter" class="filter-select">
                    <option value="all">All Libraries</option>
                    <option value="featured">⭐ Featured Libraries</option>
                    <option value="most_visited">🔥 Most Visited</option>
                    <option value="new">🆕 Recently Added</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Libraries Grid -->
    <div id="librariesGrid" class="libraries-grid">
        <!-- Dynamic content will be loaded here -->
    </div>
</div>

<!-- QR Code Modal -->
<div id="qrModal" class="qr-modal">
    <div class="qr-modal-content">
        <h3><i class="fas fa-qrcode"></i> Scan to Visit</h3>
        <img id="qrModalImg" src="" alt="QR Code">
        <p id="qrModalUrl"></p>
        <button class="visit-btn" id="qrVisitBtn" onclick="openLink()">Open Website</button>
        <button class="btn btn-secondary mt-2" onclick="closeQRModal()">Close</button>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Digital Library Hub') ?>. All rights reserved.</p>
        <p class="mt-2" style="font-size: 12px; opacity: 0.7;">
            <i class="fas fa-code"></i> Designed by <strong>Sameermon</strong>
        </p>
    </div>
</div>

<script>
// Library data from PHP
const libraries = <?= json_encode($digitalLibraries) ?>;

// Current page URL for QR
let currentUrl = '';

// DOM Elements
const gridContainer = document.getElementById('librariesGrid');
const searchInput = document.getElementById('searchInput');
const ageFilter = document.getElementById('ageFilter');
const categoryFilter = document.getElementById('categoryFilter');
const quickFilter = document.getElementById('quickFilter');

// Render libraries
function renderLibraries() {
    const searchTerm = searchInput.value.toLowerCase();
    const ageValue = ageFilter.value;
    const categoryValue = categoryFilter.value;
    const quickValue = quickFilter.value;
    
    let filtered = libraries.filter(lib => {
        // Search filter
        const matchesSearch = searchTerm === '' || 
            lib.name.toLowerCase().includes(searchTerm) ||
            lib.description.toLowerCase().includes(searchTerm) ||
            lib.features.some(f => f.toLowerCase().includes(searchTerm)) ||
            lib.category.toLowerCase().includes(searchTerm);
        
        // Age filter
        const matchesAge = ageValue === 'all' || lib.age_group === ageValue;
        
        // Category filter
        const matchesCategory = categoryValue === 'all' || lib.category === categoryValue;
        
        // Quick filter
        let matchesQuick = true;
        if (quickValue === 'featured') {
            matchesQuick = lib.name.includes('Oxford') || lib.name.includes('Khan') || lib.name.includes('National Geographic');
        } else if (quickValue === 'most_visited') {
            matchesQuick = lib.name.includes('Google') || lib.name.includes('Project Gutenberg') || lib.name.includes('Internet Archive');
        } else if (quickValue === 'new') {
            matchesQuick = lib.features.includes('New') || lib.name.includes('MIT');
        }
        
        return matchesSearch && matchesAge && matchesCategory && matchesQuick;
    });
    
    if (filtered.length === 0) {
        gridContainer.innerHTML = `
            <div class="no-results" style="grid-column: 1/-1;">
                <i class="fas fa-search fa-3x mb-3" style="color: #6c757d;"></i>
                <h4>No libraries found</h4>
                <p class="text-muted">Try adjusting your search or filter criteria</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    filtered.forEach(lib => {
        // Random color based on name for consistency
        const colorHash = lib.name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        const color = `hsl(${colorHash % 360}, 70%, 55%)`;
        
        html += `
            <div class="library-card" data-url="${lib.url}">
                <div class="card-color-bar" style="background: ${color};"></div>
                <div class="card-content">
                    <div class="card-header">
                        <div>
                            <div class="library-icon">${lib.icon}</div>
                            <div class="library-name">${escapeHtml(lib.name)}</div>
                            <div class="library-url">${escapeHtml(lib.url.replace('https://', ''))}</div>
                        </div>
                        <img class="qr-code" src="https://quickchart.io/qr?text=${encodeURIComponent(lib.url)}&size=100&margin=0" 
                             alt="QR Code" onclick="showQRModal('${lib.url}', '${escapeHtml(lib.name.replace(/'/g, "\\'"))}')">
                    </div>
                    
                    <div class="mt-2">
                        <span class="badge-group badge-age"><i class="fas fa-graduation-cap"></i> ${escapeHtml(lib.age_group)}</span>
                        <span class="badge-group badge-category"><i class="fas fa-tag"></i> ${escapeHtml(lib.category)}</span>
                        <span class="badge-group badge-lang"><i class="fas fa-language"></i> ${escapeHtml(lib.language)}</span>
                    </div>
                    
                    <div class="library-description">${escapeHtml(lib.description)}</div>
                    
                    <ul class="features-list">
                        ${lib.features.map(f => `<li><i class="fas fa-check-circle"></i> ${escapeHtml(f)}</li>`).join('')}
                    </ul>
                    
                    <div class="card-footer">
                        <a href="${lib.url}" target="_blank" class="visit-btn" onclick="event.stopPropagation();">
                            <i class="fas fa-external-link-alt"></i> Visit Library
                        </a>
                        <button class="btn btn-sm btn-outline-secondary" onclick="copyToClipboard('${lib.url}')">
                            <i class="fas fa-copy"></i> Copy URL
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    gridContainer.innerHTML = html;
}

// Show QR Modal
function showQRModal(url, name) {
    currentUrl = url;
    const modal = document.getElementById('qrModal');
    const qrImg = document.getElementById('qrModalImg');
    const urlSpan = document.getElementById('qrModalUrl');
    
    qrImg.src = `https://quickchart.io/qr?text=${encodeURIComponent(url)}&size=300&margin=0`;
    urlSpan.innerHTML = `<strong>${escapeHtml(name)}</strong><br><small>${escapeHtml(url)}</small>`;
    modal.classList.add('show');
}

// Close QR Modal
function closeQRModal() {
    const modal = document.getElementById('qrModal');
    modal.classList.remove('show');
}

// Open link from modal
function openLink() {
    if (currentUrl) {
        window.open(currentUrl, '_blank');
    }
}

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('URL copied to clipboard!', 'success');
    });
}

// Show toast notification
function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '300px';
    toast.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Escape HTML
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

// Debounce function for search
let debounceTimer;
function debounce(func, delay) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(func, delay);
}

// Event listeners
searchInput.addEventListener('input', () => debounce(renderLibraries, 300));
ageFilter.addEventListener('change', renderLibraries);
categoryFilter.addEventListener('change', renderLibraries);
quickFilter.addEventListener('change', renderLibraries);

// Click on card to visit
document.addEventListener('click', function(e) {
    const card = e.target.closest('.library-card');
    if (card && !e.target.closest('.visit-btn') && !e.target.closest('.qr-code') && !e.target.closest('button')) {
        const url = card.getAttribute('data-url');
        if (url) window.open(url, '_blank');
    }
});

// Close modal with escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeQRModal();
    }
});

// Initial render
renderLibraries();

// Stats counter animation
function animateNumbers() {
    const numbers = document.querySelectorAll('.stat-number');
    numbers.forEach(num => {
        const target = parseInt(num.innerText);
        if (target) {
            let current = 0;
            const increment = target / 50;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    num.innerText = target;
                    clearInterval(timer);
                } else {
                    num.innerText = Math.floor(current);
                }
            }, 20);
        }
    });
}
animateNumbers();
</script>

</body>
</html>