<?php
/**
 * Digital Library Hub - Unified Design
 * Version: 2.0 - Expanded with 50+ Digital Libraries
 * 
 * Features:
 * - Curated list of 50+ digital libraries and educational resources
 * - Filtering by age group, category, and search
 * - QR code generation for each resource
 * - Quick access links
 * - Responsive grid layout
 * - Unified with system-wide design (gradient cards, consistent UI)
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== DIGITAL LIBRARIES DATABASE - 50+ SITES ====================
$digitalLibraries = [

    // ===== KG / EARLY LEARNERS (Ages 3-6) =====
    ['name' => 'Oxford Owl', 'url' => 'https://www.oxfordowl.co.uk', 'age_group' => 'KG', 'category' => 'Early Learning', 'language' => 'English', 'description' => 'Free eBooks for children ages 3-11 with reading activities and parent guides.', 'icon' => '🦉', 'color' => '#FF6B6B', 'features' => ['300+ free eBooks', 'Reading activities', 'Parent guides', 'Phonics support']],
    ['name' => 'Khan Academy Kids', 'url' => 'https://learn.khanacademy.org/khan-academy-kids', 'age_group' => 'KG', 'category' => 'Interactive Learning', 'language' => 'English', 'description' => 'Joyful learning app for ages 2-8 with thousands of activities in math, reading, and more.', 'icon' => '🎨', 'color' => '#4ECDC4', 'features' => ['Interactive books', 'Math & reading', 'Progress tracking', 'Offline access']],
    ['name' => 'StoryPlace', 'url' => 'https://www.storyplace.org', 'age_group' => 'KG', 'category' => 'Storytelling', 'language' => 'English/Spanish', 'description' => 'Virtual storytime and interactive activities for preschoolers.', 'icon' => '📖', 'color' => '#45B7D1', 'features' => ['Virtual storytime', 'Interactive games', 'Take-home activities', 'Bilingual']],
    ['name' => 'Starfall', 'url' => 'https://www.starfall.com', 'age_group' => 'KG', 'category' => 'Phonics', 'language' => 'English', 'description' => 'Learn to read with phonics - fun interactive games for early readers.', 'icon' => '⭐', 'color' => '#F7B32B', 'features' => ['Phonics learning', 'Reading games', 'Printable resources', 'Music & songs']],
    ['name' => 'ABCya!', 'url' => 'https://www.abcya.com', 'age_group' => 'KG', 'category' => 'Educational Games', 'language' => 'English', 'description' => 'Educational games and activities for preschool to 6th grade.', 'icon' => '🎮', 'color' => '#E76F51', 'features' => ['300+ games', 'Math & reading', 'Seasonal activities', 'Teacher resources']],
    ['name' => 'PBS Kids', 'url' => 'https://pbskids.org', 'age_group' => 'KG', 'category' => 'Educational Media', 'language' => 'English', 'description' => 'Educational games and videos featuring beloved PBS characters.', 'icon' => '📺', 'color' => '#4A90D9', 'features' => ['Character videos', 'Interactive games', 'Print activities', 'Parent resources']],
    ['name' => 'Sesame Street', 'url' => 'https://www.sesamestreet.org', 'age_group' => 'KG', 'category' => 'Early Learning', 'language' => 'English/Spanish', 'description' => 'Playful learning resources featuring Elmo, Cookie Monster and friends.', 'icon' => '🧸', 'color' => '#F5A623', 'features' => ['Character videos', 'Educational games', 'Bilingual content', 'Parent guides']],
    
    // ===== PRIMARY (Grades 1-5 / Ages 6-11) =====
    ['name' => 'StoryWeaver', 'url' => 'https://storyweaver.org.in', 'age_group' => 'Primary', 'category' => 'Multilingual', 'language' => 'Multiple Languages', 'description' => '50,000+ free children\'s books in 300+ languages from around the world.', 'icon' => '📚', 'color' => '#20B2AA', 'features' => ['50,000+ books', '300+ languages', 'Create stories', 'Read aloud']],
    ['name' => 'Epic!', 'url' => 'https://www.getepic.com', 'age_group' => 'Primary', 'category' => 'Digital Library', 'language' => 'English', 'description' => '40,000+ high-quality books for kids 12 and under, including read-to-me features.', 'icon' => '📱', 'color' => '#E63946', 'features' => ['40,000+ books', 'Read-to-me', 'Quizzes', 'Personalized recommendations']],
    ['name' => 'International Children\'s Library', 'url' => 'https://en.childrenslibrary.org', 'age_group' => 'Primary', 'category' => 'Multicultural', 'language' => 'Multiple Languages', 'description' => 'Children\'s books from around the world celebrating cultural diversity.', 'icon' => '🌍', 'color' => '#2A9D8F', 'features' => ['Global collection', 'Cultural diversity', 'Free access', 'Multiple languages']],
    ['name' => 'ReadWorks', 'url' => 'https://www.readworks.org', 'age_group' => 'Primary', 'category' => 'Reading Comprehension', 'language' => 'English', 'description' => 'Reading comprehension passages and activities for K-12.', 'icon' => '📝', 'color' => '#E9C46A', 'features' => ['Teacher resources', 'Differentiated passages', 'Question sets', 'Paired texts']],
    ['name' => 'CommonLit', 'url' => 'https://www.commonlit.org', 'age_group' => 'Primary', 'category' => 'Literacy', 'language' => 'English', 'description' => 'Reading program with thousands of literacy lessons and progress tracking.', 'icon' => '💡', 'color' => '#F4A261', 'features' => ['2,000+ lessons', 'Progress tracking', 'Parent portal', 'Spanish translations']],
    ['name' => 'National Geographic Kids', 'url' => 'https://kids.nationalgeographic.com', 'age_group' => 'Primary', 'category' => 'STEM', 'language' => 'English', 'description' => 'Amazing facts, games, and videos about nature, science, and animals.', 'icon' => '🦁', 'color' => '#6D6875', 'features' => ['Nature articles', 'Science videos', 'Educational games', 'Animal facts']],
    ['name' => 'Funbrain', 'url' => 'https://www.funbrain.com', 'age_group' => 'Primary', 'category' => 'Educational Games', 'language' => 'English', 'description' => 'Educational games, books, and videos for grades K-8.', 'icon' => '🧠', 'color' => '#F39C12', 'features' => ['Math games', 'Reading books', 'Comics', 'Videos']],
    ['name' => 'Reading Eggs', 'url' => 'https://readingeggs.com', 'age_group' => 'Primary', 'category' => 'Literacy', 'language' => 'English', 'description' => 'Learn to read with fun interactive lessons and games for ages 2-13.', 'icon' => '🥚', 'color' => '#2ECC71', 'features' => ['Interactive lessons', 'Phonics games', 'Progress tracking', 'Printable worksheets']],
    ['name' => 'Turtle Diary', 'url' => 'https://www.turtlediary.com', 'age_group' => 'Primary', 'category' => 'Educational Games', 'language' => 'English', 'description' => 'Educational games, worksheets, and activities for grades K-5.', 'icon' => '🐢', 'color' => '#27AE60', 'features' => ['1000+ games', 'Worksheets', 'Science experiments', 'Arts & crafts']],
    ['name' => 'Highlights Kids', 'url' => 'https://www.highlightskids.com', 'age_group' => 'Primary', 'category' => 'Activities', 'language' => 'English', 'description' => 'Fun activities, jokes, puzzles, and stories for kids.', 'icon' => '🔍', 'color' => '#E74C3C', 'features' => ['Hidden pictures', 'Puzzles', 'Stories', 'Science experiments']],
    
    // ===== SECONDARY (Grades 6-10 / Ages 11-16) =====
    ['name' => 'Open Library', 'url' => 'https://openlibrary.org', 'age_group' => 'Secondary', 'category' => 'General', 'language' => 'English', 'description' => 'Millions of free books - one web page for every book ever published.', 'icon' => '📖', 'color' => '#6A4C93', 'features' => ['3+ million books', 'Borrow online', 'Reading lists', 'Digital lending']],
    ['name' => 'Project Gutenberg', 'url' => 'https://www.gutenberg.org', 'age_group' => 'Secondary', 'category' => 'Classics', 'language' => 'English', 'description' => '70,000+ free eBooks featuring the world\'s greatest literature.', 'icon' => '📕', 'color' => '#9C89B8', 'features' => ['70,000+ eBooks', 'Public domain', 'Multiple formats', 'Downloadable']],
    ['name' => 'LibriVox', 'url' => 'https://librivox.org', 'age_group' => 'Secondary', 'category' => 'Audiobooks', 'language' => 'English', 'description' => 'Free public domain audiobooks read by volunteers from around the world.', 'icon' => '🎧', 'color' => '#B8F2E6', 'features' => ['Audiobooks', 'Volunteer narrated', 'MP3 downloads', 'Classic literature']],
    ['name' => 'Internet Archive', 'url' => 'https://archive.org', 'age_group' => 'Secondary', 'category' => 'Multimedia', 'language' => 'English', 'description' => 'Digital library of books, movies, music, software, and websites.', 'icon' => '🗄️', 'color' => '#AED9E0', 'features' => ['Books, movies & music', 'Web archive', 'Research materials', 'Software library']],
    ['name' => 'Junky Books', 'url' => 'https://www.junkybooks.com', 'age_group' => 'Secondary', 'category' => 'Classic Literature', 'language' => 'English', 'description' => 'Free classic literature eBooks and novels in multiple formats.', 'icon' => '📘', 'color' => '#FFE66D', 'features' => ['Classic novels', 'Free downloads', 'No registration', 'Multiple formats']],
    ['name' => 'Folger Shakespeare', 'url' => 'https://www.folger.edu', 'age_group' => 'Secondary', 'category' => 'Literature', 'language' => 'English', 'description' => 'Shakespeare\'s complete works, teaching resources, and digital collections.', 'icon' => '🎭', 'color' => '#4A235A', 'features' => ['Shakespeare works', 'Teaching resources', 'Digital collections', 'Audio recordings']],
    ['name' => 'Poetry Foundation', 'url' => 'https://www.poetryfoundation.org', 'age_group' => 'Secondary', 'category' => 'Poetry', 'language' => 'English', 'description' => 'World\'s largest poetry collection with poems, poets, and teaching resources.', 'icon' => '📝', 'color' => '#8E44AD', 'features' => ['Poetry collection', 'Poet biographies', 'Audio recordings', 'Lesson plans']],
    ['name' => 'Khan Academy', 'url' => 'https://www.khanacademy.org', 'age_group' => 'Secondary', 'category' => 'STEM', 'language' => 'English', 'description' => 'Free world-class education in math, science, arts, and more.', 'icon' => '📐', 'color' => '#2D9CDB', 'features' => ['Math tutorials', 'Science videos', 'Test prep', 'Progress tracking']],
    
    // ===== HIGHER SECONDARY & COLLEGE =====
    ['name' => 'LibreTexts', 'url' => 'https://www.libretexts.org', 'age_group' => 'Higher', 'category' => 'STEM', 'language' => 'English', 'description' => 'Free textbooks and learning materials for STEM subjects at university level.', 'icon' => '🔬', 'color' => '#1D3557', 'features' => ['Free textbooks', 'STEM focus', 'Interactive tools', 'Open source']],
    ['name' => 'Google Books', 'url' => 'https://books.google.com', 'age_group' => 'Higher', 'category' => 'General', 'language' => 'English', 'description' => 'Search millions of books from libraries and publishers worldwide.', 'icon' => '🔍', 'color' => '#4285F4', 'features' => ['Preview millions', 'Full view classics', 'Research tools', 'Library partnerships']],
    ['name' => 'PDF Drive', 'url' => 'https://www.pdfdrive.com', 'age_group' => 'Higher', 'category' => 'Academic', 'language' => 'English', 'description' => '70+ million PDF eBooks, academic papers, and documents.', 'icon' => '📑', 'color' => '#E94F37', 'features' => ['70M+ PDFs', 'Academic papers', 'Direct download', 'No registration']],
    ['name' => 'HathiTrust', 'url' => 'https://www.hathitrust.org', 'age_group' => 'Higher', 'category' => 'Research', 'language' => 'English', 'description' => 'Digital library of research materials from leading academic institutions.', 'icon' => '🎓', 'color' => '#2B2D42', 'features' => ['Academic research', 'Digitized collections', 'Public domain', 'Full-text search']],
    ['name' => 'DOAJ', 'url' => 'https://doaj.org', 'age_group' => 'Higher', 'category' => 'Journals', 'language' => 'English', 'description' => 'Directory of Open Access Journals - peer-reviewed, free articles.', 'icon' => '📰', 'color' => '#F25F5C', 'features' => ['Open access journals', 'Peer-reviewed', 'Free articles', 'Global research']],
    ['name' => 'PubMed Central', 'url' => 'https://www.ncbi.nlm.nih.gov/pmc', 'age_group' => 'Higher', 'category' => 'Medical', 'language' => 'English', 'description' => 'Biomedical and life sciences journal literature from the NIH.', 'icon' => '🩺', 'color' => '#008080', 'features' => ['Medical research', 'Life sciences', 'Free access', 'NIH database']],
    ['name' => 'Smashwords', 'url' => 'https://www.smashwords.com', 'age_group' => 'Higher', 'category' => 'Independent Publishing', 'language' => 'English', 'description' => 'Indie author eBooks across all genres - many available for free.', 'icon' => '✍️', 'color' => '#FF6B6B', 'features' => ['Indie authors', 'Free previews', 'Multiple formats', 'Direct purchase']],
    ['name' => 'OpenStax', 'url' => 'https://openstax.org', 'age_group' => 'Higher', 'category' => 'Textbooks', 'language' => 'English', 'description' => 'Free, peer-reviewed, openly licensed college textbooks.', 'icon' => '📗', 'color' => '#D35400', 'features' => ['Free textbooks', 'Peer-reviewed', 'Open license', 'Supplements']],
    ['name' => 'Cornell University arXiv', 'url' => 'https://arxiv.org', 'age_group' => 'Higher', 'category' => 'Research', 'language' => 'English', 'description' => 'Open access archive for research papers in physics, math, computer science, and more.', 'icon' => '📄', 'color' => '#B31B1B', 'features' => ['Research papers', 'Preprints', 'Open access', 'Global research']],
    ['name' => 'JSTOR Open Content', 'url' => 'https://about.jstor.org/oa-and-free', 'age_group' => 'Higher', 'category' => 'Academic', 'language' => 'English', 'description' => 'Free access to thousands of academic articles, books, and primary sources.', 'icon' => '🏛️', 'color' => '#003366', 'features' => ['Academic articles', 'Primary sources', 'Open access', 'Research tools']],
    ['name' => 'Open Textbook Library', 'url' => 'https://open.umn.edu/opentextbooks', 'age_group' => 'Higher', 'category' => 'Textbooks', 'language' => 'English', 'description' => 'Open textbooks reviewed by faculty for higher education.', 'icon' => '📙', 'color' => '#7C3AED', 'features' => ['Open textbooks', 'Faculty reviews', 'Multiple subjects', 'Free access']],
    
    // ===== RESEARCH & SPECIALIZED =====
    ['name' => 'Europeana', 'url' => 'https://www.europeana.eu', 'age_group' => 'Research', 'category' => 'Cultural Heritage', 'language' => 'Multilingual', 'description' => 'Digital cultural heritage of Europe - art, music, literature, and history.', 'icon' => '🏛️', 'color' => '#003C8F', 'features' => ['Art & culture', 'Historical documents', 'Museum collections', 'Multilingual']],
    ['name' => 'DPLA', 'url' => 'https://dp.la', 'age_group' => 'Research', 'category' => 'Digital Collections', 'language' => 'English', 'description' => 'Digital Public Library of America - 30M+ items from US institutions.', 'icon' => '🇺🇸', 'color' => '#FD7E14', 'features' => ['US digital collections', '30M+ items', 'Free access', 'Primary sources']],
    ['name' => 'Cambridge Digital Library', 'url' => 'https://cudl.lib.cam.ac.uk', 'age_group' => 'Research', 'category' => 'Historical', 'language' => 'English', 'description' => 'Historic manuscripts, rare books, and cultural artifacts from Cambridge.', 'icon' => '📜', 'color' => '#8B4513', 'features' => ['Rare manuscripts', 'Historical texts', 'Digitized archives', 'Cultural heritage']],
    ['name' => 'British Library', 'url' => 'https://www.bl.uk', 'age_group' => 'Research', 'category' => 'Cultural Heritage', 'language' => 'English', 'description' => 'The British Library\'s digital collections and research resources.', 'icon' => '🏛️', 'color' => '#1A237E', 'features' => ['Digital collections', 'Manuscripts', 'Historical archives', 'Research resources']],
    ['name' => 'Library of Congress', 'url' => 'https://www.loc.gov', 'age_group' => 'Research', 'category' => 'Cultural Heritage', 'language' => 'English', 'description' => 'The world\'s largest library - digital collections and primary sources.', 'icon' => '🏛️', 'color' => '#B22222', 'features' => ['Primary sources', 'Historical documents', 'Digital collections', 'Teaching resources']],
    ['name' => 'UNESCO Digital Library', 'url' => 'https://unesdoc.unesco.org', 'age_group' => 'Research', 'category' => 'International', 'language' => 'Multilingual', 'description' => 'UNESCO\'s digital library with education, culture, and science resources.', 'icon' => '🌐', 'color' => '#005B9C', 'features' => ['Education resources', 'Culture & science', 'UNESCO publications', 'Multilingual']],
    
    // ===== STEAM & CODING =====
    ['name' => 'NASA STEM', 'url' => 'https://www.nasa.gov/stem', 'age_group' => 'STEAM', 'category' => 'Space Science', 'language' => 'English', 'description' => 'Space science resources, educational materials, and student activities.', 'icon' => '🚀', 'color' => '#0B3D91', 'features' => ['Space articles', 'Educational resources', 'Student activities', 'NASA missions']],
    ['name' => 'CK-12 Foundation', 'url' => 'https://www.ck12.org', 'age_group' => 'STEAM', 'category' => 'Math & Science', 'language' => 'English', 'description' => 'Free interactive STEM textbooks with simulations and practice questions.', 'icon' => '⚡', 'color' => '#3CB371', 'features' => ['FlexBooks', 'Interactive simulations', 'Practice questions', 'Adaptive learning']],
    ['name' => 'Code.org', 'url' => 'https://code.org', 'age_group' => 'STEAM', 'category' => 'Coding', 'language' => 'English', 'description' => 'Computer science tutorials, coding games, and Hour of Code activities.', 'icon' => '💻', 'color' => '#00ADB5', 'features' => ['Coding tutorials', 'Hour of Code', 'Games and apps', 'Teacher resources']],
    ['name' => 'MIT OpenCourseWare', 'url' => 'https://ocw.mit.edu', 'age_group' => 'STEAM', 'category' => 'University', 'language' => 'English', 'description' => 'MIT course materials for free - lecture notes, exams, and videos.', 'icon' => '🏫', 'color' => '#A31F34', 'features' => ['University courses', 'Lecture notes', 'Video lectures', 'Open access']],
    ['name' => 'Scratch', 'url' => 'https://scratch.mit.edu', 'age_group' => 'STEAM', 'category' => 'Coding', 'language' => 'English', 'description' => 'Create stories, games, and animations with block-based coding from MIT.', 'icon' => '🐱', 'color' => '#F5821E', 'features' => ['Block-based coding', 'Interactive projects', 'Community sharing', 'Creative learning']],
    ['name' => 'PhET Interactive Simulations', 'url' => 'https://phet.colorado.edu', 'age_group' => 'STEAM', 'category' => 'Science', 'language' => 'English', 'description' => 'Free interactive math and science simulations from the University of Colorado.', 'icon' => '🔬', 'color' => '#3366CC', 'features' => ['Science simulations', 'Math simulations', 'Interactive learning', 'Free access']],
    ['name' => 'Desmos', 'url' => 'https://www.desmos.com', 'age_group' => 'STEAM', 'category' => 'Math', 'language' => 'English', 'description' => 'Free graphing calculator and math activities for students and teachers.', 'icon' => '📊', 'color' => '#155E83', 'features' => ['Graphing calculator', 'Math activities', 'Interactive lessons', 'Free access']],
    ['name' => 'GeoGebra', 'url' => 'https://www.geogebra.org', 'age_group' => 'STEAM', 'category' => 'Math', 'language' => 'Multiple Languages', 'description' => 'Dynamic mathematics software for learning and teaching geometry, algebra, and calculus.', 'icon' => '📐', 'color' => '#3D8C40', 'features' => ['Geometry tools', 'Algebra tools', 'Interactive lessons', 'Multilingual']],
    
    // ===== LANGUAGE LEARNING =====
    ['name' => 'Duolingo', 'url' => 'https://www.duolingo.com', 'age_group' => 'All Ages', 'category' => 'Language Learning', 'language' => 'Multiple Languages', 'description' => 'Learn 40+ languages with fun, bite-sized lessons and gamified learning.', 'icon' => '🦉', 'color' => '#58CC02', 'features' => ['40+ languages', 'Gamified learning', 'Progress tracking', 'Free access']],
    ['name' => 'Mango Languages', 'url' => 'https://mangolanguages.com', 'age_group' => 'All Ages', 'category' => 'Language Learning', 'language' => 'Multiple Languages', 'description' => 'Practical language learning with cultural context and conversation-based lessons.', 'icon' => '🥭', 'color' => '#FF7F2A', 'features' => ['70+ languages', 'Cultural context', 'Conversation focus', 'Library access']],
    ['name' => 'Busuu', 'url' => 'https://www.busuu.com', 'age_group' => 'All Ages', 'category' => 'Language Learning', 'language' => 'Multiple Languages', 'description' => 'Learn 12 languages with interactive lessons and native speaker feedback.', 'icon' => '🌐', 'color' => '#2C3E50', 'features' => ['12 languages', 'Native speaker community', 'Progress tracking', 'Grammar focus']],
    
    // ===== GENERAL REFERENCE =====
    ['name' => 'Wikipedia', 'url' => 'https://www.wikipedia.org', 'age_group' => 'All Ages', 'category' => 'Reference', 'language' => 'Multiple Languages', 'description' => 'The free encyclopedia - 6+ million articles in over 300 languages.', 'icon' => '📚', 'color' => '#000000', 'features' => ['6M+ articles', '300+ languages', 'Free access', 'Well-referenced']],
    ['name' => 'Wikisource', 'url' => 'https://wikisource.org', 'age_group' => 'All Ages', 'category' => 'Reference', 'language' => 'Multiple Languages', 'description' => 'A digital library of source texts, including historical documents and literature.', 'icon' => '📜', 'color' => '#2E4053', 'features' => ['Source texts', 'Historical documents', 'Free access', 'Multilingual']],
    ['name' => 'Wikibooks', 'url' => 'https://www.wikibooks.org', 'age_group' => 'All Ages', 'category' => 'Reference', 'language' => 'Multiple Languages', 'description' => 'Open-content textbooks and manuals for all subjects.', 'icon' => '📗', 'color' => '#7F8C8D', 'features' => ['Open textbooks', 'Manuals', 'Free access', 'Collaborative editing']],
    ['name' => 'World Digital Library', 'url' => 'https://www.wdl.org', 'age_group' => 'All Ages', 'category' => 'Cultural Heritage', 'language' => 'Multiple Languages', 'description' => 'Cultural treasures and historical documents from libraries worldwide.', 'icon' => '🌍', 'color' => '#1A5276', 'features' => ['Cultural heritage', 'Historical documents', 'Global content', 'Multilingual']],
    ['name' => 'Google Scholar', 'url' => 'https://scholar.google.com', 'age_group' => 'All Ages', 'category' => 'Academic', 'language' => 'English', 'description' => 'Search academic literature across journals, books, and research papers.', 'icon' => '🔬', 'color' => '#4285F4', 'features' => ['Academic search', 'Research papers', 'Citations', 'Library links']],
    
    // ===== SPECIAL NEEDS / INCLUSIVE EDUCATION =====
    ['name' => 'Bookshare', 'url' => 'https://www.bookshare.org', 'age_group' => 'All Ages', 'category' => 'Accessible Books', 'language' => 'English', 'description' => 'Accessible books for people with reading barriers - dyslexia, blindness, and more.', 'icon' => '♿', 'color' => '#0066CC', 'features' => ['Accessible formats', 'Dyslexia support', 'Visual impairment', 'Reading tools']],
    ['name' => 'Learning Ally', 'url' => 'https://learningally.org', 'age_group' => 'All Ages', 'category' => 'Audiobooks', 'language' => 'English', 'description' => 'Human-read audiobooks for students with learning differences.', 'icon' => '🎧', 'color' => '#008040', 'features' => ['Human-read audiobooks', 'Learning support', 'Student focus', 'Educator resources']],
    
    // ===== OER & OPEN EDUCATION =====
    ['name' => 'OER Commons', 'url' => 'https://oercommons.org', 'age_group' => 'All Ages', 'category' => 'Open Education', 'language' => 'English', 'description' => 'Open educational resources including lesson plans, textbooks, and multimedia.', 'icon' => '🔄', 'color' => '#2C6FBB', 'features' => ['OER resources', 'Lesson plans', 'Textbooks', 'Multimedia']],
    ['name' => 'OpenLearn', 'url' => 'https://www.open.edu/openlearn', 'age_group' => 'All Ages', 'category' => 'Open Education', 'language' => 'English', 'description' => 'Free courses and learning materials from The Open University.', 'icon' => '🎓', 'color' => '#00665C', 'features' => ['Free courses', 'Learning materials', 'University content', 'Certificates']],
    ['name' => 'Coursera', 'url' => 'https://www.coursera.org', 'age_group' => 'All Ages', 'category' => 'Online Courses', 'language' => 'English', 'description' => 'Thousands of courses from top universities and companies worldwide.', 'icon' => '💻', 'color' => '#2A73CC', 'features' => ['University courses', 'Professional certificates', 'Free audit', 'Global content']],
    ['name' => 'edX', 'url' => 'https://www.edx.org', 'age_group' => 'All Ages', 'category' => 'Online Courses', 'language' => 'English', 'description' => 'High-quality online courses from leading universities.', 'icon' => '🎓', 'color' => '#001A41', 'features' => ['University courses', 'Professional programs', 'Free audit', 'Verified certificates']],
];

// ==================== GET UNIQUE VALUES FOR FILTERS ====================
$ageGroups = array_unique(array_column($digitalLibraries, 'age_group'));
sort($ageGroups);

$categories = array_unique(array_column($digitalLibraries, 'category'));
sort($categories);

// Stats
$totalLibraries = count($digitalLibraries);
$totalBooks = '350k+';
$totalLanguages = '100+';

renderHeader('Digital Library Hub');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Library Hub - <?= htmlspecialchars($institution['name'] ?? 'Library System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f6f9; 
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: var(--gradient-primary);
            border-radius: var(--radius-card);
            padding: 20px 20px 20px 70px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
            cursor: default;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-value { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
            color: white;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            color: rgba(255,255,255,0.9);
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            color: rgba(255,255,255,0.7); 
            margin-top: 4px; 
        }
        
        /* ===== FILTER CARD ===== */
        .filter-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 20px;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }
        .filter-card:hover {
            box-shadow: var(--shadow-hover);
        }
        
        /* ===== LIBRARY GRID ===== */
        .libraries-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .library-card {
            background: white;
            border-radius: var(--radius-card);
            overflow: hidden;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
            position: relative;
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .library-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
        }
        
        .card-color-bar {
            height: 5px;
            background: var(--primary-color);
            flex-shrink: 0;
        }
        
        .card-content {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            gap: 10px;
        }
        
        .library-icon {
            font-size: 42px;
            line-height: 1;
        }
        
        .library-name {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 4px;
        }
        
        .library-url {
            font-size: 11px;
            color: #6c757d;
            word-break: break-all;
        }
        
        .badge-group {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            margin: 2px 2px 2px 0;
        }
        .badge-age { background: #e8f0fe; color: var(--primary-color); }
        .badge-category { background: #fef3c7; color: #d97706; }
        .badge-lang { background: #dcfce7; color: #16a34a; }
        
        .library-description {
            font-size: 13px;
            color: #6c757d;
            margin: 12px 0;
            line-height: 1.5;
            flex-grow: 1;
        }
        
        .features-list {
            list-style: none;
            padding: 0;
            margin: 10px 0 15px 0;
        }
        .features-list li {
            font-size: 12px;
            padding: 3px 0;
            color: #495057;
        }
        .features-list li i {
            color: #4ecdc4;
            width: 20px;
            margin-right: 8px;
        }
        
        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-top: 15px;
            border-top: 1px solid #e9ecef;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .visit-btn {
            background: var(--gradient-primary);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
        }
        .visit-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(30,60,114,0.3);
            color: white;
        }
        
        .qr-code {
            width: 50px;
            height: 50px;
            cursor: pointer;
            transition: transform 0.3s;
            border-radius: 8px;
            border: 2px solid #e9ecef;
        }
        .qr-code:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
        }
        
        /* ===== QR MODAL ===== */
        .qr-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1050;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }
        .qr-modal.show {
            opacity: 1;
            visibility: visible;
        }
        .qr-modal-content {
            background: white;
            padding: 30px;
            border-radius: var(--radius-card);
            text-align: center;
            max-width: 400px;
            width: 90%;
            box-shadow: var(--shadow-hover);
        }
        .qr-modal-content img {
            width: 200px;
            height: 200px;
            margin: 15px 0;
            border-radius: 12px;
        }
        
        /* ===== NO RESULTS ===== */
        .no-results {
            grid-column: 1/-1;
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: var(--radius-card);
            box-shadow: var(--shadow-sm);
        }
        .no-results i {
            color: #6c757d;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card { padding: 15px 15px 15px 60px; }
            .stat-card .stat-icon-wrapper { left: 15px; width: 34px; height: 34px; font-size: 16px; }
            .stat-card .stat-value { font-size: 22px; }
            .libraries-grid { grid-template-columns: 1fr; }
            .card-header { flex-wrap: wrap; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-value { font-size: 18px; }
            .library-icon { font-size: 32px; }
        }
        
        /* ===== PRINT ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon-wrapper { 
                background: #e9ecef !important; 
                color: #333 !important;
            }
            .filter-card { display: none !important; }
            .qr-modal { display: none !important; }
        }
        
        /* ===== SELECT2 OVERRIDES (if used) ===== */
        .select2-container--bootstrap-5 .select2-selection {
            border-radius: 8px;
            border-color: #ced4da;
        }
        .select2-container--bootstrap-5 .select2-selection:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(30,60,114,0.25);
        }
    </style>
</head>
<body>
<div class="container-fluid px-4">
    <!-- ===== PAGE HEADER ===== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-globe me-2"></i> Digital Library Hub</h2>
            <p class="text-muted small">Curated collection of <?= $totalLibraries ?>+ free digital libraries and educational resources</p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            <button class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
        </div>
    </div>

    <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-3 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-book-open"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= $totalLibraries ?></div>
                    <div class="stat-label">Digital Libraries</div>
                    <div class="stat-sub"><i class="fas fa-link"></i> Curated resources</div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-file-alt"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= $totalBooks ?></div>
                    <div class="stat-label">Free Books</div>
                    <div class="stat-sub"><i class="fas fa-graduation-cap"></i> Educational content</div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-language"></i></div>
                <div class="stat-content">
                    <div class="stat-value"><?= $totalLanguages ?></div>
                    <div class="stat-label">Languages</div>
                    <div class="stat-sub"><i class="fas fa-globe"></i> Multilingual access</div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-4 col-6">
            <div class="stat-card">
                <div class="stat-icon-wrapper"><i class="fas fa-users"></i></div>
                <div class="stat-content">
                    <div class="stat-value">All Ages</div>
                    <div class="stat-label">From KG to Research</div>
                    <div class="stat-sub"><i class="fas fa-child"></i> Inclusive learning</div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== FILTER CARD ===== -->
    <div class="filter-card no-print">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
            <h6 class="fw-bold" style="color: var(--primary-color);"><i class="fas fa-filter me-2"></i> Filter Resources</h6>
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-danger" type="button" id="clearFiltersBtn">
                    <i class="fas fa-eraser"></i> Clear Filters
                </button>
            </div>
        </div>
        <div class="row g-2">
            <div class="col-md-3">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" id="searchInput" class="form-control" placeholder="Search by name, description, features...">
                </div>
            </div>
            <div class="col-md-2">
                <select id="ageFilter" class="form-select">
                    <option value="all">All Ages</option>
                    <?php foreach($ageGroups as $age): ?>
                        <option value="<?= htmlspecialchars($age) ?>"><?= htmlspecialchars($age) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select id="categoryFilter" class="form-select">
                    <option value="all">All Categories</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <select id="quickFilter" class="form-select">
                    <option value="all">All Libraries</option>
                    <option value="featured">⭐ Featured</option>
                    <option value="most_visited">🔥 Most Visited</option>
                    <option value="new">🆕 Recently Added</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary w-100" onclick="resetFilters()"><i class="fas fa-undo-alt"></i> Reset</button>
            </div>
        </div>
    </div>

    <!-- ===== LIBRARIES GRID ===== -->
    <div id="librariesGrid" class="libraries-grid">
        <!-- Dynamic content -->
    </div>
</div>

<!-- ===== QR MODAL ===== -->
<div id="qrModal" class="qr-modal">
    <div class="qr-modal-content">
        <h5><i class="fas fa-qrcode me-2"></i>Scan to Visit</h5>
        <img id="qrModalImg" src="" alt="QR Code">
        <p id="qrModalUrl" class="mb-2"></p>
        <div class="d-flex justify-content-center gap-2">
            <button class="btn btn-primary" id="qrVisitBtn" onclick="openLink()"><i class="fas fa-external-link-alt"></i> Open Website</button>
            <button class="btn btn-secondary" onclick="closeQRModal()">Close</button>
        </div>
    </div>
</div>

<!-- ========== JAVASCRIPT ========== -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Library data from PHP
const libraries = <?= json_encode($digitalLibraries) ?>;

// Current URL for QR
let currentUrl = '';

// DOM Elements
const gridContainer = document.getElementById('librariesGrid');
const searchInput = document.getElementById('searchInput');
const ageFilter = document.getElementById('ageFilter');
const categoryFilter = document.getElementById('categoryFilter');
const quickFilter = document.getElementById('quickFilter');

// Render libraries
function renderLibraries() {
    const searchTerm = searchInput.value.toLowerCase().trim();
    const ageValue = ageFilter.value;
    const categoryValue = categoryFilter.value;
    const quickValue = quickFilter.value;
    
    let filtered = libraries.filter(lib => {
        // Search filter
        const matchesSearch = searchTerm === '' || 
            lib.name.toLowerCase().includes(searchTerm) ||
            lib.description.toLowerCase().includes(searchTerm) ||
            lib.features.some(f => f.toLowerCase().includes(searchTerm)) ||
            lib.category.toLowerCase().includes(searchTerm);
        
        // Age filter
        const matchesAge = ageValue === 'all' || lib.age_group === ageValue;
        
        // Category filter
        const matchesCategory = categoryValue === 'all' || lib.category === categoryValue;
        
        // Quick filter
        let matchesQuick = true;
        if (quickValue === 'featured') {
            const featured = ['Oxford Owl','Khan Academy Kids','National Geographic Kids','StoryWeaver','Open Library','Project Gutenberg','Khan Academy','NASA STEM','Duolingo'];
            matchesQuick = featured.some(f => lib.name.includes(f));
        } else if (quickValue === 'most_visited') {
            const popular = ['Google Books','Project Gutenberg','Internet Archive','Open Library','LibriVox','Wikipedia','Khan Academy','Duolingo'];
            matchesQuick = popular.some(f => lib.name.includes(f));
        } else if (quickValue === 'new') {
            const newSites = ['Bookshare','Learning Ally','OER Commons','OpenLearn','Coursera','edX','OpenStax','JSTOR Open Content'];
            matchesQuick = newSites.some(f => lib.name.includes(f));
        }
        
        return matchesSearch && matchesAge && matchesCategory && matchesQuick;
    });
    
    if (filtered.length === 0) {
        gridContainer.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search fa-3x mb-3 d-block"></i>
                <h5>No libraries found</h5>
                <p class="text-muted">Try adjusting your search or filter criteria</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    filtered.forEach(lib => {
        // Use the color from data or generate a hash-based color
        const color = lib.color || `hsl(${lib.name.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % 360}, 70%, 55%)`;
        
        html += `
            <div class="library-card" data-url="${lib.url}">
                <div class="card-color-bar" style="background: ${color};"></div>
                <div class="card-content">
                    <div class="card-header">
                        <div>
                            <div class="library-icon">${lib.icon}</div>
                            <div class="library-name">${escapeHtml(lib.name)}</div>
                            <div class="library-url">${escapeHtml(lib.url.replace('https://', '').replace('http://', ''))}</div>
                        </div>
                        <img class="qr-code" src="https://quickchart.io/qr?text=${encodeURIComponent(lib.url)}&size=100&margin=0" 
                             alt="QR Code" onclick="event.stopPropagation(); showQRModal('${lib.url}', '${escapeHtml(lib.name.replace(/'/g, "\\'"))}')">
                    </div>
                    
                    <div class="mt-2">
                        <span class="badge-group badge-age"><i class="fas fa-graduation-cap"></i> ${escapeHtml(lib.age_group)}</span>
                        <span class="badge-group badge-category"><i class="fas fa-tag"></i> ${escapeHtml(lib.category)}</span>
                        <span class="badge-group badge-lang"><i class="fas fa-language"></i> ${escapeHtml(lib.language)}</span>
                    </div>
                    
                    <div class="library-description">${escapeHtml(lib.description)}</div>
                    
                    <ul class="features-list">
                        ${lib.features.map(f => `<li><i class="fas fa-check-circle"></i> ${escapeHtml(f)}</li>`).join('')}
                    </ul>
                    
                    <div class="card-footer">
                        <a href="${lib.url}" target="_blank" class="visit-btn" onclick="event.stopPropagation();">
                            <i class="fas fa-external-link-alt"></i> Visit
                        </a>
                        <button class="btn btn-sm btn-outline-secondary" onclick="event.stopPropagation(); copyToClipboard('${lib.url}')">
                            <i class="fas fa-copy"></i> Copy URL
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    gridContainer.innerHTML = html;
}

// Show QR Modal
function showQRModal(url, name) {
    currentUrl = url;
    const modal = document.getElementById('qrModal');
    const qrImg = document.getElementById('qrModalImg');
    const urlSpan = document.getElementById('qrModalUrl');
    
    qrImg.src = `https://quickchart.io/qr?text=${encodeURIComponent(url)}&size=300&margin=0`;
    urlSpan.innerHTML = `<strong>${escapeHtml(name)}</strong><br><small>${escapeHtml(url)}</small>`;
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
}

// Close QR Modal
function closeQRModal() {
    const modal = document.getElementById('qrModal');
    modal.classList.remove('show');
    document.body.style.overflow = '';
}

// Open link from modal
function openLink() {
    if (currentUrl) {
        window.open(currentUrl, '_blank');
    }
}

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('URL copied to clipboard!', 'success');
    }).catch(() => {
        // Fallback
        const input = document.createElement('input');
        input.value = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
        showToast('URL copied to clipboard!', 'success');
    });
}

// Show toast notification
function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '300px';
    toast.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// Escape HTML
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

// Debounce for search
let debounceTimer;
function debounce(func, delay) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(func, delay);
}

// Reset filters
function resetFilters() {
    searchInput.value = '';
    ageFilter.value = 'all';
    categoryFilter.value = 'all';
    quickFilter.value = 'all';
    renderLibraries();
}

// Event listeners
searchInput.addEventListener('input', () => debounce(renderLibraries, 300));
ageFilter.addEventListener('change', renderLibraries);
categoryFilter.addEventListener('change', renderLibraries);
quickFilter.addEventListener('change', renderLibraries);

// Click on card to visit
document.addEventListener('click', function(e) {
    const card = e.target.closest('.library-card');
    if (card && !e.target.closest('.visit-btn') && !e.target.closest('.qr-code') && !e.target.closest('button')) {
        const url = card.getAttribute('data-url');
        if (url) window.open(url, '_blank');
    }
});

// Close modal with escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeQRModal();
    }
});

// Clear filters button
document.getElementById('clearFiltersBtn')?.addEventListener('click', resetFilters);

// Initial render
renderLibraries();

// Animate stat numbers
document.addEventListener('DOMContentLoaded', function() {
    const numbers = document.querySelectorAll('.stat-value');
    numbers.forEach(el => {
        const text = el.innerText;
        const num = parseInt(text.replace(/[^0-9]/g, ''));
        if (num && !isNaN(num) && num < 1000) {
            let current = 0;
            const target = num;
            const increment = Math.max(1, Math.floor(target / 40));
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    el.innerText = text.replace(/\d+/, target);
                    clearInterval(timer);
                } else {
                    el.innerText = text.replace(/\d+/, current);
                }
            }, 30);
        }
    });
});
</script>

<?php renderFooter(); ?>
</body>
</html>
