<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$type = isset($_GET['type']) ? trim($_GET['type']) : 'all';

if (empty($keyword) && $type === 'all') {
    echo json_encode([]);
    exit;
}

$sql = "SELECT id, name, description, url, category, type, icon, is_featured 
        FROM research_databases 
        WHERE is_active = 1";
$params = [];

if (!empty($keyword)) {
    $sql .= " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)";
    $like = "%$keyword%";
    $params = [$like, $like, $like];
}

if ($type !== 'all') {
    $sql .= " AND type = ?";
    $params[] = $type;
}

$sql .= " ORDER BY is_featured DESC, sort_order ASC, name ASC LIMIT 50";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$databases = $stmt->fetchAll();

echo json_encode($databases);
?>