<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json');

$db = getDB();
$keyword = trim($_GET['keyword'] ?? '');
$category = trim($_GET['category'] ?? '');

logSearch($db, $keyword, null, 'books');

$sql = "SELECT id, barcode, title, author, publisher, category, available, quantity, isbn, cover_path, year, pages, language, location, summary, book_status 
        FROM books WHERE status != 'Deleted'";
$params = [];

if(!empty($keyword)) {
    $sql .= " AND (title LIKE ? OR author LIKE ? OR isbn LIKE ? OR barcode LIKE ? OR category LIKE ?)";
    $like = "%$keyword%";
    $params = [$like, $like, $like, $like, $like];
}

if(!empty($category) && $category !== 'all') {
    $sql .= " AND category = ?";
    $params[] = $category;
}

$sql .= " ORDER BY title LIMIT 100";

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();
    
    foreach($books as &$book) {
        $book['cover_base64'] = getCoverBase64($book['cover_path'] ?? '');
        $book['available'] = (int)$book['available'];
    }
    
    echo json_encode($books);
    
} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}

function logSearch($db, $keyword, $bookBarcode = null, $searchType = 'books') {
    if(empty($keyword) && empty($bookBarcode)) return;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $sessionId = session_id();
        $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='search_logs'")->fetch();
        if($tableCheck) {
            $stmt = $db->prepare("INSERT INTO search_logs (keyword, book_barcode, search_type, user_ip, user_agent, session_id, created_at) 
                                  VALUES (?, ?, ?, ?, ?, ?, datetime('now'))");
            $stmt->execute([$keyword, $bookBarcode, $searchType, $ip, $userAgent, $sessionId]);
        }
    } catch(Exception $e) {
        error_log("Failed to log search: " . $e->getMessage());
    }
}
?>