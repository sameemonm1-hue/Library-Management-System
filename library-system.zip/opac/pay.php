<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'pay_fines' => 'Pay Fines',
        'pay_now' => 'Pay Now',
        'fine_total' => 'Total Fines',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'pay_fines' => 'जुर्माना भुगतान करें',
        'pay_now' => 'अभी भुगतान करें',
        'fine_total' => 'कुल जुर्माना',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'pay_fines' => 'دفع الغرامات',
        'pay_now' => 'ادفع الآن',
        'fine_total' => 'إجمالي الغرامات',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

$db = getDB();
if (!isset($_SESSION['member_id'])) { header('Location: login.php'); exit; }
$memberId = $_SESSION['member_id'];
$member = $db->prepare("SELECT total_fines, email, name, admno FROM members WHERE id = ?")->execute([$memberId])->fetch();

if ($member['total_fines'] <= 0) {
    header('Location: account.php');
    exit;
}

$settings = getSettings();
$apiKey = $settings['razorpay_key_id'] ?? 'rzp_test_YourKey';
$apiSecret = $settings['razorpay_key_secret'] ?? 'YourSecret';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['razorpay_payment_id'])) {
    $paymentId = $_POST['razorpay_payment_id'];
    $amount = (float)$_POST['amount'];
    $newFines = max(0, $member['total_fines'] - $amount);
    $db->prepare("UPDATE members SET total_fines = ? WHERE id = ?")->execute([$newFines, $memberId]);
    $db->prepare("INSERT INTO payment_transactions (member_admno, amount, payment_type, reference_id, payment_method, status, created_by) VALUES (?, ?, 'fine', ?, 'online', 'success', 'member')")
       ->execute([$member['admno'], $amount, $paymentId]);
    header('Location: account.php?paid=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <title><?= __('pay_fines') ?></title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow">
        <div class="card-body text-center">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2><i class="fas fa-credit-card"></i> <?= __('pay_fines') ?></h2>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                    </ul>
                </div>
            </div>
            <p class="display-4 text-danger">₹<?= number_format($member['total_fines'], 2) ?></p>
            <button id="payBtn" class="btn btn-primary btn-lg w-100"><?= __('pay_now') ?></button>
        </div>
    </div>
</div>
<script>
var options = {
    key: "<?= $apiKey ?>",
    amount: <?= $member['total_fines'] * 100 ?>,
    currency: "INR",
    name: "Library Fine Payment",
    description: "Outstanding library fines",
    handler: function(response){
        var form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = '<input type="hidden" name="razorpay_payment_id" value="'+response.razorpay_payment_id+'"><input type="hidden" name="amount" value="<?= $member['total_fines'] ?>">';
        document.body.appendChild(form);
        form.submit();
    },
    prefill: { email: "<?= addslashes($member['email']) ?>", name: "<?= addslashes($member['name']) ?>" }
};
document.getElementById('payBtn').onclick = function(e){
    var rzp = new Razorpay(options);
    rzp.open();
    e.preventDefault();
}
</script>
</body>
</html>