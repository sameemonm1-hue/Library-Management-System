<?php
session_start();
require_once '../config/db.php';

header('Content-Type: application/json');

$ids = isset($_GET['ids']) ? explode(',', $_GET['ids']) : [];
$result = [];
if (!empty($ids)) {
    $db = getDB();
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $db->prepare("SELECT id, available FROM books WHERE id IN ($placeholders)");
    $stmt->execute($ids);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $result[$row['id']] = ['available' => $row['available'] > 0];
    }
}
echo json_encode($result);
?>