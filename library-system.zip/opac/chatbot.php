<?php
/**
 * OPAC AI Chatbot
 * Uses FAQ database (RAG) + Hugging Face Inference API (or Ollama) fallback.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// Get chatbot settings from settings table
$hfApiKey = $settings['hf_api_key'] ?? ''; // Store your Hugging Face API key in settings
$useOllama = $settings['use_ollama'] ?? 0;  // Set to 1 to use local Ollama
$ollamaUrl = $settings['ollama_url'] ?? 'http://localhost:11434';
$ollamaModel = $settings['ollama_model'] ?? 'llama2';

// Handle AJAX chat request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    header('Content-Type: application/json');
    
    $userMessage = trim($_POST['message']);
    if (empty($userMessage)) {
        echo json_encode(['error' => 'Empty message']);
        exit;
    }
    
    // Step 1: Search FAQ database (RAG)
    $faqAnswer = searchFaq($db, $userMessage);
    if ($faqAnswer) {
        echo json_encode(['answer' => $faqAnswer, 'source' => 'faq']);
        exit;
    }
    
    // Step 2: Fallback to AI (Hugging Face or Ollama)
    $aiAnswer = callAiModel($userMessage, $hfApiKey, $useOllama, $ollamaUrl, $ollamaModel);
    echo json_encode(['answer' => $aiAnswer, 'source' => 'ai']);
    exit;
}

/**
 * Search FAQ database for relevant answer using keyword matching.
 */
function searchFaq($db, $query) {
    // Simple keyword search (you can also use SQLite FTS)
    $keywords = explode(' ', $query);
    $conditions = [];
    $params = [];
    foreach ($keywords as $kw) {
        if (strlen($kw) < 3) continue;
        $conditions[] = "(question LIKE ? OR answer LIKE ? OR keywords LIKE ?)";
        $like = "%$kw%";
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }
    if (empty($conditions)) return null;
    
    $sql = "SELECT answer, question FROM faq WHERE is_active = 1 AND (" . implode(' OR ', $conditions) . ") LIMIT 1";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch();
    if ($result) {
        return $result['answer'];
    }
    return null;
}

/**
 * Call Hugging Face Inference API or local Ollama.
 */
function callAiModel($message, $hfApiKey, $useOllama, $ollamaUrl, $ollamaModel) {
    // System prompt to keep the chatbot focused on library topics
    $systemPrompt = "You are a helpful library assistant. Answer questions about library hours, policies, book renewal, holds, fines, membership, eBooks, and general library services. Keep answers concise (2-3 sentences). If asked about non-library topics, politely say you can only answer library-related questions.";
    
    if ($useOllama && extension_loaded('curl')) {
        // Use local Ollama API
        $data = [
            'model' => $ollamaModel,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $message]
            ],
            'stream' => false
        ];
        $ch = curl_init($ollamaUrl . '/api/chat');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode == 200 && $response) {
            $result = json_decode($response, true);
            if (isset($result['message']['content'])) {
                return trim($result['message']['content']);
            }
        }
        // Fallback to Hugging Face if Ollama fails
    }
    
    // Hugging Face Inference API (free tier)
    if (!empty($hfApiKey)) {
        $apiUrl = 'https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium';
        // Alternatively, use a more modern model like 'HuggingFaceH4/zephyr-7b-beta'
        // But DialoGPT is smaller and faster for free tier.
        
        $payload = [
            'inputs' => $systemPrompt . "\nUser: " . $message . "\nAssistant:",
            'parameters' => ['max_length' => 150, 'temperature' => 0.7]
        ];
        
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $hfApiKey,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode == 200 && $response) {
            $result = json_decode($response, true);
            if (isset($result[0]['generated_text'])) {
                // Extract only the assistant part (after "Assistant:")
                $full = $result[0]['generated_text'];
                $parts = explode("Assistant:", $full);
                $answer = trim(end($parts));
                if (strlen($answer) > 5) return $answer;
            }
        }
    }
    
    // Ultimate fallback if all AI methods fail
    return "I'm sorry, I couldn't process your request right now. Please contact the library staff for assistance, or try asking a different question.";
}

// ========== HTML/JS frontend ==========
$opacPrimaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
$opacFontFamily = $settings['opac_font_family'] ?? 'Inter';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Library AI Chatbot - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($opacFontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { font-family: '<?= $opacFontFamily ?>', sans-serif; }
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .chat-container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            border-radius: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: calc(100vh - 40px);
            max-height: 800px;
        }
        .chat-header {
            background: <?= $opacPrimaryColor ?>;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .chat-header h1 { font-size: 1.5rem; margin: 0; }
        .chat-header p { margin: 0; opacity: 0.9; font-size: 0.85rem; }
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .message {
            margin-bottom: 20px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }
        .message.user { flex-direction: row-reverse; }
        .message .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .message.user .avatar { background: <?= $opacPrimaryColor ?>; color: white; }
        .message.bot .avatar { background: #28a745; color: white; }
        .message .bubble {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 18px;
            background: white;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        .message.user .bubble {
            background: <?= $opacPrimaryColor ?>;
            color: white;
        }
        .message.bot .bubble {
            background: #e9ecef;
            color: #333;
        }
        .typing-indicator {
            display: none;
            align-items: center;
            gap: 5px;
            padding: 10px 15px;
            background: #e9ecef;
            border-radius: 20px;
            width: fit-content;
            margin-bottom: 20px;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #6c757d;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
            30% { transform: translateY(-10px); opacity: 1; }
        }
        .chat-input {
            padding: 15px;
            background: white;
            border-top: 1px solid #dee2e6;
        }
        .chat-input form {
            display: flex;
            gap: 10px;
        }
        .chat-input input {
            flex: 1;
            padding: 12px;
            border: 2px solid #e9ecef;
            border-radius: 30px;
            outline: none;
            transition: all 0.3s;
        }
        .chat-input input:focus {
            border-color: <?= $opacPrimaryColor ?>;
        }
        .chat-input button {
            background: <?= $opacPrimaryColor ?>;
            border: none;
            border-radius: 30px;
            padding: 0 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        .chat-input button:hover {
            transform: scale(1.02);
            filter: brightness(1.05);
        }
        .footer {
            text-align: center;
            padding: 10px;
            font-size: 0.7rem;
            background: white;
            border-top: 1px solid #e9ecef;
        }
        @media (max-width: 576px) {
            .message .bubble { max-width: 85%; }
            .chat-container { height: 100vh; max-height: none; margin: 0; border-radius: 0; }
            body { background: white; }
        }
    </style>
</head>
<body>
<div class="chat-container">
    <div class="chat-header">
        <h1><i class="fas fa-robot"></i> Library AI Assistant</h1>
        <p>Ask me about library hours, policies, renewals, holds, fines & more</p>
    </div>
    <div class="chat-messages" id="chatMessages">
        <div class="message bot">
            <div class="avatar"><i class="fas fa-robot"></i></div>
            <div class="bubble">
                Hello! I'm your library assistant. How can I help you today?<br>
                <small class="text-muted">You can ask: "Library hours", "How to renew a book?", "What is the fine for overdue books?" etc.</small>
            </div>
        </div>
    </div>
    <div class="typing-indicator" id="typingIndicator">
        <span></span><span></span><span></span>
        <span class="ms-2">Assistant is typing...</span>
    </div>
    <div class="chat-input">
        <form id="chatForm">
            <input type="text" id="messageInput" placeholder="Type your question here..." required autocomplete="off">
            <button type="submit"><i class="fas fa-paper-plane"></i> Send</button>
        </form>
    </div>
    <div class="footer">
        <small>Powered by AI &nbsp;|&nbsp; <a href="index.php" class="text-decoration-none">← Back to OPAC</a></small>
    </div>
</div>

<script>
const chatMessages = document.getElementById('chatMessages');
const typingIndicator = document.getElementById('typingIndicator');
const chatForm = document.getElementById('chatForm');
const messageInput = document.getElementById('messageInput');

function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addMessage(role, text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    const avatarIcon = role === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';
    messageDiv.innerHTML = `
        <div class="avatar">${avatarIcon}</div>
        <div class="bubble">${escapeHtml(text)}</div>
    `;
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    }).replace(/\n/g, '<br>');
}

chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const question = messageInput.value.trim();
    if (!question) return;
    
    // Add user message
    addMessage('user', question);
    messageInput.value = '';
    
    // Show typing indicator
    typingIndicator.style.display = 'flex';
    scrollToBottom();
    
    try {
        const response = await fetch('chatbot.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'message=' + encodeURIComponent(question)
        });
        const data = await response.json();
        typingIndicator.style.display = 'none';
        
        if (data.answer) {
            let answer = data.answer;
            // Add small source indicator
            if (data.source === 'faq') answer += '<br><small class="text-muted">📚 From our FAQ</small>';
            else if (data.source === 'ai') answer += '<br><small class="text-muted">🤖 AI generated</small>';
            addMessage('bot', answer);
        } else if (data.error) {
            addMessage('bot', 'Sorry, I encountered an error. Please try again later.');
        } else {
            addMessage('bot', 'I could not understand. Please rephrase your question.');
        }
    } catch (err) {
        typingIndicator.style.display = 'none';
        addMessage('bot', 'Network error. Please check your connection and try again.');
    }
});

// Optional: focus on input on load
messageInput.focus();
</script>
</body>
</html>