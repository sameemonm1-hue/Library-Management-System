<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    // Remove ?lang from URL for cleaner navigation
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'advanced_search' => 'Advanced Book Search',
        'find_books_by' => 'Find books by title, author, publisher, year, language, and more',
        'back_to_opac' => 'Back to OPAC',
        'keyword' => 'Keyword (title, author, subject)',
        'author' => 'Author',
        'publisher' => 'Publisher',
        'isbn' => 'ISBN',
        'year_from' => 'Year From',
        'year_to' => 'Year To',
        'language' => 'Language',
        'all_languages' => 'All Languages',
        'curriculum' => 'Curriculum',
        'search' => 'Search',
        'clear_filters' => 'Clear Filters',
        'results_found' => 'results found',
        'no_books_found' => 'No books found matching your criteria.',
        'try_adjusting' => 'Try adjusting your filters or use different keywords.',
        'unknown_author' => 'Unknown Author',
        'publisher_label' => 'Publisher',
        'isbn_label' => 'ISBN',
        'available' => 'Available',
        'not_available' => 'Not Available',
        'copies_available' => 'copies available',
        'view_details' => 'View Details',
        'previous' => 'Previous',
        'next' => 'Next',
        'enter_search_criteria' => 'Enter search criteria above to find books',
        'you_can_search' => 'You can search by keyword, author, publisher, ISBN, year range, language, and curriculum.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'advanced_search' => 'उन्नत पुस्तक खोज',
        'find_books_by' => 'शीर्षक, लेखक, प्रकाशक, वर्ष, भाषा और अधिक से पुस्तकें खोजें',
        'back_to_opac' => 'OPAC पर वापस जाएं',
        'keyword' => 'कीवर्ड (शीर्षक, लेखक, विषय)',
        'author' => 'लेखक',
        'publisher' => 'प्रकाशक',
        'isbn' => 'ISBN',
        'year_from' => 'वर्ष से',
        'year_to' => 'वर्ष तक',
        'language' => 'भाषा',
        'all_languages' => 'सभी भाषाएँ',
        'curriculum' => 'पाठ्यक्रम',
        'search' => 'खोजें',
        'clear_filters' => 'फ़िल्टर साफ़ करें',
        'results_found' => 'परिणाम मिले',
        'no_books_found' => 'आपके मानदंड से मेल खाने वाली कोई पुस्तक नहीं मिली।',
        'try_adjusting' => 'कृपया अपने फ़िल्टर समायोजित करें या अलग कीवर्ड का उपयोग करें।',
        'unknown_author' => 'अज्ञात लेखक',
        'publisher_label' => 'प्रकाशक',
        'isbn_label' => 'ISBN',
        'available' => 'उपलब्ध',
        'not_available' => 'उपलब्ध नहीं',
        'copies_available' => 'प्रतियाँ उपलब्ध',
        'view_details' => 'विवरण देखें',
        'previous' => 'पिछला',
        'next' => 'अगला',
        'enter_search_criteria' => 'पुस्तकें खोजने के लिए ऊपर मानदंड दर्ज करें',
        'you_can_search' => 'आप कीवर्ड, लेखक, प्रकाशक, ISBN, वर्ष सीमा, भाषा और पाठ्यक्रम द्वारा खोज सकते हैं।',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'advanced_search' => 'بحث متقدم عن الكتب',
        'find_books_by' => 'ابحث عن الكتب بالعنوان، المؤلف، الناشر، السنة، اللغة والمزيد',
        'back_to_opac' => 'العودة إلى الفهرس العام',
        'keyword' => 'كلمة مفتاحية (العنوان، المؤلف، الموضوع)',
        'author' => 'المؤلف',
        'publisher' => 'الناشر',
        'isbn' => 'الترقيم الدولي',
        'year_from' => 'من سنة',
        'year_to' => 'إلى سنة',
        'language' => 'اللغة',
        'all_languages' => 'جميع اللغات',
        'curriculum' => 'المنهج',
        'search' => 'بحث',
        'clear_filters' => 'مسح الفلاتر',
        'results_found' => 'نتائج وجدت',
        'no_books_found' => 'لم يتم العثور على كتب تطابق معاييرك.',
        'try_adjusting' => 'يرجى تعديل الفلاتر أو استخدام كلمات مفتاحية مختلفة.',
        'unknown_author' => 'مؤلف غير معروف',
        'publisher_label' => 'الناشر',
        'isbn_label' => 'الترقيم الدولي',
        'available' => 'متاح',
        'not_available' => 'غير متوفر',
        'copies_available' => 'نسخ متاحة',
        'view_details' => 'عرض التفاصيل',
        'previous' => 'السابق',
        'next' => 'التالي',
        'enter_search_criteria' => 'أدخل معايير البحث أعلاه للعثور على الكتب',
        'you_can_search' => 'يمكنك البحث بالكلمة المفتاحية، المؤلف، الناشر، ISBN، نطاق السنة، اللغة، والمنهج.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}

function isRTL() { global $lang; return $lang === 'ar'; }

$settings = getSettings();
$institution = getInstitution();
$db = getDB();

// OPAC styling
$opacPrimaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
$opacHeaderBgColor = $settings['opac_header_bg_color'] ?? '#1e3c72';
$opacFontFamily = $settings['opac_font_family'] ?? 'Inter';
$opacBaseFontSize = (int)($settings['opac_base_font_size'] ?? 16);
$opacHeadingFontSize = (int)($settings['opac_heading_font_size'] ?? 32);
$containerMaxWidth = (int)($settings['container_max_width'] ?? 1600);
$containerPadding = (int)($settings['container_padding'] ?? 10);

// Get search parameters
$keyword = trim($_GET['keyword'] ?? '');
$author = trim($_GET['author'] ?? '');
$publisher = trim($_GET['publisher'] ?? '');
$year_from = trim($_GET['year_from'] ?? '');
$year_to = trim($_GET['year_to'] ?? '');
$language = trim($_GET['language'] ?? '');
$curriculum = trim($_GET['curriculum'] ?? '');
$isbn = trim($_GET['isbn'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = [];
$params = [];

if (!empty($keyword)) {
    $where[] = "books_fts MATCH ?";
    $params[] = $keyword;
} else {
    if (!empty($author)) {
        $where[] = "author LIKE ?";
        $params[] = "%$author%";
    }
    if (!empty($publisher)) {
        $where[] = "publisher LIKE ?";
        $params[] = "%$publisher%";
    }
    if (!empty($isbn)) {
        $where[] = "isbn LIKE ?";
        $params[] = "%$isbn%";
    }
}

if (!empty($year_from)) {
    $where[] = "year >= ?";
    $params[] = $year_from;
}
if (!empty($year_to)) {
    $where[] = "year <= ?";
    $params[] = $year_to;
}
if (!empty($language)) {
    $where[] = "language = ?";
    $params[] = $language;
}
if (!empty($curriculum)) {
    $where[] = "curriculum LIKE ?";
    $params[] = "%$curriculum%";
}

$whereClause = empty($where) ? "" : "WHERE " . implode(" AND ", $where);

if (!empty($keyword)) {
    $countSql = "SELECT COUNT(*) FROM books b JOIN books_fts ON b.id = books_fts.rowid $whereClause";
} else {
    $countSql = "SELECT COUNT(*) FROM books b $whereClause";
}
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$total = $countStmt->fetchColumn();
$totalPages = ceil($total / $perPage);

if (!empty($keyword)) {
    $sql = "SELECT b.* FROM books b JOIN books_fts ON b.id = books_fts.rowid $whereClause ORDER BY rank LIMIT ? OFFSET ?";
} else {
    $sql = "SELECT * FROM books b $whereClause ORDER BY title LIMIT ? OFFSET ?";
}
$params[] = $perPage;
$params[] = $offset;
$stmt = $db->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$languages = $db->query("SELECT DISTINCT language FROM books WHERE language IS NOT NULL AND language != '' ORDER BY language")->fetchAll(PDO::FETCH_COLUMN);
$curricula = $db->query("SELECT DISTINCT curriculum FROM books WHERE curriculum IS NOT NULL AND curriculum != '' ORDER BY curriculum")->fetchAll(PDO::FETCH_COLUMN);

function getOpacLogoData() {
    global $settings, $institution;
    if (!empty($settings['opac_header_logo']) && file_exists($settings['opac_header_logo'])) {
        $ext = pathinfo($settings['opac_header_logo'], PATHINFO_EXTENSION);
        $data = @file_get_contents($settings['opac_header_logo']);
        if ($data) return 'data:image/' . $ext . ';base64,' . base64_encode($data);
    }
    if (!empty($institution['logo_path']) && file_exists($institution['logo_path'])) {
        $ext = pathinfo($institution['logo_path'], PATHINFO_EXTENSION);
        $data = @file_get_contents($institution['logo_path']);
        if ($data) return 'data:image/' . $ext . ';base64,' . base64_encode($data);
    }
    return '';
}
$logoData = getOpacLogoData();

// Header logo fallback (same as OPAC)
function getHeaderLogoUrl() {
    global $settings, $institution;
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    $logoKeys = ['opac_header_logo', 'library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
        }
    }
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%23'.$opacPrimaryColor.'\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}
$logoUrl = getHeaderLogoUrl();

?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('advanced_search') ?> - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($opacFontFamily) ?>:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $opacPrimaryColor ?>;
            --header-bg: <?= $opacHeaderBgColor ?>;
            --container-max-width: <?= $containerMaxWidth ?>px;
            --container-padding: <?= $containerPadding ?>px;
        }
        * { font-family: '<?= $opacFontFamily ?>', 'Inter', sans-serif; }
        body { background: #f0f2f5; font-size: <?= $opacBaseFontSize ?>px; }
        .header-bg { background: linear-gradient(135deg, var(--header-bg), #2a5298); color: white; padding: 20px 0; margin-bottom: 30px; }
        .header-container { display: flex; align-items: center; justify-content: space-between; max-width: var(--container-max-width); margin: 0 auto; padding: 0 var(--container-padding); }
        .header-left img { height: 60px; width: auto; background: white; border-radius: 8px; padding: 5px; }
        .header-title h1 { font-size: <?= $opacHeadingFontSize ?>px; font-weight: 800; margin: 0; }
        .header-title p { font-size: 0.9rem; opacity: 0.9; }
        .search-container { background: white; border-radius: 20px; padding: 30px; margin-bottom: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .result-card { background: white; border-radius: 15px; padding: 20px; margin-bottom: 20px; transition: transform 0.2s; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .result-card:hover { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .book-cover { width: 80px; height: 110px; object-fit: cover; border-radius: 6px; background: #f8f9fa; }
        .pagination .page-link { color: var(--primary-color); }
        .pagination .active .page-link { background: var(--primary-color); border-color: var(--primary-color); color: white; }
        .footer { background: #1a1a2e; color: #eee; padding: 30px 0; margin-top: 50px; text-align: center; }
        .lang-switch { background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.4); border-radius: 40px; padding: 10px 18px; color: white; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.3s; display: inline-flex; align-items: center; gap: 8px; backdrop-filter: blur(5px); }
        .lang-switch:hover { background: rgba(255,255,255,0.3); transform: scale(1.05); color: white; }
        [dir="rtl"] .me-2 { margin-right: 0 !important; margin-left: 0.5rem !important; }
        @media (max-width: 768px) {
            .header-container { flex-direction: column; gap: 10px; text-align: center; }
            .book-cover { width: 60px; height: 85px; }
        }
    </style>
</head>
<body>

<div class="header-bg">
    <div class="header-container">
        <div class="header-left">
            <?php if ($logoData): ?>
                <img src="<?= $logoData ?>" alt="Logo">
            <?php endif; ?>
        </div>
        <div class="header-title text-center">
            <h1><?= __('advanced_search') ?></h1>
            <p><?= __('find_books_by') ?></p>
        </div>
        <div>
            <!-- 3-language switcher -->
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                </ul>
            </div>
            <a href="index.php" class="lang-switch ms-2" style="background:#ffc107; color:#333;">
                <i class="fas fa-arrow-left"></i> <?= __('back_to_opac') ?>
            </a>
        </div>
    </div>
</div>

<div class="container" style="max-width: var(--container-max-width); padding: 0 var(--container-padding);">
    <div class="search-container">
        <form method="get" action="" class="row g-3">
            <div class="col-md-6">
                <label class="form-label fw-bold"><?= __('keyword') ?></label>
                <input type="text" name="keyword" class="form-control" value="<?= htmlspecialchars($keyword) ?>" placeholder="e.g., programming, harry potter">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold"><?= __('author') ?></label>
                <input type="text" name="author" class="form-control" value="<?= htmlspecialchars($author) ?>" placeholder="e.g., J.K. Rowling">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold"><?= __('publisher') ?></label>
                <input type="text" name="publisher" class="form-control" value="<?= htmlspecialchars($publisher) ?>" placeholder="e.g., Penguin, O'Reilly">
            </div>
            <div class="col-md-6">
                <label class="form-label fw-bold"><?= __('isbn') ?></label>
                <input type="text" name="isbn" class="form-control" value="<?= htmlspecialchars($isbn) ?>" placeholder="978-3-16-148410-0">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold"><?= __('year_from') ?></label>
                <input type="number" name="year_from" class="form-control" value="<?= htmlspecialchars($year_from) ?>" placeholder="1900">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold"><?= __('year_to') ?></label>
                <input type="number" name="year_to" class="form-control" value="<?= htmlspecialchars($year_to) ?>" placeholder="<?= date('Y') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold"><?= __('language') ?></label>
                <select name="language" class="form-select">
                    <option value=""><?= __('all_languages') ?></option>
                    <?php foreach ($languages as $langOption): ?>
                        <option value="<?= htmlspecialchars($langOption) ?>" <?= $language === $langOption ? 'selected' : '' ?>><?= htmlspecialchars($langOption) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-bold"><?= __('curriculum') ?></label>
                <input type="text" name="curriculum" class="form-control" value="<?= htmlspecialchars($curriculum) ?>" placeholder="e.g., CBSE, IB">
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary px-4"><i class="fas fa-search"></i> <?= __('search') ?></button>
                <a href="advanced_search.php" class="btn btn-secondary"><?= __('clear_filters') ?></a>
            </div>
        </form>
    </div>

    <?php if ($_GET): ?>
        <div class="mb-3">
            <strong><?= number_format($total) ?></strong> <?= __('results_found') ?>
        </div>

        <?php if (empty($books)): ?>
            <div class="alert alert-info text-center py-5">
                <i class="fas fa-search fa-3x mb-3"></i>
                <h5><?= __('no_books_found') ?></h5>
                <p><?= __('try_adjusting') ?></p>
            </div>
        <?php else: ?>
            <?php foreach ($books as $book): 
                $coverBase64 = getCoverBase64($book['cover_path'] ?? '');
                $isAvailable = $book['available'] > 0;
            ?>
                <div class="result-card" onclick="viewBook('<?= htmlspecialchars($book['barcode']) ?>')" style="cursor: pointer;">
                    <div class="row">
                        <div class="col-auto">
                            <?php if ($coverBase64): ?>
                                <img src="<?= $coverBase64 ?>" class="book-cover" alt="Cover">
                            <?php else: ?>
                                <div class="book-cover d-flex align-items-center justify-content-center bg-light"><i class="fas fa-book fa-3x text-muted"></i></div>
                            <?php endif; ?>
                        </div>
                        <div class="col">
                            <h5 class="mb-1"><?= htmlspecialchars($book['title']) ?></h5>
                            <p class="mb-1 text-muted small">
                                <?= htmlspecialchars($book['author'] ?? __('unknown_author')) ?> 
                                <?php if ($book['year']): ?>(<?= htmlspecialchars($book['year']) ?>)<?php endif; ?>
                            </p>
                            <p class="mb-2 small">
                                <?= __('publisher_label') ?>: <?= htmlspecialchars($book['publisher'] ?? 'N/A') ?> | 
                                <?= __('isbn_label') ?>: <?= htmlspecialchars($book['isbn'] ?? 'N/A') ?>
                            </p>
                            <div>
                                <span class="badge bg-<?= $isAvailable ? 'success' : 'danger' ?>">
                                    <?= $isAvailable ? __('available') : __('not_available') ?>
                                </span>
                                <?php if ($book['available'] > 0): ?>
                                    <span class="badge bg-info"><?= $book['available'] ?> <?= __('copies_available') ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if ($totalPages > 1): ?>
            <nav>
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>"><?= __('previous') ?></a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>"><?= __('next') ?></a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="fas fa-search fa-4x text-muted mb-3"></i>
            <h4><?= __('enter_search_criteria') ?></h4>
            <p class="text-muted"><?= __('you_can_search') ?></p>
        </div>
    <?php endif; ?>
</div>

<footer class="footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function viewBook(barcode) {
    window.location.href = 'book_details.php?barcode=' + encodeURIComponent(barcode);
}
</script>
</body>
</html>