<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'ebooks' => 'eBooks',
        'digital_collection' => 'Digital Collection',
        'search_ebooks' => 'Search eBooks',
        'search_by_title_author_subject' => 'Search by title, author, subject...',
        'all_subjects' => 'All Subjects',
        'filter_by_subject' => 'Filter by Subject',
        'most_popular' => 'Most Popular',
        'latest' => 'Latest',
        'download' => 'Download',
        'view_details' => 'View Details',
        'title' => 'Title',
        'author' => 'Author',
        'subject' => 'Subject',
        'publisher' => 'Publisher',
        'year' => 'Year',
        'isbn' => 'ISBN',
        'description' => 'Description',
        'downloads' => 'Downloads',
        'no_ebooks_found' => 'No eBooks found',
        'back_to_home' => 'Back to Home',
        'opac' => 'OPAC',
        'new_arrivals' => 'New Arrivals',
        'library_hours' => 'Library Hours',
        'designed_by' => 'Designed by',
        'all_rights_reserved' => 'All rights reserved.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
        'unknown_author' => 'Unknown Author',
        'ebooks_found' => 'eBooks found',
    ],
    'hi' => [
        'ebooks' => 'ई-पुस्तकें',
        'digital_collection' => 'डिजिटल संग्रह',
        'search_ebooks' => 'ई-पुस्तकें खोजें',
        'search_by_title_author_subject' => 'शीर्षक, लेखक, विषय से खोजें...',
        'all_subjects' => 'सभी विषय',
        'filter_by_subject' => 'विषय के अनुसार फ़िल्टर करें',
        'most_popular' => 'सबसे लोकप्रिय',
        'latest' => 'नवीनतम',
        'download' => 'डाउनलोड',
        'view_details' => 'विवरण देखें',
        'title' => 'शीर्षक',
        'author' => 'लेखक',
        'subject' => 'विषय',
        'publisher' => 'प्रकाशक',
        'year' => 'वर्ष',
        'isbn' => 'ISBN',
        'description' => 'विवरण',
        'downloads' => 'डाउनलोड',
        'no_ebooks_found' => 'कोई ई-पुस्तक नहीं मिली',
        'back_to_home' => 'होम पर वापस जाएं',
        'opac' => 'OPAC',
        'new_arrivals' => 'नई आगमन',
        'library_hours' => 'पुस्तकालय समय',
        'designed_by' => 'द्वारा डिज़ाइन किया गया',
        'all_rights_reserved' => 'सर्वाधिकार सुरक्षित।',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
        'unknown_author' => 'अज्ञात लेखक',
        'ebooks_found' => 'ई-पुस्तकें मिलीं',
    ],
    'ar' => [
        'ebooks' => 'الكتب الإلكترونية',
        'digital_collection' => 'المجموعة الرقمية',
        'search_ebooks' => 'البحث في الكتب الإلكترونية',
        'search_by_title_author_subject' => 'ابحث بالعنوان، المؤلف، الموضوع...',
        'all_subjects' => 'جميع المواد',
        'filter_by_subject' => 'تصفية حسب الموضوع',
        'most_popular' => 'الأكثر شهرة',
        'latest' => 'الأحدث',
        'download' => 'تحميل',
        'view_details' => 'عرض التفاصيل',
        'title' => 'العنوان',
        'author' => 'المؤلف',
        'subject' => 'الموضوع',
        'publisher' => 'الناشر',
        'year' => 'السنة',
        'isbn' => 'الترقيم الدولي',
        'description' => 'الوصف',
        'downloads' => 'التنزيلات',
        'no_ebooks_found' => 'لم يتم العثور على كتب إلكترونية',
        'back_to_home' => 'العودة إلى الرئيسية',
        'opac' => 'الفهرس العام',
        'new_arrivals' => 'الوافدون الجدد',
        'library_hours' => 'ساعات المكتبة',
        'designed_by' => 'تصميم',
        'all_rights_reserved' => 'جميع الحقوق محفوظة.',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
        'unknown_author' => 'مؤلف غير معروف',
        'ebooks_found' => 'كتب إلكترونية وجدت',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}

function isRTL() { global $lang; return $lang === 'ar'; }

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

function getHeaderLogoUrl() {
    global $settings, $institution;
    $resolveUrl = function($path) {
        if (empty($path)) return '';
        if (filter_var($path, FILTER_VALIDATE_URL)) return $path;
        $cleanPath = ltrim($path, '/');
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
        $baseDir = str_replace('/opac', '', $scriptDir);
        return $protocol . '://' . $host . rtrim($baseDir, '/') . '/' . $cleanPath;
    };
    $logoKeys = ['opac_header_logo', 'library_logo', 'right_logo_path'];
    foreach ($logoKeys as $key) {
        if (!empty($settings[$key])) {
            $url = $resolveUrl($settings[$key]);
            $testPath = parse_url($url, PHP_URL_PATH);
            if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
        }
    }
    if (!empty($institution['logo_path'])) {
        $url = $resolveUrl($institution['logo_path']);
        $testPath = parse_url($url, PHP_URL_PATH);
        if ($testPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $testPath)) return $url;
    }
    return 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'120\' height=\'60\' viewBox=\'0 0 120 60\'%3E%3Crect width=\'120\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'15\' y=\'38\' font-size=\'16\' fill=\'%231e3c72\' font-weight=\'bold\'%3E📚 LIBRARY%3C/text%3E%3C/svg%3E';
}
$logoUrl = getHeaderLogoUrl();

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = (int)($settings['opac_ebooks_per_page'] ?? 8);
$offset = ($page - 1) * $perPage;
$subject = isset($_GET['subject']) ? trim($_GET['subject']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'latest';

$whereConditions = [];
$params = [];
if (!empty($subject)) {
    $whereConditions[] = "subject = ?";
    $params[] = $subject;
}
if (!empty($search)) {
    $whereConditions[] = "(title LIKE ? OR author LIKE ? OR subject LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$whereClause = count($whereConditions) > 0 ? "WHERE " . implode(" AND ", $whereConditions) : "";
$orderBy = $sort == 'popular' ? "ORDER BY downloads DESC" : "ORDER BY created_at DESC";

$countStmt = $db->prepare("SELECT COUNT(*) FROM ebooks $whereClause");
$countStmt->execute($params);
$totalEbooks = $countStmt->fetchColumn();
$totalPages = ceil($totalEbooks / $perPage);

$stmt = $db->prepare("SELECT * FROM ebooks $whereClause $orderBy LIMIT ? OFFSET ?");
$stmt->execute(array_merge($params, [$perPage, $offset]));
$ebooks = $stmt->fetchAll();

$subjects = $db->query("SELECT DISTINCT subject FROM ebooks WHERE subject IS NOT NULL AND subject != '' ORDER BY subject")->fetchAll(PDO::FETCH_COLUMN);
$popularEbooks = $db->query("SELECT id, title, author, downloads FROM ebooks WHERE downloads > 0 ORDER BY downloads DESC LIMIT 5")->fetchAll();

$opacHeaderBgColor = $settings['opac_header_bg_color'] ?? '#1e3c72';
$opacPrimaryColor = $settings['opac_primary_color'] ?? '#1e3c72';
$opacFontFamily = $settings['opac_font_family'] ?? 'Inter';

?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= __('ebooks') ?> - <?= htmlspecialchars($institution['name'] ?? 'Library') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($opacFontFamily) ?>:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: '<?= $opacFontFamily ?>', 'Inter', sans-serif; }
        body { background: #f0f2f5; }
        .header-bg { background: <?= $opacHeaderBgColor ?>; color: white; padding: 15px 0; margin-bottom: 30px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .header-container { display: flex; align-items: center; justify-content: space-between; max-width: 1400px; margin: 0 auto; padding: 0 20px; }
        .header-left img { height: 60px; width: auto; max-width: 130px; object-fit: contain; background: white; border-radius: 8px; padding: 5px; }
        .header-title h1 { font-size: 1.8rem; font-weight: 600; margin: 0; }
        .header-title p { margin: 0; opacity: 0.9; }
        .lang-switch { background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 30px; padding: 6px 15px; color: white; text-decoration: none; font-size: 13px; transition: all 0.3s; }
        .lang-switch:hover { background: rgba(255,255,255,0.25); color: white; }
        .ebook-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: all 0.3s; height: 100%; }
        .ebook-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.15); }
        .ebook-cover { height: 220px; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea, #764ba2); }
        .ebook-cover img { max-height: 180px; width: auto; object-fit: contain; }
        .download-badge { position: absolute; top: 10px; right: 10px; }
        .filter-sidebar { background: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); position: sticky; top: 20px; }
        .subject-list { list-style: none; padding: 0; }
        .subject-list li { margin-bottom: 10px; }
        .subject-list a { color: #333; text-decoration: none; display: block; padding: 5px 10px; border-radius: 6px; transition: all 0.3s; }
        .subject-list a:hover, .subject-list a.active { background: <?= $opacPrimaryColor ?>; color: white; }
        .popular-ebook-item { padding: 10px; border-bottom: 1px solid #eee; transition: all 0.3s; cursor: pointer; }
        .popular-ebook-item:hover { background: #f8f9fa; transform: translateX(5px); }
        .pagination .page-link { color: <?= $opacPrimaryColor ?>; }
        .pagination .active .page-link { background: <?= $opacPrimaryColor ?>; border-color: <?= $opacPrimaryColor ?>; color: white; }
        .footer { background: #1a1a2e; color: #eee; padding: 30px 0 20px; margin-top: 50px; }
        .footer a { color: #ffd700; text-decoration: none; }
        [dir="rtl"] .me-2 { margin-right: 0 !important; margin-left: 0.5rem !important; }
        [dir="rtl"] .ms-2 { margin-left: 0 !important; margin-right: 0.5rem !important; }
        @media (max-width: 768px) {
            .header-container { flex-direction: column; gap: 10px; text-align: center; }
            .header-title h1 { font-size: 1.3rem; }
            .ebook-cover { height: 180px; }
        }
    </style>
</head>
<body>

<div class="header-bg">
    <div class="header-container">
        <div class="header-left"><img src="<?= htmlspecialchars($logoUrl) ?>" alt="Logo"></div>
        <div class="header-title text-center">
            <h1><?= __('ebooks') ?></h1>
            <p><?= __('digital_collection') ?></p>
        </div>
        <div>
            <!-- 3-language switcher -->
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                    <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container mt-2">
        <a href="index.php" class="btn btn-outline-light btn-sm"><i class="fas fa-arrow-left"></i> <?= __('back_to_home') ?></a>
        <a href="new_arrivals.php" class="btn btn-outline-warning btn-sm ms-2"><i class="fas fa-star"></i> <?= __('new_arrivals') ?></a>
    </div>
</div>

<div class="container">
    <div class="row g-4">
        <div class="col-lg-3">
            <div class="filter-sidebar">
                <h5><i class="fas fa-filter"></i> <?= __('filter_by_subject') ?></h5>
                <hr>
                <ul class="subject-list">
                    <li><a href="ebooks.php" class="<?= empty($subject) ? 'active' : '' ?>"><?= __('all_subjects') ?> (<?= $totalEbooks ?>)</a></li>
                    <?php foreach ($subjects as $subj): 
                        $subjCount = $db->prepare("SELECT COUNT(*) FROM ebooks WHERE subject = ?")->execute([$subj])->fetchColumn();
                    ?>
                    <li><a href="?subject=<?= urlencode($subj) ?>&sort=<?= $sort ?>" class="<?= $subject == $subj ? 'active' : '' ?>"><?= htmlspecialchars($subj) ?> (<?= $subjCount ?>)</a></li>
                    <?php endforeach; ?>
                </ul>
                <hr>
                <h5><i class="fas fa-search"></i> <?= __('search_ebooks') ?></h5>
                <form method="GET" action="">
                    <input type="hidden" name="subject" value="<?= htmlspecialchars($subject) ?>">
                    <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="<?= __('search_by_title_author_subject') ?>" value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </form>
                <hr>
                <h5><i class="fas fa-chart-line"></i> <?= __('most_popular') ?></h5>
                <?php foreach ($popularEbooks as $pe): ?>
                <div class="popular-ebook-item" onclick="downloadEbook(<?= $pe['id'] ?>, '<?= htmlspecialchars($pe['title']) ?>')">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="fw-semibold"><?= htmlspecialchars(substr($pe['title'], 0, 30)) ?></small>
                            <br><small class="text-muted"><?= htmlspecialchars($pe['author'] ?? __('unknown_author')) ?></small>
                        </div>
                        <span class="badge bg-danger rounded-pill"><?= $pe['downloads'] ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if (function_exists('getLibraryHoursHTML')): ?>
                    <hr><?= getLibraryHoursHTML() ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div><span class="text-muted"><?= $totalEbooks ?> <?= __('ebooks_found') ?></span></div>
                <div>
                    <div class="btn-group btn-group-sm">
                        <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'latest', 'page' => 1])) ?>" class="btn <?= $sort == 'latest' ? 'btn-primary' : 'btn-outline-secondary' ?>"><i class="fas fa-clock"></i> <?= __('latest') ?></a>
                        <a href="?<?= http_build_query(array_merge($_GET, ['sort' => 'popular', 'page' => 1])) ?>" class="btn <?= $sort == 'popular' ? 'btn-primary' : 'btn-outline-secondary' ?>"><i class="fas fa-fire"></i> <?= __('most_popular') ?></a>
                    </div>
                </div>
            </div>

            <?php if (empty($ebooks)): ?>
                <div class="alert alert-info text-center py-5">
                    <i class="fas fa-file-pdf fa-3x mb-3"></i>
                    <h5><?= __('no_ebooks_found') ?></h5>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($ebooks as $ebook): 
                        $coverBase64 = getCoverBase64($ebook['cover_path'] ?? '');
                    ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="ebook-card">
                            <div class="ebook-cover position-relative">
                                <?php if ($coverBase64): ?>
                                    <img src="<?= $coverBase64 ?>" alt="<?= htmlspecialchars($ebook['title']) ?>">
                                <?php else: ?>
                                    <i class="fas fa-file-pdf fa-4x text-white"></i>
                                <?php endif; ?>
                                <div class="download-badge"><span class="badge bg-danger"><i class="fas fa-download"></i> <?= $ebook['downloads'] ?? 0 ?></span></div>
                            </div>
                            <div class="card-body p-3">
                                <h6 class="card-title fw-semibold mb-1"><?= htmlspecialchars(substr($ebook['title'], 0, 45)) ?></h6>
                                <p class="small text-muted mb-1"><i class="fas fa-user"></i> <?= htmlspecialchars($ebook['author'] ?? __('unknown_author')) ?></p>
                                <?php if (!empty($ebook['subject'])): ?>
                                    <p class="small text-muted mb-1"><i class="fas fa-tag"></i> <?= htmlspecialchars(substr($ebook['subject'], 0, 25)) ?></p>
                                <?php endif; ?>
                                <div class="mt-2">
                                    <button class="btn btn-danger btn-sm w-100" onclick="downloadEbook(<?= $ebook['id'] ?>, '<?= htmlspecialchars($ebook['title']) ?>')">
                                        <i class="fas fa-download"></i> <?= __('download') ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php if ($totalPages > 1): ?>
                <nav class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>">«</a>
                        </li>
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>">»</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer class="footer">
    <div class="container text-center">
        <p class="small mb-0">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Library System') ?>. <?= __('all_rights_reserved') ?></p>
        <p class="small mt-1"><?= __('designed_by') ?> <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank">Sameermon</a></p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function downloadEbook(id, title) {
    if (confirm(`Download "${title}"?`)) {
        window.open(`download_ebook.php?id=${id}`, '_blank');
    }
}
</script>
</body>
</html>