<?php
require_once __DIR__ . '/../../config/db.php';

$db = getDB();
$type = $_GET['type'] ?? 'weekly';

if ($type === 'weekly') {
    $data = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $stmt = $db->prepare("SELECT books_issued, books_returned FROM daily_stats WHERE stat_date = ?");
        $stmt->execute([$date]);
        $row = $stmt->fetch();
        $data[] = [
            'date' => $date,
            'issues' => $row['books_issued'] ?? 0,
            'returns' => $row['books_returned'] ?? 0
        ];
    }
    echo json_encode($data);
}