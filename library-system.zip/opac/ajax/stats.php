<?php
require_once __DIR__ . '/../../config/db.php';

$db = getDB();

$totalBooks = $db->query("SELECT SUM(quantity) as total FROM books")->fetchColumn();
$totalBooks = $totalBooks ?: $db->query("SELECT COUNT(*) FROM books")->fetchColumn();

$totalMembers = $db->query("SELECT COUNT(*) FROM members")->fetchColumn();
$activeIssues = $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
$insideCount = $db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'")->fetchColumn();

echo json_encode([
    'totalBooks' => $totalBooks,
    'totalMembers' => $totalMembers,
    'activeIssues' => $activeIssues,
    'insideCount' => $insideCount
]);