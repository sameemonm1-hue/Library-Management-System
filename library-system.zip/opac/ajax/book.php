<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';

$db = getDB();

if (isset($_GET['barcode'])) {
    $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
    $stmt->execute([$_GET['barcode']]);
    echo json_encode($stmt->fetch());
}