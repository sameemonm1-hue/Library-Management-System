<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';

$db = getDB();

if (isset($_GET['admno'])) {
    $stmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $stmt->execute([$_GET['admno']]);
    echo json_encode($stmt->fetch());
}