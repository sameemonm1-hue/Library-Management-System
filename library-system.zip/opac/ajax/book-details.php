<?php
/**
 * AJAX: Get Book Details for Modal
 */

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';

header('Content-Type: application/json');

$db = getDB();

if (isset($_GET['barcode'])) {
    $stmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
    $stmt->execute([$_GET['barcode']]);
    $book = $stmt->fetch();
    
    if ($book) {
        // Add cover path info
        if ($book['cover_path'] && file_exists($book['cover_path'])) {
            $book['cover_exists'] = true;
        } else {
            $book['cover_exists'] = false;
            $book['cover_path'] = '';
        }
        echo json_encode($book);
    } else {
        echo json_encode(null);
    }
} else {
    echo json_encode(['error' => 'No barcode provided']);
}