<?php
/**
 * log_action.php
 * Simple action logger for WHOM button clicks
 */

session_start();
require_once '../config/db.php';
require_once '../config/functions.php';

header('Content-Type: application/json');

try {
    if (!isset($_POST['action']) || $_POST['action'] !== 'whom_click') {
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
        exit;
    }

    $book_id = isset($_POST['book_id']) ? (int)$_POST['book_id'] : 0;
    $member_holder = isset($_POST['member_holder']) ? trim($_POST['member_holder']) : '';

    if ($book_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid book ID']);
        exit;
    }

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([
        $_SESSION['member_name'] ?? 'Guest',
        'WHOM_CLICK',
        "Viewed holder for book ID: $book_id, Holder: $member_holder",
        $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>