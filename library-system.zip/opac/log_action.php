<?php
session_start();
require_once '../config/db.php';

$data = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
    } else {
        $data = $_POST;
    }
}

$db = getDB();
$stmt = $db->prepare("INSERT INTO kiosk_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([
    $_SESSION['member_id'] ?? 'guest',
    $data['action'] ?? '',
    isset($data['details']) ? substr($data['details'], 0, 500) : '',
    $_SERVER['REMOTE_ADDR'],
    $_SERVER['HTTP_USER_AGENT'] ?? ''
]);

http_response_code(204);
?>