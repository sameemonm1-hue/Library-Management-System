<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== MULTI-LANGUAGE ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['lang'] ?? 'en';

$translations = [
    'en' => [
        'register_member' => 'Register as Library Member',
        'admission_number' => 'Admission Number *',
        'full_name' => 'Full Name *',
        'email' => 'Email *',
        'phone' => 'Phone',
        'password' => 'Password *',
        'confirm_password' => 'Confirm Password *',
        'captcha' => 'CAPTCHA',
        'register' => 'Register',
        'already_have_account' => 'Already have an account? Login',
        'passwords_mismatch' => 'Passwords do not match.',
        'captcha_incorrect' => 'CAPTCHA incorrect.',
        'admno_exists' => 'Admission number already registered.',
        'registration_success' => 'Registration submitted. You will receive an email after admin approval.',
        'back_to_home' => 'Back to Home',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'hi' => [
        'register_member' => 'पुस्तकालय सदस्य के रूप में पंजीकरण करें',
        'admission_number' => 'नामांकन संख्या *',
        'full_name' => 'पूरा नाम *',
        'email' => 'ईमेल *',
        'phone' => 'फोन',
        'password' => 'पासवर्ड *',
        'confirm_password' => 'पासवर्ड की पुष्टि करें *',
        'captcha' => 'CAPTCHA',
        'register' => 'पंजीकरण करें',
        'already_have_account' => 'पहले से खाता है? लॉगिन करें',
        'passwords_mismatch' => 'पासवर्ड मेल नहीं खाते।',
        'captcha_incorrect' => 'CAPTCHA गलत है।',
        'admno_exists' => 'नामांकन संख्या पहले से पंजीकृत है।',
        'registration_success' => 'पंजीकरण जमा किया गया। प्रशासक द्वारा अनुमोदन के बाद आपको ईमेल प्राप्त होगा।',
        'back_to_home' => 'होम पर वापस जाएं',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ],
    'ar' => [
        'register_member' => 'التسجيل كعضو في المكتبة',
        'admission_number' => 'رقم القبول *',
        'full_name' => 'الاسم الكامل *',
        'email' => 'البريد الإلكتروني *',
        'phone' => 'الهاتف',
        'password' => 'كلمة المرور *',
        'confirm_password' => 'تأكيد كلمة المرور *',
        'captcha' => 'CAPTCHA',
        'register' => 'تسجيل',
        'already_have_account' => 'هل لديك حساب؟ تسجيل الدخول',
        'passwords_mismatch' => 'كلمات المرور غير متطابقة.',
        'captcha_incorrect' => 'CAPTCHA غير صحيح.',
        'admno_exists' => 'رقم القبول مسجل بالفعل.',
        'registration_success' => 'تم تقديم التسجيل. ستتلقى بريدًا إلكترونيًا بعد موافقة المسؤول.',
        'back_to_home' => 'العودة إلى الرئيسية',
        'switch_to_arabic' => 'العربية',
        'switch_to_hindi' => 'हिन्दी',
        'switch_to_english' => 'English',
    ]
];

function __($key) {
    global $lang, $translations;
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}
function isRTL() { global $lang; return $lang === 'ar'; }

$error = '';
$success = '';
$db = getDB();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admno   = trim($_POST['admno']);
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];
    $captcha  = (int)$_POST['captcha'];
    $captchaSum = (int)$_SESSION['captcha_sum'];

    if ($password !== $confirm) {
        $error = __('passwords_mismatch');
    } elseif ($captcha !== $captchaSum) {
        $error = __('captcha_incorrect');
    } else {
        $check = $db->prepare("SELECT id FROM members WHERE admno = ?");
        $check->execute([$admno]);
        if ($check->fetch()) {
            $error = __('admno_exists');
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $insert = $db->prepare("INSERT INTO members (admno, name, email, phone, password, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', datetime('now'))");
            $insert->execute([$admno, $name, $email, $phone, $hashed]);
            $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")
               ->execute([$email, "Registration Request", "Dear $name, your registration request has been submitted. Admin will approve it soon."]);
            $success = __('registration_success');
        }
    }
}
$num1 = rand(1,9);
$num2 = rand(1,9);
$_SESSION['captcha_sum'] = $num1 + $num2;
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" <?= isRTL() ? 'dir="rtl"' : '' ?>>
<head>
    <title><?= __('register_member') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>body{background:#f0f2f5;}</style>
</head>
<body>
<div class="container mt-5" style="max-width: 600px;">
    <div class="card shadow border-0 rounded-4">
        <div class="card-body p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="mb-0"><i class="fas fa-user-plus"></i> <?= __('register_member') ?></h2>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-globe"></i> <?= strtoupper($lang) ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item <?= ($lang == 'en') ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'hi') ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                        <li><a class="dropdown-item <?= ($lang == 'ar') ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                    </ul>
                </div>
            </div>
            <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
            <form method="post">
                <div class="mb-3"><label class="form-label"><?= __('admission_number') ?></label><input type="text" name="admno" class="form-control" required></div>
                <div class="mb-3"><label class="form-label"><?= __('full_name') ?></label><input type="text" name="name" class="form-control" required></div>
                <div class="mb-3"><label class="form-label"><?= __('email') ?></label><input type="email" name="email" class="form-control" required></div>
                <div class="mb-3"><label class="form-label"><?= __('phone') ?></label><input type="text" name="phone" class="form-control"></div>
                <div class="mb-3"><label class="form-label"><?= __('password') ?></label><input type="password" name="password" class="form-control" required></div>
                <div class="mb-3"><label class="form-label"><?= __('confirm_password') ?></label><input type="password" name="confirm_password" class="form-control" required></div>
                <div class="mb-3"><label class="form-label"><?= __('captcha') ?>: <?= $num1 ?> + <?= $num2 ?> = ?</label><input type="text" name="captcha" class="form-control" required></div>
                <button type="submit" class="btn btn-primary w-100"><?= __('register') ?></button>
                <div class="text-center mt-3"><a href="login.php"><?= __('already_have_account') ?></a></div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>