<?php
// Prevent session start warnings
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Optional: log member logout activity (if logActivity exists)
if (isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true && function_exists('logActivity')) {
    $admno = $_SESSION['member_admno'] ?? 'Unknown';
    $name = $_SESSION['member_name'] ?? 'Unknown';
    logActivity($admno, 'MEMBER_LOGOUT', "Member $name ($admno) logged out from OPAC");
}

// Clear all member session variables
$_SESSION = [];

// Destroy the session completely
session_destroy();

// Redirect to member login page (or OPAC homepage)
header("Location: index.php");
exit;
?>