<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/SessionManager.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

$sessionManager = new SessionManager();

if (isset($_GET['extend'])) {
    $sessionManager->extendSession();
    echo json_encode(['success' => true, 'message' => 'Session extended']);
} else {
    $timeRemaining = $sessionManager->getTimeoutWarningTime();
    echo json_encode(['success' => true, 'time_remaining' => $timeRemaining]);
}
?>