<?php
/**
 * Return Book - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - Member photo display in result card
 * - Book cover display
 * - AJAX processing with visual feedback
 * - Hold queue notification
 * - Fine calculation with admin waive option
 * - Responsive layout with proper alignment
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$toast = '';
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

// Report settings for unified styling
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== AJAX PROCESS RETURN ==========
if (isset($_GET['ajax_process_return']) || isset($_POST['ajax_process_return'])) {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode'] ?? $_POST['barcode'] ?? '');
    $csrf = $_GET['csrf_token'] ?? $_POST['csrf_token'] ?? '';
    $waiveFine = ($_GET['waive_fine'] ?? $_POST['waive_fine'] ?? 0) == 1 && $isAdmin;
    
    if ($csrf !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid security token.']);
        exit;
    }
    if (empty($barcode)) {
        echo json_encode(['success' => false, 'error' => 'Barcode is required.']);
        exit;
    }
    
    try {
        $db->beginTransaction();
        
        // Get circulation record with member and book details
        $stmt = $db->prepare("SELECT c.*, m.total_fines as current_fines, m.name as member_name, 
                                     m.admno, m.member_category, m.photo_path,
                                     b.title, b.author, b.item_category, b.barcode as book_barcode, 
                                     b.cover_path
                              FROM circulation c 
                              LEFT JOIN members m ON c.admno = m.admno 
                              LEFT JOIN books b ON c.barcode = b.barcode
                              WHERE c.barcode = ? AND c.return_date IS NULL");
        $stmt->execute([$barcode]);
        $record = $stmt->fetch();
        if (!$record) throw new Exception("No active issue found for this barcode.");
        
        // Fine calculation
        $rule = getLoanRule($record['member_category'], $record['item_category']);
        if ($rule) {
            $finePerDay = $rule['fine_per_day'];
            $gracePeriod = $rule['grace_period'];
        } else {
            $finePerDay = (float)($settings['fine_per_day'] ?? 2);
            $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
        }
        
        $dueDate = new DateTime($record['due_date']);
        $today = new DateTime();
        $fine = 0;
        if ($today > $dueDate) {
            $daysOverdue = $today->diff($dueDate)->days;
            $chargeableDays = max(0, $daysOverdue - $gracePeriod);
            $fine = $chargeableDays * $finePerDay;
            $maxFine = (float)($settings['max_fine_amount'] ?? 0);
            if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                $fine = max(0, $maxFine - $record['current_fines']);
            }
        }
        if ($waiveFine) $fine = 0;
        
        // Update circulation
        $db->prepare("UPDATE circulation SET return_date = ?, fine = ? WHERE id = ?")->execute([date('Y-m-d'), $fine, $record['id']]);
        
        // Update book availability
        if ($record['is_manual'] == 0) {
            $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
        }
        
        // Update member
        if ($fine > 0) {
            $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
        } else {
            $db->prepare("UPDATE members SET active_books = active_books - 1 WHERE admno = ?")->execute([$record['admno']]);
        }
        
        // ========== HOLD QUEUE CHECK ==========
        $holdStmt = $db->prepare("SELECT id, admno, member_name FROM book_holds WHERE book_barcode = ? AND status = 'pending' ORDER BY hold_date ASC LIMIT 1");
        $holdStmt->execute([$record['book_barcode']]);
        $nextHold = $holdStmt->fetch();
        if ($nextHold) {
            $db->prepare("UPDATE book_holds SET status = 'available', notified = 0 WHERE id = ?")->execute([$nextHold['id']]);
            $memberStmt = $db->prepare("SELECT email FROM members WHERE admno = ? AND status = 'active'");
            $memberStmt->execute([$nextHold['admno']]);
            $memberEmail = $memberStmt->fetchColumn();
            if ($memberEmail) {
                $bookTitle = $record['title'];
                $subject = "Hold Available: $bookTitle";
                $body = "Dear {$nextHold['member_name']},\n\nThe book \"$bookTitle\" is now available for pickup at the library. Please collect it by " . date('Y-m-d', strtotime('+7 days')) . ".\n\nThank you.";
                $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$memberEmail, $subject, $body]);
            }
        }
        
        $db->commit();
        
        // Prepare response with images
        $photo_base64 = getImageBase64($record['photo_path'] ?? '');
        $cover_base64 = getImageBase64($record['cover_path'] ?? '');
        
        $daysOverdue = max(0, (strtotime(date('Y-m-d')) - strtotime($record['due_date'])) / 86400);
        
        echo json_encode([
            'success' => true,
            'message' => 'Book returned successfully!',
            'fine' => formatCurrency($fine),
            'days_overdue' => ceil($daysOverdue),
            'member_name' => $record['member_name'],
            'member_admno' => $record['admno'],
            'book_title' => $record['title'],
            'photo_base64' => $photo_base64,
            'cover_base64' => $cover_base64,
            'new_total_fine' => formatCurrency($record['current_fines'] + $fine),
            'waived' => $waiveFine
        ]);
        
        logActivity($_SESSION['username'], 'BOOK_RETURN_AJAX', "Returned {$record['title']} to {$record['admno']} - Fine: $fine" . ($waiveFine ? ' (waived)' : ''));
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// ========== FALLBACK TRADITIONAL POST ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            $barcode = trim($_POST['barcode']);
            $waiveFine = isset($_POST['waive_fine']) && $isAdmin;
            
            $stmt = $db->prepare("SELECT c.*, m.total_fines as current_fines, m.member_category, 
                                         b.item_category, b.title, b.barcode as book_barcode, 
                                         m.photo_path, b.cover_path
                                  FROM circulation c 
                                  LEFT JOIN members m ON c.admno = m.admno 
                                  LEFT JOIN books b ON c.barcode = b.barcode
                                  WHERE c.barcode = ? AND c.return_date IS NULL");
            $stmt->execute([$barcode]);
            $record = $stmt->fetch();
            if (!$record) throw new Exception("No active issue found for this barcode.");
            
            $rule = getLoanRule($record['member_category'], $record['item_category']);
            if ($rule) {
                $finePerDay = $rule['fine_per_day'];
                $gracePeriod = $rule['grace_period'];
            } else {
                $finePerDay = (float)($settings['fine_per_day'] ?? 2);
                $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
            }
            
            $dueDate = new DateTime($record['due_date']);
            $today = new DateTime();
            $fine = 0;
            if ($today > $dueDate) {
                $daysOverdue = $today->diff($dueDate)->days;
                $chargeableDays = max(0, $daysOverdue - $gracePeriod);
                $fine = $chargeableDays * $finePerDay;
                $maxFine = (float)($settings['max_fine_amount'] ?? 0);
                if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                    $fine = max(0, $maxFine - $record['current_fines']);
                }
            }
            if ($waiveFine) $fine = 0;
            
            $db->prepare("UPDATE circulation SET return_date = ?, fine = ? WHERE id = ?")->execute([date('Y-m-d'), $fine, $record['id']]);
            if ($record['is_manual'] == 0) {
                $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
            }
            if ($fine > 0) {
                $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
            } else {
                $db->prepare("UPDATE members SET active_books = active_books - 1 WHERE admno = ?")->execute([$record['admno']]);
            }
            
            // Hold queue check
            $holdStmt = $db->prepare("SELECT id, admno, member_name FROM book_holds WHERE book_barcode = ? AND status = 'pending' ORDER BY hold_date ASC LIMIT 1");
            $holdStmt->execute([$record['book_barcode']]);
            $nextHold = $holdStmt->fetch();
            if ($nextHold) {
                $db->prepare("UPDATE book_holds SET status = 'available', notified = 0 WHERE id = ?")->execute([$nextHold['id']]);
                $memberStmt = $db->prepare("SELECT email FROM members WHERE admno = ? AND status = 'active'");
                $memberStmt->execute([$nextHold['admno']]);
                $memberEmail = $memberStmt->fetchColumn();
                if ($memberEmail) {
                    $bookTitle = $record['title'];
                    $subject = "Hold Available: $bookTitle";
                    $body = "Dear {$nextHold['member_name']},\n\nThe book \"$bookTitle\" is now available for pickup at the library. Please collect it by " . date('Y-m-d', strtotime('+7 days')) . ".\n\nThank you.";
                    $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$memberEmail, $subject, $body]);
                }
            }
            
            $db->commit();
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book returned successfully!';
            if ($fine > 0) $toast .= "<br>💰 Fine: " . formatCurrency($fine);
            if ($waiveFine) $toast .= "<br>💸 Fine waived by admin.";
            $toast .= '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            logActivity($_SESSION['username'], 'BOOK_RETURN', "Returned {$record['title']} - Fine: $fine" . ($waiveFine ? ' (waived)' : ''));
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Return Book');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-warning {
        background: linear-gradient(135deg, #f0ad4e, #ffc107) !important;
    }
    .card-custom .card-header.bg-success {
        background: linear-gradient(135deg, #28a745, #20c997) !important;
    }
    .card-custom .card-body {
        padding: 1.5rem;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }

    /* ========== RESULT CARD ========== */
    .return-result-card {
        background: #f8f9fa;
        border-radius: var(--border-radius);
        padding: 18px;
        margin-top: 12px;
        border: 2px solid var(--success);
        transition: var(--transition);
        animation: slideIn 0.3s ease;
    }
    @keyframes slideIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .return-result-card .member-photo {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid var(--success);
        background: #fff;
        flex-shrink: 0;
        transition: var(--transition);
    }
    .return-result-card .member-photo:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .return-result-card .member-photo-placeholder {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid var(--success);
        flex-shrink: 0;
        color: #6c757d;
        font-size: 2.5rem;
    }
    .return-result-card .book-cover-small {
        max-width: 50px;
        max-height: 70px;
        object-fit: contain;
        border-radius: 6px;
        border: 1px solid #dee2e6;
        background: #fff;
        padding: 2px;
        transition: var(--transition);
    }
    .return-result-card .book-cover-small:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .return-result-card .result-body {
        display: flex;
        align-items: center;
        gap: 15px;
        flex-wrap: wrap;
    }
    .return-result-card .result-details {
        flex: 1;
        min-width: 200px;
    }
    .return-result-card .result-details p {
        margin-bottom: 4px;
        font-size: 0.9rem;
    }
    .return-result-card .result-details h5 {
        color: var(--success);
    }
    
    /* ========== BADGES ========== */
    .badge-result {
        display: inline-block;
        padding: 3px 12px;
        border-radius: 30px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .badge-success { background: #d4edda; color: #155724; }
    .badge-danger { background: #f8d7da; color: #721c24; }
    .badge-warning { background: #fff3cd; color: #856404; }
    .badge-info { background: #cfe2ff; color: #084298; }

    /* ========== INPUT ========== */
    #barcode {
        font-size: 1.25rem;
        padding: 12px 20px;
        border-radius: 12px;
        border: 2px solid #e9ecef;
        transition: var(--transition);
        text-align: center;
        letter-spacing: 1px;
        font-weight: 500;
        background: #f8f9fa;
    }
    #barcode:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        background: #fff;
    }

    /* ========== WAIVE CHECKBOX ========== */
    .waive-checkbox {
        margin-top: 12px;
        padding: 12px 16px;
        background: #f8f9fa;
        border-radius: 10px;
        border: 1px solid #e9ecef;
        text-align: left;
        transition: var(--transition);
    }
    .waive-checkbox:hover {
        background: #e9ecef;
    }
    .waive-checkbox .form-check-input {
        width: 18px;
        height: 18px;
        margin-top: 0.1rem;
        cursor: pointer;
        border-radius: 4px;
    }
    .waive-checkbox .form-check-input:checked {
        background-color: var(--success);
        border-color: var(--success);
    }
    .waive-checkbox .form-check-label {
        font-weight: 500;
        cursor: pointer;
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .container { padding: 0 12px; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .card-custom .card-body { padding: 1rem; }
        .return-result-card .result-body {
            flex-direction: column;
            text-align: center;
        }
        .return-result-card .member-photo {
            width: 60px;
            height: 60px;
        }
        .return-result-card .member-photo-placeholder {
            width: 60px;
            height: 60px;
            font-size: 1.8rem;
        }
        .return-result-card .book-cover-small {
            max-width: 40px;
            max-height: 55px;
        }
        #barcode {
            font-size: 1rem;
            padding: 10px 16px;
        }
    }

    @media (max-width: 576px) {
        .return-result-card { padding: 12px; }
        .return-result-card .result-details p { font-size: 0.8rem; }
        .waive-checkbox { padding: 10px 12px; }
        .waive-checkbox .form-check-label { font-size: 0.85rem; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .alert { display: none !important; }
        .return-result-card { border: 1px solid #28a745 !important; background: #fff !important; }
    }
    </style>
</head>
<body>

<div class="container py-3">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-arrow-left me-2" style="color: var(--primary-color);"></i> Return Book
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="issue.php" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
            <a href="renew.php" class="btn btn-info btn-sm text-white"><i class="fas fa-sync-alt"></i> Renew</a>
            <a href="holds.php" class="btn btn-purple btn-sm" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6); color: #fff; border: none;"><i class="fas fa-hand-paper"></i> Holds</a>
        </div>
    </div>

    <!-- ========== MAIN CARD ========== -->
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card-custom">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="fas fa-arrow-left me-2"></i> Return Book</h5>
                    <span class="badge bg-light text-dark ms-auto">Scan barcode</span>
                </div>
                <div class="card-body">
                    <?= $toast ?>
                    
                    <div class="text-center mb-3">
                        <div class="display-4 text-muted">
                            <i class="fas fa-barcode"></i>
                        </div>
                        <label class="form-label fw-bold fs-5 mb-2">Scan Book Barcode</label>
                        <input type="text" id="barcode" class="form-control form-control-lg" 
                               placeholder="Scan or enter barcode" autofocus autocomplete="off">
                        <div id="returnResult" class="mt-3"></div>
                    </div>

                    <?php if ($isAdmin): ?>
                    <div class="waive-checkbox">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="waiveFineCheckbox">
                            <label class="form-check-label" for="waiveFineCheckbox">
                                <i class="fas fa-hand-holding-usd text-success me-2"></i>
                                <strong>Waive overdue fine</strong> 
                                <span class="badge bg-primary ms-1">Admin</span>
                                <small class="text-muted d-block mt-1">Check this box to waive all overdue fines for this return.</small>
                            </label>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="text-center mt-4 no-print">
                        <a href="index.php" class="btn btn-secondary btn-lg px-5">
                            <i class="fas fa-times-circle"></i> Cancel
                        </a>
                    </div>

                    <!-- ========== QUICK STATS ========== -->
                    <hr class="my-4">
                    <div class="row g-2 text-center">
                        <div class="col-4">
                            <div class="p-2 bg-soft-success rounded shadow-hover" style="background: #d1e7dd; border-radius: 10px;">
                                <i class="fas fa-book-open text-success"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn()) ?></div>
                                <small class="text-muted">Active Loans</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-danger rounded shadow-hover" style="background: #f8d7da; border-radius: 10px;">
                                <i class="fas fa-exclamation-triangle text-danger"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn()) ?></div>
                                <small class="text-muted">Overdue</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-purple rounded shadow-hover" style="background: #e8d5f5; border-radius: 10px;">
                                <i class="fas fa-hand-paper" style="color: #6f42c1;"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'pending'")->fetchColumn()) ?></div>
                                <small class="text-muted">Pending Holds</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== RETURN LOGIC ==========
function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m);
}

let barcodeInput = document.getElementById('barcode');
let waiveCheckbox = document.getElementById('waiveFineCheckbox');
let isProcessing = false;
let lastBarcode = '';
const currencySymbol = '<?= addslashes($currencySymbol) ?>';

function processReturn() {
    let barcode = barcodeInput.value.trim();
    if (barcode.length < 3 || isProcessing || barcode === lastBarcode) return;
    
    isProcessing = true;
    lastBarcode = barcode;
    barcodeInput.disabled = true;
    if (waiveCheckbox) waiveCheckbox.disabled = true;
    
    let waive = waiveCheckbox ? (waiveCheckbox.checked ? 1 : 0) : 0;
    let url = 'return.php?ajax_process_return=1&barcode=' + encodeURIComponent(barcode) 
            + '&csrf_token=' + encodeURIComponent('<?= $_SESSION['csrf_token'] ?>')
            + '&waive_fine=' + waive;
    
    let resultDiv = document.getElementById('returnResult');
    resultDiv.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div><p class="mt-2 text-muted">Processing return...</p></div>';
    
    fetch(url, { method: 'GET', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Member photo
                let memberPhotoHtml = '';
                if (data.photo_base64) {
                    memberPhotoHtml = `<img src="${data.photo_base64}" class="member-photo" alt="Member Photo" loading="lazy">`;
                } else {
                    memberPhotoHtml = `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                }
                
                // Book cover
                let bookCoverHtml = '';
                if (data.cover_base64) {
                    bookCoverHtml = `<img src="${data.cover_base64}" class="book-cover-small" alt="Book Cover" loading="lazy">`;
                }
                
                let daysText = data.days_overdue > 0 ? 
                    `<span class="badge-result badge-danger"><i class="fas fa-clock"></i> Overdue by ${data.days_overdue} day(s)</span>` : 
                    `<span class="badge-result badge-success"><i class="fas fa-check-circle"></i> On time</span>`;
                
                let fineText = data.fine > 0 ? 
                    `<span class="badge-result badge-warning"><i class="fas fa-coins"></i> Fine: ${data.fine}</span>` : 
                    `<span class="badge-result badge-success"><i class="fas fa-check-circle"></i> No fine</span>`;
                
                let waivedText = data.waived ? 
                    `<span class="badge-result text-success"><i class="fas fa-hand-holding-usd"></i> 💸 Fine waived by admin.</span>` : '';
                
                resultDiv.innerHTML = `
                    <div class="return-result-card">
                        <div class="result-body">
                            ${memberPhotoHtml}
                            <div class="result-details">
                                <h5><i class="fas fa-check-circle"></i> ${escapeHtml(data.message)}</h5>
                                <p><strong>📖 Book:</strong> ${bookCoverHtml} ${escapeHtml(data.book_title)}</p>
                                <p><strong>👤 Member:</strong> ${escapeHtml(data.member_name)} (${escapeHtml(data.member_admno)})</p>
                                <p>${daysText} | ${fineText}</p>
                                ${waivedText}
                                <p><strong>💰 Total Fines:</strong> ${data.new_total_fine}</p>
                            </div>
                        </div>
                    </div>
                `;
                setTimeout(() => location.reload(), 2500);
            } else {
                resultDiv.innerHTML = `
                    <div class="alert alert-danger text-center py-3">
                        <i class="fas fa-exclamation-triangle fa-2x d-block mb-2"></i>
                        ${escapeHtml(data.error)}
                    </div>
                `;
                resetInputs();
            }
        })
        .catch(() => {
            resultDiv.innerHTML = `
                <div class="alert alert-danger text-center py-3">
                    <i class="fas fa-wifi fa-2x d-block mb-2"></i>
                    Network error. Please try again.
                </div>
            `;
            resetInputs();
        });
}

function resetInputs() {
    barcodeInput.disabled = false;
    barcodeInput.value = '';
    if (waiveCheckbox) waiveCheckbox.disabled = false;
    barcodeInput.focus();
    isProcessing = false;
    lastBarcode = '';
}

// ========== EVENT LISTENERS ==========
barcodeInput.addEventListener('input', function() {
    if (!isProcessing) processReturn();
});

barcodeInput.addEventListener('blur', function() {
    if (!isProcessing) processReturn();
});

barcodeInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        if (!isProcessing) processReturn();
    }
});

if (waiveCheckbox) {
    waiveCheckbox.addEventListener('change', function() {
        if (barcodeInput.value.trim().length >= 3 && !isProcessing) {
            // Re-process with waive setting
            processReturn();
        }
    });
}

window.addEventListener('load', function() {
    barcodeInput.focus();
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
    if (e.key === 'Enter' && document.activeElement === barcodeInput) {
        e.preventDefault();
        if (!isProcessing) processReturn();
    }
});
</script>

<?php renderFooter(); ?>