<?php
/**
 * Return Book - Complete Update
 * Features:
 * - Member photo display in result card
 * - Book cover display
 * - AJAX processing with visual feedback
 * - Hold queue notification
 * - Fine calculation with admin waive option
 * - Responsive layout with proper alignment
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$toast = '';
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== AJAX PROCESS RETURN ==========
if (isset($_GET['ajax_process_return']) || isset($_POST['ajax_process_return'])) {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode'] ?? $_POST['barcode'] ?? '');
    $csrf = $_GET['csrf_token'] ?? $_POST['csrf_token'] ?? '';
    $waiveFine = ($_GET['waive_fine'] ?? $_POST['waive_fine'] ?? 0) == 1 && $isAdmin;
    
    if ($csrf !== $_SESSION['csrf_token']) {
        echo json_encode(['success' => false, 'error' => 'Invalid security token.']);
        exit;
    }
    if (empty($barcode)) {
        echo json_encode(['success' => false, 'error' => 'Barcode is required.']);
        exit;
    }
    
    try {
        $db->beginTransaction();
        
        // Get circulation record with member and book details
        $stmt = $db->prepare("SELECT c.*, m.total_fines as current_fines, m.name as member_name, 
                                     m.admno, m.member_category, m.photo_path,
                                     b.title, b.author, b.item_category, b.barcode as book_barcode, 
                                     b.cover_path
                              FROM circulation c 
                              LEFT JOIN members m ON c.admno = m.admno 
                              LEFT JOIN books b ON c.barcode = b.barcode
                              WHERE c.barcode = ? AND c.return_date IS NULL");
        $stmt->execute([$barcode]);
        $record = $stmt->fetch();
        if (!$record) throw new Exception("No active issue found for this barcode.");
        
        // Fine calculation
        $rule = getLoanRule($record['member_category'], $record['item_category']);
        if ($rule) {
            $finePerDay = $rule['fine_per_day'];
            $gracePeriod = $rule['grace_period'];
        } else {
            $finePerDay = (float)($settings['fine_per_day'] ?? 2);
            $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
        }
        
        $dueDate = new DateTime($record['due_date']);
        $today = new DateTime();
        $fine = 0;
        if ($today > $dueDate) {
            $daysOverdue = $today->diff($dueDate)->days;
            $chargeableDays = max(0, $daysOverdue - $gracePeriod);
            $fine = $chargeableDays * $finePerDay;
            $maxFine = (float)($settings['max_fine_amount'] ?? 0);
            if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                $fine = max(0, $maxFine - $record['current_fines']);
            }
        }
        if ($waiveFine) $fine = 0;
        
        // Update circulation
        $db->prepare("UPDATE circulation SET return_date = ?, fine = ? WHERE id = ?")->execute([date('Y-m-d'), $fine, $record['id']]);
        
        // Update book availability
        if ($record['is_manual'] == 0) {
            $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
        }
        
        // Update member
        if ($fine > 0) {
            $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
        } else {
            $db->prepare("UPDATE members SET active_books = active_books - 1 WHERE admno = ?")->execute([$record['admno']]);
        }
        
        // ========== HOLD QUEUE CHECK ==========
        $holdStmt = $db->prepare("SELECT id, admno, member_name FROM book_holds WHERE book_barcode = ? AND status = 'pending' ORDER BY hold_date ASC LIMIT 1");
        $holdStmt->execute([$record['book_barcode']]);
        $nextHold = $holdStmt->fetch();
        if ($nextHold) {
            $db->prepare("UPDATE book_holds SET status = 'available', notified = 0 WHERE id = ?")->execute([$nextHold['id']]);
            $memberStmt = $db->prepare("SELECT email FROM members WHERE admno = ? AND status = 'active'");
            $memberStmt->execute([$nextHold['admno']]);
            $memberEmail = $memberStmt->fetchColumn();
            if ($memberEmail) {
                $bookTitle = $record['title'];
                $subject = "Hold Available: $bookTitle";
                $body = "Dear {$nextHold['member_name']},\n\nThe book \"$bookTitle\" is now available for pickup at the library. Please collect it by " . date('Y-m-d', strtotime('+7 days')) . ".\n\nThank you.";
                $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$memberEmail, $subject, $body]);
            }
        }
        
        $db->commit();
        
        // Prepare response with images
        $photo_base64 = getImageBase64($record['photo_path'] ?? '');
        $cover_base64 = getImageBase64($record['cover_path'] ?? '');
        
        $daysOverdue = max(0, (strtotime(date('Y-m-d')) - strtotime($record['due_date'])) / 86400);
        
        echo json_encode([
            'success' => true,
            'message' => 'Book returned successfully!',
            'fine' => formatCurrency($fine),
            'days_overdue' => ceil($daysOverdue),
            'member_name' => $record['member_name'],
            'member_admno' => $record['admno'],
            'book_title' => $record['title'],
            'photo_base64' => $photo_base64,
            'cover_base64' => $cover_base64,
            'new_total_fine' => formatCurrency($record['current_fines'] + $fine),
            'waived' => $waiveFine
        ]);
        
        logActivity($_SESSION['username'], 'BOOK_RETURN_AJAX', "Returned {$record['title']} to {$record['admno']} - Fine: $fine" . ($waiveFine ? ' (waived)' : ''));
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        
    } catch (Exception $e) {
        if ($db->inTransaction()) $db->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// ========== FALLBACK TRADITIONAL POST ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            $barcode = trim($_POST['barcode']);
            $waiveFine = isset($_POST['waive_fine']) && $isAdmin;
            
            $stmt = $db->prepare("SELECT c.*, m.total_fines as current_fines, m.member_category, 
                                         b.item_category, b.title, b.barcode as book_barcode, 
                                         m.photo_path, b.cover_path
                                  FROM circulation c 
                                  LEFT JOIN members m ON c.admno = m.admno 
                                  LEFT JOIN books b ON c.barcode = b.barcode
                                  WHERE c.barcode = ? AND c.return_date IS NULL");
            $stmt->execute([$barcode]);
            $record = $stmt->fetch();
            if (!$record) throw new Exception("No active issue found for this barcode.");
            
            // ... (same logic as AJAX)
            $rule = getLoanRule($record['member_category'], $record['item_category']);
            if ($rule) {
                $finePerDay = $rule['fine_per_day'];
                $gracePeriod = $rule['grace_period'];
            } else {
                $finePerDay = (float)($settings['fine_per_day'] ?? 2);
                $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
            }
            
            $dueDate = new DateTime($record['due_date']);
            $today = new DateTime();
            $fine = 0;
            if ($today > $dueDate) {
                $daysOverdue = $today->diff($dueDate)->days;
                $chargeableDays = max(0, $daysOverdue - $gracePeriod);
                $fine = $chargeableDays * $finePerDay;
                $maxFine = (float)($settings['max_fine_amount'] ?? 0);
                if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                    $fine = max(0, $maxFine - $record['current_fines']);
                }
            }
            if ($waiveFine) $fine = 0;
            
            $db->prepare("UPDATE circulation SET return_date = ?, fine = ? WHERE id = ?")->execute([date('Y-m-d'), $fine, $record['id']]);
            if ($record['is_manual'] == 0) {
                $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
            }
            if ($fine > 0) {
                $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
            } else {
                $db->prepare("UPDATE members SET active_books = active_books - 1 WHERE admno = ?")->execute([$record['admno']]);
            }
            
            // Hold queue check
            $holdStmt = $db->prepare("SELECT id, admno, member_name FROM book_holds WHERE book_barcode = ? AND status = 'pending' ORDER BY hold_date ASC LIMIT 1");
            $holdStmt->execute([$record['book_barcode']]);
            $nextHold = $holdStmt->fetch();
            if ($nextHold) {
                $db->prepare("UPDATE book_holds SET status = 'available', notified = 0 WHERE id = ?")->execute([$nextHold['id']]);
                $memberStmt = $db->prepare("SELECT email FROM members WHERE admno = ? AND status = 'active'");
                $memberStmt->execute([$nextHold['admno']]);
                $memberEmail = $memberStmt->fetchColumn();
                if ($memberEmail) {
                    $bookTitle = $record['title'];
                    $subject = "Hold Available: $bookTitle";
                    $body = "Dear {$nextHold['member_name']},\n\nThe book \"$bookTitle\" is now available for pickup at the library. Please collect it by " . date('Y-m-d', strtotime('+7 days')) . ".\n\nThank you.";
                    $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$memberEmail, $subject, $body]);
                }
            }
            
            $db->commit();
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book returned successfully!';
            if ($fine > 0) $toast .= "<br>💰 Fine: " . formatCurrency($fine);
            if ($waiveFine) $toast .= "<br>💸 Fine waived by admin.";
            $toast .= '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            logActivity($_SESSION['username'], 'BOOK_RETURN', "Returned {$record['title']} - Fine: $fine" . ($waiveFine ? ' (waived)' : ''));
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Return Book');
?>

<style>
/* ========== RESULT CARD STYLES ========== */
.return-result-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 16px;
    margin-top: 10px;
    border: 2px solid #28a745;
    transition: all 0.3s ease;
}
.return-result-card .member-photo {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 50%;
    border: 3px solid #28a745;
    background: #fff;
    flex-shrink: 0;
}
.return-result-card .member-photo-placeholder {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3px solid #28a745;
    flex-shrink: 0;
    color: #6c757d;
    font-size: 2.5rem;
}
.return-result-card .book-cover-small {
    max-width: 50px;
    max-height: 70px;
    object-fit: contain;
    border-radius: 4px;
    border: 1px solid #dee2e6;
    background: #fff;
    padding: 2px;
}
.return-result-card .result-body {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}
.return-result-card .result-details {
    flex: 1;
    min-width: 200px;
}
.return-result-card .result-details p {
    margin-bottom: 3px;
    font-size: 0.9rem;
}
.return-result-card .result-badge {
    display: inline-block;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}
.return-result-card .badge-success { background: #d4edda; color: #155724; }
.return-result-card .badge-danger { background: #f8d7da; color: #721c24; }
.return-result-card .badge-warning { background: #fff3cd; color: #856404; }

.waive-checkbox {
    margin-top: 10px;
    text-align: left;
}

@media (max-width: 576px) {
    .return-result-card .result-body {
        flex-direction: column;
        text-align: center;
    }
    .return-result-card .member-photo {
        width: 60px;
        height: 60px;
    }
    .return-result-card .member-photo-placeholder {
        width: 60px;
        height: 60px;
        font-size: 1.8rem;
    }
    .return-result-card .book-cover-small {
        max-width: 40px;
        max-height: 55px;
    }
}
</style>

<div class="container">
    <div class="row justify-content-center mt-4">
        <div class="col-md-8">
            <div class="d-flex justify-content-between mb-3 flex-wrap gap-2">
                <div class="d-flex flex-wrap gap-2">
                    <a href="../index.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-home"></i> Home</a>
                    <a href="issue.php" class="btn btn-outline-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
                    <a href="renew.php" class="btn btn-outline-warning btn-sm"><i class="fas fa-sync-alt"></i> Renew</a>
                </div>
                <div><span class="badge bg-warning fs-6">Return Book</span></div>
            </div>
            <div class="card shadow rounded-4">
                <div class="card-header bg-warning text-white rounded-top-4">
                    <h4><i class="fas fa-arrow-left"></i> Return Book</h4>
                </div>
                <div class="card-body text-center">
                    <?= $toast ?>
                    <div class="mb-4">
                        <label class="form-label h5">Scan Book Barcode</label>
                        <input type="text" id="barcode" class="form-control form-control-lg text-center" 
                               placeholder="Scan or enter barcode" autofocus autocomplete="off">
                        <div id="returnResult" class="mt-3"></div>
                        <?php if ($isAdmin): ?>
                        <div class="form-check waive-checkbox">
                            <input type="checkbox" class="form-check-input" id="waiveFineCheckbox">
                            <label class="form-check-label" for="waiveFineCheckbox">
                                <strong>Waive overdue fine</strong> (Admin only)
                            </label>
                        </div>
                        <?php endif; ?>
                    </div>
                    <a href="index.php" class="btn btn-secondary btn-lg px-5">Cancel</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

let barcodeInput = document.getElementById('barcode');
let waiveCheckbox = document.getElementById('waiveFineCheckbox');
let isProcessing = false;
let lastBarcode = '';
const currencySymbol = '<?= addslashes($settings['currency_symbol'] ?? '$') ?>';
const currencyDecimalPlaces = <?= (int)($settings['currency_decimal_places'] ?? 2) ?>;

function processReturn() {
    let barcode = barcodeInput.value.trim();
    if(barcode.length < 3 || isProcessing || barcode === lastBarcode) return;
    
    isProcessing = true;
    lastBarcode = barcode;
    barcodeInput.disabled = true;
    if (waiveCheckbox) waiveCheckbox.disabled = true;
    
    let waive = waiveCheckbox ? (waiveCheckbox.checked ? 1 : 0) : 0;
    let url = 'return.php?ajax_process_return=1&barcode=' + encodeURIComponent(barcode) 
            + '&csrf_token=' + encodeURIComponent('<?= $_SESSION['csrf_token'] ?>')
            + '&waive_fine=' + waive;
    
    fetch(url, { method: 'GET', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.json())
        .then(data => {
            let resultDiv = document.getElementById('returnResult');
            if (data.success) {
                // Member photo
                let memberPhotoHtml = '';
                if (data.photo_base64) {
                    memberPhotoHtml = `<img src="${data.photo_base64}" class="member-photo" alt="Member Photo">`;
                } else {
                    memberPhotoHtml = `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                }
                
                // Book cover
                let bookCoverHtml = '';
                if (data.cover_base64) {
                    bookCoverHtml = `<img src="${data.cover_base64}" class="book-cover-small" alt="Book Cover">`;
                }
                
                let daysText = data.days_overdue > 0 ? 
                    `<span class="badge-result badge-danger">⚠ Overdue by ${data.days_overdue} day(s)</span>` : 
                    `<span class="badge-result badge-success">✅ On time</span>`;
                
                let fineText = data.fine > 0 ? 
                    `<span class="badge-result badge-warning">💰 Fine: ${data.fine}</span>` : 
                    `<span class="badge-result badge-success">No fine</span>`;
                
                let waivedText = data.waived ? 
                    `<span class="badge-result text-success">💸 Fine waived by admin.</span>` : '';
                
                resultDiv.innerHTML = `
                    <div class="return-result-card">
                        <div class="result-body">
                            ${memberPhotoHtml}
                            <div class="result-details">
                                <h5 class="text-success mb-1"><i class="fas fa-check-circle"></i> ${escapeHtml(data.message)}</h5>
                                <p><strong>📖 Book:</strong> ${bookCoverHtml} ${escapeHtml(data.book_title)}</p>
                                <p><strong>👤 Member:</strong> ${escapeHtml(data.member_name)} (${escapeHtml(data.member_admno)})</p>
                                <p>${daysText} | ${fineText}</p>
                                ${waivedText}
                                <p><strong>💰 Total Fines:</strong> ${data.new_total_fine}</p>
                            </div>
                        </div>
                    </div>
                `;
                setTimeout(() => location.reload(), 2000);
            } else {
                resultDiv.innerHTML = `
                    <div class="alert alert-danger text-center">
                        <i class="fas fa-exclamation-triangle"></i> ${escapeHtml(data.error)}
                    </div>
                `;
                barcodeInput.disabled = false;
                barcodeInput.value = '';
                if (waiveCheckbox) waiveCheckbox.disabled = false;
                barcodeInput.focus();
                isProcessing = false;
                lastBarcode = '';
            }
        })
        .catch(() => {
            resultDiv.innerHTML = '<div class="alert alert-danger text-center"><i class="fas fa-exclamation-triangle"></i> Network error. Please try again.</div>';
            barcodeInput.disabled = false;
            barcodeInput.value = '';
            if (waiveCheckbox) waiveCheckbox.disabled = false;
            barcodeInput.focus();
            isProcessing = false;
            lastBarcode = '';
        });
}

barcodeInput.addEventListener('input', function() { if(!isProcessing) processReturn(); });
barcodeInput.addEventListener('blur', function() { if(!isProcessing) processReturn(); });
barcodeInput.addEventListener('keypress', function(e) {
    if(e.key === 'Enter') { e.preventDefault(); if(!isProcessing) processReturn(); }
});
if (waiveCheckbox) waiveCheckbox.addEventListener('change', function() { 
    if(barcodeInput.value.trim().length >= 3 && !isProcessing) processReturn(); 
});
window.addEventListener('load', function() { barcodeInput.focus(); });
</script>

<?php renderFooter(); ?>