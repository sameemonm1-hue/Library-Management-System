<?php
/**
 * Circulation Dashboard - v3.3 (Self-Contained)
 * - All logic and AJAX endpoints in one file.
 * - Auto-refresh every 30 seconds.
 * - Properly ordered recent transactions (newest first).
 * - No external includes except config and functions.
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireLogin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$db = getDB();
$settings = getSettings();
$currencySymbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');
$institution = getInstitution();
$maxBooksPerMember = (int)($settings['max_books'] ?? 5);
$finePerDay = (float)($settings['fine_per_day'] ?? 2);
$maxRenewals = (int)($settings['max_renewals'] ?? 2);

// ========== HELPER: Get image base64 ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== AJAX HANDLERS ==========
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    $action = $_GET['ajax'];

    if ($action === 'stats') {
        $totalIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
        $totalOverdue = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn();
        $totalMembers = (int)$db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
        $totalBooks = (int)$db->query("SELECT SUM(quantity) FROM books")->fetchColumn();
        $totalAvailable = (int)$db->query("SELECT SUM(available) FROM books")->fetchColumn();
        $onTimeRate = $totalIssued > 0 ? round(($totalIssued - $totalOverdue) / $totalIssued * 100) : 100;
        echo json_encode([
            'totalIssued' => $totalIssued,
            'totalOverdue' => $totalOverdue,
            'totalMembers' => $totalMembers,
            'totalBooks' => $totalBooks,
            'totalAvailable' => $totalAvailable,
            'onTimeRate' => $onTimeRate
        ]);
        exit;
    }

    if ($action === 'today') {
        $todayIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(issue_date) = date('now')")->fetchColumn();
        $todayReturned = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(return_date) = date('now')")->fetchColumn();
        $todayRenewed = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE renew_count > 0 AND date(issue_date) = date('now')")->fetchColumn();
        $weekMembers = (int)$db->query("SELECT COUNT(*) FROM members WHERE created_at >= datetime('now', '-7 days')")->fetchColumn();
        $weekIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE issue_date >= date('now', '-7 days')")->fetchColumn();
        echo json_encode([
            'todayIssued' => $todayIssued,
            'todayReturned' => $todayReturned,
            'todayRenewed' => $todayRenewed,
            'weekMembers' => $weekMembers,
            'weekIssued' => $weekIssued
        ]);
        exit;
    }

    if ($action === 'transactions') {
        $recent = $db->query("
            SELECT c.*, 
                   m.photo_path as member_photo_path,
                   m.member_category,
                   b.cover_path as book_cover_path,
                   CASE WHEN c.return_date IS NOT NULL THEN 'returned'
                        WHEN c.due_date < date('now') THEN 'overdue'
                        ELSE 'issued' END as status_type
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno
            LEFT JOIN books b ON c.barcode = b.barcode
            ORDER BY c.issue_date DESC, c.id DESC
            LIMIT 100
        ")->fetchAll();

        $seen = [];
        $unique = [];
        foreach ($recent as $r) {
            if (!in_array($r['id'], $seen)) {
                $seen[] = $r['id'];
                $r['member_photo_base64'] = getImageBase64($r['member_photo_path'] ?? '');
                $r['book_cover_base64'] = getImageBase64($r['book_cover_path'] ?? '');
                $unique[] = $r;
            }
        }
        echo json_encode(['transactions' => array_slice($unique, 0, 25)]);
        exit;
    }

    if ($action === 'top_members') {
        $top = $db->query("
            SELECT m.id, m.admno, m.name, m.photo_path, COUNT(c.id) as issue_count
            FROM circulation c
            JOIN members m ON c.admno = m.admno
            WHERE c.return_date IS NULL
            GROUP BY m.id
            ORDER BY issue_count DESC
            LIMIT 5
        ")->fetchAll();
        foreach ($top as &$m) {
            $m['photo_base64'] = getImageBase64($m['photo_path'] ?? '');
        }
        echo json_encode($top);
        exit;
    }

    if ($action === 'top_books') {
        $top = $db->query("
            SELECT b.title, b.cover_path, COUNT(c.id) as count, SUM(b.quantity) as total_copies
            FROM circulation c 
            JOIN books b ON c.barcode = b.barcode 
            GROUP BY b.title 
            ORDER BY count DESC 
            LIMIT 10
        ")->fetchAll();
        foreach ($top as &$b) {
            $b['cover_base64'] = getImageBase64($b['cover_path'] ?? '');
        }
        echo json_encode($top);
        exit;
    }

    echo json_encode(['error' => 'Invalid action']);
    exit;
}

// ========== INITIAL DATA ==========
$totalIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn();
$totalOverdue = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn();
$totalMembers = (int)$db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
$totalBooks = (int)$db->query("SELECT SUM(quantity) FROM books")->fetchColumn();
$totalAvailable = (int)$db->query("SELECT SUM(available) FROM books")->fetchColumn();
$onTimeRate = $totalIssued > 0 ? round(($totalIssued - $totalOverdue) / $totalIssued * 100) : 100;

$todayIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(issue_date) = date('now')")->fetchColumn();
$todayReturned = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(return_date) = date('now')")->fetchColumn();
$todayRenewed = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE renew_count > 0 AND date(issue_date) = date('now')")->fetchColumn();
$weekMembers = (int)$db->query("SELECT COUNT(*) FROM members WHERE created_at >= datetime('now', '-7 days')")->fetchColumn();
$weekIssued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE issue_date >= date('now', '-7 days')")->fetchColumn();

// Recent transactions (deduped)
$recentRaw = $db->query("
    SELECT c.*, 
           m.photo_path as member_photo_path,
           m.member_category,
           b.cover_path as book_cover_path,
           CASE WHEN c.return_date IS NOT NULL THEN 'returned'
                WHEN c.due_date < date('now') THEN 'overdue'
                ELSE 'issued' END as status_type
    FROM circulation c 
    LEFT JOIN members m ON c.admno = m.admno
    LEFT JOIN books b ON c.barcode = b.barcode
    ORDER BY c.issue_date DESC, c.id DESC
    LIMIT 100
")->fetchAll();

$seen = [];
$uniqueTransactions = [];
foreach ($recentRaw as $r) {
    if (!in_array($r['id'], $seen)) {
        $seen[] = $r['id'];
        $r['member_photo_base64'] = getImageBase64($r['member_photo_path'] ?? '');
        $r['book_cover_base64'] = getImageBase64($r['book_cover_path'] ?? '');
        $uniqueTransactions[] = $r;
    }
}
$recentTransactions = array_slice($uniqueTransactions, 0, 25);

// Top members
$topMembers = $db->query("
    SELECT m.id, m.admno, m.name, m.photo_path, COUNT(c.id) as issue_count
    FROM circulation c
    JOIN members m ON c.admno = m.admno
    WHERE c.return_date IS NULL
    GROUP BY m.id
    ORDER BY issue_count DESC
    LIMIT 5
")->fetchAll();
foreach ($topMembers as &$m) {
    $m['photo_base64'] = getImageBase64($m['photo_path'] ?? '');
}

// Top books
$topBooks = $db->query("
    SELECT b.title, b.cover_path, COUNT(c.id) as count, SUM(b.quantity) as total_copies
    FROM circulation c 
    JOIN books b ON c.barcode = b.barcode 
    GROUP BY b.title 
    ORDER BY count DESC 
    LIMIT 10
")->fetchAll();
foreach ($topBooks as &$b) {
    $b['cover_base64'] = getImageBase64($b['cover_path'] ?? '');
}

// Weekly activity for chart
$dailyActivity = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $issued = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(issue_date) = '$date'")->fetchColumn();
    $returned = (int)$db->query("SELECT COUNT(*) FROM circulation WHERE date(return_date) = '$date'")->fetchColumn();
    $dailyActivity[] = [
        'date' => date('D', strtotime($date)),
        'issued' => $issued,
        'returned' => $returned
    ];
}

// ========== PAGE HEADER ==========
renderHeader('Circulation Dashboard');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Circulation Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
    :root {
        --primary: #1e3c72;
        --primary-light: #2a5298;
        --primary-gradient: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== STAT CARDS ========== */
    .stat-card {
        border: none;
        border-radius: var(--border-radius);
        padding: 1.25rem 1.5rem;
        transition: var(--transition);
        cursor: pointer;
        background: #fff;
        box-shadow: var(--shadow-sm);
        position: relative;
        overflow: hidden;
        min-height: 110px;
        border-left: 5px solid transparent;
    }
    .stat-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: rgba(255,255,255,0.1);
        pointer-events: none;
    }
    .stat-card.primary { border-left-color: var(--primary); }
    .stat-card.success { border-left-color: var(--success); }
    .stat-card.danger { border-left-color: var(--danger); }
    .stat-card.warning { border-left-color: var(--warning); }
    .stat-card.info { border-left-color: var(--info); }
    .stat-card.purple { border-left-color: #6f42c1; }

    .stat-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--shadow-lg);
    }
    .stat-card .stat-icon {
        font-size: 2.2rem;
        opacity: 0.8;
    }
    .stat-card .stat-value {
        font-size: 1.9rem;
        font-weight: 700;
        line-height: 1.2;
        margin-bottom: 0.1rem;
    }
    .stat-card .stat-label {
        font-size: 0.85rem;
        color: #6c757d;
        font-weight: 500;
        margin: 0;
    }

    /* ========== PHOTO / COVER ========== */
    .member-photo-small {
        width: 44px;
        height: 44px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #e9ecef;
        background: #f8f9fa;
        transition: var(--transition);
        flex-shrink: 0;
    }
    .member-photo-small:hover {
        transform: scale(1.12);
        border-color: var(--primary);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .member-photo-placeholder {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 1.2rem;
        border: 2px solid #e9ecef;
        flex-shrink: 0;
    }

    .book-cover-small {
        width: 40px;
        height: 54px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #e9ecef;
        background: #f8f9fa;
        transition: var(--transition);
        flex-shrink: 0;
    }
    .book-cover-small:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 10;
        position: relative;
    }
    .book-cover-placeholder {
        width: 40px;
        height: 54px;
        border-radius: 6px;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.9rem;
        border: 1px solid #e9ecef;
        flex-shrink: 0;
    }

    /* ========== MEMBER SEARCH RESULT ========== */
    .member-result-card {
        background: #fff;
        border-radius: var(--border-radius);
        padding: 18px;
        border-left: 4px solid var(--success);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
    }
    .member-result-card:hover {
        box-shadow: var(--shadow-md);
    }
    .member-result-card .member-photo {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid var(--success);
        background: #fff;
        flex-shrink: 0;
    }
    .member-result-card .member-photo-placeholder {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid var(--success);
        color: #6c757d;
        font-size: 2.5rem;
        flex-shrink: 0;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: transparent;
        border-bottom: 1px solid #e9ecef;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .card-custom .card-body {
        padding: 1.25rem;
    }

    /* ========== BUTTONS ========== */
    .btn-group-custom .btn {
        border-radius: 10px !important;
        padding: 0.45rem 1rem;
        font-weight: 500;
        transition: var(--transition);
        font-size: 0.9rem;
    }
    .btn-group-custom .btn:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-sm);
    }

    /* ========== TABLE ========== */
    .table-transactions {
        font-size: 0.9rem;
    }
    .table-transactions th {
        font-weight: 600;
        color: #495057;
        border-bottom: 2px solid #e9ecef;
        white-space: nowrap;
        background: #f8f9fa;
        position: sticky;
        top: 0;
        z-index: 5;
    }
    .table-transactions td {
        vertical-align: middle;
        padding: 0.6rem 0.75rem;
    }
    .table-transactions tr:hover {
        background-color: #f8f9fa;
    }
    .scrollable-table {
        max-height: 580px;
        overflow-y: auto;
    }
    .scrollable-table::-webkit-scrollbar {
        width: 6px;
    }
    .scrollable-table::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    .scrollable-table::-webkit-scrollbar-thumb {
        background: #c1c7cd;
        border-radius: 10px;
    }

    /* ========== BADGES ========== */
    .badge-status {
        font-size: 0.7rem;
        padding: 0.35rem 0.75rem;
        border-radius: 30px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    .animated-badge {
        animation: pulse-badge 2s infinite;
    }
    @keyframes pulse-badge {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    /* ========== LOADING ========== */
    .loading-spinner {
        display: inline-block;
        width: 2rem;
        height: 2rem;
        border: 3px solid rgba(0,0,0,0.1);
        border-radius: 50%;
        border-top-color: var(--primary);
        animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 992px) {
        .stat-card .stat-value { font-size: 1.5rem; }
        .stat-card .stat-icon { font-size: 1.8rem; }
    }
    @media (max-width: 768px) {
        .member-photo-small { width: 36px; height: 36px; }
        .book-cover-small { width: 32px; height: 44px; }
        .member-result-card .member-photo { width: 60px; height: 60px; }
        .member-result-card .member-photo-placeholder { width: 60px; height: 60px; font-size: 1.8rem; }
        .stat-card { padding: 1rem; min-height: 90px; }
        .stat-card .stat-value { font-size: 1.3rem; }
        .stat-card .stat-label { font-size: 0.75rem; }
        .btn-group-custom .btn { font-size: 0.8rem; padding: 0.3rem 0.7rem; }
        .table-transactions { font-size: 0.8rem; }
        .table-transactions td, .table-transactions th { padding: 0.4rem 0.5rem; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .container-fluid { padding: 0 12px; }
    }
    @media (max-width: 576px) {
        .modal-dialog { margin: 10px; }
        .modal-content { border-radius: 12px; }
        .stat-card .stat-value { font-size: 1.1rem; }
        .stat-card { padding: 0.8rem; min-height: 70px; }
        .btn-group-custom .btn { font-size: 0.7rem; padding: 0.2rem 0.5rem; }
    }

    /* ========== UTILITY ========== */
    .text-ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 130px;
        display: inline-block;
        vertical-align: middle;
    }
    .bg-soft-primary { background: rgba(30, 60, 114, 0.08); }
    .bg-soft-success { background: rgba(40, 167, 69, 0.08); }
    .bg-soft-danger { background: rgba(220, 53, 69, 0.08); }
    .bg-soft-warning { background: rgba(255, 193, 7, 0.08); }
    .bg-soft-info { background: rgba(23, 162, 184, 0.08); }
    .shadow-hover {
        transition: var(--transition);
    }
    .shadow-hover:hover {
        box-shadow: var(--shadow-md) !important;
    }
    .btn-gradient-primary {
        background: var(--primary-gradient);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(30, 60, 114, 0.4);
        color: #fff;
    }

    /* ========== TOP BOOKS LIST ========== */
    .top-book-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 12px;
        border-radius: 10px;
        background: #f8f9fa;
        transition: var(--transition);
        border-left: 3px solid transparent;
    }
    .top-book-item:hover {
        background: #e9ecef;
        transform: translateX(4px);
    }
    .top-book-item .rank-badge {
        font-weight: 700;
        color: #6c757d;
        min-width: 28px;
        text-align: center;
    }
    .top-book-item .rank-badge.gold { color: #ffc107; }
    .top-book-item .rank-badge.silver { color: #adb5bd; }
    .top-book-item .rank-badge.bronze { color: #cd7f32; }
    .top-book-item .book-info {
        flex: 1;
        overflow: hidden;
    }
    .top-book-item .book-info .title {
        font-weight: 600;
        font-size: 0.95rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .top-book-item .book-info .meta {
        font-size: 0.8rem;
        color: #6c757d;
    }
    .top-book-item .issue-count {
        background: var(--primary);
        color: #fff;
        padding: 2px 12px;
        border-radius: 30px;
        font-weight: 600;
        font-size: 0.8rem;
        white-space: nowrap;
    }
    </style>
</head>
<body>

<div class="container-fluid px-3 px-md-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary);">
                <i class="fas fa-exchange-alt text-primary me-2"></i> Circulation Dashboard
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
                <span class="ms-2 text-success" id="liveIndicator"><i class="fas fa-circle"></i> Live</span>
            </p>
        </div>
        <div class="btn-group-custom" role="group">
            <a href="../index.php" class="btn btn-primary"><i class="fas fa-home"></i> Home</a>
            <button onclick="showIssueModal()" class="btn btn-success"><i class="fas fa-arrow-right"></i> Issue</button>
            <button onclick="showReturnModal()" class="btn btn-warning"><i class="fas fa-arrow-left"></i> Return</button>
            <button onclick="showRenewModal()" class="btn btn-info text-white"><i class="fas fa-sync-alt"></i> Renew</button>
            <a href="history.php" class="btn btn-secondary"><i class="fas fa-history"></i> History</a>
            <a href="overdue.php" class="btn btn-danger"><i class="fas fa-clock"></i> Overdue</a>
            <button onclick="window.print()" class="btn btn-outline-primary" title="Print Dashboard"><i class="fas fa-print"></i></button>
            <button onclick="refreshDashboard()" class="btn btn-outline-secondary" title="Refresh Now"><i class="fas fa-sync-alt"></i></button>
        </div>
    </div>

    <!-- ========== STATISTICS CARDS ========== -->
    <div id="statsContainer" class="row g-3 mb-4">
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card primary" onclick="window.location.href='history.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-book-reader me-1"></i> Issued</p>
                        <h3 class="stat-value" id="statIssued"><?= number_format($totalIssued) ?></h3>
                    </div>
                    <div class="stat-icon text-primary"><i class="fas fa-book-open"></i></div>
                </div>
                <small class="text-muted">Active loans</small>
            </div>
        </div>
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card danger" onclick="window.location.href='overdue.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-exclamation-triangle me-1"></i> Overdue</p>
                        <h3 class="stat-value text-danger" id="statOverdue"><?= number_format($totalOverdue) ?></h3>
                    </div>
                    <div class="stat-icon text-danger"><i class="fas fa-clock"></i></div>
                </div>
                <small class="text-danger">Needs attention</small>
            </div>
        </div>
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card success" onclick="window.location.href='../admin/members.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-users me-1"></i> Members</p>
                        <h3 class="stat-value" id="statMembers"><?= number_format($totalMembers) ?></h3>
                    </div>
                    <div class="stat-icon text-success"><i class="fas fa-user-graduate"></i></div>
                </div>
                <small class="text-muted">Active members</small>
            </div>
        </div>
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card info" onclick="window.location.href='../admin/books.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-book me-1"></i> Books</p>
                        <h3 class="stat-value" id="statBooks"><?= number_format($totalBooks) ?></h3>
                    </div>
                    <div class="stat-icon text-info"><i class="fas fa-book"></i></div>
                </div>
                <small class="text-muted">Total collection</small>
            </div>
        </div>
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card warning" onclick="window.location.href='../admin/books.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-check-circle me-1"></i> Available</p>
                        <h3 class="stat-value" id="statAvailable"><?= number_format($totalAvailable) ?></h3>
                    </div>
                    <div class="stat-icon text-warning"><i class="fas fa-check-circle"></i></div>
                </div>
                <small class="text-muted">Available copies</small>
            </div>
        </div>
        <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="stat-card purple" onclick="window.location.href='history.php'">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-percent me-1"></i> On-Time</p>
                        <h3 class="stat-value" style="color:#6f42c1;" id="statOnTime"><?= $onTimeRate ?>%</h3>
                    </div>
                    <div class="stat-icon" style="color:#6f42c1;"><i class="fas fa-chart-line"></i></div>
                </div>
                <small class="text-muted">On-time rate</small>
            </div>
        </div>
    </div>

    <!-- ========== SECONDARY STATS ========== -->
    <div class="row g-3 mb-4">
        <div class="col-lg-8">
            <div class="card-custom">
                <div class="card-header">
                    <span><i class="fas fa-chart-area text-primary me-2"></i> Weekly Activity</span>
                </div>
                <div class="card-body p-3">
                    <canvas id="weeklyChart" style="height: 180px; width: 100%;"></canvas>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card-custom h-100">
                <div class="card-header">
                    <span><i class="fas fa-bolt text-warning me-2"></i> Today's Activity</span>
                </div>
                <div class="card-body p-3" id="todayActivity">
                    <div class="row g-2 text-center">
                        <div class="col-4">
                            <div class="p-2 bg-soft-success rounded shadow-hover">
                                <i class="fas fa-arrow-right fa-2x text-success"></i>
                                <h4 class="mb-0 mt-1" id="todayIssued"><?= number_format($todayIssued) ?></h4>
                                <small class="text-muted">Issued</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-warning rounded shadow-hover">
                                <i class="fas fa-arrow-left fa-2x text-warning"></i>
                                <h4 class="mb-0 mt-1" id="todayReturned"><?= number_format($todayReturned) ?></h4>
                                <small class="text-muted">Returned</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-info rounded shadow-hover">
                                <i class="fas fa-sync-alt fa-2x text-info"></i>
                                <h4 class="mb-0 mt-1" id="todayRenewed"><?= number_format($todayRenewed) ?></h4>
                                <small class="text-muted">Renewed</small>
                            </div>
                        </div>
                    </div>
                    <div class="row g-2 mt-2 text-center">
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded shadow-hover">
                                <i class="fas fa-user-plus text-primary"></i>
                                <span class="fw-bold" id="weekMembers"><?= number_format($weekMembers) ?></span>
                                <small class="d-block text-muted">New Members (7d)</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded shadow-hover">
                                <i class="fas fa-book text-primary"></i>
                                <span class="fw-bold" id="weekIssued"><?= number_format($weekIssued) ?></span>
                                <small class="d-block text-muted">Issues (7d)</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== MAIN ROW ========== -->
    <div class="row g-4">
        <!-- LEFT COLUMN -->
        <div class="col-lg-4">
            <!-- Quick Actions -->
            <div class="card-custom mb-4">
                <div class="card-header bg-primary text-white">
                    <span><i class="fas fa-bolt me-2"></i> Quick Actions</span>
                </div>
                <div class="card-body p-3">
                    <div class="d-grid gap-2">
                        <button class="btn btn-success btn-gradient-primary" onclick="showIssueModal()">
                            <i class="fas fa-arrow-right"></i> Issue Book
                        </button>
                        <button class="btn btn-warning" onclick="showReturnModal()">
                            <i class="fas fa-arrow-left"></i> Return Book
                        </button>
                        <button class="btn btn-info text-white" onclick="showRenewModal()">
                            <i class="fas fa-sync-alt"></i> Renew Book
                        </button>
                        <hr>
                        <button class="btn btn-outline-secondary" onclick="window.location.href='history.php'">
                            <i class="fas fa-history"></i> Transaction History
                        </button>
                        <button class="btn btn-outline-danger" onclick="window.location.href='overdue.php'">
                            <i class="fas fa-clock"></i> Overdue Books
                        </button>
                        <button class="btn btn-outline-primary" onclick="window.location.href='../reports/?type=circulation'">
                            <i class="fas fa-chart-bar"></i> Circulation Report
                        </button>
                    </div>
                </div>
            </div>

            <!-- Search Member -->
            <div class="card-custom mb-4">
                <div class="card-header bg-info text-white">
                    <span><i class="fas fa-search me-2"></i> Find Member</span>
                </div>
                <div class="card-body p-3">
                    <div class="input-group">
                        <input type="text" id="memberSearch" class="form-control" 
                               placeholder="Adm/Mem Number or Name" 
                               onkeyup="if(event.key==='Enter') searchMember();">
                        <button class="btn btn-info text-white" onclick="searchMember()">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    <div id="memberResult" class="mt-3" style="display: none;"></div>
                    <div id="memberSuggestions" class="mt-2" style="display: none;"></div>
                </div>
            </div>

            <!-- Top Members -->
            <div class="card-custom mb-4">
                <div class="card-header">
                    <span><i class="fas fa-trophy text-warning me-2"></i> Top Active Members</span>
                </div>
                <div class="card-body p-2" id="topMembersContainer">
                    <?php if (empty($topMembers)): ?>
                        <p class="text-muted text-center py-3 small">No active members with loans</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($topMembers as $member): ?>
                            <li class="list-group-item d-flex align-items-center gap-3 px-2 py-2 border-0 border-bottom">
                                <?php if ($member['photo_base64']): ?>
                                    <img src="<?= $member['photo_base64'] ?>" class="member-photo-small" alt="Photo">
                                <?php else: ?>
                                    <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                <?php endif; ?>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold small"><?= htmlspecialchars($member['name'] ?: 'Unknown') ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($member['admno']) ?></small>
                                </div>
                                <span class="badge bg-primary rounded-pill"><?= $member['issue_count'] ?> books</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN: Recent Transactions -->
        <div class="col-lg-8">
            <div class="card-custom">
                <div class="card-header bg-success text-white">
                    <span><i class="fas fa-history me-2"></i> Recent Transactions</span>
                    <div>
                        <span class="badge bg-light text-dark me-2" id="transactionCount"><?= count($recentTransactions) ?></span>
                        <a href="history.php" class="btn btn-sm btn-light">
                            <i class="fas fa-external-link-alt"></i> View All
                        </a>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="scrollable-table" id="transactionsTable">
                        <?php if (empty($recentTransactions)): ?>
                            <div class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-3x d-block mb-2"></i>
                                No transactions yet
                            </div>
                        <?php else: ?>
                            <table class="table table-transactions mb-0">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Member</th>
                                        <th>Book</th>
                                        <th>Due</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($recentTransactions as $trans): 
                                    $statusClass = $trans['status_type'] === 'overdue' ? 'table-danger' : 
                                                   ($trans['status_type'] === 'returned' ? 'table-success' : '');
                                    $statusBadge = $trans['status_type'] === 'returned' ? 'bg-success' : 
                                                   ($trans['status_type'] === 'overdue' ? 'bg-danger animated-badge' : 'bg-primary');
                                    $statusText = $trans['status_type'] === 'returned' ? 'Returned' : 
                                                  ($trans['status_type'] === 'overdue' ? 'Overdue' : 'Issued');
                                ?>
                                <tr class="<?= $statusClass ?>">
                                    <td><?= date('d/m/Y', strtotime($trans['issue_date'])) ?></td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if ($trans['member_photo_base64']): ?>
                                                <img src="<?= $trans['member_photo_base64'] ?>" class="member-photo-small" alt="Member">
                                            <?php else: ?>
                                                <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                            <?php endif; ?>
                                            <div>
                                                <div class="fw-semibold small"><?= htmlspecialchars($trans['member_name'] ?: 'Unknown') ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($trans['admno']) ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <?php if ($trans['book_cover_base64']): ?>
                                                <img src="<?= $trans['book_cover_base64'] ?>" class="book-cover-small" alt="Book">
                                            <?php else: ?>
                                                <div class="book-cover-placeholder"><i class="fas fa-book"></i></div>
                                            <?php endif; ?>
                                            <div>
                                                <span class="text-ellipsis" title="<?= htmlspecialchars($trans['title']) ?>">
                                                    <?= htmlspecialchars(substr($trans['title'], 0, 30)) ?>
                                                </span>
                                                <?php if (strlen($trans['title']) > 30): ?>…<?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?= date('d/m/Y', strtotime($trans['due_date'])) ?>
                                        <?php if ($trans['status_type'] === 'overdue'): ?>
                                            <br><small class="text-danger fw-bold">Overdue!</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-status <?= $statusBadge ?>">
                                            <?= $statusText ?>
                                        </span>
                                        <?php if ($trans['status_type'] === 'issued' && $trans['member_category']): ?>
                                            <br><small class="text-muted"><?= htmlspecialchars($trans['member_category']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!$trans['return_date']): ?>
                                            <div class="d-flex flex-wrap gap-1">
                                                <form method="post" action="return.php" style="display:inline">
                                                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                                    <input type="hidden" name="barcode" value="<?= htmlspecialchars($trans['barcode']) ?>">
                                                    <button type="submit" name="return" class="btn btn-sm btn-warning" title="Return">
                                                        <i class="fas fa-arrow-left"></i>
                                                    </button>
                                                </form>
                                                <a href="renew.php?barcode=<?= urlencode($trans['barcode']) ?>" 
                                                   class="btn btn-sm btn-info text-white" title="Renew">
                                                    <i class="fas fa-sync-alt"></i>
                                                </a>
                                                <button onclick="viewTransaction(<?= $trans['id'] ?>)" 
                                                        class="btn btn-sm btn-secondary" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <button onclick="viewTransaction(<?= $trans['id'] ?>)" 
                                                    class="btn btn-sm btn-secondary" title="View Details">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== BOTTOM ROW ========== -->
    <div class="row g-4 mt-2">
        <div class="col-lg-7">
            <div class="card-custom">
                <div class="card-header">
                    <span><i class="fas fa-star text-warning me-2"></i> Most Issued Books</span>
                    <span class="badge bg-primary rounded-pill">Top <?= count($topBooks) ?></span>
                </div>
                <div class="card-body p-3" id="topBooksContainer">
                    <?php if (empty($topBooks)): ?>
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-chart-line fa-3x mb-2"></i>
                            <p>No circulation data available yet.</p>
                        </div>
                    <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($topBooks as $index => $book): 
                                $rankClass = '';
                                if ($index === 0) $rankClass = 'gold';
                                elseif ($index === 1) $rankClass = 'silver';
                                elseif ($index === 2) $rankClass = 'bronze';
                            ?>
                            <div class="col-md-6">
                                <div class="top-book-item">
                                    <span class="rank-badge <?= $rankClass ?>">#<?= $index + 1 ?></span>
                                    <?php if ($book['cover_base64']): ?>
                                        <img src="<?= $book['cover_base64'] ?>" style="width:35px;height:48px;object-fit:cover;border-radius:4px;border:1px solid #e9ecef;">
                                    <?php else: ?>
                                        <div style="width:35px;height:48px;background:#e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#6c757d;border:1px solid #dee2e6;">
                                            <i class="fas fa-book"></i>
                                        </div>
                                    <?php endif; ?>
                                    <div class="book-info">
                                        <div class="title" title="<?= htmlspecialchars($book['title']) ?>">
                                            <?= htmlspecialchars(substr($book['title'], 0, 28)) ?><?= strlen($book['title']) > 28 ? '…' : '' ?>
                                        </div>
                                        <div class="meta">
                                            <i class="fas fa-copy"></i> <?= $book['total_copies'] ?? 1 ?> copies
                                        </div>
                                    </div>
                                    <span class="issue-count"><?= $book['count'] ?></span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card-custom">
                <div class="card-header">
                    <span><i class="fas fa-info-circle text-info me-2"></i> System Information</span>
                </div>
                <div class="card-body p-3">
                    <div class="row g-2">
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded">
                                <small class="text-muted">Fine per day</small>
                                <div class="fw-bold"><?= $currencySymbol ?> <?= number_format($finePerDay, 2) ?></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded">
                                <small class="text-muted">Max books per member</small>
                                <div class="fw-bold"><?= $maxBooksPerMember ?></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded">
                                <small class="text-muted">Max renewals</small>
                                <div class="fw-bold"><?= $maxRenewals ?></div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded">
                                <small class="text-muted">Active members</small>
                                <div class="fw-bold" id="totalMembersDisplay"><?= number_format($totalMembers) ?></div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between small text-muted">
                        <span><i class="fas fa-database"></i> DB: <?= getDatabaseSize() ?></span>
                        <span><i class="fas fa-clock"></i> Updated: <span id="lastUpdateTime"><?= date('H:i:s') ?></span></span>
                    </div>
                    <?php if ($institution && !empty($institution['name'])): ?>
                        <div class="text-center small text-muted mt-2">
                            <i class="fas fa-building"></i> <?= htmlspecialchars($institution['name']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== MODALS ========== -->
<!-- Issue Modal -->
<div class="modal fade" id="quickIssueModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-arrow-right me-2"></i> Issue Book</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="issue.php" id="quickIssueForm">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Member Adm/Mem Number *</label>
                            <input type="text" name="admno" id="quickAdmno" class="form-control form-control-lg" 
                                   required autocomplete="off" placeholder="Enter Adm/Mem Number">
                            <div id="quickMemberInfo" class="mt-2"></div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Book Barcode *</label>
                            <input type="text" name="barcode" id="quickBarcode" class="form-control form-control-lg" 
                                   required autocomplete="off" placeholder="Scan or enter barcode">
                            <div id="quickBookInfo" class="mt-2"></div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Any special notes about this issue..."></textarea>
                        </div>
                        <div class="col-12">
                            <div class="alert alert-info small mb-0">
                                <i class="fas fa-info-circle"></i> 
                                <strong>Fine Policy:</strong> Fine of <?= $currencySymbol ?> <?= number_format($finePerDay, 2) ?> per day will apply after due date.
                                <br><strong>Max Books:</strong> <?= $maxBooksPerMember ?> per member.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="issue" class="btn btn-primary" id="quickIssueBtn">Issue Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Return Modal -->
<div class="modal fade" id="quickReturnModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="fas fa-arrow-left me-2"></i> Return Book</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="return.php" id="quickReturnForm">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Book Barcode *</label>
                        <input type="text" name="barcode" id="quickReturnBarcode" class="form-control form-control-lg" 
                               required autocomplete="off" placeholder="Scan or enter barcode">
                        <div id="quickReturnInfo" class="mt-2"></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Condition Notes</label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Any damage or condition notes..."></textarea>
                    </div>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                    <div class="form-check">
                        <input type="checkbox" name="waive_fine" value="1" id="waiveFine" class="form-check-input">
                        <label class="form-check-label fw-semibold" for="waiveFine">
                            <i class="fas fa-hand-holding-usd text-success"></i> Waive overdue fine (Admin only)
                        </label>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="return" class="btn btn-warning">Return Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Renew Modal -->
<div class="modal fade" id="quickRenewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fas fa-sync-alt me-2"></i> Renew Book</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" action="renew.php" id="quickRenewForm">
                <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Book Barcode *</label>
                        <input type="text" name="barcode" id="renewBarcode" class="form-control form-control-lg" 
                               required autocomplete="off" placeholder="Scan or enter barcode">
                        <div id="renewInfo" class="mt-2"></div>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="charge_fine" value="1" id="renewChargeFine" class="form-check-input">
                        <label class="form-check-label" for="renewChargeFine">
                            <i class="fas fa-coins text-warning"></i> Charge overdue fine for this renewal
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="renew" class="btn btn-info text-white">Renew Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Transaction Details Modal -->
<div class="modal fade" id="transactionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title"><i class="fas fa-info-circle me-2"></i> Transaction Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="transactionDetails">
                <div class="text-center py-4">
                    <div class="loading-spinner"></div>
                    <p class="mt-2 text-muted">Loading...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Print Receipt
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== GLOBALS ==========
let autoRefreshInterval = null;
const REFRESH_INTERVAL = 30000; // 30 seconds

// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== WEEKLY CHART ==========
const weeklyData = <?= json_encode($dailyActivity) ?>;
let weeklyChart = null;
function initWeeklyChart() {
    if (weeklyChart) weeklyChart.destroy();
    if (weeklyData.length === 0) return;
    weeklyChart = new Chart(document.getElementById('weeklyChart'), {
        type: 'bar',
        data: {
            labels: weeklyData.map(d => d.date),
            datasets: [
                {
                    label: 'Issued',
                    data: weeklyData.map(d => d.issued),
                    backgroundColor: 'rgba(30, 60, 114, 0.75)',
                    borderColor: '#1e3c72',
                    borderWidth: 2,
                    borderRadius: 6
                },
                {
                    label: 'Returned',
                    data: weeklyData.map(d => d.returned),
                    backgroundColor: 'rgba(40, 167, 69, 0.75)',
                    borderColor: '#28a745',
                    borderWidth: 2,
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11 } } }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 10 } } },
                x: { ticks: { font: { size: 10 } } }
            }
        }
    });
}
initWeeklyChart();

// ========== REFRESH FUNCTIONS ==========
function refreshStats() {
    fetch('?ajax=stats')
        .then(r => r.json())
        .then(data => {
            document.getElementById('statIssued').textContent = numberFormat(data.totalIssued);
            document.getElementById('statOverdue').textContent = numberFormat(data.totalOverdue);
            document.getElementById('statMembers').textContent = numberFormat(data.totalMembers);
            document.getElementById('statBooks').textContent = numberFormat(data.totalBooks);
            document.getElementById('statAvailable').textContent = numberFormat(data.totalAvailable);
            document.getElementById('statOnTime').textContent = data.onTimeRate + '%';
            document.getElementById('totalMembersDisplay').textContent = numberFormat(data.totalMembers);
        })
        .catch(err => console.warn('Stats refresh error:', err));
}

function refreshToday() {
    fetch('?ajax=today')
        .then(r => r.json())
        .then(data => {
            document.getElementById('todayIssued').textContent = numberFormat(data.todayIssued);
            document.getElementById('todayReturned').textContent = numberFormat(data.todayReturned);
            document.getElementById('todayRenewed').textContent = numberFormat(data.todayRenewed);
            document.getElementById('weekMembers').textContent = numberFormat(data.weekMembers);
            document.getElementById('weekIssued').textContent = numberFormat(data.weekIssued);
        })
        .catch(err => console.warn('Today refresh error:', err));
}

function refreshTransactions() {
    fetch('?ajax=transactions')
        .then(r => r.json())
        .then(data => {
            const container = document.getElementById('transactionsTable');
            const transactions = data.transactions || [];
            document.getElementById('transactionCount').textContent = transactions.length;
            if (transactions.length === 0) {
                container.innerHTML = `<div class="text-center text-muted py-5">
                    <i class="fas fa-inbox fa-3x d-block mb-2"></i>
                    No transactions yet
                </div>`;
                return;
            }
            let html = `<table class="table table-transactions mb-0">
                <thead><tr>
                    <th>Date</th><th>Member</th><th>Book</th><th>Due</th><th>Status</th><th>Action</th>
                </tr></thead><tbody>`;
            transactions.forEach(t => {
                const statusClass = t.status_type === 'overdue' ? 'table-danger' : 
                                   (t.status_type === 'returned' ? 'table-success' : '');
                const statusBadge = t.status_type === 'returned' ? 'bg-success' : 
                                   (t.status_type === 'overdue' ? 'bg-danger animated-badge' : 'bg-primary');
                const statusText = t.status_type === 'returned' ? 'Returned' : 
                                  (t.status_type === 'overdue' ? 'Overdue' : 'Issued');
                const memberPhoto = t.member_photo_base64 ? 
                    `<img src="${t.member_photo_base64}" class="member-photo-small" alt="Member">` :
                    `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                const bookCover = t.book_cover_base64 ? 
                    `<img src="${t.book_cover_base64}" class="book-cover-small" alt="Book">` :
                    `<div class="book-cover-placeholder"><i class="fas fa-book"></i></div>`;
                const dueDate = t.due_date ? new Date(t.due_date).toLocaleDateString('en-GB') : 'N/A';
                html += `<tr class="${statusClass}">
                    <td>${new Date(t.issue_date).toLocaleDateString('en-GB')}</td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            ${memberPhoto}
                            <div>
                                <div class="fw-semibold small">${escapeHtml(t.member_name || 'Unknown')}</div>
                                <small class="text-muted">${escapeHtml(t.admno)}</small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            ${bookCover}
                            <div>
                                <span class="text-ellipsis" title="${escapeHtml(t.title)}">
                                    ${escapeHtml((t.title || '').substring(0, 30))}
                                </span>
                                ${(t.title || '').length > 30 ? '…' : ''}
                            </div>
                        </div>
                    </td>
                    <td>${dueDate}</td>
                    <td><span class="badge badge-status ${statusBadge}">${statusText}</span></td>
                    <td>
                        ${!t.return_date ? `
                            <div class="d-flex flex-wrap gap-1">
                                <form method="post" action="return.php" style="display:inline">
                                    <input type="hidden" name="csrf_token" value="<?= $csrf_token ?>">
                                    <input type="hidden" name="barcode" value="${escapeHtml(t.barcode)}">
                                    <button type="submit" name="return" class="btn btn-sm btn-warning" title="Return">
                                        <i class="fas fa-arrow-left"></i>
                                    </button>
                                </form>
                                <a href="renew.php?barcode=${encodeURIComponent(t.barcode)}" 
                                   class="btn btn-sm btn-info text-white" title="Renew">
                                    <i class="fas fa-sync-alt"></i>
                                </a>
                                <button onclick="viewTransaction(${t.id})" 
                                        class="btn btn-sm btn-secondary" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        ` : `
                            <button onclick="viewTransaction(${t.id})" 
                                    class="btn btn-sm btn-secondary" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                        `}
                    </td>
                </tr>`;
            });
            html += '</tbody></table>';
            container.innerHTML = html;
            document.getElementById('lastUpdateTime').textContent = new Date().toLocaleTimeString();
        })
        .catch(err => console.warn('Transactions refresh error:', err));
}

function refreshTopMembers() {
    fetch('?ajax=top_members')
        .then(r => r.json())
        .then(data => {
            const container = document.getElementById('topMembersContainer');
            if (!data || data.length === 0) {
                container.innerHTML = '<p class="text-muted text-center py-3 small">No active members with loans</p>';
                return;
            }
            let html = '<ul class="list-group list-group-flush">';
            data.forEach(m => {
                const photo = m.photo_base64 ? 
                    `<img src="${m.photo_base64}" class="member-photo-small" alt="Photo">` :
                    `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                html += `<li class="list-group-item d-flex align-items-center gap-3 px-2 py-2 border-0 border-bottom">
                    ${photo}
                    <div class="flex-grow-1">
                        <div class="fw-semibold small">${escapeHtml(m.name || 'Unknown')}</div>
                        <small class="text-muted">${escapeHtml(m.admno)}</small>
                    </div>
                    <span class="badge bg-primary rounded-pill">${m.issue_count} books</span>
                </li>`;
            });
            html += '</ul>';
            container.innerHTML = html;
        })
        .catch(err => console.warn('Top members refresh error:', err));
}

function refreshTopBooks() {
    fetch('?ajax=top_books')
        .then(r => r.json())
        .then(data => {
            const container = document.getElementById('topBooksContainer');
            if (!data || data.length === 0) {
                container.innerHTML = '<div class="text-center text-muted py-4"><i class="fas fa-chart-line fa-3x mb-2"></i><p>No circulation data available yet.</p></div>';
                return;
            }
            let html = '<div class="row g-2">';
            data.forEach((book, index) => {
                const rankClass = index === 0 ? 'gold' : (index === 1 ? 'silver' : (index === 2 ? 'bronze' : ''));
                const cover = book.cover_base64 ? 
                    `<img src="${book.cover_base64}" style="width:35px;height:48px;object-fit:cover;border-radius:4px;border:1px solid #e9ecef;">` :
                    `<div style="width:35px;height:48px;background:#e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#6c757d;border:1px solid #dee2e6;">
                        <i class="fas fa-book"></i>
                    </div>`;
                html += `<div class="col-md-6">
                    <div class="top-book-item">
                        <span class="rank-badge ${rankClass}">#${index+1}</span>
                        ${cover}
                        <div class="book-info">
                            <div class="title" title="${escapeHtml(book.title)}">
                                ${escapeHtml((book.title || '').substring(0, 28))}${(book.title||'').length>28?'…':''}
                            </div>
                            <div class="meta"><i class="fas fa-copy"></i> ${book.total_copies || 1} copies</div>
                        </div>
                        <span class="issue-count">${book.count}</span>
                    </div>
                </div>`;
            });
            html += '</div>';
            container.innerHTML = html;
        })
        .catch(err => console.warn('Top books refresh error:', err));
}

function refreshDashboard() {
    refreshStats();
    refreshToday();
    refreshTransactions();
    refreshTopMembers();
    refreshTopBooks();
    document.getElementById('lastUpdateTime').textContent = new Date().toLocaleTimeString();
    // Flash live indicator
    const indicator = document.getElementById('liveIndicator');
    if (indicator) {
        indicator.innerHTML = '<i class="fas fa-circle text-success"></i> Refreshing...';
        setTimeout(() => indicator.innerHTML = '<i class="fas fa-circle text-success"></i> Live', 1000);
    }
}

// ========== START AUTO-REFRESH ==========
function startAutoRefresh() {
    if (autoRefreshInterval) clearInterval(autoRefreshInterval);
    refreshDashboard();
    autoRefreshInterval = setInterval(refreshDashboard, REFRESH_INTERVAL);
}
startAutoRefresh();

// ========== UTILITY ==========
function escapeHtml(s) {
    if (!s) return '';
    return String(s).replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m);
}
function numberFormat(n) {
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ========== SEARCH MEMBER (unchanged) ==========
function searchMember() {
    const search = document.getElementById('memberSearch').value.trim();
    const resultDiv = document.getElementById('memberResult');
    if (search.length < 2) {
        resultDiv.innerHTML = '<div class="alert alert-warning small">Please enter at least 2 characters</div>';
        resultDiv.style.display = 'block';
        return;
    }
    resultDiv.innerHTML = '<div class="text-center py-2"><div class="loading-spinner"></div> Searching...</div>';
    resultDiv.style.display = 'block';
    document.getElementById('memberSuggestions').style.display = 'none';
    fetch('issue.php?ajax_member=1&admno=' + encodeURIComponent(search))
        .then(r => r.json())
        .then(data => {
            if (data && data.name) {
                const maxBooks = <?= $maxBooksPerMember ?>;
                const activeBooks = data.active_books || 0;
                const canIssue = activeBooks < maxBooks;
                const photo = data.photo_base64 ? `<img src="${data.photo_base64}" class="member-photo" alt="Photo">` :
                              `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                resultDiv.innerHTML = `
                    <div class="member-result-card">
                        <div class="d-flex flex-wrap align-items-center gap-3">
                            ${photo}
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><i class="fas fa-user-check text-success"></i> <strong>${escapeHtml(data.name)}</strong></h6>
                                <p class="mb-0 small">📋 ID: ${escapeHtml(data.admno)}</p>
                                <p class="mb-0 small">📚 Category: ${escapeHtml(data.member_category || 'N/A')}</p>
                                <p class="mb-0 small">📖 Books Issued: ${activeBooks} / ${maxBooks}</p>
                                ${!canIssue ? '<p class="mb-0 small text-danger fw-bold">⚠ Cannot issue more books - limit reached</p>' : ''}
                                <hr class="my-2">
                                <div class="d-flex flex-wrap gap-1">
                                    <a href="history.php?admno=${encodeURIComponent(data.admno)}" class="btn btn-sm btn-info text-white"><i class="fas fa-history"></i> History</a>
                                    <button onclick="quickIssueFromMember('${escapeHtml(data.admno)}')" class="btn btn-sm btn-primary" ${!canIssue ? 'disabled' : ''}><i class="fas fa-arrow-right"></i> Issue</button>
                                    <button onclick="quickReturnFromMember('${escapeHtml(data.admno)}')" class="btn btn-sm btn-warning"><i class="fas fa-arrow-left"></i> Return</button>
                                    <a href="../admin/members.php?admno=${encodeURIComponent(data.admno)}" class="btn btn-sm btn-secondary"><i class="fas fa-edit"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                resultDiv.innerHTML = '<div class="alert alert-danger">❌ Member not found</div>';
            }
        })
        .catch(() => resultDiv.innerHTML = '<div class="alert alert-danger">Error searching member</div>');
}

// ========== MEMBER SUGGESTIONS ==========
document.getElementById('memberSearch')?.addEventListener('input', function() {
    const query = this.value.trim();
    const suggestionsDiv = document.getElementById('memberSuggestions');
    const resultDiv = document.getElementById('memberResult');
    if (query.length < 2) { suggestionsDiv.style.display = 'none'; return; }
    fetch('issue.php?ajax_member_suggest=1&q=' + encodeURIComponent(query))
        .then(r => r.json())
        .then(data => {
            if (data && data.length > 0) {
                let html = '<div class="list-group">';
                data.slice(0, 5).forEach(m => {
                    html += `<a href="#" class="list-group-item list-group-item-action d-flex align-items-center gap-2" onclick="selectSuggestion('${escapeHtml(m.admno)}','${escapeHtml(m.name)}')">
                        <i class="fas fa-user text-primary"></i>
                        <div><div class="fw-semibold">${escapeHtml(m.name)}</div><small class="text-muted">${escapeHtml(m.admno)}</small></div>
                    </a>`;
                });
                html += '</div>';
                suggestionsDiv.innerHTML = html;
                suggestionsDiv.style.display = 'block';
                resultDiv.style.display = 'none';
            } else {
                suggestionsDiv.style.display = 'none';
            }
        })
        .catch(() => suggestionsDiv.style.display = 'none');
});
function selectSuggestion(admno, name) {
    document.getElementById('memberSearch').value = admno + ' - ' + name;
    document.getElementById('memberSuggestions').style.display = 'none';
    searchMember();
}

// ========== QUICK MODAL HELPERS ==========
function quickIssueFromMember(admno) {
    document.getElementById('quickAdmno').value = admno;
    document.getElementById('quickBarcode').value = '';
    document.getElementById('quickMemberInfo').innerHTML = '';
    document.getElementById('quickBookInfo').innerHTML = '';
    document.getElementById('quickIssueBtn').disabled = false;
    new bootstrap.Modal(document.getElementById('quickIssueModal')).show();
}
function quickReturnFromMember(admno) {
    document.getElementById('quickReturnBarcode').value = '';
    document.getElementById('quickReturnInfo').innerHTML = '';
    new bootstrap.Modal(document.getElementById('quickReturnModal')).show();
}
function showIssueModal() {
    ['quickAdmno','quickBarcode'].forEach(id => document.getElementById(id).value = '');
    ['quickMemberInfo','quickBookInfo'].forEach(id => document.getElementById(id).innerHTML = '');
    document.getElementById('quickIssueBtn').disabled = false;
    new bootstrap.Modal(document.getElementById('quickIssueModal')).show();
}
function showReturnModal() {
    document.getElementById('quickReturnBarcode').value = '';
    document.getElementById('quickReturnInfo').innerHTML = '';
    const waive = document.getElementById('waiveFine');
    if (waive) waive.checked = false;
    new bootstrap.Modal(document.getElementById('quickReturnModal')).show();
}
function showRenewModal() {
    document.getElementById('renewBarcode').value = '';
    document.getElementById('renewInfo').innerHTML = '';
    document.getElementById('renewChargeFine').checked = false;
    const btn = document.querySelector('#quickRenewForm button[type="submit"]');
    if (btn) btn.disabled = false;
    new bootstrap.Modal(document.getElementById('quickRenewModal')).show();
}

// ========== VIEW TRANSACTION ==========
function viewTransaction(id) {
    const modalBody = document.getElementById('transactionDetails');
    modalBody.innerHTML = '<div class="text-center py-4"><div class="loading-spinner"></div><p class="mt-2 text-muted">Loading...</p></div>';
    fetch('ajax_transaction.php?id=' + id)
        .then(r => r.json())
        .then(data => {
            if (data && data.id) {
                const fine = parseFloat(data.fine || 0).toFixed(2);
                const currency = '<?= $currencySymbol ?>';
                const memberPhoto = data.member_photo_base64 ? `<img src="${data.member_photo_base64}" style="width:50px;height:50px;object-fit:cover;border-radius:50%;border:2px solid #e9ecef;">` :
                    `<div style="width:50px;height:50px;border-radius:50%;background:#e9ecef;display:flex;align-items:center;justify-content:center;color:#6c757d;"><i class="fas fa-user fa-2x"></i></div>`;
                const bookCover = data.book_cover_base64 ? `<img src="${data.book_cover_base64}" style="max-width:50px;max-height:70px;object-fit:contain;border:1px solid #e9ecef;border-radius:4px;padding:2px;">` :
                    `<div style="width:45px;height:60px;border:1px solid #e9ecef;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#6c757d;background:#f8f9fa;"><i class="fas fa-book fa-2x"></i></div>`;
                modalBody.innerHTML = `
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <div class="card bg-light h-100"><div class="card-body">
                                <h6><i class="fas fa-user"></i> Member Details</h6>
                                <div class="d-flex align-items-center gap-3">
                                    ${memberPhoto}
                                    <div><p class="mb-1"><strong>Name:</strong> ${escapeHtml(data.member_name)}</p>
                                    <p class="mb-1"><strong>Adm No:</strong> ${escapeHtml(data.admno)}</p>
                                    <p class="mb-0"><strong>Category:</strong> ${escapeHtml(data.member_category || 'N/A')}</p></div>
                                </div>
                            </div></div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-light h-100"><div class="card-body">
                                <h6><i class="fas fa-book"></i> Book Details</h6>
                                <div class="d-flex align-items-center gap-3">
                                    ${bookCover}
                                    <div><p class="mb-1"><strong>Title:</strong> ${escapeHtml(data.title)}</p>
                                    <p class="mb-1"><strong>Barcode:</strong> ${escapeHtml(data.barcode)}</p>
                                    <p class="mb-0"><strong>Author:</strong> ${escapeHtml(data.author || 'N/A')}</p></div>
                                </div>
                            </div></div>
                        </div>
                    </div>
                    <table class="table table-bordered table-sm">
                        <tr><th style="width:30%;">Issue Date</th><td>${formatDate(data.issue_date)}</td></tr>
                        <tr><th>Due Date</th><td>${formatDate(data.due_date)}</td></tr>
                        ${data.return_date ? `<tr><th>Return Date</th><td>${formatDate(data.return_date)}</td></tr>` : ''}
                        ${data.return_date ? `<tr><th>Fine Charged</th><td>${currency} ${fine}</td></tr>` : ''}
                        <tr><th>Renew Count</th><td>${data.renew_count || 0}</td></tr>
                        ${data.notes ? `<tr><th>Notes</th><td>${escapeHtml(data.notes)}</td></tr>` : ''}
                        <tr><th>Status</th><td><span class="badge ${data.return_date ? 'bg-success' : 'bg-primary'}">${data.return_date ? 'Returned' : 'Issued'}</span></td></tr>
                    </table>
                `;
            } else {
                modalBody.innerHTML = '<div class="alert alert-danger">Transaction not found</div>';
            }
        })
        .catch(() => modalBody.innerHTML = '<div class="alert alert-danger">Error loading details</div>');
    new bootstrap.Modal(document.getElementById('transactionModal')).show();
}

function formatDate(dateStr) {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString('en-GB');
}

// ========== AUTO-FETCH IN MODALS ==========
document.getElementById('quickAdmno')?.addEventListener('blur', function() {
    const admno = this.value.trim();
    const info = document.getElementById('quickMemberInfo');
    if (admno.length < 3) { info.innerHTML = ''; return; }
    fetch('issue.php?ajax_member=1&admno=' + encodeURIComponent(admno))
        .then(r => r.json())
        .then(data => {
            if (data && data.name) {
                const max = <?= $maxBooksPerMember ?>;
                const active = data.active_books || 0;
                const can = active < max;
                const photo = data.photo_base64 ? `<img src="${data.photo_base64}" style="width:40px;height:40px;object-fit:cover;border-radius:50%;margin-right:10px;">` : '';
                info.innerHTML = `
                    <div class="alert ${can ? 'alert-success' : 'alert-danger'} py-2 mb-0">
                        <div class="d-flex align-items-center">
                            ${photo}
                            <div><strong>${escapeHtml(data.name)}</strong><br><small>${escapeHtml(data.member_category || 'N/A')}</small><br><small>Books: ${active} / ${max}</small>${!can ? '<br><strong class="text-danger">Limit reached</strong>' : ''}</div>
                        </div>
                    </div>
                `;
            } else {
                info.innerHTML = `<div class="alert alert-danger py-1 mb-0">✗ Member not found</div>`;
            }
        })
        .catch(() => info.innerHTML = '<div class="alert alert-danger py-1 mb-0">Error validating member</div>');
});

document.getElementById('quickBarcode')?.addEventListener('blur', function() {
    const barcode = this.value.trim();
    const info = document.getElementById('quickBookInfo');
    const btn = document.getElementById('quickIssueBtn');
    if (barcode.length < 3) { info.innerHTML = ''; btn.disabled = false; return; }
    fetch('ajax_book.php?barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            if (data && data.title) {
                const avail = data.available || 0;
                const issued = data.is_issued === true;
                let cover = data.cover_base64 ? `<br><img src="${data.cover_base64}" style="height:60px;margin-top:5px;border-radius:4px;border:1px solid #e9ecef;padding:2px;">` : '';
                let html = `<div class="alert ${avail > 0 && !issued ? 'alert-success' : 'alert-danger'} py-2 mb-0">
                    <div><i class="fas ${avail > 0 && !issued ? 'fa-check-circle' : 'fa-times-circle'}"></i> <strong>${escapeHtml(data.title)}</strong><br>
                    Author: ${escapeHtml(data.author || 'Unknown')}<br>Available: ${avail} / ${data.quantity || 1}${cover}</div>`;
                if (issued) {
                    html += `<div class="alert alert-danger mt-1 py-1 mb-0">
                        <i class="fas fa-ban"></i> <strong>⚠ ALREADY ISSUED</strong><br>
                        <small>Issued to: <strong>${escapeHtml(data.member_name)}</strong> (${escapeHtml(data.member_admno)})<br>
                        Issue: ${data.issue_date} | Due: ${data.due_date}</small></div>`;
                    btn.disabled = true;
                } else if (avail <= 0) {
                    html += `<div class="alert alert-warning mt-1 py-1 mb-0"><strong>Not available for issue</strong></div>`;
                    btn.disabled = true;
                } else {
                    btn.disabled = false;
                }
                html += '</div>';
                info.innerHTML = html;
            } else {
                info.innerHTML = `<div class="alert alert-warning py-1 mb-0"><i class="fas fa-exclamation-triangle"></i> New book - will be added upon issue.</div>`;
                btn.disabled = false;
            }
        })
        .catch(() => { info.innerHTML = '<div class="alert alert-danger py-1 mb-0">Error fetching book details</div>'; btn.disabled = false; });
});

document.getElementById('quickReturnBarcode')?.addEventListener('blur', function() {
    const barcode = this.value.trim();
    const info = document.getElementById('quickReturnInfo');
    if (barcode.length < 3) { info.innerHTML = ''; return; }
    fetch('ajax_book.php?barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            if (data && data.title) {
                const days = data.days_overdue || 0;
                const fine = data.fine_amount || 0;
                const cover = data.cover_base64 ? `<img src="${data.cover_base64}" style="height:40px;border-radius:4px;margin-right:10px;">` : '';
                info.innerHTML = `
                    <div class="alert alert-info py-2 mb-0">
                        <div class="d-flex align-items-start">
                            ${cover}
                            <div><strong>📖 ${escapeHtml(data.title)}</strong><br>
                            <strong>👤 Member:</strong> ${escapeHtml(data.member_name || 'Unknown')}<br>
                            <strong>📅 Due Date:</strong> ${data.due_date || 'N/A'}<br>
                            ${days > 0 ? `<span class="text-danger">⚠️ Overdue by ${days} day(s) | Fine: ${'<?= $currencySymbol ?>'} ${fine.toFixed(2)}</span>` : '<span class="text-success">✅ On time</span>'}
                        </div>
                    </div>
                `;
            } else {
                info.innerHTML = '<div class="alert alert-warning py-1 mb-0">⚠ No active issue for this barcode</div>';
            }
        })
        .catch(() => info.innerHTML = '<div class="alert alert-danger py-1 mb-0">Error fetching issue details</div>');
});

document.getElementById('renewBarcode')?.addEventListener('blur', function() {
    const barcode = this.value.trim();
    const info = document.getElementById('renewInfo');
    const btn = document.querySelector('#quickRenewForm button[type="submit"]');
    if (barcode.length < 3) { info.innerHTML = ''; if (btn) btn.disabled = false; return; }
    fetch('renew.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            if (data && data.title) {
                const fine = data.fine_amount || 0;
                const days = data.days_overdue || 0;
                const newDue = data.new_due_date;
                const maxRen = <?= $maxRenewals ?>;
                const curRen = data.renew_count || 0;
                const can = curRen < maxRen;
                const cover = data.cover_base64 ? `<img src="${data.cover_base64}" style="height:40px;border-radius:4px;margin-right:10px;">` : '';
                const photo = data.photo_base64 ? `<img src="${data.photo_base64}" style="height:30px;width:30px;object-fit:cover;border-radius:50%;margin-right:10px;">` : '';
                info.innerHTML = `
                    <div class="alert alert-info py-2 mb-0">
                        <div class="d-flex align-items-start">
                            ${cover}
                            <div><strong>📖 ${escapeHtml(data.title)}</strong><br>
                            <div class="d-flex align-items-center">${photo}<span><strong>👤 Member:</strong> ${escapeHtml(data.member_name)} (${escapeHtml(data.admno)})</span></div>
                            <strong>📅 Current Due:</strong> ${data.due_date}<br>
                            <strong>🔄 Renewals:</strong> ${curRen} / ${maxRen}<br>
                            ${days > 0 ? `<span class="text-danger">⚠️ Overdue by ${days} day(s) | Fine: ${'<?= $currencySymbol ?>'} ${fine.toFixed(2)}</span>` : '<span class="text-success">✅ On time</span>'}<br>
                            <strong>📆 New Due:</strong> ${newDue}
                            ${!can ? '<br><span class="text-danger">❌ Cannot renew - maximum renewals reached</span>' : ''}
                        </div>
                    </div>
                `;
                if (btn) btn.disabled = !can;
            } else {
                info.innerHTML = '<div class="alert alert-danger py-1 mb-0">⚠ No active issue for this barcode</div>';
                if (btn) btn.disabled = true;
            }
        })
        .catch(() => { info.innerHTML = '<div class="alert alert-danger py-1 mb-0">Error fetching renewal details</div>'; if (btn) btn.disabled = true; });
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'i') { e.preventDefault(); showIssueModal(); }
    if (e.ctrlKey && e.key === 'r') { e.preventDefault(); showReturnModal(); }
    if (e.ctrlKey && e.key === 'n') { e.preventDefault(); showRenewModal(); }
    if (e.ctrlKey && e.key === 'h') { e.preventDefault(); window.location.href = 'history.php'; }
    if (e.ctrlKey && e.key === 'o') { e.preventDefault(); window.location.href = 'overdue.php'; }
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
});

// ========== MODAL SCROLL FIX ==========
document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('shown.bs.modal', () => document.body.style.overflow = 'hidden');
    m.addEventListener('hidden.bs.modal', () => document.body.style.overflow = '');
});
</script>

<?php renderFooter(); ?>