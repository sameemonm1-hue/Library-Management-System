<?php
/**
 * Issue Book - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - Enhanced member and book display with photos
 * - Auto-fetch metadata from multiple sources
 * - Reference book permission handling
 * - Library hours enforcement
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// ========== HELPER: GET SINGLE SETTING ==========
if (!function_exists('getSettingValue')) {
    function getSettingValue($key) {
        $settings = getSettings();
        return $settings[$key] ?? null;
    }
}

// ========== IMAGE HELPER (base64) ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== METADATA FETCHERS ==========
function fetchViaOpenLibrary($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (empty($isbn)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "https://openlibrary.org/api/books?bibkeys=ISBN:" . $isbn . "&format=json&jscmd=data";
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    $key = "ISBN:" . $isbn;
    if (isset($data[$key])) {
        $book = $data[$key];
        $result['title'] = $book['title'] ?? '';
        $result['author'] = $book['authors'][0]['name'] ?? '';
        $result['publisher'] = $book['publishers'][0]['name'] ?? '';
        $result['year'] = $book['publish_date'] ?? '';
        $result['pages'] = $book['number_of_pages'] ?? 0;
        $result['cover_url'] = $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
        $result['category'] = $book['subjects'][0]['name'] ?? '';
        $result['summary'] = isset($book['description']) ? (is_array($book['description']) ? ($book['description']['value'] ?? '') : $book['description']) : '';
    }
    return $result;
}

function fetchViaGoogleBooks($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (empty($isbn)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    if (isset($data['items'][0]['volumeInfo'])) {
        $info = $data['items'][0]['volumeInfo'];
        $result['title'] = $info['title'] ?? '';
        $result['author'] = $info['authors'][0] ?? '';
        $result['publisher'] = $info['publisher'] ?? '';
        $result['year'] = $info['publishedDate'] ?? '';
        $result['pages'] = $info['pageCount'] ?? 0;
        $result['summary'] = $info['description'] ?? '';
        $result['category'] = $info['categories'][0] ?? '';
        $result['cover_url'] = $info['imageLinks']['thumbnail'] ?? '';
    }
    return $result;
}

function fetchViaISBNdb($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    $apiKey = getSettingValue('isbndb_api_key');
    if (empty($apiKey)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true, 'header' => "Authorization: " . $apiKey]]);
    $url = "https://api2.isbndb.com/book/" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    if (isset($data['book'])) {
        $book = $data['book'];
        $result['title'] = $book['title'] ?? '';
        $result['author'] = $book['authors'] ? implode(', ', $book['authors']) : '';
        $result['publisher'] = $book['publisher'] ?? '';
        $result['year'] = $book['date_published'] ?? '';
        $result['pages'] = $book['pages'] ?? 0;
        $result['summary'] = $book['synopsis'] ?? '';
        $result['category'] = $book['subject'] ?? '';
        $result['cover_url'] = $book['image'] ?? '';
    }
    return $result;
}

function fetchViaWorldCat($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    $apiKey = getSettingValue('worldcat_api_key');
    if (empty($apiKey)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "http://www.worldcat.org/webservices/catalog/content/isbn/" . $isbn . "?wskey=" . $apiKey . "&format=xml";
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $xml = @simplexml_load_string($response);
    if ($xml) {
        $namespaces = $xml->getNamespaces(true);
        $dc = $namespaces['dc'] ?? '';
        if ($dc) {
            $result['title'] = (string)$xml->children($dc)->title ?? '';
            $result['author'] = (string)$xml->children($dc)->creator ?? '';
            $result['publisher'] = (string)$xml->children($dc)->publisher ?? '';
            $result['year'] = (string)$xml->children($dc)->date ?? '';
        }
    }
    return $result;
}

$yazAvailable = extension_loaded('yaz');
$z39Targets = [
    ['host' => 'z3950.loc.gov', 'port' => 7090, 'database' => 'voyager'],
    ['host' => 'z3950.fcla.edu', 'port' => 7090, 'database' => 'FCL01'],
];

function fetchViaZ3950($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (!extension_loaded('yaz')) return $result;
    global $z39Targets;
    foreach ($z39Targets as $target) {
        try {
            $conn = yaz_connect($target['host'] . ':' . $target['port'] . '/' . $target['database']);
            if (!$conn) continue;
            yaz_syntax($conn, 'marc21');
            yaz_range($conn, 1, 10);
            yaz_search($conn, 'rpn', '@attr 1=7 ' . $isbn);
            yaz_wait();
            $error = yaz_error($conn);
            if ($error) continue;
            $recs = yaz_record($conn, 1, 'array');
            if ($recs) {
                $fields = $recs['fields'] ?? [];
                foreach ($fields as $field) {
                    if ($field['tag'] == '245') {
                        $subfields = $field['subfields'] ?? [];
                        $title = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'a') $title = $sf['data'];
                        }
                        $result['title'] = $title;
                    }
                    if ($field['tag'] == '100') {
                        $subfields = $field['subfields'] ?? [];
                        $author = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'a') $author = $sf['data'];
                        }
                        $result['author'] = $author;
                    }
                    if ($field['tag'] == '260') {
                        $subfields = $field['subfields'] ?? [];
                        $publisher = '';
                        $year = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'b') $publisher = $sf['data'];
                            if ($sf['code'] == 'c') $year = $sf['data'];
                        }
                        $result['publisher'] = $publisher;
                        $result['year'] = $year;
                    }
                }
                if (!empty($result['title'])) break;
            }
        } catch (Exception $e) {
            continue;
        }
    }
    return $result;
}

function fetchBookMetadata($isbn, $source = 'auto') {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return null;
    
    if ($source === 'auto') {
        $sources = ['openlibrary', 'google', 'isbndb', 'worldcat', 'z3950'];
        foreach ($sources as $src) {
            $result = null;
            switch ($src) {
                case 'openlibrary': $result = fetchViaOpenLibrary($isbn); break;
                case 'google': $result = fetchViaGoogleBooks($isbn); break;
                case 'isbndb': $result = fetchViaISBNdb($isbn); break;
                case 'worldcat': $result = fetchViaWorldCat($isbn); break;
                case 'z3950': $result = fetchViaZ3950($isbn); break;
            }
            if ($result && !empty($result['title'])) return $result;
        }
        return null;
    }
    
    switch ($source) {
        case 'openlibrary': return fetchViaOpenLibrary($isbn);
        case 'google': return fetchViaGoogleBooks($isbn);
        case 'isbndb': return fetchViaISBNdb($isbn);
        case 'worldcat': return fetchViaWorldCat($isbn);
        case 'z3950': return fetchViaZ3950($isbn);
        default: return null;
    }
}

function fetchAllSources($isbn) {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return [];
    $results = [];
    $sources = ['openlibrary', 'google', 'isbndb', 'worldcat', 'z3950'];
    foreach ($sources as $src) {
        $result = null;
        switch ($src) {
            case 'openlibrary': $result = fetchViaOpenLibrary($isbn); break;
            case 'google': $result = fetchViaGoogleBooks($isbn); break;
            case 'isbndb': $result = fetchViaISBNdb($isbn); break;
            case 'worldcat': $result = fetchViaWorldCat($isbn); break;
            case 'z3950': $result = fetchViaZ3950($isbn); break;
        }
        if ($result && !empty($result['title'])) {
            $results[$src] = $result;
        }
    }
    return $results;
}

// ========== LIBRARY HOURS ENFORCEMENT ==========
$settings = getSettings();
$enforceHours = (int)($settings['enforce_library_hours'] ?? 1);
$isOpen = true;
if ($enforceHours && function_exists('isLibraryOpen')) {
    $isOpen = isLibraryOpen();
}

// Report settings for unified styling
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$toast = '';

// ========== DISPLAY WARNING IF LIBRARY CLOSED ==========
if (!$isOpen && $enforceHours) {
    $toast .= '<div class="alert alert-danger alert-dismissible fade show mb-3">
        <i class="fas fa-clock"></i> <strong>Library is currently closed.</strong> 
        Issuing books is not allowed at this time.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>';
}

// ---------- OPTIMISED AJAX HANDLERS ----------
if (isset($_GET['ajax_member'])) {
    $admno = trim($_GET['admno']);
    $stmt = $db->prepare("SELECT admno, name, member_category, class, division, active_books, photo_path, email, phone 
                          FROM members WHERE admno = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$admno]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($member && !empty($member['photo_path'])) {
        $member['photo_base64'] = getImageBase64($member['photo_path']);
    }
    header('Content-Type: application/json');
    echo json_encode($member ?? null);
    exit;
}

if (isset($_GET['ajax_book'])) {
    $barcode = trim($_GET['barcode']);
    $bookStmt = $db->prepare("SELECT barcode, title, author, publisher, category, isbn, 
                                     item_category, book_status, available, quantity, cover_path 
                              FROM books WHERE barcode = ? LIMIT 1");
    $bookStmt->execute([$barcode]);
    $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($book) {
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
        unset($book['cover_path']);
        $book['book_status'] = $book['book_status'] ?? 'Available';
        
        $issuedStmt = $db->prepare("SELECT c.issue_date, c.due_date, m.name as member_name, m.admno as member_admno, 
                                           m.photo_path as member_photo_path
                                    FROM circulation c 
                                    LEFT JOIN members m ON c.admno = m.admno 
                                    WHERE c.barcode = ? AND c.return_date IS NULL LIMIT 1");
        $issuedStmt->execute([$barcode]);
        $issued = $issuedStmt->fetch(PDO::FETCH_ASSOC);
        if ($issued) {
            $book['is_issued'] = true;
            $book['issued_member'] = $issued['member_name'];
            $book['issued_admno'] = $issued['member_admno'];
            $book['issue_date'] = $issued['issue_date'];
            $book['due_date'] = $issued['due_date'];
            $book['issued_member_photo_base64'] = getImageBase64($issued['member_photo_path'] ?? '');
        } else {
            $book['is_issued'] = false;
        }
    }
    header('Content-Type: application/json');
    echo json_encode($book ?? null);
    exit;
}

// ISBN metadata AJAX
if (isset($_GET['ajax_isbn'])) {
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    $source = $_GET['source'] ?? 'auto';
    $all = $_GET['all'] ?? false;
    header('Content-Type: application/json');
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    if ($all) {
        $results = fetchAllSources($isbn);
        echo json_encode(['success' => true, 'results' => $results]);
    } else {
        $result = fetchBookMetadata($isbn, $source);
        if ($result) {
            echo json_encode(['success' => true, 'data' => $result]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No metadata found']);
        }
    }
    exit;
}

// ========== HANDLE ISSUE SUBMISSION ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['issue'])) {
    if (!$isOpen && $enforceHours) {
        $toast = '<div class="alert alert-danger">❌ Cannot issue books – library is currently closed.</div>';
    } 
    elseif (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            
            $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
            $stmt->execute([$_POST['admno']]);
            $member = $stmt->fetch();
            if (!$member) throw new Exception("Member not found or inactive");
            
            $barcode = trim($_POST['barcode']);
            $isManual = 0;
            
            $bookStmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
            $bookStmt->execute([$barcode]);
            $book = $bookStmt->fetch();
            
            $activeIssueStmt = $db->prepare("SELECT c.*, m.name as member_name, m.admno as member_admno 
                                             FROM circulation c 
                                             LEFT JOIN members m ON c.admno = m.admno 
                                             WHERE c.barcode = ? AND c.return_date IS NULL");
            $activeIssueStmt->execute([$barcode]);
            $activeIssue = $activeIssueStmt->fetch();
            if ($activeIssue) {
                throw new Exception("Book is already issued to {$activeIssue['member_name']} (Adm No: {$activeIssue['member_admno']}). Please return it first before issuing again.");
            }
            
            $memberCat = $member['member_category'] ?? 'Student';
            $itemCat = $book ? ($book['item_category'] ?? 'General') : 'General';
            
            $categoryRulesEnabled = (int)($settings['enable_category_rules'] ?? 1);
            if ($categoryRulesEnabled && function_exists('getMemberMaxBooks') && function_exists('getMemberLoanDays') && function_exists('getMemberMaxRenewals') && function_exists('getMemberFinePerDay') && function_exists('getMemberMaxFineAmount')) {
                $maxLoans = getMemberMaxBooks($memberCat);
                $loanPeriod = getMemberLoanDays($memberCat);
                $finePerDay = getMemberFinePerDay($memberCat);
                $gracePeriod = 0;
            } else {
                $rule = getLoanRule($memberCat, $itemCat);
                if ($rule) {
                    $maxLoans = $rule['max_loans'];
                    $loanPeriod = $rule['loan_period'];
                    $finePerDay = $rule['fine_per_day'];
                    $gracePeriod = $rule['grace_period'];
                } else {
                    $maxLoans = $settings['max_books'] ?? 5;
                    $loanPeriod = $settings['loan_days'] ?? 14;
                    $finePerDay = $settings['fine_per_day'] ?? 2;
                    $gracePeriod = $settings['fine_grace_period'] ?? 0;
                }
            }
            
            $activeStmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL");
            $activeStmt->execute([$_POST['admno']]);
            $activeCount = $activeStmt->fetchColumn();
            if ($activeCount >= $maxLoans) {
                throw new Exception("Member already has maximum allowed books ({$maxLoans})");
            }
            
            if (!$book) {
                $isManual = 1;
                $coverPath = '';
                if (!empty($_POST['isbn'])) {
                    $apiData = fetchBookMetadata($_POST['isbn'], 'auto');
                    if ($apiData && $apiData['title']) {
                        if (empty($_POST['title'])) $_POST['title'] = $apiData['title'];
                        if (empty($_POST['author'])) $_POST['author'] = $apiData['author'];
                        if (empty($_POST['publisher'])) $_POST['publisher'] = $apiData['publisher'];
                        if (!empty($apiData['cover_url'])) {
                            if (function_exists('downloadCoverImage')) {
                                $coverPath = downloadCoverImage($apiData['cover_url'], $barcode);
                            } elseif (!empty($apiData['cover_url'])) {
                                $coverPath = $apiData['cover_url'];
                            }
                        }
                    }
                }
                $insert = $db->prepare("INSERT INTO books (barcode, isbn, title, author, publisher, category, quantity, available, cover_path, item_category, book_status) VALUES (?, ?, ?, ?, ?, ?, 1, 1, ?, ?, 'Available')");
                $insert->execute([$barcode, $_POST['isbn'] ?? '', $_POST['title'], $_POST['author'], $_POST['publisher'], $_POST['category'], $coverPath, $_POST['item_category'] ?? 'General']);
                $book = [
                    'title' => $_POST['title'], 'author' => $_POST['author'], 'isbn' => $_POST['isbn'] ?? '',
                    'publisher' => $_POST['publisher'], 'category' => $_POST['category'], 'available' => 1,
                    'item_category' => $_POST['item_category'] ?? 'General', 'quantity' => 1,
                    'book_status' => 'Available'
                ];
            }
            
            $bookStatus = $book['book_status'] ?? 'Available';
            $allowedStatuses = ['Available', 'Reference Only'];
            if (!in_array($bookStatus, $allowedStatuses)) {
                throw new Exception("This book has status '{$bookStatus}' and cannot be issued.");
            }
            
            $itemCategory = $book['item_category'] ?? 'General';
            if ($itemCategory == 'Restricted') {
                throw new Exception("This book is marked as 'RESTRICTED' and cannot be issued.");
            }
            
            if ($itemCategory == 'Reference' || $bookStatus == 'Reference Only') {
                if (empty($_POST['ref_permission']) || $_POST['ref_permission'] !== 'yes') {
                    throw new Exception("Reference books require librarian permission. Please ask the librarian to override.");
                }
                $adminPass = $_POST['ref_password'] ?? '';
                if (!empty($adminPass)) {
                    $userCheck = $db->prepare("SELECT password FROM users WHERE role IN ('admin','staff') LIMIT 1");
                    $userCheck->execute();
                    $adminHash = $userCheck->fetchColumn();
                    if (!password_verify($adminPass, $adminHash)) {
                        throw new Exception("Incorrect librarian password. Reference book cannot be issued.");
                    }
                }
            }
            
            if (!$isManual && $book['available'] < 1) {
                throw new Exception("Book not available for issue (no copies left).");
            }
            
            $dueDate = date("Y-m-d", strtotime("+{$loanPeriod} days"));
            
            $insert = $db->prepare("INSERT INTO circulation (admno, member_name, class, division, barcode, isbn, title, author, category, publisher, issue_date, due_date, notes, is_manual) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([
                $member['admno'], $member['name'], $member['class'] ?? '', $member['division'] ?? '',
                $barcode, $book['isbn'] ?? '', $book['title'], $book['author'] ?? '', $book['category'] ?? '',
                $book['publisher'] ?? '', date('Y-m-d'), $dueDate, $_POST['notes'] ?? '', $isManual
            ]);
            
            if (!$isManual) {
                $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$barcode]);
            }
            $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$member['admno']]);
            
            $db->commit();
            
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book issued successfully! Due Date: ' . formatDate($dueDate) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            if ($isManual) $toast .= '<div class="alert alert-info alert-dismissible fade show">📚 Manual entry - book added to system<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            
            try {
                $ip = $_SERVER['REMOTE_ADDR'] ?? '';
                $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address, created_at) VALUES (?, ?, ?, ?, datetime('now'))");
                $stmt->execute([$_SESSION['username'], 'BOOK_ISSUE', "Issued {$book['title']} to {$member['admno']}", $ip]);
            } catch (Exception $e) {
                // Silent fail for logging
            }
            
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Issue Book');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== MEMBER PHOTO ========== */
    .member-photo-large {
        width: 140px;
        height: 140px;
        object-fit: cover;
        border-radius: 10%;
        border: 3px solid var(--primary-color);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        background-color: #f8f9fa;
        transition: var(--transition);
        display: block;
        margin: 0 auto 12px auto;
    }
    .member-photo-large:hover {
        transform: scale(1.02);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    .no-photo-placeholder {
        width: 140px;
        height: 140px;
        background: #e9ecef;
        border-radius: 10%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.8rem;
        text-align: center;
        border: 2px dashed #adb5bd;
        flex-direction: column;
        margin: 0 auto 12px auto;
    }
    .no-photo-placeholder i {
        font-size: 2.5rem;
        margin-bottom: 4px;
        color: #6c757d;
    }

    /* ========== ISSUER PHOTO IN ALREADY ISSUED CARD ========== */
    .issuer-photo {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid var(--danger);
        background: #f8f9fa;
        flex-shrink: 0;
        margin-right: 12px;
    }
    .issuer-photo-placeholder {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: #f8d7da;
        border: 3px solid var(--danger);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--danger);
        font-size: 2.5rem;
        flex-shrink: 0;
        margin-right: 12px;
    }

    /* ========== BOOK COVER ========== */
    .book-cover-left {
        max-width: 100px;
        max-height: 140px;
        object-fit: contain;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-right: 15px;
        float: left;
    }
    .book-cover-left-placeholder {
        width: 80px;
        height: 110px;
        background: #f8f9fa;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        float: left;
        margin-right: 15px;
        border: 1px solid #dee2e6;
    }
    .book-details-text {
        overflow: hidden;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: var(--primary-color);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-success {
        background: linear-gradient(135deg, #28a745, #20c997) !important;
    }
    .card-custom .card-header.bg-danger {
        background: linear-gradient(135deg, #dc3545, #e74c3c) !important;
    }
    .card-custom .card-header.bg-purple {
        background: linear-gradient(135deg, #6f42c1, #8b5cf6) !important;
    }
    .card-custom .card-body {
        padding: 1.25rem;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }

    /* ========== MEMBER INFO CARD ========== */
    .member-info-card {
        padding: 12px;
        border-radius: 16px;
        transition: var(--transition);
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
        background: #f8f9fa;
        border-left: 4px solid var(--primary-color);
    }
    .member-info-card.alert-success {
        border-left-color: var(--success);
        background: #d1e7dd;
    }
    .member-info-card.alert-warning {
        border-left-color: var(--warning);
        background: #fff3cd;
    }
    .member-info-card.alert-danger {
        border-left-color: var(--danger);
        background: #f8d7da;
    }
    .member-details h5 {
        font-size: 1.2rem;
        font-weight: 700;
        margin-bottom: 0.3rem;
        color: var(--primary-color);
    }
    .member-details p {
        margin-bottom: 0.2rem;
        font-size: 0.9rem;
    }

    /* ========== BOOK STATUS BADGE ========== */
    .book-status-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-top: 6px;
    }
    .book-status-Available { background: #d4edda; color: #155724; }
    .book-status-Not-Available { background: #f8d7da; color: #721c24; }
    .book-status-Restricted { background: #fff3cd; color: #856404; }
    .book-status-Reference-Only { background: #cfe2ff; color: #084298; }
    .book-status-Removed { background: #e2e3e5; color: #383d41; }
    .book-status-Weeded-Out { background: #e2e3e5; color: #383d41; }
    .book-status-Missing { background: #f8d7da; color: #721c24; }
    .book-status-default { background: #e9ecef; color: #495057; }

    /* ========== SPECIAL ITEM ALERTS ========== */
    .alert-textbook, .alert-restricted {
        font-size: 20px;
        font-weight: bold;
        text-align: center;
        animation: blinkBg 0.5s ease-in-out 3;
        padding: 8px;
        border-radius: 8px;
    }
    .alert-textbook { background: #28a745; color: white; }
    .alert-restricted { background: #ffc107; color: #856404; border: 1px solid #ffc107; }
    @keyframes blinkBg { 
        0% { opacity: 1; } 
        50% { opacity: 0.6; } 
        100% { opacity: 1; } 
    }
    .special-item-notice {
        background-color: #fff3cd;
        border-left: 3px solid #ffc107;
        color: #856404;
        padding: 8px 12px;
        margin-top: 8px;
        border-radius: 6px;
        font-size: 0.85rem;
    }
    .ref-alert {
        background-color: #f8d7da;
        color: #721c24;
        padding: 8px;
        border-radius: 6px;
        text-align: center;
        margin-top: 8px;
        border: 1px solid #f5c6cb;
    }
    .ref-alert .top-line {
        font-size: 1.1rem;
        font-weight: bold;
        letter-spacing: 1px;
    }
    .ref-alert .bottom-line {
        font-size: 0.75rem;
        margin-top: 2px;
        opacity: 0.9;
    }

    /* ========== ALREADY ISSUED CARD ========== */
    .issued-detail {
        font-size: 0.85rem;
        margin-bottom: 5px;
    }
    .issued-label {
        font-weight: 600;
        color: #721c24;
    }
    .issued-user-info {
        display: flex;
        align-items: center;
        padding: 8px;
        background: #f8f9fa;
        border-radius: 8px;
        margin-bottom: 10px;
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 992px) {
        .member-photo-large { width: 100px; height: 100px; }
        .no-photo-placeholder { width: 100px; height: 100px; }
        .issuer-photo { width: 60px; height: 60px; }
        .issuer-photo-placeholder { width: 60px; height: 60px; font-size: 1.8rem; }
        .book-cover-left { max-width: 70px; max-height: 100px; }
        .book-cover-left-placeholder { width: 60px; height: 85px; }
    }

    @media (max-width: 768px) {
        .member-photo-large { width: 80px; height: 80px; }
        .no-photo-placeholder { width: 80px; height: 80px; font-size: 0.7rem; }
        .no-photo-placeholder i { font-size: 1.8rem; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .container-fluid { padding: 0 12px; }
    }

    @media (max-width: 576px) {
        .modal-dialog { margin: 10px; }
        .modal-content { border-radius: 12px; }
        .member-photo-large { width: 60px; height: 60px; }
        .no-photo-placeholder { width: 60px; height: 60px; font-size: 0.6rem; }
        .no-photo-placeholder i { font-size: 1.4rem; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .alert { display: none !important; }
    }
    </style>
</head>
<body>

<div class="container-fluid px-3 px-md-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-arrow-right me-2" style="color: var(--primary-color);"></i> Issue Book
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
                <?php if (!$isOpen && $enforceHours): ?>
                <span class="ms-2 text-danger"><i class="fas fa-lock"></i> Library Closed</span>
                <?php else: ?>
                <span class="ms-2 text-success"><i class="fas fa-check-circle"></i> Library Open</span>
                <?php endif; ?>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="return.php" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
            <a href="renew.php" class="btn btn-info btn-sm text-white"><i class="fas fa-sync-alt"></i> Renew</a>
            <a href="holds.php" class="btn btn-purple btn-sm"><i class="fas fa-hand-paper"></i> Holds</a>
            <a href="history.php" class="btn btn-secondary btn-sm"><i class="fas fa-history"></i> History</a>
        </div>
    </div>

    <?= $toast ?>
    
    <?php if (!$isOpen && $enforceHours): ?>
        <div class="alert alert-warning text-center py-3 mb-4">
            <i class="fas fa-clock fa-2x d-block mb-2"></i>
            <strong>Library is currently closed.</strong><br>
            Issuing books is disabled. Please come back during open hours.
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- LEFT COLUMN: Main Form -->
        <div class="col-lg-9">
            <div class="card-custom">
                <div class="card-header">
                    <span><i class="fas fa-arrow-right me-2"></i> Issue Book to Member</span>
                    <span class="badge bg-light text-dark"><?= ($isOpen && !$enforceHours) ? 'Open' : 'Closed' ?></span>
                </div>
                <div class="card-body p-3">
                    <form method="post" id="issueForm" <?= (!$isOpen && $enforceHours) ? 'onsubmit="return false;"' : '' ?>>
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="ref_permission" id="ref_permission" value="">
                        <input type="hidden" name="ref_password" id="ref_password" value="">
                        
                        <div class="row g-3">
                            <!-- Member Column -->
                            <div class="col-md-5">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-header bg-primary text-white py-2">
                                        <h6 class="mb-0"><i class="fas fa-user me-2"></i> Member Information</h6>
                                    </div>
                                    <div class="card-body p-3">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Adm/Mem Number *</label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                                                <input type="text" name="admno" id="admno" class="form-control" 
                                                       placeholder="Scan or enter barcode" required autofocus autocomplete="off"
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div id="memberInfo" class="mt-3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Book Column -->
                            <div class="col-md-7">
                                <div class="card h-100 border-0 shadow-sm">
                                    <div class="card-header bg-success text-white py-2">
                                        <h6 class="mb-0"><i class="fas fa-book me-2"></i> Book Information</h6>
                                    </div>
                                    <div class="card-body p-3">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold">Book Barcode *</label>
                                            <div class="input-group">
                                                <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                                                <input type="text" name="barcode" id="barcode" class="form-control" 
                                                       placeholder="Scan or enter barcode" autocomplete="off"
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div id="bookInfo" class="mt-3"></div>
                                        </div>

                                        <!-- ISBN Auto-fetch -->
                                        <div class="row g-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold">ISBN (Auto-fetch)</label>
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                                    <input type="text" name="isbn" id="isbn" class="form-control" 
                                                           placeholder="Enter ISBN to auto-fetch" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                                    <select id="fetchSourceSelect" class="form-select w-auto" style="max-width: 140px;">
                                                        <option value="auto">Auto</option>
                                                        <option value="openlibrary">OpenLibrary</option>
                                                        <option value="google">Google Books</option>
                                                        <?php if(getSettingValue('isbndb_api_key')): ?>
                                                        <option value="isbndb">ISBNdb</option>
                                                        <?php endif; ?>
                                                        <?php if(getSettingValue('worldcat_api_key')): ?>
                                                        <option value="worldcat">WorldCat</option>
                                                        <?php endif; ?>
                                                        <?php if($yazAvailable): ?>
                                                        <option value="z3950">Z39.50</option>
                                                        <?php endif; ?>
                                                    </select>
                                                    <button type="button" class="btn btn-info btn-sm" onclick="fetchFromSelectedSource()">
                                                        <i class="fas fa-sync-alt"></i> Fetch
                                                    </button>
                                                    <button type="button" class="btn btn-secondary btn-sm" onclick="fetchFromAllSources()">
                                                        <i class="fas fa-list"></i> All
                                                    </button>
                                                </div>
                                                <div id="apiStatus" class="small text-muted mt-1"></div>
                                            </div>
                                        </div>

                                        <!-- Book Details -->
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold">Title *</label>
                                                <input type="text" name="title" id="title" class="form-control" required
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-1">
                                            <div class="col-6">
                                                <label class="form-label fw-semibold">Author</label>
                                                <input type="text" name="author" id="author" class="form-control"
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label fw-semibold">Publisher</label>
                                                <input type="text" name="publisher" id="publisher" class="form-control"
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-1">
                                            <div class="col-6">
                                                <label class="form-label fw-semibold">Category</label>
                                                <input type="text" name="category" id="category" class="form-control"
                                                       <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div class="col-6">
                                                <label class="form-label fw-semibold">Item Category</label>
                                                <select name="item_category" id="item_category" class="form-select"
                                                        <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                                    <option value="General">General</option>
                                                    <option value="Reference">Reference</option>
                                                    <option value="Textbook">Textbook</option>
                                                    <option value="Textbooks">Textbooks</option>
                                                    <option value="Restricted">Restricted</option>
                                                    <option value="CD">CD</option>
                                                    <option value="MAPS">MAPS</option>
                                                    <option value="Furniture">Furniture</option>
                                                    <option value="Computer">Computer</option>
                                                </select>
                                                <small class="text-muted">Used for issue restrictions</small>
                                            </div>
                                        </div>
                                        <div class="mt-2">
                                            <label class="form-label fw-semibold">Notes</label>
                                            <textarea name="notes" class="form-control" rows="2" placeholder="Any additional notes..."
                                                      <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="text-center mt-4">
                            <button type="submit" name="issue" class="btn btn-gradient-primary px-5 py-2 fs-6" id="confirmIssueBtn"
                                    <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                <i class="fas fa-check-circle"></i> Confirm Issue
                            </button>
                            <a href="index.php" class="btn btn-secondary px-4 py-2 fs-6 ms-2">
                                <i class="fas fa-times-circle"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- RIGHT COLUMN: Sidebar -->
        <div class="col-lg-3">
            <!-- Library Hours -->
            <?php if (function_exists('getLibraryHoursHTML')): ?>
                <?= getLibraryHoursHTML() ?>
            <?php else: ?>
                <div class="card-custom mb-3">
                    <div class="card-body text-center text-muted small py-4">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <p>Library hours module not available.</p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Already Issued Card -->
            <div id="alreadyIssuedCard" style="display: none;" class="card-custom mb-3 border-danger">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-ban me-2"></i> <strong>⚠ Already Issued</strong>
                </div>
                <div class="card-body" id="alreadyIssuedContent">
                    <!-- Dynamically inserted -->
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="card-custom">
                <div class="card-header">
                    <span><i class="fas fa-info-circle me-2"></i> Quick Stats</span>
                </div>
                <div class="card-body p-3">
                    <?php
                    $stats = [
                        ['label' => 'Active Loans', 'value' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn(), 'icon' => 'book-open'],
                        ['label' => 'Overdue Books', 'value' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn(), 'icon' => 'exclamation-triangle'],
                        ['label' => 'Active Members', 'value' => $db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn(), 'icon' => 'users'],
                        ['label' => 'Available Books', 'value' => $db->query("SELECT SUM(available) FROM books")->fetchColumn(), 'icon' => 'check-circle'],
                    ];
                    foreach ($stats as $stat):
                    ?>
                    <div class="d-flex justify-content-between align-items-center py-1 border-bottom">
                        <span><i class="fas fa-<?= $stat['icon'] ?> me-2 text-primary"></i> <?= $stat['label'] ?></span>
                        <span class="fw-bold"><?= number_format($stat['value']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== REFERENCE PERMISSION MODAL ========== -->
<div class="modal fade" id="refPermissionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i> Reference Book – Permission Required</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>This book is marked as <strong>Reference</strong> (either by Item Category or Book Status). Reference books can only be issued with librarian permission.</p>
                <label class="form-label">Enter your librarian password to confirm:</label>
                <input type="password" class="form-control" id="refPasswordInput" placeholder="Librarian password">
                <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" id="refConfirmCheck">
                    <label class="form-check-label" for="refConfirmCheck">I confirm that I have permission to issue this reference book.</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-warning" id="confirmRefIssueBtn">Approve & Issue</button>
            </div>
        </div>
    </div>
</div>

<!-- ========== ALL SOURCES MODAL ========== -->
<div class="modal fade" id="allSourcesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: var(--primary-color); color: white;">
                <h5 class="modal-title"><i class="fas fa-list me-2"></i> Results from All Sources</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="allSourcesResults"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== CACHING ==========
const memberCache = new Map();
const bookCache = new Map();

let memberLoaded = false, bookLoaded = false, isSubmitting = false;
let currentBookData = null;
let currentItemCategory = '';
let currentBookStatus = '';
let currentIsIssued = false;

function escapeHtml(s) { if(!s) return ''; return s.replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m); }

// ========== MEMBER LOOKUP ==========
const memberInput = document.getElementById('admno');
function lookupMember() {
    const admno = memberInput.value.trim();
    if (admno.length < 3) return;

    if (memberCache.has(admno)) {
        displayMember(memberCache.get(admno));
        return;
    }

    fetch('issue.php?ajax_member=1&admno=' + encodeURIComponent(admno))
        .then(r => r.json())
        .then(data => {
            memberCache.set(admno, data);
            displayMember(data);
        });
}

function displayMember(data) {
    const infoDiv = document.getElementById('memberInfo');
    if (data && data.name) {
        memberLoaded = true;
        const activeBooks = data.active_books || 0;
        const maxBooksVal = <?= (int)($settings['max_books'] ?? 5) ?>;
        const canIssue = activeBooks < maxBooksVal;
        const alertClass = canIssue ? 'alert-success' : 'alert-warning';
        
        let photoHtml = '';
        if (data.photo_base64) {
            photoHtml = `<img src="${data.photo_base64}" class="member-photo-large" alt="Member Photo" loading="lazy">`;
        } else {
            photoHtml = `<div class="no-photo-placeholder"><i class="fas fa-user-circle"></i><span>No Photo</span></div>`;
        }
        
        let emailHtml = data.email ? `<i class="fas fa-envelope"></i> ${escapeHtml(data.email)}` : '';
        let phoneHtml = data.phone ? `<i class="fas fa-phone"></i> ${escapeHtml(data.phone)}` : '';
        
        infoDiv.innerHTML = `
            <div class="member-info-card ${alertClass} p-3">
                ${photoHtml}
                <div class="member-details">
                    <h5><i class="fas fa-id-card"></i> ${escapeHtml(data.name)}</h5>
                    <p><i class="fas fa-tag"></i> <strong>Category:</strong> ${escapeHtml(data.member_category)}</p>
                    <p><i class="fas fa-graduation-cap"></i> <strong>Class:</strong> ${escapeHtml(data.class)} &nbsp;|&nbsp; <strong>Div:</strong> ${escapeHtml(data.division)}</p>
                    <p><i class="fas fa-book-open"></i> <strong>Active Books:</strong> ${activeBooks} / ${maxBooksVal}</p>
                    ${emailHtml ? `<p>${emailHtml}</p>` : ''}
                    ${phoneHtml ? `<p>${phoneHtml}</p>` : ''}
                    ${!canIssue ? '<p class="text-danger fw-bold"><i class="fas fa-exclamation-triangle"></i> ⚠ Cannot issue - maximum books reached!</p>' : ''}
                </div>
            </div>
        `;
        
        if (bookLoaded && canIssue && !currentIsIssued && !isSubmitting) attemptAutoIssue();
    } else {
        memberLoaded = false;
        infoDiv.innerHTML = '<div class="alert alert-danger text-center py-2"><i class="fas fa-exclamation-triangle"></i> Member not found or inactive</div>';
    }
}

// ========== BOOK LOOKUP ==========
const bookInput = document.getElementById('barcode');
let bookLookupTimer = null;

function lookupBook() {
    const barcode = bookInput.value.trim();
    if (barcode.length < 3) {
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmIssueBtn').disabled = true;
        return;
    }

    if (bookLookupTimer) {
        clearTimeout(bookLookupTimer);
        bookLookupTimer = null;
    }

    if (bookCache.has(barcode)) {
        displayBook(bookCache.get(barcode));
        return;
    }

    document.getElementById('bookInfo').innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> Searching for book...</div>';

    fetch('issue.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            bookCache.set(barcode, data);
            displayBook(data);
        })
        .catch(err => {
            console.error('Book lookup error:', err);
            document.getElementById('bookInfo').innerHTML = '<div class="alert alert-danger">Error searching for book.</div>';
        });
}

function displayBook(data) {
    const infoDiv = document.getElementById('bookInfo');
    if (data && data.title) {
        // Fill form fields
        document.getElementById('title').value = data.title;
        document.getElementById('author').value = data.author || '';
        document.getElementById('publisher').value = data.publisher || '';
        document.getElementById('category').value = data.category || '';
        document.getElementById('isbn').value = data.isbn || '';
        document.getElementById('item_category').value = data.item_category || 'General';
        
        currentBookData = data;
        currentItemCategory = data.item_category || 'General';
        currentBookStatus = data.book_status || 'Available';
        currentIsIssued = data.is_issued === true;
        
        const available = data.available || 0;
        const quantity = data.quantity || 1;
        
        // Status badge
        let statusClass = 'book-status-default';
        const statusMap = {
            'Available': 'book-status-Available',
            'Not Available': 'book-status-Not-Available',
            'Restricted': 'book-status-Restricted',
            'Reference Only': 'book-status-Reference-Only',
            'Removed': 'book-status-Removed',
            'Weeded Out': 'book-status-Weeded-Out',
            'Missing': 'book-status-Missing'
        };
        statusClass = statusMap[currentBookStatus] || 'book-status-default';
        const statusHtml = `<div class="book-status-badge ${statusClass}"><i class="fas fa-info-circle"></i> Status: ${escapeHtml(currentBookStatus)}</div>`;
        
        // Cover
        let coverHtml = '';
        if (data.cover_base64) {
            coverHtml = `<img src="${data.cover_base64}" class="book-cover-left" alt="Book Cover" loading="lazy">`;
        } else {
            coverHtml = `<div class="book-cover-left-placeholder"><i class="fas fa-book fa-3x text-muted"></i></div>`;
        }
        
        const availabilityIcon = (available > 0 && !currentIsIssued) ? 'fa-check-circle' : 'fa-times-circle';
        const alertClass = (available > 0 && !currentIsIssued) ? 'alert-success' : 'alert-danger';
        
        let html = `<div class="alert ${alertClass} py-2 px-3 book-info-clearfix">
                        ${coverHtml}
                        <div class="book-details-text">
                            <i class="fas ${availabilityIcon}"></i> 
                            <strong>${escapeHtml(data.title)}</strong><br>
                            <i class="fas fa-user-edit"></i> Author: ${escapeHtml(data.author || 'Unknown')}<br>
                            <i class="fas fa-building"></i> Publisher: ${escapeHtml(data.publisher || 'Unknown')}<br>
                            <i class="fas fa-tag"></i> Category: ${escapeHtml(data.category || 'Uncategorized')}<br>
                            <i class="fas fa-tag"></i> Item Category: ${escapeHtml(currentItemCategory)}<br>
                            <i class="fas fa-copy"></i> Available: ${available} / ${quantity}<br>
                            ${statusHtml}
                            ${available < 1 ? '<br><span class="text-danger fw-bold">⚠ Book not available!</span>' : ''}
                        </div>
                    </div>`;
        
        // Already issued card
        const alreadyIssuedCard = document.getElementById('alreadyIssuedCard');
        const alreadyIssuedContent = document.getElementById('alreadyIssuedContent');
        const confirmBtn = document.getElementById('confirmIssueBtn');
        
        if (currentIsIssued) {
            let issuerPhotoHtml = '';
            if (data.issued_member_photo_base64) {
                issuerPhotoHtml = `<img src="${data.issued_member_photo_base64}" class="issuer-photo" alt="Member Photo" loading="lazy">`;
            } else {
                issuerPhotoHtml = `<div class="issuer-photo-placeholder"><i class="fas fa-user"></i></div>`;
            }
            alreadyIssuedContent.innerHTML = `
                <div class="issued-user-info">
                    ${issuerPhotoHtml}
                    <div class="issued-details-container">
                        <div class="issued-detail"><span class="issued-label">👤 Issued to:</span> <strong>${escapeHtml(data.issued_member)}</strong></div>
                        <div class="issued-detail"><span class="issued-label">📛 Adm No:</span> ${escapeHtml(data.issued_admno)}</div>
                    </div>
                </div>
                <div class="issued-detail"><span class="issued-label">📖 Book:</span> ${escapeHtml(data.title)}</div>
                <div class="issued-detail"><span class="issued-label">📅 Issue Date:</span> ${data.issue_date}</div>
                <div class="issued-detail"><span class="issued-label">📆 Due Date:</span> ${data.due_date}</div>
                <div class="issued-detail text-danger mt-2"><i class="fas fa-exclamation-triangle"></i> <strong>⚠ This book is already issued.</strong><br>Please return it before issuing again.</div>
            `;
            alreadyIssuedCard.style.display = 'block';
            confirmBtn.disabled = true;
            bookLoaded = false;
        } else {
            alreadyIssuedCard.style.display = 'none';
            confirmBtn.disabled = false;
            bookLoaded = true;
        }
        
        // Special item alerts
        if (currentItemCategory === 'Restricted') {
            html += `<div class="alert-restricted mt-1 p-2 rounded"><i class="fas fa-ban"></i> 🚫 RESTRICTED 🚫</div>`;
            bookLoaded = false;
        } else if (currentItemCategory === 'Reference' || currentBookStatus === 'Reference Only') {
            html += `<div class="ref-alert mt-1">
                        <div class="top-line">⭐ ❌ REFERENCE ⭐</div>
                        <div class="bottom-line">Permission Required</div>
                    </div>`;
        } else if (currentItemCategory === 'Textbook' || currentItemCategory === 'Textbooks') {
            html += `<div class="alert-textbook mt-1 p-2 rounded"><i class="fas fa-book"></i> 📘 TEXT BOOK</div>`;
        } else if (['CD', 'MAPS', 'Furniture', 'Computer'].includes(currentItemCategory)) {
            html += `<div class="special-item-notice"><i class="fas fa-info-circle"></i> <strong>Notice:</strong> This is a <strong>${currentItemCategory}</strong> item. Please handle with care.</div>`;
        }
        
        infoDiv.innerHTML = html;
        
        const canIssueStatus = (currentBookStatus === 'Available' || currentBookStatus === 'Reference Only') && !currentIsIssued;
        if (!canIssueStatus) bookLoaded = false;
        if (memberLoaded && bookLoaded && !isSubmitting) attemptAutoIssue();
    } else {
        // New book
        bookLoaded = false;
        currentIsIssued = false;
        document.getElementById('confirmIssueBtn').disabled = false;
        document.getElementById('alreadyIssuedCard').style.display = 'none';
        infoDiv.innerHTML = '<div class="alert alert-info text-center py-2"><i class="fas fa-info-circle"></i> New book - will be added upon issue. Please fill the book details below.</div>';
    }
}

function attemptAutoIssue() {
    if (!memberLoaded || !bookLoaded) return;
    if (!currentBookData) return;
    let canIssue = (currentBookData.available > 0 && currentItemCategory !== 'Restricted' && !currentIsIssued);
    if (currentBookStatus !== 'Available' && currentBookStatus !== 'Reference Only') canIssue = false;
    if ((currentItemCategory === 'Reference' || currentBookStatus === 'Reference Only')) {
        showReferenceModal();
        return;
    }
    if (canIssue && !isSubmitting) {
        isSubmitting = true;
        setTimeout(() => document.getElementById('confirmIssueBtn').click(), 500);
    }
}

// ========== REFERENCE MODAL ==========
function showReferenceModal() {
    new bootstrap.Modal(document.getElementById('refPermissionModal')).show();
}

document.getElementById('confirmRefIssueBtn').addEventListener('click', function() {
    const password = document.getElementById('refPasswordInput').value;
    const confirm = document.getElementById('refConfirmCheck').checked;
    if (!confirm) { alert('Please confirm you have permission to issue this reference book.'); return; }
    if (!password) { alert('Please enter your librarian password.'); return; }
    document.getElementById('ref_password').value = password;
    document.getElementById('ref_permission').value = 'yes';
    bootstrap.Modal.getInstance(document.getElementById('refPermissionModal')).hide();
    document.getElementById('confirmIssueBtn').click();
});

// ========== ISBN FETCH ==========
function fetchFromSelectedSource() {
    const isbn = document.getElementById('isbn').value.trim();
    if (isbn.length < 10) {
        document.getElementById('apiStatus').innerHTML = '<span class="text-danger">Please enter a valid ISBN</span>';
        return;
    }
    const source = document.getElementById('fetchSourceSelect').value;
    document.getElementById('apiStatus').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from ' + source + '...';
    fetch('issue.php?ajax_isbn=1&isbn=' + encodeURIComponent(isbn) + '&source=' + encodeURIComponent(source))
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                applySourceData(data.data);
                document.getElementById('apiStatus').innerHTML = '<span class="text-success">✅ Data fetched from ' + source + '</span>';
            } else {
                document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ ' + data.error + '</span>';
            }
        })
        .catch(err => {
            document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ Error: ' + err.message + '</span>';
        });
}

function fetchFromAllSources() {
    const isbn = document.getElementById('isbn').value.trim();
    if (isbn.length < 10) {
        document.getElementById('apiStatus').innerHTML = '<span class="text-danger">Please enter a valid ISBN</span>';
        return;
    }
    document.getElementById('apiStatus').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from all sources...';
    fetch('issue.php?ajax_isbn=1&isbn=' + encodeURIComponent(isbn) + '&all=1')
        .then(r => r.json())
        .then(data => {
            const modal = new bootstrap.Modal(document.getElementById('allSourcesModal'));
            const resultsDiv = document.getElementById('allSourcesResults');
            if (data.success && data.results) {
                let html = '<div class="list-group">';
                let count = 0;
                for (const [source, result] of Object.entries(data.results)) {
                    if (result.title) {
                        count++;
                        html += `<div class="list-group-item list-group-item-action">
                            <h6 class="mb-1"><i class="fas fa-check-circle text-success"></i> <strong>${source}</strong></h6>
                            <p class="mb-1"><strong>Title:</strong> ${escapeHtml(result.title)}</p>
                            <p class="mb-1"><strong>Author:</strong> ${escapeHtml(result.author)}</p>
                            <p class="mb-1"><strong>Publisher:</strong> ${escapeHtml(result.publisher)}</p>
                            <button class="btn btn-sm btn-primary mt-1" onclick="applySourceData(${JSON.stringify(result).replace(/"/g, '&quot;')})">Use This</button>
                        </div>`;
                    }
                }
                html += '</div>';
                resultsDiv.innerHTML = count > 0 ? html : '<div class="alert alert-warning">No results found from any source.</div>';
                document.getElementById('apiStatus').innerHTML = '<span class="text-success">✅ Found ' + count + ' results</span>';
            } else {
                resultsDiv.innerHTML = '<div class="alert alert-danger">' + (data.error || 'No results found') + '</div>';
            }
            modal.show();
        })
        .catch(err => {
            document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ Error: ' + err.message + '</span>';
        });
}

function applySourceData(data) {
    if (data.title) document.getElementById('title').value = data.title;
    if (data.author) document.getElementById('author').value = data.author;
    if (data.publisher) document.getElementById('publisher').value = data.publisher;
    if (data.category) document.getElementById('category').value = data.category;
    if (data.cover_url) {
        const infoDiv = document.getElementById('bookInfo');
        infoDiv.innerHTML += `<div class="mt-2"><img src="${data.cover_url}" style="max-height:100px; border-radius:4px; box-shadow:0 2px 8px rgba(0,0,0,0.1);"></div>`;
    }
}

// ========== EVENT LISTENERS ==========
memberInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); lookupMember(); }
});
memberInput.addEventListener('blur', function() {
    if (this.value.trim().length >= 3) lookupMember();
});

bookInput.addEventListener('input', function() {
    if (bookLookupTimer) { clearTimeout(bookLookupTimer); bookLookupTimer = null; }
    const barcode = this.value.trim();
    if (barcode.length >= 3) {
        bookLookupTimer = setTimeout(lookupBook, 300);
    } else {
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmIssueBtn').disabled = true;
        document.getElementById('alreadyIssuedCard').style.display = 'none';
    }
});
bookInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); if (bookLookupTimer) clearTimeout(bookLookupTimer); lookupBook(); }
});
bookInput.addEventListener('blur', function() {
    if (this.value.trim().length >= 3) lookupBook();
});

window.addEventListener('load', function() {
    document.getElementById('barcode').focus();
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
});
</script>

<?php renderFooter(); ?>