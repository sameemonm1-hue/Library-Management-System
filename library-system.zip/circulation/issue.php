<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// ========== HELPER: GET SINGLE SETTING ==========
if (!function_exists('getSettingValue')) {
    function getSettingValue($key) {
        $settings = getSettings();
        return $settings[$key] ?? null;
    }
}

// ========== IMAGE HELPER (base64) ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== METADATA FETCHERS ==========
function fetchViaOpenLibrary($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (empty($isbn)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "https://openlibrary.org/api/books?bibkeys=ISBN:" . $isbn . "&format=json&jscmd=data";
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    $key = "ISBN:" . $isbn;
    if (isset($data[$key])) {
        $book = $data[$key];
        $result['title'] = $book['title'] ?? '';
        $result['author'] = $book['authors'][0]['name'] ?? '';
        $result['publisher'] = $book['publishers'][0]['name'] ?? '';
        $result['year'] = $book['publish_date'] ?? '';
        $result['pages'] = $book['number_of_pages'] ?? 0;
        $result['cover_url'] = $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
        $result['category'] = $book['subjects'][0]['name'] ?? '';
        $result['summary'] = isset($book['description']) ? (is_array($book['description']) ? ($book['description']['value'] ?? '') : $book['description']) : '';
    }
    return $result;
}

function fetchViaGoogleBooks($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (empty($isbn)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    if (isset($data['items'][0]['volumeInfo'])) {
        $info = $data['items'][0]['volumeInfo'];
        $result['title'] = $info['title'] ?? '';
        $result['author'] = $info['authors'][0] ?? '';
        $result['publisher'] = $info['publisher'] ?? '';
        $result['year'] = $info['publishedDate'] ?? '';
        $result['pages'] = $info['pageCount'] ?? 0;
        $result['summary'] = $info['description'] ?? '';
        $result['category'] = $info['categories'][0] ?? '';
        $result['cover_url'] = $info['imageLinks']['thumbnail'] ?? '';
    }
    return $result;
}

function fetchViaISBNdb($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    $apiKey = getSettingValue('isbndb_api_key');
    if (empty($apiKey)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true, 'header' => "Authorization: " . $apiKey]]);
    $url = "https://api2.isbndb.com/book/" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $data = json_decode($response, true);
    if (isset($data['book'])) {
        $book = $data['book'];
        $result['title'] = $book['title'] ?? '';
        $result['author'] = $book['authors'] ? implode(', ', $book['authors']) : '';
        $result['publisher'] = $book['publisher'] ?? '';
        $result['year'] = $book['date_published'] ?? '';
        $result['pages'] = $book['pages'] ?? 0;
        $result['summary'] = $book['synopsis'] ?? '';
        $result['category'] = $book['subject'] ?? '';
        $result['cover_url'] = $book['image'] ?? '';
    }
    return $result;
}

function fetchViaWorldCat($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    $apiKey = getSettingValue('worldcat_api_key');
    if (empty($apiKey)) return $result;
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "http://www.worldcat.org/webservices/catalog/content/isbn/" . $isbn . "?wskey=" . $apiKey . "&format=xml";
    $response = @file_get_contents($url, false, $ctx);
    if ($response === false) return $result;
    $xml = @simplexml_load_string($response);
    if ($xml) {
        $namespaces = $xml->getNamespaces(true);
        $dc = $namespaces['dc'] ?? '';
        if ($dc) {
            $result['title'] = (string)$xml->children($dc)->title ?? '';
            $result['author'] = (string)$xml->children($dc)->creator ?? '';
            $result['publisher'] = (string)$xml->children($dc)->publisher ?? '';
            $result['year'] = (string)$xml->children($dc)->date ?? '';
        }
    }
    return $result;
}

$yazAvailable = extension_loaded('yaz');
$z39Targets = [
    ['host' => 'z3950.loc.gov', 'port' => 7090, 'database' => 'voyager'],
    ['host' => 'z3950.fcla.edu', 'port' => 7090, 'database' => 'FCL01'],
];

function fetchViaZ3950($isbn) {
    $result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => '', 'category' => ''];
    if (!extension_loaded('yaz')) return $result;
    global $z39Targets;
    foreach ($z39Targets as $target) {
        try {
            $conn = yaz_connect($target['host'] . ':' . $target['port'] . '/' . $target['database']);
            if (!$conn) continue;
            yaz_syntax($conn, 'marc21');
            yaz_range($conn, 1, 10);
            yaz_search($conn, 'rpn', '@attr 1=7 ' . $isbn);
            yaz_wait();
            $error = yaz_error($conn);
            if ($error) continue;
            $recs = yaz_record($conn, 1, 'array');
            if ($recs) {
                $fields = $recs['fields'] ?? [];
                foreach ($fields as $field) {
                    if ($field['tag'] == '245') {
                        $subfields = $field['subfields'] ?? [];
                        $title = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'a') $title = $sf['data'];
                        }
                        $result['title'] = $title;
                    }
                    if ($field['tag'] == '100') {
                        $subfields = $field['subfields'] ?? [];
                        $author = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'a') $author = $sf['data'];
                        }
                        $result['author'] = $author;
                    }
                    if ($field['tag'] == '260') {
                        $subfields = $field['subfields'] ?? [];
                        $publisher = '';
                        $year = '';
                        foreach ($subfields as $sf) {
                            if ($sf['code'] == 'b') $publisher = $sf['data'];
                            if ($sf['code'] == 'c') $year = $sf['data'];
                        }
                        $result['publisher'] = $publisher;
                        $result['year'] = $year;
                    }
                }
                if (!empty($result['title'])) break;
            }
        } catch (Exception $e) {
            continue;
        }
    }
    return $result;
}

function fetchBookMetadata($isbn, $source = 'auto') {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return null;
    
    if ($source === 'auto') {
        $sources = ['openlibrary', 'google', 'isbndb', 'worldcat', 'z3950'];
        foreach ($sources as $src) {
            $result = null;
            switch ($src) {
                case 'openlibrary': $result = fetchViaOpenLibrary($isbn); break;
                case 'google': $result = fetchViaGoogleBooks($isbn); break;
                case 'isbndb': $result = fetchViaISBNdb($isbn); break;
                case 'worldcat': $result = fetchViaWorldCat($isbn); break;
                case 'z3950': $result = fetchViaZ3950($isbn); break;
            }
            if ($result && !empty($result['title'])) return $result;
        }
        return null;
    }
    
    switch ($source) {
        case 'openlibrary': return fetchViaOpenLibrary($isbn);
        case 'google': return fetchViaGoogleBooks($isbn);
        case 'isbndb': return fetchViaISBNdb($isbn);
        case 'worldcat': return fetchViaWorldCat($isbn);
        case 'z3950': return fetchViaZ3950($isbn);
        default: return null;
    }
}

function fetchAllSources($isbn) {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return [];
    $results = [];
    $sources = ['openlibrary', 'google', 'isbndb', 'worldcat', 'z3950'];
    foreach ($sources as $src) {
        $result = null;
        switch ($src) {
            case 'openlibrary': $result = fetchViaOpenLibrary($isbn); break;
            case 'google': $result = fetchViaGoogleBooks($isbn); break;
            case 'isbndb': $result = fetchViaISBNdb($isbn); break;
            case 'worldcat': $result = fetchViaWorldCat($isbn); break;
            case 'z3950': $result = fetchViaZ3950($isbn); break;
        }
        if ($result && !empty($result['title'])) {
            $results[$src] = $result;
        }
    }
    return $results;
}

// ========== LIBRARY HOURS ENFORCEMENT ==========
$settings = getSettings();
$enforceHours = (int)($settings['enforce_library_hours'] ?? 1);
$isOpen = true;
if ($enforceHours && function_exists('isLibraryOpen')) {
    $isOpen = isLibraryOpen();
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$toast = '';

// ========== DISPLAY WARNING IF LIBRARY CLOSED ==========
if (!$isOpen && $enforceHours) {
    $toast .= '<div class="alert alert-danger alert-dismissible fade show mb-3">
        <i class="fas fa-clock"></i> <strong>Library is currently closed.</strong> 
        Issuing books is not allowed at this time.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>';
}

// ---------- OPTIMISED AJAX HANDLERS ----------
if (isset($_GET['ajax_member'])) {
    $admno = trim($_GET['admno']);
    $stmt = $db->prepare("SELECT admno, name, member_category, class, division, active_books, photo_path, email, phone 
                          FROM members WHERE admno = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$admno]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($member && !empty($member['photo_path'])) {
        $photoPath = $member['photo_path'];
        if (strpos($photoPath, 'uploads/') === 0) {
            $fullPath = BASE_PATH . '/' . $photoPath;
        } elseif (strpos($photoPath, '/') !== 0 && strpos($photoPath, ':\\') === false) {
            $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
        } else {
            $fullPath = $photoPath;
        }
        if (file_exists($fullPath)) {
            $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
            $mime = 'image/jpeg';
            if ($ext == 'png') $mime = 'image/png';
            elseif ($ext == 'gif') $mime = 'image/gif';
            elseif ($ext == 'webp') $mime = 'image/webp';
            $member['photo_base64'] = 'data:' . $mime . ';base64,' . base64_encode(file_get_contents($fullPath));
        }
    }
    header('Content-Type: application/json');
    echo json_encode($member ?? null);
    exit;
}

if (isset($_GET['ajax_book'])) {
    $barcode = trim($_GET['barcode']);
    $bookStmt = $db->prepare("SELECT barcode, title, author, publisher, category, isbn, 
                                     item_category, book_status, available, quantity, cover_path 
                              FROM books WHERE barcode = ? LIMIT 1");
    $bookStmt->execute([$barcode]);
    $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($book) {
        // --- REMOVED THE DANGEROUS RESET BLOCK THAT SET available = quantity ---
        // --- USE BASE64 FOR COVER ---
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
        unset($book['cover_path']); // clean up
        $book['book_status'] = $book['book_status'] ?? 'Available';
        
        $issuedStmt = $db->prepare("SELECT c.issue_date, c.due_date, m.name as member_name, m.admno as member_admno, 
                                           m.photo_path as member_photo_path
                                    FROM circulation c 
                                    LEFT JOIN members m ON c.admno = m.admno 
                                    WHERE c.barcode = ? AND c.return_date IS NULL LIMIT 1");
        $issuedStmt->execute([$barcode]);
        $issued = $issuedStmt->fetch(PDO::FETCH_ASSOC);
        if ($issued) {
            $book['is_issued'] = true;
            $book['issued_member'] = $issued['member_name'];
            $book['issued_admno'] = $issued['member_admno'];
            $book['issue_date'] = $issued['issue_date'];
            $book['due_date'] = $issued['due_date'];
            $book['issued_member_photo_base64'] = getImageBase64($issued['member_photo_path'] ?? '');
        } else {
            $book['is_issued'] = false;
        }
    }
    header('Content-Type: application/json');
    echo json_encode($book ?? null);
    exit;
}

// ISBN metadata AJAX
if (isset($_GET['ajax_isbn'])) {
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    $source = $_GET['source'] ?? 'auto';
    $all = $_GET['all'] ?? false;
    header('Content-Type: application/json');
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    if ($all) {
        $results = fetchAllSources($isbn);
        echo json_encode(['success' => true, 'results' => $results]);
    } else {
        $result = fetchBookMetadata($isbn, $source);
        if ($result) {
            echo json_encode(['success' => true, 'data' => $result]);
        } else {
            echo json_encode(['success' => false, 'error' => 'No metadata found']);
        }
    }
    exit;
}

// ========== HANDLE ISSUE SUBMISSION ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['issue'])) {
    if (!$isOpen && $enforceHours) {
        $toast = '<div class="alert alert-danger">❌ Cannot issue books – library is currently closed.</div>';
    } 
    elseif (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            
            $stmt = $db->prepare("SELECT * FROM members WHERE admno = ? AND status = 'active'");
            $stmt->execute([$_POST['admno']]);
            $member = $stmt->fetch();
            if (!$member) throw new Exception("Member not found or inactive");
            
            $barcode = trim($_POST['barcode']);
            $isManual = 0;
            
            $bookStmt = $db->prepare("SELECT * FROM books WHERE barcode = ?");
            $bookStmt->execute([$barcode]);
            $book = $bookStmt->fetch();
            
            $activeIssueStmt = $db->prepare("SELECT c.*, m.name as member_name, m.admno as member_admno 
                                             FROM circulation c 
                                             LEFT JOIN members m ON c.admno = m.admno 
                                             WHERE c.barcode = ? AND c.return_date IS NULL");
            $activeIssueStmt->execute([$barcode]);
            $activeIssue = $activeIssueStmt->fetch();
            if ($activeIssue) {
                throw new Exception("Book is already issued to {$activeIssue['member_name']} (Adm No: {$activeIssue['member_admno']}). Please return it first before issuing again.");
            }
            
            $memberCat = $member['member_category'] ?? 'Student';
            $itemCat = $book ? ($book['item_category'] ?? 'General') : 'General';
            
            $categoryRulesEnabled = (int)($settings['enable_category_rules'] ?? 1);
            if ($categoryRulesEnabled && function_exists('getMemberMaxBooks') && function_exists('getMemberLoanDays') && function_exists('getMemberMaxRenewals') && function_exists('getMemberFinePerDay') && function_exists('getMemberMaxFineAmount')) {
                $maxLoans = getMemberMaxBooks($memberCat);
                $loanPeriod = getMemberLoanDays($memberCat);
                $finePerDay = getMemberFinePerDay($memberCat);
                $gracePeriod = 0;
            } else {
                $rule = getLoanRule($memberCat, $itemCat);
                if ($rule) {
                    $maxLoans = $rule['max_loans'];
                    $loanPeriod = $rule['loan_period'];
                    $finePerDay = $rule['fine_per_day'];
                    $gracePeriod = $rule['grace_period'];
                } else {
                    $maxLoans = $settings['max_books'] ?? 5;
                    $loanPeriod = $settings['loan_days'] ?? 14;
                    $finePerDay = $settings['fine_per_day'] ?? 2;
                    $gracePeriod = $settings['fine_grace_period'] ?? 0;
                }
            }
            
            $activeStmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL");
            $activeStmt->execute([$_POST['admno']]);
            $activeCount = $activeStmt->fetchColumn();
            if ($activeCount >= $maxLoans) {
                throw new Exception("Member already has maximum allowed books ({$maxLoans})");
            }
            
            if (!$book) {
                $isManual = 1;
                $coverPath = '';
                if (!empty($_POST['isbn'])) {
                    $apiData = fetchBookMetadata($_POST['isbn'], 'auto');
                    if ($apiData && $apiData['title']) {
                        if (empty($_POST['title'])) $_POST['title'] = $apiData['title'];
                        if (empty($_POST['author'])) $_POST['author'] = $apiData['author'];
                        if (empty($_POST['publisher'])) $_POST['publisher'] = $apiData['publisher'];
                        if (!empty($apiData['cover_url'])) {
                            if (function_exists('downloadCoverImage')) {
                                $coverPath = downloadCoverImage($apiData['cover_url'], $barcode);
                            } elseif (!empty($apiData['cover_url'])) {
                                $coverPath = $apiData['cover_url'];
                            }
                        }
                    }
                }
                $insert = $db->prepare("INSERT INTO books (barcode, isbn, title, author, publisher, category, quantity, available, cover_path, item_category, book_status) VALUES (?, ?, ?, ?, ?, ?, 1, 1, ?, ?, 'Available')");
                $insert->execute([$barcode, $_POST['isbn'] ?? '', $_POST['title'], $_POST['author'], $_POST['publisher'], $_POST['category'], $coverPath, $_POST['item_category'] ?? 'General']);
                $book = [
                    'title' => $_POST['title'], 'author' => $_POST['author'], 'isbn' => $_POST['isbn'] ?? '',
                    'publisher' => $_POST['publisher'], 'category' => $_POST['category'], 'available' => 1,
                    'item_category' => $_POST['item_category'] ?? 'General', 'quantity' => 1,
                    'book_status' => 'Available'
                ];
            }
            
            $bookStatus = $book['book_status'] ?? 'Available';
            $allowedStatuses = ['Available', 'Reference Only'];
            if (!in_array($bookStatus, $allowedStatuses)) {
                throw new Exception("This book has status '{$bookStatus}' and cannot be issued.");
            }
            
            $itemCategory = $book['item_category'] ?? 'General';
            if ($itemCategory == 'Restricted') {
                throw new Exception("This book is marked as 'RESTRICTED' and cannot be issued.");
            }
            
            if ($itemCategory == 'Reference' || $bookStatus == 'Reference Only') {
                if (empty($_POST['ref_permission']) || $_POST['ref_permission'] !== 'yes') {
                    throw new Exception("Reference books require librarian permission. Please ask the librarian to override.");
                }
                $adminPass = $_POST['ref_password'] ?? '';
                if (!empty($adminPass)) {
                    $userCheck = $db->prepare("SELECT password FROM users WHERE role IN ('admin','staff') LIMIT 1");
                    $userCheck->execute();
                    $adminHash = $userCheck->fetchColumn();
                    if (!password_verify($adminPass, $adminHash)) {
                        throw new Exception("Incorrect librarian password. Reference book cannot be issued.");
                    }
                }
            }
            
            if (!$isManual && $book['available'] < 1) {
                throw new Exception("Book not available for issue (no copies left).");
            }
            
            $dueDate = date("Y-m-d", strtotime("+{$loanPeriod} days"));
            
            $insert = $db->prepare("INSERT INTO circulation (admno, member_name, class, division, barcode, isbn, title, author, category, publisher, issue_date, due_date, notes, is_manual) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $insert->execute([
                $member['admno'], $member['name'], $member['class'] ?? '', $member['division'] ?? '',
                $barcode, $book['isbn'] ?? '', $book['title'], $book['author'] ?? '', $book['category'] ?? '',
                $book['publisher'] ?? '', date('Y-m-d'), $dueDate, $_POST['notes'] ?? '', $isManual
            ]);
            
            if (!$isManual) {
                $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$barcode]);
            }
            $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$member['admno']]);
            
            $db->commit();
            
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book issued successfully! Due Date: ' . formatDate($dueDate) . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            if ($isManual) $toast .= '<div class="alert alert-info alert-dismissible fade show">📚 Manual entry - book added to system<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            
            try {
                $checkCol = $db->query("PRAGMA table_info(activity_logs)")->fetchAll(PDO::FETCH_COLUMN, 1);
                if (in_array('user_agent', $checkCol)) {
                    logActivity($_SESSION['username'], 'BOOK_ISSUE', "Issued {$book['title']} to {$member['admno']}");
                } else {
                    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
                    $stmt = $db->prepare("INSERT INTO activity_logs (username, action, details, ip_address, created_at) VALUES (?, ?, ?, ?, datetime('now'))");
                    $stmt->execute([$_SESSION['username'], 'BOOK_ISSUE', "Issued {$book['title']} to {$member['admno']}", $ip]);
                }
            } catch (Exception $e) {
                // Silent fail for logging
            }
            
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Issue Book');
?>

<div class="container-fluid px-3 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-2 mb-3">
        <div>
            <a href="../index.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-home"></i> Back to Home</a>
            <a href="return.php" class="btn btn-outline-success btn-sm"><i class="fas fa-arrow-right"></i> Return Book</a>
            <a href="renew.php" class="btn btn-outline-warning btn-sm"><i class="fas fa-arrow-left"></i> Renew Book</a>
        </div>
        <div><span class="badge bg-primary fs-6">Issue Book</span></div>
    </div>

    <div class="row g-3">
        <!-- Left column: Main form (9 columns) -->
        <div class="col-lg-9">
            <?= $toast ?>
            
            <?php if (!$isOpen && $enforceHours): ?>
                <div class="alert alert-warning text-center py-2">
                    <i class="fas fa-clock"></i> <strong>Library is currently closed.</strong><br>
                    Issuing books is disabled. Please come back during open hours.
                </div>
            <?php endif; ?>
            
            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-header bg-primary text-white py-2">
                    <h5 class="mb-0"><i class="fas fa-arrow-right"></i> Issue Book to Member</h5>
                </div>
                <div class="card-body p-3">
                    <form method="post" id="issueForm" <?= (!$isOpen && $enforceHours) ? 'onsubmit="return false;"' : '' ?>>
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <input type="hidden" name="ref_permission" id="ref_permission" value="">
                        <input type="hidden" name="ref_password" id="ref_password" value="">
                        
                        <div class="row g-3">
                            <!-- Member Information Column -->
                            <div class="col-md-5 col-lg-5">
                                <div class="card h-100 border-primary member-info-card-container">
                                    <div class="card-header bg-primary text-white py-2">
                                        <h5 class="mb-0"><i class="fas fa-user"></i> Member Information</h5>
                                    </div>
                                    <div class="card-body p-3">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold fs-6">Adm/Mem Number *</label>
                                            <div class="input-group input-group-md">
                                                <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                                                <input type="text" name="admno" id="admno" class="form-control form-control-md" style="font-size: 1rem;" placeholder="Scan or enter barcode" required autofocus autocomplete="off" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div id="memberInfo" class="mt-3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Book Information Column -->
                            <div class="col-md-7 col-lg-7">
                                <div class="card h-100 border-success book-info-card-container">
                                    <div class="card-header bg-success text-white py-2">
                                        <h5 class="mb-0"><i class="fas fa-book"></i> Book Information</h5>
                                    </div>
                                    <div class="card-body p-3">
                                        <div class="mb-3">
                                            <label class="form-label fw-bold fs-6">Book Barcode *</label>
                                            <div class="input-group input-group-md">
                                                <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                                                <input type="text" name="barcode" id="barcode" class="form-control form-control-md" style="font-size: 1rem;" placeholder="Scan or enter barcode" autocomplete="off" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                            <div id="bookInfo" class="mt-3"></div>
                                        </div>
                                        <div class="row g-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">ISBN (Auto-fetch)</label>
                                                <div class="input-group input-group-md">
                                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                                    <input type="text" name="isbn" id="isbn" class="form-control form-control-md" style="font-size: 0.95rem;" placeholder="Enter ISBN to auto-fetch" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                                    <select id="fetchSourceSelect" class="form-select w-auto" style="max-width: 140px;">
                                                        <option value="auto">Auto</option>
                                                        <option value="openlibrary">OpenLibrary</option>
                                                        <option value="google">Google Books</option>
                                                        <?php if(getSettingValue('isbndb_api_key')): ?><option value="isbndb">ISBNdb</option><?php endif; ?>
                                                        <?php if(getSettingValue('worldcat_api_key')): ?><option value="worldcat">WorldCat</option><?php endif; ?>
                                                        <?php if($yazAvailable): ?><option value="z3950">Z39.50</option><?php endif; ?>
                                                    </select>
                                                    <button type="button" class="btn btn-info btn-md" onclick="fetchFromSelectedSource()"><i class="fas fa-sync-alt"></i> Fetch</button>
                                                    <button type="button" class="btn btn-secondary btn-md" onclick="fetchFromAllSources()"><i class="fas fa-list"></i> All</button>
                                                </div>
                                                <div id="apiStatus" class="small text-muted mt-1"></div>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">Title *</label>
                                                <input type="text" name="title" id="title" class="form-control form-control-md" style="font-size: 0.95rem;" required <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">Author</label>
                                                <input type="text" name="author" id="author" class="form-control form-control-md" style="font-size: 0.95rem;" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">Publisher</label>
                                                <input type="text" name="publisher" id="publisher" class="form-control form-control-md" style="font-size: 0.95rem;" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">Category</label>
                                                <input type="text" name="category" id="category" class="form-control form-control-md" style="font-size: 0.95rem;" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                            </div>
                                        </div>
                                        <div class="row g-2 mt-2">
                                            <div class="col-12">
                                                <label class="form-label fw-semibold fs-6">Item Category</label>
                                                <select name="item_category" id="item_category" class="form-select form-select-md" style="font-size: 0.95rem;" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>>
                                                    <option value="General">General</option>
                                                    <option value="Reference">Reference</option>
                                                    <option value="Textbook">Textbook</option>
                                                    <option value="Textbooks">Textbooks</option>
                                                    <option value="Restricted">Restricted</option>
                                                    <option value="CD">CD</option>
                                                    <option value="MAPS">MAPS</option>
                                                    <option value="Furniture">Furniture</option>
                                                    <option value="Computer">Computer</option>
                                                </select>
                                                <small class="text-muted" style="font-size: 0.8rem;">Used for issue restrictions and alerts.</small>
                                            </div>
                                        </div>
                                        <div class="mt-3">
                                            <label class="form-label fw-semibold fs-6">Notes</label>
                                            <textarea name="notes" class="form-control form-control-md" style="font-size: 0.95rem;" rows="2" placeholder="Any additional notes..." <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <button type="submit" name="issue" class="btn btn-primary px-4 py-2 fs-6" id="confirmIssueBtn" <?= (!$isOpen && $enforceHours) ? 'disabled' : '' ?>><i class="fas fa-check-circle"></i> Confirm Issue</button>
                            <a href="index.php" class="btn btn-secondary px-4 py-2 fs-6"><i class="fas fa-times-circle"></i> Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Right column: Library Hours Card + Already Issued Card -->
        <div class="col-lg-3">
            <?php if (function_exists('getLibraryHoursHTML')): ?>
                <?= getLibraryHoursHTML() ?>
            <?php else: ?>
                <div class="card border-0 shadow-sm rounded-3 mb-3">
                    <div class="card-body text-center text-muted small">
                        <i class="fas fa-clock"></i> Library hours module not available.
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- ========== ALREADY ISSUED CARD (Now with photo support) ========== -->
            <div id="alreadyIssuedCard" style="display: none;" class="card border-danger shadow-sm rounded-3 mb-3">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-ban"></i> <strong>⚠ ALREADY ISSUED</strong>
                </div>
                <div class="card-body" id="alreadyIssuedContent">
                    <!-- Content dynamically inserted by JavaScript with photo -->
                </div>
            </div>
            <!-- ========== END ALREADY ISSUED CARD ========== -->
        </div>
    </div>
</div>

<!-- Modal for Reference Book Permission -->
<div class="modal fade" id="refPermissionModal" tabindex="-1" aria-labelledby="refPermissionModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="refPermissionModalLabel"><i class="fas fa-exclamation-triangle"></i> Reference Book – Permission Required</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>This book is marked as <strong>Reference</strong> (either by Item Category or Book Status). Reference books can only be issued with librarian permission.</p>
                <label for="refPasswordInput" class="form-label">Enter your librarian password to confirm:</label>
                <input type="password" class="form-control" id="refPasswordInput" placeholder="Librarian password">
                <div class="form-check mt-2">
                    <input class="form-check-input" type="checkbox" id="refConfirmCheck">
                    <label class="form-check-label" for="refConfirmCheck">I confirm that I have permission to issue this reference book.</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-warning" id="confirmRefIssueBtn">Approve & Issue</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal for "Fetch from All Sources" results -->
<div class="modal fade" id="allSourcesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">Results from All Sources</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="allSourcesResults"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
/* ========== MEMBER PHOTO - LARGE, CLEAR & CENTERED ========== */
.member-photo-large {
    width: 140px;
    height: 140px;
    object-fit: cover;
    border-radius: 10%;
    border: 3px solid #ffffff;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    background-color: #f8f9fa;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    display: block;
    margin: 0 auto 12px auto;
}
.member-photo-large:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}
.no-photo-placeholder {
    width: 140px;
    height: 140px;
    background: #e9ecef;
    border-radius: 10%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 0.8rem;
    text-align: center;
    border: 1px dashed #adb5bd;
    flex-direction: column;
    margin: 0 auto 12px auto;
}
.no-photo-placeholder i {
    font-size: 2.5rem;
    margin-bottom: 4px;
    color: #6c757d;
}
/* ========== ISSUER PHOTO IN ALREADY ISSUED CARD ========== */
.issuer-photo {
    width: 80px;
    height: 80px;
    object-fit: cover;
    border-radius: 50%;
    border: 3px solid #dc3545;
    background: #f8f9fa;
    flex-shrink: 0;
    margin-right: 12px;
}
.issuer-photo-placeholder {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: #f8d7da;
    border: 3px solid #dc3545;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #dc3545;
    font-size: 2.5rem;
    flex-shrink: 0;
    margin-right: 12px;
}
.issued-details-container {
    flex: 1;
}
.book-cover-left {
    max-width: 100px;
    max-height: 140px;
    object-fit: contain;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-right: 15px;
    float: left;
}
.book-cover-left-placeholder {
    width: 80px;
    height: 110px;
    background: #f8f9fa;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    float: left;
    margin-right: 15px;
    border: 1px solid #dee2e6;
}
.book-details-text {
    overflow: hidden;
}
.member-info-card {
    padding: 12px;
    border-radius: 16px;
    transition: all 0.2s;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}
.member-info-card.alert-success {
    background-color: #d1e7dd;
    border-color: #badbcc;
}
.member-info-card.alert-warning {
    background-color: #fff3cd;
    border-color: #ffecb5;
}
.member-details h5 {
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 0.3rem;
    color: #1e466e;
}
.member-details p {
    margin-bottom: 0.2rem;
    font-size: 0.9rem;
}
.member-details .badge-info {
    background-color: #0d6efd;
    color: white;
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 0.75rem;
}
.card { border-radius: 12px; overflow: hidden; }
.card-header { font-weight: 600; padding: 0.5rem 1rem; }
.member-info-card-container .card-body,
.book-info-card-container .card-body {
    font-size: 0.95rem;
}
.member-info-card-container .form-label,
.book-info-card-container .form-label {
    font-size: 0.9rem;
}
.member-info-card-container input,
.book-info-card-container input,
.book-info-card-container select,
.book-info-card-container textarea {
    font-size: 0.95rem;
}
.special-item-notice {
    background-color: #fff3cd;
    border-left: 3px solid #ffc107;
    color: #856404;
    padding: 8px 12px;
    margin-top: 8px;
    border-radius: 6px;
    font-size: 0.85rem;
}
.special-item-notice i {
    margin-right: 6px;
    color: #e6a700;
}
.ref-alert {
    background-color: #f8d7da;
    color: #721c24;
    padding: 8px;
    border-radius: 6px;
    text-align: center;
    margin-top: 8px;
    border: 1px solid #f5c6cb;
}
.ref-alert .top-line {
    font-size: 1.1rem;
    font-weight: bold;
    letter-spacing: 1px;
}
.ref-alert .top-line .star {
    font-size: 1rem;
}
.ref-alert .bottom-line {
    font-size: 0.75rem;
    margin-top: 2px;
    opacity: 0.9;
}
.book-status-badge {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    margin-top: 6px;
}
.book-status-Available { background: #d4edda; color: #155724; }
.book-status-Not-Available { background: #f8d7da; color: #721c24; }
.book-status-Restricted { background: #fff3cd; color: #856404; }
.book-status-Reference-Only { background: #cfe2ff; color: #084298; }
.book-status-Removed { background: #e2e3e5; color: #383d41; }
.book-status-Weeded-Out { background: #e2e3e5; color: #383d41; }
.book-status-Missing { background: #f8d7da; color: #721c24; }
.book-status-default { background: #e9ecef; color: #495057; }
.alert-textbook, .alert-restricted {
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    animation: blinkBg 0.5s ease-in-out 3;
    padding: 8px;
}
.alert-textbook { background: #28a745; color: white; }
.alert-restricted { background: #ffc107; color: #856404; border: 1px solid #ffc107; }
@keyframes blinkBg { 0% { background-color: inherit; } 50% { background-color: rgba(0,0,0,0.1); } 100% { background-color: inherit; } }
#bookInfo .alert {
    text-align: left;
    font-size: 0.9rem;
    padding: 0.6rem;
}
.book-info-clearfix::after {
    content: "";
    clear: both;
    display: table;
}
/* Already issued card styling */
.issued-detail {
    font-size: 0.85rem;
    margin-bottom: 5px;
}
.issued-label {
    font-weight: 600;
    color: #721c24;
}
.issued-detail-text {
    font-size: 0.85rem;
}
.issued-user-info {
    display: flex;
    align-items: center;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 8px;
    margin-bottom: 10px;
}
</style>
<script>
// ========== CLIENT‑SIDE CACHING ==========
const memberCache = new Map();
const bookCache = new Map();

let memberLoaded = false, bookLoaded = false, isSubmitting = false;
let currentBookData = null;
let currentItemCategory = '';
let currentBookStatus = '';
let currentIsIssued = false;

function escapeHtml(s) { if(!s) return ''; return s.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;')); }

// Member lookup with caching
const memberInput = document.getElementById('admno');
function lookupMember() {
    const admno = memberInput.value.trim();
    if (admno.length < 3) return;

    if (memberCache.has(admno)) {
        displayMember(memberCache.get(admno));
        return;
    }

    fetch('issue.php?ajax_member=1&admno=' + encodeURIComponent(admno))
        .then(r => r.json())
        .then(data => {
            memberCache.set(admno, data);
            displayMember(data);
        });
}

function displayMember(data) {
    const infoDiv = document.getElementById('memberInfo');
    if (data && data.name) {
        memberLoaded = true;
        const activeBooks = data.active_books || 0;
        const maxBooksVal = <?= (int)($settings['max_books'] ?? 5) ?>;
        const canIssue = activeBooks < maxBooksVal;
        const alertClass = canIssue ? 'alert-success' : 'alert-warning';
        
        let photoHtml = '';
        if (data.photo_base64) {
            photoHtml = `<img src="${data.photo_base64}" class="member-photo-large" alt="Member Photo" loading="lazy">`;
        } else {
            photoHtml = `<div class="no-photo-placeholder"><i class="fas fa-user-circle fa-3x"></i><span>No Photo</span></div>`;
        }
        
        let emailHtml = data.email ? `<i class="fas fa-envelope"></i> ${escapeHtml(data.email)}` : '';
        let phoneHtml = data.phone ? `<i class="fas fa-phone"></i> ${escapeHtml(data.phone)}` : '';
        
        const detailsHtml = `
            <div class="member-details">
                <h5><i class="fas fa-id-card"></i> ${escapeHtml(data.name)}</h5>
                <p><i class="fas fa-tag"></i> <strong>Category:</strong> ${escapeHtml(data.member_category)}</p>
                <p><i class="fas fa-graduation-cap"></i> <strong>Class/Dept:</strong> ${escapeHtml(data.class)} &nbsp;|&nbsp; <strong>Div/Course:</strong> ${escapeHtml(data.division)}</p>
                <p><i class="fas fa-book-open"></i> <strong>Active Books:</strong> ${activeBooks} / ${maxBooksVal}</p>
                ${emailHtml ? `<p>${emailHtml}</p>` : ''}
                ${phoneHtml ? `<p>${phoneHtml}</p>` : ''}
                ${!canIssue ? '<p class="text-danger fw-bold"><i class="fas fa-exclamation-triangle"></i> ⚠ Cannot issue - maximum books reached!</p>' : ''}
            </div>
        `;
        
        infoDiv.innerHTML = `<div class="member-info-card alert ${alertClass} p-2">${photoHtml}${detailsHtml}</div>`;
        
        if (bookLoaded && canIssue && !currentIsIssued && !isSubmitting) attemptAutoIssue();
    } else {
        memberLoaded = false;
        infoDiv.innerHTML = '<div class="alert alert-danger text-center py-1 small"><i class="fas fa-exclamation-triangle"></i> Member not found or inactive</div>';
    }
}

// Book lookup with caching - FIXED for better barcode reading
const bookInput = document.getElementById('barcode');
let bookLookupTimer = null;

function lookupBook() {
    const barcode = bookInput.value.trim();
    if (barcode.length < 3) {
        // Clear book info if barcode is too short
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmIssueBtn').disabled = true;
        return;
    }

    // Clear any pending timer
    if (bookLookupTimer) {
        clearTimeout(bookLookupTimer);
        bookLookupTimer = null;
    }

    // Check cache first
    if (bookCache.has(barcode)) {
        displayBook(bookCache.get(barcode));
        return;
    }

    // Show loading indicator
    document.getElementById('bookInfo').innerHTML = '<div class="alert alert-info"><i class="fas fa-spinner fa-spin"></i> Searching for book...</div>';

    fetch('issue.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
        .then(r => r.json())
        .then(data => {
            bookCache.set(barcode, data);
            displayBook(data);
        })
        .catch(err => {
            console.error('Book lookup error:', err);
            document.getElementById('bookInfo').innerHTML = '<div class="alert alert-danger">Error searching for book. Please try again.</div>';
        });
}

function displayBook(data) {
    const infoDiv = document.getElementById('bookInfo');
    if (data && data.title) {
        // Fill form fields
        document.getElementById('title').value = data.title;
        document.getElementById('author').value = data.author || '';
        document.getElementById('publisher').value = data.publisher || '';
        document.getElementById('category').value = data.category || '';
        document.getElementById('isbn').value = data.isbn || '';
        document.getElementById('item_category').value = data.item_category || 'General';
        
        currentBookData = data;
        currentItemCategory = data.item_category || 'General';
        currentBookStatus = data.book_status || 'Available';
        currentIsIssued = data.is_issued === true;
        
        const available = data.available || 0;
        const quantity = data.quantity || 1;
        
        // Status badge
        let statusClass = 'book-status-default';
        const statusMap = {
            'Available': 'book-status-Available',
            'Not Available': 'book-status-Not-Available',
            'Restricted': 'book-status-Restricted',
            'Reference Only': 'book-status-Reference-Only',
            'Removed': 'book-status-Removed',
            'Weeded Out': 'book-status-Weeded-Out',
            'Missing': 'book-status-Missing'
        };
        statusClass = statusMap[currentBookStatus] || 'book-status-default';
        const statusHtml = `<div class="book-status-badge ${statusClass}"><i class="fas fa-info-circle"></i> Status: ${escapeHtml(currentBookStatus)}</div>`;
        
        // Cover on left side - use base64 if available
        let coverHtml = '';
        if (data.cover_base64) {
            coverHtml = `<img src="${data.cover_base64}" class="book-cover-left" alt="Book Cover" loading="lazy">`;
        } else {
            coverHtml = `<div class="book-cover-left-placeholder"><i class="fas fa-book fa-3x text-muted"></i></div>`;
        }
        
        const availabilityIcon = (available > 0 && !currentIsIssued) ? 'fa-check-circle' : 'fa-times-circle';
        const alertClass = (available > 0 && !currentIsIssued) ? 'alert-success' : 'alert-danger';
        
        let html = `<div class="alert ${alertClass} py-2 px-3 book-info-clearfix">
                        ${coverHtml}
                        <div class="book-details-text">
                            <i class="fas ${availabilityIcon}"></i> 
                            <strong>${escapeHtml(data.title)}</strong><br>
                            <i class="fas fa-user-edit"></i> Author: ${escapeHtml(data.author || 'Unknown')}<br>
                            <i class="fas fa-building"></i> Publisher: ${escapeHtml(data.publisher || 'Unknown')}<br>
                            <i class="fas fa-tag"></i> Category: ${escapeHtml(data.category || 'Uncategorized')}<br>
                            <i class="fas fa-tag"></i> Item Category: ${escapeHtml(currentItemCategory)}<br>
                            <i class="fas fa-copy"></i> Available: ${available} / ${quantity}<br>
                            ${statusHtml}
                            ${available < 1 ? '<br><span class="text-danger fw-bold">⚠ Book not available for issue!</span>' : ''}
                        </div>
                    </div>`;
        
        // Already issued card (right column) - WITH PHOTO SUPPORT
        const alreadyIssuedCard = document.getElementById('alreadyIssuedCard');
        const alreadyIssuedContent = document.getElementById('alreadyIssuedContent');
        const confirmBtn = document.getElementById('confirmIssueBtn');
        
        if (currentIsIssued) {
            let issuerPhotoHtml = '';
            if (data.issued_member_photo_base64) {
                issuerPhotoHtml = `<img src="${data.issued_member_photo_base64}" class="issuer-photo" alt="Member Photo" loading="lazy">`;
            } else {
                issuerPhotoHtml = `<div class="issuer-photo-placeholder"><i class="fas fa-user"></i></div>`;
            }
            alreadyIssuedContent.innerHTML = `
                <div class="issued-user-info">
                    ${issuerPhotoHtml}
                    <div class="issued-details-container">
                        <div class="issued-detail"><span class="issued-label">👤 Issued to:</span> <strong>${escapeHtml(data.issued_member)}</strong></div>
                        <div class="issued-detail"><span class="issued-label">📛 Adm No:</span> ${escapeHtml(data.issued_admno)}</div>
                    </div>
                </div>
                <div class="issued-detail"><span class="issued-label">📖 Book:</span> ${escapeHtml(data.title)}</div>
                <div class="issued-detail"><span class="issued-label">📅 Issue Date:</span> ${data.issue_date}</div>
                <div class="issued-detail"><span class="issued-label">📆 Due Date:</span> ${data.due_date}</div>
                <div class="issued-detail text-danger mt-2"><i class="fas fa-exclamation-triangle"></i> <strong>⚠ This book is already issued.</strong><br>Please return it before issuing again.</div>
            `;
            alreadyIssuedCard.style.display = 'block';
            confirmBtn.disabled = true;
            bookLoaded = false;
        } else {
            alreadyIssuedCard.style.display = 'none';
            confirmBtn.disabled = false;
            bookLoaded = true;
        }
        
        // Additional item‑specific alerts
        if (currentItemCategory === 'Restricted') {
            html += `<div class="alert-restricted mt-1 p-2 rounded"><i class="fas fa-star"></i> 🚫 RESTRICTED 🚫 <i class="fas fa-star"></i></div>`;
            bookLoaded = false;
        } else if (currentItemCategory === 'Reference' || currentBookStatus === 'Reference Only') {
            html += `<div class="ref-alert mt-1"><div class="top-line"><span class="star">⭐</span> ❌ REFERENCE <span class="star">⭐</span></div><div class="bottom-line">Permission Required</div></div>`;
        } else if (currentItemCategory === 'Textbook' || currentItemCategory === 'Textbooks') {
            html += `<div class="alert-textbook mt-1 p-2 rounded"><i class="fas fa-star"></i> 📘 TEXT BOOK <i class="fas fa-star"></i></div>`;
        } else if (['CD', 'MAPS', 'Furniture', 'Computer'].includes(currentItemCategory)) {
            html += `<div class="special-item-notice"><i class="fas fa-info-circle"></i> <strong>Notice:</strong> This is a <strong>${currentItemCategory}</strong> item. Please handle with care and return in original condition.</div>`;
        }
        
        infoDiv.innerHTML = html;
        
        // Re‑evaluate auto‑issue possibility
        const canIssueStatus = (currentBookStatus === 'Available' || currentBookStatus === 'Reference Only') && !currentIsIssued;
        if (!canIssueStatus) {
            bookLoaded = false;
        }
        if (memberLoaded && bookLoaded && !isSubmitting) attemptAutoIssue();
    } else {
        // New book – not in database
        bookLoaded = false;
        currentIsIssued = false;
        document.getElementById('confirmIssueBtn').disabled = false;
        document.getElementById('alreadyIssuedCard').style.display = 'none';
        infoDiv.innerHTML = '<div class="alert alert-info text-center py-1 small"><i class="fas fa-info-circle"></i> New book - will be added to system upon issue. Please fill the book details below.</div>';
    }
}

function attemptAutoIssue() {
    if (!memberLoaded || !bookLoaded) return;
    if (!currentBookData) return;
    let canIssue = (currentBookData.available > 0 && currentItemCategory !== 'Restricted' && !currentIsIssued);
    if (currentBookStatus !== 'Available' && currentBookStatus !== 'Reference Only') canIssue = false;
    if ((currentItemCategory === 'Reference' || currentBookStatus === 'Reference Only')) {
        showReferenceModal();
        return;
    }
    if (canIssue && !isSubmitting) {
        isSubmitting = true;
        setTimeout(() => { document.getElementById('confirmIssueBtn').click(); }, 500);
    }
}

// Reference modal
function showReferenceModal() {
    const modal = new bootstrap.Modal(document.getElementById('refPermissionModal'));
    modal.show();
}

document.getElementById('confirmRefIssueBtn').addEventListener('click', function() {
    const password = document.getElementById('refPasswordInput').value;
    const confirm = document.getElementById('refConfirmCheck').checked;
    if (!confirm) {
        alert('Please confirm that you have permission to issue this reference book.');
        return;
    }
    if (!password) {
        alert('Please enter your librarian password.');
        return;
    }
    document.getElementById('ref_password').value = password;
    document.getElementById('ref_permission').value = 'yes';
    const modal = bootstrap.Modal.getInstance(document.getElementById('refPermissionModal'));
    modal.hide();
    document.getElementById('confirmIssueBtn').click();
});

// ISBN fetch functions
function fetchFromSelectedSource() {
    const isbn = document.getElementById('isbn').value.trim();
    if (isbn.length < 10) {
        document.getElementById('apiStatus').innerHTML = '<span class="text-danger">Please enter a valid ISBN</span>';
        return;
    }
    const source = document.getElementById('fetchSourceSelect').value;
    document.getElementById('apiStatus').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from ' + source + '...';
    fetch('issue.php?ajax_isbn=1&isbn=' + encodeURIComponent(isbn) + '&source=' + encodeURIComponent(source))
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                applySourceData(data.data);
                document.getElementById('apiStatus').innerHTML = '<span class="text-success">✅ Data fetched from ' + source + '</span>';
            } else {
                document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ ' + data.error + '</span>';
            }
        })
        .catch(err => {
            document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ Error: ' + err.message + '</span>';
        });
}

function fetchFromAllSources() {
    const isbn = document.getElementById('isbn').value.trim();
    if (isbn.length < 10) {
        document.getElementById('apiStatus').innerHTML = '<span class="text-danger">Please enter a valid ISBN</span>';
        return;
    }
    document.getElementById('apiStatus').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from all sources...';
    fetch('issue.php?ajax_isbn=1&isbn=' + encodeURIComponent(isbn) + '&all=1')
        .then(r => r.json())
        .then(data => {
            const modal = new bootstrap.Modal(document.getElementById('allSourcesModal'));
            const resultsDiv = document.getElementById('allSourcesResults');
            if (data.success && data.results) {
                let html = '<div class="list-group">';
                let count = 0;
                for (const [source, result] of Object.entries(data.results)) {
                    if (result.title) {
                        count++;
                        html += `<div class="list-group-item list-group-item-action">
                            <h6 class="mb-1"><i class="fas fa-check-circle text-success"></i> <strong>${source}</strong></h6>
                            <p class="mb-1"><strong>Title:</strong> ${escapeHtml(result.title)}</p>
                            <p class="mb-1"><strong>Author:</strong> ${escapeHtml(result.author)}</p>
                            <p class="mb-1"><strong>Publisher:</strong> ${escapeHtml(result.publisher)}</p>
                            <button class="btn btn-sm btn-primary mt-1" onclick="applySourceData(${JSON.stringify(result).replace(/"/g, '&quot;')})">Use This</button>
                        </div>`;
                    }
                }
                html += '</div>';
                if (count === 0) {
                    resultsDiv.innerHTML = '<div class="alert alert-warning">No results found from any source.</div>';
                } else {
                    resultsDiv.innerHTML = html;
                }
                document.getElementById('apiStatus').innerHTML = '<span class="text-success">✅ Found ' + count + ' results</span>';
            } else {
                resultsDiv.innerHTML = '<div class="alert alert-danger">' + (data.error || 'No results found') + '</div>';
            }
            modal.show();
        })
        .catch(err => {
            document.getElementById('apiStatus').innerHTML = '<span class="text-danger">❌ Error: ' + err.message + '</span>';
        });
}

function applySourceData(data) {
    if (data.title) document.getElementById('title').value = data.title;
    if (data.author) document.getElementById('author').value = data.author;
    if (data.publisher) document.getElementById('publisher').value = data.publisher;
    if (data.category) document.getElementById('category').value = data.category;
    if (data.cover_url) {
        const infoDiv = document.getElementById('bookInfo');
        const coverPreview = `<div class="mt-2"><img src="${data.cover_url}" style="max-height:100px; border-radius:4px; box-shadow:0 2px 8px rgba(0,0,0,0.1);"></div>`;
        infoDiv.innerHTML += coverPreview;
    }
}

// ========== FIXED EVENT LISTENERS FOR BARCODE SCANNING ==========
// Member input
memberInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        lookupMember();
    }
});
memberInput.addEventListener('blur', function() {
    if (this.value.trim().length >= 3) lookupMember();
});

// Book input - Fixed for better barcode reading
bookInput.addEventListener('input', function() {
    // Clear any pending timer
    if (bookLookupTimer) {
        clearTimeout(bookLookupTimer);
        bookLookupTimer = null;
    }
    
    const barcode = this.value.trim();
    if (barcode.length >= 3) {
        // Debounce the lookup to avoid multiple requests
        bookLookupTimer = setTimeout(function() {
            lookupBook();
        }, 300);
    } else {
        // Clear info if barcode is too short
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmIssueBtn').disabled = true;
        document.getElementById('alreadyIssuedCard').style.display = 'none';
    }
});

bookInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        // Clear timer and lookup immediately
        if (bookLookupTimer) {
            clearTimeout(bookLookupTimer);
            bookLookupTimer = null;
        }
        lookupBook();
    }
});

bookInput.addEventListener('blur', function() {
    if (this.value.trim().length >= 3) lookupBook();
});

// Focus on barcode input when page loads
window.addEventListener('load', function() {
    document.getElementById('barcode').focus();
});
</script>

<?php renderFooter(); ?>