<?php
/**
 * Transaction History - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - Member photo and book cover display
 * - Advanced search with filters
 * - Fine summary and statistics
 * - Pagination for large histories
 * - Responsive design with proper alignment
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== AJAX HANDLER FOR MEMBER HISTORY ==========
if (isset($_GET['ajax_member'])) {
    header('Content-Type: application/json');
    $admno = trim($_GET['admno']);
    
    // Get member details
    $stmt = $db->prepare("SELECT admno, name, photo_path, member_category, class, division, total_issued, total_fines, status FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($member) {
        $member['photo_base64'] = getImageBase64($member['photo_path'] ?? '');
        
        // Get active loans
        $stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL");
        $stmt->execute([$admno]);
        $member['active_loans'] = (int)$stmt->fetchColumn();
        
        // Get overdue loans
        $stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL AND due_date < date('now')");
        $stmt->execute([$admno]);
        $member['overdue_loans'] = (int)$stmt->fetchColumn();
        
        echo json_encode(['success' => true, 'member' => $member]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Member not found']);
    }
    exit;
}

if (isset($_GET['ajax_history'])) {
    header('Content-Type: application/json');
    $admno = trim($_GET['admno']);
    $status = $_GET['status'] ?? 'all';
    $limit = (int)($_GET['limit'] ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);
    
    $params = [$admno];
    $sql = "SELECT c.*, b.cover_path, b.quantity as book_quantity
            FROM circulation c 
            LEFT JOIN books b ON c.barcode = b.barcode
            WHERE c.admno = ?";
    
    if ($status === 'active') {
        $sql .= " AND c.return_date IS NULL";
    } elseif ($status === 'returned') {
        $sql .= " AND c.return_date IS NOT NULL";
    } elseif ($status === 'overdue') {
        $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')";
    }
    
    $sql .= " ORDER BY c.issue_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $history = $stmt->fetchAll();
    
    foreach ($history as &$h) {
        $h['cover_base64'] = getImageBase64($h['cover_path'] ?? '');
        $h['status_type'] = $h['return_date'] ? 'returned' : 
                           (strtotime($h['due_date']) < time() ? 'overdue' : 'issued');
    }
    
    echo json_encode(['success' => true, 'history' => $history]);
    exit;
}

// ========== MAIN PAGE VARIABLES ==========
$admno = $_GET['admno'] ?? '';
$statusFilter = $_GET['status'] ?? 'all';
$page = (int)($_GET['page'] ?? 1);
$limit = 20;
$offset = ($page - 1) * $limit;
$member = null;
$history = [];
$totalCount = 0;
$totalPages = 0;

if ($admno) {
    // Get member details
    $stmt = $db->prepare("SELECT admno, name, photo_path, member_category, class, division, total_issued, total_fines, status FROM members WHERE admno = ?");
    $stmt->execute([$admno]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($member) {
        $member['photo_base64'] = getImageBase64($member['photo_path'] ?? '');
        
        // Get total count for pagination
        $params = [$admno];
        $countSql = "SELECT COUNT(*) FROM circulation WHERE admno = ?";
        if ($statusFilter === 'active') {
            $countSql .= " AND return_date IS NULL";
        } elseif ($statusFilter === 'returned') {
            $countSql .= " AND return_date IS NOT NULL";
        } elseif ($statusFilter === 'overdue') {
            $countSql .= " AND return_date IS NULL AND due_date < date('now')";
        }
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $totalCount = (int)$stmt->fetchColumn();
        $totalPages = ceil($totalCount / $limit);
        
        // Get history with pagination
        $params = [$admno];
        $sql = "SELECT c.*, b.cover_path, b.quantity as book_quantity
                FROM circulation c 
                LEFT JOIN books b ON c.barcode = b.barcode
                WHERE c.admno = ?";
        
        if ($statusFilter === 'active') {
            $sql .= " AND c.return_date IS NULL";
        } elseif ($statusFilter === 'returned') {
            $sql .= " AND c.return_date IS NOT NULL";
        } elseif ($statusFilter === 'overdue') {
            $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')";
        }
        
        $sql .= " ORDER BY c.issue_date DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $history = $stmt->fetchAll();
        
        foreach ($history as &$h) {
            $h['cover_base64'] = getImageBase64($h['cover_path'] ?? '');
            $h['status_type'] = $h['return_date'] ? 'returned' : 
                               (strtotime($h['due_date']) < time() ? 'overdue' : 'issued');
        }
    }
}

renderHeader('Transaction History');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-success {
        background: linear-gradient(135deg, #28a745, #20c997) !important;
    }
    .card-custom .card-header.bg-info {
        background: linear-gradient(135deg, #17a2b8, #0dcaf0) !important;
    }
    .card-custom .card-body {
        padding: 1.25rem;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }

    /* ========== MEMBER PHOTO ========== */
    .member-photo-medium {
        width: 80px;
        height: 80px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid var(--primary-color);
        background: #f8f9fa;
        transition: var(--transition);
        flex-shrink: 0;
    }
    .member-photo-medium:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .member-photo-placeholder-medium {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid var(--primary-color);
        flex-shrink: 0;
        color: #6c757d;
        font-size: 2.5rem;
    }

    /* ========== BOOK COVER ========== */
    .book-cover-history {
        width: 35px;
        height: 48px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #e9ecef;
        background: #f8f9fa;
        transition: var(--transition);
        flex-shrink: 0;
    }
    .book-cover-history:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 10;
        position: relative;
    }
    .book-cover-placeholder-history {
        width: 35px;
        height: 48px;
        border-radius: 6px;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.8rem;
        border: 1px solid #e9ecef;
        flex-shrink: 0;
    }

    /* ========== INPUT ========== */
    #admnoSearch {
        font-size: 1.1rem;
        padding: 10px 18px;
        border-radius: 12px;
        border: 2px solid #e9ecef;
        transition: var(--transition);
        background: #f8f9fa;
    }
    #admnoSearch:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        background: #fff;
    }

    /* ========== TABLE ========== */
    .table-history {
        font-size: 0.9rem;
    }
    .table-history th {
        font-weight: 600;
        color: #495057;
        border-bottom: 2px solid #e9ecef;
        white-space: nowrap;
        background: #f8f9fa;
        position: sticky;
        top: 0;
        z-index: 5;
    }
    .table-history td {
        vertical-align: middle;
        padding: 0.6rem 0.75rem;
    }
    .table-history tr:hover {
        background-color: #f8f9fa;
    }
    .table-history .table-overdue { background-color: #f8d7da; }
    .table-history .table-issued { background-color: #cfe2ff; }
    .table-history .table-returned { background-color: #d4edda; }
    .scrollable-history {
        max-height: 500px;
        overflow-y: auto;
    }
    .scrollable-history::-webkit-scrollbar {
        width: 6px;
    }
    .scrollable-history::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    .scrollable-history::-webkit-scrollbar-thumb {
        background: #c1c7cd;
        border-radius: 10px;
    }

    /* ========== BADGES ========== */
    .badge-status {
        font-size: 0.7rem;
        padding: 0.35rem 0.75rem;
        border-radius: 30px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    .badge-returned { background: #d4edda; color: #155724; }
    .badge-overdue { background: #f8d7da; color: #721c24; animation: pulse-badge 2s infinite; }
    .badge-issued { background: #cfe2ff; color: #084298; }

    @keyframes pulse-badge {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    /* ========== FILTER BUTTONS ========== */
    .filter-group .btn {
        border-radius: 30px;
        padding: 0.4rem 1.2rem;
        font-weight: 500;
        transition: var(--transition);
        font-size: 0.85rem;
    }
    .filter-group .btn:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow-sm);
    }
    .filter-group .btn.active {
        background: var(--primary-color);
        color: white;
        border-color: var(--primary-color);
    }

    /* ========== STATS BADGES ========== */
    .stat-summary {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 10px;
    }
    .stat-summary .stat-item {
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 500;
        background: #f8f9fa;
    }
    .stat-summary .stat-item.total { background: var(--primary-color); color: white; }
    .stat-summary .stat-item.active { background: #cfe2ff; color: #084298; }
    .stat-summary .stat-item.overdue { background: #f8d7da; color: #721c24; }
    .stat-summary .stat-item.returned { background: #d4edda; color: #155724; }

    /* ========== PAGINATION ========== */
    .pagination .page-link {
        color: var(--primary-color);
        border-radius: 8px;
        margin: 0 3px;
    }
    .pagination .page-item.active .page-link {
        background: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .pagination .page-item.disabled .page-link {
        color: #6c757d;
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .container-fluid { padding: 0 12px; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .card-custom .card-body { padding: 1rem; }
        .table-history { font-size: 0.8rem; }
        .table-history td, .table-history th { padding: 0.4rem 0.5rem; }
        #admnoSearch { font-size: 0.95rem; padding: 8px 14px; }
        .btn { font-size: 0.8rem; padding: 0.3rem 0.7rem; }
        .member-photo-medium { width: 60px; height: 60px; }
        .member-photo-placeholder-medium { width: 60px; height: 60px; font-size: 1.8rem; }
        .book-cover-history { width: 28px; height: 38px; }
        .book-cover-placeholder-history { width: 28px; height: 38px; font-size: 0.6rem; }
        .stat-summary .stat-item { font-size: 0.7rem; padding: 4px 10px; }
        .filter-group .btn { font-size: 0.75rem; padding: 0.3rem 0.8rem; }
    }

    @media (max-width: 576px) {
        .table-history { font-size: 0.7rem; }
        .table-history td, .table-history th { padding: 0.3rem 0.35rem; }
        .btn { font-size: 0.7rem; padding: 0.2rem 0.5rem; }
        .badge-status { font-size: 0.6rem; padding: 0.25rem 0.5rem; }
        .member-photo-medium { width: 50px; height: 50px; }
        .member-photo-placeholder-medium { width: 50px; height: 50px; font-size: 1.4rem; }
        .filter-group .btn { font-size: 0.7rem; padding: 0.2rem 0.6rem; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .table-history th { background: #333 !important; color: white !important; }
        .filter-group { display: none !important; }
        .pagination { display: none !important; }
    }
    </style>
</head>
<body>

<div class="container-fluid px-3 px-md-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-history me-2" style="color: var(--primary-color);"></i> Transaction History
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="issue.php" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
            <a href="return.php" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
            <a href="renew.php" class="btn btn-info btn-sm text-white"><i class="fas fa-sync-alt"></i> Renew</a>
            <button onclick="window.print()" class="btn btn-outline-primary btn-sm" title="Print"><i class="fas fa-print"></i></button>
        </div>
    </div>

    <!-- ========== SEARCH CARD ========== -->
    <div class="card-custom mb-4">
        <div class="card-header">
            <span><i class="fas fa-search me-2"></i> Search Member History</span>
            <span class="badge bg-light text-dark">Enter Adm/Mem Number</span>
        </div>
        <div class="card-body">
            <form method="get" id="searchForm" class="row g-3 align-items-end">
                <div class="col-md-8">
                    <label class="form-label fw-semibold">Adm/Mem Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-id-card"></i></span>
                        <input type="text" name="admno" id="admnoSearch" class="form-control form-control-lg" 
                               placeholder="Enter Adm/Mem Number to view history" 
                               value="<?= htmlspecialchars($admno) ?>" required autofocus autocomplete="off">
                    </div>
                    <div id="memberPreview" class="mt-2" style="display: none;"></div>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-gradient-primary btn-lg w-100">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($admno && $member): ?>
    <!-- ========== MEMBER INFO CARD ========== -->
    <div class="card-custom mb-4">
        <div class="card-header bg-success">
            <span><i class="fas fa-user me-2"></i> Member Information</span>
            <span class="badge bg-light text-dark"><?= htmlspecialchars($member['status'] ?? 'Active') ?></span>
        </div>
        <div class="card-body">
            <div class="d-flex flex-wrap align-items-center gap-4">
                <?php if (!empty($member['photo_base64'])): ?>
                    <img src="<?= $member['photo_base64'] ?>" class="member-photo-medium" alt="Member Photo" loading="lazy">
                <?php else: ?>
                    <div class="member-photo-placeholder-medium"><i class="fas fa-user"></i></div>
                <?php endif; ?>
                <div>
                    <h5 class="mb-1"><?= htmlspecialchars($member['name']) ?></h5>
                    <div class="row g-2">
                        <div class="col-md-6"><strong>Adm/Mem:</strong> <?= htmlspecialchars($member['admno']) ?></div>
                        <div class="col-md-6"><strong>Category:</strong> <?= htmlspecialchars($member['member_category'] ?? 'N/A') ?></div>
                        <div class="col-md-6"><strong>Class/Dept:</strong> <?= htmlspecialchars($member['class'] ?? 'N/A') ?></div>
                        <div class="col-md-6"><strong>Div/Course:</strong> <?= htmlspecialchars($member['division'] ?? 'N/A') ?></div>
                        <div class="col-md-6"><strong>Total Issued:</strong> <?= number_format($member['total_issued'] ?? 0) ?></div>
                        <div class="col-md-6"><strong>Total Fines:</strong> <?= formatCurrency($member['total_fines'] ?? 0) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== FILTERS AND STATS ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div class="filter-group no-print">
            <a href="?admno=<?= urlencode($admno) ?>&status=all" class="btn <?= $statusFilter === 'all' ? 'btn-primary active' : 'btn-outline-primary' ?>">All</a>
            <a href="?admno=<?= urlencode($admno) ?>&status=active" class="btn <?= $statusFilter === 'active' ? 'btn-primary active' : 'btn-outline-primary' ?>"><i class="fas fa-book-open"></i> Active</a>
            <a href="?admno=<?= urlencode($admno) ?>&status=overdue" class="btn <?= $statusFilter === 'overdue' ? 'btn-danger active' : 'btn-outline-danger' ?>"><i class="fas fa-clock"></i> Overdue</a>
            <a href="?admno=<?= urlencode($admno) ?>&status=returned" class="btn <?= $statusFilter === 'returned' ? 'btn-success active' : 'btn-outline-success' ?>"><i class="fas fa-check-circle"></i> Returned</a>
        </div>
        <div>
            <span class="badge bg-primary"><?= number_format($totalCount) ?> records</span>
        </div>
    </div>

    <?php
    // Calculate stats
    $activeCount = 0;
    $overdueCount = 0;
    $returnedCount = 0;
    $totalFine = 0;
    foreach ($history as $h) {
        if ($h['return_date']) {
            $returnedCount++;
            $totalFine += (float)($h['fine'] ?? 0);
        } elseif (strtotime($h['due_date']) < time()) {
            $overdueCount++;
        } else {
            $activeCount++;
        }
    }
    ?>
    <div class="stat-summary mb-3">
        <span class="stat-item total"><i class="fas fa-list"></i> Total: <?= $totalCount ?></span>
        <span class="stat-item active"><i class="fas fa-book-open"></i> Active: <?= $activeCount ?></span>
        <span class="stat-item overdue"><i class="fas fa-clock"></i> Overdue: <?= $overdueCount ?></span>
        <span class="stat-item returned"><i class="fas fa-check-circle"></i> Returned: <?= $returnedCount ?></span>
        <span class="stat-item" style="background: #fff3cd; color: #856404;"><i class="fas fa-coins"></i> Total Fine: <?= formatCurrency($totalFine) ?></span>
    </div>

    <!-- ========== HISTORY TABLE ========== -->
    <div class="card-custom">
        <div class="card-header bg-info">
            <span><i class="fas fa-list me-2"></i> Transaction Records</span>
            <span class="badge bg-light text-dark"><?= count($history) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="scrollable-history">
                <table class="table table-history mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Book</th>
                            <th>Author</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Return Date</th>
                            <th class="text-end">Fine</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($history)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x d-block mb-2"></i>
                                    No transactions found for this member.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $sn = $offset + 1; foreach ($history as $h): 
                                $rowClass = $h['status_type'] === 'overdue' ? 'table-overdue' : 
                                           ($h['status_type'] === 'issued' ? 'table-issued' : 'table-returned');
                                $badgeClass = $h['status_type'] === 'overdue' ? 'badge-overdue animated-badge' : 
                                             ($h['status_type'] === 'issued' ? 'badge-issued' : 'badge-returned');
                                $statusText = ucfirst($h['status_type']);
                                
                                $coverHtml = '';
                                if (!empty($h['cover_base64'])) {
                                    $coverHtml = '<img src="' . $h['cover_base64'] . '" class="book-cover-history" alt="Cover" loading="lazy">';
                                } else {
                                    $coverHtml = '<div class="book-cover-placeholder-history"><i class="fas fa-book"></i></div>';
                                }
                            ?>
                            <tr class="<?= $rowClass ?>">
                                <td><?= $sn++ ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <?= $coverHtml ?>
                                        <div>
                                            <div class="fw-semibold small" title="<?= htmlspecialchars($h['title']) ?>">
                                                <?= htmlspecialchars(substr($h['title'], 0, 30)) ?><?= strlen($h['title']) > 30 ? '…' : '' ?>
                                            </div>
                                            <small class="text-muted">Barcode: <?= htmlspecialchars($h['barcode']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($h['author'] ?? '-') ?></td>
                                <td><?= formatDate($h['issue_date']) ?></td>
                                <td>
                                    <?= formatDate($h['due_date']) ?>
                                    <?php if ($h['status_type'] === 'overdue'): ?>
                                        <br><small class="text-danger fw-bold">Overdue!</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($h['return_date']): ?>
                                        <?= formatDate($h['return_date']) ?>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Not Returned</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <?= ($h['fine'] ?? 0) > 0 ? formatCurrency($h['fine']) : '-' ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge badge-status <?= $badgeClass ?>">
                                        <?= $statusText ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ========== PAGINATION ========== -->
    <?php if ($totalPages > 1): ?>
    <div class="d-flex justify-content-center mt-4 no-print">
        <nav>
            <ul class="pagination">
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="?admno=<?= urlencode($admno) ?>&status=<?= $statusFilter ?>&page=<?= $page - 1 ?>">«</a>
                </li>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="?admno=<?= urlencode($admno) ?>&status=<?= $statusFilter ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                    <a class="page-link" href="?admno=<?= urlencode($admno) ?>&status=<?= $statusFilter ?>&page=<?= $page + 1 ?>">»</a>
                </li>
            </ul>
        </nav>
    </div>
    <?php endif; ?>

    <?php elseif ($admno && !$member): ?>
    <!-- ========== MEMBER NOT FOUND ========== -->
    <div class="alert alert-danger text-center py-4">
        <i class="fas fa-exclamation-triangle fa-3x d-block mb-2"></i>
        <h5>Member not found</h5>
        <p>No member found with Adm/Mem Number: <strong><?= htmlspecialchars($admno) ?></strong></p>
        <a href="history.php" class="btn btn-primary">Try Again</a>
    </div>
    <?php endif; ?>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== MEMBER PREVIEW ==========
const admnoInput = document.getElementById('admnoSearch');
const memberPreview = document.getElementById('memberPreview');
let previewTimeout = null;

admnoInput.addEventListener('input', function() {
    const admno = this.value.trim();
    if (admno.length < 3) {
        memberPreview.style.display = 'none';
        return;
    }
    
    if (previewTimeout) clearTimeout(previewTimeout);
    previewTimeout = setTimeout(() => {
        fetch('history.php?ajax_member=1&admno=' + encodeURIComponent(admno))
            .then(r => r.json())
            .then(data => {
                if (data.success && data.member) {
                    const m = data.member;
                    let photoHtml = '';
                    if (m.photo_base64) {
                        photoHtml = `<img src="${m.photo_base64}" style="width:50px;height:50px;object-fit:cover;border-radius:50%;border:2px solid var(--primary-color);flex-shrink:0;">`;
                    } else {
                        photoHtml = `<div style="width:50px;height:50px;border-radius:50%;background:#e9ecef;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fas fa-user text-muted"></i></div>`;
                    }
                    memberPreview.innerHTML = `
                        <div class="d-flex align-items-center gap-3 p-2 bg-light rounded">
                            ${photoHtml}
                            <div>
                                <div class="fw-bold">${escapeHtml(m.name)}</div>
                                <div class="small text-muted">${escapeHtml(m.admno)} | ${escapeHtml(m.member_category || 'N/A')}</div>
                                <div class="small">Active Loans: ${m.active_loans || 0} | Overdue: ${m.overdue_loans || 0}</div>
                            </div>
                        </div>
                    `;
                    memberPreview.style.display = 'block';
                } else {
                    memberPreview.innerHTML = `<div class="alert alert-warning py-1 mb-0">Member not found</div>`;
                    memberPreview.style.display = 'block';
                }
            })
            .catch(() => {
                memberPreview.innerHTML = `<div class="alert alert-danger py-1 mb-0">Error fetching member details</div>`;
                memberPreview.style.display = 'block';
            });
    }, 400);
});

function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m);
}

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
    if (e.key === 'Enter' && document.activeElement === admnoInput) {
        e.preventDefault();
        document.getElementById('searchForm').submit();
    }
});

// ========== FILTER BUTTON ACTIVE STATE ==========
document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.filter-group .btn');
    filterButtons.forEach(btn => {
        if (btn.classList.contains('active')) {
            btn.style.pointerEvents = 'none';
        }
    });
});
</script>

<?php renderFooter(); ?>