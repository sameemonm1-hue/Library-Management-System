<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
// $currencySymbol is still available but not used for fine formatting anymore
$currencySymbol = $settings['currency_symbol'] ?? '$';

$admno = $_GET['admno'] ?? '';
$history = [];

if($admno) {
    $stmt = $db->prepare("SELECT * FROM circulation WHERE admno = ? ORDER BY issue_date DESC");
    $stmt->execute([$admno]);
    $history = $stmt->fetchAll();
    
    $memberStmt = $db->prepare("SELECT * FROM members WHERE admno = ?");
    $memberStmt->execute([$admno]);
    $member = $memberStmt->fetch();
}

renderHeader('Transaction History');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-history"></i> Transaction History</h2>
        <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
    
    <div class="card mb-4">
        <div class="card-header">Search Member History</div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="admno" class="form-control form-control-lg" 
                           placeholder="Enter Adm/Mem Number" value="<?= htmlspecialchars($admno) ?>" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-lg w-100">Search</button>
                </div>
            </form>
        </div>
    </div>
    
    <?php if($admno): ?>
        <?php if(isset($member) && $member): ?>
            <div class="alert alert-info">
                <strong><?= htmlspecialchars($member['name']) ?></strong><br>
                Adm/Mem: <?= $member['admno'] ?> | Category: <?= $member['member_category'] ?> | 
                Class/Dept: <?= $member['class'] ?> | Div/Course: <?= $member['division'] ?> |
                Total Issued: <?= $member['total_issued'] ?> | Total Fines: <?= formatCurrency($member['total_fines'] ?? 0) ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">Transaction Records</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th><th>Book Title</th><th>Author</th><th>Issue Date</th>
                                <th>Due Date</th><th>Return Date</th><th>Fine</th><th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $sn = 1; foreach($history as $h): ?>
                            <tr>
                                <td><?= $sn++ ?></td>
                                <td><?= htmlspecialchars($h['title']) ?></td>
                                <td><?= htmlspecialchars($h['author'] ?? '-') ?></td>
                                <td><?= formatDate($h['issue_date']) ?></td>
                                <td><?= formatDate($h['due_date']) ?></td>
                                <td><?= $h['return_date'] ? formatDate($h['return_date']) : '<span class="badge bg-warning">Not Returned</span>' ?></td>
                                <td><?= $h['fine'] > 0 ? formatCurrency($h['fine']) : '-' ?></td>
                                <td>
                                    <?php if($h['return_date']): ?>
                                        <span class="badge bg-success">Returned</span>
                                    <?php elseif(strtotime($h['due_date']) < time()): ?>
                                        <span class="badge bg-danger">Overdue</span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">Issued</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($history)): ?>
                            <tr><td colspan="8" class="text-center">No transactions found</td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php renderFooter(); ?>