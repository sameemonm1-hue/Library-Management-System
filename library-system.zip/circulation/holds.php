<?php
/**
 * Hold Queue Management - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - View holds by book barcode
 * - Mark holds as available
 * - Cancel holds
 * - Responsive design with proper alignment
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$searchBarcode = '';
$holds = [];

// Report settings for unified styling
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';
$holdDays = (int)($settings['hold_days'] ?? 7);

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Get book details for search result
if (isset($_GET['ajax_book']) && !empty($_GET['barcode'])) {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode']);
    $stmt = $db->prepare("SELECT barcode, title, author, available, quantity, cover_path FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $book = $stmt->fetch();
    if ($book) {
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
        $book['hold_count'] = (int)$db->prepare("SELECT COUNT(*) FROM book_holds WHERE book_barcode = ? AND status = 'pending'")->execute([$barcode]) ? $db->query("SELECT COUNT(*) FROM book_holds WHERE book_barcode = '$barcode' AND status = 'pending'")->fetchColumn() : 0;
    }
    echo json_encode($book ?? null);
    exit;
}

if (isset($_GET['barcode']) && !empty($_GET['barcode'])) {
    $searchBarcode = trim($_GET['barcode']);
    $stmt = $db->prepare("SELECT h.*, b.title, b.author, b.available as book_available, b.cover_path
                          FROM book_holds h 
                          JOIN books b ON h.book_barcode = b.barcode 
                          WHERE h.book_barcode = ? 
                          ORDER BY h.hold_date ASC");
    $stmt->execute([$searchBarcode]);
    $holds = $stmt->fetchAll();
    
    // Add queue position for each hold
    foreach ($holds as &$hold) {
        $posStmt = $db->prepare("SELECT COUNT(*) + 1 as pos FROM book_holds WHERE book_barcode = ? AND status = 'pending' AND hold_date < ?");
        $posStmt->execute([$hold['book_barcode'], $hold['hold_date']]);
        $hold['queue_position'] = (int)$posStmt->fetchColumn();
        $hold['cover_base64'] = getImageBase64($hold['cover_path'] ?? '');
    }
    unset($hold);
} else {
    // Show all pending holds if no barcode searched
    $stmt = $db->prepare("SELECT h.*, b.title, b.author, b.available as book_available, b.cover_path
                          FROM book_holds h 
                          JOIN books b ON h.book_barcode = b.barcode 
                          WHERE h.status = 'pending' 
                          ORDER BY h.hold_date ASC LIMIT 50");
    $stmt->execute();
    $holds = $stmt->fetchAll();
    
    foreach ($holds as &$hold) {
        $posStmt = $db->prepare("SELECT COUNT(*) + 1 as pos FROM book_holds WHERE book_barcode = ? AND status = 'pending' AND hold_date < ?");
        $posStmt->execute([$hold['book_barcode'], $hold['hold_date']]);
        $hold['queue_position'] = (int)$posStmt->fetchColumn();
        $hold['cover_base64'] = getImageBase64($hold['cover_path'] ?? '');
    }
    unset($hold);
}

// Handle cancel
if (isset($_GET['cancel'])) {
    $id = (int)$_GET['cancel'];
    $stmt = $db->prepare("SELECT book_barcode FROM book_holds WHERE id = ?");
    $stmt->execute([$id]);
    $bookBarcode = $stmt->fetchColumn();
    $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ?")->execute([$id]);
    logActivity($_SESSION['username'], 'HOLD_CANCELLED', "Cancelled hold ID $id for book $bookBarcode");
    header('Location: holds.php' . ($searchBarcode ? '?barcode=' . urlencode($searchBarcode) : ''));
    exit;
}

// Handle mark available
if (isset($_GET['mark_available'])) {
    $id = (int)$_GET['mark_available'];
    $stmt = $db->prepare("SELECT h.*, b.title FROM book_holds h JOIN books b ON h.book_barcode = b.barcode WHERE h.id = ?");
    $stmt->execute([$id]);
    $hold = $stmt->fetch();
    if ($hold) {
        $db->prepare("UPDATE book_holds SET status = 'available' WHERE id = ?")->execute([$id]);
        logActivity($_SESSION['username'], 'HOLD_AVAILABLE', "Marked hold ID $id available for {$hold['title']}");
        
        // Notify member via email queue
        $memberStmt = $db->prepare("SELECT email FROM members WHERE admno = ? AND status = 'active'");
        $memberStmt->execute([$hold['admno']]);
        $memberEmail = $memberStmt->fetchColumn();
        if ($memberEmail) {
            $subject = "Hold Available: {$hold['title']}";
            $body = "Dear {$hold['member_name']},\n\nThe book \"{$hold['title']}\" you requested is now available for pickup at the library.\n\nPlease collect it within $holdDays days.\n\nThank you for using the library system.";
            $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")->execute([$memberEmail, $subject, $body]);
        }
    }
    header('Location: holds.php' . ($searchBarcode ? '?barcode=' . urlencode($searchBarcode) : ''));
    exit;
}

renderHeader('Hold Queue');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hold Queue Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --purple: #6f42c1;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-purple {
        background: linear-gradient(135deg, #6f42c1, #8b5cf6) !important;
    }
    .card-custom .card-header.bg-secondary {
        background: linear-gradient(135deg, #6c757d, #8a929a) !important;
    }
    .card-custom .card-body {
        padding: 1.25rem;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }
    .btn-purple {
        background: linear-gradient(135deg, #6f42c1, #8b5cf6);
        color: #fff;
        border: none;
    }
    .btn-purple:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(111, 66, 193, 0.4);
        color: #fff;
    }

    /* ========== INPUT ========== */
    #barcodeSearch {
        font-size: 1.1rem;
        padding: 10px 18px;
        border-radius: 12px;
        border: 2px solid #e9ecef;
        transition: var(--transition);
        background: #f8f9fa;
    }
    #barcodeSearch:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        background: #fff;
    }

    /* ========== TABLE ========== */
    .table-holds {
        font-size: 0.9rem;
    }
    .table-holds th {
        font-weight: 600;
        color: #495057;
        border-bottom: 2px solid #e9ecef;
        white-space: nowrap;
        background: #f8f9fa;
        position: sticky;
        top: 0;
        z-index: 5;
    }
    .table-holds td {
        vertical-align: middle;
        padding: 0.7rem 0.75rem;
    }
    .table-holds tr:hover {
        background-color: #f8f9fa;
    }
    .scrollable-table {
        max-height: 500px;
        overflow-y: auto;
    }
    .scrollable-table::-webkit-scrollbar {
        width: 6px;
    }
    .scrollable-table::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
    .scrollable-table::-webkit-scrollbar-thumb {
        background: #c1c7cd;
        border-radius: 10px;
    }

    /* ========== BOOK COVER ========== */
    .book-cover-small {
        width: 35px;
        height: 48px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #e9ecef;
        background: #f8f9fa;
        transition: var(--transition);
        flex-shrink: 0;
    }
    .book-cover-small:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 10;
        position: relative;
    }
    .book-cover-placeholder {
        width: 35px;
        height: 48px;
        border-radius: 6px;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #6c757d;
        font-size: 0.8rem;
        border: 1px solid #e9ecef;
        flex-shrink: 0;
    }

    /* ========== BADGES ========== */
    .badge-status {
        font-size: 0.7rem;
        padding: 0.35rem 0.75rem;
        border-radius: 30px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }
    .badge-pending { background: #fff3cd; color: #856404; }
    .badge-available { background: #d4edda; color: #155724; }
    .badge-cancelled { background: #e2e3e5; color: #383d41; }

    /* ========== QUEUE POSITION ========== */
    .queue-badge {
        display: inline-block;
        min-width: 28px;
        text-align: center;
        background: #6f42c1;
        color: white;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 600;
    }
    .queue-badge.top1 { background: #ffc107; color: #856404; }
    .queue-badge.top2 { background: #adb5bd; color: #383d41; }
    .queue-badge.top3 { background: #cd7f32; color: white; }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .container-fluid { padding: 0 12px; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .card-custom .card-body { padding: 1rem; }
        .table-holds { font-size: 0.8rem; }
        .table-holds td, .table-holds th { padding: 0.4rem 0.5rem; }
        #barcodeSearch { font-size: 0.95rem; padding: 8px 14px; }
        .btn { font-size: 0.8rem; padding: 0.3rem 0.7rem; }
        .book-cover-small { width: 28px; height: 38px; }
        .book-cover-placeholder { width: 28px; height: 38px; font-size: 0.6rem; }
    }

    @media (max-width: 576px) {
        .table-holds { font-size: 0.7rem; }
        .table-holds td, .table-holds th { padding: 0.3rem 0.35rem; }
        .btn { font-size: 0.7rem; padding: 0.2rem 0.5rem; }
        .badge-status { font-size: 0.6rem; padding: 0.25rem 0.5rem; }
        .queue-badge { font-size: 0.6rem; padding: 1px 6px; min-width: 20px; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .table-holds th { background: #333 !important; color: white !important; }
    }
    </style>
</head>
<body>

<div class="container-fluid px-3 px-md-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-hand-paper me-2" style="color: var(--purple);"></i> Hold Queue Management
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
                <span class="ms-2 text-purple"><i class="fas fa-clock"></i> Hold expiry: <?= $holdDays ?> days</span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="issue.php" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
            <a href="return.php" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
            <a href="renew.php" class="btn btn-info btn-sm text-white"><i class="fas fa-sync-alt"></i> Renew</a>
            <button onclick="window.print()" class="btn btn-outline-primary btn-sm" title="Print"><i class="fas fa-print"></i></button>
        </div>
    </div>

    <!-- ========== STATS CARDS ========== -->
    <?php
    $totalHolds = (int)$db->query("SELECT COUNT(*) FROM book_holds WHERE status IN ('pending', 'available')")->fetchColumn();
    $pendingHolds = (int)$db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'pending'")->fetchColumn();
    $availableHolds = (int)$db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'available'")->fetchColumn();
    $expiringSoon = (int)$db->query("SELECT COUNT(*) FROM book_holds WHERE status = 'pending' AND expiry_date < date('now', '+2 days')")->fetchColumn();
    ?>
    
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
            <div class="stat-card" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6); border-radius: var(--border-radius); padding: 1rem 1.25rem; color: white; box-shadow: var(--shadow-sm);">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label" style="font-size: 0.85rem; opacity: 0.9; margin: 0;"><i class="fas fa-hand-paper me-1"></i> Total Holds</p>
                        <h3 class="stat-value" style="font-size: 1.9rem; font-weight: 700; margin: 0;"><?= number_format($totalHolds) ?></h3>
                    </div>
                    <div class="stat-icon" style="font-size: 2.2rem; opacity: 0.25;"><i class="fas fa-hand-paper"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
            <div class="stat-card" style="background: linear-gradient(135deg, #ffc107, #f0ad4e); border-radius: var(--border-radius); padding: 1rem 1.25rem; color: #856404; box-shadow: var(--shadow-sm);">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label" style="font-size: 0.85rem; opacity: 0.9; margin: 0;"><i class="fas fa-clock me-1"></i> Pending</p>
                        <h3 class="stat-value" style="font-size: 1.9rem; font-weight: 700; margin: 0; color: #856404;"><?= number_format($pendingHolds) ?></h3>
                    </div>
                    <div class="stat-icon" style="font-size: 2.2rem; opacity: 0.25;"><i class="fas fa-clock"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
            <div class="stat-card" style="background: linear-gradient(135deg, #28a745, #20c997); border-radius: var(--border-radius); padding: 1rem 1.25rem; color: white; box-shadow: var(--shadow-sm);">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label" style="font-size: 0.85rem; opacity: 0.9; margin: 0;"><i class="fas fa-check-circle me-1"></i> Available</p>
                        <h3 class="stat-value" style="font-size: 1.9rem; font-weight: 700; margin: 0;"><?= number_format($availableHolds) ?></h3>
                    </div>
                    <div class="stat-icon" style="font-size: 2.2rem; opacity: 0.25;"><i class="fas fa-check-circle"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
            <div class="stat-card" style="background: linear-gradient(135deg, #dc3545, #e74c3c); border-radius: var(--border-radius); padding: 1rem 1.25rem; color: white; box-shadow: var(--shadow-sm);">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label" style="font-size: 0.85rem; opacity: 0.9; margin: 0;"><i class="fas fa-exclamation-triangle me-1"></i> Expiring Soon</p>
                        <h3 class="stat-value" style="font-size: 1.9rem; font-weight: 700; margin: 0;"><?= number_format($expiringSoon) ?></h3>
                    </div>
                    <div class="stat-icon" style="font-size: 2.2rem; opacity: 0.25;"><i class="fas fa-exclamation-triangle"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== SEARCH CARD ========== -->
    <div class="card-custom mb-4">
        <div class="card-header bg-purple">
            <span><i class="fas fa-search me-2"></i> Search Holds by Book</span>
            <span class="badge bg-light text-dark">Enter barcode</span>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-8">
                    <label class="form-label fw-semibold">Book Barcode</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-barcode"></i></span>
                        <input type="text" name="barcode" id="barcodeSearch" class="form-control form-control-lg" 
                               placeholder="Enter book barcode to view holds" value="<?= htmlspecialchars($searchBarcode) ?>">
                    </div>
                    <div id="bookPreview" class="mt-2" style="display: none;"></div>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-gradient-primary btn-lg w-100">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- ========== HOLDS TABLE ========== -->
    <div class="card-custom">
        <div class="card-header <?= $searchBarcode ? 'bg-purple' : 'bg-secondary' ?>">
            <span><i class="fas fa-list me-2"></i> 
                <?= $searchBarcode ? "Holds for Book: " . htmlspecialchars($searchBarcode) : "All Pending Holds" ?>
            </span>
            <span class="badge bg-light text-dark"><?= count($holds) ?> holds</span>
        </div>
        <div class="card-body p-0">
            <div class="scrollable-table">
                <table class="table table-holds mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Book</th>
                            <th>Member</th>
                            <th>Hold Date</th>
                            <th>Expiry</th>
                            <th class="text-center">Queue</th>
                            <th class="text-center">Status</th>
                            <th class="text-center no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($holds)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x d-block mb-2"></i>
                                    <?= $searchBarcode ? 'No holds found for this barcode. Try another.' : 'No pending holds in the system.' ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($holds as $index => $hold): 
                                $statusClass = $hold['status'] == 'pending' ? 'badge-pending' : ($hold['status'] == 'available' ? 'badge-available' : 'badge-cancelled');
                                $queueClass = '';
                                if ($hold['queue_position'] == 1) $queueClass = 'top1';
                                elseif ($hold['queue_position'] == 2) $queueClass = 'top2';
                                elseif ($hold['queue_position'] == 3) $queueClass = 'top3';
                                
                                // Cover image
                                $coverHtml = '';
                                if (!empty($hold['cover_base64'])) {
                                    $coverHtml = '<img src="' . $hold['cover_base64'] . '" class="book-cover-small" alt="Cover" loading="lazy">';
                                } else {
                                    $coverHtml = '<div class="book-cover-placeholder"><i class="fas fa-book"></i></div>';
                                }
                            ?>
                            <tr>
                                <td><?= $index + 1 ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <?= $coverHtml ?>
                                        <div>
                                            <div class="fw-semibold small" title="<?= htmlspecialchars($hold['title']) ?>">
                                                <?= htmlspecialchars(substr($hold['title'], 0, 35)) ?><?= strlen($hold['title']) > 35 ? '…' : '' ?>
                                            </div>
                                            <small class="text-muted">Barcode: <?= htmlspecialchars($hold['book_barcode']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-semibold small"><?= htmlspecialchars($hold['member_name']) ?></div>
                                    <small class="text-muted"><?= htmlspecialchars($hold['admno']) ?></small>
                                </td>
                                <td><?= formatDate($hold['hold_date']) ?></td>
                                <td>
                                    <?= formatDate($hold['expiry_date']) ?>
                                    <?php if ($hold['status'] == 'pending' && strtotime($hold['expiry_date']) < strtotime('+2 days')): ?>
                                        <br><small class="text-danger fw-bold">⚠ Expiring soon</small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($hold['status'] == 'pending'): ?>
                                        <span class="queue-badge <?= $queueClass ?>">#<?= $hold['queue_position'] ?? '?' ?></span>
                                    <?php elseif ($hold['status'] == 'available'): ?>
                                        <span class="text-success"><i class="fas fa-check-circle"></i> Ready</span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge badge-status <?= $statusClass ?>">
                                        <?= ucfirst($hold['status']) ?>
                                    </span>
                                </td>
                                <td class="text-center no-print">
                                    <?php if ($hold['status'] == 'pending'): ?>
                                        <div class="d-flex flex-wrap gap-1 justify-content-center">
                                            <a href="?mark_available=<?= $hold['id'] ?>&barcode=<?= urlencode($searchBarcode) ?>" 
                                               class="btn btn-sm btn-success" onclick="return confirm('Mark as available? Member will be notified.')" title="Mark Available">
                                                <i class="fas fa-check"></i>
                                            </a>
                                            <a href="?cancel=<?= $hold['id'] ?>&barcode=<?= urlencode($searchBarcode) ?>" 
                                               class="btn btn-sm btn-danger" onclick="return confirm('Cancel this hold?')" title="Cancel">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        </div>
                                    <?php elseif ($hold['status'] == 'available'): ?>
                                        <span class="text-success"><i class="fas fa-check-circle"></i> Waiting</span>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ========== QUICK STATS ========== -->
    <div class="row g-3 mt-3">
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-secondary">
                    <span><i class="fas fa-info-circle me-2"></i> Hold Information</span>
                </div>
                <div class="card-body p-3">
                    <div class="row g-2">
                        <div class="col-6">
                            <div class="p-2 bg-soft-primary rounded" style="background: #cfe2ff; border-radius: 10px;">
                                <small class="text-muted">Hold Duration</small>
                                <div class="fw-bold"><?= $holdDays ?> days</div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-2 bg-soft-purple rounded" style="background: #e8d5f5; border-radius: 10px;">
                                <small class="text-muted">Expired Holds</small>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM book_holds WHERE expiry_date < date('now') AND status IN ('pending', 'available')")->fetchColumn()) ?></div>
                            </div>
                        </div>
                        <div class="col-12 mt-2">
                            <div class="p-2 bg-soft-info rounded" style="background: #d1ecf1; border-radius: 10px;">
                                <small class="text-muted">Available Books with Holds</small>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(DISTINCT book_barcode) FROM book_holds WHERE status = 'available'")->fetchColumn()) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-secondary">
                    <span><i class="fas fa-lightbulb me-2"></i> Quick Tips</span>
                </div>
                <div class="card-body p-3">
                    <ul class="list-unstyled small mb-0">
                        <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> <strong>Mark Available:</strong> When a book is returned and a hold exists, mark it available to notify the member.</li>
                        <li class="mb-2"><i class="fas fa-times-circle text-danger me-2"></i> <strong>Cancel Hold:</strong> Remove a hold if the member no longer needs the book.</li>
                        <li class="mb-2"><i class="fas fa-clock text-warning me-2"></i> <strong>Expiry:</strong> Holds expire after <?= $holdDays ?> days if not picked up.</li>
                        <li><i class="fas fa-envelope text-info me-2"></i> <strong>Notification:</strong> Members are automatically notified when holds become available.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== BOOK PREVIEW ==========
const barcodeInput = document.getElementById('barcodeSearch');
const bookPreview = document.getElementById('bookPreview');
let previewTimeout = null;

barcodeInput.addEventListener('input', function() {
    const barcode = this.value.trim();
    if (barcode.length < 3) {
        bookPreview.style.display = 'none';
        return;
    }
    
    if (previewTimeout) clearTimeout(previewTimeout);
    previewTimeout = setTimeout(() => {
        fetch('holds.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
            .then(r => r.json())
            .then(data => {
                if (data && data.title) {
                    let coverHtml = '';
                    if (data.cover_base64) {
                        coverHtml = `<img src="${data.cover_base64}" style="width:50px;height:70px;object-fit:cover;border-radius:6px;border:1px solid #e9ecef;flex-shrink:0;">`;
                    }
                    bookPreview.innerHTML = `
                        <div class="d-flex align-items-center gap-3 p-2 bg-light rounded">
                            ${coverHtml}
                            <div>
                                <div class="fw-bold">${escapeHtml(data.title)}</div>
                                <div class="small text-muted">Author: ${escapeHtml(data.author || 'Unknown')}</div>
                                <div class="small">Available: ${data.available} / ${data.quantity} | Holds: ${data.hold_count || 0}</div>
                            </div>
                        </div>
                    `;
                    bookPreview.style.display = 'block';
                } else {
                    bookPreview.innerHTML = `<div class="alert alert-warning py-1 mb-0">Book not found</div>`;
                    bookPreview.style.display = 'block';
                }
            })
            .catch(() => {
                bookPreview.innerHTML = `<div class="alert alert-danger py-1 mb-0">Error fetching book details</div>`;
                bookPreview.style.display = 'block';
            });
    }, 400);
});

function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m);
}

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
});

// ========== CONFIRM DIALOGS ==========
document.querySelectorAll('[onclick*="return confirm"]').forEach(el => {
    el.addEventListener('click', function(e) {
        // The inline onclick already handles confirm
    });
});
</script>

<?php renderFooter(); ?>