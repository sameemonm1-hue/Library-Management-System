<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$searchBarcode = '';
$holds = [];

if (isset($_GET['barcode']) && !empty($_GET['barcode'])) {
    $searchBarcode = trim($_GET['barcode']);
    $stmt = $db->prepare("SELECT h.*, b.title, b.author, b.available as book_available
                          FROM book_holds h 
                          JOIN books b ON h.book_barcode = b.barcode 
                          WHERE h.book_barcode = ? 
                          ORDER BY h.hold_date ASC");
    $stmt->execute([$searchBarcode]);
    $holds = $stmt->fetchAll();
} else {
    // Show all pending holds if no barcode searched
    $stmt = $db->prepare("SELECT h.*, b.title, b.author, b.available as book_available
                          FROM book_holds h 
                          JOIN books b ON h.book_barcode = b.barcode 
                          WHERE h.status = 'pending' 
                          ORDER BY h.hold_date ASC LIMIT 50");
    $stmt->execute();
    $holds = $stmt->fetchAll();
}

// Handle cancel
if (isset($_GET['cancel'])) {
    $id = (int)$_GET['cancel'];
    $db->prepare("UPDATE book_holds SET status = 'cancelled' WHERE id = ?")->execute([$id]);
    header('Location: holds.php' . ($searchBarcode ? '?barcode=' . urlencode($searchBarcode) : ''));
    exit;
}

// Handle mark available
if (isset($_GET['mark_available'])) {
    $id = (int)$_GET['mark_available'];
    $db->prepare("UPDATE book_holds SET status = 'available' WHERE id = ?")->execute([$id]);
    header('Location: holds.php' . ($searchBarcode ? '?barcode=' . urlencode($searchBarcode) : ''));
    exit;
}

renderHeader('Hold Queue');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-hand-paper text-info"></i> Hold Queue (by Book)</h2>
        <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Home</a>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-search"></i> Search Holds by Book Barcode</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-8">
                    <input type="text" name="barcode" class="form-control form-control-lg" 
                           placeholder="Enter Book Barcode" value="<?= htmlspecialchars($searchBarcode) ?>">
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-lg w-100">Search</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-list"></i> 
                <?= $searchBarcode ? "Holds for Book: " . htmlspecialchars($searchBarcode) : "All Pending Holds" ?>
            </h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>ID</th><th>Book Title / Barcode</th><th>Member</th><th>Adm No</th><th>Hold Date</th><th>Expiry</th><th>Status</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php if (empty($holds)): ?>
                            <tr><td colspan="8" class="text-center text-muted py-4">No holds found.<?= $searchBarcode ? ' Try another barcode.' : '' ?></td></tr>
                        <?php else: ?>
                            <?php foreach ($holds as $hold): ?>
                            <tr>
                                <td><?= $hold['id'] ?></td>
                                <td>
                                    <?= htmlspecialchars($hold['title']) ?><br>
                                    <small class="text-muted">Barcode: <?= htmlspecialchars($hold['book_barcode']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($hold['member_name']) ?></td>
                                <td><?= htmlspecialchars($hold['admno']) ?></td>
                                <td><?= $hold['hold_date'] ?></td>
                                <td><?= $hold['expiry_date'] ?></td>
                                <td>
                                    <span class="badge <?= $hold['status'] == 'pending' ? 'bg-warning' : ($hold['status'] == 'available' ? 'bg-success' : 'bg-secondary') ?>">
                                        <?= $hold['status'] ?>
                                    </span>
                                 </td>
                                 <td>
                                    <?php if ($hold['status'] == 'pending'): ?>
                                        <a href="?mark_available=<?= $hold['id'] ?>&barcode=<?= urlencode($searchBarcode) ?>" 
                                           class="btn btn-sm btn-success" onclick="return confirm('Mark as available? Member will be notified on return.')">
                                            <i class="fas fa-check"></i> Mark Available
                                        </a>
                                        <a href="?cancel=<?= $hold['id'] ?>&barcode=<?= urlencode($searchBarcode) ?>" 
                                           class="btn btn-sm btn-danger" onclick="return confirm('Cancel this hold?')">
                                            <i class="fas fa-times"></i> Cancel
                                        </a>
                                    <?php elseif ($hold['status'] == 'available'): ?>
                                        <span class="text-success">Waiting for pickup</span>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php renderFooter(); ?>