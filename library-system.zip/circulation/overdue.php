<?php
// overdue.php - Enhanced with mPDF export, member photos, modern UI
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$finePerDay = (float)($settings['fine_per_day'] ?? 2);
$institution = getInstitution();
$currencySymbol = $settings['currency_symbol'] ?? '$';

// Get filter values
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$selectedMember = $_GET['member_admno'] ?? '';

// Get top 10 overdue students (with photos)
$topOverdueStudents = [];
try {
    $topOverdueSQL = "SELECT m.admno, m.name, m.class, m.division, m.photo_path,
                      COUNT(c.barcode) as overdue_count,
                      SUM(julianday('now') - julianday(c.due_date)) * ? as total_fine
                      FROM circulation c 
                      LEFT JOIN members m ON c.admno = m.admno
                      WHERE c.return_date IS NULL 
                      AND c.due_date < date('now')
                      GROUP BY m.admno, m.name, m.class, m.division, m.photo_path
                      ORDER BY overdue_count DESC, total_fine DESC
                      LIMIT 10";
    $stmt = $db->prepare($topOverdueSQL);
    $stmt->execute([$finePerDay]);
    $topOverdueStudents = $stmt->fetchAll();
} catch (Exception $e) {
    $topOverdueStudents = [];
}

// Handle Export Requests (Excel and PDF)
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $paperSize = $_GET['paper_size'] ?? 'A4';
    $orientation = $_GET['orientation'] ?? 'landscape';
    
    // Query for exports (same as main but without photo_path)
    $sql = "SELECT c.*, 
            m.name as member_name, m.class, m.division, m.email, m.phone,
            b.title, b.author, b.isbn, b.publisher
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno
            LEFT JOIN books b ON c.barcode = b.barcode
            WHERE c.return_date IS NULL AND c.due_date < date('now')";
    $params = [];
    
    if($class) {
        $sql .= " AND m.class LIKE ?";
        $params[] = "%$class%";
    }
    if($division) {
        $sql .= " AND m.division LIKE ?";
        $params[] = "%$division%";
    }
    if($selectedMember) {
        $sql .= " AND m.admno = ?";
        $params[] = $selectedMember;
    }
    
    $sql .= " ORDER BY c.due_date ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $overdueBooks = $stmt->fetchAll();
    
    // Calculate total fine
    $totalFine = 0;
    foreach($overdueBooks as $book) {
        $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
        $totalFine += $days * $finePerDay;
    }
    
    if ($exportType === 'excel') {
        // Excel Export (unchanged)
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="overdue_books_' . date('Y-m-d') . '.xls"');
        
        echo "<html><head><meta charset='UTF-8'><title>Overdue Books Report</title>";
        echo "<style>th{background:#dc3545;color:#fff;padding:8px;} td{padding:6px;} table{border-collapse:collapse;width:100%;} th,td{border:1px solid #ddd;}</style>";
        echo "</head><body>";
        echo "<h2>" . htmlspecialchars($institution['name'] ?? 'Library') . "</h2>";
        echo "<h3>Overdue Books Report</h3>";
        echo "<p><b>Generated:</b> " . date('Y-m-d H:i:s') . "</p>";
        if($class || $division || $selectedMember) {
            echo "<p><b>Filters:</b> " . ($class ? "Class: $class " : '') . ($division ? "Division: $division " : '') . ($selectedMember ? "Member: $selectedMember" : '') . "</p>";
        }
        echo "<hr>";
        
        echo "<table border='1'>";
        echo "<thead><tr>
                <th>Sl No</th><th>Adm No</th><th>Member Name</th><th>Class</th><th>Division</th>
                <th>Barcode</th><th>Book Title</th><th>Author</th><th>ISBN</th>
                <th>Issue Date</th><th>Due Date</th><th>Days</th><th>Fine</th>
              </tr></thead><tbody>";
        $sl = 1;
        foreach($overdueBooks as $book) {
            $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
            $fine = $days * $finePerDay;
            echo "<tr>
                    <td align='center'>{$sl}</td>
                    <td>{$book['admno']}</td>
                    <td>{$book['member_name']}</td>
                    <td>{$book['class']}</td>
                    <td>{$book['division']}</td>
                    <td>{$book['barcode']}</td>
                    <td>{$book['title']}</td>
                    <td>{$book['author']}</td>
                    <td>{$book['isbn']}</td>
                    <td>" . formatDate($book['issue_date']) . "</td>
                    <td>" . formatDate($book['due_date']) . "</td>
                    <td align='center'>{$days}</td>
                    <td align='right'>" . formatCurrency($fine) . "</td>
                  </tr>";
            $sl++;
        }
        echo "</tbody><tfoot><tr style='background:#f0f0f0;font-weight:bold;'>
                <td colspan='12' align='right'>Total Fine:</td>
                <td align='right'>" . formatCurrency($totalFine) . "</td>
              </tr></tfoot></table>";
        echo "<p align='center' style='margin-top:20px;'>System Generated Report</p>";
        echo "</body></html>";
        exit;
    }
    
    elseif ($exportType === 'pdf') {
        // PDF Export using mPDF
        $institutionName = $institution['name'] ?? 'Library';
        $filters = [];
        if ($class) $filters['Class/Department'] = $class;
        if ($division) $filters['Division/Course'] = $division;
        if ($selectedMember) $filters['Member'] = $selectedMember;
        
        // Build table rows with barcode column
        $tableRows = '';
        if (!empty($overdueBooks)) {
            $tableRows .= '<thead><tr style="background-color: #dc3545; color: white;">
                                <th style="border:1px solid #000; padding:6px; text-align:center;">Sl No</th>
                                <th style="border:1px solid #000; padding:6px;">Adm No</th>
                                <th style="border:1px solid #000; padding:6px;">Member Name</th>
                                <th style="border:1px solid #000; padding:6px;">Class</th>
                                <th style="border:1px solid #000; padding:6px;">Division</th>
                                <th style="border:1px solid #000; padding:6px;">Barcode</th>
                                <th style="border:1px solid #000; padding:6px;">Book Title</th>
                                <th style="border:1px solid #000; padding:6px;">Author</th>
                                <th style="border:1px solid #000; padding:6px;">Issue Date</th>
                                <th style="border:1px solid #000; padding:6px;">Due Date</th>
                                <th style="border:1px solid #000; padding:6px; text-align:center;">Days</th>
                                <th style="border:1px solid #000; padding:6px; text-align:right;">Fine</th>
                            </tr></thead><tbody>';
            $sn = 1;
            foreach ($overdueBooks as $book) {
                $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
                $fine = $days * $finePerDay;
                $rowColor = ($sn % 2 == 0) ? '#f9f9f9' : '#ffffff';
                $tableRows .= '<tr style="background-color:' . $rowColor . ';">';
                $tableRows .= '<td style="border:1px solid #000; padding:6px; text-align:center;">' . $sn++ . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['admno']) . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['member_name']) . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['class'] ?? '-') . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['division'] ?? '-') . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['barcode']) . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['title'] ?? 'N/A') . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px;">' . htmlspecialchars($book['author'] ?? '-') . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px; text-align:center;">' . formatDate($book['issue_date']) . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px; text-align:center;">' . formatDate($book['due_date']) . '</td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px; text-align:center;"><strong>' . $days . '</strong></td>';
                $tableRows .= '<td style="border:1px solid #000; padding:6px; text-align:right;"><strong>' . formatCurrency($fine) . '</strong></td>';
                $tableRows .= '</tr>';
            }
            $tableRows .= '</tbody><tfoot><tr style="background-color:#f0f0f0; font-weight:bold;">
                            <td colspan="11" style="border:1px solid #000; padding:8px; text-align:right;">Total Estimated Fine:</td>
                            <td style="border:1px solid #000; padding:8px; text-align:right;">' . formatCurrency($totalFine) . '</td>
                         </tr></tfoot>';
        } else {
            $tableRows = '<tbody><tr><td colspan="12" style="border:1px solid #000; padding:50px; text-align:center;">No overdue books found.</td></tr></tbody>';
        }
        
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Overdue Books Report</title>
            <style>
                @page { margin: 1.5cm; }
                body { font-family: "DejaVu Sans", "Arial", sans-serif; font-size: 10px; margin: 0; padding: 10px; }
                .header { text-align: center; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #dc3545; }
                .institution-name { font-size: 18px; font-weight: bold; color: #1e3c72; }
                .report-title { font-size: 16px; font-weight: bold; margin: 10px 0; color: #dc3545; }
                .report-meta { font-size: 10px; color: #666; margin: 5px 0; }
                .filters { margin-top: 10px; font-size: 10px; padding: 8px; background: #f5f5f5; }
                .summary { margin: 15px 0; padding: 10px; background: #f8f9fa; border-left: 4px solid #dc3545; font-size: 10px; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
                th, td { border: 1px solid #000000; padding: 6px; vertical-align: top; }
                th { background-color: #dc3545; color: white; font-weight: bold; }
                .footer { margin-top: 20px; text-align: center; font-size: 9px; color: #777; padding-top: 10px; border-top: 1px solid #ddd; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="institution-name">' . htmlspecialchars($institutionName) . '</div>
                <div class="report-title">Overdue Books Report</div>
                <div class="report-meta">Generated: ' . date('Y-m-d H:i:s') . '</div>';
        if (!empty($filters)) {
            $html .= '<div class="filters">';
            foreach ($filters as $label => $value) {
                $html .= '<strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . ' &nbsp; ';
            }
            $html .= '</div>';
        }
        $html .= '</div>';
        $html .= '<div class="summary">
                        <strong>Summary:</strong> 
                        Total Overdue Books: ' . count($overdueBooks) . ' | 
                        Total Fine Amount: ' . formatCurrency($totalFine) . ' | 
                        Fine per Day: ' . formatCurrency($finePerDay) . ' |
                        Members Affected: ' . count(array_unique(array_column($overdueBooks, 'admno'))) . '
                    </div>';
        $html .= '<table cellspacing="0">' . $tableRows . '</table>';
        $html .= '<div class="footer">
                        This is a system generated report from Library Management System<br>
                        &copy; ' . date('Y') . ' ' . htmlspecialchars($institutionName) . '. All rights reserved.
                    </div>
        </body>
        </html>';
        
        // Load mPDF and generate PDF
        require_once __DIR__ . '/../vendor/autoload.php';
        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'format' => $paperSize,
            'orientation' => $orientation,
            'default_font_size' => 10,
            'default_font' => 'dejavusans'
        ]);
        $mpdf->WriteHTML($html);
        $mpdf->Output('overdue_books_' . date('Y-m-d') . '.pdf', 'I');
        exit;
    }
}

// Main query for displaying the page (includes photo_path)
$sql = "SELECT c.*, 
        m.name as member_name, m.class, m.division, m.email, m.phone, m.photo_path,
        b.title, b.author, b.isbn, b.publisher
        FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno
        LEFT JOIN books b ON c.barcode = b.barcode
        WHERE c.return_date IS NULL AND c.due_date < date('now')";
$params = [];

if($class) {
    $sql .= " AND m.class LIKE ?";
    $params[] = "%$class%";
}
if($division) {
    $sql .= " AND m.division LIKE ?";
    $params[] = "%$division%";
}
if($selectedMember) {
    $sql .= " AND m.admno = ?";
    $params[] = $selectedMember;
}

$sql .= " ORDER BY c.due_date ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$overdueBooks = $stmt->fetchAll();

$totalFine = 0;
foreach($overdueBooks as $book) {
    $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
    $totalFine += $days * $finePerDay;
}

renderHeader('Overdue Books');
?>

<style>
    /* Enhanced UI Styles */
    .dropdown-scroll { max-height: 400px; overflow-y: auto; }
    .overdue-student-item {
        border-left: 4px solid #dc3545;
        margin-bottom: 5px;
        transition: all 0.2s;
        cursor: pointer;
        border-radius: 8px;
    }
    .overdue-student-item:hover {
        background-color: #f8f9fa;
        transform: translateX(5px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .student-badge {
        font-size: 12px;
        background: #dc3545;
        color: white;
        padding: 2px 10px;
        border-radius: 20px;
        display: inline-block;
    }
    .fine-amount { font-size: 13px; color: #dc3545; font-weight: bold; }
    .quick-filter-btn { cursor: pointer; transition: all 0.2s; }
    .quick-filter-btn:hover { background-color: #dc3545 !important; color: white !important; }
    .barcode-text { font-family: monospace; font-size: 12px; letter-spacing: 0.5px; }
    .member-photo-thumb {
        width: 40px;
        height: 40px;
        object-fit: cover;
        border-radius: 50%;
        border: 2px solid #dee2e6;
        background: #f8f9fa;
    }
    .member-photo-small {
        width: 35px;
        height: 35px;
        object-fit: cover;
        border-radius: 50%;
        margin-right: 8px;
        border: 2px solid #fff;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .photo-placeholder {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e9ecef;
        border-radius: 50%;
        color: #6c757d;
        font-size: 1.2rem;
    }
    .student-name-with-photo {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .stat-card {
        border-radius: 12px;
        transition: all 0.2s;
        border: none;
        box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 16px rgba(0,0,0,0.10);
    }
    .stat-card .card-body {
        padding: 1.25rem;
    }
    .stat-card .stat-icon {
        font-size: 2.5rem;
        opacity: 0.4;
    }
    .filter-card {
        border-radius: 12px;
        border: none;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .table-overdue th {
        background: #dc3545;
        color: white;
        font-weight: 600;
        white-space: nowrap;
    }
    .table-overdue td {
        vertical-align: middle;
    }
    .table-overdue tfoot {
        background: #f8f9fa;
        font-weight: bold;
    }
    .top-students-title {
        font-size: 0.9rem;
        font-weight: 600;
    }
    .action-btns .btn {
        border-radius: 20px;
        padding: 0.25rem 1rem;
    }
</style>

<div class="container-fluid px-4">
    <!-- Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <h2 class="mb-0"><i class="fas fa-exclamation-triangle text-danger me-2"></i>Overdue Books</h2>
        <div class="d-flex flex-wrap gap-2">
            <button type="button" class="btn btn-success" onclick="exportExcel()"><i class="fas fa-file-excel me-1"></i> Excel</button>
            <div class="btn-group">
                <button type="button" class="btn btn-danger dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-file-pdf me-1"></i> PDF</button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'portrait')">A4 Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'landscape')">A4 Landscape</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'portrait')">Letter Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'landscape')">Letter Landscape</a></li>
                </ul>
            </div>
            <button type="button" class="btn btn-info" onclick="window.print()"><i class="fas fa-print me-1"></i> Print</button>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-1"></i> Back</a>
        </div>
    </div>
    
    <!-- Filter Form -->
    <div class="card filter-card mb-4">
        <div class="card-header bg-primary text-white d-flex align-items-center">
            <i class="fas fa-filter me-2"></i> Filter Overdue Books
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label fw-semibold"><i class="fas fa-users me-1"></i> Class/Department</label>
                    <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($class) ?>" placeholder="e.g. Class 10">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold"><i class="fas fa-layer-group me-1"></i> Division/Course</label>
                    <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($division) ?>" placeholder="e.g. A">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold"><i class="fas fa-id-card me-1"></i> Member (Adm No)</label>
                    <select name="member_admno" class="form-select">
                        <option value="">-- All Members --</option>
                        <?php foreach($topOverdueStudents as $student): ?>
                        <option value="<?= htmlspecialchars($student['admno']) ?>" <?= $selectedMember == $student['admno'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($student['admno']) ?> - <?= htmlspecialchars($student['name']) ?> 
                            (<?= $student['overdue_count'] ?> books | <?= formatCurrency($student['total_fine']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary w-100"><i class="fas fa-search me-1"></i> Apply</button>
                        <a href="overdue.php" class="btn btn-secondary w-100">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Top 10 Overdue Students -->
    <div class="card mb-4 border-danger">
        <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
            <span><i class="fas fa-trophy me-2"></i>Top 10 Most Overdue Students</span>
            <span class="small"><i class="fas fa-hand-pointer me-1"></i> Click any student to filter</span>
        </div>
        <div class="card-body p-2">
            <div class="dropdown-scroll">
                <div class="row g-2">
                    <?php if(empty($topOverdueStudents)): ?>
                        <div class="col-12 text-center py-4 text-muted"><i class="fas fa-info-circle me-2"></i>No overdue books found</div>
                    <?php else: ?>
                        <?php $rank = 1; foreach($topOverdueStudents as $student): 
                            $photoUrl = '';
                            if (!empty($student['photo_path'])) {
                                $photoPath = $student['photo_path'];
                                if (strpos($photoPath, 'uploads/') === 0) $fullPath = BASE_PATH . '/' . $photoPath;
                                elseif (strpos($photoPath, '/') !== 0 && strpos($photoPath, ':\\') === false) $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
                                else $fullPath = $photoPath;
                                if (file_exists($fullPath)) $photoUrl = getWebImageUrl($photoPath);
                            }
                        ?>
                        <div class="col-md-6 col-lg-4 col-xl-3 p-2">
                            <div class="overdue-student-item border rounded p-3 h-100 bg-white quick-filter-btn" data-admno="<?= htmlspecialchars($student['admno']) ?>" onclick="filterByMember('<?= htmlspecialchars($student['admno']) ?>')">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="student-badge"><i class="fas fa-medal me-1"></i> #<?= $rank ?></span>
                                    <span class="badge bg-warning text-dark"><i class="fas fa-book me-1"></i> <?= $student['overdue_count'] ?></span>
                                </div>
                                <div class="student-name-with-photo">
                                    <?php if ($photoUrl): ?>
                                        <img src="<?= $photoUrl ?>" class="member-photo-small" alt="Photo" onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.photo-placeholder-small').style.display='flex';">
                                        <div class="photo-placeholder-small" style="width:35px;height:35px;display:none;align-items:center;justify-content:center;background:#e9ecef;border-radius:50%;"><i class="fas fa-user"></i></div>
                                    <?php else: ?>
                                        <div class="photo-placeholder-small" style="width:35px;height:35px;display:flex;align-items:center;justify-content:center;background:#e9ecef;border-radius:50%;"><i class="fas fa-user"></i></div>
                                    <?php endif; ?>
                                    <h6 class="mb-1 text-truncate" title="<?= htmlspecialchars($student['name']) ?>" style="flex:1;"><?= htmlspecialchars($student['name']) ?></h6>
                                </div>
                                <small class="text-muted d-block"><i class="fas fa-id-card me-1"></i> <?= htmlspecialchars($student['admno']) ?></small>
                                <?php if($student['class']): ?>
                                <small class="text-muted d-block"><i class="fas fa-graduation-cap me-1"></i> <?= htmlspecialchars($student['class']) ?> <?= htmlspecialchars($student['division'] ?? '') ?></small>
                                <?php endif; ?>
                                <div class="fine-amount mt-2"><i class="fas fa-dollar-sign me-1"></i> Fine: <?= formatCurrency($student['total_fine']) ?></div>
                            </div>
                        </div>
                        <?php $rank++; endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card stat-card bg-danger text-white">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">Total Overdue</h6>
                        <h2 class="mb-0"><?= count($overdueBooks) ?></h2>
                    </div>
                    <i class="fas fa-clock stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-warning text-white">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">Total Fine</h6>
                        <h2 class="mb-0"><?= formatCurrency($totalFine) ?></h2>
                    </div>
                    <i class="fas fa-dollar-sign stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-info text-white">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">Fine per Day</h6>
                        <h2 class="mb-0"><?= formatCurrency($finePerDay) ?></h2>
                    </div>
                    <i class="fas fa-charging-station stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card bg-success text-white">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-0">Members Affected</h6>
                        <h2 class="mb-0"><?= count(array_unique(array_column($overdueBooks, 'admno'))) ?></h2>
                    </div>
                    <i class="fas fa-users stat-icon"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Overdue Books List with Photos -->
    <div class="card">
        <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
            <span><i class="fas fa-list me-2"></i>Overdue Books List</span>
            <span class="badge bg-light text-dark">Total: <?= count($overdueBooks) ?> | Fine: <?= formatCurrency($totalFine) ?></span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-overdue mb-0">
                    <thead>
                        <tr>
                            <th style="width:50px;">#</th>
                            <th style="width:60px;">Photo</th>
                            <th>Adm No</th>
                            <th>Member Name</th>
                            <th>Class</th>
                            <th>Division</th>
                            <th>Barcode</th>
                            <th>Book Title</th>
                            <th>Author</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Days</th>
                            <th>Fine</th>
                            <th style="width:100px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $sn = 1; foreach($overdueBooks as $book): 
                            $days = max(1, ceil((time() - strtotime($book['due_date'])) / 86400));
                            $fine = $days * $finePerDay;
                            $photoUrl = '';
                            if (!empty($book['photo_path'])) {
                                $photoPath = $book['photo_path'];
                                if (strpos($photoPath, 'uploads/') === 0) $fullPath = BASE_PATH . '/' . $photoPath;
                                elseif (strpos($photoPath, '/') !== 0 && strpos($photoPath, ':\\') === false) $fullPath = BASE_PATH . '/' . ltrim($photoPath, '/');
                                else $fullPath = $photoPath;
                                if (file_exists($fullPath)) $photoUrl = getWebImageUrl($photoPath);
                            }
                        ?>
                        <tr>
                            <td class="text-center"><?= $sn++ ?></td>
                            <td class="text-center">
                                <?php if ($photoUrl): ?>
                                    <img src="<?= $photoUrl ?>" class="member-photo-thumb" alt="Photo" onerror="this.onerror=null;this.style.display='none';this.parentElement.querySelector('.photo-placeholder').style.display='flex';">
                                    <div class="photo-placeholder" style="display:none;margin:0 auto;"><i class="fas fa-user"></i></div>
                                <?php else: ?>
                                    <div class="photo-placeholder" style="margin:0 auto;"><i class="fas fa-user"></i></div>
                                <?php endif; ?>
                            </td>
                            <td><code class="barcode-text"><?= htmlspecialchars($book['admno']) ?></code></td>
                            <td><strong><?= htmlspecialchars($book['member_name']) ?></strong></td>
                            <td><?= htmlspecialchars($book['class'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($book['division'] ?? '-') ?></td>
                            <td><code class="barcode-text"><?= htmlspecialchars($book['barcode']) ?></code></td>
                            <td><?= htmlspecialchars($book['title'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                            <td><?= formatDate($book['issue_date']) ?></td>
                            <td>
                                <?= formatDate($book['due_date']) ?>
                                <span class="badge bg-danger ms-1"><?= $days ?>d</span>
                            </td>
                            <td class="text-danger fw-bold"><?= formatCurrency($fine) ?></td>
                            <td>
                                <form method="post" action="return.php" style="display:inline-block">
                                    <input type="hidden" name="barcode" value="<?= htmlspecialchars($book['barcode']) ?>">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <button type="submit" name="return" class="btn btn-sm btn-warning" onclick="return confirm('Process return with fine?')">
                                        <i class="fas fa-undo"></i> Return
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($overdueBooks)): ?>
                        <tr><td colspan="14" class="text-center py-4 text-muted"><i class="fas fa-check-circle me-2"></i>No overdue books found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <?php if(!empty($overdueBooks)): ?>
                    <tfoot>
                        <tr class="fw-bold">
                            <td colspan="12" class="text-end">Total Estimated Fine:</td>
                            <td colspan="2" class="text-danger"><?= formatCurrency($totalFine) ?></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function exportExcel() {
    let classFilter = document.querySelector('input[name="class"]').value;
    let divisionFilter = document.querySelector('input[name="division"]').value;
    let memberFilter = document.querySelector('select[name="member_admno"]').value;
    let url = '?export=excel';
    if(classFilter) url += '&class=' + encodeURIComponent(classFilter);
    if(divisionFilter) url += '&division=' + encodeURIComponent(divisionFilter);
    if(memberFilter) url += '&member_admno=' + encodeURIComponent(memberFilter);
    window.location.href = url;
}

function exportPDF(paperSize, orientation) {
    let classFilter = document.querySelector('input[name="class"]').value;
    let divisionFilter = document.querySelector('input[name="division"]').value;
    let memberFilter = document.querySelector('select[name="member_admno"]').value;
    let url = '?export=pdf&paper_size=' + paperSize + '&orientation=' + orientation;
    if(classFilter) url += '&class=' + encodeURIComponent(classFilter);
    if(divisionFilter) url += '&division=' + encodeURIComponent(divisionFilter);
    if(memberFilter) url += '&member_admno=' + encodeURIComponent(memberFilter);
    window.location.href = url;
}

function filterByMember(admno) {
    let select = document.querySelector('select[name="member_admno"]');
    if(select) { select.value = admno; document.querySelector('form').submit(); }
}
</script>

<?php renderFooter(); ?>