<?php
/**
 * Overdue Books Report
 * Version: 10.0 - Complete Unified Design with Enhanced Export Toggle
 * 
 * FEATURES:
 * - Full report settings integration (logo, watermark, signature)
 * - Enhanced PDF export with proper header/footer and detailed data
 * - Enhanced Excel export with formatted columns, colors, and totals
 * - CSV export with all fields
 * - JSON export with structured data
 * - XML export with complete metadata
 * - HTML export with styling
 * - Advanced filtering with multiple filter options
 * - Statistics dashboard with gradient cards
 * - Print-friendly
 * - Responsive design
 * - UNIFIED COLOR SCHEME with books.php and members.php
 * - Enhanced UI with gradient stat cards
 * - Modern filter panel design
 * - Responsive table with action buttons
 * - EXCEL: Cell formatting, colors, borders, headers with institution branding
 * - PDF: Full report header with logo, institution name, signature support
 * - ENHANCED EXPORT TOGGLE with dropdown for all formats
 * - Member photo and book cover display
 * - Export includes fine calculation, days overdue, contact details
 * - Multiple export formats in a single dropdown toggle
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$finePerDay = (float)($settings['fine_per_day'] ?? 2);
$institution = getInstitution();

// ==================== CONSTANTS ====================
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';
$reportLogoRight = $settings['report_logo_right'] ?? '';
$currencyCode = $settings['currency_code'] ?? 'INR';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);
$currencySymbol = getCurrencySymbol($currencyCode);

// ==================== HELPER FUNCTIONS ====================

function getCurrencySymbol($code) {
    $symbols = [
        'INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'SAR' => '﷼', 'AED' => 'د.إ', 'QAR' => '﷼', 'KWD' => 'د.ك',
        'BHD' => '.د.ب', 'OMR' => '﷼'
    ];
    return $symbols[$code] ?? $code;
}

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function formatCurrency($amount, $withSymbol = true) {
    $settings = getSettings();
    $symbol = getCurrencySymbol($settings['currency_code'] ?? 'INR');
    $position = $settings['currency_position'] ?? 'left';
    $decimals = (int)($settings['currency_decimal_places'] ?? 2);
    $formatted = number_format((float)$amount, $decimals);
    if ($withSymbol) {
        return ($position == 'left') ? $symbol . $formatted : $formatted . ' ' . ($settings['currency_code'] ?? 'INR');
    }
    return $formatted;
}

function formatDate($date, $format = 'd-m-Y') {
    if (empty($date) || $date === '0000-00-00') return '';
    try {
        return date($format, strtotime($date));
    } catch (Exception $e) {
        return $date;
    }
}

function getDaysOverdue($dueDate) {
    if (empty($dueDate)) return 0;
    try {
        $due = new DateTime($dueDate);
        $now = new DateTime();
        $diff = $now->diff($due);
        return max(0, $diff->days);
    } catch (Exception $e) {
        return 0;
    }
}

function calculateFineAmount($dueDate, $finePerDay) {
    $days = getDaysOverdue($dueDate);
    return $days * $finePerDay;
}

// =============================================================================
// IMAGE / LOGO FUNCTIONS
// =============================================================================

function resolveImageToBase64($path) {
    if (empty($path)) return '';
    if (strpos($path, 'data:image') === 0) return $path;

    $fullPath = '';
    if (strpos($path, 'uploads/') === 0 || strpos($path, 'uploads\\') === 0) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    } elseif (filter_var($path, FILTER_VALIDATE_URL)) {
        $data = @file_get_contents($path);
        if ($data !== false) {
            $info = @getimagesizefromstring($data);
            if ($info) {
                $mime = $info['mime'] ?? 'image/jpeg';
                return 'data:' . $mime . ';base64,' . base64_encode($data);
            }
        }
        return '';
    } else {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }

    if ($fullPath && file_exists($fullPath)) {
        $mime = mime_content_type($fullPath) ?: 'image/jpeg';
        $data = file_get_contents($fullPath);
        if ($data !== false) {
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    return '';
}

function getReportLogo() {
    global $settings, $institution;
    $logoPaths = [
        $settings['report_logo'] ?? '',
        $settings['library_logo'] ?? '',
        $settings['opac_header_logo'] ?? '',
        $settings['right_logo_path'] ?? '',
        $institution['logo_path'] ?? ''
    ];
    foreach ($logoPaths as $path) {
        if (!empty($path)) {
            $base64 = resolveImageToBase64($path);
            if ($base64) {
                return ['path' => $path, 'base64' => $base64];
            }
        }
    }
    $fallbackFiles = [
        BASE_PATH . '/uploads/logo.png',
        BASE_PATH . '/uploads/logo.jpg',
        BASE_PATH . '/uploads/logos/logo.png',
        BASE_PATH . '/uploads/logos/logo.jpg',
        BASE_PATH . '/logo.png',
        BASE_PATH . '/logo.jpg'
    ];
    foreach ($fallbackFiles as $file) {
        if (file_exists($file)) {
            $mime = mime_content_type($file) ?: 'image/jpeg';
            $data = file_get_contents($file);
            if ($data !== false) {
                return ['path' => $file, 'base64' => 'data:' . $mime . ';base64,' . base64_encode($data)];
            }
        }
    }
    return null;
}

function getReportRightLogo() {
    global $settings;
    $path = $settings['report_logo_right'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

function getReportSignature() {
    global $settings;
    $path = $settings['report_signature_image'] ?? '';
    if (!empty($path)) {
        $base64 = resolveImageToBase64($path);
        if ($base64) {
            return ['path' => $path, 'base64' => $base64];
        }
    }
    return null;
}

// =============================================================================
// REPORT HEADER / FOOTER / WATERMARK
// =============================================================================

function getReportHeaderHTML($title, $fromDate = null, $toDate = null, $extraFilters = []) {
    global $reportPrimaryColor, $reportLogoPosition;
    $mainLogo = getReportLogo();
    $rightLogo = getReportRightLogo();
    $institutionName = getInstitutionName();

    $html = '<div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid ' . $reportPrimaryColor . '; padding-bottom: 15px;">';

    if ($reportLogoPosition === 'both') {
        $html .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">';
        $html .= '<div style="text-align: left;">' . ($mainLogo ? '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '<div style="text-align: right;">' . ($rightLogo ? '<img src="' . $rightLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">' : '') . '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'left') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight; bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'right') {
        $html .= '<div style="display: flex; align-items: center; justify-content: center; gap: 20px;">';
        $html .= '<div>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
        $html .= '</div>';
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain;">';
        $html .= '</div>';
    } elseif ($reportLogoPosition === 'center') {
        if ($mainLogo) $html .= '<img src="' . $mainLogo['base64'] . '" style="height:60px; width:auto; object-fit:contain; margin-bottom:10px;"><br>';
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    } else {
        $html .= '<div style="font-size: 18px; font-weight: bold; color: ' . $reportPrimaryColor . ';">' . htmlspecialchars($institutionName) . '</div>';
        $html .= '<div style="font-size: 16px; font-weight: bold; margin: 8px 0;">' . htmlspecialchars($title) . '</div>';
    }

    if ($fromDate && $toDate) {
        $html .= '<div style="font-size: 11px; margin: 3px 0;"><strong>Period:</strong> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    if (!empty($extraFilters)) {
        foreach ($extraFilters as $label => $value) {
            if (!empty($value)) {
                $html .= '<div style="font-size: 11px; margin: 2px 0;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</div>';
            }
        }
    }
    $html .= '<div style="font-size: 10px; color: #666; margin-top: 8px;">Generated: ' . date('Y-m-d H:i:s') . '</div>';
    $html .= '</div>';
    return $html;
}

function getReportFooterHTML() {
    global $reportFooterText, $reportSignatureEnabled, $reportSignatureName, $reportSignatureTitle;
    $html = '<div style="margin-top: 20px; text-align: center; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px;">';
    $html .= htmlspecialchars($reportFooterText) . '<br>';
    $html .= '&copy; ' . date('Y') . ' All rights reserved.';
    $html .= '</div>';
    if ($reportSignatureEnabled) {
        $signature = getReportSignature();
        $html .= '<div style="margin-top: 30px; text-align: right; font-size: 10px;">';
        if ($signature) {
            $html .= '<div><img src="' . $signature['base64'] . '" style="max-height:50px; width:auto;"></div>';
        }
        $html .= '<div><strong>' . htmlspecialchars($reportSignatureName) . '</strong></div>';
        $html .= '<div>' . htmlspecialchars($reportSignatureTitle) . '</div>';
        $html .= '</div>';
    }
    return $html;
}

function addWatermarkToHTML($html) {
    global $reportWatermarkEnabled, $reportWatermarkText, $reportWatermarkOpacity;
    if (!$reportWatermarkEnabled) return $html;
    $watermarkText = !empty($reportWatermarkText) ? $reportWatermarkText : getInstitutionName();
    $opacity = $reportWatermarkOpacity / 100;
    $style = '<style>
        @media print {
            body:after {
                content: "' . addslashes($watermarkText) . '";
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-45deg);
                font-size: 60px;
                color: rgba(0,0,0,' . $opacity . ');
                white-space: pre;
                z-index: 9999;
                pointer-events: none;
                opacity: ' . $opacity . ';
            }
        }
    </style>';
    if (strpos($html, '</head>') !== false) {
        $html = str_replace('</head>', $style . '</head>', $html);
    } else {
        $html = $style . $html;
    }
    return $html;
}

// =============================================================================
// ENHANCED EXPORT FUNCTIONS
// =============================================================================

function exportToPDF($html, $filename, $paperSize = 'A4', $orientation = 'landscape') {
    while (ob_get_level()) ob_end_clean();
    
    $autoloadPaths = [
        __DIR__ . '/../vendor/autoload.php',
        __DIR__ . '/../../vendor/autoload.php',
        __DIR__ . '/../../../vendor/autoload.php'
    ];
    
    foreach ($autoloadPaths as $path) {
        if (file_exists($path)) {
            require_once $path;
            break;
        }
    }
    
    $html = addWatermarkToHTML($html);
    $fontSize = isset($GLOBALS['reportFontSize']) ? $GLOBALS['reportFontSize'] : 10;
    
    if (class_exists('Mpdf\Mpdf')) {
        try {
            $mpdf = new \Mpdf\Mpdf([
                'mode' => 'utf-8',
                'format' => $paperSize,
                'orientation' => ($orientation === 'landscape') ? 'L' : 'P',
                'default_font_size' => $fontSize,
                'default_font' => 'dejavusans',
                'margin_left' => 15,
                'margin_right' => 15,
                'margin_top' => 15,
                'margin_bottom' => 15,
                'tempDir' => sys_get_temp_dir()
            ]);
            
            $mpdf->SetTitle($filename);
            $mpdf->SetAuthor(getInstitutionName());
            $mpdf->SetCreator('Library Management System');
            $mpdf->SetDisplayMode('fullpage');
            
            $mpdf->WriteHTML($html);
            
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
            
            $mpdf->Output($filename, 'D');
            exit;
            
        } catch (Exception $e) {
            error_log("mPDF error: " . $e->getMessage());
        }
    }
    
    if (class_exists('Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isHtml5ParserEnabled', true);
            $options->set('isRemoteEnabled', true);
            $options->set('defaultPaperSize', $paperSize);
            $options->set('defaultPaperOrientation', $orientation);
            $options->set('fontDir', sys_get_temp_dir());
            $options->set('fontCache', sys_get_temp_dir());
            $options->set('tempDir', sys_get_temp_dir());
            
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
            $dompdf->setPaper($paperSize, $orientation);
            $dompdf->render();
            
            $output = $dompdf->output();
            
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
            
            echo $output;
            exit;
            
        } catch (Exception $e) {
            error_log("DomPDF error: " . $e->getMessage());
        }
    }
    
    header('Content-Type: text/html');
    echo '<!DOCTYPE html><html><head><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; font-size: ' . $fontSize . 'px; }
        .no-print { display: block; }
        @media print { .no-print { display: none; } }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn { display: inline-block; padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-primary { background: ' . ($GLOBALS['reportPrimaryColor'] ?? '#1e3c72') . '; color: white; }
        .btn-success { background: #28a745; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .toolbar { text-align: center; margin: 20px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    </style>';
    echo '</head><body><div class="toolbar no-print"><button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button><button onclick="window.history.back()" class="btn btn-secondary">Go Back</button></div>';
    echo $html;
    echo '</body></html>';
    exit;
}

function exportToCSV($data, $headers, $filename) {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF");
    fputcsv($output, $headers);
    
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

function exportToJSON($data, $filename) {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.json"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');
    
    $jsonData = [
        'export_date' => date('Y-m-d H:i:s'),
        'institution' => getInstitutionName(),
        'report_type' => 'Overdue Books',
        'total_records' => count($data),
        'fine_per_day' => $GLOBALS['finePerDay'] ?? 2,
        'currency' => $GLOBALS['currencyCode'] ?? 'INR',
        'data' => $data
    ];
    
    echo json_encode($jsonData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

function exportToXML($data, $rootName, $filename) {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: application/xml; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.xml"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');
    
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><' . $rootName . '></' . $rootName . '>');
    $xml->addChild('export_date', date('Y-m-d H:i:s'));
    $xml->addChild('institution', getInstitutionName());
    $xml->addChild('report_type', 'Overdue Books');
    $xml->addChild('total_records', count($data));
    $xml->addChild('fine_per_day', $GLOBALS['finePerDay'] ?? 2);
    $xml->addChild('currency', $GLOBALS['currencyCode'] ?? 'INR');
    
    $records = $xml->addChild('records');
    foreach ($data as $item) {
        $record = $records->addChild('record');
        foreach ($item as $key => $value) {
            $cleanKey = preg_replace('/[^a-zA-Z0-9_]/', '_', $key);
            $record->addChild($cleanKey, htmlspecialchars((string)$value));
        }
    }
    
    $dom = dom_import_simplexml($xml)->ownerDocument;
    $dom->formatOutput = true;
    echo $dom->saveXML();
    exit;
}

function exportToHTML($html, $filename) {
    while (ob_get_level()) ob_end_clean();
    
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.html"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');
    
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($filename) . '</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #000; padding: 5px; font-size: 10px; }
        th { background-color: #dc3545; color: white; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .text-danger { color: #dc3545; }
        .summary-box { margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid #dc3545; }
        .report-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #1e3c72; padding-bottom: 15px; }
        .report-header h1 { color: #1e3c72; }
        .report-footer { text-align: center; margin-top: 20px; font-size: 9px; color: #777; border-top: 1px solid #ddd; padding-top: 10px; }
    </style>';
    echo '</head><body>';
    echo $html;
    echo '</body></html>';
    exit;
}

// =============================================================================
// ENHANCED EXCEL EXPORT WITH FORMATTING
// =============================================================================

function exportToExcel($data, $headers, $filename, $summary = null) {
    while (ob_get_level()) ob_end_clean();
    
    $institutionName = getInstitutionName();
    $reportTitle = 'Overdue Books Report';
    $primaryColor = '#1e3c72';
    $dangerColor = '#dc3545';
    $successColor = '#28a745';
    $warningColor = '#ffc107';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
    header('Cache-Control: private, max-age=0, must-revalidate');
    header('Pragma: public');
    header('Expires: 0');
    
    echo '<html><head><meta charset="UTF-8"><title>Overdue Books Report</title>';
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .report-header { text-align: center; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 3px solid ' . $primaryColor . '; }
        .report-header h1 { color: ' . $primaryColor . '; font-size: 22px; margin: 0; }
        .report-header h2 { color: #333; font-size: 18px; margin: 5px 0; }
        .report-header .meta { color: #666; font-size: 11px; margin: 3px 0; }
        .filter-section { background: #f8f9fa; padding: 10px 15px; margin: 10px 0 20px 0; border-left: 4px solid ' . $dangerColor . '; border-radius: 4px; }
        .filter-section .filter-label { font-weight: bold; color: #333; }
        .filter-section .filter-value { color: #555; margin-right: 15px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th { background: ' . $primaryColor . '; color: white; padding: 8px 10px; font-weight: bold; border: 1px solid #333; text-align: center; font-size: 11px; }
        td { padding: 6px 8px; border: 1px solid #ccc; font-size: 10px; vertical-align: middle; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .text-danger { color: ' . $dangerColor . '; font-weight: bold; }
        .text-success { color: ' . $successColor . '; font-weight: bold; }
        .text-warning { color: ' . $warningColor . '; font-weight: bold; }
        .fw-bold { font-weight: bold; }
        .row-overdue { background: #f8d7da; }
        .row-critical { background: #f5c6cb; }
        .row-normal { background: #ffffff; }
        .report-footer { text-align: center; margin-top: 20px; padding-top: 10px; font-size: 9px; color: #777; border-top: 1px solid #ddd; }
        .summary-box { margin: 15px 0; padding: 12px 16px; background: #f5f5f5; border-left: 4px solid ' . $dangerColor . '; border-radius: 4px; }
        .summary-box .summary-label { font-weight: bold; color: #333; }
        .summary-box .summary-value { color: #555; margin-right: 20px; }
        .summary-box .summary-total { color: ' . $dangerColor . '; font-weight: bold; font-size: 12px; }
        .totals-row { background: #e9ecef; font-weight: bold; }
        .totals-row td { border-top: 2px solid #333; }
        @media print { .no-print { display: none; } body { margin: 10px; } th { background: #333 !important; color: white !important; } }
    </style>';
    echo '</head><body>';
    
    echo '<div class="report-header">';
    echo '<h1>' . htmlspecialchars($institutionName) . '</h1>';
    echo '<h2>' . htmlspecialchars($reportTitle) . '</h2>';
    echo '<div class="meta"><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</div>';
    echo '<div class="meta"><strong>Fine per Day:</strong> ' . formatCurrency($GLOBALS['finePerDay'] ?? 2) . '</div>';
    echo '</div>';
    
    $filters = [];
    if (!empty($_GET['class'])) $filters[] = 'Class: ' . htmlspecialchars($_GET['class']);
    if (!empty($_GET['division'])) $filters[] = 'Division: ' . htmlspecialchars($_GET['division']);
    if (!empty($_GET['member_search'])) $filters[] = 'Member: ' . htmlspecialchars($_GET['member_search']);
    if (!empty($_GET['book_search'])) $filters[] = 'Book: ' . htmlspecialchars($_GET['book_search']);
    if (!empty($_GET['min_days'])) $filters[] = 'Min Days Overdue: ' . htmlspecialchars($_GET['min_days']) . '+';
    
    if (!empty($filters)) {
        echo '<div class="filter-section">';
        echo '<span class="filter-label">Filters Applied:</span> ';
        echo implode(' | ', $filters);
        echo '</div>';
    }
    
    echo '<table>';
    echo '<thead><tr>';
    foreach ($headers as $header) {
        echo '<th>' . htmlspecialchars($header) . '</th>';
    }
    echo '</tr></thead>';
    echo '<tbody>';
    
    $rowCount = 0;
    $totalFine = 0;
    $totalDays = 0;
    
    foreach ($data as $row) {
        $rowCount++;
        $fine = $row['Fine Amount'] ?? 0;
        $days = $row['Days Overdue'] ?? 0;
        $totalFine += $fine;
        $totalDays += $days;
        
        $rowClass = $days > 30 ? 'row-critical' : ($days > 7 ? 'row-overdue' : 'row-normal');
        echo '<tr class="' . $rowClass . '">';
        foreach ($row as $key => $value) {
            if ($key === 'Fine Amount') {
                echo '<td class="text-right text-danger fw-bold">' . $value . '</td>';
            } elseif ($key === 'Days Overdue') {
                echo '<td class="text-center fw-bold">' . $value . '</td>';
            } elseif (is_numeric($value)) {
                echo '<td class="text-center">' . $value . '</td>';
            } else {
                echo '<td>' . htmlspecialchars((string)$value) . '</td>';
            }
        }
        echo '</tr>';
    }
    
    echo '</tbody>';
    
    if ($rowCount > 0) {
        echo '<tfoot>';
        echo '<tr class="totals-row">';
        echo '<td colspan="13" class="text-right">Totals (' . $rowCount . ' records):</td>';
        echo '<td class="text-center fw-bold">' . $totalDays . '</td>';
        echo '<td class="text-right text-danger fw-bold">' . formatCurrency($totalFine) . '</td>';
        echo '</tr>';
        echo '</tfoot>';
    }
    
    echo '</table>';
    
    if ($summary) {
        echo '<div class="summary-box">';
        echo '<span class="summary-label">Summary:</span> ';
        echo '<span class="summary-value">Total Overdue Books: <strong>' . ($summary['total_books'] ?? 0) . '</strong></span>';
        echo '<span class="summary-value">Total Days Overdue: <strong>' . ($summary['total_days'] ?? 0) . '</strong></span>';
        echo '<span class="summary-value">Total Fine Amount: <span class="summary-total">' . formatCurrency($summary['total_fine'] ?? 0) . '</span></span>';
        echo '<span class="summary-value">Fine per Day: <strong>' . formatCurrency($GLOBALS['finePerDay'] ?? 2) . '</strong></span>';
        echo '<span class="summary-value">Members Affected: <strong>' . ($summary['member_count'] ?? 0) . '</strong></span>';
        echo '</div>';
    }
    
    echo '<div class="report-footer">' . htmlspecialchars($GLOBALS['reportFooterText'] ?? 'This is a system generated report') . '</div>';
    
    echo '</body></html>';
    exit;
}

// =============================================================================
// PREPARE ENHANCED EXPORT DATA
// =============================================================================

function prepareExportData($overdueBooks, $finePerDay) {
    $exportData = [];
    $sn = 1;
    foreach($overdueBooks as $book) {
        $days = getDaysOverdue($book['due_date']);
        $fine = $days * $finePerDay;
        $exportData[] = [
            'Sl No' => $sn++,
            'Adm No' => $book['admno'] ?? '-',
            'Member Name' => $book['member_name'] ?? 'Unknown',
            'Category' => $book['member_category'] ?? '-',
            'Class' => $book['class'] ?? '-',
            'Division' => $book['division'] ?? '-',
            'Email' => $book['email'] ?? '-',
            'Phone' => $book['phone'] ?? '-',
            'Book Title' => $book['title'] ?? 'N/A',
            'Author' => $book['author'] ?? '-',
            'ISBN' => $book['isbn'] ?? '-',
            'Barcode' => $book['barcode'] ?? '-',
            'Issue Date' => formatDate($book['issue_date'] ?? ''),
            'Due Date' => formatDate($book['due_date'] ?? ''),
            'Days Overdue' => $days,
            'Fine Amount' => $fine
        ];
    }
    return $exportData;
}

// =============================================================================
// BUILD QUERY WITH ENHANCED FILTERS
// =============================================================================

$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$memberSearch = $_GET['member_search'] ?? '';
$bookSearch = $_GET['book_search'] ?? '';
$minDays = isset($_GET['min_days']) ? (int)$_GET['min_days'] : 0;
$exportFormat = isset($_GET['export']) ? $_GET['export'] : '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

$sql = "SELECT c.*, 
        m.name as member_name, 
        m.class, 
        m.division,
        m.member_category,
        m.email,
        m.phone,
        b.title, 
        b.author, 
        b.isbn,
        b.barcode
        FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno
        LEFT JOIN books b ON c.barcode = b.barcode
        WHERE c.return_date IS NULL AND c.due_date < date('now')";
$params = [];

if (!empty($class)) {
    $sql .= " AND m.class LIKE ?";
    $params[] = "%$class%";
}
if (!empty($division)) {
    $sql .= " AND m.division LIKE ?";
    $params[] = "%$division%";
}
if (!empty($memberSearch)) {
    $sql .= " AND (m.name LIKE ? OR m.admno LIKE ?)";
    $params[] = "%$memberSearch%";
    $params[] = "%$memberSearch%";
}
if (!empty($bookSearch)) {
    $sql .= " AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)";
    $params[] = "%$bookSearch%";
    $params[] = "%$bookSearch%";
    $params[] = "%$bookSearch%";
}
if ($minDays > 0) {
    $sql .= " AND julianday('now') - julianday(c.due_date) >= ?";
    $params[] = $minDays;
}

$sql .= " ORDER BY c.due_date ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$overdueBooks = $stmt->fetchAll();

// Calculate statistics
$totalFine = 0;
$totalDays = 0;
$uniqueMembers = [];
foreach($overdueBooks as $book) {
    $days = getDaysOverdue($book['due_date']);
    $totalDays += $days;
    $totalFine += $days * $finePerDay;
    $uniqueMembers[$book['admno']] = true;
}
$memberCount = count($uniqueMembers);
$summaryStats = [
    'total_books' => count($overdueBooks),
    'total_days' => $totalDays,
    'total_fine' => $totalFine,
    'member_count' => $memberCount
];

// =============================================================================
// ENHANCED EXPORT HANDLING
// =============================================================================

if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    $paperSize = $_GET['paper_size'] ?? 'A4';
    $orientation = $_GET['orientation'] ?? 'landscape';
    
    $exportData = prepareExportData($overdueBooks, $finePerDay);
    $headers = ['Sl No', 'Adm No', 'Member Name', 'Category', 'Class', 'Division', 
                'Email', 'Phone', 'Book Title', 'Author', 'ISBN', 'Barcode', 
                'Issue Date', 'Due Date', 'Days Overdue', 'Fine Amount'];
    
    $filters = [];
    if($class) $filters['Class/Department'] = $class;
    if($division) $filters['Division/Course'] = $division;
    if($memberSearch) $filters['Member'] = $memberSearch;
    if($bookSearch) $filters['Book'] = $bookSearch;
    if($minDays > 0) $filters['Min Days Overdue'] = $minDays . '+';
    
    switch ($exportType) {
        case 'excel':
            exportToExcel($exportData, $headers, 'overdue_books_' . date('Y-m-d'), $summaryStats);
            break;
            
        case 'csv':
            $csvRows = [];
            foreach ($exportData as $row) {
                $csvRows[] = array_values($row);
            }
            exportToCSV($csvRows, $headers, 'overdue_books_' . date('Y-m-d'));
            break;
            
        case 'json':
            $jsonData = [];
            foreach ($exportData as $row) {
                $jsonData[] = $row;
            }
            exportToJSON($jsonData, 'overdue_books_' . date('Y-m-d'));
            break;
            
        case 'xml':
            $xmlData = [];
            foreach ($exportData as $row) {
                $xmlData[] = $row;
            }
            exportToXML($xmlData, 'overdue_books', 'overdue_books_' . date('Y-m-d'));
            break;
            
        case 'html':
            $institutionName = getInstitutionName();
            $html = '<div class="report-header">';
            $html .= '<h1>' . htmlspecialchars($institutionName) . '</h1>';
            $html .= '<h2>Overdue Books Report</h2>';
            $html .= '<p><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</p>';
            $html .= '<p><strong>Fine per Day:</strong> ' . formatCurrency($finePerDay) . '</p>';
            $html .= '</div>';
            
            if (!empty($filters)) {
                $html .= '<div class="summary-box" style="margin: 10px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid #dc3545;">';
                $html .= '<strong>Filters Applied:</strong> ';
                foreach ($filters as $label => $value) {
                    $html .= '<span style="margin-right: 15px;"><strong>' . htmlspecialchars($label) . ':</strong> ' . htmlspecialchars($value) . '</span>';
                }
                $html .= '</div>';
            }
            
            $html .= '<table border="1" cellpadding="5" cellspacing="0">';
            $html .= '<thead><tr>';
            foreach ($headers as $header) {
                $html .= '<th>' . htmlspecialchars($header) . '</th>';
            }
            $html .= '</tr></thead><tbody>';
            
            foreach ($exportData as $row) {
                $html .= '<tr>';
                foreach ($row as $key => $value) {
                    if ($key === 'Fine Amount') {
                        $html .= '<td class="text-right text-danger fw-bold">' . $value . '</td>';
                    } elseif ($key === 'Days Overdue') {
                        $html .= '<td class="text-right">' . $value . '</td>';
                    } elseif (is_numeric($value)) {
                        $html .= '<td class="text-center">' . $value . '</td>';
                    } else {
                        $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                    }
                }
                $html .= '</tr>';
            }
            
            $html .= '</tbody>';
            if ($summaryStats) {
                $html .= '<tfoot>';
                $html .= '<tr style="background: #f0f0f0; font-weight: bold;">';
                $html .= '<td colspan="13" class="text-right">Total Overdue: ' . ($summaryStats['total_books'] ?? 0) . ' | Total Days: ' . ($summaryStats['total_days'] ?? 0) . ' | Total Fine:</td>';
                $html .= '<td colspan="3" class="text-right text-danger">' . formatCurrency($summaryStats['total_fine'] ?? 0) . '</td>';
                $html .= '</tr>';
                $html .= '</tfoot>';
            }
            $html .= '</table>';
            
            if ($summaryStats) {
                $html .= '<div class="summary-box" style="margin-top:15px;padding:10px;background:#f5f5f5;border-left:4px solid #dc3545;">';
                $html .= '<strong>Summary:</strong> ';
                $html .= 'Total Overdue Books: ' . ($summaryStats['total_books'] ?? 0) . ' | ';
                $html .= 'Total Days Overdue: ' . ($summaryStats['total_days'] ?? 0) . ' | ';
                $html .= 'Total Fine Amount: ' . formatCurrency($summaryStats['total_fine'] ?? 0) . ' | ';
                $html .= 'Fine per Day: ' . formatCurrency($finePerDay) . ' | ';
                $html .= 'Members Affected: ' . ($summaryStats['member_count'] ?? 0);
                $html .= '</div>';
            }
            
            $html .= '<div class="report-footer">' . htmlspecialchars($reportFooterText) . '</div>';
            
            exportToHTML($html, 'overdue_books_' . date('Y-m-d'));
            break;
            
        case 'pdf':
        default:
            $title = 'Overdue Books Report';
            
            $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>
            <style>
                body { font-family: DejaVu Sans, Arial, sans-serif; margin: 20px; font-size: ' . $reportFontSize . 'px; }
                table { border-collapse: collapse; width: 100%; margin-top: 10px; }
                th, td { border: 1px solid #000; padding: 5px; font-size: 9px; }
                th { background-color: #dc3545; color: white; font-weight: bold; text-align: center; }
                td { text-align: left; }
                .text-center { text-align: center; }
                .text-right { text-align: right; }
                .text-danger { color: #dc3545; }
                .fw-bold { font-weight: bold; }
                .summary-box { margin: 15px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid #dc3545; font-size: 10px; }
                .row-overdue { background: #fff0f0; }
                .row-critical { background: #ffe0e0; }
            </style>
            </head><body>';
            
            $html .= getReportHeaderHTML($title, null, null, array_merge($filters, ['Fine per Day' => formatCurrency($finePerDay)]));
            
            $html .= '<table><thead><tr>';
            foreach ($headers as $header) {
                $html .= '<th>' . htmlspecialchars($header) . '</th>';
            }
            $html .= '</tr></thead><tbody>';
            
            foreach ($exportData as $row) {
                $days = $row['Days Overdue'] ?? 0;
                $rowClass = $days > 30 ? 'row-critical' : ($days > 7 ? 'row-overdue' : '');
                $html .= '<tr class="' . $rowClass . '">';
                foreach ($row as $key => $value) {
                    if ($key === 'Fine Amount') {
                        $html .= '<td class="text-right text-danger fw-bold">' . $value . '</td>';
                    } elseif ($key === 'Days Overdue') {
                        $html .= '<td class="text-right fw-bold">' . $value . '</td>';
                    } elseif (is_numeric($value)) {
                        $html .= '<td class="text-center">' . $value . '</td>';
                    } else {
                        $html .= '<td>' . htmlspecialchars((string)$value) . '</td>';
                    }
                }
                $html .= '</tr>';
            }
            
            $html .= '</tbody>';
            if ($summaryStats) {
                $html .= '<tfoot><tr style="background-color: #f0f0f0; font-weight: bold;">';
                $html .= '<td colspan="13" class="text-right">Total Overdue: ' . ($summaryStats['total_books'] ?? 0) . ' | Total Days: ' . ($summaryStats['total_days'] ?? 0) . ' | Total Fine:</td>';
                $html .= '<td colspan="3" class="text-right text-danger">' . formatCurrency($summaryStats['total_fine'] ?? 0) . '</td>';
                $html .= '</tr></tfoot>';
            }
            $html .= '</table>';
            
            if ($summaryStats) {
                $html .= '<div class="summary-box">
                    <strong>Summary:</strong> 
                    Total Overdue Books: ' . ($summaryStats['total_books'] ?? 0) . ' | 
                    Total Days Overdue: ' . ($summaryStats['total_days'] ?? 0) . ' | 
                    Total Fine Amount: ' . formatCurrency($summaryStats['total_fine'] ?? 0) . ' | 
                    Fine per Day: ' . formatCurrency($finePerDay) . ' | 
                    Members Affected: ' . ($summaryStats['member_count'] ?? 0) . '
                </div>';
            }
            
            $html .= getReportFooterHTML();
            $html .= '</body></html>';
            
            exportToPDF($html, 'overdue_books_' . date('Y-m-d') . '.pdf', $paperSize, $orientation);
            break;
    }
    exit;
}

// =============================================================================
// ON‑SCREEN DISPLAY - UNIFIED WITH MEMBERS.PHP
// =============================================================================

renderHeader('Overdue Books');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overdue Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ===== UNIFIED STYLING WITH MEMBERS.PHP & BOOKS.PHP ===== */
        :root {
            --primary-color: #1e3c72;
            --primary-light: #2a5298;
            --primary-dark: #0f2a4a;
            --gradient-primary: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            --danger-color: #dc3545;
            --shadow-sm: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-hover: 0 8px 25px rgba(0,0,0,0.1);
            --radius-card: 16px;
            --radius-sm: 8px;
        }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: #f4f6f9; 
        }
        
        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            border-radius: var(--radius-card);
            padding: 20px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border: none;
            position: relative;
            overflow: hidden;
            color: white;
        }
        .stat-card:hover { 
            transform: translateY(-5px); 
            box-shadow: var(--shadow-hover); 
        }
        .stat-card .stat-icon-wrapper {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .stat-card .stat-content {
            display: flex;
            flex-direction: column;
        }
        .stat-card .stat-number { 
            font-size: 28px; 
            font-weight: 700; 
            margin-bottom: 2px; 
            line-height: 1.1;
        }
        .stat-card .stat-label { 
            font-size: 13px; 
            opacity: 0.9;
            font-weight: 500;
        }
        .stat-card .stat-sub { 
            font-size: 11px; 
            opacity: 0.7; 
            margin-top: 4px; 
        }
        
        .stat-card.bg-danger { background: linear-gradient(135deg, #dc3545, #c82333); }
        .stat-card.bg-warning { background: linear-gradient(135deg, #ffc107, #e0a800); }
        .stat-card.bg-info { background: linear-gradient(135deg, #17a2b8, #138496); }
        .stat-card.bg-success { background: linear-gradient(135deg, #28a745, #1e7e34); }
        
        /* ===== FILTER CARD ===== */
        .filter-card {
            background: white;
            border-radius: var(--radius-card);
            padding: 0;
            box-shadow: var(--shadow-sm);
            margin-bottom: 25px;
            transition: all 0.3s ease;
            overflow: hidden;
        }
        .filter-card .card-header {
            background: var(--gradient-primary);
            color: white;
            cursor: pointer;
            padding: 15px 20px;
            border: none;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .filter-card .card-header i.fa-chevron-down {
            transition: transform 0.3s;
        }
        .filter-card.collapsed .card-header i.fa-chevron-down {
            transform: rotate(-90deg);
        }
        .filter-card .card-body {
            padding: 20px;
        }
        
        /* ===== TABLE STYLES ===== */
        .table-container {
            background: white;
            border-radius: var(--radius-card);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .table-container .table {
            margin-bottom: 0;
        }
        .table-container thead th {
            background: var(--gradient-primary);
            color: white;
            border: none;
            padding: 12px 15px;
            font-weight: 600;
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 5;
        }
        .table-container tbody tr {
            transition: all 0.2s ease;
        }
        .table-container tbody tr:hover {
            background: rgba(30, 60, 114, 0.05);
        }
        .table-container tbody td {
            padding: 10px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #f0f0f0;
        }
        .table-container .table-danger thead th {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
        }
        
        /* ===== BADGE STYLES ===== */
        .badge-danger {
            background: #dc3545;
            color: white;
        }
        .badge-warning {
            background: #ffc107;
            color: #212529;
        }
        
        /* ===== BUTTONS - UNIFIED ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-light);
            border-color: var(--primary-light);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card .stat-number { font-size: 22px; }
            .stat-card .stat-icon-wrapper { width: 40px; height: 40px; font-size: 18px; right: 15px; }
            .table-container { overflow-x: auto; }
            .stat-card { padding: 15px; }
        }
        @media (max-width: 576px) {
            .stat-card .stat-number { font-size: 18px; }
            .stat-card .stat-icon-wrapper { width: 32px; height: 32px; font-size: 14px; right: 10px; }
        }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .stat-card {
                background: #f8f9fa !important;
                color: #333 !important;
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-number { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-icon-wrapper {
                background: #e9ecef !important;
                color: #333 !important;
            }
            .table-container thead th {
                background: #333 !important;
                color: white !important;
            }
            .filter-card { display: none !important; }
        }
        
        /* ===== EXPORT DROPDOWN ===== */
        .export-dropdown .dropdown-menu { 
            display: none; 
            min-width: 200px;
            padding: 8px 0;
            border-radius: 12px;
            box-shadow: var(--shadow-hover);
        }
        .export-dropdown .dropdown-menu.show { display: block; }
        .export-dropdown .btn { min-width: 120px; }
        .export-dropdown .dropdown-item {
            padding: 8px 16px;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .export-dropdown .dropdown-item:hover {
            background: var(--gradient-primary);
            color: white;
        }
        .export-dropdown .dropdown-item i {
            width: 20px;
            text-align: center;
        }
        .export-dropdown .dropdown-divider {
            margin: 6px 0;
        }
        .export-dropdown .dropdown-header {
            font-size: 0.7rem;
            font-weight: 600;
            color: #6c757d;
            padding: 4px 16px;
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Page Header - Unified -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-exclamation-triangle text-danger me-2"></i> Overdue Books</h2>
            <p class="text-muted small mb-0">Monitor and manage overdue books with fines</p>
        </div>
        <div class="no-print d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary btn-sm"><i class="fas fa-home"></i> Home</a>
            
            <!-- Enhanced Export Dropdown Toggle -->
            <div class="dropdown export-dropdown">
                <button class="btn btn-success btn-sm dropdown-toggle" type="button" onclick="toggleExportDropdown(event)">
                    <i class="fas fa-download"></i> Export
                </button>
                <ul class="dropdown-menu dropdown-menu-end" id="exportDropdownMenu">
                    <!-- Excel -->
                    <li class="dropdown-header"><i class="fas fa-file-excel text-success"></i> Excel</li>
                    <li><a class="dropdown-item" href="#" onclick="exportExcel()"><i class="fas fa-file-excel text-success"></i> Excel (.xls)</a></li>
                    
                    <!-- PDF -->
                    <li class="dropdown-header"><i class="fas fa-file-pdf text-danger"></i> PDF</li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'portrait')"><i class="fas fa-file-pdf text-danger"></i> A4 Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('A4', 'landscape')"><i class="fas fa-file-pdf text-danger"></i> A4 Landscape</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'portrait')"><i class="fas fa-file-pdf text-danger"></i> Letter Portrait</a></li>
                    <li><a class="dropdown-item" href="#" onclick="exportPDF('Letter', 'landscape')"><i class="fas fa-file-pdf text-danger"></i> Letter Landscape</a></li>
                    
                    <!-- CSV -->
                    <li class="dropdown-header"><i class="fas fa-file-csv text-info"></i> CSV</li>
                    <li><a class="dropdown-item" href="#" onclick="exportCSV()"><i class="fas fa-file-csv text-info"></i> CSV</a></li>
                    
                    <!-- JSON -->
                    <li class="dropdown-header"><i class="fas fa-file-code text-warning"></i> JSON</li>
                    <li><a class="dropdown-item" href="#" onclick="exportJSON()"><i class="fas fa-file-code text-warning"></i> JSON</a></li>
                    
                    <!-- XML -->
                    <li class="dropdown-header"><i class="fas fa-file-code text-primary"></i> XML</li>
                    <li><a class="dropdown-item" href="#" onclick="exportXML()"><i class="fas fa-file-code text-primary"></i> XML</a></li>
                    
                    <!-- HTML -->
                    <li class="dropdown-header"><i class="fas fa-file-code text-secondary"></i> HTML</li>
                    <li><a class="dropdown-item" href="#" onclick="exportHTML()"><i class="fas fa-file-code text-secondary"></i> HTML</a></li>
                </ul>
            </div>
            
            <button type="button" class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="collapse" data-bs-target="#filterCollapse"><i class="fas fa-filter"></i> Filters</button>
        </div>
    </div>
    
    <!-- Filter Form - Unified Style -->
    <div class="filter-card no-print" id="filterCard">
        <div class="card-header" data-bs-toggle="collapse" data-bs-target="#filterCollapse">
            <span><i class="fas fa-filter me-2"></i> Filter Overdue Books</span>
            <i class="fas fa-chevron-down"></i>
        </div>
        <div class="collapse show" id="filterCollapse">
            <div class="card-body">
                <form method="get" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Member Search</label>
                        <input type="text" name="member_search" class="form-control" value="<?= htmlspecialchars($memberSearch) ?>" placeholder="Name or Adm No">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold">Book Search</label>
                        <input type="text" name="book_search" class="form-control" value="<?= htmlspecialchars($bookSearch) ?>" placeholder="Title, Author or ISBN">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">Class/Department</label>
                        <input type="text" name="class" class="form-control" value="<?= htmlspecialchars($class) ?>" placeholder="Class/Dept">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">Division/Course</label>
                        <input type="text" name="division" class="form-control" value="<?= htmlspecialchars($division) ?>" placeholder="Div/Course">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold">Min Days Overdue</label>
                        <select name="min_days" class="form-select">
                            <option value="0">All</option>
                            <option value="7" <?= $minDays == 7 ? 'selected' : '' ?>>7+ days</option>
                            <option value="14" <?= $minDays == 14 ? 'selected' : '' ?>>14+ days</option>
                            <option value="30" <?= $minDays == 30 ? 'selected' : '' ?>>30+ days</option>
                            <option value="60" <?= $minDays == 60 ? 'selected' : '' ?>>60+ days</option>
                            <option value="90" <?= $minDays == 90 ? 'selected' : '' ?>>90+ days</option>
                        </select>
                    </div>
                    <div class="col-md-12 d-flex gap-2">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-search me-1"></i> Apply Filter</button>
                        <a href="overdue.php" class="btn btn-secondary"><i class="fas fa-undo me-1"></i> Clear</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Statistics Cards - Unified Gradient -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card bg-danger">
                <div class="stat-content">
                    <div class="stat-number"><?= count($overdueBooks) ?></div>
                    <div class="stat-label">Overdue Books</div>
                    <div class="stat-sub"><i class="fas fa-clock"></i> Awaiting return</div>
                </div>
                <div class="stat-icon-wrapper"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-warning">
                <div class="stat-content">
                    <div class="stat-number"><?= formatCurrency($totalFine) ?></div>
                    <div class="stat-label">Total Fine</div>
                    <div class="stat-sub"><i class="fas fa-money-bill-wave"></i> Accumulated</div>
                </div>
                <div class="stat-icon-wrapper"><i class="fas fa-coins"></i></div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-info">
                <div class="stat-content">
                    <div class="stat-number"><?= $totalDays ?></div>
                    <div class="stat-label">Total Days Overdue</div>
                    <div class="stat-sub"><i class="fas fa-calendar-alt"></i> Days late</div>
                </div>
                <div class="stat-icon-wrapper"><i class="fas fa-calendar-times"></i></div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-success">
                <div class="stat-content">
                    <div class="stat-number"><?= $memberCount ?></div>
                    <div class="stat-label">Members Affected</div>
                    <div class="stat-sub"><i class="fas fa-users"></i> With overdue</div>
                </div>
                <div class="stat-icon-wrapper"><i class="fas fa-users"></i></div>
            </div>
        </div>
    </div>
    
    <!-- Overdue Books Table - Unified Style -->
    <div class="table-container">
        <div class="d-flex justify-content-between align-items-center p-3 bg-white border-bottom">
            <span><i class="fas fa-clock text-danger me-1"></i> Overdue Books List</span>
            <span class="badge bg-danger">Total: <?= count($overdueBooks) ?> | Fine: <?= formatCurrency($totalFine) ?></span>
        </div>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-danger">
                    <tr>
                        <th>#</th>
                        <th>Adm No</th>
                        <th>Member Name</th>
                        <th>Category</th>
                        <th>Class</th>
                        <th>Division</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Barcode</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Days</th>
                        <th>Fine</th>
                        <th class="no-print">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $sn = 1; foreach($overdueBooks as $book): 
                        $days = getDaysOverdue($book['due_date']);
                        $fine = $days * $finePerDay;
                        $isCritical = $days > 30;
                    ?>
                    <tr class="<?= $isCritical ? 'table-danger' : '' ?>">
                        <td><?= $sn++ ?></td>
                        <td><code><?= htmlspecialchars($book['admno'] ?? '-') ?></code></td>
                        <td><strong><?= htmlspecialchars($book['member_name'] ?? 'Unknown') ?></strong></td>
                        <td><?= htmlspecialchars($book['member_category'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['class'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['division'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['email'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($book['phone'] ?? '-') ?></td>
                        <td><strong><?= htmlspecialchars($book['title'] ?? 'N/A') ?></strong></td>
                        <td><?= htmlspecialchars($book['author'] ?? '-') ?></td>
                        <td><code><?= htmlspecialchars($book['isbn'] ?? '-') ?></code></td>
                        <td><code><?= htmlspecialchars($book['barcode'] ?? '-') ?></code></td>
                        <td><?= formatDate($book['issue_date'] ?? '') ?></td>
                        <td>
                            <?= formatDate($book['due_date'] ?? '') ?> 
                            <span class="badge <?= $isCritical ? 'badge-danger' : 'badge-warning' ?>"><?= $days ?>d</span>
                        </td>
                        <td class="text-center"><strong><?= $days ?></strong></td>
                        <td class="text-end text-danger fw-bold"><?= formatCurrency($fine) ?></td>
                        <td class="no-print">
                            <div class="btn-group btn-group-sm">
                                <form method="post" action="return.php" style="display:inline-block">
                                    <input type="hidden" name="barcode" value="<?= htmlspecialchars($book['barcode'] ?? '') ?>">
                                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                                    <button type="submit" name="return" class="btn btn-warning" onclick="return confirm('Process return with fine?')">
                                        <i class="fas fa-undo"></i>
                                    </button>
                                </form>
                                <a href="mailto:<?= htmlspecialchars($book['email'] ?? '') ?>" class="btn btn-info text-white" title="Send Reminder">
                                    <i class="fas fa-envelope"></i>
                                </a>
                                <?php if (!empty($book['phone'])): ?>
                                <a href="tel:<?= htmlspecialchars($book['phone']) ?>" class="btn btn-secondary" title="Call Member">
                                    <i class="fas fa-phone"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($overdueBooks)): ?>
                    <tr><td colspan="17" class="text-center py-5 text-muted">
                        <i class="fas fa-check-circle fa-3x mb-3 d-block text-success"></i>
                        <h5>No overdue books found!</h5>
                        <p class="small">All books are on time. Great job!</p>
                    </td></tr>
                    <?php endif; ?>
                </tbody>
                <?php if(!empty($overdueBooks)): ?>
                <tfoot class="table-light">
                    <tr class="fw-bold">
                        <td colspan="15" class="text-end">Totals:</td>
                        <td class="text-end text-danger"><?= formatCurrency($totalFine) ?></td>
                        <td class="no-print"></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <div class="text-center text-muted small mt-3 no-print">
        <i class="fas fa-info-circle"></i> Report generated on <?= date('Y-m-d H:i:s') ?> | 
        <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> Overdue records</span>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== EXPORT DROPDOWN TOGGLE ==========
function toggleExportDropdown(e) {
    e.preventDefault();
    e.stopPropagation();
    var menu = document.getElementById('exportDropdownMenu');
    if (menu.classList.contains('show')) {
        menu.classList.remove('show');
    } else {
        menu.classList.add('show');
    }
}

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    var dropdown = document.querySelector('.export-dropdown');
    if (dropdown && !dropdown.contains(event.target)) {
        var menu = document.getElementById('exportDropdownMenu');
        if (menu) {
            menu.classList.remove('show');
        }
    }
});

// ========== EXPORT FUNCTIONS ==========
function getFilterParams() {
    let params = new URLSearchParams(window.location.search);
    let result = '';
    for (let [key, value] of params) {
        if (key !== 'export' && key !== 'paper_size' && key !== 'orientation') {
            result += '&' + key + '=' + encodeURIComponent(value);
        }
    }
    return result;
}

function exportExcel() {
    let url = '?export=excel' + getFilterParams();
    window.location.href = url;
}

function exportCSV() {
    let url = '?export=csv' + getFilterParams();
    window.location.href = url;
}

function exportJSON() {
    let url = '?export=json' + getFilterParams();
    window.location.href = url;
}

function exportXML() {
    let url = '?export=xml' + getFilterParams();
    window.location.href = url;
}

function exportHTML() {
    let url = '?export=html' + getFilterParams();
    window.location.href = url;
}

function exportPDF(paperSize, orientation) {
    let url = '?export=pdf&paper_size=' + paperSize + '&orientation=' + orientation + getFilterParams();
    window.location.href = url;
}

// ========== AUTO HIDE FILTER ==========
document.addEventListener('DOMContentLoaded', function() {
    let hasFilters = false;
    let params = new URLSearchParams(window.location.search);
    for (let [key, value] of params) {
        if (value && key !== 'export' && key !== 'paper_size' && key !== 'orientation') {
            hasFilters = true;
            break;
        }
    }
    if (!hasFilters) {
        let filterCollapse = document.getElementById('filterCollapse');
        if (filterCollapse) {
            filterCollapse.classList.remove('show');
        }
    }
});

// ========== KEYBOARD SHORTCUT ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        var menu = document.getElementById('exportDropdownMenu');
        if (menu) {
            menu.classList.remove('show');
        }
    }
});

// ========== CONFIRM RETURN ==========
document.querySelectorAll('form[action="return.php"]').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm('Process return with fine? This will charge the member. Continue?')) {
            e.preventDefault();
        }
    });
});
</script>

<?php renderFooter(); ?>