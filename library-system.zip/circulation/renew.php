<?php
/**
 * Renew Book - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - Member photo display
 * - Book cover display
 * - Renewal count and max limits
 * - Fine calculation with admin waive option
 * - Responsive layout with proper alignment
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$toast = '';
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

// Report settings for unified styling
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';
$currencyDecimalPlaces = (int)($settings['currency_decimal_places'] ?? 2);

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Handle AJAX info display
if (isset($_GET['ajax_book'])) {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode']);
    $stmt = $db->prepare("SELECT c.*, m.name as member_name, m.admno, m.active_books, m.total_fines, 
                                 m.photo_path, m.member_category,
                                 b.title, b.author, b.item_category, b.cover_path
                          FROM circulation c 
                          LEFT JOIN members m ON c.admno = m.admno
                          LEFT JOIN books b ON c.barcode = b.barcode
                          WHERE c.barcode = ? AND c.return_date IS NULL");
    $stmt->execute([$barcode]);
    $record = $stmt->fetch();
    if ($record) {
        // Get loan rule
        $memberCat = $record['member_category'] ?? 'Student';
        $itemCat = $record['item_category'] ?? 'General';
        $rule = getLoanRule($memberCat, $itemCat);
        if ($rule) {
            $finePerDay = $rule['fine_per_day'];
            $maxRenewals = $rule['renewals_allowed'];
            $loanPeriod = $rule['loan_period'];
            $gracePeriod = $rule['grace_period'];
        } else {
            $finePerDay = (float)($settings['fine_per_day'] ?? 2);
            $maxRenewals = (int)($settings['max_renewals'] ?? 1);
            $loanPeriod = (int)($settings['loan_days'] ?? 14);
            $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
        }
        
        $dueDateObj = new DateTime($record['due_date']);
        $todayObj = new DateTime();
        $daysOverdue = 0;
        $fine = 0;
        if ($todayObj > $dueDateObj) {
            $daysOverdue = $todayObj->diff($dueDateObj)->days;
            $chargeableDays = max(0, $daysOverdue - $gracePeriod);
            $fine = $chargeableDays * $finePerDay;
            $maxFine = (float)($settings['max_fine_amount'] ?? 0);
            if ($maxFine > 0 && $fine > $maxFine) $fine = $maxFine;
        }
        
        $record['days_overdue'] = $daysOverdue;
        $record['fine_amount'] = $fine;
        $record['new_due_date'] = date('Y-m-d', strtotime($record['due_date'] . " +$loanPeriod days"));
        $record['max_renewals'] = $maxRenewals;
        $record['renew_count'] = $record['renew_count'] ?? 0;
        $record['can_renew'] = ($record['renew_count'] < $maxRenewals);
        
        // Get images
        $record['photo_base64'] = getImageBase64($record['photo_path'] ?? '');
        $record['cover_base64'] = getImageBase64($record['cover_path'] ?? '');
    }
    echo json_encode($record ?? null);
    exit;
}

// Handle renewal submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['renew'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            $barcode = trim($_POST['barcode']);
            $chargeFine = isset($_POST['charge_fine']) ? 1 : 0;
            $waiveFine = isset($_POST['waive_fine']) && $isAdmin ? 1 : 0;
            
            $stmt = $db->prepare("SELECT c.*, m.member_category, m.total_fines as current_fines, 
                                         b.item_category, b.title, b.cover_path
                                  FROM circulation c 
                                  LEFT JOIN members m ON c.admno = m.admno 
                                  LEFT JOIN books b ON c.barcode = b.barcode
                                  WHERE c.barcode = ? AND c.return_date IS NULL");
            $stmt->execute([$barcode]);
            $record = $stmt->fetch();
            if (!$record) throw new Exception("No active issue found for this barcode");
            
            // Get loan rule
            $rule = getLoanRule($record['member_category'], $record['item_category']);
            if ($rule) {
                $maxRenewals = $rule['renewals_allowed'];
                $loanPeriod = $rule['loan_period'];
                $finePerDay = $rule['fine_per_day'];
                $gracePeriod = $rule['grace_period'];
            } else {
                $maxRenewals = (int)($settings['max_renewals'] ?? 1);
                $loanPeriod = (int)($settings['loan_days'] ?? 14);
                $finePerDay = (float)($settings['fine_per_day'] ?? 2);
                $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
            }
            
            $currentRenewals = (int)($record['renew_count'] ?? 0);
            if ($currentRenewals >= $maxRenewals) {
                throw new Exception("Maximum renewals ({$maxRenewals}) already reached for this item.");
            }
            
            // Calculate fine
            $dueDateObj = new DateTime($record['due_date']);
            $todayObj = new DateTime();
            $fine = 0;
            if ($todayObj > $dueDateObj) {
                $daysOverdue = $todayObj->diff($dueDateObj)->days;
                $chargeableDays = max(0, $daysOverdue - $gracePeriod);
                $fine = $chargeableDays * $finePerDay;
                $maxFine = (float)($settings['max_fine_amount'] ?? 0);
                if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                    $fine = max(0, $maxFine - $record['current_fines']);
                }
            }
            if ($waiveFine) $fine = 0;
            
            $newDueDate = date('Y-m-d', strtotime($record['due_date'] . " +$loanPeriod days"));
            
            // Update
            $db->prepare("UPDATE circulation SET renew_count = renew_count + 1, due_date = ? WHERE id = ?")->execute([$newDueDate, $record['id']]);
            
            if ($chargeFine && $fine > 0) {
                $db->prepare("UPDATE circulation SET fine = fine + ? WHERE id = ?")->execute([$fine, $record['id']]);
                $db->prepare("UPDATE members SET total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
            }
            
            $db->commit();
            
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book renewed successfully! New due date: ' . date('d-m-Y', strtotime($newDueDate));
            if ($chargeFine && $fine > 0) $toast .= "<br>💰 Fine added: " . formatCurrency($fine);
            if ($waiveFine) $toast .= "<br>💸 Fine waived by admin.";
            $toast .= '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            logActivity($_SESSION['username'], 'BOOK_RENEW', "Renewed {$record['title']} - New due: $newDueDate" . ($fine > 0 ? " - Fine: $fine" : ""));
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Renew Book');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Renew Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-info {
        background: linear-gradient(135deg, #17a2b8, #0dcaf0) !important;
    }
    .card-custom .card-header.bg-success {
        background: linear-gradient(135deg, #28a745, #20c997) !important;
    }
    .card-custom .card-body {
        padding: 1.5rem;
    }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }

    /* ========== INPUT ========== */
    #barcode {
        font-size: 1.25rem;
        padding: 12px 20px;
        border-radius: 12px;
        border: 2px solid #e9ecef;
        transition: var(--transition);
        text-align: center;
        letter-spacing: 1px;
        font-weight: 500;
        background: #f8f9fa;
    }
    #barcode:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        background: #fff;
    }

    /* ========== RENEW INFO CARD ========== */
    .renew-info-card {
        background: #f8f9fa;
        border-radius: var(--border-radius);
        padding: 18px;
        margin-top: 12px;
        border: 2px solid var(--info);
        transition: var(--transition);
        animation: slideIn 0.3s ease;
    }
    @keyframes slideIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .renew-info-card .member-photo {
        width: 70px;
        height: 70px;
        object-fit: cover;
        border-radius: 50%;
        border: 3px solid var(--info);
        background: #fff;
        flex-shrink: 0;
        transition: var(--transition);
    }
    .renew-info-card .member-photo:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .renew-info-card .member-photo-placeholder {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e9ecef, #dee2e6);
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid var(--info);
        flex-shrink: 0;
        color: #6c757d;
        font-size: 2rem;
    }
    .renew-info-card .book-cover-small {
        max-width: 45px;
        max-height: 60px;
        object-fit: contain;
        border-radius: 6px;
        border: 1px solid #dee2e6;
        background: #fff;
        padding: 2px;
        transition: var(--transition);
    }
    .renew-info-card .book-cover-small:hover {
        transform: scale(1.15);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .renew-info-card .renew-body {
        display: flex;
        align-items: center;
        gap: 15px;
        flex-wrap: wrap;
    }
    .renew-info-card .renew-details {
        flex: 1;
        min-width: 200px;
    }
    .renew-info-card .renew-details p {
        margin-bottom: 4px;
        font-size: 0.9rem;
    }

    /* ========== BADGES ========== */
    .renew-badge {
        display: inline-block;
        padding: 3px 12px;
        border-radius: 30px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .renew-badge-success { background: #d4edda; color: #155724; }
    .renew-badge-danger { background: #f8d7da; color: #721c24; }
    .renew-badge-warning { background: #fff3cd; color: #856404; }
    .renew-badge-info { background: #cfe2ff; color: #084298; }

    /* ========== CHECKBOXES ========== */
    .charge-checkbox {
        padding: 12px 16px;
        background: #f8f9fa;
        border-radius: 10px;
        border: 1px solid #e9ecef;
        text-align: left;
        transition: var(--transition);
    }
    .charge-checkbox:hover {
        background: #e9ecef;
    }
    .charge-checkbox .form-check-input {
        width: 18px;
        height: 18px;
        margin-top: 0.1rem;
        cursor: pointer;
        border-radius: 4px;
    }
    .charge-checkbox .form-check-input:checked {
        background-color: var(--info);
        border-color: var(--info);
    }
    .charge-checkbox .form-check-label {
        font-weight: 500;
        cursor: pointer;
    }

    .waive-checkbox {
        padding: 12px 16px;
        background: #fff3cd;
        border-radius: 10px;
        border: 1px solid #ffc107;
        text-align: left;
        transition: var(--transition);
    }
    .waive-checkbox:hover {
        background: #ffeaa7;
    }
    .waive-checkbox .form-check-input {
        width: 18px;
        height: 18px;
        margin-top: 0.1rem;
        cursor: pointer;
        border-radius: 4px;
    }
    .waive-checkbox .form-check-input:checked {
        background-color: var(--success);
        border-color: var(--success);
    }
    .waive-checkbox .form-check-label {
        font-weight: 500;
        cursor: pointer;
    }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .container { padding: 0 12px; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .card-custom .card-body { padding: 1rem; }
        .renew-info-card .renew-body {
            flex-direction: column;
            text-align: center;
        }
        .renew-info-card .member-photo {
            width: 55px;
            height: 55px;
        }
        .renew-info-card .member-photo-placeholder {
            width: 55px;
            height: 55px;
            font-size: 1.6rem;
        }
        .renew-info-card .book-cover-small {
            max-width: 35px;
            max-height: 48px;
        }
        #barcode {
            font-size: 1rem;
            padding: 10px 16px;
        }
        .charge-checkbox, .waive-checkbox {
            padding: 10px 12px;
            font-size: 0.9rem;
        }
    }

    @media (max-width: 576px) {
        .renew-info-card { padding: 12px; }
        .renew-info-card .renew-details p { font-size: 0.8rem; }
        .charge-checkbox .form-check-label, 
        .waive-checkbox .form-check-label { font-size: 0.85rem; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .alert { display: none !important; }
    }
    </style>
</head>
<body>

<div class="container py-3">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-sync-alt me-2" style="color: var(--primary-color);"></i> Renew Book
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="issue.php" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
            <a href="return.php" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
            <a href="holds.php" class="btn btn-purple btn-sm" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6); color: #fff; border: none;"><i class="fas fa-hand-paper"></i> Holds</a>
        </div>
    </div>

    <!-- ========== MAIN CARD ========== -->
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card-custom">
                <div class="card-header bg-info">
                    <h5 class="mb-0"><i class="fas fa-sync-alt me-2"></i> Renew Book</h5>
                    <span class="badge bg-light text-dark ms-auto">Extend loan period</span>
                </div>
                <div class="card-body">
                    <?= $toast ?>
                    
                    <form method="post" id="renewForm">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        
                        <div class="text-center mb-3">
                            <div class="display-4 text-muted">
                                <i class="fas fa-barcode"></i>
                            </div>
                            <label class="form-label fw-bold fs-5 mb-2">Scan Book Barcode</label>
                            <input type="text" name="barcode" id="barcode" class="form-control form-control-lg" 
                                   placeholder="Scan or enter barcode" required autofocus autocomplete="off">
                            <div id="bookInfo" class="mt-3"></div>
                        </div>

                        <!-- ========== FINE OPTIONS ========== -->
                        <div class="charge-checkbox mb-2">
                            <div class="form-check">
                                <input type="checkbox" name="charge_fine" value="1" id="chargeFine" class="form-check-input">
                                <label class="form-check-label" for="chargeFine">
                                    <i class="fas fa-coins text-warning me-2"></i>
                                    <strong>Charge overdue fine</strong> for this renewal
                                    <small class="text-muted d-block mt-1">If checked, any overdue fine will be charged to the member's account.</small>
                                </label>
                            </div>
                        </div>
                        
                        <?php if ($isAdmin): ?>
                        <div class="waive-checkbox mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="waive_fine" value="1" id="waiveFine" class="form-check-input">
                                <label class="form-check-label" for="waiveFine">
                                    <i class="fas fa-hand-holding-usd text-success me-2"></i>
                                    <strong>Waive overdue fine</strong>
                                    <span class="badge bg-primary ms-1">Admin</span>
                                    <small class="text-muted d-block mt-1">Check this box to waive all overdue fines for this renewal.</small>
                                </label>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- ========== SUBMIT BUTTONS ========== -->
                        <div class="text-center mt-4">
                            <button type="submit" name="renew" class="btn btn-gradient-primary btn-lg px-5" id="confirmRenewBtn">
                                <i class="fas fa-check-circle me-2"></i> Renew Book
                            </button>
                            <a href="index.php" class="btn btn-secondary btn-lg px-5 ms-2">
                                <i class="fas fa-times-circle"></i> Cancel
                            </a>
                        </div>
                    </form>

                    <!-- ========== QUICK STATS ========== -->
                    <hr class="my-4">
                    <div class="row g-2 text-center">
                        <div class="col-4">
                            <div class="p-2 bg-soft-info rounded shadow-hover" style="background: #cfe2ff; border-radius: 10px;">
                                <i class="fas fa-sync-alt text-info"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn()) ?></div>
                                <small class="text-muted">Active Loans</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-success rounded shadow-hover" style="background: #d4edda; border-radius: 10px;">
                                <i class="fas fa-check-circle text-success"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND renew_count > 0")->fetchColumn()) ?></div>
                                <small class="text-muted">Renewed</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="p-2 bg-soft-warning rounded shadow-hover" style="background: #fff3cd; border-radius: 10px;">
                                <i class="fas fa-clock text-warning"></i>
                                <div class="fw-bold"><?= number_format($db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date < date('now')")->fetchColumn()) ?></div>
                                <small class="text-muted">Overdue</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== RENEW LOGIC ==========
function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>"]/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' })[m] || m);
}

let barcodeInput = document.getElementById('barcode');
let lookupTimeout = null;
const currencySymbol = '<?= addslashes($currencySymbol) ?>';
const currencyDecimalPlaces = <?= (int)$currencyDecimalPlaces ?>;

function lookupBook() {
    let barcode = barcodeInput.value.trim();
    if (barcode.length >= 3) {
        let infoDiv = document.getElementById('bookInfo');
        infoDiv.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-info" role="status"></div><p class="mt-2 text-muted">Loading renewal details...</p></div>';
        
        fetch('renew.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
            .then(r => r.json())
            .then(data => {
                if (data && data.title) {
                    let fine = data.fine_amount || 0;
                    let days = data.days_overdue || 0;
                    let newDue = data.new_due_date;
                    let canRenew = data.can_renew;
                    let renewCount = data.renew_count || 0;
                    let maxRenewals = data.max_renewals || 0;
                    
                    // Member photo
                    let memberPhotoHtml = '';
                    if (data.photo_base64) {
                        memberPhotoHtml = `<img src="${data.photo_base64}" class="member-photo" alt="Member Photo" loading="lazy">`;
                    } else {
                        memberPhotoHtml = `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                    }
                    
                    // Book cover
                    let bookCoverHtml = '';
                    if (data.cover_base64) {
                        bookCoverHtml = `<img src="${data.cover_base64}" class="book-cover-small" alt="Book Cover" loading="lazy">`;
                    }
                    
                    let daysText = days > 0 ? 
                        `<span class="renew-badge renew-badge-danger"><i class="fas fa-clock"></i> Overdue by ${days} day(s)</span>` : 
                        `<span class="renew-badge renew-badge-success"><i class="fas fa-check-circle"></i> On time</span>`;
                    
                    let fineText = fine > 0 ? 
                        `<span class="renew-badge renew-badge-warning"><i class="fas fa-coins"></i> Fine: ${currencySymbol} ${fine.toFixed(currencyDecimalPlaces)}</span>` : 
                        `<span class="renew-badge renew-badge-success"><i class="fas fa-check-circle"></i> No fine</span>`;
                    
                    let renewStatus = canRenew ? 
                        `<span class="renew-badge renew-badge-success"><i class="fas fa-check-circle"></i> Can renew (${renewCount}/${maxRenewals})</span>` : 
                        `<span class="renew-badge renew-badge-danger"><i class="fas fa-times-circle"></i> Cannot renew - maximum reached</span>`;
                    
                    infoDiv.innerHTML = `
                        <div class="renew-info-card">
                            <div class="renew-body">
                                ${memberPhotoHtml}
                                <div class="renew-details">
                                    <p><strong>📖 Book:</strong> ${bookCoverHtml} ${escapeHtml(data.title)}</p>
                                    <p><strong>👤 Member:</strong> ${escapeHtml(data.member_name)} (${escapeHtml(data.admno)})</p>
                                    <p><strong>📅 Current Due:</strong> ${data.due_date}</p>
                                    <p><strong>🔄 Renewals:</strong> ${renewCount} / ${maxRenewals}</p>
                                    <p>${daysText} | ${fineText}</p>
                                    <p><strong>📆 New Due Date:</strong> <span class="fw-bold text-info">${newDue}</span></p>
                                    <p>${renewStatus}</p>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('confirmRenewBtn').disabled = !canRenew;
                    if (!canRenew) {
                        document.getElementById('confirmRenewBtn').title = 'Maximum renewals reached';
                    }
                } else {
                    infoDiv.innerHTML = '<div class="alert alert-danger text-center py-3"><i class="fas fa-exclamation-triangle"></i> No active issue found for this barcode.</div>';
                    document.getElementById('confirmRenewBtn').disabled = true;
                }
            })
            .catch(() => {
                document.getElementById('bookInfo').innerHTML = '<div class="alert alert-danger text-center py-3"><i class="fas fa-wifi"></i> Error fetching renewal details.</div>';
            });
    } else {
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmRenewBtn').disabled = false;
    }
}

// ========== EVENT LISTENERS ==========
barcodeInput.addEventListener('input', function() {
    if (lookupTimeout) clearTimeout(lookupTimeout);
    lookupTimeout = setTimeout(lookupBook, 500);
});

barcodeInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        lookupBook();
    }
});

barcodeInput.addEventListener('blur', function() {
    if (this.value.trim().length >= 3) lookupBook();
});

window.addEventListener('load', function() {
    barcodeInput.focus();
});

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
    if (e.key === 'Enter' && document.activeElement === barcodeInput) {
        e.preventDefault();
        lookupBook();
    }
});

// ========== MODAL SCROLLING FIX ==========
document.addEventListener('DOMContentLoaded', function() {
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        modal.addEventListener('shown.bs.modal', function() {
            document.body.style.overflow = 'hidden';
        });
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.style.overflow = '';
        });
    });
});
</script>

<?php renderFooter(); ?>