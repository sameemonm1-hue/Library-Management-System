<?php
/**
 * Renew Book - Complete Update
 * Features:
 * - Member photo display
 * - Book cover display
 * - Renewal count and max limits
 * - Fine calculation
 * - Admin waive option
 * - Responsive layout
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$settings = getSettings();
$toast = '';
$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// Handle AJAX info display
if (isset($_GET['ajax_book'])) {
    header('Content-Type: application/json');
    $barcode = trim($_GET['barcode']);
    $stmt = $db->prepare("SELECT c.*, m.name as member_name, m.admno, m.active_books, m.total_fines, 
                                 m.photo_path, m.member_category,
                                 b.title, b.author, b.item_category, b.cover_path
                          FROM circulation c 
                          LEFT JOIN members m ON c.admno = m.admno
                          LEFT JOIN books b ON c.barcode = b.barcode
                          WHERE c.barcode = ? AND c.return_date IS NULL");
    $stmt->execute([$barcode]);
    $record = $stmt->fetch();
    if ($record) {
        // Get loan rule
        $memberCat = $record['member_category'] ?? 'Student';
        $itemCat = $record['item_category'] ?? 'General';
        $rule = getLoanRule($memberCat, $itemCat);
        if ($rule) {
            $finePerDay = $rule['fine_per_day'];
            $maxRenewals = $rule['renewals_allowed'];
            $loanPeriod = $rule['loan_period'];
            $gracePeriod = $rule['grace_period'];
        } else {
            $finePerDay = (float)($settings['fine_per_day'] ?? 2);
            $maxRenewals = (int)($settings['max_renewals'] ?? 1);
            $loanPeriod = (int)($settings['loan_days'] ?? 14);
            $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
        }
        
        $dueDateObj = new DateTime($record['due_date']);
        $todayObj = new DateTime();
        $daysOverdue = 0;
        $fine = 0;
        if ($todayObj > $dueDateObj) {
            $daysOverdue = $todayObj->diff($dueDateObj)->days;
            $chargeableDays = max(0, $daysOverdue - $gracePeriod);
            $fine = $chargeableDays * $finePerDay;
            $maxFine = (float)($settings['max_fine_amount'] ?? 0);
            if ($maxFine > 0 && $fine > $maxFine) $fine = $maxFine;
        }
        
        $record['days_overdue'] = $daysOverdue;
        $record['fine_amount'] = $fine;
        $record['new_due_date'] = date('Y-m-d', strtotime($record['due_date'] . " +$loanPeriod days"));
        $record['max_renewals'] = $maxRenewals;
        $record['renew_count'] = $record['renew_count'] ?? 0;
        $record['can_renew'] = ($record['renew_count'] < $maxRenewals);
        
        // Get images
        $record['photo_base64'] = getImageBase64($record['photo_path'] ?? '');
        $record['cover_base64'] = getImageBase64($record['cover_path'] ?? '');
    }
    echo json_encode($record ?? null);
    exit;
}

// Handle renewal submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['renew'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $toast = '<div class="alert alert-danger">❌ Invalid security token. Please refresh and try again.</div>';
    } else {
        try {
            $db->beginTransaction();
            $barcode = trim($_POST['barcode']);
            $chargeFine = isset($_POST['charge_fine']) ? 1 : 0;
            $waiveFine = isset($_POST['waive_fine']) && $isAdmin ? 1 : 0;
            
            $stmt = $db->prepare("SELECT c.*, m.member_category, m.total_fines as current_fines, 
                                         b.item_category, b.title, b.cover_path
                                  FROM circulation c 
                                  LEFT JOIN members m ON c.admno = m.admno 
                                  LEFT JOIN books b ON c.barcode = b.barcode
                                  WHERE c.barcode = ? AND c.return_date IS NULL");
            $stmt->execute([$barcode]);
            $record = $stmt->fetch();
            if (!$record) throw new Exception("No active issue found for this barcode");
            
            // Get loan rule
            $rule = getLoanRule($record['member_category'], $record['item_category']);
            if ($rule) {
                $maxRenewals = $rule['renewals_allowed'];
                $loanPeriod = $rule['loan_period'];
                $finePerDay = $rule['fine_per_day'];
                $gracePeriod = $rule['grace_period'];
            } else {
                $maxRenewals = (int)($settings['max_renewals'] ?? 1);
                $loanPeriod = (int)($settings['loan_days'] ?? 14);
                $finePerDay = (float)($settings['fine_per_day'] ?? 2);
                $gracePeriod = (int)($settings['fine_grace_period'] ?? 0);
            }
            
            $currentRenewals = (int)($record['renew_count'] ?? 0);
            if ($currentRenewals >= $maxRenewals) {
                throw new Exception("Maximum renewals ({$maxRenewals}) already reached for this item.");
            }
            
            // Calculate fine
            $dueDateObj = new DateTime($record['due_date']);
            $todayObj = new DateTime();
            $fine = 0;
            if ($todayObj > $dueDateObj) {
                $daysOverdue = $todayObj->diff($dueDateObj)->days;
                $chargeableDays = max(0, $daysOverdue - $gracePeriod);
                $fine = $chargeableDays * $finePerDay;
                $maxFine = (float)($settings['max_fine_amount'] ?? 0);
                if ($maxFine > 0 && ($record['current_fines'] + $fine) > $maxFine) {
                    $fine = max(0, $maxFine - $record['current_fines']);
                }
            }
            if ($waiveFine) $fine = 0;
            
            $newDueDate = date('Y-m-d', strtotime($record['due_date'] . " +$loanPeriod days"));
            
            // Update
            $db->prepare("UPDATE circulation SET renew_count = renew_count + 1, due_date = ? WHERE id = ?")->execute([$newDueDate, $record['id']]);
            
            if ($chargeFine && $fine > 0) {
                $db->prepare("UPDATE circulation SET fine = fine + ? WHERE id = ?")->execute([$fine, $record['id']]);
                $db->prepare("UPDATE members SET total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
            }
            
            $db->commit();
            
            $toast = '<div class="alert alert-success alert-dismissible fade show">✅ Book renewed successfully! New due date: ' . date('d-m-Y', strtotime($newDueDate));
            if ($chargeFine && $fine > 0) $toast .= "<br>💰 Fine added: " . formatCurrency($fine);
            if ($waiveFine) $toast .= "<br>💸 Fine waived by admin.";
            $toast .= '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
            logActivity($_SESSION['username'], 'BOOK_RENEW', "Renewed {$record['title']} - New due: $newDueDate" . ($fine > 0 ? " - Fine: $fine" : ""));
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            $toast = '<div class="alert alert-danger alert-dismissible fade show">❌ ' . $e->getMessage() . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        }
    }
}

renderHeader('Renew Book');
?>

<style>
/* ========== RENEW INFO CARD ========== */
.renew-info-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 16px;
    margin-top: 10px;
    border-left: 4px solid #0dcaf0;
}
.renew-info-card .member-photo {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #0dcaf0;
    background: #fff;
    flex-shrink: 0;
}
.renew-info-card .member-photo-placeholder {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid #0dcaf0;
    flex-shrink: 0;
    color: #6c757d;
    font-size: 1.8rem;
}
.renew-info-card .book-cover-small {
    max-width: 40px;
    max-height: 55px;
    object-fit: contain;
    border-radius: 4px;
    border: 1px solid #dee2e6;
    background: #fff;
    padding: 2px;
}
.renew-info-card .renew-body {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}
.renew-info-card .renew-details {
    flex: 1;
    min-width: 200px;
}
.renew-info-card .renew-details p {
    margin-bottom: 3px;
    font-size: 0.85rem;
}
.renew-badge {
    display: inline-block;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}
.renew-badge-success { background: #d4edda; color: #155724; }
.renew-badge-danger { background: #f8d7da; color: #721c24; }
.renew-badge-warning { background: #fff3cd; color: #856404; }
.renew-badge-info { background: #cfe2ff; color: #084298; }

.waive-checkbox {
    margin-top: 10px;
    text-align: left;
}

@media (max-width: 576px) {
    .renew-info-card .renew-body {
        flex-direction: column;
        text-align: center;
    }
    .renew-info-card .member-photo {
        width: 50px;
        height: 50px;
    }
    .renew-info-card .member-photo-placeholder {
        width: 50px;
        height: 50px;
        font-size: 1.4rem;
    }
}
</style>

<div class="container">
    <div class="row justify-content-center mt-4">
        <div class="col-md-8">
            <div class="d-flex justify-content-between mb-3 flex-wrap gap-2">
                <div class="d-flex flex-wrap gap-2">
                    <a href="../index.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-home"></i> Home</a>
                    <a href="issue.php" class="btn btn-outline-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
                    <a href="return.php" class="btn btn-outline-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
                </div>
                <div><span class="badge bg-info fs-6">Renew Book</span></div>
            </div>
            
            <div class="card shadow rounded-4">
                <div class="card-header bg-info text-white rounded-top-4">
                    <h4><i class="fas fa-sync-alt"></i> Renew Book</h4>
                </div>
                <div class="card-body text-center">
                    <?= $toast ?>
                    
                    <form method="post" id="renewForm">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <div class="mb-4">
                            <label class="form-label h5">Scan Book Barcode</label>
                            <input type="text" name="barcode" id="barcode" class="form-control form-control-lg text-center" 
                                   placeholder="Scan or enter barcode" required autofocus autocomplete="off">
                            <div id="bookInfo" class="mt-3"></div>
                        </div>
                        
                        <div class="form-check mb-2 text-start">
                            <input type="checkbox" name="charge_fine" value="1" id="chargeFine" class="form-check-input">
                            <label class="form-check-label" for="chargeFine">
                                <strong>Charge overdue fine (if any) for this renewal</strong>
                            </label>
                        </div>
                        
                        <?php if ($isAdmin): ?>
                        <div class="form-check mb-3 text-start waive-checkbox">
                            <input type="checkbox" name="waive_fine" value="1" id="waiveFine" class="form-check-input">
                            <label class="form-check-label" for="waiveFine">
                                <strong>Waive overdue fine</strong> (Admin only)
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div class="mt-4">
                            <button type="submit" name="renew" class="btn btn-info btn-lg px-5" id="confirmRenewBtn">Renew Book</button>
                            <a href="index.php" class="btn btn-secondary btn-lg px-5">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function escapeHtml(s) {
    if (!s) return '';
    return s.replace(/[&<>]/g, function(m) {
        return m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;');
    });
}

let barcodeInput = document.getElementById('barcode');
let lookupTimeout = null;
const currencySymbol = '<?= addslashes($settings['currency_symbol'] ?? '$') ?>';
const currencyDecimalPlaces = <?= (int)($settings['currency_decimal_places'] ?? 2) ?>;

function lookupBook() {
    let barcode = barcodeInput.value.trim();
    if (barcode.length >= 3) {
        fetch('renew.php?ajax_book=1&barcode=' + encodeURIComponent(barcode))
            .then(r => r.json())
            .then(data => {
                let infoDiv = document.getElementById('bookInfo');
                if (data && data.title) {
                    let fine = data.fine_amount || 0;
                    let days = data.days_overdue || 0;
                    let newDue = data.new_due_date;
                    let canRenew = data.can_renew;
                    
                    // Member photo
                    let memberPhotoHtml = '';
                    if (data.photo_base64) {
                        memberPhotoHtml = `<img src="${data.photo_base64}" class="member-photo" alt="Member Photo">`;
                    } else {
                        memberPhotoHtml = `<div class="member-photo-placeholder"><i class="fas fa-user"></i></div>`;
                    }
                    
                    // Book cover
                    let bookCoverHtml = '';
                    if (data.cover_base64) {
                        bookCoverHtml = `<img src="${data.cover_base64}" class="book-cover-small" alt="Book Cover">`;
                    }
                    
                    let daysText = days > 0 ? 
                        `<span class="renew-badge renew-badge-danger">⚠ Overdue by ${days} day(s)</span>` : 
                        `<span class="renew-badge renew-badge-success">✅ On time</span>`;
                    
                    let fineText = fine > 0 ? 
                        `<span class="renew-badge renew-badge-warning">💰 Fine: ${currencySymbol} ${fine.toFixed(currencyDecimalPlaces)}</span>` : 
                        `<span class="renew-badge renew-badge-success">No fine</span>`;
                    
                    let renewStatus = canRenew ? 
                        `<span class="renew-badge renew-badge-success">✅ Can renew (${data.renew_count}/${data.max_renewals})</span>` : 
                        `<span class="renew-badge renew-badge-danger">❌ Cannot renew - maximum reached</span>`;
                    
                    infoDiv.innerHTML = `
                        <div class="renew-info-card">
                            <div class="renew-body">
                                ${memberPhotoHtml}
                                <div class="renew-details">
                                    <p><strong>📖 Book:</strong> ${bookCoverHtml} ${escapeHtml(data.title)}</p>
                                    <p><strong>👤 Member:</strong> ${escapeHtml(data.member_name)} (${escapeHtml(data.admno)})</p>
                                    <p><strong>📅 Current Due:</strong> ${data.due_date}</p>
                                    <p><strong>🔄 Renewals:</strong> ${data.renew_count} / ${data.max_renewals}</p>
                                    <p>${daysText} | ${fineText}</p>
                                    <p><strong>📆 New Due Date:</strong> ${newDue}</p>
                                    <p>${renewStatus}</p>
                                </div>
                            </div>
                        </div>
                    `;
                    
                    document.getElementById('confirmRenewBtn').disabled = !canRenew;
                } else {
                    infoDiv.innerHTML = '<div class="alert alert-danger text-center"><i class="fas fa-exclamation-triangle"></i> No active issue found for this barcode.</div>';
                    document.getElementById('confirmRenewBtn').disabled = true;
                }
            })
            .catch(() => {
                document.getElementById('bookInfo').innerHTML = '<div class="alert alert-danger text-center"><i class="fas fa-exclamation-triangle"></i> Error fetching renewal details</div>';
            });
    } else {
        document.getElementById('bookInfo').innerHTML = '';
        document.getElementById('confirmRenewBtn').disabled = false;
    }
}

barcodeInput.addEventListener('input', function() {
    if (lookupTimeout) clearTimeout(lookupTimeout);
    lookupTimeout = setTimeout(lookupBook, 500);
});
barcodeInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        lookupBook();
    }
});
barcodeInput.addEventListener('blur', lookupBook);

window.addEventListener('load', function() {
    barcodeInput.focus();
});

// ========== MODAL SCROLLING FIX ==========
document.addEventListener('DOMContentLoaded', function() {
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        modal.addEventListener('shown.bs.modal', function() {
            document.body.style.overflow = 'hidden';
        });
        modal.addEventListener('hidden.bs.modal', function() {
            document.body.style.overflow = '';
        });
    });
});
</script>

<?php renderFooter(); ?>