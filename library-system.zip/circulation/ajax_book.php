<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

$db = getDB();
$barcode = $_GET['barcode'] ?? '';

if($barcode) {
    // Check if book exists in system
    $stmt = $db->prepare("SELECT barcode, title, author, available, quantity, isbn, publisher FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $book = $stmt->fetch();
    
    if($book) {
        // Check if book is currently issued (for return functionality)
        $checkIssued = $db->prepare("SELECT c.*, m.name as member_name, m.admno 
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            WHERE c.barcode = ? AND c.return_date IS NULL");
        $checkIssued->execute([$barcode]);
        $issued = $checkIssued->fetch();
        
        if($issued) {
            $book['is_issued'] = true;
            $book['member_name'] = $issued['member_name'];
            $book['member_admno'] = $issued['admno'];
            $book['issue_date'] = $issued['issue_date'];
            $book['due_date'] = $issued['due_date'];
        } else {
            $book['is_issued'] = false;
        }
        
        header('Content-Type: application/json');
        echo json_encode($book);
        exit;
    }
}

// Book not found - return null
header('Content-Type: application/json');
echo json_encode(null);
?>