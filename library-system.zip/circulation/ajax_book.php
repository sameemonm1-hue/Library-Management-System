<?php
/**
 * AJAX Book Lookup - v3.5 (Unified with Circulation Dashboard)
 * - Returns book details with cover image
 * - Checks if book is currently issued
 * - Unified JSON response format
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

$db = getDB();
$barcode = trim($_GET['barcode'] ?? '');

if ($barcode) {
    // Check if book exists in system
    $stmt = $db->prepare("SELECT barcode, title, author, available, quantity, isbn, publisher, cover_path, item_category, book_status 
                          FROM books WHERE barcode = ?");
    $stmt->execute([$barcode]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($book) {
        // Add cover image
        $book['cover_base64'] = getImageBase64($book['cover_path'] ?? '');
        unset($book['cover_path']);
        
        // Check if book is currently issued
        $checkIssued = $db->prepare("SELECT c.*, m.name as member_name, m.admno, m.photo_path as member_photo_path 
            FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno 
            WHERE c.barcode = ? AND c.return_date IS NULL");
        $checkIssued->execute([$barcode]);
        $issued = $checkIssued->fetch(PDO::FETCH_ASSOC);
        
        if ($issued) {
            $book['is_issued'] = true;
            $book['member_name'] = $issued['member_name'];
            $book['member_admno'] = $issued['admno'];
            $book['issue_date'] = $issued['issue_date'];
            $book['due_date'] = $issued['due_date'];
            $book['member_photo_base64'] = getImageBase64($issued['member_photo_path'] ?? '');
        } else {
            $book['is_issued'] = false;
        }
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'data' => $book]);
        exit;
    }
}

// Book not found
header('Content-Type: application/json');
echo json_encode(['success' => false, 'error' => 'Book not found']);
?>