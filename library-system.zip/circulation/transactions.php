<?php
/**
 * Transaction History / Reports - v3.5 (Unified with Circulation Dashboard)
 * - Unified gradient color scheme
 * - Class & Division wise summary
 * - Excel and PDF export
 * - Advanced filtering
 * - Responsive design
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$currencySymbol = $settings['currency_symbol'] ?? '$';

// Get filter parameters
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$admno = $_GET['admno'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$status = $_GET['status'] ?? 'all';
$format = $_GET['format'] ?? '';
$export = $_GET['export'] ?? '';

// Get distinct classes and divisions for dropdowns
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

// Build query for transactions
$sql = "SELECT c.*, m.name as member_name, m.class as member_class, m.division as member_division 
        FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno 
        WHERE c.issue_date BETWEEN ? AND ?";
$params = [$from, $to];

if (!empty($admno)) {
    $sql .= " AND c.admno LIKE ?";
    $params[] = "%$admno%";
}
if (!empty($class)) {
    $sql .= " AND m.class = ?";
    $params[] = $class;
}
if (!empty($division)) {
    $sql .= " AND m.division = ?";
    $params[] = $division;
}

if ($status === 'issued') {
    $sql .= " AND c.return_date IS NULL";
} elseif ($status === 'returned') {
    $sql .= " AND c.return_date IS NOT NULL";
} elseif ($status === 'overdue') {
    $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')";
}

$sql .= " ORDER BY c.issue_date DESC LIMIT 500";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Calculate statistics
$totalIssued = count($transactions);
$totalReturned = count(array_filter($transactions, function($t) { return $t['return_date']; }));
$totalOverdue = count(array_filter($transactions, function($t) { 
    return !$t['return_date'] && strtotime($t['due_date']) < time(); 
}));
$totalFine = array_sum(array_column($transactions, 'fine'));

// Class-wise summary
$classSummary = [];
$classStmt = $db->prepare("
    SELECT 
        m.class,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        SUM(CASE WHEN c.return_date IS NULL AND c.due_date < date('now') THEN 1 ELSE 0 END) as overdue_count,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE c.issue_date BETWEEN ? AND ?
    GROUP BY m.class
    ORDER BY total_issued DESC
");
$classStmt->execute([$from, $to]);
$classSummary = $classStmt->fetchAll();

// Division-wise summary
$divisionSummary = [];
$divisionStmt = $db->prepare("
    SELECT 
        m.division,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        SUM(CASE WHEN c.return_date IS NULL AND c.due_date < date('now') THEN 1 ELSE 0 END) as overdue_count,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE c.issue_date BETWEEN ? AND ? AND m.division IS NOT NULL AND m.division != ''
    GROUP BY m.division
    ORDER BY total_issued DESC
");
$divisionStmt->execute([$from, $to]);
$divisionSummary = $divisionStmt->fetchAll();

// Handle Excel export
if ($export === 'excel' || $format === 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="circulation_transactions_' . date('Y-m-d') . '.xls"');
    exportExcel($transactions, $classSummary, $divisionSummary, $from, $to, $class, $division);
    exit;
}

if ($format === 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="circulation_transactions_' . date('Y-m-d') . '.pdf"');
    exportPDF($transactions, $classSummary, $divisionSummary, $from, $to, $class, $division, $settings);
    exit;
}

$flash = getFlashMessage();

renderHeader('Transaction History');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - <?= h($settings['software_header'] ?? 'Library System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
    :root {
        --primary-color: <?= $reportPrimaryColor ?>;
        --primary-light: <?= $reportPrimaryColor ?>dd;
        --primary-dark: <?= $reportPrimaryColor ?>aa;
        --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        --success: #28a745;
        --danger: #dc3545;
        --warning: #ffc107;
        --info: #17a2b8;
        --border-radius: 16px;
        --shadow-sm: 0 2px 8px rgba(0,0,0,0.06);
        --shadow-md: 0 4px 20px rgba(0,0,0,0.08);
        --shadow-lg: 0 8px 40px rgba(0,0,0,0.12);
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    body {
        font-family: 'Inter', sans-serif;
        background: #f4f6fa;
        padding-bottom: 40px;
    }

    /* ========== CARDS ========== */
    .card-custom {
        border: none;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        background: #fff;
        overflow: hidden;
    }
    .card-custom:hover {
        box-shadow: var(--shadow-md);
    }
    .card-custom .card-header {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: white;
        border-bottom: none;
        padding: 0.9rem 1.25rem;
        font-weight: 600;
        border-radius: var(--border-radius) var(--border-radius) 0 0;
    }
    .card-custom .card-header.bg-success {
        background: linear-gradient(135deg, #28a745, #20c997) !important;
    }
    .card-custom .card-header.bg-warning {
        background: linear-gradient(135deg, #f0ad4e, #ffc107) !important;
    }
    .card-custom .card-header.bg-danger {
        background: linear-gradient(135deg, #dc3545, #e74c3c) !important;
    }
    .card-custom .card-body {
        padding: 1.25rem;
    }

    /* ========== STAT CARDS ========== */
    .stat-card {
        border: none;
        border-radius: var(--border-radius);
        padding: 1.25rem 1.5rem;
        transition: var(--transition);
        box-shadow: var(--shadow-sm);
        position: relative;
        overflow: hidden;
        min-height: 90px;
        color: white;
    }
    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-lg);
    }
    .stat-card .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        line-height: 1.2;
        margin: 0;
        color: white;
    }
    .stat-card .stat-label {
        font-size: 0.85rem;
        opacity: 0.9;
        margin: 0;
    }
    .stat-card .stat-icon {
        font-size: 2rem;
        opacity: 0.25;
        color: white;
    }
    .stat-card.bg-primary { background: linear-gradient(135deg, var(--primary-color), var(--primary-light)); }
    .stat-card.bg-success { background: linear-gradient(135deg, #28a745, #20c997); }
    .stat-card.bg-warning { background: linear-gradient(135deg, #f0ad4e, #ffc107); color: #856404; }
    .stat-card.bg-warning .stat-value { color: #856404; }
    .stat-card.bg-danger { background: linear-gradient(135deg, #dc3545, #e74c3c); }

    /* ========== BUTTONS ========== */
    .btn-primary {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-primary:hover {
        background-color: var(--primary-dark);
        border-color: var(--primary-dark);
    }
    .btn-outline-primary {
        color: var(--primary-color);
        border-color: var(--primary-color);
    }
    .btn-outline-primary:hover {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    .btn-gradient-primary {
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
        color: #fff;
        border: none;
    }
    .btn-gradient-primary:hover {
        transform: scale(1.02);
        box-shadow: 0 4px 15px rgba(var(--primary-rgb), 0.4);
        color: #fff;
    }

    /* ========== FILTER FORM ========== */
    .filter-card .form-control, .filter-card .form-select {
        border-radius: 10px;
        border: 2px solid #e9ecef;
        transition: var(--transition);
        background: #f8f9fa;
    }
    .filter-card .form-control:focus, .filter-card .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.15);
        background: #fff;
    }

    /* ========== TABLE ========== */
    .table-transactions {
        font-size: 0.9rem;
    }
    .table-transactions th {
        font-weight: 600;
        color: #495057;
        border-bottom: 2px solid #e9ecef;
        white-space: nowrap;
        background: #f8f9fa;
        position: sticky;
        top: 0;
        z-index: 5;
    }
    .table-transactions td {
        vertical-align: middle;
        padding: 0.6rem 0.75rem;
    }
    .table-transactions tr:hover {
        background-color: #f8f9fa;
    }
    .table-transactions .text-overdue { color: var(--danger); font-weight: 600; }

    /* ========== STATUS BADGES ========== */
    .status-badge {
        padding: 4px 14px;
        border-radius: 30px;
        font-size: 0.7rem;
        font-weight: 600;
        letter-spacing: 0.3px;
        display: inline-block;
    }
    .status-issued { background: #cfe2ff; color: #084298; }
    .status-returned { background: #d4edda; color: #155724; }
    .status-overdue { background: #f8d7da; color: #721c24; animation: pulse-badge 2s infinite; }

    @keyframes pulse-badge {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    /* ========== SUMMARY TABLES ========== */
    .summary-table th { background: #e9ecef; font-weight: 600; }
    .summary-table .overdue-count { color: var(--danger); font-weight: 600; }

    /* ========== RESPONSIVE ========== */
    @media (max-width: 768px) {
        .container-fluid { padding: 0 12px; }
        .stat-card .stat-value { font-size: 1.4rem; }
        .stat-card { padding: 1rem; min-height: 70px; }
        .card-custom .card-header { padding: 0.6rem 1rem; font-size: 0.95rem; }
        .card-custom .card-body { padding: 1rem; }
        .table-transactions { font-size: 0.8rem; }
        .table-transactions td, .table-transactions th { padding: 0.4rem 0.5rem; }
    }

    @media (max-width: 576px) {
        .table-transactions { font-size: 0.7rem; }
        .table-transactions td, .table-transactions th { padding: 0.3rem 0.35rem; }
        .stat-card .stat-value { font-size: 1.1rem; }
        .btn { font-size: 0.8rem; padding: 0.3rem 0.7rem; }
        .status-badge { font-size: 0.6rem; padding: 2px 8px; }
    }

    /* ========== PRINT ========== */
    @media print {
        .no-print { display: none !important; }
        .card-custom { border: 1px solid #ddd !important; box-shadow: none !important; }
        .card-custom .card-header { background: #f8f9fa !important; color: #333 !important; }
        .btn { display: none !important; }
        .table-transactions th { background: #333 !important; color: white !important; }
        .stat-card { background: #f8f9fa !important; color: #333 !important; border: 1px solid #ddd !important; }
        .stat-card .stat-value { color: #333 !important; }
        .stat-card .stat-icon { display: none !important; }
    }
    </style>
</head>
<body>

<div class="container-fluid px-3 px-md-4">
    <!-- ========== HEADER ========== -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4 gap-2">
        <div>
            <h2 class="fw-bold mb-1" style="color: var(--primary-color);">
                <i class="fas fa-history me-2" style="color: var(--primary-color);"></i> Transaction History
            </h2>
            <p class="text-muted small mb-0">
                <i class="fas fa-calendar-alt me-1"></i> <?= date('l, F j, Y') ?> &bull; 
                <span id="currentTime"></span>
                <span class="ms-2">Records: <?= count($transactions) ?></span>
            </p>
        </div>
        <div class="btn-group-custom no-print" role="group">
            <a href="index.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="issue.php" class="btn btn-success btn-sm"><i class="fas fa-arrow-right"></i> Issue</a>
            <a href="return.php" class="btn btn-warning btn-sm"><i class="fas fa-arrow-left"></i> Return</a>
            <button onclick="window.print()" class="btn btn-outline-primary btn-sm" title="Print"><i class="fas fa-print"></i></button>
        </div>
    </div>

    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show no-print">
            <?= h($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- ========== STATISTICS CARDS ========== -->
    <div class="row g-3 mb-4">
        <div class="col-md-3 col-6">
            <div class="stat-card bg-primary">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-book-open me-1"></i> Total</p>
                        <h3 class="stat-value"><?= number_format($totalIssued) ?></h3>
                    </div>
                    <div class="stat-icon"><i class="fas fa-book-open"></i></div>
                </div>
                <small>Transactions</small>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-success">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-check-circle me-1"></i> Returned</p>
                        <h3 class="stat-value"><?= number_format($totalReturned) ?></h3>
                    </div>
                    <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                </div>
                <small><?= $totalIssued > 0 ? round($totalReturned / $totalIssued * 100) : 0 ?>% returned</small>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-warning">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-clock me-1"></i> Overdue</p>
                        <h3 class="stat-value"><?= number_format($totalOverdue) ?></h3>
                    </div>
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                </div>
                <small>Needs attention</small>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="stat-card bg-danger">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <p class="stat-label"><i class="fas fa-coins me-1"></i> Total Fine</p>
                        <h3 class="stat-value"><?= formatCurrency($totalFine) ?></h3>
                    </div>
                    <div class="stat-icon"><i class="fas fa-coins"></i></div>
                </div>
                <small>Collected fines</small>
            </div>
        </div>
    </div>

    <!-- ========== FILTER CARD ========== -->
    <div class="card-custom mb-4 no-print">
        <div class="card-header">
            <span><i class="fas fa-filter me-2"></i> Filter Transactions</span>
            <span class="badge bg-light text-dark">Apply filters to refine results</span>
        </div>
        <div class="card-body filter-card">
            <form class="row g-3" method="get">
                <div class="col-md-2">
                    <label class="form-label fw-semibold">From Date</label>
                    <input type="date" name="from" class="form-control" value="<?= $from ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">To Date</label>
                    <input type="date" name="to" class="form-control" value="<?= $to ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Adm/Mem No</label>
                    <input type="text" name="admno" class="form-control" value="<?= h($admno) ?>" placeholder="Search">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Class</label>
                    <select name="class" class="form-select">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= h($c) ?>" <?= $class == $c ? 'selected' : '' ?>><?= h($c) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Division</label>
                    <select name="division" class="form-select">
                        <option value="">All Divisions</option>
                        <?php foreach ($divisions as $d): ?>
                            <option value="<?= h($d) ?>" <?= $division == $d ? 'selected' : '' ?>><?= h($d) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-semibold">Status</label>
                    <select name="status" class="form-select">
                        <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All</option>
                        <option value="issued" <?= $status === 'issued' ? 'selected' : '' ?>>Currently Issued</option>
                        <option value="returned" <?= $status === 'returned' ? 'selected' : '' ?>>Returned</option>
                        <option value="overdue" <?= $status === 'overdue' ? 'selected' : '' ?>>Overdue</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-gradient-primary"><i class="fas fa-search"></i> Apply</button>
                    <a href="?from=<?= date('Y-m-01') ?>&to=<?= date('Y-m-d') ?>" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</a>
                    <a href="?from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= $status ?>&export=excel" class="btn btn-success float-end"><i class="fas fa-file-excel"></i> Excel</a>
                    <a href="?from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= $status ?>&format=pdf" class="btn btn-danger float-end me-2"><i class="fas fa-file-pdf"></i> PDF</a>
                </div>
            </form>
        </div>
    </div>

    <!-- ========== CLASS & DIVISION SUMMARY ========== -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-success">
                    <span><i class="fas fa-chart-bar me-2"></i> Class-wise Summary</span>
                    <span class="badge bg-light text-dark"><?= count($classSummary) ?> classes</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover summary-table mb-0">
                            <thead class="table-light">
                                <tr><th>Class</th><th class="text-center">Issued</th><th class="text-center">Returned</th><th class="text-center">Overdue</th><th class="text-end">Fine</th></tr>
                            </thead>
                            <tbody>
                                <?php if (empty($classSummary)): ?>
                                    <tr><td colspan="5" class="text-center text-muted py-3">No data</td></tr>
                                <?php else: ?>
                                    <?php foreach ($classSummary as $c): ?>
                                        <tr>
                                            <td><strong><?= $c['class'] ?: 'Unspecified' ?></strong></td>
                                            <td class="text-center"><?= $c['total_issued'] ?></td>
                                            <td class="text-center"><?= $c['total_returned'] ?></td>
                                            <td class="text-center overdue-count"><?= $c['overdue_count'] ?></td>
                                            <td class="text-end"><?= formatCurrency($c['total_fine']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card-custom">
                <div class="card-header bg-warning text-dark">
                    <span><i class="fas fa-chart-pie me-2"></i> Division-wise Summary</span>
                    <span class="badge bg-dark text-white"><?= count($divisionSummary) ?> divisions</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover summary-table mb-0">
                            <thead class="table-light">
                                <tr><th>Division</th><th class="text-center">Issued</th><th class="text-center">Returned</th><th class="text-center">Overdue</th><th class="text-end">Fine</th></tr>
                            </thead>
                            <tbody>
                                <?php if (empty($divisionSummary)): ?>
                                    <tr><td colspan="5" class="text-center text-muted py-3">No data</td></tr>
                                <?php else: ?>
                                    <?php foreach ($divisionSummary as $d): ?>
                                        <tr>
                                            <td><strong><?= $d['division'] ?: 'Unspecified' ?></strong></td>
                                            <td class="text-center"><?= $d['total_issued'] ?></td>
                                            <td class="text-center"><?= $d['total_returned'] ?></td>
                                            <td class="text-center overdue-count"><?= $d['overdue_count'] ?></td>
                                            <td class="text-end"><?= formatCurrency($d['total_fine']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== TRANSACTIONS TABLE ========== -->
    <div class="card-custom">
        <div class="card-header bg-info">
            <span><i class="fas fa-list me-2"></i> Transaction Records</span>
            <span class="badge bg-light text-dark"><?= count($transactions) ?> records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-transactions mb-0" id="transactionsTable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Issue Date</th>
                            <th>Return Date</th>
                            <th>AdmNo</th>
                            <th>Member</th>
                            <th>Class</th>
                            <th>Division</th>
                            <th>Book Title</th>
                            <th>Barcode</th>
                            <th>Due Date</th>
                            <th class="text-end">Fine</th>
                            <th class="text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transactions)): ?>
                            <tr>
                                <td colspan="12" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x d-block mb-2"></i>
                                    No transactions found matching the filters.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $sn = 1; foreach ($transactions as $t): 
                                $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
                                $statusClass = $t['return_date'] ? 'status-returned' : ($isOverdue ? 'status-overdue' : 'status-issued');
                                $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
                                $fine = (float)($t['fine'] ?? 0);
                            ?>
                                <tr>
                                    <td><?= $sn++ ?></td>
                                    <td><?= formatDate($t['issue_date']) ?></td>
                                    <td><?= $t['return_date'] ? formatDate($t['return_date']) : '-' ?></td>
                                    <td><code><?= h($t['admno']) ?></code></td>
                                    <td><?= h($t['member_name'] ?? '-') ?></td>
                                    <td><?= h($t['member_class'] ?? '-') ?></td>
                                    <td><?= h($t['member_division'] ?? '-') ?></td>
                                    <td title="<?= h($t['title']) ?>">
                                        <?= h(substr($t['title'], 0, 35)) ?><?= strlen($t['title']) > 35 ? '…' : '' ?>
                                    </td>
                                    <td><code><?= h($t['barcode']) ?></code></td>
                                    <td class="<?= $isOverdue ? 'text-overdue' : '' ?>">
                                        <?= formatDate($t['due_date']) ?>
                                        <?php if ($isOverdue): ?>
                                            <br><small class="text-danger fw-bold">Overdue!</small>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end"><?= $fine > 0 ? formatCurrency($fine) : '-' ?></td>
                                    <td class="text-center">
                                        <span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <?php if (!empty($transactions)): ?>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="10" class="text-end">Summary:</td>
                            <td class="text-end"><?= formatCurrency($totalFine) ?></td>
                            <td class="text-center">
                                <span class="status-badge status-issued"><?= $totalIssued - $totalReturned - $totalOverdue ?> Issued</span>
                                <span class="status-badge status-returned"><?= $totalReturned ?> Returned</span>
                                <span class="status-badge status-overdue"><?= $totalOverdue ?> Overdue</span>
                            </td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- ========== SCRIPTS ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== CLOCK ==========
function updateClock() {
    document.getElementById('currentTime').textContent = new Date().toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
}
updateClock();
setInterval(updateClock, 1000);

// ========== PRINT HANDLING ==========
window.onbeforeprint = function() {
    document.querySelectorAll('.no-print').forEach(el => el.style.display = 'none');
};
window.onafterprint = function() {
    document.querySelectorAll('.no-print').forEach(el => el.style.display = '');
};

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        const open = document.querySelector('.modal.show');
        if (open) bootstrap.Modal.getInstance(open)?.hide();
    }
});
</script>

<?php
// ========== EXPORT FUNCTIONS ==========
function exportExcel($transactions, $classSummary, $divisionSummary, $from, $to, $class, $division) {
    echo '<html><head><meta charset="UTF-8"><title>Circulation Transactions Report</title></head><body>';
    echo '<h2>Library Circulation Transactions Report</h2>';
    echo '<p>Period: ' . formatDate($from) . ' to ' . formatDate($to) . '</p>';
    echo '<p>Filters: ' . ($class ? "Class: $class " : '') . ($division ? "Division: $division " : '') . '</p>';
    echo '<p>Generated: ' . date('d/m/Y H:i:s') . '</p>';
    
    // Class-wise summary
    echo '<h3>Class-wise Summary</h3>';
    echo '<table border="1" cellpadding="5"><tr style="background:#1e3c72;color:white"><th>Class</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>';
    foreach ($classSummary as $c) {
        echo '<tr><td>' . ($c['class'] ?: 'Unspecified') . '</td>';
        echo '<td>' . $c['total_issued'] . '</td>';
        echo '<td>' . $c['total_returned'] . '</td>';
        echo '<td>' . $c['overdue_count'] . '</td>';
        echo '<td>' . formatCurrency($c['total_fine']) . '</td></tr>';
    }
    echo '</table>';
    
    // Division-wise summary
    echo '<h3>Division-wise Summary</h3>';
    echo '<table border="1" cellpadding="5"><tr style="background:#1e3c72;color:white"><th>Division</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>';
    foreach ($divisionSummary as $d) {
        echo '<tr><td>' . ($d['division'] ?: 'Unspecified') . '</td>';
        echo '<td>' . $d['total_issued'] . '</td>';
        echo '<td>' . $d['total_returned'] . '</td>';
        echo '<td>' . $d['overdue_count'] . '</td>';
        echo '<td>' . formatCurrency($d['total_fine']) . '</td></tr>';
    }
    echo '</table>';
    
    // Detailed transactions
    echo '<h3>Detailed Transactions</h3>';
    echo '<table border="1" cellpadding="5">';
    echo '<tr style="background:#1e3c72;color:white"><th>Sl No</th><th>Issue Date</th><th>Return Date</th><th>AdmNo</th><th>Member</th><th>Class</th><th>Division</th><th>Book</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr>';
    
    $sn = 1;
    foreach ($transactions as $t) {
        $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
        $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
        echo '<tr>';
        echo '<td>' . $sn++ . '</td>';
        echo '<td>' . formatDate($t['issue_date']) . '</td>';
        echo '<td>' . ($t['return_date'] ? formatDate($t['return_date']) : '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['admno']) . '</td>';
        echo '<td>' . htmlspecialchars($t['member_name'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['member_class'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['member_division'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['title']) . '</td>';
        echo '<td>' . htmlspecialchars($t['barcode']) . '</td>';
        echo '<td>' . formatDate($t['due_date']) . '</td>';
        echo '<td>' . formatCurrency($t['fine']) . '</td>';
        echo '<td>' . $statusText . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    echo '<p>Total Records: ' . count($transactions) . '</p>';
    echo '</body></html>';
}

function exportPDF($transactions, $classSummary, $divisionSummary, $from, $to, $class, $division, $settings) {
    ?>
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>Circulation Transactions Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2, h3 { text-align: center; color: #1e3c72; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 11px; }
        th { background: #1e3c72; color: white; }
        .summary { background: #f0f2f5; }
    </style>
    </head>
    <body>
        <h2><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></h2>
        <h3>Circulation Transactions Report</h3>
        <p>Period: <?= formatDate($from) ?> to <?= formatDate($to) ?></p>
        <p>Filters: <?= $class ? "Class: $class " : '' ?><?= $division ? "Division: $division " : '' ?></p>
        
        <h3>Class-wise Summary</h3>
        <table>
            <tr><th>Class</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
            <?php foreach ($classSummary as $c): ?>
            <tr><td><?= $c['class'] ?: 'Unspecified' ?></td><td><?= $c['total_issued'] ?></td><td><?= $c['total_returned'] ?></td><td><?= $c['overdue_count'] ?></td><td><?= formatCurrency($c['total_fine']) ?></td></tr>
            <?php endforeach; ?>
        </table>
        
        <h3>Division-wise Summary</h3>
        <table>
            <tr><th>Division</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
            <?php foreach ($divisionSummary as $d): ?>
            <tr><td><?= $d['division'] ?: 'Unspecified' ?></td><td><?= $d['total_issued'] ?></td><td><?= $d['total_returned'] ?></td><td><?= $d['overdue_count'] ?></td><td><?= formatCurrency($d['total_fine']) ?></td></tr>
            <?php endforeach; ?>
        </table>
        
        <h3>Detailed Transactions</h3>
        <table>
            <tr><th>Sl</th><th>Issue Date</th><th>Return Date</th><th>AdmNo</th><th>Member</th><th>Class</th><th>Division</th><th>Book</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr>
            <?php $sn=1; foreach ($transactions as $t): 
                $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
                $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
            ?>
            <tr>
                <td><?= $sn++ ?></td>
                <td><?= formatDate($t['issue_date']) ?></td>
                <td><?= $t['return_date'] ? formatDate($t['return_date']) : '-' ?></td>
                <td><?= htmlspecialchars($t['admno']) ?></td>
                <td><?= htmlspecialchars($t['member_name'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['member_class'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['member_division'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['title']) ?></td>
                <td><?= htmlspecialchars($t['barcode']) ?></td>
                <td><?= formatDate($t['due_date']) ?></td>
                <td><?= formatCurrency($t['fine']) ?></td>
                <td><?= $statusText ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <p>Total Records: <?= count($transactions) ?></p>
    </body>
    </html>
    <?php
}

renderFooter();
?>