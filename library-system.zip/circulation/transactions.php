<?php
/**
 * Transaction History / Reports
 * View all circulation transactions with filters, including class & division wise summary
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
require_once __DIR__ . '/../config/auth.php';

requireLogin();

$db = getDB();
$settings = getSettings();

// Get filter parameters
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$admno = $_GET['admno'] ?? '';
$class = $_GET['class'] ?? '';
$division = $_GET['division'] ?? '';
$status = $_GET['status'] ?? 'all';
$format = $_GET['format'] ?? '';
$export = $_GET['export'] ?? '';

// Get distinct classes and divisions for dropdowns
$classes = $db->query("SELECT DISTINCT class FROM members WHERE class IS NOT NULL AND class != '' ORDER BY class")->fetchAll(PDO::FETCH_COLUMN);
$divisions = $db->query("SELECT DISTINCT division FROM members WHERE division IS NOT NULL AND division != '' ORDER BY division")->fetchAll(PDO::FETCH_COLUMN);

// Build query for transactions
$sql = "SELECT c.* FROM circulation c 
        LEFT JOIN members m ON c.admno = m.admno 
        WHERE c.issue_date BETWEEN ? AND ?";
$params = [$from, $to];

if (!empty($admno)) {
    $sql .= " AND c.admno LIKE ?";
    $params[] = "%$admno%";
}
if (!empty($class)) {
    $sql .= " AND m.class = ?";
    $params[] = $class;
}
if (!empty($division)) {
    $sql .= " AND m.division = ?";
    $params[] = $division;
}

if ($status === 'issued') {
    $sql .= " AND c.return_date IS NULL";
} elseif ($status === 'returned') {
    $sql .= " AND c.return_date IS NOT NULL";
} elseif ($status === 'overdue') {
    $sql .= " AND c.return_date IS NULL AND c.due_date < date('now')";
}

$sql .= " ORDER BY c.issue_date DESC LIMIT 500";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Calculate statistics
$totalIssued = count($transactions);
$totalReturned = count(array_filter($transactions, function($t) { return $t['return_date']; }));
$totalOverdue = count(array_filter($transactions, function($t) { 
    return !$t['return_date'] && strtotime($t['due_date']) < time(); 
}));
$totalFine = array_sum(array_column($transactions, 'fine'));

// ========== CLASS & DIVISION WISE SUMMARY ==========
$classSummary = [];
$divisionSummary = [];

// Class-wise summary
$classStmt = $db->prepare("
    SELECT 
        m.class,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        SUM(CASE WHEN c.return_date IS NULL AND c.due_date < date('now') THEN 1 ELSE 0 END) as overdue_count,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE c.issue_date BETWEEN ? AND ?
    GROUP BY m.class
    ORDER BY total_issued DESC
");
$classStmt->execute([$from, $to]);
$classSummary = $classStmt->fetchAll();

// Division-wise summary
$divisionStmt = $db->prepare("
    SELECT 
        m.division,
        COUNT(c.id) as total_issued,
        SUM(CASE WHEN c.return_date IS NOT NULL THEN 1 ELSE 0 END) as total_returned,
        SUM(CASE WHEN c.return_date IS NULL AND c.due_date < date('now') THEN 1 ELSE 0 END) as overdue_count,
        SUM(c.fine) as total_fine
    FROM circulation c
    LEFT JOIN members m ON c.admno = m.admno
    WHERE c.issue_date BETWEEN ? AND ? AND m.division IS NOT NULL AND m.division != ''
    GROUP BY m.division
    ORDER BY total_issued DESC
");
$divisionStmt->execute([$from, $to]);
$divisionSummary = $divisionStmt->fetchAll();

// Handle Excel export
if ($export === 'excel' || $format === 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="circulation_transactions_' . date('Y-m-d') . '.xls"');
    
    echo '<html><head><meta charset="UTF-8"><title>Circulation Transactions Report</title></head><body>';
    echo '<h2>Library Circulation Transactions Report</h2>';
    echo '<p>Period: ' . formatDate($from) . ' to ' . formatDate($to) . '</p>';
    echo '<p>Filters: ' . ($class ? "Class: $class " : '') . ($division ? "Division: $division " : '') . '</p>';
    echo '<p>Generated: ' . date('d/m/Y H:i:s') . '</p>';
    
    // Class-wise summary
    echo '<h3>Class-wise Summary</h3>';
    echo '<table border="1" cellpadding="5"><tr style="background:#1e3c72;color:white"><th>Class</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>';
    foreach ($classSummary as $c) {
        echo '<tr>';
        echo '<td>' . ($c['class'] ?: 'Unspecified') . '</td>';
        echo '<td>' . $c['total_issued'] . '</td>';
        echo '<td>' . $c['total_returned'] . '</td>';
        echo '<td>' . $c['overdue_count'] . '</td>';
        echo '<td>' . formatCurrency($c['total_fine']) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    
    // Division-wise summary
    echo '<h3>Division-wise Summary</h3>';
    echo '<table border="1" cellpadding="5"><tr style="background:#1e3c72;color:white"><th>Division</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>';
    foreach ($divisionSummary as $d) {
        echo '<tr>';
        echo '<td>' . ($d['division'] ?: 'Unspecified') . '</td>';
        echo '<td>' . $d['total_issued'] . '</td>';
        echo '<td>' . $d['total_returned'] . '</td>';
        echo '<td>' . $d['overdue_count'] . '</td>';
        echo '<td>' . formatCurrency($d['total_fine']) . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    
    // Detailed transactions
    echo '<h3>Detailed Transactions</h3>';
    echo '<table border="1" cellpadding="5">';
    echo '<tr style="background:#1e3c72;color:white"><th>Sl No</th><th>Issue Date</th><th>Return Date</th><th>AdmNo</th><th>Member</th><th>Class</th><th>Division</th><th>Book</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr>';
    
    $sn = 1;
    foreach ($transactions as $t) {
        $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
        $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
        echo '<tr>';
        echo '<td>' . $sn++ . '</td>';
        echo '<td>' . formatDate($t['issue_date']) . '</td>';
        echo '<td>' . ($t['return_date'] ? formatDate($t['return_date']) : '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['admno']) . '</td>';
        echo '<td>' . htmlspecialchars($t['member_name']) . '</td>';
        echo '<td>' . htmlspecialchars($t['class'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['division'] ?? '-') . '</td>';
        echo '<td>' . htmlspecialchars($t['title']) . '</td>';
        echo '<td>' . htmlspecialchars($t['barcode']) . '</td>';
        echo '<td>' . formatDate($t['due_date']) . '</td>';
        echo '<td>' . formatCurrency($t['fine']) . '</td>';
        echo '<td>' . $statusText . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    echo '<p>Total Records: ' . count($transactions) . '</p>';
    echo '</body></html>';
    exit;
}

if ($format === 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="circulation_transactions_' . date('Y-m-d') . '.pdf"');
    ?>
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><title>Circulation Transactions Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2, h3 { text-align: center; color: #1e3c72; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background: #1e3c72; color: white; }
        .summary { background: #f0f2f5; }
    </style>
    </head>
    <body>
        <h2><?= htmlspecialchars($settings['software_header'] ?? 'Library ERP System') ?></h2>
        <h3>Circulation Transactions Report</h3>
        <p>Period: <?= formatDate($from) ?> to <?= formatDate($to) ?></p>
        <p>Filters: <?= $class ? "Class: $class " : '' ?><?= $division ? "Division: $division " : '' ?></p>
        
        <h3>Class-wise Summary</h3>
        <table>
            <tr><th>Class</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
            <?php foreach ($classSummary as $c): ?>
            <tr><td><?= $c['class'] ?: 'Unspecified' ?></td><td><?= $c['total_issued'] ?></td><td><?= $c['total_returned'] ?></td><td><?= $c['overdue_count'] ?></td><td><?= formatCurrency($c['total_fine']) ?></td></tr>
            <?php endforeach; ?>
        </table>
        
        <h3>Division-wise Summary</h3>
        <table>
            <tr><th>Division</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
            <?php foreach ($divisionSummary as $d): ?>
            <tr><td><?= $d['division'] ?: 'Unspecified' ?></td><td><?= $d['total_issued'] ?></td><td><?= $d['total_returned'] ?></td><td><?= $d['overdue_count'] ?></td><td><?= formatCurrency($d['total_fine']) ?></td></tr>
            <?php endforeach; ?>
        </table>
        
        <h3>Detailed Transactions</h3>
        <table>
            <tr><th>Sl</th><th>Issue Date</th><th>Return Date</th><th>AdmNo</th><th>Member</th><th>Class</th><th>Division</th><th>Book</th><th>Barcode</th><th>Due Date</th><th>Fine</th><th>Status</th></tr>
            <?php $sn=1; foreach ($transactions as $t): 
                $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
                $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
            ?>
            <tr>
                <td><?= $sn++ ?></td>
                <td><?= formatDate($t['issue_date']) ?></td>
                <td><?= $t['return_date'] ? formatDate($t['return_date']) : '-' ?></td>
                <td><?= htmlspecialchars($t['admno']) ?></td>
                <td><?= htmlspecialchars($t['member_name']) ?></td>
                <td><?= htmlspecialchars($t['class'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['division'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['title']) ?></td>
                <td><?= htmlspecialchars($t['barcode']) ?></td>
                <td><?= formatDate($t['due_date']) ?></td>
                <td><?= formatCurrency($t['fine']) ?></td>
                <td><?= $statusText ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <p>Total Records: <?= count($transactions) ?></p>
    </body>
    </html>
    <?php
    exit;
}

$flash = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - <?= h($settings['software_header'] ?? 'Library ERP System') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar-custom { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); }
        .status-badge { padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .status-issued { background: #cfe2ff; color: #084298; }
        .status-returned { background: #d4edda; color: #155724; }
        .status-overdue { background: #f8d7da; color: #721c24; }
        .filter-card { background: white; border-radius: 15px; margin-bottom: 20px; }
        .summary-card { background: white; border-radius: 15px; margin-bottom: 20px; }
        .summary-table th { background: #e9ecef; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <nav class="navbar navbar-custom navbar-dark mb-4 no-print">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="/library-system/">
                <?php if (!empty($settings['library_logo']) && file_exists($settings['library_logo'])): ?>
                    <img src="<?= $settings['library_logo'] ?>" style="height: 35px;" class="me-2">
                <?php else: ?>
                    <i class="fas fa-book-open me-2"></i>
                <?php endif; ?>
                <?= h($settings['software_header'] ?? 'Library ERP System') ?> - Transactions
            </a>
            <div>
                <a href="/library-system/circulation/" class="btn btn-outline-light btn-sm">← Back to Circulation</a>
                <a href="/library-system/reports/" class="btn btn-outline-light btn-sm ms-2">Reports</a>
            </div>
        </div>
    </nav>
    
    <div class="container">
        <?php if ($flash): ?>
            <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show no-print">
                <?= h($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Filter Card -->
        <div class="card filter-card no-print">
            <div class="card-header bg-white fw-bold">
                <i class="fas fa-filter"></i> Filter Transactions
            </div>
            <div class="card-body">
                <form class="row g-3" method="get">
                    <div class="col-md-2">
                        <label class="form-label">From Date</label>
                        <input type="date" name="from" class="form-control" value="<?= $from ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">To Date</label>
                        <input type="date" name="to" class="form-control" value="<?= $to ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Adm/Mem No</label>
                        <input type="text" name="admno" class="form-control" value="<?= h($admno) ?>" placeholder="Search">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Class</label>
                        <select name="class" class="form-select">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= h($c) ?>" <?= $class == $c ? 'selected' : '' ?>><?= h($c) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Division</label>
                        <select name="division" class="form-select">
                            <option value="">All Divisions</option>
                            <?php foreach ($divisions as $d): ?>
                                <option value="<?= h($d) ?>" <?= $division == $d ? 'selected' : '' ?>><?= h($d) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>All</option>
                            <option value="issued" <?= $status === 'issued' ? 'selected' : '' ?>>Currently Issued</option>
                            <option value="returned" <?= $status === 'returned' ? 'selected' : '' ?>>Returned</option>
                            <option value="overdue" <?= $status === 'overdue' ? 'selected' : '' ?>>Overdue</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Apply</button>
                        <a href="?from=<?= date('Y-m-01') ?>&to=<?= date('Y-m-d') ?>" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</a>
                        <a href="?from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= $status ?>&export=excel" class="btn btn-success float-end"><i class="fas fa-file-excel"></i> Excel</a>
                        <a href="?from=<?= $from ?>&to=<?= $to ?>&admno=<?= urlencode($admno) ?>&class=<?= urlencode($class) ?>&division=<?= urlencode($division) ?>&status=<?= $status ?>&format=pdf" class="btn btn-danger float-end me-2"><i class="fas fa-file-pdf"></i> PDF</a>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Class & Division Summary Cards -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card summary-card">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-chart-bar"></i> Class-wise Summary
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="table-light">
                                    <tr><th>Class</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($classSummary)): ?>
                                        <tr><td colspan="5" class="text-center text-muted">No data</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($classSummary as $c): ?>
                                            <tr>
                                                <td><strong><?= $c['class'] ?: 'Unspecified' ?></strong></td>
                                                <td><?= $c['total_issued'] ?></td>
                                                <td><?= $c['total_returned'] ?></td>
                                                <td class="text-danger"><?= $c['overdue_count'] ?></td>
                                                <td><?= formatCurrency($c['total_fine']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card summary-card">
                    <div class="card-header bg-success text-white">
                        <i class="fas fa-chart-pie"></i> Division-wise Summary
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover mb-0">
                                <thead class="table-light">
                                    <tr><th>Division</th><th>Issued</th><th>Returned</th><th>Overdue</th><th>Fine</th></tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($divisionSummary)): ?>
                                        <tr><td colspan="5" class="text-center text-muted">No data</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($divisionSummary as $d): ?>
                                            <tr>
                                                <td><strong><?= $d['division'] ?: 'Unspecified' ?></strong></td>
                                                <td><?= $d['total_issued'] ?></td>
                                                <td><?= $d['total_returned'] ?></td>
                                                <td class="text-danger"><?= $d['overdue_count'] ?></td>
                                                <td><?= formatCurrency($d['total_fine']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Statistics Summary Card (overall) -->
        <div class="row mb-4 no-print">
            <div class="col-md-3"><div class="card bg-primary text-white text-center"><div class="card-body"><h3><?= $totalIssued ?></h3><small>Total Transactions</small></div></div></div>
            <div class="col-md-3"><div class="card bg-success text-white text-center"><div class="card-body"><h3><?= $totalReturned ?></h3><small>Returned</small></div></div></div>
            <div class="col-md-3"><div class="card bg-warning text-dark text-center"><div class="card-body"><h3><?= $totalOverdue ?></h3><small>Overdue</small></div></div></div>
            <div class="col-md-3"><div class="card bg-danger text-white text-center"><div class="card-body"><h3><?= formatCurrency($totalFine) ?></h3><small>Total Fines</small></div></div></div>
        </div>
        
        <!-- Report Header (for print) -->
        <div class="text-center mb-4" style="display:none" id="printHeader">
            <h3><?= h($settings['software_header'] ?? 'Library ERP System') ?></h3>
            <h5>Circulation Transactions Report</h5>
            <p>Period: <?= formatDate($from) ?> to <?= formatDate($to) ?></p>
            <p>Filters: <?= $class ? "Class: $class " : '' ?><?= $division ? "Division: $division " : '' ?></p>
        </div>
        
        <!-- Transactions Table -->
        <div class="card">
            <div class="card-header bg-white fw-bold">
                <i class="fas fa-list"></i> Transaction History
                <span class="float-end">Records: <?= count($transactions) ?></span>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="transactionsTable">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th><th>Issue Date</th><th>Return Date</th><th>AdmNo</th><th>Member</th>
                                <th>Class</th><th>Division</th><th>Book Title</th><th>Barcode</th>
                                <th>Due Date</th><th>Fine</th><th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($transactions)): ?>
                                <tr><td colspan="12" class="text-center text-muted py-5">No transactions found.</td></tr>
                            <?php else: ?>
                                <?php $sn = 1; foreach ($transactions as $t): 
                                    $isOverdue = !$t['return_date'] && strtotime($t['due_date']) < time();
                                    $statusClass = $t['return_date'] ? 'status-returned' : ($isOverdue ? 'status-overdue' : 'status-issued');
                                    $statusText = $t['return_date'] ? 'Returned' : ($isOverdue ? 'Overdue' : 'Issued');
                                ?>
                                    <tr>
                                        <td><?= $sn++ ?></td>
                                        <td><?= formatDate($t['issue_date']) ?></td>
                                        <td><?= $t['return_date'] ? formatDate($t['return_date']) : '-' ?></td>
                                        <td><?= h($t['admno']) ?></td>
                                        <td><?= h($t['member_name']) ?></td>
                                        <td><?= h($t['class'] ?? '-') ?></td>
                                        <td><?= h($t['division'] ?? '-') ?></td>
                                        <td><?= h($t['title']) ?></td>
                                        <td><code><?= h($t['barcode']) ?></code></td>
                                        <td class="<?= $isOverdue ? 'text-danger fw-bold' : '' ?>"><?= formatDate($t['due_date']) ?></td>
                                        <td><?= $t['fine'] > 0 ? formatCurrency($t['fine']) : '-' ?></td>
                                        <td><span class="status-badge <?= $statusClass ?>"><?= $statusText ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <?php if (!empty($transactions)): ?>
                        <tfoot class="table-light">
                            <tr class="fw-bold">
                                <td colspan="10" class="text-end">Summary:</td>
                                <td><?= formatCurrency($totalFine) ?></td>
                                <td><?= $totalIssued ?> Total (<?= $totalReturned ?> Returned, <?= $totalOverdue ?> Overdue)</td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mt-4 no-print">
            <div class="col-md-12 text-center">
                <button onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
                <a href="issue.php" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Issue New Book</a>
                <a href="return.php" class="btn btn-warning"><i class="fas fa-arrow-left"></i> Return Book</a>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        window.onbeforeprint = function() {
            document.getElementById('printHeader').style.display = 'block';
            document.querySelectorAll('.no-print').forEach(el => el.style.display = 'none');
        };
        window.onafterprint = function() {
            document.getElementById('printHeader').style.display = 'none';
            document.querySelectorAll('.no-print').forEach(el => el.style.display = '');
        };
    </script>
</body>
</html>