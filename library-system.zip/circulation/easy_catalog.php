<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$db = getDB();
$message = '';
$error = '';

// Auto-create columns if missing (same as books.php logic)
$driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
$existing = ($driver === 'sqlite') ? $db->query("PRAGMA table_info(books)")->fetchAll(PDO::FETCH_COLUMN, 1) : $db->query("SHOW COLUMNS FROM books")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('sub_title', $existing)) $db->exec("ALTER TABLE books ADD COLUMN sub_title TEXT DEFAULT ''");
if (!in_array('keyword', $existing)) $db->exec("ALTER TABLE books ADD COLUMN keyword TEXT DEFAULT ''");

$isbndbKey = getSettingValue('isbndb_api_key');
$worldcatKey = getSettingValue('worldcat_api_key');
$yazAvailable = extension_loaded('yaz');

// Helper functions (copied from books.php)
function curlGet($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Library-ERP/1.0');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $data = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code === 200) ? $data : false;
}

function fetchBookMetadataEasy($isbn) {
    $isbn = preg_replace('/[^0-9X]/i', '', $isbn);
    if (strlen($isbn) < 10) return null;
    // Try Google Books first
    $json = curlGet("https://www.googleapis.com/books/v1/volumes?q=isbn:$isbn");
    if ($json) {
        $data = json_decode($json, true);
        if (!empty($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            return [
                'title' => $info['title'] ?? '',
                'subtitle' => $info['subtitle'] ?? '',
                'author' => isset($info['authors']) ? implode(', ', $info['authors']) : '',
                'publisher' => $info['publisher'] ?? '',
                'year' => substr($info['publishedDate'] ?? '', 0, 4),
                'pages' => $info['pageCount'] ?? 0,
                'subject' => isset($info['categories']) ? implode(', ', $info['categories']) : '',
                'summary' => $info['description'] ?? '',
                'cover_url' => $info['imageLinks']['thumbnail'] ?? '',
                'source' => 'Google Books'
            ];
        }
    }
    // Fallback to OpenLibrary
    $json = curlGet("https://openlibrary.org/api/books?bibkeys=ISBN:$isbn&format=json&jscmd=data");
    if ($json) {
        $data = json_decode($json, true);
        $key = "ISBN:$isbn";
        if (isset($data[$key])) {
            $book = $data[$key];
            return [
                'title' => $book['title'] ?? '',
                'subtitle' => $book['subtitle'] ?? '',
                'author' => isset($book['authors']) ? implode(', ', array_column($book['authors'], 'name')) : '',
                'publisher' => $book['publishers'][0]['name'] ?? '',
                'year' => preg_replace('/[^0-9]/', '', $book['publish_date'] ?? ''),
                'pages' => $book['number_of_pages'] ?? 0,
                'subject' => isset($book['subjects']) ? implode(', ', array_slice($book['subjects'], 0, 3)) : '',
                'summary' => $book['notes'] ?? ($book['description'] ?? ''),
                'cover_url' => $book['cover']['large'] ?? ($book['cover']['medium'] ?? ''),
                'source' => 'OpenLibrary'
            ];
        }
    }
    return null;
}

function downloadCoverImageEasy($url, $barcode) {
    if (empty($url)) return false;
    $ext = 'jpg';
    $path = parse_url($url, PHP_URL_PATH);
    if ($path && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $path, $m)) {
        $ext = strtolower($m[1]);
    }
    $filename = 'book_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $barcode) . '_' . time() . '.' . $ext;
    $target = __DIR__ . '/../uploads/books/' . $filename;
    if (!is_dir(__DIR__ . '/../uploads/books/')) mkdir(__DIR__ . '/../uploads/books/', 0777, true);
    $data = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Library-ERP/1.0');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($http !== 200) $data = false;
    }
    if (!$data && function_exists('file_get_contents')) {
        $context = stream_context_create(['http' => ['method' => 'GET', 'header' => "User-Agent: Library-ERP/1.0\r\n", 'timeout' => 15, 'ignore_errors' => true], 'ssl' => ['verify_peer' => false]]);
        $data = @file_get_contents($url, false, $context);
    }
    if ($data !== false && file_put_contents($target, $data)) {
        return 'uploads/books/' . $filename;
    }
    return false;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_book'])) {
    try {
        $barcode = trim($_POST['barcode']);
        if (empty($barcode)) {
            throw new Exception("Barcode is required");
        }
        $check = $db->prepare("SELECT barcode FROM books WHERE barcode = ?");
        $check->execute([$barcode]);
        if ($check->fetch()) {
            throw new Exception("Book with this barcode already exists");
        }
        $title = trim($_POST['title']);
        if (empty($title)) {
            throw new Exception("Title is required");
        }
        $quantity = (int)($_POST['quantity'] ?? 1);
        $available = isset($_POST['available']) ? (int)$_POST['available'] : $quantity;
        $price = !empty($_POST['price']) ? (float)$_POST['price'] : null;
        $coverPath = '';
        if (!empty($_POST['pre_downloaded_cover'])) {
            $coverPath = $_POST['pre_downloaded_cover'];
        } elseif (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['cover_image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
                $filename = 'book_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $barcode) . '_' . time() . '.' . $ext;
                $target = __DIR__ . '/../uploads/books/' . $filename;
                if (move_uploaded_file($_FILES['cover_image']['tmp_name'], $target)) {
                    $coverPath = 'uploads/books/' . $filename;
                }
            }
        }
        $stmt = $db->prepare("INSERT INTO books (barcode, isbn, title, sub_title, author, publisher, year, pages, subject, summary, cover_path, quantity, available, price, price_currency, keyword, language) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $barcode, $_POST['isbn'] ?? '', $title, $_POST['sub_title'] ?? '', $_POST['author'] ?? '',
            $_POST['publisher'] ?? '', $_POST['year'] ?? '', (int)($_POST['pages'] ?? 0), $_POST['subject'] ?? '',
            $_POST['summary'] ?? '', $coverPath, $quantity, $available, $price, $_POST['price_currency'] ?? 'INR',
            $_POST['keyword'] ?? '', $_POST['language'] ?? 'English'
        ]);
        $message = "Book added successfully!";
        logActivity($_SESSION['username'], 'EASY_CATALOG', "Added book: $barcode - $title");
        // Clear form
        $_POST = [];
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

renderHeader('Easy Cataloguing');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Easy Cataloguing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body{background:#eef2f7}
        .card{border:none;border-radius:20px;box-shadow:0 10px 30px rgba(0,0,0,0.1)}
        .card-header{background:linear-gradient(135deg,#1e3c72,#2a5298);color:white;border-radius:20px 20px 0 0;padding:15px 25px}
        .form-control, .form-select{border-radius:12px;padding:10px 15px}
        .btn-primary{border-radius:30px;padding:10px 30px}
        .cover-preview{max-height:150px;border-radius:10px;margin-top:10px}
        .info-icon{color:#1e3c72;font-size:0.8rem;margin-left:5px}
    </style>
</head>
<body>
<div class="container mt-4 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><i class="fas fa-feather-alt"></i> Easy Cataloguing</h2>
        <a href="books.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Back to Full Cataloguing</a>
    </div>

    <?php if($message): ?>
        <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($message) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?= htmlspecialchars($error) ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <i class="fas fa-plus-circle me-2"></i> Add New Book – Minimal Fields
        </div>
        <div class="card-body p-4">
            <form method="post" enctype="multipart/form-data" id="easyForm">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label">Barcode *</label>
                        <input type="text" name="barcode" class="form-control" required value="<?= htmlspecialchars($_POST['barcode'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">ISBN (10/13) – Auto‑fetch metadata</label>
                        <div class="input-group">
                            <input type="text" name="isbn" id="isbn" class="form-control" value="<?= htmlspecialchars($_POST['isbn'] ?? '') ?>">
                            <button type="button" class="btn btn-primary" onclick="fetchMetadata()"><i class="fas fa-sync-alt"></i> Fetch</button>
                        </div>
                        <div id="fetchStatus" class="small text-muted mt-1"></div>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Title *</label>
                        <input type="text" name="title" id="title" class="form-control" required value="<?= htmlspecialchars($_POST['title'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Subtitle</label>
                        <input type="text" name="sub_title" id="sub_title" class="form-control" value="<?= htmlspecialchars($_POST['sub_title'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Author(s)</label>
                        <input type="text" name="author" id="author" class="form-control" value="<?= htmlspecialchars($_POST['author'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Publisher</label>
                        <input type="text" name="publisher" id="publisher" class="form-control" value="<?= htmlspecialchars($_POST['publisher'] ?? '') ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Year</label>
                        <input type="text" name="year" id="year" class="form-control" value="<?= htmlspecialchars($_POST['year'] ?? '') ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Pages</label>
                        <input type="number" name="pages" id="pages" class="form-control" value="<?= htmlspecialchars($_POST['pages'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Language</label>
                        <input type="text" name="language" class="form-control" value="<?= htmlspecialchars($_POST['language'] ?? 'English') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Subjects (Keywords)</label>
                        <input type="text" name="subject" id="subject" class="form-control" value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Additional Keywords</label>
                        <input type="text" name="keyword" class="form-control" value="<?= htmlspecialchars($_POST['keyword'] ?? '') ?>">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Summary / Description</label>
                        <textarea name="summary" id="summary" class="form-control" rows="3"><?= htmlspecialchars($_POST['summary'] ?? '') ?></textarea>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Quantity</label>
                        <input type="number" name="quantity" class="form-control" value="<?= $_POST['quantity'] ?? 1 ?>" min="1">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Available copies</label>
                        <input type="number" name="available" class="form-control" value="<?= $_POST['available'] ?? 1 ?>" min="0">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Price</label>
                        <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Currency</label>
                        <select name="price_currency" class="form-select">
                            <option value="INR" selected>INR (₹)</option>
                            <option value="USD">USD ($)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="GBP">GBP (£)</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Cover Image</label>
                        <input type="file" name="cover_image" class="form-control" accept="image/*" onchange="previewCover(this)">
                        <div id="coverPreviewContainer" class="mt-2" style="display:none;"><img id="coverPreviewImg" class="cover-preview"></div>
                        <input type="hidden" name="pre_downloaded_cover" id="preDownloadedCover" value="">
                    </div>
                    <div class="col-12 text-center mt-3">
                        <button type="submit" name="add_book" class="btn btn-primary btn-lg px-5"> <i class="fas fa-save"></i> Save Book</button>
                        <button type="reset" class="btn btn-secondary btn-lg px-4">Clear</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="text-muted mt-3 text-center small">
        <i class="fas fa-info-circle"></i> Use the "Fetch" button to automatically fill title, author, publisher, year, pages, subjects, summary and cover from Google Books or OpenLibrary (via ISBN).
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function fetchMetadata() {
    let isbn = document.getElementById('isbn').value.trim();
    if(isbn.length < 10) {
        document.getElementById('fetchStatus').innerHTML = '<span class="text-warning">Enter at least 10 digits</span>';
        return;
    }
    let statusDiv = document.getElementById('fetchStatus');
    statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching metadata...';
    fetch('easy_catalog.php?ajax_fetch=1&isbn=' + encodeURIComponent(isbn))
        .then(r => r.json())
        .then(data => {
            if(data.success) {
                let b = data.data;
                document.getElementById('title').value = b.title || '';
                document.getElementById('sub_title').value = b.subtitle || '';
                document.getElementById('author').value = b.author || '';
                document.getElementById('publisher').value = b.publisher || '';
                document.getElementById('year').value = b.year || '';
                document.getElementById('pages').value = b.pages || '';
                document.getElementById('subject').value = b.subject || '';
                document.getElementById('summary').value = b.summary || '';
                if(b.cover_url) {
                    let previewDiv = document.getElementById('coverPreviewContainer');
                    let previewImg = document.getElementById('coverPreviewImg');
                    previewImg.src = b.cover_url;
                    previewDiv.style.display = 'block';
                    // Download cover
                    let barcode = document.getElementById('barcode').value.trim() || 'temp';
                    fetch('easy_catalog.php?ajax_download_cover=1&url=' + encodeURIComponent(b.cover_url) + '&barcode=' + encodeURIComponent(barcode))
                        .then(res => res.json())
                        .then(dlData => {
                            if(dlData.success) {
                                document.getElementById('preDownloadedCover').value = dlData.path;
                                previewImg.src = dlData.webUrl;
                            }
                        })
                        .catch(err => console.error("Cover download error", err));
                }
                statusDiv.innerHTML = '<span class="text-success">Fetched from ' + (b.source || 'external source') + '</span>';
            } else {
                statusDiv.innerHTML = '<span class="text-danger">' + (data.error || 'Not found') + '</span>';
            }
        })
        .catch(err => {
            console.error(err);
            statusDiv.innerHTML = '<span class="text-danger">Network error</span>';
        });
}

function previewCover(input) {
    let previewDiv = document.getElementById('coverPreviewContainer');
    let previewImg = document.getElementById('coverPreviewImg');
    if(input.files && input.files[0]) {
        let reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            previewDiv.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        previewDiv.style.display = 'none';
    }
}

// AJAX handlers for this page (placed inline)
<?php
if (isset($_GET['ajax_fetch'])) {
    header('Content-Type: application/json');
    $isbn = preg_replace('/[^0-9X]/i', '', $_GET['isbn']);
    if (strlen($isbn) < 10) {
        echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
        exit;
    }
    $result = fetchBookMetadataEasy($isbn);
    if ($result) {
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => 'No metadata found']);
    }
    exit;
}
if (isset($_GET['ajax_download_cover'])) {
    header('Content-Type: application/json');
    $url = $_GET['url'] ?? '';
    $barcode = $_GET['barcode'] ?? 'temp';
    $local = downloadCoverImageEasy($url, $barcode);
    if ($local) {
        $webUrl = (strpos($local, 'http') === 0) ? $local : (substr($local, 0, 8) === 'uploads/' ? BASE_URL . '/' . $local : $local);
        echo json_encode(['success' => true, 'path' => $local, 'webUrl' => $webUrl]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Download failed']);
    }
    exit;
}
?>
</script>
</body>
</html>
<?php renderFooter(); ?>