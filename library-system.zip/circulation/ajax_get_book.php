<?php
require_once __DIR__ . '/../config/db.php';
session_start();
header('Content-Type: application/json');

// Only allow logged-in users
if(!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$isbn = trim($_GET['isbn'] ?? '');
if(empty($isbn)) {
    echo json_encode(['error' => 'No ISBN provided']);
    exit;
}

// Clean ISBN
$isbn = preg_replace('/[^0-9X]/i', '', $isbn);
$result = ['title' => '', 'author' => '', 'publisher' => '', 'year' => '', 'pages' => 0, 'cover_url' => '', 'summary' => ''];

// Try OpenLibrary API first
$ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
$openlibUrl = "https://openlibrary.org/api/books?bibkeys=ISBN:" . $isbn . "&format=json&jscmd=data";
$response = @file_get_contents($openlibUrl, false, $ctx);
if($response) {
    $data = json_decode($response, true);
    $key = "ISBN:" . $isbn;
    if(isset($data[$key])) {
        $book = $data[$key];
        $result['title'] = $book['title'] ?? '';
        $result['author'] = isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '';
        $result['publisher'] = isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '';
        $result['year'] = $book['publish_date'] ?? '';
        $result['pages'] = $book['number_of_pages'] ?? 0;
        $result['cover_url'] = $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
        $result['summary'] = isset($book['description']) ? (is_array($book['description']) ? ($book['description']['value'] ?? '') : $book['description']) : '';
    }
}

// If OpenLibrary fails, try Google Books API
if(empty($result['title'])) {
    $googleUrl = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . $isbn;
    $response = @file_get_contents($googleUrl, false, $ctx);
    if($response) {
        $data = json_decode($response, true);
        if(isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $result['title'] = $info['title'] ?? '';
            $result['author'] = isset($info['authors'][0]) ? $info['authors'][0] : '';
            $result['publisher'] = $info['publisher'] ?? '';
            $result['year'] = $info['publishedDate'] ?? '';
            $result['pages'] = $info['pageCount'] ?? 0;
            $result['summary'] = $info['description'] ?? '';
            $result['cover_url'] = $info['imageLinks']['thumbnail'] ?? '';
        }
    }
}

if(empty($result['title'])) {
    echo json_encode(['error' => 'Book not found in online databases. Check ISBN or add manually.']);
} else {
    echo json_encode($result);
}
exit;
?>