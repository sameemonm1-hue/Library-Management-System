<?php
/**
 * AJAX Book Metadata Fetcher - v3.5 (Unified with Circulation Dashboard)
 * - Fetches book metadata from multiple sources
 * - Returns unified JSON response format
 * - Supports OpenLibrary, Google Books, ISBNdb, WorldCat
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
session_start();

header('Content-Type: application/json');

// Only allow logged-in users
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$isbn = trim($_GET['isbn'] ?? '');
$source = $_GET['source'] ?? 'auto';

if (empty($isbn)) {
    echo json_encode(['success' => false, 'error' => 'No ISBN provided']);
    exit;
}

// Clean ISBN
$isbn = preg_replace('/[^0-9X]/i', '', $isbn);
if (strlen($isbn) < 10) {
    echo json_encode(['success' => false, 'error' => 'Invalid ISBN']);
    exit;
}

$result = [
    'title' => '',
    'author' => '',
    'publisher' => '',
    'year' => '',
    'pages' => 0,
    'cover_url' => '',
    'summary' => '',
    'category' => '',
    'source' => ''
];

$ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);

// ========== OPENLIBRARY ==========
function fetchOpenLibrary($isbn, &$result) {
    global $ctx;
    $url = "https://openlibrary.org/api/books?bibkeys=ISBN:" . $isbn . "&format=json&jscmd=data";
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        $key = "ISBN:" . $isbn;
        if (isset($data[$key])) {
            $book = $data[$key];
            $result['title'] = $book['title'] ?? '';
            $result['author'] = $book['authors'][0]['name'] ?? '';
            $result['publisher'] = $book['publishers'][0]['name'] ?? '';
            $result['year'] = $book['publish_date'] ?? '';
            $result['pages'] = $book['number_of_pages'] ?? 0;
            $result['cover_url'] = $book['cover']['large'] ?? $book['cover']['medium'] ?? '';
            $result['summary'] = isset($book['description']) ? (is_array($book['description']) ? ($book['description']['value'] ?? '') : $book['description']) : '';
            $result['category'] = $book['subjects'][0]['name'] ?? '';
            $result['source'] = 'openlibrary';
            return true;
        }
    }
    return false;
}

// ========== GOOGLE BOOKS ==========
function fetchGoogleBooks($isbn, &$result) {
    global $ctx;
    $url = "https://www.googleapis.com/books/v1/volumes?q=isbn:" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['items'][0]['volumeInfo'])) {
            $info = $data['items'][0]['volumeInfo'];
            $result['title'] = $info['title'] ?? '';
            $result['author'] = $info['authors'][0] ?? '';
            $result['publisher'] = $info['publisher'] ?? '';
            $result['year'] = $info['publishedDate'] ?? '';
            $result['pages'] = $info['pageCount'] ?? 0;
            $result['summary'] = $info['description'] ?? '';
            $result['category'] = $info['categories'][0] ?? '';
            $result['cover_url'] = $info['imageLinks']['thumbnail'] ?? '';
            $result['source'] = 'google';
            return true;
        }
    }
    return false;
}

// ========== ISBNdb ==========
function fetchISBNdb($isbn, &$result) {
    $settings = getSettings();
    $apiKey = $settings['isbndb_api_key'] ?? '';
    if (empty($apiKey)) return false;
    
    $ctx = stream_context_create(['http' => [
        'timeout' => 15,
        'ignore_errors' => true,
        'header' => "Authorization: " . $apiKey
    ]]);
    $url = "https://api2.isbndb.com/book/" . $isbn;
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['book'])) {
            $book = $data['book'];
            $result['title'] = $book['title'] ?? '';
            $result['author'] = $book['authors'] ? implode(', ', $book['authors']) : '';
            $result['publisher'] = $book['publisher'] ?? '';
            $result['year'] = $book['date_published'] ?? '';
            $result['pages'] = $book['pages'] ?? 0;
            $result['summary'] = $book['synopsis'] ?? '';
            $result['category'] = $book['subject'] ?? '';
            $result['cover_url'] = $book['image'] ?? '';
            $result['source'] = 'isbndb';
            return true;
        }
    }
    return false;
}

// ========== WORLDCAT ==========
function fetchWorldCat($isbn, &$result) {
    $settings = getSettings();
    $apiKey = $settings['worldcat_api_key'] ?? '';
    if (empty($apiKey)) return false;
    
    $ctx = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true]]);
    $url = "http://www.worldcat.org/webservices/catalog/content/isbn/" . $isbn . "?wskey=" . $apiKey . "&format=xml";
    $response = @file_get_contents($url, false, $ctx);
    if ($response) {
        $xml = @simplexml_load_string($response);
        if ($xml) {
            $namespaces = $xml->getNamespaces(true);
            $dc = $namespaces['dc'] ?? '';
            if ($dc) {
                $result['title'] = (string)$xml->children($dc)->title ?? '';
                $result['author'] = (string)$xml->children($dc)->creator ?? '';
                $result['publisher'] = (string)$xml->children($dc)->publisher ?? '';
                $result['year'] = (string)$xml->children($dc)->date ?? '';
                $result['source'] = 'worldcat';
                return true;
            }
        }
    }
    return false;
}

// ========== EXECUTE FETCH ==========
$fetched = false;

if ($source === 'auto') {
    $sources = ['openlibrary', 'google', 'isbndb', 'worldcat'];
    foreach ($sources as $src) {
        $fetched = false;
        switch ($src) {
            case 'openlibrary': $fetched = fetchOpenLibrary($isbn, $result); break;
            case 'google': $fetched = fetchGoogleBooks($isbn, $result); break;
            case 'isbndb': $fetched = fetchISBNdb($isbn, $result); break;
            case 'worldcat': $fetched = fetchWorldCat($isbn, $result); break;
        }
        if ($fetched && !empty($result['title'])) break;
    }
} else {
    switch ($source) {
        case 'openlibrary': $fetched = fetchOpenLibrary($isbn, $result); break;
        case 'google': $fetched = fetchGoogleBooks($isbn, $result); break;
        case 'isbndb': $fetched = fetchISBNdb($isbn, $result); break;
        case 'worldcat': $fetched = fetchWorldCat($isbn, $result); break;
        default: $fetched = false;
    }
}

if ($fetched && !empty($result['title'])) {
    echo json_encode(['success' => true, 'data' => $result]);
} else {
    echo json_encode(['success' => false, 'error' => 'Book not found in online databases. Check ISBN or add manually.']);
}
?>