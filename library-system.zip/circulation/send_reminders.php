<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireLogin();

$db = getDB();
$settings = getSettings();

$overdueIds = explode(',', $_POST['overdue_ids'] ?? '');

if(isset($_POST['send_email'])) {
    foreach($overdueIds as $id) {
        $stmt = $db->prepare("SELECT c.*, m.email, m.name as member_name FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno WHERE c.id = ?");
        $stmt->execute([$id]);
        $book = $stmt->fetch();
        
        if($book && $book['email']) {
            $days = ceil((time() - strtotime($book['due_date'])) / 86400);
            $fine = $days * $settings['fine_per_day'];
            $subject = "Overdue Book Notice - " . htmlspecialchars($book['title']);
            $message = "Dear {$book['member_name']},\n\n"
                . "The book '{$book['title']}' is overdue by {$days} days.\n"
                . "Please return it as soon as possible. Fine accrued: " . formatCurrency($fine) . "\n\n"
                . "Thank you,\nLibrary Staff";
            
            sendEmail($book['email'], $subject, nl2br($message));
        }
    }
    showToast("Email reminders sent", "success");
    
} elseif(isset($_POST['send_sms'])) {
    foreach($overdueIds as $id) {
        $stmt = $db->prepare("SELECT c.*, m.phone FROM circulation c 
            LEFT JOIN members m ON c.admno = m.admno WHERE c.id = ?");
        $stmt->execute([$id]);
        $book = $stmt->fetch();
        
        if($book && $book['phone']) {
            $days = ceil((time() - strtotime($book['due_date'])) / 86400);
            $message = "Overdue: '{$book['title']}' - {$days} days late. Please return.";
            sendSMS($book['phone'], $message);
        }
    }
    showToast("SMS reminders sent", "success");
}

header("Location: overdue.php");
exit;
?>