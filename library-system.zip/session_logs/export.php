<?php
require_once __DIR__ . '/../config/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized");
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

$db = getDB();

$user_type = $_GET['user_type'] ?? '';
$username = $_GET['username'] ?? '';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

$sql = "SELECT * FROM session_logs WHERE 1=1";
$params = [];

if ($user_type) {
    $sql .= " AND user_type = ?";
    $params[] = $user_type;
}
if ($username) {
    $sql .= " AND username LIKE ?";
    $params[] = "%$username%";
}
if ($from_date) {
    $sql .= " AND DATE(login_time) >= ?";
    $params[] = $from_date;
}
if ($to_date) {
    $sql .= " AND DATE(login_time) <= ?";
    $params[] = $to_date;
}
$sql .= " ORDER BY login_time DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="session_logs_' . date('Y-m-d') . '.csv"');
header('Cache-Control: private, max-age=0, must-revalidate');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'User Type', 'Username', 'Login Time', 'Logout Time', 'IP Address', 'Session ID', 'User Agent']);

foreach ($sessions as $s) {
    fputcsv($output, [
        $s['id'],
        $s['user_type'],
        $s['username'],
        $s['login_time'],
        $s['logout_time'] ?? '',
        $s['ip_address'],
        $s['session_id'],
        $s['user_agent']
    ]);
}
fclose($output);
exit;
?>