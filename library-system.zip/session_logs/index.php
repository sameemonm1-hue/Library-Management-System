<?php
require_once __DIR__ . '/../config/functions.php';
// session_start(); // REMOVED - session is already started in db.php (included via functions.php)

if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

$user_type = $_GET['user_type'] ?? '';
$username = $_GET['username'] ?? '';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

$sql = "SELECT * FROM session_logs WHERE 1=1";
$params = [];

if ($user_type) {
    $sql .= " AND user_type = ?";
    $params[] = $user_type;
}
if ($username) {
    $sql .= " AND username LIKE ?";
    $params[] = "%$username%";
}
if ($from_date) {
    $sql .= " AND DATE(login_time) >= ?";
    $params[] = $from_date;
}
if ($to_date) {
    $sql .= " AND DATE(login_time) <= ?";
    $params[] = $to_date;
}
$sql .= " ORDER BY login_time DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

foreach ($sessions as &$s) {
    if ($s['logout_time']) {
        $login = new DateTime($s['login_time']);
        $logout = new DateTime($s['logout_time']);
        $diff = $login->diff($logout);
        $s['duration'] = $diff->format('%h h %i m');
    } else {
        $s['duration'] = 'Still logged in';
    }
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Session Logs - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .filter-card { background: white; border-radius: 16px; padding: 20px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .table-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .badge-user { font-size: 12px; padding: 5px 10px; border-radius: 20px; }
        .btn-home { margin-left: 10px; }
        @media print { .filter-card, .btn, .footer { display: none; } }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-history"></i> Session Logs</h2>
                <div>
                    <a href="export.php?<?= http_build_query($_GET) ?>" class="btn btn-success"><i class="fas fa-file-csv"></i> Export to CSV</a>
                    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <div class="filter-card">
                <form method="GET" class="row g-3">
                    <div class="col-md-2">
                        <label>User Type</label>
                        <select name="user_type" class="form-select">
                            <option value="">All</option>
                            <option value="admin" <?= $user_type=='admin'?'selected':'' ?>>Admin</option>
                            <option value="member" <?= $user_type=='member'?'selected':'' ?>>Member</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($username) ?>" placeholder="Search...">
                    </div>
                    <div class="col-md-2">
                        <label>From Date</label>
                        <input type="date" name="from_date" class="form-control" value="<?= $from_date ?>">
                    </div>
                    <div class="col-md-2">
                        <label>To Date</label>
                        <input type="date" name="to_date" class="form-control" value="<?= $to_date ?>">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2"><i class="fas fa-search"></i> Filter</button>
                        <a href="index.php" class="btn btn-secondary">Reset</a>
                    </div>
                </form>
            </div>

            <div class="table-card">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>User Type</th>
                                <th>Username</th>
                                <th>Login Time</th>
                                <th>Logout Time</th>
                                <th>Duration</th>
                                <th>IP Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($sessions) == 0): ?>
                                <tr><td colspan="8" class="text-center">No session logs found.<?php else: ?>
                                <?php foreach ($sessions as $s): ?>
                                    <tr>
                                        <td class="fw-bold"><?= $s['id'] ?> </td>
                                        <td><span class="badge bg-<?= $s['user_type']=='admin'?'primary':'info' ?> badge-user"><?= ucfirst($s['user_type']) ?></span> </td>
                                        <td><?= htmlspecialchars($s['username']) ?> </td>
                                        <td><?= date('d-m-Y H:i:s', strtotime($s['login_time'])) ?> </td>
                                        <td><?= $s['logout_time'] ? date('d-m-Y H:i:s', strtotime($s['logout_time'])) : '-' ?> </td>
                                        <td><?= $s['duration'] ?> </td>
                                        <td>
                                            <?= htmlspecialchars($s['ip_address']) ?><br>
                                            <small class="text-muted"><?= htmlspecialchars($s['session_id']) ?></small>
                                         </td>
                                        <td><a href="view.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i> Details</a> </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>