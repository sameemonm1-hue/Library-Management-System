<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) header("Location: ../index.php");

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$id = intval($_GET['id'] ?? 0);
if (!$id) die("Invalid session ID.");

$stmt = $db->prepare("SELECT * FROM session_logs WHERE id = ?");
$stmt->execute([$id]);
$session = $stmt->fetch();
if (!$session) die("Session not found.");

if ($session['logout_time']) {
    $login = new DateTime($session['login_time']);
    $logout = new DateTime($session['logout_time']);
    $diff = $login->diff($logout);
    $duration = $diff->format('%h hours %i minutes %s seconds');
} else {
    $duration = 'Still logged in (active)';
}

$logoUrl = getWebImageUrl($institution['logo_path'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Session Details - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f4f6f9; }
        .content-wrapper { padding: 30px; }
        .detail-card { background: white; border-radius: 16px; padding: 25px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .footer { text-align: center; padding: 20px; color: #6c757d; background: white; margin-top: 30px; border-radius: 16px; }
        .info-label { font-weight: 600; color: #1e3c72; width: 180px; display: inline-block; }
        .btn-home { margin-left: 10px; }
        @media print { .btn, .footer { display: none; } }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-info-circle"></i> Session Details</h2>
                <div>
                    <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to List</a>
                    <a href="../index.php" class="btn btn-primary btn-home"><i class="fas fa-home"></i> Back to Home</a>
                </div>
            </div>

            <div class="detail-card">
                <div class="row">
                    <div class="col-md-6">
                        <p><span class="info-label">Session ID:</span> <?= htmlspecialchars($session['session_id']) ?></p>
                        <p><span class="info-label">User Type:</span> <span class="badge bg-<?= $session['user_type']=='admin'?'primary':'info' ?>"><?= ucfirst($session['user_type']) ?></span></p>
                        <p><span class="info-label">Username:</span> <?= htmlspecialchars($session['username']) ?></p>
                        <p><span class="info-label">Login Time:</span> <?= date('d-m-Y H:i:s', strtotime($session['login_time'])) ?></p>
                        <p><span class="info-label">Logout Time:</span> <?= $session['logout_time'] ? date('d-m-Y H:i:s', strtotime($session['logout_time'])) : '<span class="text-success">Still active</span>' ?></p>
                        <p><span class="info-label">Duration:</span> <?= $duration ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><span class="info-label">IP Address:</span> <?= htmlspecialchars($session['ip_address']) ?></p>
                        <p><span class="info-label">User Agent:</span></p>
                        <div class="border rounded p-2 bg-light" style="word-break: break-all; font-family: monospace; font-size: 12px;">
                            <?= nl2br(htmlspecialchars($session['user_agent'])) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="footer">
            <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>