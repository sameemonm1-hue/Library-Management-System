<?php
require_once __DIR__ . '/../config/functions.php';
session_start();
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Rate limiting
$rate_key = 'ajax_rate_' . $_SESSION['user_id'];
if (!isset($_SESSION[$rate_key])) $_SESSION[$rate_key] = 0;
if ($_SESSION[$rate_key] > 20) {
    echo json_encode(['error' => 'Too many requests. Please wait.']);
    exit;
}
$_SESSION[$rate_key]++;

$db = getDB();
$action = $_GET['action'] ?? '';

if ($action == 'get_sessions') {
    $user_type = $_GET['user_type'] ?? '';
    $username = $_GET['username'] ?? '';
    $from_date = $_GET['from_date'] ?? '';
    $to_date = $_GET['to_date'] ?? '';
    
    $sql = "SELECT * FROM session_logs WHERE 1=1";
    $params = [];
    
    if ($user_type) {
        $sql .= " AND user_type = ?";
        $params[] = $user_type;
    }
    if ($username) {
        $sql .= " AND username LIKE ?";
        $params[] = "%$username%";
    }
    if ($from_date) {
        $sql .= " AND DATE(login_time) >= ?";
        $params[] = $from_date;
    }
    if ($to_date) {
        $sql .= " AND DATE(login_time) <= ?";
        $params[] = $to_date;
    }
    $sql .= " ORDER BY login_time DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $sessions = $stmt->fetchAll();
    
    foreach ($sessions as &$s) {
        if ($s['logout_time']) {
            $login = new DateTime($s['login_time']);
            $logout = new DateTime($s['logout_time']);
            $diff = $login->diff($logout);
            $s['duration'] = $diff->format('%h h %i m');
        } else {
            $s['duration'] = 'Still logged in';
        }
    }
    
    echo json_encode(['success' => true, 'data' => $sessions]);
    exit;
}

if ($action == 'get_session') {
    $id = intval($_GET['id'] ?? 0);
    if (!$id) {
        echo json_encode(['error' => 'Invalid session ID']);
        exit;
    }
    $stmt = $db->prepare("SELECT * FROM session_logs WHERE id = ?");
    $stmt->execute([$id]);
    $session = $stmt->fetch();
    if (!$session) {
        echo json_encode(['error' => 'Session not found']);
        exit;
    }
    if ($session['logout_time']) {
        $login = new DateTime($session['login_time']);
        $logout = new DateTime($session['logout_time']);
        $diff = $login->diff($logout);
        $session['duration'] = $diff->format('%h hours %i minutes %s seconds');
    } else {
        $session['duration'] = 'Still logged in (active)';
    }
    echo json_encode(['success' => true, 'data' => $session]);
    exit;
}

echo json_encode(['error' => 'Invalid action']);
?>