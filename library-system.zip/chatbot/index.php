<?php
/**
 * Library ERP – Complete AI Chatbot Assistant
 * 
 * Features:
 * - OpenAI GPT integration (optional, falls back to smart keywords)
 * - Persistent chat sessions with database storage
 * - Member context (loans, fines, personalised answers)
 * - CSRF protection and rate limiting
 * - Beautiful responsive UI with typing indicator
 * - Admin can configure OpenAI key via settings
 * 
 * @package LibraryERP
 * @version 2.0
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// ==================== DATABASE SETUP ====================
$db = getDB();
$db->exec("CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    user_type TEXT DEFAULT 'guest',
    user_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$db->exec("CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT CHECK(role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    tokens INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// ==================== HELPER FUNCTIONS ====================
function getOpenAIKey() {
    $settings = getSettings();
    return $settings['openai_api_key'] ?? '';
}

function callOpenAI($messages, $apiKey) {
    if (empty($apiKey)) return null;
    
    $url = 'https://api.openai.com/v1/chat/completions';
    $data = [
        'model' => 'gpt-3.5-turbo',
        'messages' => $messages,
        'temperature' => 0.7,
        'max_tokens' => 500
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200) {
        $result = json_decode($response, true);
        return $result['choices'][0]['message']['content'] ?? null;
    }
    return null;
}

function getKeywordResponse($message, $member = null) {
    $msg = strtolower(trim($message));
    $db = getDB();
    $settings = getSettings();
    
    // Library hours
    if (strpos($msg, 'hour') !== false || strpos($msg, 'timing') !== false || strpos($msg, 'open') !== false) {
        return getLibraryHoursHTML(); // from functions.php
    }
    
    // Book search
    if (strpos($msg, 'search') !== false || strpos($msg, 'find book') !== false || strpos($msg, 'look for') !== false) {
        return "You can search our catalogue using the <a href='../opac/'>OPAC</a>. Enter title, author, or ISBN. For advanced AI search, try the <a href='../opac/semantic_search.php'>Semantic Search</a> page.";
    }
    
    // Contact
    if (strpos($msg, 'contact') !== false || strpos($msg, 'email') !== false || strpos($msg, 'phone') !== false) {
        $contact = "You can reach us at:<br>";
        if (!empty($settings['mail_from'])) $contact .= "📧 Email: " . htmlspecialchars($settings['mail_from']) . "<br>";
        if (!empty($settings['whatsapp_number'])) $contact .= "📱 WhatsApp: " . htmlspecialchars($settings['whatsapp_number']);
        if (empty($settings['mail_from']) && empty($settings['whatsapp_number'])) $contact .= "Please visit the library in person or use the contact form.";
        return $contact;
    }
    
    // Fines / overdue
    if (strpos($msg, 'fine') !== false || strpos($msg, 'overdue') !== false) {
        if ($member) {
            return "Your current total fines: " . formatCurrency($member['total_fines']) . ". You can pay them online via your <a href='../member/account.php'>member account</a>.";
        } else {
            return "Overdue fines are calculated per day. Please log in to your member account to see your fines. General rate is " . formatCurrency($settings['fine_per_day'] ?? 2) . " per day for most books.";
        }
    }
    
    // Member loans
    if ((strpos($msg, 'loan') !== false || strpos($msg, 'borrowed') !== false || strpos($msg, 'issued') !== false) && $member) {
        $stmt = $db->prepare("SELECT b.title, c.due_date FROM circulation c JOIN books b ON c.barcode = b.barcode WHERE c.admno = ? AND c.return_date IS NULL ORDER BY c.due_date ASC LIMIT 5");
        $stmt->execute([$member['admno']]);
        $loans = $stmt->fetchAll();
        if (count($loans) > 0) {
            $response = "You currently have " . count($loans) . " book(s) borrowed:<br><ul>";
            foreach ($loans as $loan) {
                $response .= "<li>" . htmlspecialchars($loan['title']) . " – due " . date('d-m-Y', strtotime($loan['due_date'])) . "</li>";
            }
            $response .= "</ul>";
            return $response;
        } else {
            return "You have no active loans. Great!";
        }
    }
    
    // Borrowing policy
    if (strpos($msg, 'borrow') !== false || strpos($msg, 'issue') !== false) {
        $maxBooks = $settings['max_books'] ?? 5;
        $loanDays = $settings['loan_days'] ?? 7;
        return "You can borrow up to $maxBooks books for $loanDays days. Bring your member card to the circulation desk. Renewals are allowed once if no holds.";
    }
    
    // Membership
    if (strpos($msg, 'membership') !== false || strpos($msg, 'renew') !== false) {
        return "Membership can be renewed at the library counter. Please bring your ID and pay the annual fee (if applicable). Expired members cannot borrow books.";
    }
    
    // Lost book
    if (strpos($msg, 'lost') !== false) {
        return "If you lost a book, report immediately at the circulation desk. You will need to pay replacement cost plus a processing fee. The exact amount depends on the book.";
    }
    
    // Holidays
    if (strpos($msg, 'holiday') !== false) {
        return "The library remains closed on national holidays and second Saturdays. Check the notice board or our website for exact dates.";
    }
    
    // Greeting / help
    if (strpos($msg, 'hello') !== false || strpos($msg, 'hi') === 0 || strpos($msg, 'help') !== false) {
        return "Hello! I'm the library assistant. I can help with:<br>
        • 📅 Library hours and location<br>
        • 🔍 Finding books (search our catalogue)<br>
        • 💰 Fines and overdue books<br>
        • 📚 Your current loans (if logged in)<br>
        • 📞 Contact information<br><br>
        What would you like to know?";
    }
    
    return "I'm not sure about that. Please ask about library hours, book search, fines, your loans (login required), or contact details. For complex queries, a librarian will assist you.";
}

// ==================== RATE LIMITING (optional) ====================
function isRateLimited($sessionId, $limit = 10, $window = 60) {
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM chat_messages WHERE session_id = ? AND role = 'user' AND created_at > datetime('now', '-' || ? || ' seconds')");
    $stmt->execute([$sessionId, $window]);
    $count = $stmt->fetchColumn();
    return $count >= $limit;
}

// ==================== GET OR CREATE SESSION ====================
$sessionId = session_id();
$db->prepare("INSERT OR IGNORE INTO chat_sessions (session_id, user_type, last_activity) VALUES (?, 'guest', datetime('now'))")->execute([$sessionId]);
$db->prepare("UPDATE chat_sessions SET last_activity = datetime('now') WHERE session_id = ?")->execute([$sessionId]);

// Member context (if logged in)
$member = null;
if (isset($_SESSION['member_id'])) {
    $stmt = $db->prepare("SELECT id, admno, name, email, total_fines, member_category FROM members WHERE id = ?");
    $stmt->execute([$_SESSION['member_id']]);
    $member = $stmt->fetch();
    if ($member) {
        $db->prepare("UPDATE chat_sessions SET user_type = 'member', user_id = ? WHERE session_id = ?")->execute([$member['id'], $sessionId]);
    }
}

// ==================== AJAX REQUEST HANDLER ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    header('Content-Type: application/json');
    
    // CSRF protection (optional but recommended)
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['error' => 'Invalid security token. Please refresh the page.']);
        exit;
    }
    
    $message = trim($_POST['message'] ?? '');
    if (empty($message)) {
        echo json_encode(['error' => 'Message cannot be empty']);
        exit;
    }
    
    // Rate limiting
    if (isRateLimited($sessionId)) {
        echo json_encode(['error' => 'Too many messages. Please wait a moment before sending more.']);
        exit;
    }
    
    // Save user message
    $db->prepare("INSERT INTO chat_messages (session_id, role, content) VALUES (?, 'user', ?)")->execute([$sessionId, $message]);
    
    // Build conversation context (last 6 messages)
    $stmt = $db->prepare("SELECT role, content FROM chat_messages WHERE session_id = ? ORDER BY created_at DESC LIMIT 6");
    $stmt->execute([$sessionId]);
    $history = array_reverse($stmt->fetchAll());
    
    // Try OpenAI first
    $apiKey = getOpenAIKey();
    $reply = null;
    if (!empty($apiKey)) {
        $openaiMessages = [];
        $openaiMessages[] = ['role' => 'system', 'content' => "You are a helpful library assistant for a library management system. Answer questions about library hours, book search, fines, member accounts, and library policies. Be concise and friendly. Use HTML for formatting if needed."];
        if ($member) {
            $openaiMessages[] = ['role' => 'system', 'content' => "The current member is " . $member['name'] . " (ID: " . $member['admno'] . "). You can answer questions about their loans and fines based on your knowledge, but advise them to log into their account for exact real‑time details."];
        }
        foreach ($history as $msg) {
            $openaiMessages[] = ['role' => $msg['role'], 'content' => $msg['content']];
        }
        $reply = callOpenAI($openaiMessages, $apiKey);
    }
    
    // Fallback to keyword responses
    if ($reply === null) {
        $reply = getKeywordResponse($message, $member);
    }
    
    // Save assistant reply
    $db->prepare("INSERT INTO chat_messages (session_id, role, content) VALUES (?, 'assistant', ?)")->execute([$sessionId, $reply]);
    
    echo json_encode(['reply' => $reply]);
    exit;
}

// ==================== PAGE RENDERING ====================
$settings = getSettings();
$institution = getInstitution();
$pageTitle = "AI Library Assistant";
renderHeader($pageTitle);

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title><?= htmlspecialchars($pageTitle) ?> - <?= htmlspecialchars($settings['software_header'] ?? 'Library ERP') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        .chat-container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            border-radius: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .chat-header {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            padding: 20px 25px;
        }
        .chat-header h3 {
            margin: 0;
            font-weight: 700;
        }
        .chat-header p {
            margin: 5px 0 0;
            opacity: 0.9;
        }
        .chat-messages {
            height: 500px;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .message {
            margin-bottom: 20px;
            display: flex;
        }
        .message.user {
            justify-content: flex-end;
        }
        .message.assistant {
            justify-content: flex-start;
        }
        .message .bubble {
            max-width: 75%;
            padding: 12px 18px;
            border-radius: 25px;
            font-size: 0.95rem;
            line-height: 1.4;
        }
        .message.user .bubble {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white;
            border-bottom-right-radius: 5px;
        }
        .message.assistant .bubble {
            background: white;
            color: #333;
            border-bottom-left-radius: 5px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .chat-input-area {
            padding: 15px 20px;
            background: white;
            border-top: 1px solid #e9ecef;
            display: flex;
            gap: 10px;
        }
        .chat-input-area input {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 50px;
            padding: 12px 20px;
            outline: none;
            font-size: 1rem;
        }
        .chat-input-area input:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 3px rgba(30,60,114,0.1);
        }
        .chat-input-area button {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            border: none;
            border-radius: 50px;
            padding: 0 25px;
            color: white;
            font-weight: 600;
            transition: all 0.3s;
        }
        .chat-input-area button:hover {
            transform: translateY(-2px);
            filter: brightness(1.05);
        }
        .typing-indicator {
            display: none;
            margin-bottom: 20px;
            align-items: center;
            gap: 8px;
            background: white;
            width: fit-content;
            padding: 8px 15px;
            border-radius: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #aaa;
            border-radius: 50%;
            display: inline-block;
            animation: bounce 1.4s infinite ease-in-out both;
        }
        .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
        .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
        @keyframes bounce {
            0%, 80%, 100% { transform: scale(0); }
            40% { transform: scale(1); }
        }
        .footer {
            text-align: center;
            padding: 15px;
            font-size: 12px;
            color: #6c757d;
            background: white;
            border-top: 1px solid #eee;
        }
        @media (max-width: 768px) {
            .chat-container { margin: 15px; border-radius: 20px; }
            .chat-messages { height: 400px; }
            .message .bubble { max-width: 85%; }
        }
    </style>
</head>
<body>
<div class="chat-container">
    <div class="chat-header">
        <h3><i class="fas fa-robot me-2"></i> Library Assistant</h3>
        <p>Ask me anything about the library – hours, books, fines, or your account.</p>
        <?php if ($member): ?>
            <span class="badge bg-light text-dark mt-2"><i class="fas fa-user-check"></i> Logged in as <?= htmlspecialchars($member['name']) ?></span>
        <?php else: ?>
            <a href="../opac/login.php" class="btn btn-sm btn-outline-light mt-2"><i class="fas fa-sign-in-alt"></i> Member Login for personalised help</a>
        <?php endif; ?>
    </div>
    <div class="chat-messages" id="chatMessages">
        <div class="message assistant">
            <div class="bubble">
                Hello! I'm your library assistant. I can help you find books, tell you library hours, explain fines, and more. How can I help you today?
            </div>
        </div>
    </div>
    <div class="typing-indicator" id="typingIndicator">
        <span></span><span></span><span></span>
    </div>
    <div class="chat-input-area">
        <input type="text" id="messageInput" placeholder="Type your question..." autocomplete="off">
        <button id="sendBtn"><i class="fas fa-paper-plane"></i> Send</button>
    </div>
    <div class="footer">
        <i class="fas fa-brain"></i> Powered by <?= !empty(getOpenAIKey()) ? 'OpenAI GPT' : 'Smart Keyword Responses' ?>
        <?php if (!empty(getOpenAIKey())): ?>
            <span class="text-success ms-2"><i class="fas fa-check-circle"></i> AI enabled</span>
        <?php else: ?>
            <span class="text-warning ms-2"><i class="fas fa-exclamation-triangle"></i> Add OpenAI API key in <a href="../admin/settings.php">Settings</a> for AI responses</span>
        <?php endif; ?>
    </div>
</div>

<script>
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const typingIndicator = document.getElementById('typingIndicator');
const csrfToken = '<?= $csrfToken ?>';

function addMessage(text, isUser) {
    const div = document.createElement('div');
    div.className = `message ${isUser ? 'user' : 'assistant'}`;
    div.innerHTML = `<div class="bubble">${text}</div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    }).replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, function(c) {
        return c;
    });
}

async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message) return;
    
    addMessage(escapeHtml(message), true);
    messageInput.value = '';
    
    typingIndicator.style.display = 'flex';
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    const formData = new FormData();
    formData.append('message', message);
    formData.append('csrf_token', csrfToken);
    
    try {
        const response = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        });
        const data = await response.json();
        typingIndicator.style.display = 'none';
        if (data.error) {
            addMessage('⚠️ ' + escapeHtml(data.error), false);
        } else {
            addMessage(data.reply, false);
        }
    } catch (err) {
        typingIndicator.style.display = 'none';
        addMessage('Network error. Please check your connection and try again.', false);
    }
}

sendBtn.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});
</script>

<?php renderFooter(); ?>