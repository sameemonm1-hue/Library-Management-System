<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';

$question = strtolower(trim($_POST['message'] ?? ''));
$reply = "I'm sorry, I didn't understand. Please ask about timings, borrowing, fines, book availability, or membership.";

// Keyword matching
if (strpos($question, 'timing') !== false || strpos($question, 'open') !== false || strpos($question, 'hours') !== false) {
    $reply = "Library timings: Monday–Friday 9:00 AM – 8:00 PM, Saturday 9:00 AM – 5:00 PM, Sunday closed.";
} 
elseif (strpos($question, 'borrow') !== false || strpos($question, 'issue') !== false || strpos($question, 'loan') !== false) {
    $maxBooks = $settings['max_books'] ?? 5;
    $loanDays = $settings['loan_days'] ?? 7;
    $reply = "You can borrow up to $maxBooks books for $loanDays days. Bring your member card to the circulation desk.";
}
elseif (strpos($question, 'fine') !== false || strpos($question, 'late') !== false || strpos($question, 'penalty') !== false) {
    $fine = $settings['fine_per_day'] ?? 2;
    $reply = "The standard fine is $currencySymbol$fine per day per overdue book. Check with staff for category‑wise rates.";
}
elseif (strpos($question, 'availability') !== false || strpos($question, 'available') !== false || strpos($question, 'find book') !== false) {
    $reply = "You can search for books in our <a href='../opac/'>OPAC</a>. If you need help, ask at the front desk.";
}
elseif (strpos($question, 'renew') !== false || strpos($question, 'extend') !== false || strpos($question, 'membership') !== false) {
    $reply = "Membership can be renewed at the library counter. Please bring your ID and pay the annual fee if applicable.";
}
elseif (strpos($question, 'contact') !== false || strpos($question, 'phone') !== false || strpos($question, 'email') !== false) {
    $reply = "You can call us at +91-XXXXXXXXXX or email library@example.com";
}
elseif (strpos($question, 'lost book') !== false) {
    $reply = "If you lost a book, please report immediately. You will need to pay replacement cost plus processing fee.";
}
elseif (strpos($question, 'holiday') !== false) {
    $reply = "The library remains closed on national holidays and second Saturdays. Check notice board for updates.";
}

echo json_encode(['reply' => $reply]);