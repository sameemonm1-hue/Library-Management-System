/**
 * js/common.js
 * Shared JavaScript functions for Library ERP System
 */

// ==================== UTILITY FUNCTIONS ====================

/**
 * Escape HTML special characters to prevent XSS
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

/**
 * Show a temporary toast notification
 * @param {string} message
 * @param {string} type - 'success', 'danger', 'warning', 'info'
 * @param {number} duration - milliseconds (default 3000)
 */
function showToast(message, type, duration = 3000) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 shadow-lg`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '280px';
    toast.style.fontSize = '0.9rem';
    toast.style.borderRadius = '50px';
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i> ${message}<button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
}

/**
 * Format a date string to local date (d-m-Y)
 * @param {string} dateStr
 * @returns {string}
 */
function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-GB');
}

/**
 * Format a date/time string to local datetime
 * @param {string} datetimeStr
 * @returns {string}
 */
function formatDateTime(datetimeStr) {
    if (!datetimeStr) return '';
    const d = new Date(datetimeStr);
    return d.toLocaleString('en-GB');
}

/**
 * Get CSRF token from meta tag or from session storage
 * @returns {string}
 */
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.getAttribute('content');
    return window.csrfToken || '';
}

/**
 * Make an AJAX request with JSON handling
 * @param {string} url
 * @param {object} options
 * @returns {Promise}
 */
function ajaxRequest(url, options = {}) {
    const defaults = {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        credentials: 'same-origin'
    };
    const config = Object.assign({}, defaults, options);
    if (config.body && typeof config.body === 'object') {
        config.body = new URLSearchParams(config.body).toString();
    }
    return fetch(url, config).then(response => response.json());
}

/**
 * Debounce function for input events
 * @param {Function} func
 * @param {number} delay
 * @returns {Function}
 */
function debounce(func, delay) {
    let timer;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(timer);
        timer = setTimeout(() => func.apply(context, args), delay);
    };
}

/**
 * Copy text to clipboard
 * @param {string} text
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Could not copy', 'danger');
    });
}

// ==================== MEMBER / BOOK LOOKUP ====================

/**
 * Fetch member information by admission number
 * @param {string} admno
 * @returns {Promise<object>}
 */
function fetchMember(admno) {
    return ajaxRequest(`../entry_exit/ajax_member.php?admno=${encodeURIComponent(admno)}`);
}

/**
 * Fetch book information by barcode
 * @param {string} barcode
 * @returns {Promise<object>}
 */
function fetchBook(barcode) {
    return ajaxRequest(`../circulation/ajax_book.php?barcode=${encodeURIComponent(barcode)}`);
}

// ==================== PRINT FUNCTIONS ====================

/**
 * Print a specific element by ID
 * @param {string} elementId
 */
function printElement(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;
    const originalTitle = document.title;
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${document.title}</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>body { padding: 20px; } .no-print { display: none; }</style>
        </head>
        <body>${element.innerHTML}</body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
}

// Auto-dismiss alerts after 5 seconds
setTimeout(() => {
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}, 3000);