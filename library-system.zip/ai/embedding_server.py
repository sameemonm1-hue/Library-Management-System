#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Embedding Server for Library ERP
Generates vector embeddings for book titles and summaries using sentence-transformers.
"""

from flask import Flask, request, jsonify
from sentence_transformers import SentenceTransformer
import numpy as np
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Load model (MiniLM is fast and good for semantic search)
MODEL_NAME = 'all-MiniLM-L6-v2'
logger.info(f"Loading model: {MODEL_NAME}")
model = SentenceTransformer(MODEL_NAME)
logger.info("Model loaded successfully.")

@app.route('/embed', methods=['POST'])
def embed():
    """
    Expects JSON: {"texts": ["sentence1", "sentence2", ...]}
    Returns: {"embeddings": [[...], [...]]}
    """
    data = request.get_json()
    if not data or 'texts' not in data:
        return jsonify({'error': 'Missing "texts" field'}), 400
    
    texts = data['texts']
    if not isinstance(texts, list):
        return jsonify({'error': 'texts must be a list'}), 400
    
    if len(texts) == 0:
        return jsonify({'embeddings': []})
    
    try:
        embeddings = model.encode(texts).tolist()
        return jsonify({'embeddings': embeddings})
    except Exception as e:
        logger.error(f"Error generating embeddings: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/similarity', methods=['POST'])
def similarity():
    """
    Compute cosine similarity between a query embedding and a list of candidate embeddings.
    Input: {"query": [float, ...], "candidates": [[float, ...], ...]}
    Returns: {"similarities": [float, ...]}
    """
    data = request.get_json()
    if not data or 'query' not in data or 'candidates' not in data:
        return jsonify({'error': 'Missing query or candidates'}), 400
    
    query = np.array(data['query'])
    candidates = np.array(data['candidates'])
    
    if query.ndim != 1:
        return jsonify({'error': 'query must be 1D array'}), 400
    if candidates.ndim == 1:
        candidates = candidates.reshape(1, -1)
    
    # Normalize vectors
    query_norm = query / np.linalg.norm(query)
    candidates_norm = candidates / np.linalg.norm(candidates, axis=1, keepdims=True)
    
    similarities = np.dot(candidates_norm, query_norm).tolist()
    return jsonify({'similarities': similarities})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    # Run on all interfaces, port 5001
    app.run(host='0.0.0.0', port=5001, debug=False)