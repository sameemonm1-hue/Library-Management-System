<?php
/**
 * Start a new computer session
 * Members cannot have two active sessions simultaneously
 */
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$error = '';
$success = '';

// Get list of computers with status 'active'
$computers = $db->query("SELECT id, computer_name, location FROM computers WHERE status = 'active' ORDER BY computer_name")->fetchAll();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_session'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid security token. Please refresh and try again.";
    } else {
        $member_id = (int)$_POST['member_id'];
        $computer_id = (int)$_POST['computer_id'];
        
        // Check if member already has an active session
        $checkActive = $db->prepare("SELECT cs.id, c.computer_name FROM computer_sessions cs 
                                     JOIN computers c ON cs.computer_id = c.id 
                                     WHERE cs.member_id = ? AND cs.logout_time IS NULL");
        $checkActive->execute([$member_id]);
        $active = $checkActive->fetch();
        
        if ($active) {
            $error = "This member already has an active session on computer: " . htmlspecialchars($active['computer_name']) . ". End that session first.";
        } else {
            // Start new session
            $stmt = $db->prepare("INSERT INTO computer_sessions (member_id, computer_id, login_time) VALUES (?, ?, datetime('now'))");
            if ($stmt->execute([$member_id, $computer_id])) {
                $success = "Session started successfully.";
                logActivity($_SESSION['username'], 'COMPUTER_SESSION_START', "Started session for member ID $member_id on computer $computer_id");
                // Regenerate CSRF token after successful action
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            } else {
                $error = "Failed to start session. Please try again.";
            }
        }
    }
}

// Member search via AJAX
if (isset($_GET['ajax']) && $_GET['ajax'] == 'search_members') {
    header('Content-Type: application/json');
    $search = trim($_GET['q'] ?? '');
    if (strlen($search) < 2) {
        echo json_encode([]);
        exit;
    }
    $stmt = $db->prepare("SELECT id, admno, name, class, division, member_category 
                          FROM members 
                          WHERE status = 'active' 
                          AND (admno LIKE ? OR name LIKE ? OR class LIKE ? OR division LIKE ?)
                          LIMIT 20");
    $like = "%$search%";
    $stmt->execute([$like, $like, $like, $like]);
    $members = $stmt->fetchAll();
    echo json_encode($members);
    exit;
}

renderHeader('Start Computer Session');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Start Computer Session</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f4f6f9; }
        .card { border-radius: 20px; border: none; }
        .member-result { cursor: pointer; transition: background 0.2s; }
        .member-result:hover { background: #e9ecef; }
        .selected-member-card { background: #e3f2fd; border-left: 4px solid #1e3c72; }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-play-circle"></i> Start Computer Session</h2>
        <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?> <a href="index.php">View active sessions</a></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body p-4">
            <form method="post" id="startSessionForm">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="mb-4">
                    <label class="form-label fw-bold">Search Member</label>
                    <input type="text" id="memberSearch" class="form-control" placeholder="Type AdmNo, Name, Class/Dept, or Div/Course... (min 2 chars)">
                    <div id="memberResults" class="list-group mt-2" style="max-height: 300px; overflow-y: auto;"></div>
                    <input type="hidden" id="selectedMemberId" name="member_id" required>
                    <div id="selectedMemberInfo" class="alert alert-info mt-2 d-none">
                        <strong>Selected Member:</strong> <span id="selectedMemberName"></span> (ID: <span id="selectedMemberAdmno"></span>)<br>
                        <small>Class/Dept: <span id="selectedMemberClass"></span> | Div/Course: <span id="selectedMemberDivision"></span></small>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Computer</label>
                    <select name="computer_id" id="computer_id" class="form-select" required>
                        <option value="">-- Select Computer --</option>
                        <?php foreach ($computers as $comp): ?>
                            <option value="<?= $comp['id'] ?>"><?= htmlspecialchars($comp['computer_name']) ?> (<?= htmlspecialchars($comp['location'] ?? 'No location') ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($computers)): ?>
                        <div class="text-danger mt-1">No active computers found. <a href="manage_computers.php">Add a computer first</a>.</div>
                    <?php endif; ?>
                </div>

                <button type="submit" name="start_session" class="btn btn-success px-4" <?= empty($computers) ? 'disabled' : '' ?>>
                    <i class="fas fa-play"></i> Start Session
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    let searchTimeout;
    const searchInput = document.getElementById('memberSearch');
    const resultsDiv = document.getElementById('memberResults');
    const selectedMemberId = document.getElementById('selectedMemberId');
    const selectedInfo = document.getElementById('selectedMemberInfo');
    const selectedNameSpan = document.getElementById('selectedMemberName');
    const selectedAdmnoSpan = document.getElementById('selectedMemberAdmno');
    const selectedClassSpan = document.getElementById('selectedMemberClass');
    const selectedDivisionSpan = document.getElementById('selectedMemberDivision');

    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        if (query.length < 2) {
            resultsDiv.innerHTML = '';
            return;
        }
        searchTimeout = setTimeout(() => {
            fetch(`computer_access.php?ajax=search_members&q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    if (data.length === 0) {
                        resultsDiv.innerHTML = '<div class="list-group-item text-muted">No members found</div>';
                        return;
                    }
                    let html = '';
                    data.forEach(m => {
                        html += `<div class="list-group-item list-group-item-action member-result" 
                                    data-id="${m.id}" 
                                    data-admno="${escapeHtml(m.admno)}"
                                    data-name="${escapeHtml(m.name)}"
                                    data-class="${escapeHtml(m.class || '')}"
                                    data-division="${escapeHtml(m.division || '')}">
                                    <strong>${escapeHtml(m.name)}</strong> (${escapeHtml(m.admno)})<br>
                                    <small>Class/Dept: ${escapeHtml(m.class || '-')} | Div/Course: ${escapeHtml(m.division || '-')}</small>
                                </div>`;
                    });
                    resultsDiv.innerHTML = html;
                    document.querySelectorAll('.member-result').forEach(el => {
                        el.addEventListener('click', function() {
                            selectedMemberId.value = this.dataset.id;
                            selectedNameSpan.innerText = this.dataset.name;
                            selectedAdmnoSpan.innerText = this.dataset.admno;
                            selectedClassSpan.innerText = this.dataset.class || '-';
                            selectedDivisionSpan.innerText = this.dataset.division || '-';
                            selectedInfo.classList.remove('d-none');
                            searchInput.value = `${this.dataset.name} (${this.dataset.admno})`;
                            resultsDiv.innerHTML = '';
                        });
                    });
                })
                .catch(err => console.error(err));
        }, 300);
    });

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }
</script>
</body>
</html>
<?php renderFooter(); ?>