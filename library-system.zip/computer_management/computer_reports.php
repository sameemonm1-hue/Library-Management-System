<?php
/**
 * Computer Usage Reports
 * Allows filtering and export to Excel/PDF
 */
session_start();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false) {
    // No backdoor – just block access and show violation message
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Access to the system has been blocked for security reasons.</p>
    <hr><p class="text-muted">Please restore the original credit or contact your system administrator.</p></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();

// Filter parameters
$from_date = $_GET['from_date'] ?? date('Y-m-01');
$to_date = $_GET['to_date'] ?? date('Y-m-d');
$member_search = $_GET['member_search'] ?? '';
$computer_id = $_GET['computer_id'] ?? '';
$format = $_GET['format'] ?? '';
$paperSize = $_GET['paper_size'] ?? 'A4';
$orientation = $_GET['orientation'] ?? 'landscape';

// Build query
$sql = "SELECT cs.*, 
               m.admno, m.name as member_name, m.member_category, m.class, m.division,
               c.computer_name, c.location as computer_location
        FROM computer_sessions cs
        LEFT JOIN members m ON cs.member_id = m.id
        LEFT JOIN computers c ON cs.computer_id = c.id
        WHERE 1=1";
$params = [];

if ($from_date) {
    $sql .= " AND DATE(cs.login_time) >= ?";
    $params[] = $from_date;
}
if ($to_date) {
    $sql .= " AND DATE(cs.login_time) <= ?";
    $params[] = $to_date;
}
if ($member_search) {
    $sql .= " AND (m.admno LIKE ? OR m.name LIKE ?)";
    $params[] = "%$member_search%";
    $params[] = "%$member_search%";
}
if ($computer_id) {
    $sql .= " AND cs.computer_id = ?";
    $params[] = $computer_id;
}
$sql .= " ORDER BY cs.login_time DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$sessions = $stmt->fetchAll();

// Calculate statistics
$totalSessions = count($sessions);
$totalMinutes = array_sum(array_column($sessions, 'duration_minutes'));
$totalHours = round($totalMinutes / 60, 1);
$avgMinutes = $totalSessions > 0 ? round($totalMinutes / $totalSessions, 1) : 0;

// Get computers list for filter dropdown
$computers = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();

// ========== HELPER FUNCTIONS FOR EXPORTS ==========

function getInstitutionName() {
    $institution = getInstitution();
    return $institution['name'] ?? 'Library';
}

function getExcelHeader($institutionName, $title, $fromDate, $toDate, $extraFilters = []) {
    $html = '<center>';
    $html .= '<h2>' . htmlspecialchars($institutionName) . '</h2>';
    $html .= '<h3>' . htmlspecialchars($title) . '</h3>';
    $html .= '<p><b>Period:</b> ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</p>';
    foreach ($extraFilters as $label => $value) {
        if ($value) {
            $html .= '<p><b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . '</p>';
        }
    }
    $html .= '<p><b>Generated:</b> ' . date('Y-m-d H:i:s') . '</p><hr></center>';
    return $html;
}

function getPdfHeader($institutionName, $title, $fromDate = null, $toDate = null, $extraFilters = []) {
    $leftHtml = '<span style="font-size:28px;">📚</span>';
    $rightHtml = '<span style="font-size:28px;">🏛️</span>';
    
    $filterHtml = '';
    if (!empty($extraFilters)) {
        $filterHtml = '<div style="margin-top:5px; font-size:10px;">';
        foreach ($extraFilters as $label => $value) {
            if ($label !== 'Period') {
                $filterHtml .= '<b>' . htmlspecialchars($label) . ':</b> ' . htmlspecialchars($value) . ' &nbsp; ';
            }
        }
        $filterHtml .= '</div>';
    }
    
    $periodHtml = '';
    if ($fromDate && $toDate && ($title === 'Circulation Report' || $title === 'Entry/Exit Report')) {
        $periodHtml = '<div style="font-size:10px; margin:3px 0;">Period: ' . formatDate($fromDate) . ' to ' . formatDate($toDate) . '</div>';
    }
    
    // Use a simple table to ensure left, center, right stay on one line
    return '<table style="width:100%; border-collapse:collapse; margin-bottom:15px;">
        <tr>
            <td style="width:80px; text-align:left; vertical-align:middle; border:none;">' . $leftHtml . '</td>
            <td style="text-align:center; vertical-align:middle; border:none;">
                <div style="font-size:16px; font-weight:bold;">' . htmlspecialchars($institutionName) . '</div>
                <div style="font-size:14px; font-weight:bold; margin:3px 0; color:#1e3c72;">' . htmlspecialchars($title) . '</div>
                ' . $periodHtml . '
                ' . $filterHtml . '
                <div style="font-size:9px; color:#555;">Generated: ' . date('Y-m-d H:i:s') . '</div>
            </td>
            <td style="width:80px; text-align:right; vertical-align:middle; border:none;">' . $rightHtml . '</td>
        </tr>
    </table>';
}

function getReportFooter() {
    return '<div style="margin-top:15px; text-align:center; font-size:9px; color:#777;">This is a system generated report.</div>';
}

// Handle export
if ($format === 'excel' || $format === 'pdf') {
    $institutionName = getInstitutionName();
    $computerName = '';
    if ($computer_id) {
        foreach ($computers as $c) {
            if ($c['id'] == $computer_id) {
                $computerName = $c['computer_name'];
                break;
            }
        }
    }
    $filters = [
        'Member' => $member_search ?: 'All',
        'Computer' => $computerName ?: 'All'
    ];
    
    // Build the data table HTML – ensure proper table structure
    $tableHtml = '';
    if (!empty($sessions)) {
        $tableHtml .= '<thead><tr>';
        $tableHtml .= '<th>Sl No</th><th>Member Name</th><th>Adm No</th><th>Category</th><th>Class/Dept</th><th>Div/Course</th><th>Computer</th><th>Login Time</th><th>Logout Time</th><th>Duration (min)</th>';
        $tableHtml .= '</thead><tbody>';
        $sn = 1;
        foreach ($sessions as $s) {
            $tableHtml .= '<tr>';
            $tableHtml .= '<td>' . $sn++ . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['member_name'] ?? 'Unknown') . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['admno'] ?? '-') . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['member_category'] ?? '-') . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['class'] ?? '-') . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['division'] ?? '-') . '</td>';
            $tableHtml .= '<td>' . htmlspecialchars($s['computer_name'] ?? '-') . '</td>';
            $tableHtml .= '<td>' . date('d-m-Y H:i', strtotime($s['login_time'])) . '</td>';
            $tableHtml .= '<td>' . ($s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : 'Active') . '</td>';
            $tableHtml .= '<td>' . ($s['duration_minutes'] ?? '-') . '</td>';
            $tableHtml .= '</tr>';
        }
        $tableHtml .= '</tbody>';
    } else {
        $tableHtml .= '<tbody><tr><td colspan="10" align="center">No sessions found</td></tr></tbody>';
    }
    
    // Wrap the table in a proper <table> tag
    $dataTable = '<table style="width:100%; border-collapse:collapse;">' . $tableHtml . '</table>';
    
    $summary = '<p align="center"><strong>Summary:</strong> Total Sessions: ' . $totalSessions . ' | Total Usage: ' . $totalHours . ' hrs | Avg Duration: ' . $avgMinutes . ' min</p>';
    
    if ($format === 'excel') {
        $html = '<!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"><title>Computer Usage Report</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h2, h3, p { text-align: center; }
            table { margin: 0 auto; border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 6px; text-align: left; }
            th { background: #1e3c72; color: white; }
        </style>
        </head>
        <body>';
        $html .= getExcelHeader($institutionName, 'Computer Usage Report', $from_date, $to_date, $filters);
        $html .= $dataTable;
        $html .= $summary;
        $html .= '<p align="center">This is a system generated report.</p>';
        $html .= '</body></html>';
        
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="computer_usage_report_' . date('Y-m-d') . '.xls"');
        echo $html;
        exit;
        
    } elseif ($format === 'pdf') {
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Computer Usage Report</title>
            <style>
                body { font-family: DejaVu Sans, sans-serif; font-size: 11px; margin: 20px; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; }
                th, td { border: 1px solid #ddd; padding: 5px; text-align: left; vertical-align: top; }
                th { background: #1e3c72; color: white; }
            </style>
        </head>
        <body>';
        $html .= getPdfHeader($institutionName, 'Computer Usage Report', $from_date, $to_date, $filters);
        $html .= $dataTable;
        $html .= $summary;
        $html .= getReportFooter();
        $html .= '</body></html>';
        
        generatePdfFromHtml($html, 'computer_usage_report_' . date('Y-m-d') . '.pdf', $orientation, $paperSize);
        exit;
    }
}

// ========== ON‑SCREEN DISPLAY ==========
renderHeader('Computer Usage Report');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-desktop"></i> Computer Usage Report</h2>
        <div>
            <a href="index.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            <a href="../index.php" class="btn btn-secondary"><i class="fas fa-home"></i> Back to Home</a>
        </div>
    </div>

    <!-- Filter Form -->
    <div class="card mb-4">
        <div class="card-header bg-white fw-bold">
            <i class="fas fa-filter"></i> Filter Reports
        </div>
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label class="form-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" value="<?= htmlspecialchars($from_date) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" value="<?= htmlspecialchars($to_date) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Member (Adm No / Name)</label>
                    <input type="text" name="member_search" class="form-control" value="<?= htmlspecialchars($member_search) ?>" placeholder="Search...">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Computer</label>
                    <select name="computer_id" class="form-select">
                        <option value="">All Computers</option>
                        <?php foreach ($computers as $comp): ?>
                            <option value="<?= $comp['id'] ?>" <?= $computer_id == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Paper Size (PDF)</label>
                    <select name="paper_size" class="form-select">
                        <option value="A4" <?= $paperSize=='A4'?'selected':''?>>A4</option>
                        <option value="Letter" <?= $paperSize=='Letter'?'selected':''?>>Letter</option>
                        <option value="Legal" <?= $paperSize=='Legal'?'selected':''?>>Legal</option>
                        <option value="A3" <?= $paperSize=='A3'?'selected':''?>>A3</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
                    <a href="?format=excel&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&member_search=<?= urlencode($member_search) ?>&computer_id=<?= urlencode($computer_id) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-success"><i class="fas fa-file-excel"></i> Export Excel</a>
                    <a href="?format=pdf&from_date=<?= urlencode($from_date) ?>&to_date=<?= urlencode($to_date) ?>&member_search=<?= urlencode($member_search) ?>&computer_id=<?= urlencode($computer_id) ?>&paper_size=<?= $paperSize ?>&orientation=<?= $orientation ?>" class="btn btn-danger"><i class="fas fa-file-pdf"></i> Export PDF</a>
                    <button type="button" onclick="window.print()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
                    <a href="computer_reports.php" class="btn btn-outline-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Report Table -->
    <div class="card">
        <div class="card-header bg-white fw-bold"><i class="fas fa-table"></i> Session Details</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Sl No</th>
                            <th>Member Name</th>
                            <th>Adm No</th>
                            <th>Category</th>
                            <th>Class/Dept</th>
                            <th>Div/Course</th>
                            <th>Computer</th>
                            <th>Login Time</th>
                            <th>Logout Time</th>
                            <th>Duration (min)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($sessions)): ?>
                            <tr><td colspan="10" class="text-center text-muted py-4">No sessions found for selected filters.</td></tr>
                        <?php else: ?>
                            <?php $sn = 1; foreach ($sessions as $s): ?>
                            <tr>
                                <td><?= $sn++ ?></td>
                                <td><?= htmlspecialchars($s['member_name'] ?? 'Unknown') ?><br><small class="text-muted"><?= htmlspecialchars($s['member_category'] ?? '-') ?></small></td>
                                <td><?= htmlspecialchars($s['admno'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['member_category'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['class'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($s['division'] ?? '-') ?></td>
                                <td><strong><?= htmlspecialchars($s['computer_name'] ?? '-') ?></strong><br><small><?= htmlspecialchars($s['computer_location'] ?? '') ?></small></td>
                                <td><?= date('d-m-Y H:i', strtotime($s['login_time'])) ?></td>
                                <td><?= $s['logout_time'] ? date('d-m-Y H:i', strtotime($s['logout_time'])) : '<span class="badge bg-warning">Active</span>' ?></td>
                                <td><?= $s['duration_minutes'] ?? '-' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td colspan="9" class="text-end">Total Sessions: <?= $totalSessions ?> | Total Minutes: <?= $totalMinutes ?></td>
                            <td><?= $totalMinutes ?> min</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<?php renderFooter(); ?>