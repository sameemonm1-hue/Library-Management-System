<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();

// Update policies
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_policies'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: computer_policies.php");
        exit;
    }
    try {
        foreach ($_POST['policy'] as $id => $data) {
            $stmt = $db->prepare("UPDATE computer_policies SET max_minutes_per_day=?, max_minutes_per_week=?, max_sessions_per_week=?, require_attendance=?, weekly_attendance_required=? WHERE id=?");
            $stmt->execute([
                $data['max_minutes_per_day'],
                $data['max_minutes_per_week'],
                $data['max_sessions_per_week'],
                isset($data['require_attendance']) ? 1 : 0,
                $data['weekly_attendance_required'],
                $id
            ]);
        }
        showToast("Policies updated", "success");
        logActivity($_SESSION['username'], 'COMPUTER_POLICY_UPDATE', "Updated computer access policies");
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header("Location: computer_policies.php");
        exit;
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

$policies = $db->query("SELECT * FROM computer_policies ORDER BY user_role")->fetchAll();

// If no policies exist, insert defaults
if (empty($policies)) {
    $defaults = [
        ['student', 60, 240, 3, 1, 1],
        ['teacher', 120, 480, 10, 0, 0],
        ['staff', 90, 360, 5, 1, 1],
        ['visitor', 30, 120, 2, 0, 0]
    ];
    $ins = $db->prepare("INSERT INTO computer_policies (user_role, max_minutes_per_day, max_minutes_per_week, max_sessions_per_week, require_attendance, weekly_attendance_required) VALUES (?,?,?,?,?,?)");
    foreach ($defaults as $d) {
        $ins->execute($d);
    }
    header("Location: computer_policies.php");
    exit;
}

renderHeader('Computer Policies');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-sliders-h"></i> Computer Usage Policies</h2>
        <a href="manage_computers.php" class="btn btn-secondary"><i class="fas fa-desktop"></i> Manage Computers</a>
    </div>

    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        <div class="card">
            <div class="card-header"><i class="fas fa-gavel"></i> Usage Limits per Role</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Role</th>
                                <th>Max Minutes/Day</th>
                                <th>Max Minutes/Week</th>
                                <th>Max Sessions/Week</th>
                                <th>Require Attendance?</th>
                                <th>Weekly Attendance Required (# sessions)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($policies as $p): ?>
                            <tr>
                                <td><?= ucfirst($p['user_role']) ?><input type="hidden" name="policy[<?= $p['id'] ?>][role]" value="<?= $p['user_role'] ?>"></td>
                                <td><input type="number" name="policy[<?= $p['id'] ?>][max_minutes_per_day]" class="form-control" value="<?= $p['max_minutes_per_day'] ?>" min="0"></td>
                                <td><input type="number" name="policy[<?= $p['id'] ?>][max_minutes_per_week]" class="form-control" value="<?= $p['max_minutes_per_week'] ?>" min="0"></td>
                                <td><input type="number" name="policy[<?= $p['id'] ?>][max_sessions_per_week]" class="form-control" value="<?= $p['max_sessions_per_week'] ?>" min="0"></td>
                                <td class="text-center"><input type="checkbox" name="policy[<?= $p['id'] ?>][require_attendance]" value="1" <?= $p['require_attendance'] ? 'checked' : '' ?>></td>
                                <td><input type="number" name="policy[<?= $p['id'] ?>][weekly_attendance_required]" class="form-control" value="<?= $p['weekly_attendance_required'] ?>" min="0"></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <button type="submit" name="update_policies" class="btn btn-primary mt-3"><i class="fas fa-save"></i> Save Policies</button>
            </div>
        </div>
    </form>
</div>
<?php renderFooter(); ?>