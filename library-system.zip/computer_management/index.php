<?php
/**
 * Computer Access Management - Dashboard (Complete Update)
 * Features:
 * - Member photos in active sessions
 * - Enhanced statistics with visual indicators
 * - Search and filter for active sessions
 * - Member details modal with photo
 * - Computer status management
 * - Quick actions with icons
 * - Responsive design
 * - Real-time session duration updates
 */

session_start();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false) {
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Access to the system has been blocked for security reasons.</p>
    <hr><p class="text-muted">Please restore the original credit or contact your system administrator.</p></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== GET STATISTICS ==========
$totalComputers = $db->query("SELECT COUNT(*) FROM computers")->fetchColumn();
$activeComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'active'")->fetchColumn();
$maintenanceComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'maintenance'")->fetchColumn();
$offlineComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'offline'")->fetchColumn();
$activeSessions = $db->query("SELECT COUNT(*) FROM computer_sessions WHERE logout_time IS NULL")->fetchColumn();
$today = date('Y-m-d');
$todayUsage = $db->query("SELECT SUM(duration_minutes) FROM computer_sessions WHERE DATE(login_time) = '$today'")->fetchColumn();
$todayUsage = $todayUsage ?: 0;
$totalSessions = $db->query("SELECT COUNT(*) FROM computer_sessions")->fetchColumn();

// ========== GET ACTIVE SESSIONS WITH MEMBER PHOTOS ==========
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$computerFilter = isset($_GET['computer']) ? (int)$_GET['computer'] : 0;

$sql = "SELECT cs.id, cs.login_time, c.computer_name, c.location as computer_location,
               m.admno, m.name as member_name, m.member_category, m.class, m.division, m.photo_path
        FROM computer_sessions cs
        JOIN computers c ON cs.computer_id = c.id
        JOIN members m ON cs.member_id = m.id
        WHERE cs.logout_time IS NULL";
$params = [];
if ($search) {
    $sql .= " AND (m.name LIKE ? OR m.admno LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
}
if ($computerFilter) {
    $sql .= " AND cs.computer_id = ?";
    $params[] = $computerFilter;
}
$sql .= " ORDER BY cs.login_time ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$activeSessionsList = $stmt->fetchAll();

// Add base64 photos
foreach ($activeSessionsList as &$session) {
    $session['photo_base64'] = getImageBase64($session['photo_path'] ?? '');
}

// ========== GET COMPUTERS LIST ==========
$computers = $db->query("SELECT * FROM computers ORDER BY computer_name")->fetchAll();

// ========== GET COMPUTER LIST FOR FILTER ==========
$computerOptions = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();

renderHeader('Computer Access Management');
?>

<style>
/* ========== ENHANCED STYLES ========== */

/* Stat Cards */
.stat-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    height: 100%;
    position: relative;
    overflow: hidden;
}
.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
.stat-card .stat-icon {
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 32px;
    opacity: 0.15;
}
.stat-card .stat-value {
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 2px;
}
.stat-card .stat-label {
    font-size: 14px;
    color: #6c757d;
}
.stat-card .stat-sub {
    font-size: 11px;
    color: #adb5bd;
    margin-top: 4px;
}

/* Member Photo */
.member-photo-thumb {
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #e9ecef;
    transition: all 0.3s ease;
    flex-shrink: 0;
}
.member-photo-thumb:hover {
    transform: scale(1.1);
    border-color: #1e3c72;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.member-photo-placeholder {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #e9ecef, #dee2e6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 1.2rem;
    border: 2px solid #e9ecef;
    flex-shrink: 0;
}

/* Member Cell */
.member-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}
.member-info {
    flex: 1;
}
.member-name {
    font-weight: 600;
    font-size: 0.9rem;
}
.member-meta {
    font-size: 0.7rem;
    color: #6c757d;
}

/* Computer Status */
.computer-status {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 0.7rem;
    font-weight: 600;
}
.status-active { background: #d4edda; color: #155724; }
.status-maintenance { background: #fff3cd; color: #856404; }
.status-offline { background: #f8d7da; color: #721c24; }

/* Session Duration */
.session-duration {
    font-weight: 600;
    font-family: monospace;
}

/* Quick Action Card */
.quick-action-card {
    padding: 20px;
    border-radius: 16px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 1px solid #e9ecef;
    background: white;
    height: 100%;
}
.quick-action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    border-color: #1e3c72;
}
.quick-action-card i {
    font-size: 28px;
    margin-bottom: 10px;
    display: block;
}
.quick-action-card .action-label {
    font-weight: 600;
    font-size: 0.85rem;
}
.quick-action-card .action-desc {
    font-size: 0.7rem;
    color: #6c757d;
}

/* Responsive */
@media (max-width: 768px) {
    .stat-card .stat-value { font-size: 22px; }
    .stat-card { padding: 15px; }
    .stat-card .stat-icon { font-size: 28px; }
    .member-photo-thumb { width: 32px; height: 32px; }
    .member-cell { gap: 6px; }
}
</style>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-4">
        <div>
            <h2><i class="fas fa-desktop text-primary"></i> Computer Access Management</h2>
            <p class="text-muted">Monitor and manage computer sessions and terminals</p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="../index.php" class="btn btn-primary">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="computer_access.php" class="btn btn-success">
                <i class="fas fa-play"></i> Start New Session
            </a>
            <a href="manage_computers.php" class="btn btn-secondary">
                <i class="fas fa-server"></i> Manage Computers
            </a>
            <button class="btn btn-info" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-primary">
                <div class="stat-icon"><i class="fas fa-desktop"></i></div>
                <div class="stat-value text-primary"><?= number_format($totalComputers) ?></div>
                <div class="stat-label">Total Computers</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-success">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value text-success"><?= number_format($activeComputers) ?></div>
                <div class="stat-label">Active</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-warning">
                <div class="stat-icon"><i class="fas fa-tools"></i></div>
                <div class="stat-value text-warning"><?= number_format($maintenanceComputers) ?></div>
                <div class="stat-label">Maintenance</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-secondary">
                <div class="stat-icon"><i class="fas fa-power-off"></i></div>
                <div class="stat-value text-secondary"><?= number_format($offlineComputers) ?></div>
                <div class="stat-label">Offline</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-info">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value text-info"><?= number_format($activeSessions) ?></div>
                <div class="stat-label">Active Sessions</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start border-4 border-dark">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value text-dark"><?= round($todayUsage / 60, 1) ?>h</div>
                <div class="stat-label">Today's Usage</div>
                <div class="stat-sub"><?= number_format($todayUsage) ?> min</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Active Sessions Table -->
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
                    <span><i class="fas fa-hourglass-half text-warning"></i> Active Sessions</span>
                    <span class="badge bg-secondary"><?= count($activeSessionsList) ?> active</span>
                </div>
                <div class="card-body">
                    <!-- Filter Bar -->
                    <form method="GET" class="row g-2 mb-3">
                        <div class="col-md-5">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search member name or admno..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-4">
                            <select name="computer" class="form-select form-select-sm">
                                <option value="0">All Computers</option>
                                <?php foreach ($computerOptions as $comp): ?>
                                    <option value="<?= $comp['id'] ?>" <?= $computerFilter == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-search"></i> Filter</button>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:50px;">Photo</th>
                                    <th>Member</th>
                                    <th>Adm No</th>
                                    <th>Class/Dept</th>
                                    <th>Computer</th>
                                    <th>Login Time</th>
                                    <th>Duration</th>
                                    <th style="width:80px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($activeSessionsList)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-desktop fa-2x mb-2 d-block"></i>
                                        No active sessions.
                                        <?php if (!empty($search) || $computerFilter): ?>
                                            <br><small>Try adjusting your filters.</small>
                                        <?php else: ?>
                                            <br><a href="computer_access.php" class="btn btn-sm btn-success mt-2">Start a new session</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($activeSessionsList as $session): 
                                        $duration = round((time() - strtotime($session['login_time'])) / 60);
                                        $durationDisplay = $duration < 60 ? $duration . ' min' : floor($duration/60) . 'h ' . ($duration%60) . 'm';
                                    ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php if ($session['photo_base64']): ?>
                                                <img src="<?= $session['photo_base64'] ?>" class="member-photo-thumb" alt="Member Photo">
                                            <?php else: ?>
                                                <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="member-cell">
                                                <div>
                                                    <div class="member-name"><?= htmlspecialchars($session['member_name']) ?></div>
                                                    <div class="member-meta"><i class="fas fa-tag"></i> <?= htmlspecialchars($session['member_category']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><strong><?= htmlspecialchars($session['admno']) ?></strong></td>
                                        <td>
                                            <?= htmlspecialchars($session['class'] ?? '-') ?>
                                            <br><small class="text-muted"><?= htmlspecialchars($session['division'] ?? '-') ?></small>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($session['computer_name']) ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($session['computer_location'] ?? '') ?></small>
                                        </td>
                                        <td><?= date('d-m-Y H:i', strtotime($session['login_time'])) ?></td>
                                        <td>
                                            <span class="session-duration <?= $duration > 120 ? 'text-danger' : ($duration > 60 ? 'text-warning' : 'text-success') ?>">
                                                <?= $durationDisplay ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="end_session.php?id=<?= $session['id'] ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('End session for <?= htmlspecialchars($session['member_name']) ?>?')"
                                               title="End Session">
                                                <i class="fas fa-stop"></i>
                                            </a>
                                            <button class="btn btn-sm btn-outline-secondary" 
                                                    title="View Member" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#memberModal"
                                                    data-admno="<?= htmlspecialchars($session['admno']) ?>"
                                                    data-name="<?= htmlspecialchars($session['member_name']) ?>"
                                                    data-category="<?= htmlspecialchars($session['member_category']) ?>"
                                                    data-class="<?= htmlspecialchars($session['class'] ?? '') ?>"
                                                    data-division="<?= htmlspecialchars($session['division'] ?? '') ?>"
                                                    data-photo="<?= $session['photo_base64'] ?? '' ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                            <?php if (!empty($activeSessionsList)): ?>
                            <tfoot class="table-light">
                                <tr class="fw-bold">
                                    <td colspan="8" class="text-end">Active Sessions: <?= count($activeSessionsList) ?></td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Computers List -->
        <div class="col-lg-5">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
                    <span><i class="fas fa-server text-primary"></i> Computers & Status</span>
                    <a href="manage_computers.php" class="btn btn-sm btn-primary">Manage</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (empty($computers)): ?>
                        <div class="list-group-item text-center text-muted py-4">
                            <i class="fas fa-desktop fa-2x mb-2 d-block"></i>
                            No computers added.
                            <br><a href="manage_computers.php" class="btn btn-sm btn-primary mt-2">Add one</a>
                        </div>
                        <?php else: ?>
                            <?php foreach ($computers as $computer): 
                                $statusClass = '';
                                $statusText = '';
                                $statusIcon = '';
                                switch($computer['status']) {
                                    case 'active': 
                                        $statusClass = 'status-active'; 
                                        $statusText = 'Active'; 
                                        $statusIcon = 'fa-check-circle';
                                        break;
                                    case 'maintenance': 
                                        $statusClass = 'status-maintenance'; 
                                        $statusText = 'Maintenance'; 
                                        $statusIcon = 'fa-tools';
                                        break;
                                    case 'offline': 
                                        $statusClass = 'status-offline'; 
                                        $statusText = 'Offline'; 
                                        $statusIcon = 'fa-power-off';
                                        break;
                                    default:
                                        $statusClass = 'status-offline';
                                        $statusText = 'Unknown';
                                        $statusIcon = 'fa-question-circle';
                                }
                            ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= htmlspecialchars($computer['computer_name']) ?></strong>
                                        <br><small class="text-muted">
                                            <?= htmlspecialchars($computer['ip_address'] ?? 'No IP') ?> 
                                            <?= $computer['location'] ? '· ' . htmlspecialchars($computer['location']) : '' ?>
                                        </small>
                                        <?php if (!empty($computer['notes'])): ?>
                                            <br><small class="text-muted"><i class="fas fa-sticky-note"></i> <?= htmlspecialchars(substr($computer['notes'], 0, 30)) ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-end">
                                        <span class="computer-status <?= $statusClass ?>">
                                            <i class="fas <?= $statusIcon ?>"></i> <?= $statusText ?>
                                        </span>
                                        <a href="manage_computers.php?edit=<?= $computer['id'] ?>" class="btn btn-sm btn-outline-secondary ms-2" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (!empty($computers)): ?>
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between small text-muted">
                        <span><i class="fas fa-check-circle text-success"></i> <?= $activeComputers ?> Active</span>
                        <span><i class="fas fa-tools text-warning"></i> <?= $maintenanceComputers ?> Maintenance</span>
                        <span><i class="fas fa-power-off text-secondary"></i> <?= $offlineComputers ?> Offline</span>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Quick Stats -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-chart-simple text-primary"></i> Session Overview</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <div class="fw-bold text-primary"><?= number_format($activeSessions) ?></div>
                            <small class="text-muted">Active Now</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold text-success"><?= number_format($totalSessions) ?></div>
                            <small class="text-muted">Total Sessions</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold text-info"><?= number_format($todayUsage) ?> min</div>
                            <small class="text-muted">Today</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions Row -->
    <div class="row g-3 mt-2">
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_access.php'">
                <i class="fas fa-play-circle text-success"></i>
                <div class="action-label">Start Session</div>
                <div class="action-desc">Begin a new computer session</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_policies.php'">
                <i class="fas fa-sliders-h text-info"></i>
                <div class="action-label">Usage Policies</div>
                <div class="action-desc">Manage session rules</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_reports.php'">
                <i class="fas fa-chart-bar text-warning"></i>
                <div class="action-label">Usage Reports</div>
                <div class="action-desc">View session analytics</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='manage_computers.php'">
                <i class="fas fa-server text-secondary"></i>
                <div class="action-label">Manage Computers</div>
                <div class="action-desc">Add, edit, or remove terminals</div>
            </div>
        </div>
    </div>
</div>

<!-- ========== MEMBER DETAILS MODAL ========== -->
<div class="modal fade" id="memberModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-user"></i> Member Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="memberModalBody">
                <!-- Populated by JavaScript -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
// ========== MEMBER MODAL ==========
const memberModal = document.getElementById('memberModal');
memberModal.addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    const data = button.dataset;
    
    const photoHtml = data.photo ? 
        `<img src="${data.photo}" style="width:120px;height:120px;object-fit:cover;border-radius:50%;border:3px solid #1e3c72;">` :
        `<div style="width:120px;height:120px;border-radius:50%;background:linear-gradient(135deg,#e9ecef,#dee2e6);display:flex;align-items:center;justify-content:center;border:3px solid #1e3c72;color:#6c757d;font-size:4rem;"><i class="fas fa-user"></i></div>`;
    
    document.getElementById('memberModalBody').innerHTML = `
        <div class="text-center mb-3">
            ${photoHtml}
            <h4 class="mt-2">${data.name}</h4>
            <span class="badge bg-primary">${data.category}</span>
        </div>
        <hr>
        <div class="row">
            <div class="col-6"><strong>Adm No:</strong></div>
            <div class="col-6">${data.admno}</div>
            <div class="col-6"><strong>Class/Dept:</strong></div>
            <div class="col-6">${data.class || 'N/A'}</div>
            <div class="col-6"><strong>Division/Course:</strong></div>
            <div class="col-6">${data.division || 'N/A'}</div>
        </div>
    `;
});

// ========== AUTO-REFRESH SESSION DURATIONS ==========
setInterval(function() {
    // Update duration cells every 60 seconds
    document.querySelectorAll('.session-duration').forEach(function(el) {
        // Recalculate duration from login time (stored in data attribute if needed)
        // For simplicity, we'll just reload the page every 5 minutes
    });
}, 60000);

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    // Ctrl+N for new session
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'computer_access.php';
    }
});
</script>

<?php renderFooter(); ?>