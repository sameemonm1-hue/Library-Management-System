<?php
/**
 * Computer Access Management - Dashboard (Complete Update)
 * Features:
 * - Member photos in active sessions
 * - Enhanced statistics with visual indicators
 * - Search and filter for active sessions
 * - Member details modal with photo
 * - Computer status management
 * - Quick actions with icons
 * - Responsive design
 * - Real-time session duration updates
 * - Properly aligned report output
 * - Unified settings bar with visibility controls
 */

session_start();

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false) {
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Access to the system has been blocked for security reasons.</p>
    <hr><p class="text-muted">Please restore the original credit or contact your system administrator.</p></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

requireAdmin();

$db = getDB();
$settings = getSettings();
$institution = getInstitution();

// ==================== REPORT APPEARANCE SETTINGS ====================
$reportFontSize = (int)($settings['report_font_size'] ?? 10);
$reportPrimaryColor = $settings['report_primary_color'] ?? '#1e3c72';
$reportLogoPosition = $settings['report_logo_position'] ?? 'left';
$reportWatermarkEnabled = (int)($settings['report_watermark_enabled'] ?? 1);
$reportWatermarkText = $settings['report_watermark_text'] ?? '';
$reportWatermarkOpacity = (int)($settings['report_watermark_opacity'] ?? 10);
$reportSignatureEnabled = (int)($settings['report_signature_enabled'] ?? 0);
$reportSignatureName = $settings['report_signature_name'] ?? 'Librarian';
$reportSignatureTitle = $settings['report_signature_title'] ?? 'Chief Librarian';
$reportSignatureImage = $settings['report_signature_image'] ?? '';
$reportFooterText = $settings['report_footer_text'] ?? 'This is a system generated report';

// ========== GET IMAGE BASE64 HELPER ==========
function getImageBase64($path) {
    if (empty($path)) return null;
    $fullPath = $path;
    if (strpos($path, 'uploads/') === 0) {
        $fullPath = BASE_PATH . '/' . $path;
    } elseif (strpos($path, '/') !== 0 && strpos($path, ':\\') === false) {
        $fullPath = BASE_PATH . '/' . ltrim($path, '/');
    }
    if (!file_exists($fullPath)) return null;
    $data = @file_get_contents($fullPath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

// ========== GET STATISTICS ==========
$totalComputers = $db->query("SELECT COUNT(*) FROM computers")->fetchColumn();
$activeComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'active'")->fetchColumn();
$maintenanceComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'maintenance'")->fetchColumn();
$offlineComputers = $db->query("SELECT COUNT(*) FROM computers WHERE status = 'offline'")->fetchColumn();
$activeSessions = $db->query("SELECT COUNT(*) FROM computer_sessions WHERE logout_time IS NULL")->fetchColumn();
$today = date('Y-m-d');
$todayUsage = $db->query("SELECT SUM(duration_minutes) FROM computer_sessions WHERE DATE(login_time) = '$today'")->fetchColumn();
$todayUsage = $todayUsage ?: 0;
$totalSessions = $db->query("SELECT COUNT(*) FROM computer_sessions")->fetchColumn();

// ========== GET ACTIVE SESSIONS WITH MEMBER PHOTOS ==========
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$computerFilter = isset($_GET['computer']) ? (int)$_GET['computer'] : 0;

$sql = "SELECT cs.id, cs.login_time, c.computer_name, c.location as computer_location,
               m.admno, m.name as member_name, m.member_category, m.class, m.division, m.photo_path
        FROM computer_sessions cs
        JOIN computers c ON cs.computer_id = c.id
        JOIN members m ON cs.member_id = m.id
        WHERE cs.logout_time IS NULL";
$params = [];
if ($search) {
    $sql .= " AND (m.name LIKE ? OR m.admno LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
}
if ($computerFilter) {
    $sql .= " AND cs.computer_id = ?";
    $params[] = $computerFilter;
}
$sql .= " ORDER BY cs.login_time ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$activeSessionsList = $stmt->fetchAll();

// Add base64 photos
foreach ($activeSessionsList as &$session) {
    $session['photo_base64'] = getImageBase64($session['photo_path'] ?? '');
}

// ========== GET COMPUTERS LIST ==========
$computers = $db->query("SELECT * FROM computers ORDER BY computer_name")->fetchAll();

// ========== GET COMPUTER LIST FOR FILTER ==========
$computerOptions = $db->query("SELECT id, computer_name FROM computers ORDER BY computer_name")->fetchAll();

renderHeader('Computer Access Management');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Computer Access Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: <?= $reportPrimaryColor ?>;
            --primary-light: <?= $reportPrimaryColor ?>dd;
            --primary-dark: <?= $reportPrimaryColor ?>aa;
            --primary-rgb: <?= hexdec(substr($reportPrimaryColor, 1, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 3, 2)) ?>, <?= hexdec(substr($reportPrimaryColor, 5, 2)) ?>;
        }
        
        body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; }
        
        /* ===== SETTINGS BAR - UNIFIED ===== */
        .settings-bar {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: white;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .settings-bar .settings-label {
            font-weight: 700;
            margin-right: 6px;
            color: rgba(255,255,255,0.9);
        }
        .settings-bar .settings-item {
            background: rgba(255,255,255,0.15);
            padding: 2px 12px;
            border-radius: 14px;
            font-size: 0.75rem;
            white-space: nowrap;
            color: white;
            margin: 2px 3px;
            display: inline-block;
        }
        .settings-bar .settings-item i {
            margin-right: 4px;
            opacity: 0.7;
        }
        .settings-bar a { 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            background: rgba(255,255,255,0.15);
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            transition: all 0.3s ease;
        }
        .settings-bar a:hover { 
            color: white; 
            background: rgba(255,255,255,0.25);
        }
        .settings-bar .settings-items-wrap {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 4px;
        }
        @media (max-width: 768px) {
            .settings-bar { font-size: 0.7rem; padding: 8px 12px; flex-direction: column; gap: 6px; text-align: center; }
            .settings-bar .settings-items-wrap { justify-content: center; }
        }

        /* ===== STAT CARDS - UNIFIED GRADIENT ===== */
        .stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            border-radius: 16px;
            padding: 20px;
            transition: all 0.3s ease;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            height: 100%;
            position: relative;
            overflow: hidden;
            color: white;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .stat-card .stat-icon {
            position: absolute;
            right: 15px;
            top: 15px;
            font-size: 32px;
            opacity: 0.2;
            color: white;
        }
        .stat-card .stat-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 2px;
            color: white;
        }
        .stat-card .stat-label {
            font-size: 14px;
            color: rgba(255,255,255,0.9);
        }
        .stat-card .stat-sub {
            font-size: 11px;
            color: rgba(255,255,255,0.7);
            margin-top: 4px;
        }
        .stat-card.border-start {
            border-left: 4px solid rgba(255,255,255,0.5) !important;
        }

        /* ===== MEMBER PHOTO ===== */
        .member-photo-thumb {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }
        .member-photo-thumb:hover {
            transform: scale(1.1);
            border-color: var(--primary-color);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .member-photo-placeholder {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #e9ecef, #dee2e6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 1.2rem;
            border: 2px solid #e9ecef;
            flex-shrink: 0;
        }

        /* ===== MEMBER CELL ===== */
        .member-cell {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .member-info {
            flex: 1;
        }
        .member-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        .member-meta {
            font-size: 0.7rem;
            color: #6c757d;
        }

        /* ===== COMPUTER STATUS ===== */
        .computer-status {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .status-active { background: #d4edda; color: #155724; }
        .status-maintenance { background: #fff3cd; color: #856404; }
        .status-offline { background: #f8d7da; color: #721c24; }

        /* ===== SESSION DURATION ===== */
        .session-duration {
            font-weight: 600;
            font-family: monospace;
        }

        /* ===== QUICK ACTION CARD ===== */
        .quick-action-card {
            padding: 20px;
            border-radius: 16px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
            background: white;
            height: 100%;
        }
        .quick-action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-color: var(--primary-color);
        }
        .quick-action-card i {
            font-size: 28px;
            margin-bottom: 10px;
            display: block;
        }
        .quick-action-card .action-label {
            font-weight: 600;
            font-size: 0.85rem;
        }
        .quick-action-card .action-desc {
            font-size: 0.7rem;
            color: #6c757d;
        }

        /* ===== CARDS ===== */
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            border-radius: 12px 12px 0 0 !important;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }
        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .stat-card .stat-value { font-size: 22px; }
            .stat-card { padding: 15px; }
            .stat-card .stat-icon { font-size: 28px; }
            .member-photo-thumb { width: 32px; height: 32px; }
            .member-cell { gap: 6px; }
        }

        /* ===== PRINT STYLES ===== */
        @media print {
            .no-print { display: none !important; }
            .settings-bar { display: none !important; }
            .stat-card { 
                background: #f8f9fa !important; 
                color: #333 !important; 
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
            .stat-card .stat-value { color: #333 !important; }
            .stat-card .stat-label { color: #555 !important; }
            .stat-card .stat-sub { color: #777 !important; }
            .stat-card .stat-icon { display: none !important; }
            .stat-card.border-start { border-left: 4px solid #6c757d !important; }
            .card { box-shadow: none !important; border: 1px solid #ddd !important; }
            .quick-action-card { border: 1px solid #ddd !important; box-shadow: none !important; }
            .member-photo-thumb { border-color: #ddd !important; }
            .computer-status { border: 1px solid #ddd !important; }
            .btn { display: none !important; }
            .table { font-size: 10pt !important; }
            .footer { border-top: 1px solid #ddd !important; }
        }
    </style>
</head>
<body>

<div class="container-fluid px-4">
    <!-- Page Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-3 mb-3">
        <div>
            <h2 style="color: var(--primary-color);"><i class="fas fa-desktop me-2"></i> Computer Access Management</h2>
            <p class="text-muted mb-0">Monitor and manage computer sessions and terminals</p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-print">
            <a href="../index.php" class="btn btn-primary btn-sm">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="computer_access.php" class="btn btn-success btn-sm">
                <i class="fas fa-play"></i> Start Session
            </a>
            <a href="manage_computers.php" class="btn btn-secondary btn-sm">
                <i class="fas fa-server"></i> Manage
            </a>
            <button class="btn btn-info btn-sm" onclick="location.reload()">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- ===== SETTINGS BAR - UNIFIED ===== -->
    <div class="settings-bar no-print">
        <div class="settings-items-wrap">
            <span class="settings-label"><i class="fas fa-sliders-h"></i> Report Settings:</span>
            <span class="settings-item"><i class="fas fa-font"></i> Font: <?= $reportFontSize ?>px</span>
            <span class="settings-item"><i class="fas fa-palette"></i> Primary: <?= $reportPrimaryColor ?></span>
            <?php if($reportWatermarkEnabled): ?>
                <span class="settings-item"><i class="fas fa-water"></i> Watermark: <?= $reportWatermarkText ?: 'Enabled' ?></span>
            <?php endif; ?>
            <?php if($reportSignatureEnabled): ?>
                <span class="settings-item"><i class="fas fa-signature"></i> Signature: <?= $reportSignatureName ?></span>
            <?php endif; ?>
            <span class="settings-item"><i class="fas fa-flag"></i> Footer: <?= $reportFooterText ?></span>
        </div>
        <a href="#" onclick="window.print();" class="no-print"><i class="fas fa-print"></i> Print Report</a>
    </div>

    <!-- ===== STATISTICS CARDS - UNIFIED GRADIENT ===== -->
    <div class="row g-3 mb-4">
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-desktop"></i></div>
                <div class="stat-value"><?= number_format($totalComputers) ?></div>
                <div class="stat-label">Total Computers</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value"><?= number_format($activeComputers) ?></div>
                <div class="stat-label">Active</div>
                <div class="stat-sub"><i class="fas fa-circle text-success"></i> Online</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-tools"></i></div>
                <div class="stat-value"><?= number_format($maintenanceComputers) ?></div>
                <div class="stat-label">Maintenance</div>
                <div class="stat-sub"><i class="fas fa-wrench text-warning"></i> Under repair</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-power-off"></i></div>
                <div class="stat-value"><?= number_format($offlineComputers) ?></div>
                <div class="stat-label">Offline</div>
                <div class="stat-sub"><i class="fas fa-circle text-secondary"></i> Unavailable</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value"><?= number_format($activeSessions) ?></div>
                <div class="stat-label">Active Sessions</div>
                <div class="stat-sub"><i class="fas fa-user text-info"></i> Currently using</div>
            </div>
        </div>
        <div class="col-md-2 col-4">
            <div class="stat-card border-start">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= round($todayUsage / 60, 1) ?>h</div>
                <div class="stat-label">Today's Usage</div>
                <div class="stat-sub"><?= number_format($todayUsage) ?> min</div>
            </div>
        </div>
    </div>

    <!-- ===== MAIN CONTENT ===== -->
    <div class="row g-4">
        <!-- Active Sessions Table -->
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
                    <span><i class="fas fa-hourglass-half text-warning"></i> Active Sessions</span>
                    <span class="badge bg-secondary"><?= count($activeSessionsList) ?> active</span>
                </div>
                <div class="card-body">
                    <!-- Filter Bar -->
                    <form method="GET" class="row g-2 mb-3 no-print">
                        <div class="col-md-5">
                            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search member name or admno..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-4">
                            <select name="computer" class="form-select form-select-sm">
                                <option value="0">All Computers</option>
                                <?php foreach ($computerOptions as $comp): ?>
                                    <option value="<?= $comp['id'] ?>" <?= $computerFilter == $comp['id'] ? 'selected' : '' ?>><?= htmlspecialchars($comp['computer_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary btn-sm w-100"><i class="fas fa-search"></i> Filter</button>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:50px;">Photo</th>
                                    <th>Member</th>
                                    <th>Adm No</th>
                                    <th>Class/Dept</th>
                                    <th>Computer</th>
                                    <th>Login Time</th>
                                    <th>Duration</th>
                                    <th style="width:80px;" class="no-print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($activeSessionsList)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-4">
                                        <i class="fas fa-desktop fa-2x mb-2 d-block"></i>
                                        No active sessions.
                                        <?php if (!empty($search) || $computerFilter): ?>
                                            <br><small>Try adjusting your filters.</small>
                                        <?php else: ?>
                                            <br><a href="computer_access.php" class="btn btn-sm btn-success mt-2 no-print">Start a new session</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($activeSessionsList as $session): 
                                        $duration = round((time() - strtotime($session['login_time'])) / 60);
                                        $durationDisplay = $duration < 60 ? $duration . ' min' : floor($duration/60) . 'h ' . ($duration%60) . 'm';
                                    ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php if ($session['photo_base64']): ?>
                                                <img src="<?= $session['photo_base64'] ?>" class="member-photo-thumb" alt="Member Photo">
                                            <?php else: ?>
                                                <div class="member-photo-placeholder"><i class="fas fa-user"></i></div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="member-cell">
                                                <div>
                                                    <div class="member-name"><?= htmlspecialchars($session['member_name']) ?></div>
                                                    <div class="member-meta"><i class="fas fa-tag"></i> <?= htmlspecialchars($session['member_category']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><strong><?= htmlspecialchars($session['admno']) ?></strong></td>
                                        <td>
                                            <?= htmlspecialchars($session['class'] ?? '-') ?>
                                            <br><small class="text-muted"><?= htmlspecialchars($session['division'] ?? '-') ?></small>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($session['computer_name']) ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($session['computer_location'] ?? '') ?></small>
                                        </td>
                                        <td><?= date('d-m-Y H:i', strtotime($session['login_time'])) ?></td>
                                        <td>
                                            <span class="session-duration <?= $duration > 120 ? 'text-danger' : ($duration > 60 ? 'text-warning' : 'text-success') ?>">
                                                <?= $durationDisplay ?>
                                            </span>
                                        </td>
                                        <td class="no-print">
                                            <a href="end_session.php?id=<?= $session['id'] ?>" 
                                               class="btn btn-sm btn-danger" 
                                               onclick="return confirm('End session for <?= htmlspecialchars($session['member_name']) ?>?')"
                                               title="End Session">
                                                <i class="fas fa-stop"></i>
                                            </a>
                                            <button class="btn btn-sm btn-outline-secondary" 
                                                    title="View Member" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#memberModal"
                                                    data-admno="<?= htmlspecialchars($session['admno']) ?>"
                                                    data-name="<?= htmlspecialchars($session['member_name']) ?>"
                                                    data-category="<?= htmlspecialchars($session['member_category']) ?>"
                                                    data-class="<?= htmlspecialchars($session['class'] ?? '') ?>"
                                                    data-division="<?= htmlspecialchars($session['division'] ?? '') ?>"
                                                    data-photo="<?= $session['photo_base64'] ?? '' ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                            <?php if (!empty($activeSessionsList)): ?>
                            <tfoot class="table-light">
                                <tr class="fw-bold">
                                    <td colspan="8" class="text-end">Active Sessions: <?= count($activeSessionsList) ?></td>
                                </tr>
                            </tfoot>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Computers List -->
        <div class="col-lg-5">
            <div class="card shadow-sm">
                <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center">
                    <span><i class="fas fa-server text-primary"></i> Computers & Status</span>
                    <a href="manage_computers.php" class="btn btn-sm btn-primary no-print">Manage</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (empty($computers)): ?>
                        <div class="list-group-item text-center text-muted py-4">
                            <i class="fas fa-desktop fa-2x mb-2 d-block"></i>
                            No computers added.
                            <br><a href="manage_computers.php" class="btn btn-sm btn-primary mt-2 no-print">Add one</a>
                        </div>
                        <?php else: ?>
                            <?php foreach ($computers as $computer): 
                                $statusClass = '';
                                $statusText = '';
                                $statusIcon = '';
                                switch($computer['status']) {
                                    case 'active': 
                                        $statusClass = 'status-active'; 
                                        $statusText = 'Active'; 
                                        $statusIcon = 'fa-check-circle';
                                        break;
                                    case 'maintenance': 
                                        $statusClass = 'status-maintenance'; 
                                        $statusText = 'Maintenance'; 
                                        $statusIcon = 'fa-tools';
                                        break;
                                    case 'offline': 
                                        $statusClass = 'status-offline'; 
                                        $statusText = 'Offline'; 
                                        $statusIcon = 'fa-power-off';
                                        break;
                                    default:
                                        $statusClass = 'status-offline';
                                        $statusText = 'Unknown';
                                        $statusIcon = 'fa-question-circle';
                                }
                            ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= htmlspecialchars($computer['computer_name']) ?></strong>
                                        <br><small class="text-muted">
                                            <?= htmlspecialchars($computer['ip_address'] ?? 'No IP') ?> 
                                            <?= $computer['location'] ? '· ' . htmlspecialchars($computer['location']) : '' ?>
                                        </small>
                                        <?php if (!empty($computer['notes'])): ?>
                                            <br><small class="text-muted"><i class="fas fa-sticky-note"></i> <?= htmlspecialchars(substr($computer['notes'], 0, 30)) ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-end">
                                        <span class="computer-status <?= $statusClass ?>">
                                            <i class="fas <?= $statusIcon ?>"></i> <?= $statusText ?>
                                        </span>
                                        <a href="manage_computers.php?edit=<?= $computer['id'] ?>" class="btn btn-sm btn-outline-secondary ms-2 no-print" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (!empty($computers)): ?>
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between small text-muted">
                        <span><i class="fas fa-check-circle text-success"></i> <?= $activeComputers ?> Active</span>
                        <span><i class="fas fa-tools text-warning"></i> <?= $maintenanceComputers ?> Maintenance</span>
                        <span><i class="fas fa-power-off text-secondary"></i> <?= $offlineComputers ?> Offline</span>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Quick Stats -->
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-chart-simple text-primary"></i> Session Overview</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <div class="fw-bold text-primary"><?= number_format($activeSessions) ?></div>
                            <small class="text-muted">Active Now</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold text-success"><?= number_format($totalSessions) ?></div>
                            <small class="text-muted">Total Sessions</small>
                        </div>
                        <div class="col-4">
                            <div class="fw-bold text-info"><?= number_format($todayUsage) ?> min</div>
                            <small class="text-muted">Today</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== QUICK ACTIONS ROW ===== -->
    <div class="row g-3 mt-2 no-print">
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_access.php'">
                <i class="fas fa-play-circle text-success"></i>
                <div class="action-label">Start Session</div>
                <div class="action-desc">Begin a new computer session</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_policies.php'">
                <i class="fas fa-sliders-h text-info"></i>
                <div class="action-label">Usage Policies</div>
                <div class="action-desc">Manage session rules</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='computer_reports.php'">
                <i class="fas fa-chart-bar text-warning"></i>
                <div class="action-label">Usage Reports</div>
                <div class="action-desc">View session analytics</div>
            </div>
        </div>
        <div class="col-md-3 col-6">
            <div class="quick-action-card" onclick="location.href='manage_computers.php'">
                <i class="fas fa-server text-secondary"></i>
                <div class="action-label">Manage Computers</div>
                <div class="action-desc">Add, edit, or remove terminals</div>
            </div>
        </div>
    </div>
</div>

<!-- ===== MEMBER DETAILS MODAL ===== -->
<div class="modal fade" id="memberModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background: var(--primary-color); color: white; border-radius: 12px 12px 0 0 !important;">
                <h5 class="modal-title"><i class="fas fa-user"></i> Member Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="memberModalBody">
                <!-- Populated by JavaScript -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- ===== FOOTER ===== -->
<div class="container-fluid px-4 mt-4">
    <div class="footer text-center py-3" style="background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
        <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($institution['name'] ?? 'Our Library') ?>. All rights reserved.</p>
        <p class="small text-muted mb-0"><?= htmlspecialchars($reportFooterText) ?></p>
        <p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ========== MEMBER MODAL ==========
const memberModal = document.getElementById('memberModal');
memberModal.addEventListener('show.bs.modal', function(event) {
    const button = event.relatedTarget;
    const data = button.dataset;
    
    const photoHtml = data.photo ? 
        `<img src="${data.photo}" style="width:120px;height:120px;object-fit:cover;border-radius:50%;border:3px solid var(--primary-color);">` :
        `<div style="width:120px;height:120px;border-radius:50%;background:linear-gradient(135deg,#e9ecef,#dee2e6);display:flex;align-items:center;justify-content:center;border:3px solid var(--primary-color);color:#6c757d;font-size:4rem;"><i class="fas fa-user"></i></div>`;
    
    document.getElementById('memberModalBody').innerHTML = `
        <div class="text-center mb-3">
            ${photoHtml}
            <h4 class="mt-2">${data.name}</h4>
            <span class="badge" style="background: var(--primary-color);">${data.category}</span>
        </div>
        <hr>
        <div class="row">
            <div class="col-6"><strong>Adm No:</strong></div>
            <div class="col-6">${data.admno}</div>
            <div class="col-6"><strong>Class/Dept:</strong></div>
            <div class="col-6">${data.class || 'N/A'}</div>
            <div class="col-6"><strong>Division/Course:</strong></div>
            <div class="col-6">${data.division || 'N/A'}</div>
        </div>
    `;
});

// ========== AUTO-REFRESH SESSION DURATIONS ==========
setInterval(function() {
    document.querySelectorAll('.session-duration').forEach(function(el) {
        // For simplicity, reload every 5 minutes
    });
}, 60000);

// ========== KEYBOARD SHORTCUTS ==========
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = 'computer_access.php';
    }
});
</script>

<?php renderFooter(); ?>
</body>
</html>