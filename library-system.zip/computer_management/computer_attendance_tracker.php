<?php
/**
 * Run this script weekly (e.g., every Monday) to mark attendance compliance.
 * Can be triggered via cron job or manually.
 */

require_once __DIR__ . '/../config/db.php';
$db = getDB();

$lastWeekStart = date('Y-m-d', strtotime('monday last week'));
$lastWeekEnd = date('Y-m-d', strtotime('sunday last week'));

// Get all policies that require attendance
$policies = $db->query("SELECT user_role, weekly_attendance_required FROM computer_policies WHERE require_attendance = 1")->fetchAll();

foreach ($policies as $pol) {
    $role = $pol['user_role'];
    $required = $pol['weekly_attendance_required'];
    
    // Fix: use member_category instead of category
    $members = $db->prepare("SELECT id FROM members WHERE member_category = ?");
    $members->execute([$role]);
    
    while ($m = $members->fetch()) {
        // Count sessions for the member in the last week
        $sessions = $db->prepare("SELECT COUNT(*) as session_count, SUM(duration_minutes) as total_minutes 
                                  FROM computer_sessions 
                                  WHERE member_id = ? AND login_time BETWEEN ? AND ?");
        $sessions->execute([$m['id'], $lastWeekStart . ' 00:00:00', $lastWeekEnd . ' 23:59:59']);
        $data = $sessions->fetch();
        $count = $data['session_count'] ?? 0;
        $totalMinutes = $data['total_minutes'] ?? 0;
        $compliant = ($count >= $required) ? 1 : 0;
        
        // SQLite does not support ON DUPLICATE KEY UPDATE; use INSERT OR REPLACE
        $stmt = $db->prepare("INSERT OR REPLACE INTO computer_attendance 
                              (member_id, week_start_date, sessions_count, total_minutes, compliant) 
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$m['id'], $lastWeekStart, $count, $totalMinutes, $compliant]);
    }
}

echo "Attendance compliance updated for week $lastWeekStart to $lastWeekEnd\n";
?>