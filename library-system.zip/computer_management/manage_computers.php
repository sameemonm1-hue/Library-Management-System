<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$db = getDB();
$action = $_GET['action'] ?? 'list';
$editComputer = null;

if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM computers WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editComputer = $stmt->fetch();
}

// Add / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        showToast("Invalid security token", "danger");
        header("Location: manage_computers.php");
        exit;
    }
    try {
        if (isset($_POST['add_computer'])) {
            $stmt = $db->prepare("INSERT INTO computers (computer_name, ip_address, location, status, notes) VALUES (?,?,?,?,?)");
            $stmt->execute([
                $_POST['computer_name'],
                $_POST['ip_address'],
                $_POST['location'],
                $_POST['status'],
                $_POST['notes']
            ]);
            showToast("Computer added successfully", "success");
            logActivity($_SESSION['username'], 'COMPUTER_ADD', "Added computer: {$_POST['computer_name']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: manage_computers.php");
            exit;
        }
        elseif (isset($_POST['update_computer'])) {
            $stmt = $db->prepare("UPDATE computers SET computer_name=?, ip_address=?, location=?, status=?, notes=? WHERE id=?");
            $stmt->execute([
                $_POST['computer_name'],
                $_POST['ip_address'],
                $_POST['location'],
                $_POST['status'],
                $_POST['notes'],
                $_POST['id']
            ]);
            showToast("Computer updated", "success");
            logActivity($_SESSION['username'], 'COMPUTER_UPDATE', "Updated computer ID {$_POST['id']}");
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            header("Location: manage_computers.php");
            exit;
        }
    } catch (PDOException $e) {
        showToast("Error: " . $e->getMessage(), "danger");
    }
}

// Delete
if (isset($_GET['delete'])) {
    // Check if computer has active sessions (not logged out)
    $check = $db->prepare("SELECT COUNT(*) FROM computer_sessions WHERE computer_id = ? AND logout_time IS NULL");
    $check->execute([$_GET['delete']]);
    if ($check->fetchColumn() > 0) {
        showToast("Cannot delete – computer has active sessions. End all sessions first.", "warning");
    } else {
        $stmt = $db->prepare("DELETE FROM computers WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        showToast("Computer deleted", "success");
        logActivity($_SESSION['username'], 'COMPUTER_DELETE', "Deleted computer ID {$_GET['delete']}");
    }
    header("Location: manage_computers.php");
    exit;
}

$computers = $db->query("SELECT * FROM computers ORDER BY computer_name")->fetchAll();

renderHeader('Manage Computers');
?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-desktop"></i> Computer Terminals</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addComputerModal">
            <i class="fas fa-plus"></i> Add Computer
        </button>
    </div>

    <div class="card">
        <div class="card-header"><i class="fas fa-list"></i> Computers List</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Name</th><th>IP Address</th><th>Location</th><th>Status</th><th>Notes</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($computers as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['computer_name']) ?></td>
                            <td><?= htmlspecialchars($c['ip_address'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($c['location'] ?? '-') ?></td>
                            <td>
                                <span class="badge bg-<?= $c['status']=='active'?'success':($c['status']=='maintenance'?'warning':'secondary') ?>">
                                    <?= ucfirst($c['status']) ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($c['notes'] ?? '-') ?></td>
                            <td>
                                <a href="?edit=<?= $c['id'] ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                                <a href="?delete=<?= $c['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete computer?')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Computer Modal -->
<div class="modal fade" id="addComputerModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white"><h5>Add Computer</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <div class="mb-2"><label>Computer Name *</label><input type="text" name="computer_name" class="form-control" required></div>
                    <div class="mb-2"><label>IP Address</label><input type="text" name="ip_address" class="form-control" placeholder="192.168.1.100"></div>
                    <div class="mb-2"><label>Location (e.g., Ground Floor)</label><input type="text" name="location" class="form-control"></div>
                    <div class="mb-2"><label>Status</label><select name="status" class="form-select"><option value="active">Active</option><option value="maintenance">Maintenance</option><option value="offline">Offline</option></select></div>
                    <div class="mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" name="add_computer" class="btn btn-primary">Save</button></div>
            </form>
        </div>
    </div>
</div>

<?php if ($editComputer): ?>
<!-- Edit Modal -->
<div class="modal fade show" id="editComputerModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.5)">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning"><h5>Edit Computer</h5><a href="manage_computers.php" class="btn-close"></a></div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $editComputer['id'] ?>">
                    <div class="mb-2"><label>Computer Name *</label><input type="text" name="computer_name" class="form-control" value="<?= htmlspecialchars($editComputer['computer_name']) ?>" required></div>
                    <div class="mb-2"><label>IP Address</label><input type="text" name="ip_address" class="form-control" value="<?= htmlspecialchars($editComputer['ip_address'] ?? '') ?>"></div>
                    <div class="mb-2"><label>Location</label><input type="text" name="location" class="form-control" value="<?= htmlspecialchars($editComputer['location'] ?? '') ?>"></div>
                    <div class="mb-2"><label>Status</label><select name="status" class="form-select"><option value="active" <?= $editComputer['status']=='active'?'selected':'' ?>>Active</option><option value="maintenance" <?= $editComputer['status']=='maintenance'?'selected':'' ?>>Maintenance</option><option value="offline" <?= $editComputer['status']=='offline'?'selected':'' ?>>Offline</option></select></div>
                    <div class="mb-2"><label>Notes</label><textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($editComputer['notes'] ?? '') ?></textarea></div>
                </div>
                <div class="modal-footer"><a href="manage_computers.php" class="btn btn-secondary">Cancel</a><button type="submit" name="update_computer" class="btn btn-primary">Update</button></div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>