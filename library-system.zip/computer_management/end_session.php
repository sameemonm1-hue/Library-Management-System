<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireAdmin();

$id = (int)$_GET['id'];
$db = getDB();

// Update logout time and calculate duration
$stmt = $db->prepare("UPDATE computer_sessions 
                      SET logout_time = datetime('now'), 
                          duration_minutes = (strftime('%s', datetime('now')) - strftime('%s', login_time)) / 60
                      WHERE id = ? AND logout_time IS NULL");
$stmt->execute([$id]);
header("Location: index.php");
exit;
?>