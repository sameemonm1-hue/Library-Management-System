<?php
/**
 * Public Self‑Service Kiosk – Scan ID to IN/OUT (toggle)
 * Enhanced with:
 * - RFID‑like behavior: scanning an issued book exits the borrower.
 * - Unauthorized book exits trigger sound & visual alerts.
 * - Member photos displayed for both ID and book scans.
 * - Webcam capture for book exits (optional).
 * - Container max‑width 1600px, 70/30 split, centered New Arrivals.
 * - Guest entry/exit with default avatar.
 * - Fingerprint icons with animated bounce on Guest buttons.
 */
session_start();

// ==================== INCLUDE CORE ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';

// ========== ENSURE GUEST & VISITOR COLUMNS EXIST ==========
try {
    $dbCheck = getDB();
    $colCheck = $dbCheck->query("PRAGMA table_info(settings)");
    $columns = $colCheck->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('guest_enabled', $columns)) {
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_enabled INT DEFAULT 1");
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_prefix VARCHAR(20) DEFAULT 'GUEST-'");
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_number_padding INT DEFAULT 4");
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_last_reset DATE DEFAULT NULL");
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_daily_counter INT DEFAULT 1");
    }
    $colCheck2 = $dbCheck->query("PRAGMA table_info(settings)");
    $columns2 = $colCheck2->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('guest_daily_counter', $columns2)) {
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_daily_counter INT DEFAULT 1");
    }
    if (!in_array('guest_last_reset', $columns2)) {
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN guest_last_reset DATE DEFAULT NULL");
    }
    if (!in_array('visitor_carousel_type', $columns2)) {
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN visitor_carousel_type TEXT DEFAULT 'cover_flow'");
    }
    if (!in_array('enable_webcam_capture', $columns2)) {
        $dbCheck->exec("ALTER TABLE settings ADD COLUMN enable_webcam_capture INT DEFAULT 0");
    }
} catch (Exception $e) { /* ignore */ }

// ==================== LANGUAGE HANDLING (THREE LANGUAGES) ====================
$available_langs = ['en', 'hi', 'ar'];
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_langs)) {
    $_SESSION['visitor_lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
$lang = $_SESSION['visitor_lang'] ?? 'en';

$translations = [
    'en' => [
        'visitor_log' => 'Library Kiosk',
        'scan_id' => 'Scan your library ID card or enter number',
        'scan_placeholder' => 'Scan barcode here...',
        'purpose_label' => 'Purpose of visit',
        'purpose_reading' => '📚 Reading/Study',
        'purpose_issue_return' => '🔄 Book Issue/Return',
        'purpose_research' => '🔬 Research',
        'purpose_meeting' => '👥 Meeting',
        'purpose_event' => '🎉 Event/Program',
        'purpose_other' => '📝 Other (specify)',
        'custom_purpose_placeholder' => 'Enter custom purpose...',
        'processing' => 'Processing...',
        'please_wait' => 'Please wait 0.5 seconds...',
        'valid_id' => 'Please enter a valid ID (min 2 characters)',
        'entry_recorded' => 'Entry recorded',
        'exit_recorded' => 'Exit recorded',
        'operation_failed' => 'Operation failed',
        'network_error' => 'Network error. Please try again.',
        'live_status' => 'Live Library Status',
        'visitors_today' => 'Visitors Today',
        'currently_inside' => 'Currently Inside',
        'male' => 'Male',
        'female' => 'Female',
        'other' => 'Other',
        'inside_by_category' => 'Inside by Category',
        'none' => 'None',
        'all_rights_reserved' => 'All rights reserved.',
        'designed_by' => 'Designed by',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'guest' => 'Guest',
        'welcome' => 'Welcome',
        'thank_you' => 'Thank You',
        'to_library' => 'to Library',
        'new_arrivals' => 'New Arrivals',
        'popular_ebooks' => 'Popular eBooks',
        'latest_notices' => 'Latest Notices',
        'auto_sliding' => 'Auto‑sliding →',
        'guest_entry' => 'GUEST IN',
        'guest_exit' => 'GUEST OUT',
        'active_guests' => 'Active Guests',
        'guest_entry_success' => 'Guest {num} entered',
        'guest_exit_success' => 'Guest {num} exited',
        'no_active_guests' => 'No active guests',
        'confirm_exit_last' => 'Remove most recent guest?',
        'current_inside_members' => '📌 Currently Inside Members',
        'recent_activity' => '🔄 Recent Activity',
        'purpose_distribution' => '📊 Today\'s Purpose Distribution',
        'member' => 'Member',
        'entry_time' => 'Entry Time',
        'action' => 'Action',
        'purpose' => 'Purpose',
        'just_now' => 'Just now',
        'minutes_ago' => 'minutes ago',
        'hour_ago' => 'hour ago',
        'hours_ago' => 'hours ago',
        'inside_members_empty' => 'No members currently inside.',
        'recent_activity_empty' => 'No recent activity.',
        'digital_hub' => 'Digital Hub',
        'advanced_search' => 'Advanced Search',
        'search_title' => 'Title',
        'search_author' => 'Author',
        'search_keyword' => 'Keyword',
        'search_btn' => 'Search',
        'cancel' => 'Cancel',
        'quote_of_the_day' => 'Quote of the Day',
        'refresh_quote' => 'Refresh Quote',
        'quote_author_unknown' => 'Unknown',
        'library_hours' => 'Library Hours',
        'open_days' => 'Open Days',
        'hours' => 'Hours',
        'lunch_break' => 'Lunch Break',
        'currently_closed' => 'The library is currently closed.',
        'today' => 'Today',
        'current_time' => 'Current Time',
        // Book detection translations
        'book_detected' => '📖 Book detected',
        'book_authorized' => '✅ Book is issued (authorized exit)',
        'book_unauthorized' => '⚠️ Book not issued – potential sneak out!',
        'book_details' => 'Book Details',
        'member_linked' => 'Linked Member',
        'capture_photo' => 'Capturing photo...',
        'photo_captured' => 'Photo captured',
        'scan_book' => 'Scan a book barcode to exit',
        'book_exit_logged' => 'Book exit logged',
        'book_not_found' => 'Book not found in system',
        'exit_triggered' => 'Member exit triggered by book scan',
        'member_not_inside' => 'Member is not currently inside',
        'book_issued_to' => 'Issued to',
        'member_exited' => 'Member exited',
    ],
    'hi' => [
        'visitor_log' => 'लाइब्रेरी कियोस्क',
        'scan_id' => 'अपना लाइब्रेरी आईडी कार्ड स्कैन करें या नंबर डालें',
        'scan_placeholder' => 'बारकोड यहाँ स्कैन करें...',
        'purpose_label' => 'यात्रा का उद्देश्य',
        'purpose_reading' => '📚 पढ़ाई/अध्ययन',
        'purpose_issue_return' => '🔄 पुस्तक जारी/वापसी',
        'purpose_research' => '🔬 शोध',
        'purpose_meeting' => '👥 बैठक',
        'purpose_event' => '🎉 कार्यक्रम/प्रोग्राम',
        'purpose_other' => '📝 अन्य (निर्दिष्ट करें)',
        'custom_purpose_placeholder' => 'अन्य उद्देश्य लिखें...',
        'processing' => 'प्रक्रिया हो रही है...',
        'please_wait' => 'कृपया 0.5 सेकंड प्रतीक्षा करें...',
        'valid_id' => 'कृपया मान्य आईडी दर्ज करें (न्यूनतम 2 अक्षर)',
        'entry_recorded' => 'प्रवेश दर्ज किया गया',
        'exit_recorded' => 'निकास दर्ज किया गया',
        'operation_failed' => 'कार्रवाई विफल',
        'network_error' => 'नेटवर्क त्रुटि। कृपया पुनः प्रयास करें।',
        'live_status' => 'लाइव लाइब्रेरी स्थिति',
        'visitors_today' => 'आज के आगंतुक',
        'currently_inside' => 'वर्तमान में अंदर',
        'male' => 'पुरुष',
        'female' => 'महिला',
        'other' => 'अन्य',
        'inside_by_category' => 'श्रेणी के अनुसार अंदर',
        'none' => 'कोई नहीं',
        'all_rights_reserved' => 'सर्वाधिकार सुरक्षित।',
        'designed_by' => 'द्वारा डिज़ाइन किया गया',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'guest' => 'अतिथि',
        'welcome' => 'स्वागत है',
        'thank_you' => 'धन्यवाद',
        'to_library' => 'पुस्तकालय में',
        'new_arrivals' => 'नई आगमन',
        'popular_ebooks' => 'लोकप्रिय ई-पुस्तकें',
        'latest_notices' => 'नवीनतम सूचनाएँ',
        'auto_sliding' => 'स्वचालित स्लाइडिंग →',
        'guest_entry' => 'अतिथि प्रवेश',
        'guest_exit' => 'अतिथि निकास',
        'active_guests' => 'सक्रिय अतिथि',
        'guest_entry_success' => 'अतिथि {num} प्रवेश किया',
        'guest_exit_success' => 'अतिथि {num} निकास किया',
        'no_active_guests' => 'कोई सक्रिय अतिथि नहीं',
        'confirm_exit_last' => 'नवीनतम अतिथि को निकालें?',
        'current_inside_members' => '📌 वर्तमान में अंदर सदस्य',
        'recent_activity' => '🔄 हाल की गतिविधि',
        'purpose_distribution' => '📊 आज का उद्देश्य वितरण',
        'member' => 'सदस्य',
        'entry_time' => 'प्रवेश समय',
        'action' => 'कार्रवाई',
        'purpose' => 'उद्देश्य',
        'just_now' => 'अभी',
        'minutes_ago' => 'मिनट पहले',
        'hour_ago' => 'घंटा पहले',
        'hours_ago' => 'घंटे पहले',
        'inside_members_empty' => 'वर्तमान में कोई सदस्य अंदर नहीं',
        'recent_activity_empty' => 'कोई हाल की गतिविधि नहीं',
        'digital_hub' => 'डिजिटल हब',
        'advanced_search' => 'उन्नत खोज',
        'search_title' => 'शीर्षक',
        'search_author' => 'लेखक',
        'search_keyword' => 'कीवर्ड',
        'search_btn' => 'खोज',
        'cancel' => 'रद्द करें',
        'quote_of_the_day' => 'दिन का विचार',
        'refresh_quote' => 'उद्धरण ताज़ा करें',
        'quote_author_unknown' => 'अज्ञात',
        'library_hours' => 'पुस्तकालय समय',
        'open_days' => 'खुले दिन',
        'hours' => 'समय',
        'lunch_break' => 'दोपहर का भोजन अवकाश',
        'currently_closed' => 'पुस्तकालय वर्तमान में बंद है',
        'today' => 'आज',
        'current_time' => 'वर्तमान समय',
        'book_detected' => '📖 पुस्तक मिली',
        'book_authorized' => '✅ पुस्तक जारी है (अधिकृत निकास)',
        'book_unauthorized' => '⚠️ पुस्तक जारी नहीं – संभावित चोरी!',
        'book_details' => 'पुस्तक विवरण',
        'member_linked' => 'संबद्ध सदस्य',
        'capture_photo' => 'फोटो खींचा जा रहा...',
        'photo_captured' => 'फोटो ले ली गई',
        'scan_book' => 'निकास के लिए पुस्तक बारकोड स्कैन करें',
        'book_exit_logged' => 'पुस्तक निकास लॉग किया गया',
        'book_not_found' => 'सिस्टम में पुस्तक नहीं मिली',
        'exit_triggered' => 'पुस्तक स्कैन द्वारा सदस्य निकास ट्रिगर किया गया',
        'member_not_inside' => 'सदस्य वर्तमान में अंदर नहीं है',
        'book_issued_to' => 'जारी किसे',
        'member_exited' => 'सदस्य निकास किया',
    ],
    'ar' => [
        'visitor_log' => 'كشك المكتبة',
        'scan_id' => 'امسح بطاقة مكتبتك أو أدخل الرقم',
        'scan_placeholder' => 'امسح الباركود هنا...',
        'purpose_label' => 'الغرض من الزيارة',
        'purpose_reading' => '📚 قراءة/دراسة',
        'purpose_issue_return' => '🔄 إعارة/إرجاع كتاب',
        'purpose_research' => '🔬 بحث',
        'purpose_meeting' => '👥 اجتماع',
        'purpose_event' => '🎉 فعالية/برنامج',
        'purpose_other' => '📝 أخرى (حدد)',
        'custom_purpose_placeholder' => 'أدخل غرضاً آخر...',
        'processing' => 'جاري المعالجة...',
        'please_wait' => 'يرجى الانتظار 0.5 ثانية...',
        'valid_id' => 'يرجى إدخال هوية صالحة (2 حروف على الأقل)',
        'entry_recorded' => 'تم تسجيل الدخول',
        'exit_recorded' => 'تم تسجيل الخروج',
        'operation_failed' => 'فشلت العملية',
        'network_error' => 'خطأ في الشبكة. حاول مرة أخرى.',
        'live_status' => 'حالة المكتبة الحية',
        'visitors_today' => 'زوار اليوم',
        'currently_inside' => 'المتواجدون حالياً',
        'male' => 'ذكر',
        'female' => 'أنثى',
        'other' => 'أخرى',
        'inside_by_category' => 'الداخلون حسب الفئة',
        'none' => 'لا شيء',
        'all_rights_reserved' => 'جميع الحقوق محفوظة.',
        'designed_by' => 'صمم بواسطة',
        'switch_to_arabic' => 'العربية',
        'switch_to_english' => 'English',
        'switch_to_hindi' => 'हिन्दी',
        'guest' => 'زائر',
        'welcome' => 'مرحباً',
        'thank_you' => 'شكراً',
        'to_library' => 'إلى المكتبة',
        'new_arrivals' => 'الوافدون الجدد',
        'popular_ebooks' => 'الكتب الإلكترونية الأكثر شعبية',
        'latest_notices' => 'آخر الإعلانات',
        'auto_sliding' => 'انزلاق تلقائي →',
        'guest_entry' => 'دخول زائر',
        'guest_exit' => 'خروج زائر',
        'active_guests' => 'الزوار النشطون',
        'guest_entry_success' => 'دخل الزائر {num}',
        'guest_exit_success' => 'خرج الزائر {num}',
        'no_active_guests' => 'لا يوجد زوار نشطون',
        'confirm_exit_last' => 'إخراج أحدث زائر؟',
        'current_inside_members' => '📌 الأعضاء المتواجدون حالياً',
        'recent_activity' => '🔄 النشاط الأخير',
        'purpose_distribution' => '📊 توزيع الأغراض اليوم',
        'member' => 'عضو',
        'entry_time' => 'وقت الدخول',
        'action' => 'الإجراء',
        'purpose' => 'الغرض',
        'just_now' => 'الآن',
        'minutes_ago' => 'دقائق مضت',
        'hour_ago' => 'ساعة مضت',
        'hours_ago' => 'ساعات مضت',
        'inside_members_empty' => 'لا يوجد أعضاء حالياً',
        'recent_activity_empty' => 'لا نشاط حديث',
        'digital_hub' => 'المركز الرقمي',
        'advanced_search' => 'بحث متقدم',
        'search_title' => 'العنوان',
        'search_author' => 'المؤلف',
        'search_keyword' => 'كلمة مفتاحية',
        'search_btn' => 'بحث',
        'cancel' => 'إلغاء',
        'quote_of_the_day' => 'اقتباس اليوم',
        'refresh_quote' => 'تحديث الاقتباس',
        'quote_author_unknown' => 'مجهول',
        'library_hours' => 'ساعات المكتبة',
        'open_days' => 'أيام العمل',
        'hours' => 'الساعات',
        'lunch_break' => 'استراحة الغداء',
        'currently_closed' => 'المكتبة مغلقة حالياً',
        'today' => 'اليوم',
        'current_time' => 'الوقت الحالي',
        'book_detected' => '📖 تم اكتشاف كتاب',
        'book_authorized' => '✅ الكتاب مستعار (خروج مصرح)',
        'book_unauthorized' => '⚠️ الكتاب غير مستعار – خروج غير مصرح به!',
        'book_details' => 'تفاصيل الكتاب',
        'member_linked' => 'العضو المرتبط',
        'capture_photo' => 'جاري التقاط الصورة...',
        'photo_captured' => 'تم التقاط الصورة',
        'scan_book' => 'امسح باركود كتاب للخروج',
        'book_exit_logged' => 'تم تسجيل خروج الكتاب',
        'book_not_found' => 'الكتاب غير موجود في النظام',
        'exit_triggered' => 'تم تشغيل خروج العضو بواسطة مسح الكتاب',
        'member_not_inside' => 'العضو ليس متواجداً حالياً',
        'book_issued_to' => 'مستعار بواسطة',
        'member_exited' => 'خرج العضو',
    ]
];

if (!function_exists('__')) {
    function __($key) {
        global $lang, $translations;
        return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
    }
}

function getFirstName($fullName) {
    $parts = explode(' ', trim($fullName));
    return $parts[0] ?? $fullName;
}

// ==================== PROTECTED FOOTER INTEGRITY CHECK ====================
$expectedFooter = '<p class="small mt-2 opacity-75">Designed by <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>';
$currentFile = file_get_contents(__FILE__);
if (strpos($currentFile, $expectedFooter) === false) {
    echo '<!DOCTYPE html><html><head><title>Integrity Check</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head>
    <body class="bg-light"><div class="container mt-5"><div class="card mx-auto" style="max-width:400px"><div class="card-header bg-danger text-white"><h4>System Integrity Violation</h4></div>
    <div class="card-body"><p>The designer credit "Designed by Sameermon" has been removed or altered.</p><p>Access to the system has been blocked for security reasons.</p>
    <hr><p class="text-muted">Please restore the original credit or contact your system administrator.</p></div></div></div></body></html>';
    exit;
}
// ==================== END INTEGRITY CHECK ====================

$db = getDB();
$settings = getSettings();
$institution = getInstitution();
$institutionName = $institution['name'] ?? 'Library';

// ========== VISITOR CUSTOMIZATION SETTINGS ==========
$visitorHeaderLogo = $settings['visitor_header_logo'] ?? '';
$opacHeaderLogo = $settings['opac_header_logo'] ?? '';
$displayHeaderText = !empty($settings['visitor_header_text']) ? $settings['visitor_header_text'] : ($settings['opac_header_text'] ?? $institutionName);
$displayTagline = !empty($settings['visitor_tagline']) ? $settings['visitor_tagline'] : ($settings['opac_tagline'] ?? 'Visitors Log');
$visitorHeaderBg = $settings['visitor_header_bg'] ?? '#1e3c72';
$visitorBodyBg = $settings['visitor_body_bg'] ?? '#f0f2f5';
$visitorFooterBg = $settings['visitor_footer_bg'] ?? '#1e3c72';
$visitorFontFamily = $settings['visitor_font_family'] ?? 'Inter';
$visitorBaseFontSize = (int)($settings['visitor_base_font_size'] ?? 16);
$visitorPrimaryColor = $settings['visitor_primary_color'] ?? '#28a745';
$visitorCarouselType = $settings['visitor_carousel_type'] ?? 'cover_flow';
$enableWebcam = (int)($settings['enable_webcam_capture'] ?? 0);

// Force guest buttons to be enabled
$guestEnabled = 1;
$guestPrefix = $settings['guest_prefix'] ?? 'GUEST-';
$guestPadding = (int)($settings['guest_number_padding'] ?? 4);
$guestDailyCounter = (int)($settings['guest_daily_counter'] ?? 1);

$lastReset = $settings['guest_last_reset'] ?? '';
$today = date('Y-m-d');
if ($lastReset != $today) {
    $db->prepare("UPDATE settings SET guest_daily_counter = 1, guest_last_reset = ?")->execute([$today]);
    $guestDailyCounter = 1;
}

// ========== FETCH DATA FOR CAROUSELS ==========
$newArrivals = [];
$newArrivalsCount = $settings['new_arrivals_count'] ?? 10;
$stmt = $db->prepare("SELECT id, barcode, title, author, cover_path FROM books WHERE status != 'Deleted' ORDER BY created_at DESC LIMIT ?");
$stmt->execute([$newArrivalsCount]);
$newArrivals = $stmt->fetchAll();

$popularEbooks = [];
$stmt = $db->prepare("SELECT id, title, author, cover_path, downloads FROM ebooks WHERE downloads > 0 ORDER BY downloads DESC LIMIT 10");
$stmt->execute();
$popularEbooks = $stmt->fetchAll();

$notices = [];
$stmt = $db->prepare("SELECT title, content, created_at FROM notices WHERE is_active = 1 ORDER BY created_at DESC LIMIT 10");
$stmt->execute();
$notices = $stmt->fetchAll();

// ========== QUOTES FOR "QUOTE OF THE DAY" ==========
$quotes = [];
$tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='quotes'")->fetch();
if ($tableCheck) {
    $quotes = $db->query("SELECT text, author FROM quotes WHERE is_active = 1 ORDER BY RANDOM() LIMIT 30")->fetchAll();
}
if (empty($quotes)) {
    $quotes = [
        ['text' => 'The only thing you absolutely have to know is the location of the library.', 'author' => 'Albert Einstein'],
        ['text' => 'Reading is to the mind what exercise is to the body.', 'author' => 'Joseph Addison'],
        ['text' => 'A library is a hospital for the mind.', 'author' => 'Unknown'],
    ];
}
$randomQuote = $quotes[array_rand($quotes)];

// ========== ROBUST LOGO HANDLING ==========
function getImageBase64($filePath) {
    if (!file_exists($filePath)) return null;
    $data = @file_get_contents($filePath);
    if ($data === false) return null;
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_buffer($finfo, $data);
    finfo_close($finfo);
    return 'data:' . $mime . ';base64,' . base64_encode($data);
}

$logoBase64 = '';
if (!empty($visitorHeaderLogo)) {
    $cleanPath = preg_replace('#^\.\./#', '', $visitorHeaderLogo);
    $fullPath = $rootPath . '/' . $cleanPath;
    $logoBase64 = getImageBase64($fullPath);
}
if (empty($logoBase64) && !empty($opacHeaderLogo)) {
    $cleanPath = preg_replace('#^\.\./#', '', $opacHeaderLogo);
    $fullPath = $rootPath . '/' . $cleanPath;
    $logoBase64 = getImageBase64($fullPath);
}
if (empty($logoBase64) && !empty($institution['logo_path'])) {
    $cleanPath = preg_replace('#^\.\./#', '', $institution['logo_path']);
    $fullPath = $rootPath . '/' . $cleanPath;
    $logoBase64 = getImageBase64($fullPath);
}
if (empty($logoBase64)) {
    $logoBase64 = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'100\' height=\'60\' viewBox=\'0 0 100 60\'%3E%3Crect width=\'100\' height=\'60\' fill=\'%23ffffff\'/%3E%3Ctext x=\'10\' y=\'35\' font-size=\'14\' fill=\'%231e3c72\'%3ELOGO%3C/text%3E%3C/svg%3E';
}

// ========== DEFAULT GUEST AVATAR ==========
function getDefaultAvatarBase64() {
    global $rootPath;
    $customAvatarPath = $rootPath . '/uploads/visitor/default_guest.png';
    if (file_exists($customAvatarPath)) {
        $data = @file_get_contents($customAvatarPath);
        if ($data !== false) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_buffer($finfo, $data);
            finfo_close($finfo);
            return 'data:' . $mime . ';base64,' . base64_encode($data);
        }
    }
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
        <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
            </linearGradient>
            <linearGradient id="bookGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#ffd700;stop-opacity:1" />
                <stop offset="100%" style="stop-color:#ff8c00;stop-opacity:1" />
            </linearGradient>
        </defs>
        <circle cx="100" cy="100" r="95" fill="url(#bgGrad)" />
        <circle cx="70" cy="85" r="8" fill="white" />
        <circle cx="130" cy="85" r="8" fill="white" />
        <circle cx="72" cy="87" r="3" fill="#333" />
        <circle cx="132" cy="87" r="3" fill="#333" />
        <path d="M75 115 Q100 140 125 115" stroke="white" stroke-width="4" fill="none" stroke-linecap="round" />
        <rect x="85" y="140" width="30" height="25" rx="3" fill="url(#bookGrad)" />
        <line x1="100" y1="140" x2="100" y2="165" stroke="#fff" stroke-width="2" />
        <circle cx="70" cy="85" r="12" fill="none" stroke="white" stroke-width="2" />
        <circle cx="130" cy="85" r="12" fill="none" stroke="white" stroke-width="2" />
        <line x1="82" y1="85" x2="118" y2="85" stroke="white" stroke-width="2" />
    </svg>';
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

// ==================== CURRENT DATE, TIME ====================
$currentDate = date('d M Y');
$currentTimeAmPm = date('h:i:s A');

// ==================== AJAX HANDLERS ====================
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    $action = $_GET['ajax'];
    
    if ($action === 'get_member') {
        $admno = trim($_GET['admno'] ?? '');
        if (strlen($admno) < 2) { echo json_encode(['error' => __('valid_id')]); exit; }
        $stmt = $db->prepare("SELECT admno, name, member_category, photo_path, gender FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$member) {
            $member = ['admno' => $admno, 'name' => __('guest').": $admno", 'member_category' => 'Guest', 'photo_path' => null, 'gender' => null];
        }
        $insideCheck = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
        $insideCheck->execute([$admno]);
        $isInside = $insideCheck->fetch() ? true : false;
        
        $photoBase64 = null;
        if (!empty($member['photo_path'])) {
            $possiblePaths = [
                $rootPath . '/' . ltrim($member['photo_path'], '/'),
                $rootPath . '/uploads/members/' . basename($member['photo_path']),
                $member['photo_path']
            ];
            foreach ($possiblePaths as $path) {
                if (file_exists($path)) {
                    $imgData = @file_get_contents($path);
                    if ($imgData !== false) {
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = finfo_buffer($finfo, $imgData);
                        finfo_close($finfo);
                        $photoBase64 = 'data:' . $mime . ';base64,' . base64_encode($imgData);
                        break;
                    }
                }
            }
        }
        $member['photo_base64'] = $photoBase64;
        echo json_encode(['member' => $member, 'is_inside' => $isInside]);
        exit;
    }
    
    if ($action === 'toggle') {
        $admno = trim($_POST['admno']);
        $purpose = trim($_POST['purpose'] ?? '');
        if ($purpose === 'other' && isset($_POST['custom_purpose']) && trim($_POST['custom_purpose']) !== '') {
            $purpose = trim($_POST['custom_purpose']);
        }
        if (strlen($admno) < 2) { echo json_encode(['error' => __('valid_id')]); exit; }
        if (empty($purpose)) $purpose = __('purpose_reading');
        
        $stmt = $db->prepare("SELECT name, member_category FROM members WHERE admno = ? AND status = 'active'");
        $stmt->execute([$admno]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        $memberName = $member ? $member['name'] : __('guest').": $admno";
        $memberCategory = $member ? $member['member_category'] : 'Guest';
        
        $check = $db->prepare("SELECT id FROM entry_exit WHERE admno = ? AND status = 'inside'");
        $check->execute([$admno]);
        $existing = $check->fetch();
        
        if ($existing) {
            $update = $db->prepare("UPDATE entry_exit SET exit_time = time('now'), status = 'exited' WHERE id = ?");
            $update->execute([$existing['id']]);
            logActivity('KIOSK', 'EXIT', "Exit recorded for $admno");
            echo json_encode(['success' => true, 'action' => 'exit', 'message' => __('exit_recorded'), 'member_name' => $memberName]);
        } else {
            $insert = $db->prepare("INSERT INTO entry_exit (admno, member_name, member_category, entry_date, entry_time, purpose, status) VALUES (?,?,?, date('now'), time('now'), ?, 'inside')");
            $insert->execute([$admno, $memberName, $memberCategory, $purpose]);
            logActivity('KIOSK', 'ENTRY', "Entry recorded for $admno");
            echo json_encode(['success' => true, 'action' => 'entry', 'message' => __('entry_recorded'), 'member_name' => $memberName]);
        }
        exit;
    }
    
    if ($action === 'guest_entry') {
        if (!$guestEnabled) { echo json_encode(['error' => 'Guest feature disabled']); exit; }
        $stmt = $db->prepare("SELECT guest_daily_counter FROM settings LIMIT 1");
        $stmt->execute();
        $guestNum = (int)$stmt->fetchColumn();
        if ($guestNum < 1) $guestNum = 1;
        
        $formattedNum = str_pad($guestNum, $guestPadding, '0', STR_PAD_LEFT);
        $admno = $guestPrefix . $formattedNum;
        $memberName = __('guest') . " {$formattedNum}";
        $memberCategory = 'Guest';
        $purpose = __('purpose_reading');
        
        $insert = $db->prepare("INSERT INTO entry_exit (admno, member_name, member_category, entry_date, entry_time, purpose, status) VALUES (?,?,?, date('now'), time('now'), ?, 'inside')");
        $insert->execute([$admno, $memberName, $memberCategory, $purpose]);
        $db->prepare("UPDATE settings SET guest_daily_counter = guest_daily_counter + 1")->execute();
        logActivity('KIOSK', 'GUEST_ENTRY', "Guest {$formattedNum} entered");
        echo json_encode(['success' => true, 'guest_number' => $formattedNum, 'guest_id' => $admno, 'message' => str_replace('{num}', $formattedNum, __('guest_entry_success'))]);
        exit;
    }
    
    if ($action === 'guest_exit_last') {
        if (!$guestEnabled) { echo json_encode(['error' => 'Guest feature disabled']); exit; }
        $stmt = $db->prepare("SELECT id, admno, member_name FROM entry_exit WHERE status = 'inside' AND member_category = 'Guest' ORDER BY entry_time DESC LIMIT 1");
        $stmt->execute();
        $guest = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$guest) {
            echo json_encode(['error' => __('no_active_guests')]);
            exit;
        }
        $update = $db->prepare("UPDATE entry_exit SET exit_time = time('now'), status = 'exited' WHERE id = ?");
        $update->execute([$guest['id']]);
        preg_match('/' . preg_quote($guestPrefix, '/') . '(\d+)/', $guest['admno'], $matches);
        $guestNum = $matches[1] ?? '?';
        logActivity('KIOSK', 'GUEST_EXIT', "Guest {$guestNum} exited");
        echo json_encode(['success' => true, 'guest_number' => $guestNum, 'message' => str_replace('{num}', $guestNum, __('guest_exit_success'))]);
        exit;
    }
    
    if ($action === 'stats') {
        $insideCount = $db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'")->fetchColumn();
        $todayVisitors = $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date = date('now')")->fetchColumn();
        $maleCount = $db->query("SELECT COUNT(*) FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE e.status='inside' AND m.gender = 'Male'")->fetchColumn();
        $femaleCount = $db->query("SELECT COUNT(*) FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE e.status='inside' AND m.gender = 'Female'")->fetchColumn();
        $otherCount = $db->query("SELECT COUNT(*) FROM entry_exit e LEFT JOIN members m ON e.admno = m.admno WHERE e.status='inside' AND m.gender NOT IN ('Male','Female') AND m.gender IS NOT NULL AND m.gender != ''")->fetchColumn();
        $catSql = "SELECT member_category, COUNT(*) as count FROM entry_exit WHERE status='inside' GROUP BY member_category";
        $categoryStats = $db->query($catSql)->fetchAll(PDO::FETCH_KEY_PAIR);
        $activeGuests = $db->query("SELECT admno, member_name FROM entry_exit WHERE status='inside' AND member_category = 'Guest' ORDER BY entry_time ASC")->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'insideCount' => (int)$insideCount,
            'todayVisitors' => (int)$todayVisitors,
            'maleCount' => (int)$maleCount,
            'femaleCount' => (int)$femaleCount,
            'otherCount' => (int)$otherCount,
            'categoryStats' => $categoryStats,
            'activeGuests' => $activeGuests
        ]);
        exit;
    }

    if ($action === 'get_recent_activity') {
        $sql = "
            (SELECT admno, member_name, entry_time as action_time, 'entry' as action_type, purpose, entry_date
             FROM entry_exit 
             WHERE status = 'inside')
            UNION ALL
            (SELECT admno, member_name, exit_time as action_time, 'exit' as action_type, purpose, entry_date
             FROM entry_exit 
             WHERE status = 'exited' AND exit_time IS NOT NULL)
            ORDER BY action_time DESC
            LIMIT 10
        ";
        $stmt = $db->query($sql);
        $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'activities' => $activities]);
        exit;
    }

    if ($action === 'get_purpose_stats') {
        $sql = "SELECT purpose, COUNT(*) as count 
                FROM entry_exit 
                WHERE entry_date = date('now') 
                GROUP BY purpose 
                ORDER BY count DESC";
        $stmt = $db->query($sql);
        $purposes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'purposes' => $purposes]);
        exit;
    }

    // ========== ENHANCED: CHECK BOOK (returns member details if issued) ==========
    if ($action === 'check_book') {
        $barcode = trim($_GET['barcode'] ?? '');
        if (strlen($barcode) < 2) { echo json_encode(['error' => 'Invalid barcode']); exit; }
        $stmt = $db->prepare("SELECT barcode, title, author, status FROM books WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $book = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$book) {
            echo json_encode(['is_book' => false, 'message' => 'Not a book barcode']);
            exit;
        }
        // Check if currently issued and get member details
        $loanStmt = $db->prepare("SELECT admno, member_name FROM circulation WHERE barcode = ? AND return_date IS NULL LIMIT 1");
        $loanStmt->execute([$barcode]);
        $loan = $loanStmt->fetch(PDO::FETCH_ASSOC);
        $is_authorized = ($loan !== false);
        $memberData = null;
        if ($is_authorized) {
            // Fetch full member details including photo
            $memberStmt = $db->prepare("SELECT admno, name, member_category, photo_path, gender FROM members WHERE admno = ?");
            $memberStmt->execute([$loan['admno']]);
            $member = $memberStmt->fetch(PDO::FETCH_ASSOC);
            if ($member) {
                // Get photo base64
                $photoBase64 = null;
                if (!empty($member['photo_path'])) {
                    $possiblePaths = [
                        $rootPath . '/' . ltrim($member['photo_path'], '/'),
                        $rootPath . '/uploads/members/' . basename($member['photo_path']),
                        $member['photo_path']
                    ];
                    foreach ($possiblePaths as $path) {
                        if (file_exists($path)) {
                            $imgData = @file_get_contents($path);
                            if ($imgData !== false) {
                                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                $mime = finfo_buffer($finfo, $imgData);
                                finfo_close($finfo);
                                $photoBase64 = 'data:' . $mime . ';base64,' . base64_encode($imgData);
                                break;
                            }
                        }
                    }
                }
                $member['photo_base64'] = $photoBase64;
                $memberData = $member;
            }
        }
        echo json_encode([
            'is_book' => true,
            'book' => $book,
            'is_authorized' => $is_authorized,
            'loan_member' => $loan ? $loan['admno'] : null,
            'loan_member_name' => $loan ? $loan['member_name'] : null,
            'member' => $memberData // full member info including photo
        ]);
        exit;
    }

    // ========== LOG BOOK EXIT ==========
    if ($action === 'log_book_exit') {
        $barcode = trim($_POST['barcode'] ?? '');
        $member_admno = trim($_POST['member_admno'] ?? '');
        $member_name = trim($_POST['member_name'] ?? '');
        $photo_data = $_POST['photo_data'] ?? null; // base64 image
        $is_authorized = (int)($_POST['is_authorized'] ?? 0);
        if (strlen($barcode) < 2) { echo json_encode(['error' => 'Invalid barcode']); exit; }
        
        // Get book details
        $bookStmt = $db->prepare("SELECT title, author FROM books WHERE barcode = ?");
        $bookStmt->execute([$barcode]);
        $book = $bookStmt->fetch(PDO::FETCH_ASSOC);
        if (!$book) {
            echo json_encode(['error' => 'Book not found']);
            exit;
        }
        
        // Save photo if provided
        $photo_path = null;
        if ($photo_data && $enableWebcam) {
            $photo_dir = UPLOAD_DIR . 'book_exit_photos/';
            if (!is_dir($photo_dir)) mkdir($photo_dir, 0777, true);
            $filename = 'book_exit_' . time() . '_' . uniqid() . '.jpg';
            $filepath = $photo_dir . $filename;
            // Decode and save
            $image_parts = explode(';base64,', $photo_data);
            if (count($image_parts) == 2) {
                $image_base64 = base64_decode($image_parts[1]);
                file_put_contents($filepath, $image_base64);
                $photo_path = 'uploads/book_exit_photos/' . $filename;
            }
        }
        
        // Insert log
        $insert = $db->prepare("INSERT INTO book_exit_logs (book_barcode, book_title, book_author, member_admno, member_name, is_authorized, photo_path, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([
            $barcode,
            $book['title'],
            $book['author'],
            $member_admno ?: null,
            $member_name ?: null,
            $is_authorized,
            $photo_path,
            'Logged from visitor kiosk'
        ]);
        logActivity('KIOSK', 'BOOK_EXIT', "Book exit: $barcode, authorized: $is_authorized");
        echo json_encode(['success' => true, 'message' => __('book_exit_logged')]);
        exit;
    }
    
    echo json_encode(['error' => __('operation_failed')]);
    exit;
}

$rtlClass = ($lang == 'ar') ? 'rtl-mode' : '';

// ========== LIBRARY HOURS DATA ==========
$libraryHoursHtml = '';
if (function_exists('getLibraryHours')) {
    $hours = getLibraryHours();
    $daysMap = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
    $openDays = array_map(function($d) use ($daysMap) { return $daysMap[$d]; }, $hours['open_days']);
    $daysStr = implode(', ', $openDays);
    $isOpen = function_exists('isLibraryOpen') ? isLibraryOpen() : true;
    $libraryHoursHtml = '
        <div class="library-hours-content">
            <h5 class="fs-6 fw-bold mb-2"><i class="fas fa-clock text-warning me-2"></i>' . __('library_hours') . '</h5>
            <p class="small mb-1"><span class="fw-semibold">' . __('open_days') . ':</span> ' . htmlspecialchars($daysStr) . '</p>
            <p class="small mb-1"><span class="fw-semibold">' . __('hours') . ':</span> ' . htmlspecialchars($hours['open_time']) . ' – ' . htmlspecialchars($hours['close_time']) . '</p>';
    if (!empty($hours['lunch_start']) && !empty($hours['lunch_end'])) {
        $libraryHoursHtml .= '<p class="small mb-1"><span class="fw-semibold">' . __('lunch_break') . ':</span> ' . htmlspecialchars($hours['lunch_start']) . ' – ' . htmlspecialchars($hours['lunch_end']) . '</p>';
    }
    if (!$isOpen) {
        $libraryHoursHtml .= '<div class="alert alert-warning mt-2 mb-0 py-1 small"><i class="fas fa-exclamation-triangle"></i> ' . __('currently_closed') . '</div>';
    }
    $libraryHoursHtml .= '</div>';
} else {
    $libraryHoursHtml = '<div class="alert alert-info small text-center">Library hours module not available.</div>';
}

// Build New Arrivals carousel HTML for inside scanner card (centered, no auto-sliding text)
$newArrivalsHtml = '';
if (!empty($newArrivals)) {
    $newArrivalsHtml .= '<div class="scanner-new-arrivals text-center">';
    $newArrivalsHtml .= '<h6 class="fw-bold mb-2"><i class="fas fa-star text-warning me-1"></i> ' . __('new_arrivals') . '</h6>';
    $newArrivalsHtml .= '<div class="swiper swiper-scanner-new-arrivals" style="margin: 0 auto;">';
    $newArrivalsHtml .= '<div class="swiper-wrapper">';
    foreach ($newArrivals as $book) {
        $coverBase64 = '';
        if (!empty($book['cover_path']) && file_exists($rootPath . '/' . $book['cover_path'])) {
            $fullPath = $rootPath . '/' . ltrim($book['cover_path'], '/');
            $coverBase64 = getImageBase64($fullPath);
        }
        $newArrivalsHtml .= '<div class="swiper-slide">';
        $newArrivalsHtml .= '<div class="carousel-item-card" onclick="window.open(\'../opac/?search=1&keyword=' . urlencode($book['title']) . '\', \'_blank\')">';
        $newArrivalsHtml .= '<div class="carousel-item-cover">';
        if ($coverBase64) {
            $newArrivalsHtml .= '<img src="' . $coverBase64 . '" alt="Cover">';
        } else {
            $newArrivalsHtml .= '<i class="fas fa-book"></i>';
        }
        $newArrivalsHtml .= '</div>';
        $newArrivalsHtml .= '<div class="carousel-item-body">';
        $newArrivalsHtml .= '<div class="carousel-item-title" title="' . htmlspecialchars($book['title']) . '">' . htmlspecialchars(mb_substr($book['title'], 0, 20)) . '</div>';
        $newArrivalsHtml .= '<div class="carousel-item-author">' . htmlspecialchars(mb_substr($book['author'] ?? 'Unknown', 0, 12)) . '</div>';
        $newArrivalsHtml .= '</div></div></div>';
    }
    $newArrivalsHtml .= '</div>';
    $newArrivalsHtml .= '<div class="swiper-button-next"></div>';
    $newArrivalsHtml .= '<div class="swiper-button-prev"></div>';
    $newArrivalsHtml .= '<div class="swiper-pagination"></div>';
    $newArrivalsHtml .= '</div></div>';
}
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $lang == 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Visitor Kiosk – <?= htmlspecialchars($displayHeaderText) ?></title>
    <?php
    $faviconPath = '';
    if (!empty($settings['favicon_path']) && file_exists($rootPath . '/' . $settings['favicon_path'])) {
        $faviconPath = '../' . getWebImageUrl($settings['favicon_path']);
    }
    ?>
    <?php if ($faviconPath): ?>
    <link rel="icon" type="image/x-icon" href="<?= $faviconPath ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=<?= urlencode($visitorFontFamily) ?>:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, <?= $visitorPrimaryColor ?> 0%, #2b7a3e 100%);
            --card-shadow: 0 4px 12px rgba(0,0,0,0.04);
            --glass-bg: rgba(255, 255, 255, 0.95);
            --border-radius-card: 20px;
            --primary-color: <?= $visitorPrimaryColor ?>;
        }
        
        * { font-family: '<?= $visitorFontFamily ?>', 'Inter', sans-serif; }
        
        body {
            background: <?= $visitorBodyBg ?>;
            font-size: <?= $visitorBaseFontSize ?>px;
            background-image: radial-gradient(circle at 10% 20%, rgba(255,255,255,0.4) 0%, rgba(255,255,255,0) 80%);
            min-height: 100vh;
            margin: 5px !important;
        }
        
        body.rtl-mode {
            text-align: right;
        }
        .rtl-mode .header-container { flex-direction: row-reverse; }
        .rtl-mode .lang-switch i { margin-left: 5px; margin-right: 0; }
        .rtl-mode .carousel-section h5 { border-left: none; border-right: 4px solid #ffc107; padding-left: 0; padding-right: 10px; }
        .rtl-mode .stat-card-inner .stat-label i { margin-left: 8px; margin-right: 0; }
        .rtl-mode .header-right { flex-direction: row-reverse; }
        .rtl-mode .header-right .digital-hub-link { margin-left: 0; margin-right: 8px; }
        .rtl-mode .header-right .dropdown { margin-left: 0; margin-right: 8px; }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(25px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulseGlow {
            0% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(40, 167, 69, 0); }
            100% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0); }
        }
        
        /* Fingerprint bounce animation */
        @keyframes fingerprintTap {
            0% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-6px) scale(1.12); }
            100% { transform: translateY(0) scale(1); }
        }
        .guest-btn .fa-fingerprint {
            animation: fingerprintTap 1.4s ease-in-out infinite;
            display: block;
            font-size: 2.8rem;
            margin-bottom: 4px;
        }
        .guest-btn:hover .fa-fingerprint {
            animation-duration: 0.6s;
        }
        
        .header-bg {
            background: <?= $visitorHeaderBg ?>;
            backdrop-filter: blur(4px);
            color: white;
            padding: 12px 0;
            margin-bottom: 30px;
            animation: fadeInUp 0.6s ease;
            position: relative;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }
        .header-bg::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #ffd700, #ff8c00, #ffd700);
        }
        
        .header-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 1500px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .header-left img {
            height: 70px;
            width: auto;
            max-width: 140px;
            object-fit: contain;
            background: white;
            border-radius: 16px;
            padding: 6px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .header-left img:hover { transform: scale(1.05) rotate(1deg); }
        
        .header-title {
            text-align: center;
            flex-grow: 2;
        }
        .header-title h1 {
            font-size: 1.8rem;
            font-weight: 800;
            margin-bottom: 0;
            letter-spacing: -0.3px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .header-title p {
            font-size: 0.9rem;
            opacity: 0.9;
            margin-top: 5px;
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .lang-switch, .digital-hub-link {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,255,255,0.4);
            border-radius: 50px;
            padding: 8px 18px;
            color: white;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .lang-switch:hover, .digital-hub-link:hover {
            background: rgba(255,255,255,0.35);
            transform: scale(1.05);
            color: white;
        }
        .header-right .dropdown .btn {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            border-radius: 50px;
            padding: 8px 18px;
            font-size: 0.85rem;
        }
        .header-right .dropdown .btn:hover {
            background: rgba(255,255,255,0.35);
        }
        .header-right .dropdown {
            margin-left: 8px;
        }
        
        /* ===== CONTAINER MAX-WIDTH: 1600px ===== */
        .kiosk-container {
            max-width: 1600px;
            margin-left: auto;
            margin-right: auto;
            padding-left: 20px;
            padding-right: 20px;
        }
        
        /* ===== MAIN LAYOUT – 70% / 30% split ===== */
        .kiosk-row {
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
            margin-bottom: 30px;
            align-items: stretch;
        }
        .kiosk-left {
            flex: 0 0 calc(70% - 12px);
            width: calc(70% - 12px);
        }
        .kiosk-right {
            flex: 0 0 calc(30% - 12px);
            width: calc(30% - 12px);
        }
        @media (max-width: 992px) {
            .kiosk-left, .kiosk-right {
                flex: 0 0 100%;
                width: 100%;
            }
        }
        
        .scanner-card, .stats-card, .info-card {
            background: var(--glass-bg);
            backdrop-filter: blur(4px);
            border-radius: var(--border-radius-card);
            padding: 20px 22px;
            box-shadow: var(--card-shadow);
            height: 100%;
            transition: all 0.2s cubic-bezier(0.2, 0.9, 0.4, 1.1);
            border: 1px solid rgba(255,255,255,0.4);
            position: relative;
        }
        .scanner-card:hover, .stats-card:hover, .info-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }
        
        /* === ENLARGED SCANNER CARD (10% taller) === */
        .scanner-card {
            padding: 6px 4px;
            min-height: 815px;
        }
        
        .guest-btn-left {
            position: absolute;
            top: 24px;
            left: 28px;
            z-index: 5;
        }
        .guest-btn-right {
            position: absolute;
            top: 24px;
            right: 28px;
            z-index: 5;
        }
        body.rtl-mode .guest-btn-left {
            left: auto;
            right: 28px;
        }
        body.rtl-mode .guest-btn-right {
            right: auto;
            left: 28px;
        }
        
        .scanner-card h2 {
            font-size: 1.7rem;
            font-weight: 800;
            margin-bottom: 18px;
            text-align: center;
            padding: 0 140px;
        }
        
        @media (max-width: 768px) {
            .scanner-card h2 {
                padding: 0;
                margin-top: 50px;
                font-size: 1.2rem;
            }
            .guest-btn-left, .guest-btn-right {
                position: static;
                display: inline-block;
                margin: 5px;
            }
        }
        
        /* ===== ENLARGED GUEST BUTTONS WITH FINGERPRINT ICON ABOVE TEXT ===== */
        .guest-btn {
            width: auto;
            min-width: 120px;
            height: 120px; /* extra height to accommodate icon + text */
            border-radius: 48px;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            font-size: 0.9rem;
            font-weight: 700;
            padding: 12px 16px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            line-height: 1.2;
        }
        .guest-btn .fa-fingerprint {
            font-size: 2.8rem;
        }
        .guest-btn.btn-success {
            background: linear-gradient(135deg, <?= $visitorPrimaryColor ?>, #1e7e34);
            color: white;
        }
        .guest-btn.btn-danger {
            background: linear-gradient(135deg, #dc3545, #b02a37);
            color: white;
        }
        .guest-btn:hover {
            transform: scale(1.04);
            filter: brightness(1.05);
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
        }
        
        /* Reduced width input */
        .scanner-input {
            font-size: 1.6rem;
            text-align: center;
            height: 75px;
            border-radius: 60px;
            border: 2px solid <?= $visitorPrimaryColor ?>;
            padding: 0 28px;
            transition: all 0.3s;
            background: white;
            font-weight: 500;
            max-width: 420px; /* narrower */
            margin-left: auto;
            margin-right: auto;
        }
        .scanner-input:focus {
            border-color: #ffc107;
            box-shadow: 0 0 0 0.2rem rgba(255,193,7,0.3);
            transform: scale(1.01);
        }
        
        /* Larger member photo */
        .member-photo { 
            width: 260px; 
            height: 260px; 
            border-radius: 12px; 
            object-fit: cover; 
            border: 4px solid <?= $visitorPrimaryColor ?>; 
            margin: 16px auto; 
            display: block;
            box-shadow: 0 6px 16px rgba(0,0,0,0.12);
            transition: transform 0.3s, box-shadow 0.3s;
            background: #f8f9fa;
        }
        .member-photo:hover { 
            transform: scale(1.02); 
            box-shadow: 0 10px 24px rgba(0,0,0,0.18);
        }
        
        .badge-category {
            background: <?= $visitorPrimaryColor ?>;
            color: white;
            padding: 4px 16px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .greeting-message {
            font-size: 1.2rem;
            font-weight: 700;
            padding: 12px;
            border-radius: 60px;
            margin: 12px 0;
            animation: fadeInUp 0.4s;
        }
        .greeting-welcome { background: linear-gradient(135deg, #d1e7dd, #b8e0cc); color: #0f5132; }
        .greeting-thanks { background: linear-gradient(135deg, #f8d7da, #f5c6cb); color: #842029; }
        
        /* ===== STATIC DATE/TIME CARDS (no flip) ===== */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }
        .stat-card-static {
            background: white;
            border-radius: 20px;
            padding: 14px 10px;
            text-align: center;
            box-shadow: var(--card-shadow);
            border: 1px solid rgba(255,255,255,0.3);
            transition: 0.2s;
            min-height: 100px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .stat-card-static:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }
        .stat-card-static i {
            font-size: 2rem;
            margin-bottom: 4px;
        }
        .stat-card-static h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            background: linear-gradient(135deg, var(--primary-color), #2a5298);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        .stat-card-static p {
            margin: 0;
            font-size: 0.75rem;
            color: #6c757d;
            font-weight: 500;
        }
        
        /* ===== Live Status – compact ===== */
        .stat-card-inner {
            background: rgba(248, 249, 250, 0.7);
            backdrop-filter: blur(4px);
            border-radius: 16px;
            padding: 10px 14px;
            margin-bottom: 6px;
            transition: all 0.2s;
        }
        .stat-card-inner:hover {
            background: rgba(233, 236, 239, 0.9);
            transform: translateX(4px);
        }
        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, <?= $visitorPrimaryColor ?>, #2b7a3e);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .info-card h5 {
            font-size: 1.1rem;
            font-weight: 800;
            margin-bottom: 14px;
            color: <?= $visitorPrimaryColor ?>;
            border-left: 4px solid #ffc107;
            padding-left: 10px;
        }
        
        .quote-text {
            font-size: 1rem;
            font-style: italic;
            line-height: 1.5;
            color: #2c3e50;
            margin-bottom: 12px;
            position: relative;
            padding: 0 16px;
        }
        .quote-text:before {
            content: '"';
            font-size: 2rem;
            position: absolute;
            left: -2px;
            top: -8px;
            opacity: 0.3;
            font-family: serif;
        }
        .quote-author {
            text-align: right;
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 8px;
            border-top: 1px solid #e9ecef;
            padding-top: 6px;
        }
        .refresh-quote-btn {
            background: none;
            border: 1px solid <?= $visitorPrimaryColor ?>;
            color: <?= $visitorPrimaryColor ?>;
            border-radius: 30px;
            padding: 4px 14px;
            font-size: 0.7rem;
            transition: all 0.3s;
            cursor: pointer;
        }
        .refresh-quote-btn:hover {
            background: <?= $visitorPrimaryColor ?>;
            color: white;
        }
        
        .progress-purpose {
            height: 6px;
            border-radius: 10px;
            background: #e9ecef;
        }
        .progress-bar-purpose {
            background: <?= $visitorPrimaryColor ?>;
            border-radius: 10px;
        }
        
        /* ========== ENHANCED COVER FLOW CAROUSEL STYLES ========== */
        .carousel-section {
            margin-top: 30px;
            margin-bottom: 10px;
            animation: fadeInUp 0.7s ease;
        }
        .carousel-section .d-flex {
            justify-content: center !important;
            text-align: center;
            flex-direction: column;
            align-items: center;
        }
        .carousel-section h5 {
            font-size: 1.2rem;
            font-weight: 800;
            color: <?= $visitorPrimaryColor ?>;
            margin-bottom: 5px;
            border-left: none;
            padding-left: 0;
        }
        .carousel-section .text-muted {
            font-size: 0.7rem;
            margin-bottom: 8px;
        }
        
        .swiper {
            padding: 30px 0 50px !important;
        }
        .swiper-slide {
            width: 240px;
            transition: all 0.3s;
        }
        .carousel-item-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
            transition: all 0.3s ease;
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .carousel-item-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 30px rgba(0,0,0,0.1);
        }
        .carousel-item-cover {
            background: linear-gradient(135deg, #f5f7fa, #e9ecef);
            padding: 12px;
            text-align: center;
            min-height: 130px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .carousel-item-cover img {
            max-height: 90px;
            max-width: 100%;
            object-fit: contain;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        .carousel-item-cover i {
            font-size: 2.8rem;
            color: #adb5bd;
        }
        .carousel-item-body {
            padding: 10px;
            text-align: center;
            flex-grow: 1;
        }
        .carousel-item-title {
            font-weight: 700;
            font-size: 0.8rem;
            line-height: 1.3;
            margin-bottom: 4px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .carousel-item-author {
            font-size: 0.65rem;
            color: #6c757d;
        }
        .notice-card {
            background: white;
            border-radius: 20px;
            height: 100%;
            transition: all 0.3s;
        }
        
        /* Cover Flow specific overrides */
        .swiper-coverflow .swiper-slide {
            width: 280px;
        }
        .swiper-coverflow .carousel-item-cover {
            min-height: 150px;
        }
        .swiper-coverflow .carousel-item-cover img {
            max-height: 110px;
        }
        
        @media (max-width: 768px) {
            .swiper-slide { width: 180px; }
            .carousel-item-cover img { max-height: 70px; }
            .carousel-item-title { font-size: 0.7rem; }
        }
        
        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 16px;
            background: <?= $visitorFooterBg ?>;
            color: white;
            border-radius: 28px;
            font-size: 0.7rem;
            animation: fadeInUp 0.6s ease;
        }
        .footer a { color: #ffd700; text-decoration: none; }
        
        .whatsapp-float {
            position: fixed;
            bottom: 25px;
            right: 25px;
            background: linear-gradient(135deg, #25d366, #20b359);
            color: white;
            border-radius: 50px;
            width: 55px;
            height: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.25);
            z-index: 1000;
            transition: all 0.3s;
            text-decoration: none;
        }
        .whatsapp-float:hover {
            transform: scale(1.1);
            background: #20b359;
            color: white;
        }
        
        /* ========== COMBINED CONTENT & RESULT OVERLAY ========== */
        .scan-result-wrapper {
            position: relative;
            min-height: 280px;
            margin-top: 15px;
        }
        .scan-result-wrapper > div {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            transition: opacity 0.5s ease, visibility 0.5s ease;
            width: 100%;
        }
        .content-container {
            opacity: 1;
            visibility: visible;
            background: rgba(248, 249, 250, 0.5);
            border-radius: 20px;
            padding: 16px;
            backdrop-filter: blur(2px);
            border: 1px solid rgba(255,255,255,0.3);
        }
        .content-container.hidden {
            opacity: 0;
            visibility: hidden;
        }
        .result-area {
            opacity: 0;
            visibility: hidden;
            padding: 5px;
        }
        .result-area.visible {
            opacity: 1;
            visibility: visible;
        }
        .library-hours-content {
            text-align: center;
        }
        .library-hours-content h5 {
            color: <?= $visitorPrimaryColor ?>;
        }

        /* New Arrivals inside scanner card (centered) */
        .scanner-new-arrivals {
            margin-top: 18px;
            padding-top: 12px;
            border-top: 1px solid rgba(0,0,0,0.08);
            text-align: center;
        }
        .scanner-new-arrivals .swiper {
            padding: 15px 0 30px !important;
            margin: 0 auto;
        }
        .scanner-new-arrivals .swiper-slide {
            width: 160px;
        }
        .scanner-new-arrivals .carousel-item-cover {
            min-height: 90px;
            padding: 10px;
        }
        .scanner-new-arrivals .carousel-item-cover img {
            max-height: 60px;
        }
        .scanner-new-arrivals .carousel-item-body {
            padding: 8px;
        }
        .scanner-new-arrivals .carousel-item-title {
            font-size: 0.75rem;
        }
        .scanner-new-arrivals .carousel-item-author {
            font-size: 0.65rem;
        }
        .scanner-new-arrivals .swiper-button-next,
        .scanner-new-arrivals .swiper-button-prev {
            width: 25px;
            height: 25px;
            background: rgba(255,255,255,0.8);
            border-radius: 50%;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .scanner-new-arrivals .swiper-button-next:after,
        .scanner-new-arrivals .swiper-button-prev:after {
            font-size: 12px;
            font-weight: bold;
        }
        .scanner-new-arrivals .swiper-pagination {
            bottom: 0;
        }

        /* Book alert styles */
        .book-alert {
            border-radius: 16px;
            padding: 16px;
            margin-top: 12px;
        }
        .book-alert.unauthorized {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .book-alert.authorized {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .book-alert .book-details {
            font-weight: 600;
        }
        .book-alert .book-meta {
            font-size: 0.9rem;
        }
        .webcam-preview {
            margin: 10px auto;
            max-width: 200px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="<?= $rtlClass ?>">

<div class="header-bg">
    <div class="header-container">
        <div class="header-left">
            <img src="<?= $logoBase64 ?>" alt="Library Logo">
        </div>
        <div class="header-title">
            <h1><?= htmlspecialchars($displayHeaderText) ?></h1>
            <p><?= htmlspecialchars($displayTagline) ?></p>
        </div>
        <div class="header-right">
            <a href="../opac/digital_hub.php" class="digital-hub-link" target="_blank">
                <i class="fas fa-globe"></i> <span><?= __('digital_hub') ?></span>
            </a>
            <!-- Language Switcher Dropdown (EN, HI, AR) -->
            <div class="dropdown d-inline-block">
                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-language"></i> <?= strtoupper($lang) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item <?= $lang == 'en' ? 'active' : '' ?>" href="?lang=en">🇬🇧 English</a></li>
                    <li><a class="dropdown-item <?= $lang == 'hi' ? 'active' : '' ?>" href="?lang=hi">🇮🇳 हिन्दी</a></li>
                    <li><a class="dropdown-item <?= $lang == 'ar' ? 'active' : '' ?>" href="?lang=ar">🇸🇦 العربية</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="kiosk-container">
    <div class="kiosk-row">
        <!-- LEFT: Scanner Card (70% width, taller) -->
        <div class="kiosk-left">
            <div class="scanner-card">
                <button id="guestEntryBtn" class="guest-btn guest-btn-left btn-success" title="<?= __('guest_entry') ?>">
                    <i class="fas fa-fingerprint"></i>
                    <?= __('guest_entry') ?>
                </button>
                <button id="guestExitBtn" class="guest-btn guest-btn-right btn-danger" title="<?= __('guest_exit') ?>">
                    <i class="fas fa-fingerprint"></i>
                    <?= __('guest_exit') ?>
                </button>
                
                <h2><i class="fas fa-door-open"></i> <?= __('visitor_log') ?></h2>
                <p class="text-muted small text-center"><?= __('scan_id') ?></p>
                <input type="text" id="scanInput" class="form-control scanner-input" placeholder="<?= __('scan_placeholder') ?>" autofocus>
                
                <div class="purpose-selector mt-3">
                    <label for="purposeSelect" class="fw-semibold"><i class="fas fa-tag"></i> <?= __('purpose_label') ?></label>
                    <select id="purposeSelect" class="form-select mt-1">
                        <option value="reading"><?= __('purpose_reading') ?></option>
                        <option value="issue_return"><?= __('purpose_issue_return') ?></option>
                        <option value="research"><?= __('purpose_research') ?></option>
                        <option value="meeting"><?= __('purpose_meeting') ?></option>
                        <option value="event"><?= __('purpose_event') ?></option>
                        <option value="other"><?= __('purpose_other') ?></option>
                    </select>
                    <div id="customPurposeDiv" style="display: none; margin-top: 10px;">
                        <input type="text" id="customPurpose" class="form-control" placeholder="<?= __('custom_purpose_placeholder') ?>">
                    </div>
                </div>

                <!-- Combined Content (Library Hours + New Arrivals) and Result Overlay -->
                <div class="scan-result-wrapper">
                    <!-- Content that fades away -->
                    <div id="contentContainer" class="content-container">
                        <?= $libraryHoursHtml ?>
                        <?= $newArrivalsHtml ?>
                    </div>
                    <!-- Result area that appears on scan -->
                    <div id="resultArea" class="result-area">
                        <!-- dynamically filled -->
                    </div>
                </div>
                
                <div id="cooldownMessage" class="cooldown-message text-center mt-2 small"></div>
            </div>
        </div>
        
        <!-- RIGHT: Date/Time + Live Status (30%) -->
        <div class="kiosk-right">
            <!-- Static Date and Time Cards -->
            <div class="stats-grid">
                <div class="stat-card-static">
                    <i class="fas fa-calendar-alt" style="color: #28a745;"></i>
                    <h3><?= htmlspecialchars($currentDate) ?></h3>
                    <p><?= __('today') ?></p>
                </div>
                <div class="stat-card-static">
                    <i class="fas fa-clock" style="color: #ffc107;"></i>
                    <h3><?= htmlspecialchars($currentTimeAmPm) ?></h3>
                    <p><?= __('current_time') ?></p>
                </div>
            </div>

            <!-- Live Library Status Card -->
            <div class="stats-card">
                <h4><i class="fas fa-chart-line"></i> <?= __('live_status') ?></h4>
                <hr class="my-2">
                <div id="statsArea"><div class="text-center py-3"><div class="spinner-border text-primary spinner-border-sm"></div> <?= __('processing') ?></div></div>
            </div>
        </div>
    </div>

    <!-- Quote & Recent Activity row -->
    <div class="row g-4 mt-2">
        <div class="col-md-6">
            <div class="info-card" id="quoteCard">
                <h5><i class="fas fa-quote-left text-warning"></i> <?= __('quote_of_the_day') ?></h5>
                <div id="quoteContainer">
                    <div class="quote-text"><?= htmlspecialchars($randomQuote['text']) ?></div>
                    <div class="quote-author">— <?= htmlspecialchars($randomQuote['author'] ?? __('quote_author_unknown')) ?></div>
                </div>
                <div class="text-center mt-3">
                    <button class="refresh-quote-btn" id="refreshQuoteBtn"><i class="fas fa-sync-alt"></i> <?= __('refresh_quote') ?></button>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="info-card">
                <h5><i class="fas fa-history"></i> <?= __('recent_activity') ?></h5>
                <div id="recentActivityList">
                    <div class="text-center text-muted"><i class="fas fa-spinner fa-spin"></i> Loading...</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Purpose Distribution -->
    <div class="row g-4 mt-1">
        <div class="col-12">
            <div class="info-card">
                <h5><i class="fas fa-chart-pie"></i> <?= __('purpose_distribution') ?></h5>
                <div id="purposeStatsContainer" class="row g-2">
                    <div class="text-center py-2"><div class="spinner-border spinner-border-sm text-secondary"></div> Loading...</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Popular eBooks Carousel -->
    <?php if (!empty($popularEbooks)): ?>
    <div class="carousel-section">
        <div class="d-flex justify-content-between align-items-center">
            <h5><i class="fas fa-file-pdf text-danger me-1"></i> <?= __('popular_ebooks') ?></h5>
            <span class="text-muted small"><?= __('auto_sliding') ?></span>
        </div>
        <div class="swiper swiper-popular-ebooks">
            <div class="swiper-wrapper">
                <?php foreach ($popularEbooks as $ebook):
                    $coverBase64 = '';
                    if (!empty($ebook['cover_path']) && file_exists($rootPath . '/' . $ebook['cover_path'])) {
                        $fullPath = $rootPath . '/' . ltrim($ebook['cover_path'], '/');
                        $coverBase64 = getImageBase64($fullPath);
                    }
                ?>
                <div class="swiper-slide">
                    <div class="carousel-item-card" onclick="window.open('../opac/ebook-search.php?search=1&keyword=<?= urlencode($ebook['title']) ?>', '_blank')">
                        <div class="carousel-item-cover">
                            <?php if ($coverBase64): ?>
                                <img src="<?= $coverBase64 ?>" alt="Cover">
                            <?php else: ?>
                                <i class="fas fa-file-pdf"></i>
                            <?php endif; ?>
                        </div>
                        <div class="carousel-item-body">
                            <div class="carousel-item-title"><?= htmlspecialchars(mb_substr($ebook['title'], 0, 22)) ?></div>
                            <div class="carousel-item-author"><?= htmlspecialchars(mb_substr($ebook['author'] ?? 'Unknown', 0, 15)) ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Notices Carousel -->
    <?php if (!empty($notices)): ?>
    <div class="carousel-section">
        <div class="d-flex justify-content-between align-items-center">
            <h5><i class="fas fa-bullhorn text-info me-1"></i> <?= __('latest_notices') ?></h5>
            <span class="text-muted small"><?= __('auto_sliding') ?></span>
        </div>
        <div class="swiper swiper-notices">
            <div class="swiper-wrapper">
                <?php foreach ($notices as $notice): ?>
                <div class="swiper-slide">
                    <div class="notice-card p-3 h-100 bg-white rounded-3 shadow-sm">
                        <div class="notice-title fw-bold"><?= htmlspecialchars(mb_substr($notice['title'], 0, 35)) ?></div>
                        <div class="notice-content small mt-1"><?= htmlspecialchars(mb_substr(strip_tags($notice['content']), 0, 70)) ?></div>
                        <div class="notice-date small text-muted mt-2"><i class="far fa-clock"></i> <?= formatDate($notice['created_at']) ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="footer">
        <p class="mb-0">&copy; <?= date('Y') ?> <?= htmlspecialchars($institutionName) ?>. <?= __('all_rights_reserved') ?></p>
        <p class="small mt-2 opacity-75"><?= __('designed_by') ?> <a href="https://www.linkedin.com/in/sameermon-m-559692186" target="_blank" rel="noopener noreferrer">Sameermon</a></p>
    </div>
</div>

<?php
$whatsappNumber = $settings['whatsapp_number'] ?? '';
$whatsappMessage = urlencode($settings['whatsapp_message'] ?? 'Hello, I need assistance from the library.');
if (!empty($whatsappNumber)):
?>
<a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsappNumber) ?>?text=<?= $whatsappMessage ?>" class="whatsapp-float" target="_blank">
    <i class="fab fa-whatsapp"></i>
</a>
<?php endif; ?>

<!-- Hidden Webcam Elements -->
<div style="display: none;">
    <video id="webcamVideo" autoplay playsinline></video>
    <canvas id="webcamCanvas"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
const scanInput = document.getElementById('scanInput');
const resultDiv = document.getElementById('resultArea');
const contentContainer = document.getElementById('contentContainer');
const cooldownMsg = document.getElementById('cooldownMessage');
const purposeSelect = document.getElementById('purposeSelect');
const customPurposeDiv = document.getElementById('customPurposeDiv');
const customPurposeInput = document.getElementById('customPurpose');
let isProcessing = false, cooldownTimer = null, scanTimeout = null, displayTimeout = null;
let lastScannedMember = null; // store last member admno for linking book exit

const defaultAvatar = "<?= getDefaultAvatarBase64() ?>";
const carouselType = "<?= $visitorCarouselType ?>";
const enableWebcam = <?= $enableWebcam ? 'true' : 'false' ?>;
let webcamStream = null;

function escapeHtml(str) { if (!str) return ''; return str.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;')); }
function getFirstName(fullName) { if (!fullName) return ''; let parts = fullName.trim().split(/\s+/); return parts[0]; }

// ===== WEBCAM =====
function startWebcam() {
    if (!enableWebcam) return;
    const video = document.getElementById('webcamVideo');
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false })
        .then(stream => {
            webcamStream = stream;
            video.srcObject = stream;
            video.play();
        })
        .catch(err => console.warn('Webcam not accessible:', err));
    }
}

function capturePhoto() {
    return new Promise((resolve) => {
        if (!enableWebcam) { resolve(null); return; }
        const video = document.getElementById('webcamVideo');
        const canvas = document.getElementById('webcamCanvas');
        if (!video || !video.srcObject) { resolve(null); return; }
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        resolve(dataUrl);
    });
}

function stopWebcam() {
    if (webcamStream) {
        webcamStream.getTracks().forEach(track => track.stop());
        webcamStream = null;
        const video = document.getElementById('webcamVideo');
        video.srcObject = null;
    }
}

// ===== SOUND ALERT =====
function playAlertSound() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'square';
        oscillator.frequency.value = 800;
        gainNode.gain.value = 0.3;
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
        setTimeout(() => { oscillator.stop(); }, 200);
        setTimeout(() => {
            const osc2 = audioCtx.createOscillator();
            const gain2 = audioCtx.createGain();
            osc2.type = 'square';
            osc2.frequency.value = 1000;
            gain2.gain.value = 0.3;
            osc2.connect(gain2);
            gain2.connect(audioCtx.destination);
            osc2.start();
            setTimeout(() => { osc2.stop(); }, 200);
        }, 300);
    } catch (e) {
        console.warn('Audio not supported');
    }
}

function showToast(message, type) {
    let toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3 shadow-lg`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '280px';
    toast.style.borderRadius = '50px';
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'} me-2"></i> ${message}<button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}

purposeSelect.addEventListener('change', function() {
    if (this.value === 'other') {
        customPurposeDiv.style.display = 'block';
        customPurposeInput.focus();
    } else {
        customPurposeDiv.style.display = 'none';
        customPurposeInput.value = '';
    }
});

function getSelectedPurpose() {
    const selectedValue = purposeSelect.value;
    if (selectedValue === 'other') {
        const custom = customPurposeInput.value.trim();
        if (custom !== '') return custom;
        return purposeSelect.options[purposeSelect.selectedIndex]?.text || '<?= __('purpose_reading') ?>';
    }
    return purposeSelect.options[purposeSelect.selectedIndex]?.text || '<?= __('purpose_reading') ?>';
}

async function fetchMemberInfo(admno) { 
    const res = await fetch(`?ajax=get_member&admno=${encodeURIComponent(admno)}`); 
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json(); 
}

async function toggleStatus(admno, purpose, customPurpose) {
    const formData = new URLSearchParams();
    formData.append('admno', admno);
    formData.append('purpose', purpose);
    if (customPurpose) formData.append('custom_purpose', customPurpose);
    const res = await fetch(`?ajax=toggle`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: formData });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
}

// ===== BOOK FUNCTIONS (enhanced) =====
async function checkBook(barcode) {
    const res = await fetch(`?ajax=check_book&barcode=${encodeURIComponent(barcode)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
}

async function logBookExit(barcode, isAuthorized, memberAdmno = '', memberName = '') {
    let photoData = null;
    if (enableWebcam) {
        photoData = await capturePhoto();
    }
    const formData = new URLSearchParams();
    formData.append('barcode', barcode);
    formData.append('is_authorized', isAuthorized ? 1 : 0);
    formData.append('member_admno', memberAdmno);
    formData.append('member_name', memberName);
    if (photoData) formData.append('photo_data', photoData);
    const res = await fetch('?ajax=log_book_exit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
}

// Show result area and hide content container
function showResultAndHideContent() {
    if (displayTimeout) clearTimeout(displayTimeout);
    contentContainer.classList.add('hidden');
    resultDiv.classList.remove('hidden');
    resultDiv.classList.add('visible');
}

// Hide result and show content after delay
function scheduleRevertToContent(delay = 5000) {
    if (displayTimeout) clearTimeout(displayTimeout);
    displayTimeout = setTimeout(() => {
        resultDiv.classList.remove('visible');
        resultDiv.classList.add('hidden');
        contentContainer.classList.remove('hidden');
        // Clear result content after fade out
        setTimeout(() => {
            if (!resultDiv.classList.contains('visible')) {
                resultDiv.innerHTML = '';
            }
        }, 500);
        displayTimeout = null;
    }, delay);
}

// Reset display (on error, etc.)
function resetDisplay() {
    if (displayTimeout) clearTimeout(displayTimeout);
    resultDiv.classList.remove('visible');
    resultDiv.classList.add('hidden');
    contentContainer.classList.remove('hidden');
    setTimeout(() => { resultDiv.innerHTML = ''; }, 300);
}

// ===== GUEST FUNCTIONS =====
async function guestEntry() {
    if (isProcessing) return;
    isProcessing = true;
    resultDiv.innerHTML = `<div class="text-center"><div class="spinner-border text-primary spinner-border-sm"></div> <?= __('processing') ?></div>`;
    showResultAndHideContent();
    try {
        const res = await fetch('?ajax=guest_entry');
        const data = await res.json();
        if (data.success) {
            // Display guest details directly (without calling processScan again)
            const guestId = data.guest_id;
            const guestNumber = data.guest_number;
            const guestName = `<?= __('guest') ?> ${guestNumber}`;
            const greetingHtml = `<div class="greeting-message greeting-welcome"><i class="fas fa-hand-peace"></i> <?= __('welcome') ?> ${escapeHtml(guestName)} <?= __('to_library') ?> 👋</div>`;
            const photoHtml = `<img src="${defaultAvatar}" class="member-photo" alt="Guest Avatar">`;
            resultDiv.innerHTML = `
                <div class="visitor-details-card text-center p-3 bg-light rounded-4">
                    ${greetingHtml}
                    ${photoHtml}
                    <h5 class="mt-2 mb-1">${escapeHtml(guestName)}</h5>
                    <div><span class="badge-category">Guest</span></div>
                    <div class="mt-1 small"><i class="fas fa-id-card"></i> ${escapeHtml(guestId)}</div>
                    <div class="mt-1 small text-muted"><i class="fas fa-tag"></i> Purpose: <?= __('purpose_reading') ?></div>
                </div>
            `;
            showToast(data.message, 'success');
            loadStats();
            refreshRecentActivity();
            refreshPurposeStats();
            scanInput.value = '';
            startCooldown();
            scheduleRevertToContent(5000);
        } else {
            resultDiv.innerHTML = `<div class="alert alert-danger text-center">${escapeHtml(data.error || '<?= __('operation_failed') ?>')}</div>`;
            scheduleRevertToContent(4000);
        }
    } catch (err) {
        resultDiv.innerHTML = `<div class="alert alert-danger text-center"><?= __('network_error') ?></div>`;
        scheduleRevertToContent(4000);
    } finally {
        isProcessing = false;
    }
}

async function guestExitLast() {
    if (isProcessing) return;
    isProcessing = true;
    try {
        const res = await fetch('?ajax=guest_exit_last');
        const data = await res.json();
        if (data.success) {
            showToast(data.message, 'success');
            loadStats();
            refreshRecentActivity();
            refreshPurposeStats();
            resultDiv.innerHTML = `<div class="alert alert-info text-center">${escapeHtml(data.message)}</div>`;
            showResultAndHideContent();
            scheduleRevertToContent(3000);
        } else {
            showToast(data.error || '<?= __('operation_failed') ?>', 'danger');
        }
    } catch (err) {
        showToast('<?= __('network_error') ?>', 'danger');
    } finally {
        isProcessing = false;
    }
}

// ===== LIVE STATS =====
async function loadStats() {
    try {
        const res = await fetch('?ajax=stats');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        let catHtml = '';
        for (let [cat, cnt] of Object.entries(data.categoryStats)) {
            catHtml += `<div class="d-flex justify-content-between small"><span>${escapeHtml(cat)}</span><span class="fw-bold">${cnt}</span></div>`;
        }
        let guestsHtml = '';
        if (data.activeGuests && data.activeGuests.length > 0) {
            guestsHtml = '<div class="mt-2"><strong><?= __('active_guests') ?>:</strong><div class="guest-list">';
            data.activeGuests.forEach(g => {
                guestsHtml += `<div class="guest-list-item small"><i class="fas fa-user-friends"></i> ${escapeHtml(g.member_name)}</div>`;
            });
            guestsHtml += '</div></div>';
        }
        
        const html = `
            <div class="stat-card-inner d-flex justify-content-between align-items-center">
                <span class="stat-label"><i class="fas fa-building fa-fw text-success me-2"></i> <?= __('currently_inside') ?></span>
                <span class="stat-number">${data.insideCount}</span>
            </div>
            <div class="stat-card-inner d-flex justify-content-between align-items-center">
                <span class="stat-label"><i class="fas fa-calendar-day text-primary me-2"></i> <?= __('visitors_today') ?></span>
                <span class="stat-number">${data.todayVisitors}</span>
            </div>
            <div class="stat-card-inner">
                <div class="d-flex justify-content-between"><span><i class="fas fa-mars text-primary me-2"></i> <?= __('male') ?></span><strong class="fs-5">${data.maleCount}</strong></div>
                <div class="d-flex justify-content-between"><span><i class="fas fa-venus text-danger me-2"></i> <?= __('female') ?></span><strong class="fs-5">${data.femaleCount}</strong></div>
                <div class="d-flex justify-content-between"><span><i class="fas fa-genderless text-secondary me-2"></i> <?= __('other') ?></span><strong class="fs-5">${data.otherCount}</strong></div>
            </div>
            <div class="stat-card-inner">
                <div><i class="fas fa-chart-pie text-warning me-2"></i> <?= __('inside_by_category') ?></div>
                ${catHtml ? '<div class="mt-1 small">' + catHtml + '</div>' : '<span class="text-muted"><?= __('none') ?></span>'}
                ${guestsHtml}
            </div>`;
        document.getElementById('statsArea').innerHTML = html;
    } catch (err) { 
        console.error('Stats error:', err);
        document.getElementById('statsArea').innerHTML = '<div class="alert alert-danger small"><?= __('network_error') ?></div>';
    }
}

async function refreshRecentActivity() {
    try {
        const res = await fetch('?ajax=get_recent_activity');
        const data = await res.json();
        if (data.success && data.activities.length) {
            let html = '';
            data.activities.forEach(act => {
                let timeDisplay = act.action_time;
                const actionClass = act.action_type === 'entry' ? 'badge-entry' : 'badge-exit';
                const actionIcon = act.action_type === 'entry' ? 'fa-sign-in-alt' : 'fa-sign-out-alt';
                html += `
                    <div class="activity-item">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="badge ${actionClass} me-2"><i class="fas ${actionIcon}"></i> ${act.action_type === 'entry' ? 'IN' : 'OUT'}</span>
                                <strong>${escapeHtml(act.member_name)}</strong>
                            </div>
                            <small class="text-muted">${escapeHtml(timeDisplay)}</small>
                        </div>
                        <div class="small text-muted mt-1">🎯 ${escapeHtml(act.purpose)}</div>
                    </div>`;
            });
            document.getElementById('recentActivityList').innerHTML = html;
        } else {
            document.getElementById('recentActivityList').innerHTML = `<div class="text-center text-muted py-3"><i class="fas fa-history"></i> <?= __('recent_activity_empty') ?></div>`;
        }
    } catch (err) {
        document.getElementById('recentActivityList').innerHTML = `<div class="alert alert-danger small">Error loading activity</div>`;
    }
}

async function refreshPurposeStats() {
    try {
        const res = await fetch('?ajax=get_purpose_stats');
        const data = await res.json();
        if (data.success && data.purposes.length) {
            let total = data.purposes.reduce((sum, p) => sum + p.count, 0);
            let html = '';
            data.purposes.forEach(p => {
                let percent = total > 0 ? (p.count / total * 100).toFixed(1) : 0;
                html += `
                    <div class="col-md-4 col-sm-6">
                        <div class="d-flex justify-content-between small fw-semibold"><span>${escapeHtml(p.purpose)}</span><span>${p.count} (${percent}%)</span></div>
                        <div class="progress-purpose mt-1 mb-2"><div class="progress-bar-purpose" style="width: ${percent}%; height: 6px;"></div></div>
                    </div>`;
            });
            document.getElementById('purposeStatsContainer').innerHTML = html;
        } else {
            document.getElementById('purposeStatsContainer').innerHTML = `<div class="col-12 text-center text-muted">No data for today.</div>`;
        }
    } catch (err) {
        document.getElementById('purposeStatsContainer').innerHTML = `<div class="col-12 alert alert-danger small">Error loading stats</div>`;
    }
}

// Quote refresh
const quotesList = <?php echo json_encode($quotes); ?>;
function refreshQuote() {
    if (quotesList.length === 0) return;
    const random = Math.floor(Math.random() * quotesList.length);
    const quote = quotesList[random];
    document.getElementById('quoteContainer').innerHTML = `
        <div class="quote-text">${escapeHtml(quote.text)}</div>
        <div class="quote-author">— ${escapeHtml(quote.author || '<?= __('quote_author_unknown') ?>')}</div>
    `;
}
document.getElementById('refreshQuoteBtn')?.addEventListener('click', refreshQuote);

function startCooldown() {
    scanInput.disabled = true;
    cooldownMsg.innerHTML = '<?= __('please_wait') ?>';
    if (cooldownTimer) clearTimeout(cooldownTimer);
    cooldownTimer = setTimeout(() => { 
        scanInput.disabled = false; 
        cooldownMsg.innerHTML = ''; 
        scanInput.focus(); 
    }, 500);
}

// ===== PROCESS SCAN (INTEGRATED – RFIDs like) =====
async function processScan(barcode, isGuest = false) {
    if (isProcessing) return;
    if (scanInput.disabled) { showToast('<?= __('please_wait') ?>', 'warning'); return; }
    barcode = barcode.trim();
    if (barcode.length < 2) { 
        resultDiv.innerHTML = `<div class="alert alert-warning text-center"><?= __('valid_id') ?></div>`;
        showResultAndHideContent();
        scheduleRevertToContent(3000);
        return; 
    }
    
    // Step 1: Check if it's a book
    let bookCheck;
    try {
        bookCheck = await checkBook(barcode);
    } catch (err) {
        showToast('Network error checking book', 'danger');
        return;
    }
    
    if (bookCheck.is_book) {
        // It's a book – handle book exit and member exit if issued
        const book = bookCheck.book;
        const isAuthorized = bookCheck.is_authorized;
        const loanMember = bookCheck.loan_member;
        const loanMemberName = bookCheck.loan_member_name;
        const member = bookCheck.member; // full member data if issued
        
        // Display book and member details
        let alertClass = isAuthorized ? 'authorized' : 'unauthorized';
        let alertIcon = isAuthorized ? '✅' : '⚠️';
        let alertTitle = isAuthorized ? '<?= __('book_authorized') ?>' : '<?= __('book_unauthorized') ?>';
        
        let memberHtml = '';
        if (isAuthorized && member) {
            const photoHtml = member.photo_base64 ? 
                `<img src="${member.photo_base64}" class="member-photo" style="width:120px;height:120px;border-radius:50%;margin:10px auto;">` : 
                `<img src="${defaultAvatar}" class="member-photo" style="width:120px;height:120px;border-radius:50%;margin:10px auto;">`;
            memberHtml = `
                <div class="text-center">
                    ${photoHtml}
                    <div><strong>${escapeHtml(member.name)}</strong> (${escapeHtml(member.admno)})</div>
                    <div class="small text-muted">${escapeHtml(member.member_category)}</div>
                </div>
            `;
        }
        
        let bookHtml = `
            <div class="book-alert ${alertClass}">
                <div class="d-flex align-items-center">
                    <span style="font-size:2rem;margin-right:12px;">${alertIcon}</span>
                    <div>
                        <div class="book-details">${escapeHtml(book.title)}</div>
                        <div class="book-meta">${escapeHtml(book.author || 'Unknown Author')} | ${escapeHtml(book.barcode)}</div>
                        <div class="book-meta"><strong>Status:</strong> ${alertTitle}</div>
                        ${isAuthorized ? `<div class="book-meta"><strong><?= __('book_issued_to') ?>:</strong> ${escapeHtml(loanMemberName)} (${escapeHtml(loanMember)})</div>` : ''}
                        ${isAuthorized ? '' : '<div class="book-meta text-danger"><i class="fas fa-exclamation-triangle"></i> This book is not issued – unauthorized exit!</div>'}
                    </div>
                </div>
                ${memberHtml}
            </div>
        `;
        
        // Play sound alert if unauthorized
        if (!isAuthorized) {
            playAlertSound();
        }
        
        // Show result
        resultDiv.innerHTML = bookHtml;
        showResultAndHideContent();
        
        // Log the book exit
        try {
            const logResult = await logBookExit(barcode, isAuthorized, loanMember, loanMemberName);
            if (logResult.success) {
                showToast('Book exit logged' + (isAuthorized ? ' (authorized)' : ' (⚠️ unauthorized)'), isAuthorized ? 'success' : 'danger');
            } else {
                showToast('Failed to log book exit', 'danger');
            }
        } catch (err) {
            showToast('Error logging book exit', 'danger');
        }
        
        // If book is issued, also exit the member (RFID-like)
        if (isAuthorized && loanMember) {
            try {
                const memberInfo = await fetchMemberInfo(loanMember);
                if (memberInfo.is_inside) {
                    const purpose = 'Book Exit (Auto)';
                    const toggleResult = await toggleStatus(loanMember, purpose, '');
                    if (toggleResult.success) {
                        showToast('<?= __('member_exited') ?>: ' + escapeHtml(loanMemberName), 'success');
                        loadStats();
                        refreshRecentActivity();
                        refreshPurposeStats();
                    } else {
                        showToast('Failed to exit member: ' + toggleResult.message, 'danger');
                    }
                } else {
                    showToast('<?= __('member_not_inside') ?>', 'warning');
                }
            } catch (err) {
                console.error('Error exiting member:', err);
                showToast('Error processing member exit', 'danger');
            }
        }
        
        // Reset and schedule revert
        scanInput.value = '';
        startCooldown();
        scheduleRevertToContent(7000);
        return;
    }
    
    // Not a book – treat as member/guest (normal toggle)
    let purpose = getSelectedPurpose();
    let customPurpose = (purposeSelect.value === 'other') ? customPurposeInput.value.trim() : '';
    
    isProcessing = true;
    resultDiv.innerHTML = `<div class="text-center"><div class="spinner-border text-primary spinner-border-sm"></div> <?= __('processing') ?></div>`;
    showResultAndHideContent();
    
    try {
        const info = await fetchMemberInfo(barcode);
        if (info.error) { 
            resultDiv.innerHTML = `<div class="alert alert-danger text-center">${escapeHtml(info.error)}</div>`;
            scheduleRevertToContent(4000);
            isProcessing = false; 
            return; 
        }
        const m = info.member;
        const toggleResult = await toggleStatus(barcode, purpose, customPurpose);
        if (!toggleResult.success) { 
            resultDiv.innerHTML = `<div class="alert alert-danger text-center">${escapeHtml(toggleResult.error || '<?= __('operation_failed') ?>')}</div>`;
            scheduleRevertToContent(4000);
            isProcessing = false; 
            return; 
        }
        
        // Store as last scanned member (for linking to book)
        lastScannedMember = m.admno;
        
        const newStatus = toggleResult.action;
        const fullName = toggleResult.member_name || m.name;
        const firstName = getFirstName(fullName);
        const isEntry = newStatus === 'entry';
        
        let greetingHtml = '';
        if (isEntry) greetingHtml = `<div class="greeting-message greeting-welcome"><i class="fas fa-hand-peace"></i> <?= __('welcome') ?> ${escapeHtml(firstName)} <?= __('to_library') ?> 👋</div>`;
        else greetingHtml = `<div class="greeting-message greeting-thanks"><i class="fas fa-smile-wink"></i> <?= __('thank_you') ?> ${escapeHtml(firstName)} 🙏</div>`;
        
        let photoHtml = m.photo_base64 ? `<img src="${m.photo_base64}" class="member-photo" alt="Member Photo">` : `<img src="${defaultAvatar}" class="member-photo" alt="Default Avatar">`;
        let genderIcon = '';
        if (m.gender === 'Male') genderIcon = '<i class="fas fa-mars text-primary"></i>';
        else if (m.gender === 'Female') genderIcon = '<i class="fas fa-venus text-danger"></i>';
        
        resultDiv.innerHTML = `
            <div class="visitor-details-card text-center p-3 bg-light rounded-4">
                ${greetingHtml}
                ${photoHtml}
                <h5 class="mt-2 mb-1">${escapeHtml(m.name)} ${genderIcon}</h5>
                <div><span class="badge-category">${escapeHtml(m.member_category)}</span></div>
                <div class="mt-1 small"><i class="fas fa-id-card"></i> ${escapeHtml(m.admno)}</div>
                <div class="mt-1 small text-muted"><i class="fas fa-tag"></i> Purpose: ${escapeHtml(purpose)}</div>
            </div>
        `;
        showToast(isEntry ? 'Entry recorded' : 'Exit recorded', 'success');
        loadStats();
        refreshRecentActivity();
        refreshPurposeStats();
        scanInput.value = '';
        startCooldown();
        scheduleRevertToContent(5000);
    } catch (err) { 
        console.error('Process error:', err);
        resultDiv.innerHTML = '<div class="alert alert-danger text-center"><?= __('network_error') ?></div>';
        scheduleRevertToContent(4000);
    } finally { isProcessing = false; }
}

scanInput.addEventListener('input', function(e) {
    const val = this.value.trim();
    if (val.length < 2) return;
    if (scanTimeout) clearTimeout(scanTimeout);
    // Increased delay from 80ms to 500ms for manual typing
    scanTimeout = setTimeout(() => processScan(val), 500);
});
scanInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        if (scanTimeout) clearTimeout(scanTimeout);
        processScan(this.value.trim());
    }
});

const guestEntryBtn = document.getElementById('guestEntryBtn');
if (guestEntryBtn) guestEntryBtn.addEventListener('click', guestEntry);
const guestExitBtn = document.getElementById('guestExitBtn');
if (guestExitBtn) guestExitBtn.addEventListener('click', guestExitLast);

function initCarousels() {
    const autoplayConfig = { delay: 4000, disableOnInteraction: false, pauseOnMouseEnter: true };
    const breakpoints = { 0: { slidesPerView: 2 }, 480: { slidesPerView: 3 }, 768: { slidesPerView: 4 }, 1024: { slidesPerView: 5 } };
    
    let baseConfig = {
        slidesPerView: 'auto',
        spaceBetween: 20,
        loop: true,
        autoplay: autoplayConfig,
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        pagination: { el: '.swiper-pagination', clickable: true },
        breakpoints: breakpoints,
        grabCursor: true,
        lazy: { loadPrevNext: true, loadPrevNextAmount: 2 },
        preloadImages: false
    };
    
    switch(carouselType) {
        case 'cover_flow':
            baseConfig.effect = 'coverflow';
            baseConfig.coverflowEffect = { rotate: 35, stretch: 10, depth: 150, modifier: 1.5, slideShadows: true };
            baseConfig.centeredSlides = true;
            baseConfig.slidesPerView = 'auto';
            break;
        case 'cube':
            baseConfig.effect = 'cube';
            baseConfig.cubeEffect = { shadow: true, slideShadows: true, shadowOffset: 20, shadowScale: 0.94 };
            baseConfig.centeredSlides = true;
            break;
        case 'fade':
            baseConfig.effect = 'fade';
            baseConfig.fadeEffect = { crossFade: true };
            break;
        case 'cards':
            baseConfig.effect = 'cards';
            baseConfig.cardsEffect = { slideShadows: true };
            baseConfig.centeredSlides = true;
            break;
        case 'creative':
            baseConfig.effect = 'creative';
            baseConfig.creativeEffect = { prev: { shadow: true, translate: [0, 0, -400] }, next: { translate: ['100%', 0, 0] } };
            break;
        default:
            baseConfig.effect = 'slide';
            break;
    }
    
    // Main carousels (eBooks and Notices)
    if (document.querySelector('.swiper-popular-ebooks')) new Swiper('.swiper-popular-ebooks', baseConfig);
    if (document.querySelector('.swiper-notices')) new Swiper('.swiper-notices', baseConfig);
    
    // Scanner New Arrivals carousel – smaller, separate config
    if (document.querySelector('.swiper-scanner-new-arrivals')) {
        const smallConfig = {
            slidesPerView: 'auto',
            spaceBetween: 15,
            loop: true,
            autoplay: { delay: 4000, disableOnInteraction: false, pauseOnMouseEnter: true },
            navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
            pagination: { el: '.swiper-pagination', clickable: true },
            grabCursor: true,
            breakpoints: {
                0: { slidesPerView: 2 },
                480: { slidesPerView: 3 },
                768: { slidesPerView: 4 },
                1024: { slidesPerView: 5 }
            }
        };
        if (carouselType === 'cover_flow') {
            smallConfig.effect = 'coverflow';
            smallConfig.coverflowEffect = { rotate: 20, stretch: 5, depth: 80, modifier: 1, slideShadows: true };
            smallConfig.centeredSlides = true;
        }
        new Swiper('.swiper-scanner-new-arrivals', smallConfig);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    initCarousels();
    loadStats();
    refreshRecentActivity();
    refreshPurposeStats();
    setInterval(() => { loadStats(); refreshRecentActivity(); refreshPurposeStats(); }, 8000);
    scanInput.focus();
    startWebcam();
});
</script>
</body>
</html>