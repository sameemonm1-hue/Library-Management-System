<?php
session_start();
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$db = getDB();
$stmt = $db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'");
$inside = $stmt->fetchColumn();

$maxCapacity = 100; // Set your library's maximum capacity
$available = $maxCapacity - $inside;

echo json_encode([
    'inside' => (int)$inside,
    'capacity' => $maxCapacity,
    'available' => $available,
    'percentage' => round(($inside / $maxCapacity) * 100, 1)
]);