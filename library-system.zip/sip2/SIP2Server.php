#!/usr/bin/env php
<?php
/**
 * SIP2 Server for Library Self‑Checkout
 * 
 * Listens on TCP port (default 6001) and handles SIP2 messages:
 * - 93 (Checkout)
 * - 95 (Checkin)
 * - 63 (Patron Information)
 * 
 * Usage:
 *   php sip2/SIP2Server.php [start|stop|restart|status]
 * 
 * Dependencies:
 *   - PHP sockets extension
 *   - Existing library functions: getMemberByAdmno(), getBookByBarcode(), 
 *     issueBook(), returnBook(), calculateFine()
 * 
 * @author Library ERP
 * @version 1.0
 */

// ==================== CONFIGURATION ====================
$config = [
    'host' => '0.0.0.0',
    'port' => 6001,
    'max_clients' => 5,
    'timeout' => 30,           // seconds
    'pid_file' => __DIR__ . '/sip2.pid',
    'log_file' => __DIR__ . '/sip2.log',
    'institution_id' => 'LIBRARY',
    'terminal_id' => '001'
];

// ==================== BOOTSTRAP ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';

// ==================== LOGGING FUNCTION ====================
function sip2_log($message, $level = 'INFO') {
    global $config;
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] [$level] $message" . PHP_EOL;
    file_put_contents($config['log_file'], $logEntry, FILE_APPEND);
    // Also echo if running in foreground
    if (php_sapi_name() === 'cli') {
        echo $logEntry;
    }
}

// ==================== SIP2 MESSAGE PARSING ====================
/**
 * Parse a SIP2 message (fixed fields + variable fields)
 * 
 * @param string $message Raw SIP2 message (without checksum)
 * @return array Associative array with 'command', 'fields', 'raw'
 */
function parseSip2Message($message) {
    $result = [
        'command' => substr($message, 0, 2),
        'fields' => [],
        'raw' => $message
    ];
    
    // Remove command code and checksum (last 3 chars: '|' + 2 hex digits)
    $content = substr($message, 2, -3);
    $parts = explode('|', $content);
    
    foreach ($parts as $part) {
        if (strlen($part) < 2) continue;
        $code = $part[0];
        $value = substr($part, 1);
        $result['fields'][$code] = $value;
    }
    
    return $result;
}

/**
 * Build a SIP2 response with checksum
 * 
 * @param string $data Response data (without checksum)
 * @return string Full response with checksum
 */
function buildSip2Response($data) {
    // Calculate checksum (XOR of all characters including the final checksum placeholder)
    $checksum = 0;
    for ($i = 0; $i < strlen($data); $i++) {
        $checksum ^= ord($data[$i]);
    }
    $checksumHex = strtoupper(str_pad(dechex($checksum), 2, '0', STR_PAD_LEFT));
    return $data . $checksumHex . "\r";
}

// ==================== COMMAND HANDLERS ====================
/**
 * Handle SIP2 93 – Checkout (Issue book)
 * 
 * Expected fields:
 *   AO – Institution ID
 *   AA – Patron ID (admno)
 *   AB – Item ID (barcode)
 *   AC – Terminal Password (optional)
 *   AD – Patron Password (optional)
 * 
 * Response: 94 (Checkout Response)
 */
function handleCheckout($fields) {
    $patronId = $fields['AA'] ?? '';
    $itemId = $fields['AB'] ?? '';
    
    if (empty($patronId) || empty($itemId)) {
        return buildSip2Response("941" . "UY" . "AOE");
    }
    
    // Get member and book
    $member = getMemberByAdmno($patronId);
    if (!$member || $member['status'] !== 'active') {
        return buildSip2Response("940" . "UY" . "AOE");
    }
    
    $book = getBookByBarcode($itemId);
    if (!$book || $book['available'] <= 0) {
        return buildSip2Response("940" . "UY" . "AB$itemId" . "AOE");
    }
    
    // Issue book (use existing circulation logic)
    $settings = getSettings();
    $loanDays = $settings['loan_days'] ?? 7;
    $dueDate = date('Y-m-d', strtotime("+$loanDays days"));
    
    $db = getDB();
    $db->beginTransaction();
    try {
        // Insert into circulation
        $stmt = $db->prepare("INSERT INTO circulation (admno, member_name, barcode, title, author, issue_date, due_date, is_manual) 
                              VALUES (?, ?, ?, ?, ?, CURDATE(), ?, 0)");
        $stmt->execute([
            $member['admno'], $member['name'], $book['barcode'], $book['title'], 
            $book['author'] ?? '', $dueDate
        ]);
        
        // Update book availability
        $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$book['barcode']]);
        
        // Update member active books
        $db->prepare("UPDATE members SET active_books = active_books + 1, total_issued = total_issued + 1 WHERE admno = ?")->execute([$member['admno']]);
        
        $db->commit();
        
        // Build success response
        $response = "941" 
                  . "Y"                     // OK flag
                  . "UY"                    // renewal OK (not applicable)
                  . "AB$itemId|AJ$book[title]|AH$dueDate|AOE";
        return buildSip2Response($response);
        
    } catch (Exception $e) {
        $db->rollBack();
        sip2_log("Checkout error: " . $e->getMessage(), 'ERROR');
        return buildSip2Response("940" . "UY" . "AOE");
    }
}

/**
 * Handle SIP2 95 – Checkin (Return book)
 * 
 * Expected fields:
 *   AO – Institution ID
 *   AB – Item ID (barcode)
 *   AC – Terminal Password (optional)
 *   AP – Return Date (optional)
 * 
 * Response: 96 (Checkin Response)
 */
function handleCheckin($fields) {
    $itemId = $fields['AB'] ?? '';
    
    if (empty($itemId)) {
        return buildSip2Response("960" . "UY" . "AOE");
    }
    
    $db = getDB();
    
    // Find active circulation record
    $stmt = $db->prepare("SELECT * FROM circulation WHERE barcode = ? AND return_date IS NULL");
    $stmt->execute([$itemId]);
    $record = $stmt->fetch();
    
    if (!$record) {
        return buildSip2Response("960" . "UY" . "AB$itemId" . "AOE");
    }
    
    // Calculate fine (if any)
    $fine = calculateFine($record['due_date'], $record['member_category'] ?? 'Student');
    
    // Update return
    $db->beginTransaction();
    try {
        $db->prepare("UPDATE circulation SET return_date = CURDATE(), fine = fine + ? WHERE id = ?")->execute([$fine, $record['id']]);
        $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$itemId]);
        $db->prepare("UPDATE members SET active_books = active_books - 1, total_fines = total_fines + ? WHERE admno = ?")->execute([$fine, $record['admno']]);
        $db->commit();
        
        // Build response
        $response = "961" 
                  . "Y"                     // OK flag
                  . "UY"                    // resensitize flag
                  . "AB$itemId|AQ$fine|AOE";
        return buildSip2Response($response);
        
    } catch (Exception $e) {
        $db->rollBack();
        sip2_log("Checkin error: " . $e->getMessage(), 'ERROR');
        return buildSip2Response("960" . "UY" . "AOE");
    }
}

/**
 * Handle SIP2 63 – Patron Information
 * 
 * Expected fields:
 *   AO – Institution ID
 *   AA – Patron ID (admno)
 *   AC – Terminal Password (optional)
 *   AD – Patron Password (optional)
 * 
 * Response: 64 (Patron Information Response)
 */
function handlePatronInfo($fields) {
    $patronId = $fields['AA'] ?? '';
    
    if (empty($patronId)) {
        return buildSip2Response("640" . "UY" . "AOE");
    }
    
    $member = getMemberByAdmno($patronId);
    if (!$member || $member['status'] !== 'active') {
        return buildSip2Response("640" . "UY" . "AOE");
    }
    
    // Get active loans count
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM circulation WHERE admno = ? AND return_date IS NULL");
    $stmt->execute([$member['admno']]);
    $activeLoans = (int)$stmt->fetchColumn();
    
    // Get hold items count
    $stmt = $db->prepare("SELECT COUNT(*) FROM book_holds WHERE admno = ? AND status = 'available'");
    $stmt->execute([$member['admno']]);
    $holdItems = (int)$stmt->fetchColumn();
    
    // Build response (simplified)
    // Format: 64 [patron status flags] [language] [transaction date] [hold items count] [overdue items count] [fines] [fee limit] [patron id] [personal name] [home address] [phone] [email]
    $patronStatus = "Y" . ($activeLoans > 0 ? "Y" : "N") . "N" . "N"; // valid patron, charge ok, renewal ok, recall ok
    $language = "000"; // unknown
    $date = date('Ymd    Hms'); // YYYYMMDD    HHMMSS (note spaces)
    $overdueCount = 0; // can calculate if needed
    
    $response = "64"
              . $patronStatus
              . "Y" . $language . $date
              . "AH" . str_pad($holdItems, 4, '0', STR_PAD_LEFT)
              . "BV" . str_pad($overdueCount, 4, '0', STR_PAD_LEFT)
              . "BH" . str_pad($member['total_fines'] * 100, 8, '0', STR_PAD_LEFT) // fine in cents
              . "AA" . $member['admno']
              . "AE" . $member['name']
              . "AQ" . "999999" // fee limit
              . "AOE";
    
    return buildSip2Response($response);
}

// ==================== MAIN SERVER LOOP ====================
$running = true;
$socket = null;

function signalHandler($signo) {
    global $running, $socket;
    sip2_log("Received signal $signo, shutting down...", 'INFO');
    $running = false;
    if ($socket) {
        @stream_socket_shutdown($socket, STREAM_SHUT_RDWR);
    }
    exit(0);
}

// Setup signal handlers (for UNIX systems)
if (function_exists('pcntl_signal')) {
    pcntl_signal(SIGTERM, 'signalHandler');
    pcntl_signal(SIGINT, 'signalHandler');
    pcntl_signal(SIGHUP, 'signalHandler');
}

// Parse command line arguments for daemon control
$action = $argv[1] ?? 'start';

$pidFile = $config['pid_file'];

function isRunning() {
    global $pidFile;
    if (!file_exists($pidFile)) return false;
    $pid = (int)file_get_contents($pidFile);
    if (posix_kill($pid, 0)) return true;
    unlink($pidFile);
    return false;
}

if ($action === 'start') {
    if (isRunning()) {
        echo "SIP2 server is already running.\n";
        exit(1);
    }
    
    // Daemonize (fork)
    $pid = pcntl_fork();
    if ($pid == -1) {
        die("Could not fork process\n");
    } elseif ($pid) {
        // Parent exits
        exit(0);
    }
    // Child becomes daemon
    posix_setsid();
    chdir('/');
    umask(0);
    
    // Save PID
    file_put_contents($pidFile, getmypid());
    
    sip2_log("SIP2 server starting on {$config['host']}:{$config['port']}", 'INFO');
} elseif ($action === 'stop') {
    if (!isRunning()) {
        echo "SIP2 server is not running.\n";
        exit(1);
    }
    $pid = (int)file_get_contents($pidFile);
    posix_kill($pid, SIGTERM);
    // Wait for process to exit
    while (isRunning()) { usleep(100000); }
    unlink($pidFile);
    echo "SIP2 server stopped.\n";
    exit(0);
} elseif ($action === 'restart') {
    system(__FILE__ . ' stop');
    system(__FILE__ . ' start');
    exit(0);
} elseif ($action === 'status') {
    if (isRunning()) {
        echo "SIP2 server is running.\n";
    } else {
        echo "SIP2 server is not running.\n";
    }
    exit(0);
} elseif ($action !== 'start') {
    echo "Usage: php sip2/SIP2Server.php {start|stop|restart|status}\n";
    exit(1);
}

// Create socket server
$context = stream_context_create();
$socket = stream_socket_server(
    "tcp://{$config['host']}:{$config['port']}",
    $errno,
    $errstr,
    STREAM_SERVER_BIND | STREAM_SERVER_LISTEN,
    $context
);

if (!$socket) {
    sip2_log("Failed to create socket: $errstr ($errno)", 'ERROR');
    exit(1);
}

stream_set_blocking($socket, false);

sip2_log("SIP2 server listening on {$config['host']}:{$config['port']}", 'INFO');

$clients = [];

while ($running) {
    $read = [$socket];
    if (!empty($clients)) {
        $read = array_merge($read, array_keys($clients));
    }
    
    $write = null;
    $except = null;
    
    if (stream_select($read, $write, $except, $config['timeout']) === false) {
        continue;
    }
    
    // New connection
    if (in_array($socket, $read)) {
        if ($conn = stream_socket_accept($socket, 0)) {
            $clientId = (int)$conn;
            $clients[$clientId] = ['socket' => $conn, 'buffer' => ''];
            sip2_log("New client connected: $clientId", 'INFO');
        }
        unset($read[array_search($socket, $read)]);
    }
    
    // Handle client data
    foreach ($read as $clientKey) {
        $client = $clients[$clientKey];
        $data = fread($client['socket'], 1024);
        if ($data === false || $data === '') {
            // Client disconnected
            fclose($client['socket']);
            unset($clients[$clientKey]);
            sip2_log("Client $clientKey disconnected", 'INFO');
            continue;
        }
        
        $client['buffer'] .= $data;
        // SIP2 messages end with carriage return
        if (strpos($client['buffer'], "\r") !== false) {
            $messages = explode("\r", $client['buffer']);
            $client['buffer'] = array_pop($messages); // keep incomplete part
            foreach ($messages as $msg) {
                if (strlen($msg) < 5) continue;
                $parsed = parseSip2Message($msg);
                sip2_log("Received: command={$parsed['command']} fields=" . json_encode($parsed['fields']), 'DEBUG');
                
                $response = '';
                switch ($parsed['command']) {
                    case '93':
                        $response = handleCheckout($parsed['fields']);
                        break;
                    case '95':
                        $response = handleCheckin($parsed['fields']);
                        break;
                    case '63':
                        $response = handlePatronInfo($parsed['fields']);
                        break;
                    default:
                        // Unsupported command – send unsupported message (99)
                        $response = "99" . "UNSUPPORTED" . "\r";
                        break;
                }
                
                fwrite($client['socket'], $response);
                sip2_log("Sent response: " . trim($response), 'DEBUG');
            }
            // Update buffer in clients array
            $clients[$clientKey]['buffer'] = $client['buffer'];
        }
    }
    
    // Process signals if enabled
    if (function_exists('pcntl_signal_dispatch')) {
        pcntl_signal_dispatch();
    }
}

if ($socket) fclose($socket);
sip2_log("SIP2 server stopped", 'INFO');