#!/usr/bin/env php
<?php
/**
 * WebSocket Server Launcher
 * Run as daemon: php websocket/start.php
 */

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../includes/WebSocketServer.php';

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new VisitorWebSocket()
        )
    ),
    8080
);

echo "WebSocket server started on port 8080\n";
$server->run();