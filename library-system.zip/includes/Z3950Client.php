<?php
/**
 * Z39.50 Client Class – Improved Version
 * 
 * Features:
 * - Uses PHP YAZ extension if available, falls back to SRU (Search/Retrieve via URL)
 * - Supports multiple targets (Library of Congress, British Library, etc.)
 * - MARCXML parsing with scriptotek/marc library (recommended) or built‑in DOM
 * - Concurrent searches with individual timeouts
 * - Result deduplication by title/ISBN
 * 
 * Dependencies:
 * - Composer: require scriptotek/marc (optional but recommended)
 * - PHP YAZ extension (optional, for native Z39.50)
 * 
 * @author Library ERP
 * @version 2.0
 */

class Z3950ClientImproved {
    
    /**
     * @var array List of target configurations
     */
    private $targets = [];
    
    /**
     * @var bool Whether YAZ extension is available
     */
    private $yazAvailable = false;
    
    /**
     * @var bool Whether scriptotek/marc library is available
     */
    private $marcAvailable = false;
    
    /**
     * @var int Default timeout per search (seconds)
     */
    private $timeout = 30;
    
    /**
     * @var int Maximum records to retrieve per target
     */
    private $maxRecords = 10;
    
    /**
     * Constructor
     * 
     * @param array $targets Optional custom targets (overrides defaults)
     * @param array $options Optional settings (timeout, maxRecords)
     */
    public function __construct($targets = [], $options = []) {
        $this->yazAvailable = extension_loaded('yaz');
        $this->marcAvailable = $this->checkMarcLibrary();
        
        if (isset($options['timeout'])) $this->timeout = (int)$options['timeout'];
        if (isset($options['maxRecords'])) $this->maxRecords = (int)$options['maxRecords'];
        
        // Load targets
        if (empty($targets)) {
            $this->loadDefaultTargets();
        } else {
            $this->targets = $targets;
        }
    }
    
    /**
     * Check if scriptotek/marc is available via Composer
     * 
     * @return bool
     */
    private function checkMarcLibrary() {
        if (class_exists('Scriptotek\Marc\MarcReader')) {
            return true;
        }
        if (class_exists('File_MARC')) {
            return true;
        }
        return false;
    }
    
    /**
     * Load default Z39.50/SRU targets
     */
    private function loadDefaultTargets() {
        $this->targets = [
            [
                'name' => 'Library of Congress',
                'type' => 'z3950',
                'host' => 'z3950.loc.gov',
                'port' => 7090,
                'db' => 'voyager',
                'sru' => 'https://www.loc.gov/z3950/gateway.cgi?',
            ],
            [
                'name' => 'British Library',
                'type' => 'z3950',
                'host' => 'z3950.bl.uk',
                'port' => 9909,
                'db' => 'BLAC',
                'sru' => 'https://api.bl.uk/z3950/',
            ],
            [
                'name' => 'Deutsche Nationalbibliothek',
                'type' => 'z3950',
                'host' => 'z3950.dnb.de',
                'port' => 2020,
                'db' => 'DNB',
                'sru' => 'https://services.dnb.de/sru/',
            ],
            [
                'name' => 'National Library of Australia',
                'type' => 'z3950',
                'host' => 'z3950.nla.gov.au',
                'port' => 7090,
                'db' => 'NAT',
                'sru' => 'https://librariesaustralia.nla.gov.au/sru/',
            ],
        ];
        
        // Add SRU fallback for all targets if YAZ not available
        if (!$this->yazAvailable) {
            foreach ($this->targets as &$target) {
                $target['type'] = 'sru';
            }
        }
    }
    
    /**
     * Perform a search across all configured targets
     * 
     * @param string $query Search term
     * @param string $type Search type: 'title', 'author', 'isbn', 'keyword'
     * @return array Array of results with keys: target, marcxml, score, title, author, isbn, year
     */
    public function search($query, $type = 'title') {
        $allResults = [];
        
        foreach ($this->targets as $target) {
            if ($target['type'] === 'z3950' && $this->yazAvailable) {
                $results = $this->searchZ3950($target, $query, $type);
            } else {
                $results = $this->searchSRU($target, $query, $type);
            }
            
            if (!empty($results)) {
                $allResults = array_merge($allResults, $results);
            }
        }
        
        // Deduplicate by title (or ISBN if available)
        $unique = [];
        foreach ($allResults as $res) {
            $key = $res['isbn'] ?: md5($res['title']);
            if (!isset($unique[$key]) || $unique[$key]['score'] < $res['score']) {
                $unique[$key] = $res;
            }
        }
        
        // Sort by score descending
        usort($unique, function($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        
        return array_values($unique);
    }
    
    /**
     * Search a single Z39.50 target using YAZ
     * 
     * @param array $target Target configuration
     * @param string $query Search term
     * @param string $type Search type
     * @return array
     */
    private function searchZ3950($target, $query, $type) {
        $results = [];
        $attrMap = [
            'title' => 4,
            'author' => 1003,
            'isbn' => 7,
            'keyword' => 1016,
        ];
        $attr = $attrMap[$type] ?? 4;
        $formattedQuery = "@attr 1=$attr \"" . addslashes($query) . "\"";
        
        $conn = @yaz_connect($target['host'] . ':' . $target['port'] . '/' . $target['db']);
        if (!$conn) return $results;
        
        yaz_syntax($conn, 'marc21');
        yaz_search($conn, 'rpn', $formattedQuery);
        yaz_wait($this->timeout);
        
        $error = yaz_error($conn);
        if ($error) {
            yaz_close($conn);
            return $results;
        }
        
        $hits = yaz_hits($conn);
        if ($hits == 0) {
            yaz_close($conn);
            return $results;
        }
        
        $max = min($hits, $this->maxRecords);
        for ($i = 1; $i <= $max; $i++) {
            $rec = yaz_record($conn, $i, 'xml');
            if ($rec) {
                $parsed = $this->parseMarc($rec);
                $results[] = [
                    'target' => $target['name'],
                    'marcxml' => $rec,
                    'score' => $hits - $i + 1,
                    'title' => $parsed['title'],
                    'author' => $parsed['author'],
                    'isbn' => $parsed['isbn'],
                    'year' => $parsed['year'],
                    'publisher' => $parsed['publisher'],
                    'pages' => $parsed['pages'],
                ];
            }
        }
        
        yaz_close($conn);
        return $results;
    }
    
    /**
     * Search a target via SRU (Search/Retrieve via URL)
     * 
     * @param array $target Target configuration (must have 'sru' URL)
     * @param string $query Search term
     * @param string $type Search type
     * @return array
     */
    private function searchSRU($target, $query, $type) {
        $results = [];
        $sruUrl = rtrim($target['sru'], '/') . '/';
        
        // Map query type to SRU index
        $indexMap = [
            'title' => 'title',
            'author' => 'author',
            'isbn' => 'isbn',
            'keyword' => 'any',
        ];
        $index = $indexMap[$type] ?? 'any';
        
        $queryEncoded = urlencode($index . '="' . addslashes($query) . '"');
        $url = $sruUrl . '?version=1.2&operation=searchRetrieve&query=' . $queryEncoded . '&maximumRecords=' . $this->maxRecords;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Library ERP Z39.50 Client/2.0');
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || empty($response)) return $results;
        
        // Parse SRU response (XML)
        $dom = new DOMDocument();
        if (!@$dom->loadXML($response)) return $results;
        $xpath = new DOMXPath($dom);
        $xpath->registerNamespace('srw', 'http://www.loc.gov/zing/srw/');
        $xpath->registerNamespace('zs', 'http://www.loc.gov/zing/srw/');
        
        $records = $xpath->query('//srw:record');
        $score = count($records);
        foreach ($records as $recordNode) {
            $recordData = $xpath->query('.//srw:recordData/*', $recordNode);
            if ($recordData->length > 0) {
                $marcxml = $dom->saveXML($recordData->item(0));
                $parsed = $this->parseMarc($marcxml);
                $results[] = [
                    'target' => $target['name'],
                    'marcxml' => $marcxml,
                    'score' => $score--,
                    'title' => $parsed['title'],
                    'author' => $parsed['author'],
                    'isbn' => $parsed['isbn'],
                    'year' => $parsed['year'],
                    'publisher' => $parsed['publisher'],
                    'pages' => $parsed['pages'],
                ];
            }
        }
        
        return $results;
    }
    
    /**
     * Parse MARCXML to extract basic bibliographic data
     * 
     * @param string $marcxml MARCXML string
     * @return array Associative array with title, author, isbn, year, publisher, pages
     */
    private function parseMarc($marcxml) {
        $result = [
            'title' => '',
            'author' => '',
            'isbn' => '',
            'year' => '',
            'publisher' => '',
            'pages' => '',
        ];
        
        // Try to use scriptotek/marc if available
        if ($this->marcAvailable && class_exists('Scriptotek\Marc\MarcReader')) {
            try {
                $reader = \Scriptotek\Marc\MarcReader::fromString($marcxml);
                $record = $reader->next();
                if ($record) {
                    $result['title'] = $record->getTitle() ?? '';
                    $result['author'] = $record->getAuthor() ?? '';
                    $result['isbn'] = $record->getIsbn() ?? '';
                    $result['year'] = $record->getYear() ?? '';
                    $result['publisher'] = $record->getPublisher() ?? '';
                    $result['pages'] = $record->getPages() ?? '';
                    return $result;
                }
            } catch (Exception $e) {
                // Fall back to DOM
            }
        }
        
        // Fallback: DOM parsing
        $dom = new DOMDocument();
        if (!@$dom->loadXML($marcxml)) return $result;
        $xpath = new DOMXPath($dom);
        $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');
        
        // Title (245$a, 245$b)
        $titleNodes = $xpath->query("//marc:datafield[@tag='245']/marc:subfield[@code='a']");
        if ($titleNodes->length) $result['title'] = trim($titleNodes->item(0)->nodeValue);
        $titleSub = $xpath->query("//marc:datafield[@tag='245']/marc:subfield[@code='b']");
        if ($titleSub->length) $result['title'] .= ' ' . trim($titleSub->item(0)->nodeValue);
        
        // Author (100$a)
        $authorNodes = $xpath->query("//marc:datafield[@tag='100']/marc:subfield[@code='a']");
        if ($authorNodes->length) $result['author'] = trim($authorNodes->item(0)->nodeValue);
        
        // ISBN (020$a)
        $isbnNodes = $xpath->query("//marc:datafield[@tag='020']/marc:subfield[@code='a']");
        if ($isbnNodes->length) $result['isbn'] = trim($isbnNodes->item(0)->nodeValue);
        
        // Year (260$c or 264$c)
        $yearNodes = $xpath->query("//marc:datafield[@tag='260']/marc:subfield[@code='c'] | //marc:datafield[@tag='264']/marc:subfield[@code='c']");
        if ($yearNodes->length) {
            $year = trim($yearNodes->item(0)->nodeValue);
            if (preg_match('/\b(19|20)\d{2}\b/', $year, $matches)) {
                $result['year'] = $matches[0];
            }
        }
        
        // Publisher (260$b)
        $pubNodes = $xpath->query("//marc:datafield[@tag='260']/marc:subfield[@code='b']");
        if ($pubNodes->length) $result['publisher'] = trim($pubNodes->item(0)->nodeValue);
        
        // Pages (300$a)
        $pagesNodes = $xpath->query("//marc:datafield[@tag='300']/marc:subfield[@code='a']");
        if ($pagesNodes->length) {
            $pages = trim($pagesNodes->item(0)->nodeValue);
            if (preg_match('/(\d+)\s*p\.?/', $pages, $matches)) {
                $result['pages'] = (int)$matches[1];
            }
        }
        
        return $result;
    }
    
    /**
     * Fetch a record by ISBN (convenience method)
     * 
     * @param string $isbn ISBN (10 or 13 digits)
     * @return array|null First matching record or null
     */
    public function fetchByIsbn($isbn) {
        $results = $this->search($isbn, 'isbn');
        return !empty($results) ? $results[0] : null;
    }
    
    /**
     * Import a MARC record directly into the library database
     * 
     * @param string $marcxml MARCXML string
     * @param int|null $bookId Optional book ID to update (if null, inserts new)
     * @return int|bool Book ID on success, false on failure
     */
    public function importRecord($marcxml, $bookId = null) {
        $db = getDB();
        $parsed = $this->parseMarc($marcxml);
        
        $title = substr($parsed['title'], 0, 255);
        $author = substr($parsed['author'], 0, 255);
        $isbn = substr($parsed['isbn'], 0, 20);
        $publisher = substr($parsed['publisher'], 0, 255);
        $year = substr($parsed['year'], 0, 10);
        $pages = (int)$parsed['pages'];
        
        if (empty($title)) return false;
        
        if ($bookId) {
            // Update existing book
            $stmt = $db->prepare("UPDATE books SET title = ?, author = ?, isbn = ?, publisher = ?, year = ?, pages = ?, marcxml = ? WHERE id = ?");
            $stmt->execute([$title, $author, $isbn, $publisher, $year, $pages, $marcxml, $bookId]);
            return $bookId;
        } else {
            // Insert new book
            $barcode = $this->generateBarcode();
            $stmt = $db->prepare("INSERT INTO books (barcode, title, author, isbn, publisher, year, pages, marcxml, quantity, available, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 'Available')");
            $stmt->execute([$barcode, $title, $author, $isbn, $publisher, $year, $pages, $marcxml]);
            return $db->lastInsertId();
        }
    }
    
    /**
     * Generate a unique barcode for new books
     * 
     * @return string
     */
    private function generateBarcode() {
        $db = getDB();
        $max = $db->query("SELECT MAX(CAST(SUBSTR(barcode, 5) AS INTEGER)) FROM books WHERE barcode LIKE 'Z3950%'")->fetchColumn();
        $next = ($max ? $max + 1 : 1);
        return 'Z3950' . str_pad($next, 8, '0', STR_PAD_LEFT);
    }
    
    /**
     * Get or set timeout
     * 
     * @param int|null $seconds New timeout (null to get current)
     * @return int
     */
    public function timeout($seconds = null) {
        if ($seconds !== null) $this->timeout = (int)$seconds;
        return $this->timeout;
    }
    
    /**
     * Get or set max records per target
     * 
     * @param int|null $max New max (null to get current)
     * @return int
     */
    public function maxRecords($max = null) {
        if ($max !== null) $this->maxRecords = (int)$max;
        return $this->maxRecords;
    }
}