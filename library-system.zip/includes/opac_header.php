<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { padding-top: 20px; background: #f0f2f5; }
        .navbar-brand { font-weight: bold; }
        footer { margin-top: 50px; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">📚 Library OPAC</a>
        <div class="ms-auto">
            <?php if (isset($_SESSION['member_id'])): ?>
                <span class="text-white me-3">Welcome, <?= htmlspecialchars($_SESSION['member_name']) ?></span>
                <a href="account.php" class="btn btn-outline-light btn-sm">My Account</a>
                <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-light btn-sm">Login</a>
                <a href="register.php" class="btn btn-outline-light btn-sm">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="container">