<?php
/**
 * Two‑Factor Authentication (TOTP) Helper
 * Requires: composer require robthree/twofactorauth
 */

require_once __DIR__ . '/../vendor/autoload.php';
use RobThree\Auth\TwoFactorAuth;

class TwoFactorHelper
{
    private $tfa;
    private $issuer;

    public function __construct($issuer = 'LibraryERP')
    {
        $this->tfa = new TwoFactorAuth($issuer);
        $this->issuer = $issuer;
    }

    public function generateSecret()
    {
        return $this->tfa->createSecret();
    }

    public function getQRCodeDataUri($secret, $label)
    {
        return $this->tfa->getQRCodeImageAsDataUri($label, $secret);
    }

    public function verifyCode($secret, $code)
    {
        return $this->tfa->verifyCode($secret, $code);
    }
}

// Usage example (place in your login script after password verification):
// $twofa = new TwoFactorHelper();
// if ($user['twofa_secret']) {
//     if (empty($_POST['2fa_code'])) die('2FA code required');
//     if (!$twofa->verifyCode($user['twofa_secret'], $_POST['2fa_code'])) die('Invalid 2FA code');
// }