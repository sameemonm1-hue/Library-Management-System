<?php
/**
 * WebSocket server for real‑time visitor count updates
 * Requires: composer require cboden/ratchet
 */

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require_once __DIR__ . '/../config/functions.php'; // provides getDB()

class VisitorWebSocket implements MessageComponentInterface
{
    protected $clients;
    protected $db;
    protected $lastBroadcast = 0;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->db = getDB();
    }

    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
        $this->broadcastStats();
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        // Client can request a refresh by sending any message
        $this->broadcastStats();
    }

    public function onClose(ConnectionInterface $conn)
    {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} closed\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "Error: {$e->getMessage()}\n";
        $conn->close();
    }

    protected function broadcastStats()
    {
        // Rate limit broadcasts (max once per second)
        $now = microtime(true);
        if ($now - $this->lastBroadcast < 1.0) return;
        $this->lastBroadcast = $now;

        try {
            $stmt = $this->db->query("SELECT COUNT(*) FROM entry_exit WHERE status = 'inside'");
            $inside = (int) $stmt->fetchColumn();
            $data = json_encode(['type' => 'visitor_count', 'inside' => $inside]);
            foreach ($this->clients as $client) {
                $client->send($data);
            }
        } catch (Exception $e) {
            error_log('WebSocket broadcast error: ' . $e->getMessage());
        }
    }
}