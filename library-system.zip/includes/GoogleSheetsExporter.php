<?php
/**
 * Google Sheets Exporter for Reports
 * Requires: composer require google/apiclient
 * Also needs a service account JSON file (config/google_service_account.json)
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Google\Client;
use Google\Service\Sheets;

class GoogleSheetsExporter
{
    private $service;
    private $spreadsheetId;

    /**
     * @param string $spreadsheetId The ID of the Google Sheet (from URL)
     * @param string $serviceAccountJson Path to service account credentials
     */
    public function __construct($spreadsheetId, $serviceAccountJson = __DIR__ . '/../config/google_service_account.json')
    {
        if (!file_exists($serviceAccountJson)) {
            throw new Exception('Google service account JSON file not found: ' . $serviceAccountJson);
        }

        $client = new Client();
        $client->setAuthConfig($serviceAccountJson);
        $client->addScope(Sheets::SPREADSHEETS);
        $this->service = new Sheets($client);
        $this->spreadsheetId = $spreadsheetId;
    }

    /**
     * Export circulation data to the first sheet
     * @param array $data Array of associative arrays (each row)
     * @param string $range e.g., 'Sheet1!A1'
     */
    public function exportCirculation($data, $range = 'Sheet1!A1')
    {
        $values = [['AdmNo', 'Member Name', 'Book Title', 'Issue Date', 'Return Date', 'Fine']];
        foreach ($data as $row) {
            $values[] = [
                $row['admno'] ?? '',
                $row['member_name'] ?? '',
                $row['title'] ?? '',
                $row['issue_date'] ?? '',
                $row['return_date'] ?? '',
                $row['fine'] ?? 0
            ];
        }

        $body = new Google_Service_Sheets_ValueRange(['values' => $values]);
        $options = ['valueInputOption' => 'RAW'];
        $this->service->spreadsheets_values->update($this->spreadsheetId, $range, $body, $options);
        return true;
    }

    /**
     * Append rows to the sheet (instead of overwriting)
     */
    public function appendRows($data, $range = 'Sheet1!A1')
    {
        $values = [];
        foreach ($data as $row) {
            $values[] = array_values($row);
        }
        $body = new Google_Service_Sheets_ValueRange(['values' => $values]);
        $this->service->spreadsheets_values->append($this->spreadsheetId, $range, $body, ['valueInputOption' => 'RAW']);
    }
}