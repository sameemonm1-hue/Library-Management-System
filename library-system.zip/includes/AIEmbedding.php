<?php
/**
 * AI Embedding Client
 * Connects to Python embedding server (sentence-transformers)
 * 
 * Features:
 * - Configurable server URL via settings table (ai_embedding_url)
 * - Timeout configuration
 * - Fallback to dummy embeddings (random vectors) when server unavailable
 * - Cosine similarity calculation
 * - Batch processing
 * - Error logging
 * 
 * Usage:
 *   AIEmbedding::init(); // loads settings
 *   $embedding = AIEmbedding::getEmbedding("book title and summary");
 *   $similarity = AIEmbedding::cosineSimilarity($embedding1, $embedding2);
 */

class AIEmbedding
{
    private static $serverUrl = 'http://localhost:5001';
    private static $timeout = 5;
    private static $enabled = true;
    private static $fallbackToDummy = true;
    private static $initialized = false;

    /**
     * Initialize from database settings
     */
    public static function init(): void
    {
        if (self::$initialized) return;
        
        try {
            $settings = getSettings();
            if (isset($settings['ai_embedding_url']) && !empty($settings['ai_embedding_url'])) {
                self::$serverUrl = rtrim($settings['ai_embedding_url'], '/');
            }
            if (isset($settings['ai_embedding_timeout']) && is_numeric($settings['ai_embedding_timeout'])) {
                self::$timeout = (int)$settings['ai_embedding_timeout'];
            }
            if (isset($settings['ai_embedding_enabled'])) {
                self::$enabled = (bool)$settings['ai_embedding_enabled'];
            }
            if (isset($settings['ai_embedding_fallback'])) {
                self::$fallbackToDummy = (bool)$settings['ai_embedding_fallback'];
            }
        } catch (Exception $e) {
            // Settings table may not exist yet – keep defaults
        }
        
        self::$initialized = true;
    }

    /**
     * Set server URL manually (overrides settings)
     */
    public static function setServerUrl(string $url): void
    {
        self::$serverUrl = rtrim($url, '/');
    }

    /**
     * Enable/disable embedding server usage
     */
    public static function setEnabled(bool $enabled): void
    {
        self::$enabled = $enabled;
    }

    /**
     * Get embedding vector for a single text
     *
     * @param string $text Text to embed (max 512 tokens recommended)
     * @return array|null Vector of floats, or null on failure
     */
    public static function getEmbedding(string $text): ?array
    {
        if (!self::$enabled) {
            return self::getDummyEmbedding($text);
        }
        
        $result = self::batchGetEmbeddings([$text]);
        return $result[0] ?? null;
    }

    /**
     * Get embeddings for multiple texts in one request
     *
     * @param array $texts Array of strings
     * @return array|null Array of vectors, or null on failure
     */
    public static function batchGetEmbeddings(array $texts): ?array
    {
        self::init();
        
        if (!self::$enabled) {
            $dummy = [];
            foreach ($texts as $text) {
                $dummy[] = self::getDummyEmbedding($text);
            }
            return $dummy;
        }
        
        // Sanitize texts: truncate to 1000 characters, remove excessive whitespace
        $processed = [];
        foreach ($texts as $t) {
            $t = trim(preg_replace('/\s+/', ' ', $t));
            $t = mb_substr($t, 0, 1000);
            if (empty($t)) $t = "empty";
            $processed[] = $t;
        }
        
        $ch = curl_init(self::$serverUrl . '/embed');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['texts' => $processed]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, self::$timeout);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($httpCode === 200 && $response) {
            $data = json_decode($response, true);
            if (isset($data['embeddings']) && is_array($data['embeddings'])) {
                return $data['embeddings'];
            }
        }
        
        // Log error for debugging
        error_log("AIEmbedding: Request failed (HTTP $httpCode): " . ($curlError ?: 'No response'));
        
        if (self::$fallbackToDummy) {
            $dummy = [];
            foreach ($texts as $text) {
                $dummy[] = self::getDummyEmbedding($text);
            }
            return $dummy;
        }
        
        return null;
    }

    /**
     * Generate a dummy deterministic embedding (hash-based) for fallback
     * This allows semantic search to still function (though poorly) without AI server
     *
     * @param string $text
     * @return array
     */
    private static function getDummyEmbedding(string $text): array
    {
        $hash = md5($text);
        $seed = hexdec(substr($hash, 0, 8));
        mt_srand($seed);
        $dim = 384; // all-MiniLM-L6-v2 dimension
        $vector = [];
        for ($i = 0; $i < $dim; $i++) {
            $vector[] = mt_rand() / mt_getrandmax() * 2 - 1;
        }
        // Normalize
        $norm = sqrt(array_sum(array_map(function($x) { return $x * $x; }, $vector)));
        if ($norm > 0) {
            $vector = array_map(function($x) use ($norm) { return $x / $norm; }, $vector);
        }
        mt_srand(); // reset
        return $vector;
    }

    /**
     * Calculate cosine similarity between two vectors
     *
     * @param array $a First vector
     * @param array $b Second vector
     * @return float Similarity between -1 and 1
     */
    public static function cosineSimilarity(array $a, array $b): float
    {
        if (empty($a) || empty($b)) return 0.0;
        
        $dot = 0.0;
        $normA = 0.0;
        $normB = 0.0;
        $len = min(count($a), count($b));
        for ($i = 0; $i < $len; $i++) {
            $dot += $a[$i] * $b[$i];
            $normA += $a[$i] * $a[$i];
            $normB += $b[$i] * $b[$i];
        }
        if ($normA == 0 || $normB == 0) return 0.0;
        return $dot / (sqrt($normA) * sqrt($normB));
    }

    /**
     * Find the most similar embeddings from a list of candidates
     *
     * @param array $query Embedding vector
     * @param array $candidates Array of ['id' => id, 'embedding' => vector]
     * @param int $limit Max results
     * @return array Sorted by similarity descending
     */
    public static function findSimilar(array $query, array $candidates, int $limit = 10): array
    {
        $results = [];
        foreach ($candidates as $candidate) {
            $similarity = self::cosineSimilarity($query, $candidate['embedding']);
            $results[] = [
                'id' => $candidate['id'],
                'similarity' => $similarity
            ];
        }
        usort($results, function($a, $b) {
            return $b['similarity'] <=> $a['similarity'];
        });
        return array_slice($results, 0, $limit);
    }

    /**
     * Check if embedding server is healthy
     *
     * @return bool
     */
    public static function isHealthy(): bool
    {
        self::init();
        if (!self::$enabled) return false;
        
        $ch = curl_init(self::$serverUrl . '/health');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $httpCode === 200;
    }
}

// Auto-initialize when file is loaded (optional, but convenient)
// AIEmbedding::init();