<?php
session_start();

function loadLanguage() {
    $available = ['en', 'hi', 'ar'];
    $lang = $_SESSION['lang'] ?? 'en';
    if (!in_array($lang, $available)) $lang = 'en';
    $file = __DIR__ . "/../lang/{$lang}.json";
    if (file_exists($file)) {
        $translations = json_decode(file_get_contents($file), true);
    } else {
        $translations = [];
    }
    return $translations;
}

function __($key) {
    static $translations = null;
    if ($translations === null) {
        $translations = loadLanguage();
    }
    return $translations[$key] ?? $key;
}