<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
requireLogin();

$db = getDB();
$settings = getSettings();
$currencySymbol = $settings['currency_symbol'] ?? '$';
$maxBooksPerMember = $settings['max_books'] ?? 5;

$error = '';
$success = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['bulk_issue'])) {
        $memberAdmno = trim($_POST['member_admno']);
        $barcodes = explode("\n", trim($_POST['barcodes']));
        $barcodes = array_map('trim', $barcodes);
        $barcodes = array_filter($barcodes);
        
        // Check member
        $member = getMemberByAdmno($memberAdmno);
        if (!$member || $member['status'] !== 'active') {
            $error = "Member not found or inactive";
        } else {
            $currentIssued = getMemberActiveLoansCount($memberAdmno);
            $maxAllowed = $maxBooksPerMember - $currentIssued;
            
            if (count($barcodes) > $maxAllowed) {
                $error = "Member can only issue {$maxAllowed} more book(s). You selected " . count($barcodes);
            } else {
                $db->beginTransaction();
                try {
                    $loanDays = $settings['loan_days'] ?? 7;
                    $dueDate = date('Y-m-d', strtotime("+$loanDays days"));
                    
                    foreach ($barcodes as $barcode) {
                        $book = getBookByBarcode($barcode);
                        if (!$book) {
                            throw new Exception("Book not found: {$barcode}");
                        }
                        if ($book['available'] <= 0) {
                            throw new Exception("Book not available: {$book['title']}");
                        }
                        
                        // Issue book
                        $stmt = $db->prepare("INSERT INTO circulation (admno, member_name, class, division, barcode, isbn, title, author, category, publisher, issue_date, due_date) 
                                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, date('now'), ?)");
                        $stmt->execute([
                            $member['admno'], $member['name'], $member['class'] ?? '', $member['division'] ?? '',
                            $book['barcode'], $book['isbn'] ?? '', $book['title'], $book['author'] ?? '',
                            $book['category'] ?? '', $book['publisher'] ?? '', $dueDate
                        ]);
                        
                        // Update book availability
                        $db->prepare("UPDATE books SET available = available - 1 WHERE barcode = ?")->execute([$barcode]);
                        
                        $results[] = ['barcode' => $barcode, 'title' => $book['title'], 'status' => 'success'];
                    }
                    
                    $db->commit();
                    $success = count($results) . " book(s) issued successfully!";
                    logActivity($_SESSION['username'], 'BULK_ISSUE', "Issued " . count($results) . " books to {$member['name']}");
                    
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = $e->getMessage();
                }
            }
        }
    }
    
    if (isset($_POST['bulk_return'])) {
        $barcodes = explode("\n", trim($_POST['return_barcodes']));
        $barcodes = array_map('trim', $barcodes);
        $barcodes = array_filter($barcodes);
        
        $db->beginTransaction();
        try {
            foreach ($barcodes as $barcode) {
                $stmt = $db->prepare("SELECT * FROM circulation WHERE barcode = ? AND return_date IS NULL");
                $stmt->execute([$barcode]);
                $record = $stmt->fetch();
                
                if (!$record) {
                    throw new Exception("No active issue found for barcode: {$barcode}");
                }
                
                // Calculate fine
                $fine = calculateFine($record['due_date'], $record['member_category'] ?? 'Student');
                
                $db->prepare("UPDATE circulation SET return_date = date('now'), fine = ? WHERE id = ?")->execute([$fine, $record['id']]);
                $db->prepare("UPDATE books SET available = available + 1 WHERE barcode = ?")->execute([$barcode]);
                
                $results[] = ['barcode' => $barcode, 'title' => $record['title'], 'fine' => $fine, 'status' => 'success'];
            }
            
            $db->commit();
            $success = count($results) . " book(s) returned successfully!";
            logActivity($_SESSION['username'], 'BULK_RETURN', "Returned " . count($results) . " books");
            
        } catch (Exception $e) {
            $db->rollBack();
            $error = $e->getMessage();
        }
    }
    
    if (isset($_POST['export_template'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="bulk_issue_template.csv"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['Book Barcode']);
        fputcsv($output, ['BK001']);
        fputcsv($output, ['BK002']);
        fclose($output);
        exit;
    }
}

renderHeader('Bulk Issue/Return');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-layer-group"></i> Bulk Issue / Return</h2>
        <div>
            <a href="index.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Circulation</a>
        </div>
    </div>
    
    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if(!empty($results)): ?>
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-list"></i> Processing Results</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead class="table-light">
                            <tr><th>Barcode</th><th>Title</th><th>Status</th><th>Fine</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach($results as $result): ?>
                            <tr>
                                <td><?= htmlspecialchars($result['barcode']) ?></td>
                                <td><?= htmlspecialchars($result['title']) ?></div>
                                <td><span class="badge bg-success">Success</span></div>
                                <td><?= isset($result['fine']) ? $currencySymbol . number_format($result['fine'], 2) : '-' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Bulk Issue Section -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-arrow-right"></i> Bulk Issue Books</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Member Admission Number *</label>
                            <div class="input-group">
                                <input type="text" name="member_admno" id="memberAdmno" class="form-control" required>
                                <button type="button" class="btn btn-info" onclick="fetchMember()">
                                    <i class="fas fa-search"></i> Fetch
                                </button>
                            </div>
                            <div id="memberInfo" class="mt-2 small"></div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Book Barcodes (one per line) *</label>
                            <textarea name="barcodes" class="form-control" rows="10" placeholder="BK001&#10;BK002&#10;BK003" required></textarea>
                            <small class="text-muted">Enter one barcode per line. Maximum <?= $maxBooksPerMember ?> books per member.</small>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" name="bulk_issue" class="btn btn-success">
                                <i class="fas fa-arrow-right"></i> Issue All Books
                            </button>
                            <button type="button" class="btn btn-outline-secondary" onclick="downloadTemplate()">
                                <i class="fas fa-download"></i> Download Template
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Bulk Return Section -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="fas fa-arrow-left"></i> Bulk Return Books</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Book Barcodes (one per line) *</label>
                            <textarea name="return_barcodes" class="form-control" rows="10" placeholder="BK001&#10;BK002&#10;BK003" required></textarea>
                            <small class="text-muted">Enter one barcode per line. Fines will be calculated automatically.</small>
                        </div>
                        
                        <button type="submit" name="bulk_return" class="btn btn-warning">
                            <i class="fas fa-arrow-left"></i> Return All Books
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function fetchMember() {
    let admno = document.getElementById('memberAdmno').value.trim();
    if(admno.length < 2) {
        alert('Please enter at least 2 characters');
        return;
    }
    
    fetch('../entry_exit/ajax_member.php?admno=' + encodeURIComponent(admno))
        .then(response => response.json())
        .then(data => {
            let infoDiv = document.getElementById('memberInfo');
            if(data && data.name) {
                infoDiv.innerHTML = `
                    <div class="alert alert-success">
                        <strong>${escapeHtml(data.name)}</strong><br>
                        Category: ${escapeHtml(data.member_category)}<br>
                        Books Issued: ${data.active_books || 0} / <?= $maxBooksPerMember ?><br>
                        Available to issue: <?= $maxBooksPerMember ?> - ${data.active_books || 0} = ${<?= $maxBooksPerMember ?> - (data.active_books || 0)}
                    </div>
                `;
            } else {
                infoDiv.innerHTML = '<div class="alert alert-danger">Member not found</div>';
            }
        });
}

function downloadTemplate() {
    window.location.href = '?export_template=1';
}

function escapeHtml(s) {
    if(!s) return '';
    return s.replace(/[&<>]/g, m => m === '&' ? '&amp;' : (m === '<' ? '&lt;' : '&gt;'));
}
</script>

<?php renderFooter(); ?>