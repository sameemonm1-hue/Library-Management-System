<!-- Add this anywhere in the logged-in area -->
<div class="dropdown">
    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
        <i class="fas fa-language"></i> <?= strtoupper($_SESSION['lang'] ?? 'EN') ?>
    </button>
    <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="?lang=en">English</a></li>
        <li><a class="dropdown-item" href="?lang=hi">हिन्दी</a></li>
        <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
    </ul>
</div>

<?php
// At the top of each page (after session_start)
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}
// Then include language.php and use __($key) function
?>