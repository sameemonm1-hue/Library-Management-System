#!/usr/bin/env php
<?php
require_once __DIR__ . '/config.php';

$jobName = 'cleanup_temp_files';
if (!acquire_lock($jobName)) {
    exit(1);
}

try {
    cron_log("========== STARTING TEMP FILE CLEANUP ==========");
    $startTime = microtime(true);
    $db = getDB();
    $stats = ['temp_files' => 0, 'cache_files' => 0, 'old_sessions' => 0, 'upload_temp' => 0, 'space_freed' => 0];
    
    // 1. Clean temp report files
    $tempDir = sys_get_temp_dir();
    $files = glob($tempDir . '/report_*.html');
    $cutoff = time() - 3600;
    foreach ($files as $file) {
        if (filemtime($file) < $cutoff) {
            $stats['space_freed'] += filesize($file);
            unlink($file);
            $stats['temp_files']++;
        }
    }
    cron_log("Deleted {$stats['temp_files']} temp report files");
    
    // 2. Clean cache files
    $cacheDir = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/cache/';
    if (is_dir($cacheDir)) {
        $cacheFiles = glob($cacheDir . '*');
        $cutoffCache = time() - 86400;
        foreach ($cacheFiles as $file) {
            if (is_file($file) && filemtime($file) < $cutoffCache) {
                $stats['space_freed'] += filesize($file);
                unlink($file);
                $stats['cache_files']++;
            }
        }
        cron_log("Deleted {$stats['cache_files']} cache files");
    }
    
    // 3. Clean old PHP session files
    $sessionPath = session_save_path();
    if (empty($sessionPath)) $sessionPath = ini_get('session.save_path');
    if (empty($sessionPath)) $sessionPath = sys_get_temp_dir();
    if (is_dir($sessionPath)) {
        $sessionFiles = glob($sessionPath . '/sess_*');
        $cutoffSess = time() - 86400;
        foreach ($sessionFiles as $file) {
            if (filemtime($file) < $cutoffSess) {
                $stats['space_freed'] += filesize($file);
                unlink($file);
                $stats['old_sessions']++;
            }
        }
        cron_log("Deleted {$stats['old_sessions']} old session files");
    }
    
    // 4. Clean temp uploads
    $uploadTmp = ini_get('upload_tmp_dir');
    if (empty($uploadTmp)) $uploadTmp = sys_get_temp_dir();
    if (is_dir($uploadTmp)) {
        $uploadFiles = glob($uploadTmp . '/php*');
        $cutoffUpload = time() - 3600;
        foreach ($uploadFiles as $file) {
            if (filemtime($file) < $cutoffUpload) {
                $stats['space_freed'] += filesize($file);
                unlink($file);
                $stats['upload_temp']++;
            }
        }
        cron_log("Deleted {$stats['upload_temp']} temp upload files");
    }
    
    $stats['space_freed_mb'] = round($stats['space_freed'] / 1024 / 1024, 2);
    if ($stats['space_freed_mb'] > 10) sendCleanupReport($stats);
    
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("TEMP FILE CLEANUP COMPLETED in {$duration}s");
    cron_log("Freed {$stats['space_freed_mb']} MB");
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
} finally {
    release_lock($jobName);
}

function sendCleanupReport($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    if (empty($adminEmail)) return;
    $subject = "Temp File Cleanup Report - " . date('Y-m-d');
    $message = "<html><body><h3>Temp File Cleanup Report</h3>
                <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
                <table border='1'><tr><th>Type</th><th>Count</th></tr>
                <tr><td>Temp Report Files</td><td>{$stats['temp_files']}</td></tr>
                <tr><td>Cache Files</td><td>{$stats['cache_files']}</td></tr>
                <tr><td>Old Sessions</td><td>{$stats['old_sessions']}</td></tr>
                <tr><td>Temp Uploads</td><td>{$stats['upload_temp']}</td></tr>
                </table>
                <p><strong>Space Freed:</strong> {$stats['space_freed_mb']} MB</p>
                <small>This is an automated report.</small></body></html>";
    sendEmail($adminEmail, $subject, $message);
}