#!/usr/bin/env php
<?php
/**
 * Generate Reports
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'generate_reports';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING REPORT GENERATION ==========");
    $startTime = microtime(true);
    $db = getDB();

    // Weekly circulation report
    $weekStart = date('Y-m-d', strtotime('last monday'));
    $weekEnd = date('Y-m-d');
    $stmt = $db->prepare("SELECT COUNT(*) as total_issues, COUNT(DISTINCT admno) as unique_borrowers FROM circulation WHERE issue_date BETWEEN ? AND ?");
    $stmt->execute([$weekStart, $weekEnd]);
    $stats = $stmt->fetch();
    $reportData = ['period' => "$weekStart to $weekEnd", 'summary' => $stats, 'generated_at' => date('Y-m-d H:i:s')];
    saveReport('circulation', $reportData);
    cron_log("Generated circulation report");

    // Member activity report
    $monthStart = date('Y-m-01');
    $stmt = $db->prepare("SELECT m.admno, m.name, m.member_category, COUNT(c.id) as books_borrowed FROM members m LEFT JOIN circulation c ON m.admno=c.admno AND c.issue_date>=? GROUP BY m.id ORDER BY books_borrowed DESC LIMIT 50");
    $stmt->execute([$monthStart]);
    $topMembers = $stmt->fetchAll();
    saveReport('member_activity', ['top_members' => $topMembers, 'period' => "Since $monthStart"]);
    cron_log("Generated member activity report");

    // Financial report
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount),0) as total_fines FROM fine_payments WHERE payment_date >= ?");
    $stmt->execute([$monthStart]);
    $fines = $stmt->fetchColumn();
    saveReport('financial', ['total_fines_collected' => $fines, 'period' => $monthStart]);
    cron_log("Generated financial report");

    $duration = round(microtime(true)-$startTime,2);
    cron_log("REPORT GENERATION COMPLETED in {$duration}s");

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}

function saveReport($type, $data) {
    $db = getDB();
    $db->exec("CREATE TABLE IF NOT EXISTS generated_reports (id INTEGER PRIMARY KEY, report_type TEXT, report_date DATE, report_data TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
    $stmt = $db->prepare("INSERT INTO generated_reports (report_type, report_date, report_data) VALUES (?, date('now'), ?)");
    $stmt->execute([$type, json_encode($data)]);
    $reportDir = CRON_LOG_DIR . 'reports/';
    if (!is_dir($reportDir)) mkdir($reportDir, 0755, true);
    file_put_contents($reportDir . $type . '_' . date('Y-m-d') . '.json', json_encode($data, JSON_PRETTY_PRINT));
}