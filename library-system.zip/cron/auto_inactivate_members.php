#!/usr/bin/env php
<?php
/**
 * Auto-inactivate members with no activity for 6 months
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'auto_inactivate_members';
if (!acquire_lock($jobName)) exit(1);

try {
    $db = getDB();
    $sql = "UPDATE members SET status = 'inactive' 
            WHERE status = 'active' 
            AND (
                (NOT EXISTS (SELECT 1 FROM circulation WHERE circulation.admno = members.admno)
                 AND date(admission_date) <= date('now', '-6 months'))
                OR
                (strftime('%s', 'now') - strftime('%s', (
                    SELECT MAX(issue_date) FROM circulation WHERE circulation.admno = members.admno
                )) > 60*60*24*180)
            )";
    $count = $db->exec($sql);
    cron_log("Inactivated $count members with no activity for 6 months.");
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}