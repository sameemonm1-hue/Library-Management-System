<?php
/**
 * Cron Jobs Configuration
 * Set up your cron jobs to run automatically
 */

// Change to the root directory
chdir(dirname(__DIR__));
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Set timezone
$settings = getSettings();
$timezone = $settings['library_timezone'] ?? 'Asia/Kolkata';
date_default_timezone_set($timezone);

// Log file paths
define('CRON_LOG_DIR', __DIR__ . '/logs/');
define('CRON_LOCK_DIR', __DIR__ . '/locks/');

// Create directories if they don't exist
if (!is_dir(CRON_LOG_DIR)) mkdir(CRON_LOG_DIR, 0755, true);
if (!is_dir(CRON_LOCK_DIR)) mkdir(CRON_LOCK_DIR, 0755, true);

/**
 * Write to cron log
 */
function cron_log($message, $type = 'INFO') {
    $logFile = CRON_LOG_DIR . 'cron_' . date('Y-m-d') . '.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] [$type] $message" . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
    
    // Also output to console if running from CLI
    if (php_sapi_name() === 'cli') {
        echo $logMessage;
    }
}

/**
 * Prevent multiple instances of the same cron job
 */
function acquire_lock($jobName, $timeout = 300) {
    $lockFile = CRON_LOCK_DIR . $jobName . '.lock';
    
    // Check if lock exists and is not stale
    if (file_exists($lockFile)) {
        $lockTime = (int)file_get_contents($lockFile);
        if (time() - $lockTime < $timeout) {
            cron_log("Job $jobName is already running. Skipping.", "WARNING");
            return false;
        }
        cron_log("Stale lock found for $jobName. Removing...", "WARNING");
        unlink($lockFile);
    }
    
    // Create lock
    file_put_contents($lockFile, time());
    return true;
}

/**
 * Release lock
 */
function release_lock($jobName) {
    $lockFile = CRON_LOCK_DIR . $jobName . '.lock';
    if (file_exists($lockFile)) {
        unlink($lockFile);
    }
}

/**
 * Send notification to admin
 */
function notify_admin($subject, $message, $type = 'error') {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    
    if (!empty($adminEmail)) {
        sendEmail($adminEmail, "[Cron] $subject", $message);
    }
    
    cron_log("Admin notified: $subject - $message", strtoupper($type));
}

/**
 * Get library settings
 */
function get_cron_settings() {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>