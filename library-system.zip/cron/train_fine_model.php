#!/usr/bin/env php
<?php
/**
 * Train Fine Prediction Model
 * 
 * Collects historical circulation data (member category, overdue days, book subject, etc.)
 * Trains a logistic regression model to predict overdue probability.
 * Stores model coefficients in settings table for real‑time predictions.
 * 
 * Usage: php cron/train_fine_model.php [--force]
 * 
 * Dependencies (optional but recommended):
 *   composer require php-ai/php-ml
 * 
 * If PHP-ML is not installed, the script falls back to a simple heuristic model.
 * 
 * Cron example (weekly on Sunday at 3 AM):
 *   0 3 * * 0 /usr/bin/php /path/to/library-system/cron/train_fine_model.php >> /var/log/library_fine_model.log 2>&1
 */

// ==================== BOOTSTRAP ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';

// Parse command line arguments
$force = in_array('--force', $argv);

// Initialize logging
function logMessage($msg, $type = 'info') {
    $timestamp = date('Y-m-d H:i:s');
    $prefix = match($type) {
        'error' => '❌ ERROR',
        'success' => '✅ SUCCESS',
        'warning' => '⚠️ WARNING',
        default => 'ℹ️ INFO'
    };
    echo "[$timestamp] $prefix: $msg" . PHP_EOL;
    if ($type === 'error') {
        error_log("[LibraryERP] $msg");
    }
}

logMessage("Starting fine prediction model training (force=" . ($force ? 'yes' : 'no') . ")");

// ==================== CHECK DEPENDENCIES ====================
$phpmlAvailable = false;
if (file_exists($rootPath . '/vendor/autoload.php')) {
    require_once $rootPath . '/vendor/autoload.php';
    if (class_exists('Phpml\\Classification\\LogisticRegression')) {
        $phpmlAvailable = true;
        logMessage("PHP-ML library found – using logistic regression", 'success');
    } else {
        logMessage("PHP-ML found but LogisticRegression class missing", 'warning');
    }
}

if (!$phpmlAvailable) {
    logMessage("PHP-ML not available. Falling back to simple heuristic model (accuracy may be lower).", 'warning');
    logMessage("To install PHP-ML, run: composer require php-ai/php-ml", 'info');
}

$db = getDB();

// ==================== COLLECT TRAINING DATA ====================
// We need features: member_category (categorical), item_category, days_overdue (for returned items), 
// historical late frequency, book subject category, loan period.
// Target: whether the loan was overdue (1) or not (0).

logMessage("Collecting historical circulation data...");

// Get completed circulation records (returned) with member and book details
$sql = "SELECT 
            c.id,
            c.admno,
            c.issue_date,
            c.due_date,
            c.return_date,
            c.renew_count,
            m.member_category,
            m.total_issued as member_total_issued,
            m.total_fines as member_total_fines,
            b.item_category,
            b.subject,
            b.category as book_category,
            b.year
        FROM circulation c
        JOIN members m ON c.admno = m.admno
        JOIN books b ON c.barcode = b.barcode
        WHERE c.return_date IS NOT NULL
        ORDER BY c.id DESC
        LIMIT 10000";  // Limit for performance

$stmt = $db->prepare($sql);
$stmt->execute();
$records = $stmt->fetchAll();

if (count($records) < 100) {
    logMessage("Insufficient data (" . count($records) . " records). Need at least 100 returned loans. Exiting.", 'warning');
    exit(1);
}

logMessage("Collected " . count($records) . " historical records");

// ==================== FEATURE ENGINEERING ====================
// Encode categorical variables, calculate features
$samples = [];
$labels = [];

// Map categories to indices
$memberCatMap = [];
$itemCatMap = [];
$subjectMap = [];

foreach ($records as $rec) {
    // Target: overdue (1 if due_date < return_date, else 0)
    $overdue = (strtotime($rec['due_date']) < strtotime($rec['return_date'])) ? 1 : 0;
    
    // Features:
    // 1. Member category (categorical -> one-hot or integer)
    $memberCat = $rec['member_category'] ?? 'General';
    if (!isset($memberCatMap[$memberCat])) {
        $memberCatMap[$memberCat] = count($memberCatMap);
    }
    
    // 2. Item category
    $itemCat = $rec['item_category'] ?? 'General';
    if (!isset($itemCatMap[$itemCat])) {
        $itemCatMap[$itemCat] = count($itemCatMap);
    }
    
    // 3. Book subject (first few words as category)
    $subject = $rec['subject'] ?? 'Unknown';
    $subjectKey = preg_replace('/[^a-zA-Z]/', '', substr($subject, 0, 20));
    if (empty($subjectKey)) $subjectKey = 'Unknown';
    if (!isset($subjectMap[$subjectKey])) {
        $subjectMap[$subjectKey] = count($subjectMap);
    }
    
    // 4. Numeric: loan period in days
    $loanPeriod = (strtotime($rec['due_date']) - strtotime($rec['issue_date'])) / 86400;
    $loanPeriod = max(1, round($loanPeriod));
    
    // 5. Member's historical late frequency (ratio of total_issued / total_fines? but fines are aggregated)
    // Better: member's overdue rate from their own history (calculated separately)
    // For simplicity, use member's total_fines as proxy (higher fines -> more likely overdue)
    $memberFineRatio = min(1, $rec['member_total_fines'] / 100); // cap at 1
    
    // 6. Renew count
    $renewCount = min(3, (int)$rec['renew_count']);
    
    // 7. Book publication year (recent books may be more popular)
    $year = (int)$rec['year'];
    $yearNorm = $year ? max(0, min(1, ($year - 1950) / 70)) : 0.5;
    
    $samples[] = [
        'member_cat_idx' => $memberCatMap[$memberCat],
        'item_cat_idx' => $itemCatMap[$itemCat],
        'subject_idx' => $subjectMap[$subjectKey],
        'loan_period' => $loanPeriod,
        'member_fine_ratio' => $memberFineRatio,
        'renew_count' => $renewCount,
        'year_norm' => $yearNorm
    ];
    $labels[] = $overdue;
}

$numFeatures = 7;
$featureNames = ['member_category', 'item_category', 'subject', 'loan_period', 'member_fine_ratio', 'renew_count', 'year_norm'];

logMessage("Feature dimensions: " . count($memberCatMap) . " member categories, " . count($itemCatMap) . " item categories, " . count($subjectMap) . " subjects");

// ==================== TRAIN MODEL ====================
$modelParams = null;

if ($phpmlAvailable) {
    try {
        // Convert samples to flat array (one-hot encoding for categorical features)
        $totalMemberCats = count($memberCatMap);
        $totalItemCats = count($itemCatMap);
        $totalSubjects = count($subjectMap);
        
        $flatSamples = [];
        foreach ($samples as $s) {
            $row = [];
            // One-hot for member category
            for ($i = 0; $i < $totalMemberCats; $i++) {
                $row[] = ($s['member_cat_idx'] == $i) ? 1 : 0;
            }
            // One-hot for item category
            for ($i = 0; $i < $totalItemCats; $i++) {
                $row[] = ($s['item_cat_idx'] == $i) ? 1 : 0;
            }
            // One-hot for subject
            for ($i = 0; $i < $totalSubjects; $i++) {
                $row[] = ($s['subject_idx'] == $i) ? 1 : 0;
            }
            // Numeric features
            $row[] = $s['loan_period'];
            $row[] = $s['member_fine_ratio'];
            $row[] = $s['renew_count'];
            $row[] = $s['year_norm'];
            
            $flatSamples[] = $row;
        }
        
        // Train logistic regression
        use Phpml\Classification\LogisticRegression;
        $classifier = new LogisticRegression(0.01, 1000);
        $classifier->train($flatSamples, $labels);
        
        // Extract coefficients and intercept
        $coefficients = $classifier->getCoefficients();
        $intercept = $classifier->getIntercept();
        
        $modelParams = [
            'type' => 'logistic_regression',
            'coefficients' => $coefficients,
            'intercept' => $intercept,
            'feature_map' => [
                'member_categories' => array_keys($memberCatMap),
                'item_categories' => array_keys($itemCatMap),
                'subjects' => array_keys($subjectMap),
                'numeric_features' => ['loan_period', 'member_fine_ratio', 'renew_count', 'year_norm']
            ],
            'feature_count' => count($coefficients)
        ];
        
        logMessage("Logistic regression trained successfully. Coefficients: " . count($coefficients), 'success');
        
    } catch (Exception $e) {
        logMessage("PHP-ML training failed: " . $e->getMessage(), 'error');
        $phpmlAvailable = false;
    }
}

// Fallback: simple weighted formula (heuristic)
if (!$phpmlAvailable) {
    logMessage("Using heuristic model (averages)");
    
    // Calculate average overdue rate per category
    $memberOverdueRates = [];
    $itemOverdueRates = [];
    $subjectOverdueRates = [];
    $overdueCounts = [];
    
    foreach ($records as $i => $rec) {
        $memberCat = $rec['member_category'] ?? 'General';
        $itemCat = $rec['item_category'] ?? 'General';
        $subjectKey = preg_replace('/[^a-zA-Z]/', '', substr($rec['subject'] ?? 'Unknown', 0, 20));
        if (empty($subjectKey)) $subjectKey = 'Unknown';
        
        if (!isset($memberOverdueRates[$memberCat])) {
            $memberOverdueRates[$memberCat] = ['total' => 0, 'overdue' => 0];
        }
        if (!isset($itemOverdueRates[$itemCat])) {
            $itemOverdueRates[$itemCat] = ['total' => 0, 'overdue' => 0];
        }
        if (!isset($subjectOverdueRates[$subjectKey])) {
            $subjectOverdueRates[$subjectKey] = ['total' => 0, 'overdue' => 0];
        }
        
        $memberOverdueRates[$memberCat]['total']++;
        $itemOverdueRates[$itemCat]['total']++;
        $subjectOverdueRates[$subjectKey]['total']++;
        
        if ($labels[$i] == 1) {
            $memberOverdueRates[$memberCat]['overdue']++;
            $itemOverdueRates[$itemCat]['overdue']++;
            $subjectOverdueRates[$subjectKey]['overdue']++;
        }
    }
    
    $modelParams = [
        'type' => 'heuristic',
        'member_rates' => [],
        'item_rates' => [],
        'subject_rates' => [],
        'base_rate' => array_sum($labels) / count($labels)
    ];
    
    foreach ($memberOverdueRates as $cat => $data) {
        $modelParams['member_rates'][$cat] = $data['overdue'] / max(1, $data['total']);
    }
    foreach ($itemOverdueRates as $cat => $data) {
        $modelParams['item_rates'][$cat] = $data['overdue'] / max(1, $data['total']);
    }
    foreach ($subjectOverdueRates as $subj => $data) {
        $modelParams['subject_rates'][$subj] = $data['overdue'] / max(1, $data['total']);
    }
}

// ==================== STORE MODEL PARAMETERS IN SETTINGS ====================
try {
    $modelJson = json_encode($modelParams, JSON_PRETTY_PRINT);
    $stmt = $db->prepare("UPDATE settings SET fine_prediction_model = ? WHERE id = 1");
    $stmt->execute([$modelJson]);
    logMessage("Model parameters stored in settings", 'success');
} catch (PDOException $e) {
    // Column may not exist – add it
    $db->exec("ALTER TABLE settings ADD COLUMN fine_prediction_model TEXT");
    $stmt = $db->prepare("UPDATE settings SET fine_prediction_model = ? WHERE id = 1");
    $stmt->execute([$modelJson]);
    logMessage("Added fine_prediction_model column and stored parameters", 'success');
}

// ==================== EVALUATE MODEL (optional) ====================
if ($phpmlAvailable && count($records) > 200) {
    // Simple cross‑validation: split into train/test (80/20)
    $split = (int)(count($records) * 0.8);
    $trainSamples = array_slice($flatSamples, 0, $split);
    $trainLabels = array_slice($labels, 0, $split);
    $testSamples = array_slice($flatSamples, $split);
    $testLabels = array_slice($labels, $split);
    
    $classifier->train($trainSamples, $trainLabels);
    $predictions = $classifier->predict($testSamples);
    $correct = 0;
    foreach ($predictions as $i => $pred) {
        if ($pred == $testLabels[$i]) $correct++;
    }
    $accuracy = $correct / count($testLabels);
    logMessage("Model accuracy on test set: " . round($accuracy * 100, 2) . "% ($correct/" . count($testLabels) . ")", 'info');
}

logMessage("Fine prediction model training completed.", 'success');
exit(0);