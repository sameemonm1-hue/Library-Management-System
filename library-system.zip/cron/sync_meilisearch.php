#!/usr/bin/env php
<?php
/**
 * Sync books and members to Meilisearch index
 * Run after every book/member change (or via cron daily)
 */

require_once __DIR__ . '/../config/bootstrap.php'; // your app bootstrap (sets up DB, env, etc.)
$meili = require __DIR__ . '/../config/meilisearch.php';
if (!$meili) exit(1);

$db = getDB();

// Index books
$books = $db->query("SELECT id, barcode, title, author, subject, isbn, publisher, year, available FROM books WHERE status != 'Deleted'")->fetchAll(PDO::FETCH_ASSOC);
if (!empty($books)) {
    $meili->index('books')->addDocuments($books, 'id');
    echo "Indexed " . count($books) . " books.\n";
}

// Index members
$members = $db->query("SELECT id, admno, name, member_category, class, division FROM members WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);
if (!empty($members)) {
    $meili->index('members')->addDocuments($members, 'id');
    echo "Indexed " . count($members) . " members.\n";
}

exit(0);