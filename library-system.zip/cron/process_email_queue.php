#!/usr/bin/env php
<?php
/**
 * Email Queue Processor
 * 
 * Sends pending emails from email_queue table using PHPMailer (SMTP).
 * Features:
 *   - Rate limiting (max emails per minute, configurable)
 *   - Exponential backoff for retries (attempts 1, 2, 3 with increasing delays)
 *   - Logging to cron/logs/email_queue.log
 *   - Uses PHPMailer via Composer autoload
 *   - Respects priority (higher priority processed first)
 * 
 * Usage: php cron/process_email_queue.php [--force]
 * 
 * Cron example (every 5 minutes):
 *   */5 * * * * /usr/bin/php /path/to/library-system/cron/process_email_queue.php >> /var/log/email_queue.log 2>&1
 */

// ==================== BOOTSTRAP ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';

// Load Composer autoload for PHPMailer
$composerAutoload = $rootPath . '/vendor/autoload.php';
if (!file_exists($composerAutoload)) {
    die("PHPMailer not installed. Run: composer require phpmailer/phpmailer\n");
}
require_once $composerAutoload;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// ==================== CONFIGURATION ====================
$maxPerRun = 50;           // Max emails to process in one run
$rateLimitPerMinute = 30;  // Max emails per minute (to avoid being flagged as spam)
$baseDelay = 300;          // Base delay in seconds between retries (5 minutes)
$maxRetries = 3;           // Maximum number of attempts before marking as failed

// Parse command line arguments
$force = in_array('--force', $argv);

// Logging function
function logEmailQueue($message, $type = 'info') {
    $logDir = __DIR__ . '/logs/';
    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    $logFile = $logDir . 'email_queue.log';
    $timestamp = date('Y-m-d H:i:s');
    $prefix = match($type) {
        'error' => '❌ ERROR',
        'success' => '✅ SUCCESS',
        'warning' => '⚠️ WARNING',
        default => 'ℹ️ INFO'
    };
    $logLine = "[$timestamp] $prefix: $message" . PHP_EOL;
    file_put_contents($logFile, $logLine, FILE_APPEND);
    if (php_sapi_name() === 'cli') {
        echo $logLine;
    }
}

logEmailQueue("Starting email queue processor (force=" . ($force ? 'yes' : 'no') . ")");

// ==================== FETCH PENDING EMAILS ====================
$db = getDB();
$settings = getSettings();

// Validate SMTP settings
if (empty($settings['smtp_host']) || empty($settings['smtp_username'])) {
    logEmailQueue("SMTP settings not configured. Please configure in admin/settings.php", 'error');
    exit(1);
}

// Fetch pending emails ordered by priority (higher first) and oldest first
$stmt = $db->prepare("SELECT * FROM email_queue 
                       WHERE status = 'pending' 
                         AND attempts < ? 
                       ORDER BY priority DESC, created_at ASC 
                       LIMIT ?");
$stmt->execute([$maxRetries, $maxPerRun]);
$emails = $stmt->fetchAll();

if (empty($emails)) {
    logEmailQueue("No pending emails to process.");
    exit(0);
}

logEmailQueue("Found " . count($emails) . " pending emails.");

// ==================== PROCESS EMAILS WITH RATE LIMITING ====================
$sent = 0;
$failed = 0;
$startTime = time();
$emailsSentThisMinute = 0;

foreach ($emails as $email) {
    // Rate limiting: enforce emails per minute
    $elapsed = time() - $startTime;
    if ($elapsed < 60 && $emailsSentThisMinute >= $rateLimitPerMinute) {
        $sleep = 60 - $elapsed;
        logEmailQueue("Rate limit reached. Sleeping for {$sleep} seconds.");
        sleep($sleep);
        $startTime = time();
        $emailsSentThisMinute = 0;
    }
    
    // Configure PHPMailer
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = $settings['smtp_host'];
        $mail->Port       = (int)$settings['smtp_port'];
        $enc = strtolower($settings['smtp_encryption'] ?? 'tls');
        if ($enc === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($enc === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        }
        $mail->SMTPAuth   = true;
        $mail->Username   = $settings['smtp_username'];
        $mail->Password   = $settings['smtp_password'];
        $mail->SMTPDebug  = 0; // Set to 2 for debugging
        $mail->Timeout    = 30;
        
        // Recipients
        $mail->setFrom($settings['mail_from'] ?? $settings['smtp_username'], $settings['mail_from_name'] ?? 'Library System');
        $mail->addAddress($email['to_email']);
        $mail->addReplyTo($settings['mail_from'] ?? $settings['smtp_username'], 'Library Support');
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = $email['subject'];
        $mail->Body    = $email['body'];
        $mail->AltBody = strip_tags($email['body']);
        
        // Send
        $mail->send();
        
        // Update status to 'sent'
        $update = $db->prepare("UPDATE email_queue SET status = 'sent', last_attempt = NOW() WHERE id = ?");
        $update->execute([$email['id']]);
        
        logEmailQueue("Sent email #{$email['id']} to {$email['to_email']}: {$email['subject']}", 'success');
        $sent++;
        $emailsSentThisMinute++;
        
    } catch (Exception $e) {
        $errorMsg = $mail->ErrorInfo ?? $e->getMessage();
        $attempts = (int)$email['attempts'] + 1;
        $newStatus = ($attempts >= $maxRetries) ? 'failed' : 'pending';
        
        // Exponential backoff: next retry time = now + baseDelay * 2^(attempts-1)
        $nextRetry = date('Y-m-d H:i:s', time() + ($baseDelay * pow(2, $attempts - 1)));
        
        $update = $db->prepare("UPDATE email_queue 
                                SET attempts = attempts + 1, 
                                    last_attempt = NOW(), 
                                    status = ?, 
                                    error = ?,
                                    next_retry = ?
                                WHERE id = ?");
        $update->execute([$newStatus, substr($errorMsg, 0, 500), $nextRetry, $email['id']]);
        
        logEmailQueue("Failed to send email #{$email['id']} (attempt {$attempts}/{$maxRetries}): " . $errorMsg, 'error');
        $failed++;
    }
    
    // Small delay between emails to avoid overwhelming SMTP server
    usleep(200000); // 200 ms
}

// ==================== CLEANUP OLD EMAILS ====================

// Delete sent emails older than 30 days and failed emails older than 7 days
$cleanup = $db->exec("DELETE FROM email_queue 
                       WHERE (status = 'sent' AND created_at < datetime('now', '-30 days'))
                          OR (status = 'failed' AND created_at < datetime('now', '-7 days'))");

if ($cleanup > 0) {
    logEmailQueue("Cleaned up $cleanup old email records.");
}

logEmailQueue("Email queue processing completed. Sent: $sent, Failed: $failed");
exit($failed > 0 ? 1 : 0);