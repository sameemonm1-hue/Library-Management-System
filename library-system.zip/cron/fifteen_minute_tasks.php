#!/usr/bin/env php
<?php
/**
 * 15-Minute Cron Tasks
 * Crontab: */15 * * * * /usr/bin/php /path/to/library-system/cron/fifteen_minute_tasks.php
 */

require_once __DIR__ . '/config.php';

$jobName = 'fifteen_minute_tasks';
if (!acquire_lock($jobName, 600)) exit(1);

try {
    cron_log("========== STARTING 15-MINUTE TASKS ==========");
    $startTime = microtime(true);
    $stats = [];

    // Process email queue (using global function from db.php)
    cron_log("Processing email queue...");
    if (function_exists('processEmailQueue')) {
        $emailProcessed = processEmailQueue(50);
    } else {
        $emailProcessed = localProcessEmailQueue(50);
    }
    $stats['emails_processed'] = $emailProcessed;
    cron_log("Processed $emailProcessed emails");

    // Process WhatsApp queue
    cron_log("Processing WhatsApp queue...");
    $whatsappProcessed = localProcessWhatsAppQueue(20);
    $stats['whatsapp_processed'] = $whatsappProcessed;
    cron_log("Processed $whatsappProcessed WhatsApp messages");

    // Send hold availability notifications (queues emails/WhatsApp, not direct)
    cron_log("Sending hold availability notifications...");
    $holdNotified = sendHoldAvailableNotifications();
    $stats['hold_notifications'] = $holdNotified;
    cron_log("Queued $holdNotified hold availability notifications");

    $duration = round(microtime(true) - $startTime, 2);
    cron_log("15-MINUTE TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("15-Minute Tasks Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

// ==================== LOCAL QUEUE PROCESSORS (fallback if global missing) ====================

function localProcessEmailQueue($limit = 50) {
    $db = getDB();
    $settings = getSettings();
    $processed = 0;
    if (empty($settings['smtp_host']) && empty($settings['mail_from'])) {
        cron_log("Email not configured, skipping", 'WARNING');
        return 0;
    }
    $stmt = $db->prepare("SELECT * FROM email_queue WHERE status = 'pending' ORDER BY priority DESC, created_at ASC LIMIT ?");
    $stmt->execute([$limit]);
    $emails = $stmt->fetchAll();
    foreach ($emails as $email) {
        $headers = "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . ($settings['mail_from'] ?? 'noreply@library.com') . "\r\n";
        $success = mail($email['to_email'], $email['subject'], $email['body'], $headers);
        $newStatus = $success ? 'sent' : 'failed';
        $attempts = (int)$email['attempts'] + 1;
        $update = $db->prepare("UPDATE email_queue SET status = ?, attempts = ?, last_attempt = CURRENT_TIMESTAMP, error = ? WHERE id = ?");
        $update->execute([$newStatus, $attempts, $success ? null : 'Mail send failed', $email['id']]);
        if ($success) $processed++;
        usleep(100000);
    }
    return $processed;
}

function localProcessWhatsAppQueue($limit = 20) {
    $db = getDB();
    $settings = getSettings();
    if (empty($settings['enable_whatsapp'])) return 0;
    $stmt = $db->prepare("SELECT * FROM whatsapp_queue WHERE status = 'pending' ORDER BY priority DESC, created_at ASC LIMIT ?");
    $stmt->execute([$limit]);
    $messages = $stmt->fetchAll();
    $processed = 0;
    foreach ($messages as $msg) {
        // Placeholder: actual WhatsApp API call would go here.
        // Since no real gateway is configured, we just mark as sent.
        $success = true; // Simulate success
        $newStatus = $success ? 'sent' : 'pending';
        $attempts = (int)$msg['attempts'] + 1;
        $update = $db->prepare("UPDATE whatsapp_queue SET status = ?, attempts = ?, last_attempt = CURRENT_TIMESTAMP WHERE id = ?");
        $update->execute([$newStatus, $attempts, $msg['id']]);
        if ($success) $processed++;
        usleep(200000);
    }
    return $processed;
}

function sendHoldAvailableNotifications() {
    $db = getDB();
    $settings = getSettings();
    $notified = 0;
    $stmt = $db->prepare("
        SELECT h.id, h.admno, h.member_name, h.book_barcode, b.title, m.email, m.phone
        FROM book_holds h
        JOIN books b ON h.book_barcode = b.barcode
        JOIN members m ON h.admno = m.admno
        WHERE h.status = 'available' AND h.notified = 0 LIMIT 10
    ");
    $stmt->execute();
    foreach ($stmt->fetchAll() as $hold) {
        $subject = "Hold Available: {$hold['title']}";
        $body = "Dear {$hold['member_name']},\n\nThe book '{$hold['title']}' is now available for pickup. Please collect it by " . date('Y-m-d', strtotime('+7 days')) . ".\n\nThank you.";
        if (!empty($settings['enable_email']) && !empty($hold['email'])) {
            queueEmail($hold['email'], $subject, nl2br($body));
        }
        if (!empty($settings['enable_whatsapp']) && !empty($hold['phone'])) {
            addWhatsAppMessage($hold['phone'], $body);
        }
        $db->prepare("UPDATE book_holds SET notified = 1 WHERE id = ?")->execute([$hold['id']]);
        $notified++;
    }
    return $notified;
}