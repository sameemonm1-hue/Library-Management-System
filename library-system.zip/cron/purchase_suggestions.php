#!/usr/bin/env php
<?php
/**
 * Purchase Suggestions Cron
 * 
 * Analyzes circulation trends, member suggestions, and external bestseller APIs
 * to generate smart purchase recommendations.
 * 
 * Features:
 * - Analyzes most borrowed categories / authors
 * - Processes pending member suggestions (from suggestions table)
 * - Fetches trending books from OpenLibrary (or fallback to Google Books)
 * - Stores suggestions in `purchase_suggestions` table with confidence scores
 * - Deduplicates against existing books and recent purchase orders
 * 
 * Usage: php cron/suggest_purchases.php
 * 
 * Crontab example (weekly on Monday at 5 AM):
 *   0 5 * * 1 /usr/bin/php /path/to/library-system/cron/suggest_purchases.php >> /var/log/library-cron.log 2>&1
 */

// ==================== BOOTSTRAP ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';

// Load cron config (provides locking, logging, etc.)
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
} else {
    // Fallback minimal logging and locking if config.php not present
    define('CRON_LOG_DIR', __DIR__ . '/logs/');
    define('CRON_LOCK_DIR', __DIR__ . '/locks/');
    if (!is_dir(CRON_LOG_DIR)) mkdir(CRON_LOG_DIR, 0755, true);
    if (!is_dir(CRON_LOCK_DIR)) mkdir(CRON_LOCK_DIR, 0755, true);
    
    function cron_log($msg, $type = 'INFO') {
        $logFile = CRON_LOG_DIR . 'cron_' . date('Y-m-d') . '.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] [$type] $msg" . PHP_EOL, FILE_APPEND);
        if (php_sapi_name() === 'cli') echo "[$timestamp] $msg\n";
    }
    
    function acquire_lock($jobName, $timeout = 300) {
        $lockFile = CRON_LOCK_DIR . $jobName . '.lock';
        if (file_exists($lockFile) && (time() - (int)file_get_contents($lockFile)) < $timeout) {
            cron_log("Job $jobName already running, skipping.", 'WARNING');
            return false;
        }
        if (file_exists($lockFile)) unlink($lockFile);
        file_put_contents($lockFile, time());
        return true;
    }
    
    function release_lock($jobName) {
        $lockFile = CRON_LOCK_DIR . $jobName . '.lock';
        if (file_exists($lockFile)) unlink($lockFile);
    }
    
    function notify_admin($subject, $message, $level = 'error') {
        $settings = getSettings();
        $adminEmail = $settings['backup_email'] ?? '';
        if (!empty($adminEmail)) {
            sendEmail($adminEmail, "[Cron] $subject", nl2br($message));
        }
        cron_log("ADMIN NOTIFICATION: $subject - $message", strtoupper($level));
    }
}

$jobName = 'suggest_purchases';
if (!acquire_lock($jobName)) {
    exit(0);
}

try {
    cron_log("=== PURCHASE SUGGESTIONS CRON STARTED ===");
    $startTime = microtime(true);
    
    $db = getDB();
    $settings = getSettings();
    $institution = getInstitution();
    
    // ==================== CREATE TABLE IF NOT EXISTS ====================
    $db->exec("CREATE TABLE IF NOT EXISTS purchase_suggestions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT,
        isbn TEXT,
        source TEXT NOT NULL,  -- 'circulation_trend', 'member_suggestion', 'bestseller_api'
        confidence_score REAL DEFAULT 0.5,
        reason TEXT,
        member_admno TEXT,
        suggestion_id INTEGER,
        status TEXT DEFAULT 'pending',  -- pending, approved, rejected, purchased
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME
    )");
    
    // Add index for performance
    $db->exec("CREATE INDEX IF NOT EXISTS idx_purchase_suggestions_status ON purchase_suggestions(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_purchase_suggestions_isbn ON purchase_suggestions(isbn)");
    
    // ==================== HELPER: Check if book already exists in catalog ====================
    function bookExists($isbn, $title) {
        $db = getDB();
        if (!empty($isbn)) {
            $stmt = $db->prepare("SELECT id FROM books WHERE isbn = ?");
            $stmt->execute([$isbn]);
            if ($stmt->fetch()) return true;
        }
        // Fallback to title matching (exact or similar)
        $stmt = $db->prepare("SELECT id FROM books WHERE title LIKE ? LIMIT 1");
        $stmt->execute(["%$title%"]);
        return (bool)$stmt->fetch();
    }
    
    // ==================== 1. ANALYZE CIRCULATION TRENDS ====================
    cron_log("Analyzing circulation trends (last 90 days)...");
    // Top categories by circulation
    $categoryStmt = $db->query("
        SELECT b.category, COUNT(c.id) as borrow_count
        FROM circulation c
        JOIN books b ON c.barcode = b.barcode
        WHERE c.issue_date >= date('now', '-90 days')
          AND b.category IS NOT NULL AND b.category != ''
        GROUP BY b.category
        ORDER BY borrow_count DESC
        LIMIT 5
    ");
    $topCategories = $categoryStmt->fetchAll();
    
    // For each top category, find popular books not yet in library
    $suggestedFromTrends = 0;
    foreach ($topCategories as $cat) {
        $category = $cat['category'];
        cron_log("Checking category: $category (borrowed {$cat['borrow_count']} times)");
        
        // Query OpenLibrary for trending books in this category (using subject search)
        $url = "https://openlibrary.org/subjects/" . urlencode($category) . ".json?limit=10";
        $ctx = stream_context_create(['http' => ['timeout' => 10, 'ignore_errors' => true]]);
        $response = @file_get_contents($url, false, $ctx);
        if ($response) {
            $data = json_decode($response, true);
            if (isset($data['works']) && is_array($data['works'])) {
                foreach ($data['works'] as $work) {
                    $title = $work['title'] ?? '';
                    $author = isset($work['authors'][0]['name']) ? $work['authors'][0]['name'] : '';
                    $isbn = '';
                    // Try to get ISBN from the work (not always available; fallback to searching)
                    if (isset($work['isbn']) && is_array($work['isbn']) && !empty($work['isbn'])) {
                        $isbn = $work['isbn'][0];
                    }
                    if (empty($title)) continue;
                    if (bookExists($isbn, $title)) continue;
                    
                    // Check if already suggested
                    $check = $db->prepare("SELECT id FROM purchase_suggestions WHERE title = ? AND source = 'circulation_trend'");
                    $check->execute([$title]);
                    if ($check->fetch()) continue;
                    
                    $stmt = $db->prepare("INSERT INTO purchase_suggestions (title, author, isbn, source, confidence_score, reason, status)
                                          VALUES (?, ?, ?, 'circulation_trend', 0.7, ?, 'pending')");
                    $reason = "Based on high demand in category: $category";
                    $stmt->execute([$title, $author, $isbn, $reason]);
                    $suggestedFromTrends++;
                    cron_log("  Suggested from trends: $title ($category)");
                }
            }
        }
        sleep(1); // polite delay
    }
    cron_log("Added $suggestedFromTrends suggestions from circulation trends.");
    
    // ==================== 2. MEMBER SUGGESTIONS (pending suggestions) ====================
    cron_log("Processing member suggestions (pending)...");
    $pendingSuggestions = $db->query("
        SELECT id, title, author, isbn, reason, member_admno
        FROM suggestions
        WHERE status = 'pending'
        ORDER BY created_at ASC
        LIMIT 20
    ")->fetchAll();
    
    $suggestedFromMembers = 0;
    foreach ($pendingSuggestions as $sug) {
        if (bookExists($sug['isbn'], $sug['title'])) {
            // Auto-approve? Not – just skip.
            cron_log("  Skipping suggestion #{$sug['id']} – book already exists.");
            continue;
        }
        // Check if already in purchase_suggestions
        $check = $db->prepare("SELECT id FROM purchase_suggestions WHERE title = ? AND source = 'member_suggestion'");
        $check->execute([$sug['title']]);
        if ($check->fetch()) continue;
        
        $stmt = $db->prepare("INSERT INTO purchase_suggestions (title, author, isbn, source, confidence_score, reason, member_admno, suggestion_id, status)
                              VALUES (?, ?, ?, 'member_suggestion', 0.9, ?, ?, ?, 'pending')");
        $reason = "Member suggestion: " . ($sug['reason'] ?: "Requested by member");
        $stmt->execute([
            $sug['title'], $sug['author'], $sug['isbn'],
            $reason, $sug['member_admno'], $sug['id']
        ]);
        $suggestedFromMembers++;
        cron_log("  Added member suggestion: {$sug['title']} (ID #{$sug['id']})");
    }
    cron_log("Added $suggestedFromMembers suggestions from member requests.");
    
    // ==================== 3. BESTSELLER API (NYT / OpenLibrary Trending) ====================
    cron_log("Fetching bestsellers from external APIs...");
    
    // Option A: OpenLibrary trending (default, no API key)
    $trendingUrl = "https://openlibrary.org/trending.json";
    $response = @file_get_contents($trendingUrl, false, $ctx);
    $bestsellers = [];
    if ($response) {
        $data = json_decode($response, true);
        if (isset($data['works']) && is_array($data['works'])) {
            foreach ($data['works'] as $work) {
                $title = $work['title'] ?? '';
                $author = isset($work['authors'][0]['name']) ? $work['authors'][0]['name'] : '';
                $isbn = '';
                if (isset($work['isbn']) && is_array($work['isbn']) && !empty($work['isbn'])) {
                    $isbn = $work['isbn'][0];
                }
                if (empty($title)) continue;
                $bestsellers[] = ['title' => $title, 'author' => $author, 'isbn' => $isbn];
                if (count($bestsellers) >= 20) break;
            }
        }
    }
    
    // Option B: Google Books bestsellers (if NYT API not available, use Google Books)
    if (empty($bestsellers)) {
        $googleUrl = "https://www.googleapis.com/books/v1/volumes?q=subject:bestsellers&maxResults=20&orderBy=relevance";
        $resp = @file_get_contents($googleUrl, false, $ctx);
        if ($resp) {
            $data = json_decode($resp, true);
            if (isset($data['items'])) {
                foreach ($data['items'] as $item) {
                    $info = $item['volumeInfo'] ?? [];
                    $title = $info['title'] ?? '';
                    $author = isset($info['authors'][0]) ? $info['authors'][0] : '';
                    $isbn = '';
                    if (isset($info['industryIdentifiers'])) {
                        foreach ($info['industryIdentifiers'] as $id) {
                            if ($id['type'] === 'ISBN_13') {
                                $isbn = $id['identifier'];
                                break;
                            }
                        }
                    }
                    if (empty($title)) continue;
                    $bestsellers[] = ['title' => $title, 'author' => $author, 'isbn' => $isbn];
                    if (count($bestsellers) >= 20) break;
                }
            }
        }
    }
    
    $suggestedFromApi = 0;
    foreach ($bestsellers as $book) {
        if (bookExists($book['isbn'], $book['title'])) continue;
        $check = $db->prepare("SELECT id FROM purchase_suggestions WHERE title = ? AND source = 'bestseller_api'");
        $check->execute([$book['title']]);
        if ($check->fetch()) continue;
        
        $stmt = $db->prepare("INSERT INTO purchase_suggestions (title, author, isbn, source, confidence_score, reason, status)
                              VALUES (?, ?, ?, 'bestseller_api', 0.8, ?, 'pending')");
        $reason = "Currently trending / bestseller";
        $stmt->execute([$book['title'], $book['author'], $book['isbn'], $reason]);
        $suggestedFromApi++;
        cron_log("  Added bestseller: {$book['title']}");
    }
    cron_log("Added $suggestedFromApi suggestions from bestseller APIs.");
    
    // ==================== 4. DEDUPLICATION CLEANUP ====================
    // Remove duplicate suggestions (same ISBN or same title+author)
    $db->exec("DELETE FROM purchase_suggestions
               WHERE id NOT IN (
                   SELECT MIN(id) FROM purchase_suggestions
                   WHERE status = 'pending'
                   GROUP BY COALESCE(isbn, title)
               )");
    
    // ==================== 5. SUMMARY & NOTIFICATION ====================
    $totalPending = $db->query("SELECT COUNT(*) FROM purchase_suggestions WHERE status = 'pending'")->fetchColumn();
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("SUGGESTIONS CRON COMPLETED in {$duration}s");
    cron_log("Stats: Trends: $suggestedFromTrends, Member: $suggestedFromMembers, API: $suggestedFromApi, Total pending: $totalPending");
    
    // If there are pending suggestions, notify admin (optional)
    if ($totalPending > 0 && ($settings['enable_email'] ?? false)) {
        $adminEmail = $settings['backup_email'] ?? '';
        if ($adminEmail) {
            $subject = "New Purchase Suggestions Available – Library ERP";
            $message = "Dear Admin,<br><br>The automatic purchase suggestion system has identified $totalPending new book suggestions. Please review them in Admin → Acquisitions → Purchase Suggestions.<br><br>Generated: " . date('Y-m-d H:i:s');
            sendEmail($adminEmail, $subject, $message);
            cron_log("Notification email sent to admin.");
        }
    }
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), 'ERROR');
    notify_admin("Purchase Suggestions Cron Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

exit(0);