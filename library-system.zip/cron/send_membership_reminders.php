#!/usr/bin/env php
<?php
/**
 * Send Membership Reminders
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'send_membership_reminders';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING MEMBERSHIP REMINDERS ==========");
    $startTime = microtime(true);
    $db = getDB();
    $settings = getSettings();

    $stats = ['reminders_30d'=>0, 'reminders_15d'=>0, 'reminders_7d'=>0, 'reminders_3d'=>0, 'reminders_1d'=>0, 'expired_notified'=>0, 'members_updated'=>0];
    $reminderDays = [30,15,7,3,1];

    foreach ($reminderDays as $days) {
        $stmt = $db->prepare("SELECT id, admno, name, email, phone, membership_expiry FROM members WHERE status='active' AND membership_expiry=date('now','+'.$days.' days') AND (last_reminder_sent IS NULL OR last_reminder_sent < date('now','-1 day'))");
        $stmt->execute([$days]);
        $members = $stmt->fetchAll();
        foreach ($members as $member) {
            if (!empty($settings['enable_email']) && !empty($member['email'])) {
                sendMembershipReminderEmail($member, $days);
                $stats['reminders_'.$days.'d']++;
            }
            $db->prepare("UPDATE members SET last_reminder_sent = date('now') WHERE id = ?")->execute([$member['id']]);
        }
        if (count($members)) cron_log("Sent {$days}-day reminders to " . count($members) . " members");
    }

    // Expired memberships
    $stmt = $db->prepare("SELECT id, admno, name, email, phone, membership_expiry FROM members WHERE status='active' AND membership_expiry<date('now') AND (expiry_notified=0 OR expiry_notified IS NULL)");
    $stmt->execute();
    $expired = $stmt->fetchAll();
    foreach ($expired as $member) {
        if (!empty($settings['enable_email']) && !empty($member['email'])) {
            sendMembershipExpiredEmail($member);
            $stats['expired_notified']++;
        }
        $db->prepare("UPDATE members SET status='inactive', expiry_notified=1 WHERE id=?")->execute([$member['id']]);
        $stats['members_updated']++;
    }
    if (count($expired)) cron_log("Notified " . count($expired) . " expired members");

    $duration = round(microtime(true)-$startTime,2);
    cron_log("MEMBERSHIP REMINDERS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}

function sendMembershipReminderEmail($member, $days) {
    $institution = getInstitution();
    $subject = "Library Membership Expiring Soon";
    $message = "<html><body><h3>Library Membership Renewal Reminder</h3><p>Dear {$member['name']},</p><p>Your membership expires on <strong>{$member['membership_expiry']}</strong> ({$days} days).</p><p>Please renew to continue services.</p><p>Thank you,<br>{$institution['name']} Library</p></body></html>";
    if (function_exists('queueEmail')) queueEmail($member['email'], $subject, $message);
}

function sendMembershipExpiredEmail($member) {
    $institution = getInstitution();
    $subject = "Library Membership Expired";
    $message = "<html><body><h3>Membership Expired</h3><p>Dear {$member['name']},</p><p>Your membership expired on {$member['membership_expiry']}. Please renew.</p><p>{$institution['name']} Library</p></body></html>";
    if (function_exists('queueEmail')) queueEmail($member['email'], $subject, $message);
}