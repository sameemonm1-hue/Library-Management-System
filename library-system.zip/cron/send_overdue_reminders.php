#!/usr/bin/env php
<?php
/**
 * Send Overdue Reminders
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'send_overdue_reminders';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING OVERDUE REMINDERS ==========");
    $db = getDB();
    if (!$db) throw new Exception("DB connection failed");

    $stats = ['emails_sent' => 0, 'sms_sent' => 0, 'whatsapp_sent' => 0, 'errors' => 0];
    $settings = getSettings();

    $stmt = $db->prepare("
        SELECT c.*, m.name as member_name, m.email, m.phone, m.admno, m.member_category,
               b.title, b.author,
               CAST(julianday('now') - julianday(c.due_date) AS INTEGER) as days_overdue
        FROM circulation c
        JOIN members m ON c.admno = m.admno
        JOIN books b ON c.barcode = b.barcode
        WHERE c.return_date IS NULL AND c.due_date < date('now') AND m.status = 'active'
    ");
    $stmt->execute();
    $overdueBooks = $stmt->fetchAll();
    cron_log("Found " . count($overdueBooks) . " overdue books");

    foreach ($overdueBooks as $book) {
        $days = max(1, (int)$book['days_overdue']);
        $fine = calculateFine($book['due_date'], $book['member_category']);
        if (!empty($settings['enable_email']) && !empty($book['email'])) {
            $subject = "Overdue Book Notice - {$book['title']}";
            $message = "Dear {$book['member_name']},\n\nThe book '{$book['title']}' is {$days} days overdue.\nFine: " . formatCurrency($fine) . "\nPlease return it.";
            if (function_exists('queueEmail')) {
                queueEmail($book['email'], $subject, nl2br($message));
                $stats['emails_sent']++;
            } else {
                cron_log("queueEmail() missing", 'WARNING');
            }
            logNotification($book['id'], $book['admno'], 'email', $days, 'queued');
        }
    }

    sendOverdueSummary($stats);
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("OVERDUE REMINDERS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}

function logNotification($circulationId, $admno, $type, $days, $status, $error = null) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO overdue_notifications (circulation_id, admno, notification_type, days_overdue, status, response) VALUES (?, ?, ?, ?, ?, ?)");
    return $stmt->execute([$circulationId, $admno, $type, $days, $status, $error]);
}

function sendOverdueSummary($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    if (empty($adminEmail)) return;
    $subject = "Overdue Reminders Summary - " . date('Y-m-d');
    $message = "<html><body><h3>Overdue Reminders Summary</h3><p>Date: " . date('Y-m-d H:i:s') . "</p>
                <table border='1'><tr><th>Channel</th><th>Sent</th></tr>
                <tr><td>Email</td><td>{$stats['emails_sent']}</td></tr>
                <tr><td>SMS</td><td>{$stats['sms_sent']}</td></tr>
                <tr><td>WhatsApp</td><td>{$stats['whatsapp_sent']}</td></tr>
                <tr><td>Errors</td><td>{$stats['errors']}</td></tr>
                </table><small>Automated report</small></body></html>";
    if (function_exists('queueEmail')) queueEmail($adminEmail, $subject, $message);
    else mail($adminEmail, $subject, $message);
}