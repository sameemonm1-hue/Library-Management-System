#!/usr/bin/env php
<?php
/**
 * Sync Google Drive
 * Runs weekly on Sunday at 3:00 AM
 * 
 * Tasks:
 * 1. Upload new backups to Google Drive
 * 2. Delete old backups from Google Drive
 * 3. Verify folder access
 * 4. Send sync report
 */

require_once __DIR__ . '/config.php';

$jobName = 'sync_google_drive';
if (!acquire_lock($jobName)) {
    exit(1);
}
try {
    cron_log("========== STARTING GOOGLE DRIVE SYNC ==========");
    $db = getDB();  // ADD THIS
    $settings = getSettings();

    
    if (empty($settings['google_drive_enabled'])) {
        cron_log("Google Drive backup is disabled. Skipping sync.", "INFO");
        release_lock($jobName);
        exit(0);
    }
    
    // Check if Google API is available
    if (!function_exists('uploadToGoogleDriveSafe')) {
        cron_log("Google API Client not installed. Skipping sync.", "WARNING");
        notify_admin("Google Drive Sync Failed", "Google API Client not installed. Run: composer require google/apiclient", 'warning');
        release_lock($jobName);
        exit(0);
    }
    
    $stats = [
        'uploaded' => 0,
        'deleted' => 0,
        'errors' => 0,
        'total_backups' => 0
    ];
    
    // Create a fresh backup
    cron_log("Creating backup file...");
    $backupFile = createBackupFile();
    
    if (!$backupFile) {
        throw new Exception("Failed to create backup file");
    }
    
    cron_log("Backup created: " . basename($backupFile));
    
    // Upload to Google Drive
    cron_log("Uploading to Google Drive...");
    $uploadResult = uploadToGoogleDriveSafe($backupFile, $settings);
    
    if ($uploadResult === true) {
        $stats['uploaded'] = 1;
        cron_log("Backup uploaded successfully");
        
        // Delete local backup after successful upload
        if (file_exists($backupFile)) {
            unlink($backupFile);
            cron_log("Local backup deleted");
        }
    } else {
        $stats['errors']++;
        cron_log("Upload failed: $uploadResult", "ERROR");
        notify_admin("Google Drive Upload Failed", $uploadResult, 'error');
    }
    
    // Count total backups
    $backupDir = BACKUP_DIR;
    if (is_dir($backupDir)) {
        $stats['total_backups'] = count(glob($backupDir . 'library_backup_*.zip'));
    }
    
    // Send sync report
    sendSyncReport($stats);
    
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("GOOGLE DRIVE SYNC COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("Google Drive Sync Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

function sendSyncReport($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    
    if (empty($adminEmail)) return;
    
    $subject = "Google Drive Sync Report - " . date('Y-m-d');
    $message = "
        <html>
        <body>
            <h3>Google Drive Sync Report</h3>
            <p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
            <table border='1' cellpadding='5'>
                <tr><th>Metric</th><th>Value</th></tr>
                <tr><td>Backups Uploaded</td><td>{$stats['uploaded']}</td></tr>
                <tr><td>Backups Deleted</td><td>{$stats['deleted']}</td></tr>
                <tr><td>Errors</td><td>{$stats['errors']}</td></tr>
                <tr><td>Local Backups Remaining</td><td>{$stats['total_backups']}</td></tr>
            </table>
            <small>This is an automated report.</small>
        </body>
        </html>
    ";
    
    sendEmail($adminEmail, $subject, $message);
}
?>