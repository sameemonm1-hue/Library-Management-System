#!/usr/bin/env php
<?php
/**
 * Send WhatsApp Messages
 * Runs hourly at :30
 * 
 * Tasks:
 * 1. Process WhatsApp message queue
 * 2. Send bulk notifications
 * 3. Handle delivery reports
 */

require_once __DIR__ . '/config.php';

$jobName = 'send_whatsapp_messages';
if (!acquire_lock($jobName)) {
    exit(1);
}

try {
    cron_log("========== STARTING WHATSAPP MESSAGE PROCESSING ==========");
    $db = getDB();  // ADD THIS
    $settings = getSettings();

    
    if (empty($settings['enable_whatsapp'])) {
        cron_log("WhatsApp is disabled. Skipping.", "INFO");
        release_lock($jobName);
        exit(0);
    }
    
    $stats = [
        'processed' => 0,
        'sent' => 0,
        'failed' => 0,
        'pending_bulk' => 0
    ];
    
    // Process pending WhatsApp messages
    $stmt = $db->prepare("
        SELECT * FROM whatsapp_queue 
        WHERE status = 'pending' 
        AND attempts < 3
        ORDER BY priority DESC, created_at ASC 
        LIMIT 50
    ");
    $stmt->execute();
    $messages = $stmt->fetchAll();
    
    cron_log("Found " . count($messages) . " pending WhatsApp messages");
    
    foreach ($messages as $msg) {
        $stats['processed']++;
        
        $success = sendWhatsApp($msg['phone_number'], $msg['message']);
        
        if ($success) {
            $status = 'sent';
            $stats['sent']++;
            cron_log("Sent WhatsApp to {$msg['phone_number']}");
        } else {
            $status = 'pending';
            $stats['failed']++;
            cron_log("Failed to send WhatsApp to {$msg['phone_number']}", "WARNING");
        }
        
        $updateStmt = $db->prepare("
            UPDATE whatsapp_queue 
            SET status = ?, attempts = attempts + 1, last_attempt = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $updateStmt->execute([$status, $msg['id']]);
        
        usleep(200000); // 200ms delay to prevent rate limiting
    }
    
    // Process bulk WhatsApp notifications for overdue books
    if (!empty($settings['enable_whatsapp'])) {
        $bulkStmt = $db->prepare("
            SELECT DISTINCT m.phone, m.name, COUNT(c.id) as overdue_count
            FROM circulation c
            JOIN members m ON c.admno = m.admno
            WHERE c.return_date IS NULL 
            AND c.due_date < date('now')
            AND m.phone IS NOT NULL 
            AND m.phone != ''
            AND (c.last_whatsapp_sent IS NULL OR c.last_whatsapp_sent < date('now', '-3 days'))
            GROUP BY m.id
            LIMIT 20
        ");
        $bulkStmt->execute();
        $bulkRecipients = $bulkStmt->fetchAll();
        
        foreach ($bulkRecipients as $recipient) {
            $message = "📚 *Library Overdue Notice*\n\n";
            $message .= "Dear {$recipient['name']},\n";
            $message .= "You have {$recipient['overdue_count']} overdue book(s).\n";
            $message .= "Please return them to avoid additional fines.\n\n";
            $message .= "Thank you,\nLibrary Staff";
            
            $success = sendWhatsApp($recipient['phone'], $message);
            $stats['pending_bulk']++;
            
            if ($success) {
                // Update last sent timestamp
                $updateStmt = $db->prepare("
                    UPDATE circulation SET last_whatsapp_sent = CURRENT_TIMESTAMP
                    WHERE admno = ? AND return_date IS NULL
                ");
                $updateStmt->execute([$recipient['phone']]);
                $stats['sent']++;
            } else {
                $stats['failed']++;
            }
            
            usleep(200000);
        }
    }
    
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("WHATSAPP PROCESSING COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));
    
    // Create WhatsApp queue table if not exists
    $db->exec("CREATE TABLE IF NOT EXISTS whatsapp_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone_number TEXT NOT NULL,
        message TEXT NOT NULL,
        priority INTEGER DEFAULT 0,
        status TEXT DEFAULT 'pending',
        attempts INTEGER DEFAULT 0,
        last_attempt DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("WhatsApp Processing Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}
?>