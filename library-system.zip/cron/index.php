<?php
/**
 * Cron Jobs Manager - Manual execution interface
 * Access this file to run cron jobs manually for testing
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Only allow admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Admin privileges required.");
}

$availableJobs = [
    // High-frequency tasks
    'fifteen_minute_tasks' => 'Process email, WhatsApp, SMS queues; send hold notifications (every 15 min)',
    'thirty_minute_tasks' => 'Sync visitor counts, expiring reservations, book cache, computer sessions (every 30 min)',
    'forty_five_minute_tasks' => 'Retry failed notifications, update search index, sync session data, admin heartbeat (every 45 min)',
    
    // Hourly tasks
    'hourly_tasks' => 'Run hourly tasks (email queue processing, reservations, computer sessions)',
    
    // Daily tasks
    'daily_tasks' => 'Run daily tasks (overdue reminders, membership expiry, daily stats)',
    'send_overdue_reminders' => 'Send overdue book reminders (daily at 8 AM)',
    'send_membership_reminders' => 'Send membership expiry reminders (daily at 10 AM)',
    'update_daily_stats' => 'Update daily statistics (daily at 11:55 PM)',
    'process_email_queue' => 'Process pending email queue (can run on demand)',
    'send_whatsapp_messages' => 'Process WhatsApp message queue (hourly)',
    'cleanup_temp_files' => 'Clean temporary files (daily)',
    'auto_inactivate_members' => 'Inactivate members with no activity for 6 months (daily)',
    
    // Weekly tasks
    'weekly_tasks' => 'Run weekly tasks (backup rotation, report generation, Google Drive sync)',
    'backup_rotation' => 'Rotate and cleanup old backups (weekly)',
    'generate_reports' => 'Generate automated reports (weekly)',
    'sync_google_drive' => 'Sync backups with Google Drive (weekly)',
    
    // Monthly tasks
    'monthly_tasks' => 'Run monthly tasks (statistics compilation, log archiving, guest reset)',
    
    // Serial / Acquisition tasks
    'process_serial_issues' => 'Generate serial issues (daily)',
    'purchase_suggestions' => 'Generate purchase suggestions from trends and member requests (weekly)',
    
    // AI / Advanced
    'train_fine_model' => 'Train fine prediction model (weekly)',
    'update_book_embeddings' => 'Update AI embeddings for semantic search (daily)',
    'sync_meilisearch' => 'Sync books/members with Meilisearch index (on demand)',
];

$runJob = $_GET['run'] ?? '';
$result = '';

if ($runJob && isset($availableJobs[$runJob])) {
    ob_start();
    include __DIR__ . '/' . $runJob . '.php';
    $result = ob_get_clean();
}

renderHeader('Cron Jobs Manager');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-clock"></i> Cron Jobs Manager</h2>
        <div>
            <a href="../index.php" class="btn btn-primary">Back to Home</a>
            <a href="?refresh=1" class="btn btn-info"><i class="fas fa-sync-alt"></i> Refresh</a>
        </div>
    </div>

    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> 
        <strong>Cron Jobs Configuration:</strong> Add these to your server's crontab:
        <pre class="mt-2 mb-0"><code># ========== LIBRARY ERP CRON JOBS ==========

# High-frequency tasks (email/WhatsApp/SMS queues)
*/15 * * * * php <?= __DIR__ ?>/fifteen_minute_tasks.php >> <?= __DIR__ ?>/logs/cron_15min.log 2>&1
*/30 * * * * php <?= __DIR__ ?>/thirty_minute_tasks.php >> <?= __DIR__ ?>/logs/cron_30min.log 2>&1
*/45 * * * * php <?= __DIR__ ?>/forty_five_minute_tasks.php >> <?= __DIR__ ?>/logs/cron_45min.log 2>&1

# Hourly tasks
0 * * * * php <?= __DIR__ ?>/hourly_tasks.php >> <?= __DIR__ ?>/logs/cron_hourly.log 2>&1

# Daily tasks (adjust times as needed)
0 8 * * * php <?= __DIR__ ?>/send_overdue_reminders.php >> <?= __DIR__ ?>/logs/cron_overdue.log 2>&1
0 9 * * * php <?= __DIR__ ?>/daily_tasks.php >> <?= __DIR__ ?>/logs/cron_daily.log 2>&1
0 10 * * * php <?= __DIR__ ?>/send_membership_reminders.php >> <?= __DIR__ ?>/logs/cron_membership.log 2>&1
0 2 * * * php <?= __DIR__ ?>/update_book_embeddings.php >> <?= __DIR__ ?>/logs/cron_embeddings.log 2>&1
0 3 * * * php <?= __DIR__ ?>/process_serial_issues.php >> <?= __DIR__ ?>/logs/cron_serial.log 2>&1
55 23 * * * php <?= __DIR__ ?>/update_daily_stats.php >> <?= __DIR__ ?>/logs/cron_stats.log 2>&1
0 1 * * * php <?= __DIR__ ?>/auto_inactivate_members.php >> <?= __DIR__ ?>/logs/cron_inactive.log 2>&1

# Weekly tasks (Monday)
0 1 * * 1 php <?= __DIR__ ?>/weekly_tasks.php >> <?= __DIR__ ?>/logs/cron_weekly.log 2>&1
0 3 * * 1 php <?= __DIR__ ?>/sync_google_drive.php >> <?= __DIR__ ?>/logs/cron_gdrive.log 2>&1
0 5 * * 1 php <?= __DIR__ ?>/purchase_suggestions.php >> <?= __DIR__ ?>/logs/cron_suggestions.log 2>&1
0 4 * * 1 php <?= __DIR__ ?>/train_fine_model.php >> <?= __DIR__ ?>/logs/cron_fine_model.log 2>&1

# Monthly tasks (1st day)
0 2 1 * * php <?= __DIR__ ?>/monthly_tasks.php >> <?= __DIR__ ?>/logs/cron_monthly.log 2>&1</code></pre>
        <p class="mt-2 mb-0 small"><i class="fas fa-lightbulb"></i> Tip: Run <code>crontab -e</code> and paste the lines above (adjust PHP path if needed).</p>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-tasks"></i> Available Cron Jobs</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="table-dark">
                                <tr><th>Job Name</th><th>Description</th><th>Action</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($availableJobs as $job => $desc): ?>
                                <tr>
                                    <td><code><?= htmlspecialchars($job) ?></code></td>
                                    <td><?= htmlspecialchars($desc) ?></td>
                                    <td>
                                        <a href="?run=<?= $job ?>" class="btn btn-sm btn-primary" onclick="return confirm('Run <?= $job ?>?')">
                                            <i class="fas fa-play"></i> Run Now
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-history"></i> Last Execution Logs</h5>
                </div>
                <div class="card-body">
                    <?php
                    $logFiles = glob(__DIR__ . '/logs/cron_*.log');
                    rsort($logFiles);
                    if (!empty($logFiles)):
                        $logs = file($logFiles[0]);
                        $lastLogs = array_slice($logs, -20);
                        echo '<pre class="small" style="max-height: 400px; overflow-y: auto;">';
                        foreach ($lastLogs as $log) {
                            echo htmlspecialchars($log);
                        }
                        echo '</pre>';
                    else:
                        echo '<p class="text-muted">No logs found. Run a cron job first.</p>';
                    endif;
                    ?>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0"><i class="fas fa-chart-line"></i> Job Status</h5>
                </div>
                <div class="card-body">
                    <?php
                    // Quick status check: list running jobs via lock files
                    $lockDir = __DIR__ . '/locks/';
                    if (is_dir($lockDir)) {
                        $locks = glob($lockDir . '*.lock');
                        if (!empty($locks)) {
                            echo '<p class="mb-0"><strong>Currently running:</strong></p><ul class="small">';
                            foreach ($locks as $lock) {
                                $jobName = basename($lock, '.lock');
                                $lockTime = filemtime($lock);
                                $age = time() - $lockTime;
                                if ($age < 600) { // less than 10 minutes – still running
                                    echo '<li><code>' . htmlspecialchars($jobName) . '</code> (started ' . round($age / 60, 1) . ' min ago)</li>';
                                } else {
                                    // stale lock – remove
                                    @unlink($lock);
                                }
                            }
                            echo '</ul>';
                        } else {
                            echo '<p class="text-success mb-0"><i class="fas fa-check-circle"></i> No cron jobs currently running.</p>';
                        }
                    } else {
                        echo '<p class="text-muted mb-0">Lock directory not found.</p>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php if ($result): ?>
    <div class="card mt-3">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0">Execution Result: <?= htmlspecialchars($runJob) ?></h5>
        </div>
        <div class="card-body">
            <pre class="mb-0"><?= htmlspecialchars($result) ?></pre>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php renderFooter(); ?>