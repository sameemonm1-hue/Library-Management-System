#!/usr/bin/env php
<?php
/**
 * Backup Rotation
 */

require_once __DIR__ . '/config.php';

$jobName = 'backup_rotation';
if (!acquire_lock($jobName)) {
    exit(1);
}

try {
    cron_log("========== STARTING BACKUP ROTATION ==========");
    $startTime = microtime(true);
    
    $stats = ['deleted' => 0, 'compressed' => 0, 'total_size_saved' => 0, 'backups_remaining' => 0];
    $settings = getSettings();
    $keepDays = (int)($settings['google_drive_auto_delete_days'] ?? 30);
    $backupDir = defined('BACKUP_DIR') ? BACKUP_DIR : __DIR__ . '/../backups/';
    
    if (!is_dir($backupDir)) {
        throw new Exception("Backup directory not found: $backupDir");
    }
    
    $files = glob($backupDir . 'library_backup_*.zip');
    $stats['backups_remaining'] = count($files);
    cron_log("Found " . count($files) . " backup files");
    
    usort($files, fn($a, $b) => filemtime($a) - filemtime($b));
    $cutoffTime = strtotime("-$keepDays days");
    $deletedSize = 0;
    
    foreach ($files as $file) {
        if (filemtime($file) < $cutoffTime) {
            $deletedSize += filesize($file);
            unlink($file);
            $stats['deleted']++;
            cron_log("Deleted old backup: " . basename($file));
        }
    }
    
    $files = glob($backupDir . 'library_backup_*.zip');
    usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
    if (count($files) > 5) {
        foreach (array_slice($files, 5) as $file) {
            $deletedSize += filesize($file);
            unlink($file);
            $stats['deleted']++;
            cron_log("Deleted excess backup: " . basename($file));
        }
    }
    
    $stats['total_size_saved'] = round($deletedSize / 1024 / 1024, 2);
    $stats['backups_remaining'] = count(glob($backupDir . 'library_backup_*.zip'));
    
    // Compress old logs
    $logFiles = glob(CRON_LOG_DIR . '*.log');
    $cutoffLogTime = strtotime('-30 days');
    foreach ($logFiles as $file) {
        if (filemtime($file) < $cutoffLogTime) {
            $gzFile = $file . '.gz';
            file_put_contents($gzFile, gzencode(file_get_contents($file), 9));
            unlink($file);
            $stats['compressed']++;
            cron_log("Compressed log: " . basename($file));
        }
    }
    
    sendRotationReport($stats);
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("BACKUP ROTATION COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("Backup Rotation Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

function sendRotationReport($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    if (empty($adminEmail)) return;
    $subject = "Backup Rotation Report - " . date('Y-m-d');
    $message = "<html><body><h3>Backup Rotation Report</h3><p><strong>Date:</strong> " . date('Y-m-d H:i:s') . "</p>
                <table border='1'><tr><th>Metric</th><th>Value</th></tr>
                <tr><td>Backups Deleted</td><td>{$stats['deleted']}</td></tr>
                <tr><td>Logs Compressed</td><td>{$stats['compressed']}</td></tr>
                <tr><td>Space Saved</td><td>{$stats['total_size_saved']} MB</td></tr>
                <tr><td>Backups Remaining</td><td>{$stats['backups_remaining']}</td></tr></table>
                <small>This is an automated report.</small></body></html>";
    sendEmail($adminEmail, $subject, $message);
}