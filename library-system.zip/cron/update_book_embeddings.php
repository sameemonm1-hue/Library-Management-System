#!/usr/bin/env php
<?php
/**
 * Update Book Embeddings Cron Job
 * 
 * Fetches books without embeddings, sends them in batches to the AI embedding server,
 * and updates the books.embedding column (JSON).
 * 
 * Usage: php cron/update_book_embeddings.php [--force] [--limit=100]
 * 
 * Options:
 *   --force   Force update even if embedding already exists (useful for re‑generating)
 *   --limit   Maximum number of books to process (default: 500)
 *   --batch   Batch size per API request (default: 50)
 *   --debug   Enable verbose output
 * 
 * Cron example (daily at 2 AM):
 *   0 2 * * * /usr/bin/php /path/to/library-system/cron/update_book_embeddings.php >> /var/log/library_embeddings.log 2>&1
 */

// ==================== BOOTSTRAP ====================
$rootPath = dirname(__DIR__);
require_once $rootPath . '/config/db.php';
require_once $rootPath . '/config/functions.php';
require_once $rootPath . '/includes/AIEmbedding.php';

// Parse command line arguments
$options = getopt('', ['force', 'limit:', 'batch:', 'debug']);
$force = isset($options['force']);
$limit = isset($options['limit']) ? (int)$options['limit'] : 500;
$batchSize = isset($options['batch']) ? (int)$options['batch'] : 50;
$debug = isset($options['debug']);

// Initialize logging
function logMessage($msg, $type = 'info') {
    $timestamp = date('Y-m-d H:i:s');
    $prefix = match($type) {
        'error' => '❌ ERROR',
        'success' => '✅ SUCCESS',
        'warning' => '⚠️ WARNING',
        default => 'ℹ️ INFO'
    };
    echo "[$timestamp] $prefix: $msg" . PHP_EOL;
    if ($type === 'error') {
        error_log("[LibraryERP] $msg");
    }
}

logMessage("Starting book embeddings update (force=" . ($force ? 'yes' : 'no') . ", limit=$limit, batch=$batchSize)");

// ==================== DATABASE SETUP ====================
$db = getDB();

// Ensure books.embedding column exists (JSON) – add if missing
try {
    $colCheck = $db->query("PRAGMA table_info(books)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('embedding', $colCheck)) {
        $db->exec("ALTER TABLE books ADD COLUMN embedding TEXT");
        logMessage("Added 'embedding' column to books table", 'warning');
    }
} catch (PDOException $e) {
    logMessage("Failed to check/add embedding column: " . $e->getMessage(), 'error');
    exit(1);
}

// ==================== FETCH BOOKS WITHOUT EMBEDDINGS ====================
$sql = "SELECT id, title, COALESCE(summary, '') as summary, COALESCE(author, '') as author 
        FROM books 
        WHERE (embedding IS NULL OR embedding = '' OR embedding = 'null')";
if (!$force) {
    $sql .= " AND (embedding IS NULL OR embedding = '' OR embedding = 'null')";
}
$sql .= " ORDER BY id LIMIT ?";

$stmt = $db->prepare($sql);
$stmt->execute([$limit]);
$books = $stmt->fetchAll();

if (empty($books)) {
    logMessage("No books need embeddings. Exiting.", 'success');
    exit(0);
}

logMessage("Found " . count($books) . " books to process");

// ==================== INITIALIZE AI EMBEDDING CLIENT ====================
AIEmbedding::init();

// Check if embedding server is healthy
if (!AIEmbedding::isHealthy()) {
    logMessage("AI embedding server is not healthy. Check that the Python server is running at " . getenv('AI_EMBEDDING_URL') ?: 'http://localhost:5001', 'warning');
    if (!AIEmbedding::$fallbackToDummy) {
        logMessage("Embedding server unavailable and fallback disabled. Exiting.", 'error');
        exit(1);
    }
    logMessage("Using fallback dummy embeddings (quality degraded).", 'warning');
}

// ==================== PROCESS IN BATCHES ====================
$totalUpdated = 0;
$totalErrors = 0;
$chunks = array_chunk($books, $batchSize);

foreach ($chunks as $chunkIndex => $chunk) {
    logMessage("Processing batch " . ($chunkIndex + 1) . " of " . count($chunks) . " (" . count($chunk) . " books)");
    
    // Prepare texts for embedding (combine title + author + summary)
    $texts = [];
    $bookIds = [];
    foreach ($chunk as $book) {
        $text = $book['title'];
        if (!empty($book['author'])) {
            $text .= " by " . $book['author'];
        }
        if (!empty($book['summary'])) {
            $text .= ". " . $book['summary'];
        }
        // Truncate to 1000 characters to avoid token limits
        $text = mb_substr($text, 0, 1000);
        $texts[] = $text;
        $bookIds[] = $book['id'];
    }
    
    // Get embeddings from server
    if ($debug) logMessage("Sending " . count($texts) . " texts to embedding server");
    $embeddings = AIEmbedding::batchGetEmbeddings($texts);
    
    if ($embeddings === null || count($embeddings) !== count($texts)) {
        logMessage("Batch failed: embeddings count mismatch or null", 'error');
        $totalErrors += count($chunk);
        continue;
    }
    
    // Update database in a transaction for this batch
    $db->beginTransaction();
    try {
        $updateStmt = $db->prepare("UPDATE books SET embedding = ? WHERE id = ?");
        $successCount = 0;
        foreach ($bookIds as $idx => $id) {
            $embeddingJson = json_encode($embeddings[$idx], JSON_UNESCAPED_UNICODE);
            $updateStmt->execute([$embeddingJson, $id]);
            if ($updateStmt->rowCount() > 0) {
                $successCount++;
            }
        }
        $db->commit();
        logMessage("Batch updated: $successCount successful, " . (count($bookIds) - $successCount) . " failed", 'success');
        $totalUpdated += $successCount;
        $totalErrors += (count($bookIds) - $successCount);
    } catch (PDOException $e) {
        $db->rollBack();
        logMessage("Database error in batch: " . $e->getMessage(), 'error');
        $totalErrors += count($bookIds);
    }
    
    // Small delay to avoid overwhelming the server
    if ($chunkIndex + 1 < count($chunks)) {
        sleep(1);
    }
}

// ==================== FINAL REPORT ====================
logMessage("Embedding update completed: $totalUpdated books updated, $totalErrors errors", $totalErrors > 0 ? 'warning' : 'success');
exit($totalErrors > 0 ? 1 : 0);