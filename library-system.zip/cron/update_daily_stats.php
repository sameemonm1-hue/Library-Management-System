#!/usr/bin/env php
<?php
/**
 * Update Daily Statistics
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'update_daily_stats';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING DAILY STATS UPDATE ==========");
    $startTime = microtime(true);
    $db = getDB();
    $today = date('Y-m-d');

    $stats = [
        'books_issued' => $db->query("SELECT COUNT(*) FROM circulation WHERE issue_date='$today'")->fetchColumn(),
        'books_returned' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date='$today'")->fetchColumn(),
        'members_registered' => $db->query("SELECT COUNT(*) FROM members WHERE date(created_at)='$today'")->fetchColumn(),
        'fines_collected' => $db->query("SELECT COALESCE(SUM(amount),0) FROM fine_payments WHERE date(payment_date)='$today'")->fetchColumn(),
        'entries_count' => $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date='$today'")->fetchColumn(),
        'exits_count' => $db->query("SELECT COUNT(*) FROM entry_exit WHERE exit_time IS NOT NULL AND entry_date='$today'")->fetchColumn(),
        'ebook_downloads' => $db->query("SELECT COALESCE(SUM(downloads),0) FROM ebooks WHERE created_at='$today'")->fetchColumn(),
        'new_books_added' => $db->query("SELECT COUNT(*) FROM books WHERE date(created_at)='$today'")->fetchColumn(),
        'active_loans' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL")->fetchColumn(),
        'overdue_count' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date IS NULL AND due_date<'$today'")->fetchColumn(),
        'total_outstanding_fines' => $db->query("SELECT COALESCE(SUM(total_fines),0) FROM members")->fetchColumn()
    ];

    $check = $db->prepare("SELECT id FROM daily_stats WHERE stat_date=?");
    $check->execute([$today]);
    if ($check->fetch()) {
        $db->prepare("UPDATE daily_stats SET books_issued=?, books_returned=?, members_registered=?, fines_collected=?, entries_count=?, exits_count=?, ebook_downloads=?, new_books_added=?, active_loans=?, overdue_count=?, total_outstanding_fines=? WHERE stat_date=?")
           ->execute([$stats['books_issued'], $stats['books_returned'], $stats['members_registered'], $stats['fines_collected'], $stats['entries_count'], $stats['exits_count'], $stats['ebook_downloads'], $stats['new_books_added'], $stats['active_loans'], $stats['overdue_count'], $stats['total_outstanding_fines'], $today]);
    } else {
        $db->prepare("INSERT INTO daily_stats (stat_date, books_issued, books_returned, members_registered, fines_collected, entries_count, exits_count, ebook_downloads, new_books_added, active_loans, overdue_count, total_outstanding_fines) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$today, $stats['books_issued'], $stats['books_returned'], $stats['members_registered'], $stats['fines_collected'], $stats['entries_count'], $stats['exits_count'], $stats['ebook_downloads'], $stats['new_books_added'], $stats['active_loans'], $stats['overdue_count'], $stats['total_outstanding_fines']]);
    }

    // Update member fine totals
    $db->exec("UPDATE members SET total_fines = (SELECT COALESCE(SUM(fine),0) FROM circulation WHERE circulation.admno=members.admno AND return_date IS NULL)");
    // Update book availability
    $db->exec("UPDATE books SET available = quantity - (SELECT COUNT(*) FROM circulation WHERE circulation.barcode=books.barcode AND return_date IS NULL)");

    $duration = round(microtime(true)-$startTime,2);
    cron_log("DAILY STATS UPDATE COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}