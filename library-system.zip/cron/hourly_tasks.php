#!/usr/bin/env php
<?php
/**
 * Hourly Cron Tasks
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'hourly_tasks';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING HOURLY TASKS ==========");
    $startTime = microtime(true);
    $stats = [];

    // Process email queue (use global if exists)
    cron_log("Processing email queue...");
    if (function_exists('processEmailQueue')) {
        $emailProcessed = processEmailQueue(50);
    } else {
        $emailProcessed = localProcessEmailQueue(50);
    }
    $stats['emails_processed'] = $emailProcessed;
    cron_log("Processed $emailProcessed emails");

    // Expiring reservations
    cron_log("Checking expiring reservations...");
    $reservationsCancelled = processExpiringReservations();
    $stats['reservations_cancelled'] = $reservationsCancelled;
    cron_log("Cancelled $reservationsCancelled expired reservations");

    // Computer session timeouts
    cron_log("Updating computer sessions...");
    $sessionsUpdated = updateComputerSessions();
    $stats['sessions_updated'] = $sessionsUpdated;
    cron_log("Updated $sessionsUpdated computer sessions");

    $duration = round(microtime(true) - $startTime, 2);
    cron_log("HOURLY TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}

// ==================== LOCAL FALLBACKS ====================
if (!function_exists('localProcessEmailQueue')) {
    function localProcessEmailQueue($limit = 50) {
        $db = getDB();
        $settings = getSettings();
        $processed = 0;
        $stmt = $db->prepare("SELECT * FROM email_queue WHERE status='pending' ORDER BY priority DESC, created_at ASC LIMIT ?");
        $stmt->execute([$limit]);
        $emails = $stmt->fetchAll();
        foreach ($emails as $email) {
            $headers = "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n";
            $headers .= "From: " . ($settings['mail_from'] ?? 'noreply@library.com') . "\r\n";
            $success = mail($email['to_email'], $email['subject'], $email['body'], $headers);
            $status = $success ? 'sent' : 'failed';
            $db->prepare("UPDATE email_queue SET status = ?, attempts = attempts+1, last_attempt=CURRENT_TIMESTAMP, error=? WHERE id=?")
               ->execute([$status, $success ? null : 'Mail failed', $email['id']]);
            if ($success) $processed++;
            usleep(100000);
        }
        return $processed;
    }
}

if (!function_exists('processExpiringReservations')) {
    function processExpiringReservations() {
        $db = getDB();
        $cancelled = 0;
        
        // Cancel expired reservations
        $update = $db->prepare("UPDATE reservations_queue SET status='expired' WHERE status='waiting' AND expiry_date < date('now')");
        $update->execute();
        $cancelled = $update->rowCount();
        
        // Send notifications for reservations expiring tomorrow
        $stmt = $db->prepare("
            SELECT r.*, b.title 
            FROM reservations_queue r 
            JOIN books b ON r.book_barcode = b.barcode 
            WHERE r.status='waiting' AND r.expiry_date = date('now','+1 day')
        ");
        $stmt->execute();
        $expiringSoon = $stmt->fetchAll();
        
        foreach ($expiringSoon as $res) {
            $member = getMemberByAdmno($res['admno']);
            if ($member && !empty($member['email'])) {
                $subject = "Reservation Expiring Soon";
                $message = "Dear {$member['name']},\n\nYour reservation for '{$res['title']}' expires tomorrow ({$res['expiry_date']}). Please pick up.\n\nLibrary Staff";
                if (function_exists('queueEmail')) {
                    queueEmail($member['email'], $subject, nl2br($message));
                } else {
                    // Fallback: insert into email_queue directly
                    $db->prepare("INSERT INTO email_queue (to_email, subject, body, status) VALUES (?, ?, ?, 'pending')")
                       ->execute([$member['email'], $subject, nl2br($message)]);
                }
            }
        }
        
        return $cancelled;
    }
}

if (!function_exists('updateComputerSessions')) {
    function updateComputerSessions() {
        $db = getDB();
        $update = $db->prepare("
            UPDATE computer_sessions 
            SET logout_time = datetime('now'), 
                duration_minutes = (strftime('%s','now') - strftime('%s', login_time)) / 60
            WHERE logout_time IS NULL 
              AND datetime(login_time, '+4 hours') < datetime('now')
        ");
        $update->execute();
        return $update->rowCount();
    }
}