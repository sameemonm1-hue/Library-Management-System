#!/usr/bin/env php
<?php
/**
 * Serial Issues Generator
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'process_serial_issues';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("========== STARTING SERIAL ISSUES GENERATION ==========");
    $startTime = microtime(true);
    $db = getDB();

    $today = date('Y-m-d');
    $nextWeek = date('Y-m-d', strtotime('+7 days'));
    $stmt = $db->prepare("SELECT id, title, frequency FROM serial_subscriptions WHERE status='active' AND (end_date IS NULL OR end_date>=?)");
    $stmt->execute([$today]);
    $subscriptions = $stmt->fetchAll();
    $totalGenerated = 0;

    foreach ($subscriptions as $sub) {
        $generated = generateIssues($db, $sub['id'], $today, $nextWeek);
        $totalGenerated += $generated;
        cron_log("Generated $generated issues for {$sub['title']}");
    }

    $duration = round(microtime(true)-$startTime,2);
    cron_log("SERIAL ISSUES COMPLETED - Generated $totalGenerated issues in {$duration}s");

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}

function generateIssues($db, $subId, $startDate, $endDate) {
    $stmt = $db->prepare("SELECT * FROM serial_subscriptions WHERE id=?");
    $stmt->execute([$subId]);
    $sub = $stmt->fetch();
    if (!$sub) return 0;
    $frequency = $sub['frequency'];
    $current = new DateTime($startDate);
    $end = new DateTime($endDate);
    $issueNum = getNextIssueNumber($db, $subId);
    $generated = 0;

    while ($current <= $end) {
        $check = $db->prepare("SELECT id FROM serial_issues WHERE subscription_id=? AND issue_number=? AND date_published=?");
        $check->execute([$subId, $issueNum, $current->format('Y-m-d')]);
        if (!$check->fetch()) {
            $db->prepare("INSERT INTO serial_issues (subscription_id, issue_number, date_published, status) VALUES (?,?,?,'expected')")
               ->execute([$subId, $issueNum, $current->format('Y-m-d')]);
            $generated++;
        }
        switch ($frequency) {
            case 'daily': $current->modify('+1 day'); break;
            case 'weekly': $current->modify('+1 week'); break;
            case 'monthly': $current->modify('+1 month'); break;
            default: break 2;
        }
        $issueNum++;
    }
    return $generated;
}

function getNextIssueNumber($db, $subId) {
    $stmt = $db->prepare("SELECT MAX(CAST(issue_number AS INTEGER)) FROM serial_issues WHERE subscription_id=?");
    $stmt->execute([$subId]);
    $max = (int)$stmt->fetchColumn();
    return $max + 1;
}