#!/usr/bin/env php
<?php
/**
 * 30-Minute Cron Tasks
 * Crontab: */30 * * * * /usr/bin/php /path/to/library-system/cron/thirty_minute_tasks.php
 */

require_once __DIR__ . '/config.php';

$jobName = 'thirty_minute_tasks';
if (!acquire_lock($jobName, 600)) exit(1);

try {
    cron_log("========== STARTING 30-MINUTE TASKS ==========");
    $startTime = microtime(true);
    $stats = [];

    // Sync visitor counts
    syncVisitorCounts();
    $stats['visitor_sync'] = 1;

    // Check expiring reservations and send reminders (queued)
    $expiringNotified = checkExpiringReservations();
    $stats['expiring_notified'] = $expiringNotified;

    // Update OPAC book status cache
    $booksCached = updateBookStatusCache();
    $stats['books_cached'] = $booksCached;

    // Clean stale computer sessions
    $sessionsCleaned = cleanupComputerSessions();
    $stats['sessions_cleaned'] = $sessionsCleaned;

    $duration = round(microtime(true) - $startTime, 2);
    cron_log("30-MINUTE TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("30-Minute Tasks Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

// ==================== HELPER FUNCTIONS ====================

function syncVisitorCounts() {
    $db = getDB();
    $today = date('Y-m-d');
    $inside = $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date = '$today' AND exit_time IS NULL")->fetchColumn();
    $todayEntries = $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date = '$today'")->fetchColumn();
    $cacheFile = __DIR__ . '/../opac/cache/visitor_stats.json';
    $cacheDir = dirname($cacheFile);
    if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
    file_put_contents($cacheFile, json_encode([
        'inside' => (int)$inside,
        'today_entries' => (int)$todayEntries,
        'last_updated' => date('Y-m-d H:i:s')
    ]));
    return 1;
}

function checkExpiringReservations() {
    $db = getDB();
    $settings = getSettings();
    $notified = 0;
    $stmt = $db->prepare("
        SELECT h.id, h.admno, h.member_name, h.book_barcode, b.title, h.expiry_date, m.email, m.phone
        FROM book_holds h
        JOIN books b ON h.book_barcode = b.barcode
        JOIN members m ON h.admno = m.admno
        WHERE h.status = 'available' 
          AND h.expiry_date = date('now', '+1 day')
          AND (h.notified = 0 OR h.notified IS NULL) LIMIT 20
    ");
    $stmt->execute();
    foreach ($stmt->fetchAll() as $hold) {
        $subject = "Hold Expiring Tomorrow: {$hold['title']}";
        $body = "Dear {$hold['member_name']},\n\nYour hold for '{$hold['title']}' will expire on {$hold['expiry_date']}. Please pick up the book today.\n\nThank you.";
        if (!empty($settings['enable_email']) && !empty($hold['email'])) {
            queueEmail($hold['email'], $subject, nl2br($body));
        }
        if (!empty($settings['enable_whatsapp']) && !empty($hold['phone'])) {
            addWhatsAppMessage($hold['phone'], $body);
        }
        $db->prepare("UPDATE book_holds SET notified = 1 WHERE id = ?")->execute([$hold['id']]);
        $notified++;
    }
    return $notified;
}

function updateBookStatusCache() {
    $db = getDB();
    $stmt = $db->query("
        SELECT b.id, b.available, b.book_status, b.quantity 
        FROM books b
        WHERE b.status != 'Deleted'
        ORDER BY (SELECT COUNT(*) FROM circulation c WHERE c.barcode = b.barcode AND c.issue_date > date('now', '-30 days')) DESC
        LIMIT 200
    ");
    $books = $stmt->fetchAll();
    $cache = [];
    foreach ($books as $book) {
        $cache[$book['id']] = [
            'available' => (int)$book['available'],
            'status' => $book['book_status'] ?? 'Available'
        ];
    }
    $cacheFile = __DIR__ . '/../opac/cache/book_status_cache.json';
    $cacheDir = dirname($cacheFile);
    if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
    file_put_contents($cacheFile, json_encode($cache));
    return count($books);
}

function cleanupComputerSessions() {
    $db = getDB();
    $timeout = 30;
    $stmt = $db->prepare("
        UPDATE computer_sessions 
        SET logout_time = datetime('now', '+' || ? || ' minutes'), 
            duration_minutes = (strftime('%s', 'now') - strftime('%s', login_time)) / 60
        WHERE logout_time IS NULL 
          AND datetime(login_time, '+' || ? || ' minutes') < datetime('now')
    ");
    $stmt->execute([$timeout, $timeout]);
    return $stmt->rowCount();
}