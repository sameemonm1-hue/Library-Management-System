#!/usr/bin/env php
<?php
/**
 * 45-Minute Cron Tasks
 * Crontab: */45 * * * * /usr/bin/php /path/to/library-system/cron/forty_five_minute_tasks.php
 */

require_once __DIR__ . '/config.php';

$jobName = 'forty_five_minute_tasks';
if (!acquire_lock($jobName, 900)) exit(1);

try {
    cron_log("========== STARTING 45-MINUTE TASKS ==========");
    $startTime = microtime(true);
    $stats = [];

    // Retry failed notifications (using queue)
    $retried = retryFailedNotifications();
    $stats['failed_notifications_retried'] = $retried;

    // Update search index (Meilisearch or SQLite FTS)
    $indexed = updateSearchIndex();
    $stats['search_indexed'] = $indexed;

    // Clean old session data
    $synced = syncSessionData();
    $stats['session_sync'] = $synced;

    // Send admin heartbeat (once per day)
    $heartbeatSent = sendAdminHeartbeat();
    $stats['heartbeat_sent'] = $heartbeatSent ? 1 : 0;

    $duration = round(microtime(true) - $startTime, 2);
    cron_log("45-MINUTE TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("45-Minute Tasks Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

// ==================== HELPER FUNCTIONS ====================

function retryFailedNotifications() {
    $db = getDB();
    $retried = 0;
    $stmt = $db->prepare("SELECT * FROM overdue_notifications WHERE status = 'failed' AND attempts < 3 ORDER BY created_at ASC LIMIT 20");
    $stmt->execute();
    foreach ($stmt->fetchAll() as $notif) {
        $loanStmt = $db->prepare("SELECT c.*, m.email, m.phone, m.name FROM circulation c JOIN members m ON c.admno = m.admno WHERE c.id = ?");
        $loanStmt->execute([$notif['circulation_id']]);
        $loanData = $loanStmt->fetch();
        if (!$loanData) continue;
        $fine = calculateFine($loanData['due_date'], $loanData['member_category']);
        $days = (new DateTime())->diff(new DateTime($loanData['due_date']))->days;
        if ($notif['notification_type'] === 'email' && !empty($loanData['email'])) {
            $subject = "Overdue Book Notice";
            $message = "Dear {$loanData['name']},\n\nThe book '{$loanData['title']}' is {$days} days overdue.\nFine: " . formatCurrency($fine) . "\nPlease return it.";
            queueEmail($loanData['email'], $subject, nl2br($message));
            $success = true;
        } else {
            $success = false;
        }
        $newStatus = $success ? 'sent' : 'failed';
        $attempts = (int)$notif['attempts'] + 1;
        $db->prepare("UPDATE overdue_notifications SET status = ?, attempts = ?, sent_at = CURRENT_TIMESTAMP WHERE id = ?")
           ->execute([$newStatus, $attempts, $notif['id']]);
        if ($success) $retried++;
        usleep(100000);
    }
    return $retried;
}

function updateSearchIndex() {
    $db = getDB();
    $settings = getSettings();
    $meiliUrl = $settings['meilisearch_url'] ?? '';
    $meiliKey = $settings['meilisearch_key'] ?? '';
    if (!empty($meiliUrl) && !empty($meiliKey) && function_exists('curl_init')) {
        $indexed = 0;
        $booksStmt = $db->prepare("SELECT id, barcode, title, author, subject, isbn, publisher, year, available FROM books WHERE updated_at > datetime('now', '-45 minutes') OR created_at > datetime('now', '-45 minutes') LIMIT 100");
        $booksStmt->execute();
        $books = $booksStmt->fetchAll();
        if (!empty($books)) {
            $ch = curl_init($meiliUrl . '/indexes/books/documents');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($books));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . $meiliKey]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch);
            curl_close($ch);
            $indexed += count($books);
        }
        $membersStmt = $db->prepare("SELECT id, admno, name, member_category, class, division FROM members WHERE updated_at > datetime('now', '-45 minutes') OR created_at > datetime('now', '-45 minutes') LIMIT 100");
        $membersStmt->execute();
        $members = $membersStmt->fetchAll();
        if (!empty($members)) {
            $ch = curl_init($meiliUrl . '/indexes/members/documents');
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($members));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . $meiliKey]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_exec($ch);
            curl_close($ch);
            $indexed += count($members);
        }
        return $indexed;
    } else {
        $db->exec("INSERT OR REPLACE INTO books_fts(books_fts) VALUES('rebuild')");
        $db->exec("INSERT OR REPLACE INTO members_fts(members_fts) VALUES('rebuild')");
        return 1;
    }
}

function syncSessionData() {
    $db = getDB();
    $deleted = $db->exec("DELETE FROM user_sessions WHERE last_activity < datetime('now', '-45 minutes')");
    return $deleted;
}

function sendAdminHeartbeat() {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    if (empty($adminEmail)) return false;
    $lastFile = __DIR__ . '/last_heartbeat.txt';
    $now = time();
    if (file_exists($lastFile) && ($now - filemtime($lastFile)) < 86400) return false;
    $subject = "Cron Heartbeat – Library ERP";
    $body = "The 45-minute cron job is running normally as of " . date('Y-m-d H:i:s');
    queueEmail($adminEmail, $subject, $body);
    file_put_contents($lastFile, $now);
    return true;
}

// Fallback functions (in case db.php doesn't have them)
if (!function_exists('formatCurrency')) {
    function formatCurrency($amount) { return '₹' . number_format($amount, 2); }
}
if (!function_exists('calculateFine')) {
    function calculateFine($dueDate, $category = null) {
        $days = max(0, (strtotime(date('Y-m-d')) - strtotime($dueDate)) / 86400);
        $rate = 2;
        if ($category === 'Staff') $rate = 5;
        return $days * $rate;
    }
}