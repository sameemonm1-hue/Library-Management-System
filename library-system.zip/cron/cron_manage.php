<!-- Add after the existing jobs -->
<tr>
    <td><code>fifteen_minute_tasks.php</code></td>
    <td>Process email, WhatsApp, SMS queues; send hold notifications</td>
    <td>Every 15 minutes</td>
    <td><?= getJobStatus('fifteen_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('15-MINUTE TASKS') ?></td>
    <td><a href="fifteen_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 15-min tasks?')">Run Now</a></td>
</tr>
<tr>
    <td><code>thirty_minute_tasks.php</code></td>
    <td>Sync visitor counts, expiring reservations, book cache, computer sessions</td>
    <td>Every 30 minutes</td>
    <td><?= getJobStatus('thirty_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('30-MINUTE TASKS') ?></td>
    <td><a href="thirty_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 30-min tasks?')">Run Now</a></td>
</tr>
<tr>
    <td><code>forty_five_minute_tasks.php</code></td>
    <td>Retry failed notifications, update search index, sync session data, admin heartbeat</td>
    <td>Every 45 minutes</td>
    <td><?= getJobStatus('forty_five_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('45-MINUTE TASKS') ?></td>
    <td><a href="forty_five_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 45-min tasks?')">Run Now</a></td>
</tr>