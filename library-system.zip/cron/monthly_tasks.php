#!/usr/bin/env php
<?php
/**
 * Monthly Cron Tasks
 * Runs on the 1st of each month at 2:00 AM
 * 
 * Tasks:
 * 1. Generate monthly reports
 * 2. Archive old logs
 * 3. Reset guest counters
 * 4. Send monthly summary to admin
 */

require_once __DIR__ . '/config.php';

$jobName = 'monthly_tasks';
if (!acquire_lock($jobName)) {
    exit(1);
}

try {
    cron_log("========== STARTING MONTHLY TASKS ==========");
    $startTime = microtime(true);
    $stats = [];
    
    // 1. Generate monthly reports
    cron_log("Generating monthly reports...");
    $monthlyReport = generateMonthlyReport();
    $stats['monthly_report'] = $monthlyReport;
    cron_log("Monthly report generated");
    
    // 2. Archive old logs
    cron_log("Archiving old logs...");
    $logsArchived = archiveOldLogs();
    $stats['logs_archived'] = $logsArchived;
    cron_log("Archived $logsArchived log files");
    
    // 3. Reset guest counters
    cron_log("Resetting guest counters...");
    resetGuestCounters();
    $stats['guest_counters_reset'] = true;
    cron_log("Guest counters reset");
    
    // 4. Clean up old session logs
    cron_log("Cleaning old session logs...");
    $sessionsCleaned = cleanupSessionLogs();
    $stats['sessions_cleaned'] = $sessionsCleaned;
    cron_log("Cleaned $sessionsCleaned old session records");
    
    // 5. Send monthly summary
    cron_log("Sending monthly summary...");
    sendMonthlySummary($stats);
    
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("MONTHLY TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("Monthly Tasks Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

/**
 * Generate monthly report
 */
function generateMonthlyReport() {
    $db = getDB();
    $monthStart = date('Y-m-01');
    $monthEnd = date('Y-m-t');
    $previousMonthStart = date('Y-m-01', strtotime('-1 month'));
    $previousMonthEnd = date('Y-m-t', strtotime('-1 month'));
    
    // Current month statistics
    $currentStats = [
        'new_members' => $db->query("SELECT COUNT(*) FROM members WHERE created_at >= '$monthStart'")->fetchColumn(),
        'books_issued' => $db->query("SELECT COUNT(*) FROM circulation WHERE issue_date >= '$monthStart'")->fetchColumn(),
        'books_returned' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date >= '$monthStart'")->fetchColumn(),
        'fines_collected' => $db->query("SELECT COALESCE(SUM(amount), 0) FROM fine_payments WHERE payment_date >= '$monthStart'")->fetchColumn(),
        'new_books' => $db->query("SELECT COUNT(*) FROM books WHERE created_at >= '$monthStart'")->fetchColumn(),
        'total_visitors' => $db->query("SELECT COUNT(*) FROM entry_exit WHERE entry_date >= '$monthStart'")->fetchColumn(),
        'ebook_downloads' => $db->query("SELECT COALESCE(SUM(downloads), 0) FROM ebooks WHERE created_at >= '$monthStart'")->fetchColumn(),
    ];
    
    // Previous month statistics
    $previousStats = [
        'new_members' => $db->query("SELECT COUNT(*) FROM members WHERE created_at BETWEEN '$previousMonthStart' AND '$previousMonthEnd'")->fetchColumn(),
        'books_issued' => $db->query("SELECT COUNT(*) FROM circulation WHERE issue_date BETWEEN '$previousMonthStart' AND '$previousMonthEnd'")->fetchColumn(),
    ];
    
    // Calculate growth percentages
    $memberGrowth = $previousStats['new_members'] > 0 
        ? round(($currentStats['new_members'] - $previousStats['new_members']) / $previousStats['new_members'] * 100, 1)
        : 100;
    $circulationGrowth = $previousStats['books_issued'] > 0
        ? round(($currentStats['books_issued'] - $previousStats['books_issued']) / $previousStats['books_issued'] * 100, 1)
        : 100;
    
    // Get top categories
    $topCategories = $db->query("
        SELECT category, COUNT(*) as count 
        FROM books 
        WHERE category IS NOT NULL AND category != ''
        GROUP BY category 
        ORDER BY count DESC 
        LIMIT 5
    ")->fetchAll();
    
    // Get most active members
    $activeMembers = $db->query("
        SELECT m.name, m.admno, COUNT(c.id) as issue_count
        FROM members m
        JOIN circulation c ON m.admno = c.admno
        WHERE c.issue_date >= '$monthStart'
        GROUP BY m.id
        ORDER BY issue_count DESC
        LIMIT 10
    ")->fetchAll();
    
    $reportData = [
        'month' => date('F Y'),
        'period' => "$monthStart to $monthEnd",
        'current_stats' => $currentStats,
        'previous_stats' => $previousStats,
        'growth' => [
            'member_growth' => $memberGrowth,
            'circulation_growth' => $circulationGrowth,
        ],
        'top_categories' => $topCategories,
        'active_members' => $activeMembers,
        'generated_at' => date('Y-m-d H:i:s'),
    ];
    
    // Save to database
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='monthly_reports'");
    if (!$tableCheck->fetch()) {
        $db->exec("CREATE TABLE IF NOT EXISTS monthly_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_month DATE NOT NULL,
            report_data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }
    
    $stmt = $db->prepare("INSERT INTO monthly_reports (report_month, report_data) VALUES (?, ?)");
    $stmt->execute([$monthStart, json_encode($reportData)]);
    
    // Save to file
    $reportFile = CRON_LOG_DIR . 'monthly_report_' . date('Y-m') . '.json';
    file_put_contents($reportFile, json_encode($reportData, JSON_PRETTY_PRINT));
    
    return 1;
}

/**
 * Archive old logs
 */
function archiveOldLogs() {
    $logDir = CRON_LOG_DIR;
    $archiveDir = $logDir . 'archive/';
    if (!is_dir($archiveDir)) mkdir($archiveDir, 0755, true);
    
    $archived = 0;
    $files = glob($logDir . 'cron_*.log');
    $cutoffDate = strtotime('-30 days');
    
    foreach ($files as $file) {
        if (filemtime($file) < $cutoffDate) {
            $archiveName = $archiveDir . basename($file) . '.gz';
            $content = file_get_contents($file);
            file_put_contents($archiveName, gzencode($content, 9));
            unlink($file);
            $archived++;
        }
    }
    
    return $archived;
}

/**
 * Reset guest counters
 */
function resetGuestCounters() {
    $db = getDB();
    $db->prepare("UPDATE settings SET guest_daily_counter = 1, guest_last_reset = date('now')")->execute();
    return true;
}

/**
 * Cleanup old session logs
 */
function cleanupSessionLogs() {
    $db = getDB();
    $deleted = 0;
    
    // Delete sessions older than 90 days
    $stmt = $db->prepare("DELETE FROM session_logs WHERE login_time < datetime('now', '-90 days')");
    $stmt->execute();
    $deleted += $stmt->rowCount();
    
    // Delete activity logs older than 180 days
    $stmt = $db->prepare("DELETE FROM activity_logs WHERE created_at < datetime('now', '-180 days')");
    $stmt->execute();
    $deleted += $stmt->rowCount();
    
    // Delete export logs older than 180 days
    $stmt = $db->prepare("DELETE FROM export_logs WHERE created_at < datetime('now', '-180 days')");
    $stmt->execute();
    $deleted += $stmt->rowCount();
    
    return $deleted;
}

/**
 * Send monthly summary to admin
 */
function sendMonthlySummary($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    
    if (empty($adminEmail)) return;
    
    $subject = "Monthly Library Report - " . date('F Y');
    $message = "
        <html>
        <body>
            <h3>Monthly Library Statistics</h3>
            <p><strong>Month:</strong> " . date('F Y') . "</p>
            <table border='1' cellpadding='5' cellspacing='0'>
                <tr><th>Metric</th><th>Value</th></tr>
                <tr><td>Monthly Report Generated</td><td>" . ($stats['monthly_report'] ? 'Yes' : 'No') . "</td></tr>
                <tr><td>Logs Archived</td><td>{$stats['logs_archived']}</td></tr>
                <tr><td>Guest Counters Reset</td><td>" . ($stats['guest_counters_reset'] ? 'Yes' : 'No') . "</td></tr>
                <tr><td>Session Logs Cleaned</td><td>{$stats['sessions_cleaned']}</td></tr>
            </table>
            <p><small>This is an automated monthly report from your Library System.</small></p>
        </body>
        </html>
    ";
    
    sendEmail($adminEmail, $subject, $message);
}
?>