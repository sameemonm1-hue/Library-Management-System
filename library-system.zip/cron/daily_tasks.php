#!/usr/bin/env php
<?php
/**
 * Daily Cron Tasks
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: This script should be run from CLI. Continuing for testing...\n";
}

require_once __DIR__ . '/config.php';

$jobName = 'daily_tasks';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("=== Daily tasks started ===");
    $db = getDB();
    if (!$db) throw new Exception("DB connection failed");
    $settings = getSettings();

    // Process email queue
    if (function_exists('processEmailQueue')) {
        $sent = processEmailQueue(50);
        cron_log("Email queue processed: $sent emails sent.");
    } else {
        cron_log("Warning: processEmailQueue() not found.");
    }

    // Overdue notifications (queue)
    if (!empty($settings['enable_email']) && !empty($settings['notify_overdue'])) {
        $overdueStmt = $db->prepare("
            SELECT c.*, m.email, m.name as member_name, b.title as book_title, b.barcode
            FROM circulation c
            JOIN members m ON c.admno = m.admno
            JOIN books b ON c.barcode = b.barcode
            WHERE c.return_date IS NULL AND c.due_date < date('now')
            AND c.id NOT IN (SELECT circulation_id FROM overdue_notifications WHERE notification_type='email' AND date(sent_at)=date('now'))
            LIMIT 100
        ");
        $overdueStmt->execute();
        $overdueLoans = $overdueStmt->fetchAll();
        $overdueCount = 0;
        foreach ($overdueLoans as $loan) {
            $days = (new DateTime())->diff(new DateTime($loan['due_date']))->days;
            $fine = calculateFine($loan['due_date'], null, $loan['member_category']);
            $subject = "Overdue Book Notice";
            $message = "Dear {$loan['member_name']},\n\nThe book '{$loan['book_title']}' is overdue by $days days.\nFine: " . formatCurrency($fine) . "\nPlease return.";
            if (function_exists('queueEmail')) {
                queueEmail($loan['email'], $subject, nl2br($message));
                $db->prepare("INSERT INTO overdue_notifications (circulation_id, admno, notification_type, days_overdue, status) VALUES (?,?,'email',?,'queued')")
                   ->execute([$loan['id'], $loan['admno'], $days]);
                $overdueCount++;
            }
        }
        cron_log("Overdue notifications queued: $overdueCount");
    }

    // Membership expiry reminders
    if (!empty($settings['enable_email']) && !empty($settings['enable_member_notifications'])) {
        $reminderCount = 0;
        foreach ([7, 1, 0] as $daysBefore) {
            $expiryDate = date('Y-m-d', strtotime("+$daysBefore days"));
            $stmt = $db->prepare("SELECT admno, name, email FROM members WHERE status='active' AND membership_expiry=?");
            $stmt->execute([$expiryDate]);
            foreach ($stmt->fetchAll() as $member) {
                $subject = $daysBefore == 0 ? "Membership Expired" : "Membership Expiry Reminder";
                $message = $daysBefore == 0 ? "Your membership expired today." : "Your membership expires on $expiryDate. Please renew.";
                if (function_exists('queueEmail')) {
                    queueEmail($member['email'], $subject, nl2br($message));
                    $reminderCount++;
                }
            }
        }
        cron_log("Membership expiry reminders queued: $reminderCount");
    }

    // Clean old logs
    $retentionDays = (int)($settings['audit_log_retention_days'] ?? 90);
    $db->prepare("DELETE FROM notification_logs WHERE created_at < datetime('now', '-$retentionDays days')")->execute();
    $db->prepare("DELETE FROM overdue_notifications WHERE sent_at < datetime('now', '-$retentionDays days')")->execute();
    cron_log("Cleaned logs older than $retentionDays days.");
    cron_log("=== Daily tasks completed ===");

} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}