<?php
/**
 * Cron Manager - Web Interface
 * Access: http://localhost/library-system/cron/cron_manager.php
 * Requires admin login
 */

session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';

// Check admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$db = getDB();
$settings = getSettings();

// Get last execution times from logs
function getLastExecutionTime($jobName) {
    $logFile = __DIR__ . '/logs/cron_' . date('Y-m-d') . '.log';
    if (!file_exists($logFile)) return 'Never';
    
    $logs = file($logFile);
    $logs = array_reverse($logs);
    
    foreach ($logs as $log) {
        if (strpos($log, $jobName) !== false && strpos($log, 'STARTING') !== false) {
            preg_match('/\[(.*?)\]/', $log, $matches);
            return isset($matches[1]) ? $matches[1] : 'Unknown';
        }
    }
    return 'Never';
}

// Get job status
function getJobStatus($jobName) {
    $lockFile = __DIR__ . '/locks/' . $jobName . '.lock';
    if (file_exists($lockFile)) {
        $lockTime = (int)file_get_contents($lockFile);
        if (time() - $lockTime < 300) {
            return '<span class="badge bg-warning">Running</span>';
        }
    }
    return '<span class="badge bg-success">Ready</span>';
}

renderHeader('Cron Jobs Manager');
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-3 mb-4">
        <h2><i class="fas fa-clock"></i> Cron Jobs Manager</h2>
        <div>
            <a href="../index.php" class="btn btn-primary">Back to Home</a>
            <a href="?refresh=1" class="btn btn-info"><i class="fas fa-sync-alt"></i> Refresh</a>
        </div>
    </div>

    <!-- Setup Instructions -->
    <div class="alert alert-info">
        <h5><i class="fas fa-info-circle"></i> Cron Job Setup</h5>
        <p>Add these lines to your server's crontab (Linux/Ubuntu):</p>
        <pre class="bg-dark text-light p-3 rounded"><code># Library ERP System Cron Jobs

# Daily at 9:00 AM
0 9 * * * php <?= __DIR__ ?>/daily_tasks.php

# Hourly
0 * * * * php <?= __DIR__ ?>/hourly_tasks.php

# Weekly on Monday at 1:00 AM
0 1 * * 1 php <?= __DIR__ ?>/weekly_tasks.php

# Monthly on 1st at 2:00 AM
0 2 1 * * php <?= __DIR__ ?>/monthly_tasks.php

# Overdue reminders at 8:00 AM
0 8 * * * php <?= __DIR__ ?>/send_overdue_reminders.php

# Serial issues at 3:00 AM
0 3 * * * php <?= __DIR__ ?>/process_serial_issues.php</code></pre>
        
        <p class="mt-2"><strong>For Windows Task Scheduler:</strong> Create tasks for each PHP script.</p>
    </div>

    <!-- System Health -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Cron Directory</h5>
                    <p class="mb-0"><?= __DIR__ ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5>Last Daily Run</h5>
                    <p class="mb-0"><?= getLastExecutionTime('DAILY TASKS') ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5>Log Directory</h5>
                    <p class="mb-0"><?= __DIR__ ?>/logs/</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5>PHP Version</h5>
                    <p class="mb-0"><?= phpversion() ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Jobs Table -->
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="fas fa-tasks"></i> Available Cron Jobs</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Job Name</th>
                            <th>Description</th>
                            <th>Schedule</th>
                            <th>Status</th>
                            <th>Last Run</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>daily_tasks.php</code></td>
                            <td>Daily operations (overdue, membership, stats)</td>
                            <td>Daily at 9:00 AM</td>
                            <td><?= getJobStatus('daily_tasks') ?></td>
                            <td><?= getLastExecutionTime('DAILY TASKS') ?></td>
                            <td><a href="daily_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run daily tasks?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>hourly_tasks.php</code></td>
                            <td>Hourly operations (email queue, sessions)</td>
                            <td>Every hour</td>
                            <td><?= getJobStatus('hourly_tasks') ?></td>
                            <td><?= getLastExecutionTime('HOURLY TASKS') ?></td>
                            <td><a href="hourly_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run hourly tasks?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>weekly_tasks.php</code></td>
                            <td>Weekly operations (backups, reports)</td>
                            <td>Monday at 1:00 AM</td>
                            <td><?= getJobStatus('weekly_tasks') ?></td>
                            <td><?= getLastExecutionTime('WEEKLY TASKS') ?></td>
                            <td><a href="weekly_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run weekly tasks?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>monthly_tasks.php</code></td>
                            <td>Monthly operations (archive, reports)</td>
                            <td>1st at 2:00 AM</td>
                            <td><?= getJobStatus('monthly_tasks') ?></td>
                            <td><?= getLastExecutionTime('MONTHLY TASKS') ?></td>
                            <td><a href="monthly_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run monthly tasks?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>send_overdue_reminders.php</code></td>
                            <td>Send overdue notifications</td>
                            <td>Daily at 8:00 AM</td>
                            <td><?= getJobStatus('send_overdue_reminders') ?></td>
                            <td><?= getLastExecutionTime('OVERDUE REMINDERS') ?></td>
                            <td><a href="send_overdue_reminders.php" class="btn btn-sm btn-danger" onclick="return confirm('Send overdue reminders now?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>process_serial_issues.php</code></td>
                            <td>Generate serial issues</td>
                            <td>Daily at 3:00 AM</td>
                            <td><?= getJobStatus('process_serial_issues') ?></td>
                            <td><?= getLastExecutionTime('SERIAL ISSUES') ?></td>
                            <td><a href="process_serial_issues.php" class="btn btn-sm btn-primary" onclick="return confirm('Generate serial issues?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>backup_rotation.php</code></td>
                            <td>Rotate and cleanup backups</td>
                            <td>Sunday at 4:00 AM</td>
                            <td><?= getJobStatus('backup_rotation') ?></td>
                            <td><?= getLastExecutionTime('BACKUP ROTATION') ?></td>
                            <td><a href="backup_rotation.php" class="btn btn-sm btn-warning" onclick="return confirm('Run backup rotation?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>sync_google_drive.php</code></td>
                            <td>Sync backups to Google Drive</td>
                            <td>Sunday at 3:00 AM</td>
                            <td><?= getJobStatus('sync_google_drive') ?></td>
                            <td><?= getLastExecutionTime('GOOGLE DRIVE SYNC') ?></td>
                            <td><a href="sync_google_drive.php" class="btn btn-sm btn-info" onclick="return confirm('Sync to Google Drive?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>process_email_queue.php</code></td>
                            <td>Process pending emails</td>
                            <td>Every 15 minutes</td>
                            <td><?= getJobStatus('process_email_queue') ?></td>
                            <td><?= getLastExecutionTime('EMAIL QUEUE') ?></td>
                            <td><a href="process_email_queue.php" class="btn btn-sm btn-primary" onclick="return confirm('Process email queue?')">Run Now</a></td>
                        </tr>
                        <tr>
                            <td><code>send_membership_reminders.php</code></td>
                            <td>Send membership expiry reminders</td>
                            <td>Daily at 10:00 AM</td>
                            <td><?= getJobStatus('send_membership_reminders') ?></td>
                            <td><?= getLastExecutionTime('MEMBERSHIP REMINDERS') ?></td>
                            <td><a href="send_membership_reminders.php" class="btn btn-sm btn-primary" onclick="return confirm('Send membership reminders?')">Run Now</a></td>
                        </tr>
<tr>
    <td><code>fifteen_minute_tasks.php</code></td>
    <td>Process email, WhatsApp, SMS queues; send hold notifications</td>
    <td>Every 15 minutes</td>
    <td><?= getJobStatus('fifteen_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('15-MINUTE TASKS') ?></td>
    <td><a href="fifteen_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 15-min tasks?')">Run Now</a></td>
</tr>
<tr>
    <td><code>thirty_minute_tasks.php</code></td>
    <td>Sync visitor counts, expiring reservations, book cache, computer sessions</td>
    <td>Every 30 minutes</td>
    <td><?= getJobStatus('thirty_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('30-MINUTE TASKS') ?></td>
    <td><a href="thirty_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 30-min tasks?')">Run Now</a></td>
</tr>
<tr>
    <td><code>forty_five_minute_tasks.php</code></td>
    <td>Retry failed notifications, update search index, sync session data, admin heartbeat</td>
    <td>Every 45 minutes</td>
    <td><?= getJobStatus('forty_five_minute_tasks') ?></td>
    <td><?= getLastExecutionTime('45-MINUTE TASKS') ?></td>
    <td><a href="forty_five_minute_tasks.php" class="btn btn-sm btn-primary" onclick="return confirm('Run 45-min tasks?')">Run Now</a></td>
</tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Log Viewer -->
    <div class="card mt-4">
        <div class="card-header bg-secondary text-white">
            <h5 class="mb-0"><i class="fas fa-history"></i> Recent Logs</h5>
        </div>
        <div class="card-body">
            <div class="mb-2">
                <select id="logSelector" class="form-select w-auto d-inline-block">
                    <?php
                    $logFiles = glob(__DIR__ . '/logs/cron_*.log');
                    rsort($logFiles);
                    foreach ($logFiles as $file): ?>
                        <option value="<?= basename($file) ?>"><?= basename($file) ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn btn-sm btn-primary" onclick="loadLog()"><i class="fas fa-eye"></i> View Log</button>
            </div>
            <pre id="logContent" style="max-height: 400px; overflow-y: auto; background: #f8f9fa; padding: 10px; border-radius: 5px; font-size: 12px;">Select a log file to view</pre>
        </div>
    </div>
</div>

<script>
function loadLog() {
    const logFile = document.getElementById('logSelector').value;
    fetch('?view_log=' + logFile)
        .then(response => response.text())
        .then(data => {
            document.getElementById('logContent').innerText = data;
        })
        .catch(err => {
            document.getElementById('logContent').innerText = 'Error loading log: ' + err;
        });
}

// Auto-refresh every 30 seconds
setInterval(function() {
    location.reload();
}, 30000);
</script>

<?php
// Handle log viewing
if (isset($_GET['view_log'])) {
    $logFile = basename($_GET['view_log']);
    $logPath = __DIR__ . '/logs/' . $logFile;
    if (file_exists($logPath)) {
        header('Content-Type: text/plain');
        echo file_get_contents($logPath);
    } else {
        echo "Log file not found.";
    }
    exit;
}

renderFooter();
?>