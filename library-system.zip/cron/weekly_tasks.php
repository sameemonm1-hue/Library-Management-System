#!/usr/bin/env php
<?php
/**
 * Weekly Cron Tasks
 * Runs every Monday at 1:00 AM
 * 
 * Tasks:
 * 1. Backup rotation and cleanup
 * 2. Generate weekly reports
 * 3. Sync with Google Drive
 * 4. Cleanup temporary files
 * 5. Send weekly summary to admin
 */

require_once __DIR__ . '/config.php';

$jobName = 'weekly_tasks';
if (!acquire_lock($jobName)) {
    exit(1);
}

try {
    cron_log("========== STARTING WEEKLY TASKS ==========");
    $startTime = microtime(true);
    $stats = [];
    
    // 1. Backup rotation and cleanup
    cron_log("Running backup rotation...");
    $backupsRemoved = rotateBackups();
    $stats['backups_removed'] = $backupsRemoved;
    cron_log("Removed $backupsRemoved old backups");
    
    // 2. Generate weekly reports
    cron_log("Generating weekly reports...");
    $reportsGenerated = generateWeeklyReports();
    $stats['reports_generated'] = $reportsGenerated;
    cron_log("Generated $reportsGenerated weekly reports");
    
    // 3. Sync with Google Drive
    cron_log("Syncing with Google Drive...");
    $googleDriveStatus = syncGoogleDrive();
    $stats['google_drive_sync'] = $googleDriveStatus;
    cron_log("Google Drive sync: $googleDriveStatus");
    
    // 4. Cleanup temporary files
    cron_log("Cleaning temporary files...");
    $tempFilesCleaned = cleanupTempFiles();
    $stats['temp_files_cleaned'] = $tempFilesCleaned;
    cron_log("Cleaned $tempFilesCleaned temporary files");
    
    // 5. Optimize database
    cron_log("Optimizing database...");
    optimizeDatabase();
    $stats['db_optimized'] = true;
    cron_log("Database optimized");
    
    // 6. Send weekly summary
    cron_log("Sending weekly summary...");
    sendWeeklySummary($stats);
    
    $duration = round(microtime(true) - $startTime, 2);
    cron_log("WEEKLY TASKS COMPLETED in {$duration}s");
    cron_log("Stats: " . json_encode($stats));
    
} catch (Exception $e) {
    cron_log("ERROR: " . $e->getMessage(), "ERROR");
    notify_admin("Weekly Tasks Failed", $e->getMessage(), 'error');
} finally {
    release_lock($jobName);
}

/**
 * Rotate and cleanup old backups
 */
function rotateBackups() {
    $db = getDB();
    $settings = getSettings();
    $keepDays = (int)($settings['google_drive_auto_delete_days'] ?? 30);
    $backupDir = BACKUP_DIR;
    $removed = 0;
    
    if (!is_dir($backupDir)) return 0;
    
    $files = glob($backupDir . 'library_backup_*.zip');
    $cutoffTime = strtotime("-$keepDays days");
    
    foreach ($files as $file) {
        if (filemtime($file) < $cutoffTime) {
            unlink($file);
            $removed++;
        }
    }
    
    // Keep at least 3 recent backups regardless of age
    $files = glob($backupDir . 'library_backup_*.zip');
    usort($files, function($a, $b) {
        return filemtime($b) - filemtime($a);
    });
    
    if (count($files) > 5) {
        $oldFiles = array_slice($files, 5);
        foreach ($oldFiles as $file) {
            unlink($file);
            $removed++;
        }
    }
    
    return $removed;
}

/**
 * Generate weekly reports
 */
function generateWeeklyReports() {
    $db = getDB();
    $settings = getSettings();
    $generated = 0;
    $weekStart = date('Y-m-d', strtotime('last monday'));
    $weekEnd = date('Y-m-d');
    
    // Get weekly statistics
    $stats = [
        'new_members' => $db->query("SELECT COUNT(*) FROM members WHERE created_at >= '$weekStart'")->fetchColumn(),
        'books_issued' => $db->query("SELECT COUNT(*) FROM circulation WHERE issue_date >= '$weekStart'")->fetchColumn(),
        'books_returned' => $db->query("SELECT COUNT(*) FROM circulation WHERE return_date >= '$weekStart'")->fetchColumn(),
        'fines_collected' => $db->query("SELECT COALESCE(SUM(amount), 0) FROM fine_payments WHERE payment_date >= '$weekStart'")->fetchColumn(),
        'new_books' => $db->query("SELECT COUNT(*) FROM books WHERE created_at >= '$weekStart'")->fetchColumn(),
        'active_members' => $db->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn(),
        'total_books' => $db->query("SELECT SUM(quantity) FROM books")->fetchColumn(),
    ];
    
    // Get top borrowed books
    $topBooks = $db->query("
        SELECT b.title, b.author, COUNT(c.id) as borrow_count
        FROM circulation c
        JOIN books b ON c.barcode = b.barcode
        WHERE c.issue_date >= '$weekStart'
        GROUP BY b.id
        ORDER BY borrow_count DESC
        LIMIT 10
    ")->fetchAll();
    
    // Get overdue statistics
    $overdueCount = $db->query("
        SELECT COUNT(*) FROM circulation 
        WHERE return_date IS NULL AND due_date < date('now')
    ")->fetchColumn();
    
    // Save report to database or file
    $reportData = [
        'date' => date('Y-m-d H:i:s'),
        'period' => "$weekStart to $weekEnd",
        'statistics' => $stats,
        'top_books' => $topBooks,
        'overdue_count' => $overdueCount,
    ];
    
    $reportFile = CRON_LOG_DIR . 'weekly_report_' . date('Y-m-d') . '.json';
    file_put_contents($reportFile, json_encode($reportData, JSON_PRETTY_PRINT));
    
    // Also save to database if table exists
    $tableCheck = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='weekly_reports'");
    if (!$tableCheck->fetch()) {
        $db->exec("CREATE TABLE IF NOT EXISTS weekly_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_date DATE NOT NULL,
            week_start DATE NOT NULL,
            week_end DATE NOT NULL,
            report_data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");
    }
    
    $stmt = $db->prepare("
        INSERT INTO weekly_reports (report_date, week_start, week_end, report_data)
        VALUES (date('now'), ?, ?, ?)
    ");
    $stmt->execute([$weekStart, $weekEnd, json_encode($reportData)]);
    
    return 1;
}

/**
 * Sync with Google Drive
 */
function syncGoogleDrive() {
    $settings = getSettings();
    
    if (empty($settings['google_drive_enabled'])) {
        return "Google Drive backup is disabled";
    }
    
    if (!function_exists('uploadToGoogleDriveSafe')) {
        return "Google Drive function not available";
    }
    
    // Create a fresh backup
    $backupFile = createBackupFile();
    if (!$backupFile) {
        return "Failed to create backup file";
    }
    
    // Upload to Google Drive
    $result = uploadToGoogleDriveSafe($backupFile, $settings);
    
    if ($result === true) {
        unlink($backupFile);
        return "Backup uploaded successfully";
    }
    
    return "Upload failed: $result";
}

/**
 * Cleanup temporary files
 */
function cleanupTempFiles() {
    $tempDir = sys_get_temp_dir();
    $pattern = $tempDir . '/report_*';
    $files = glob($pattern);
    $removed = 0;
    $cutoffTime = time() - 3600; // 1 hour old
    
    foreach ($files as $file) {
        if (is_file($file) && filemtime($file) < $cutoffTime) {
            unlink($file);
            $removed++;
        }
    }
    
    // Clean up export logs older than 90 days
    $db = getDB();
    $db->exec("DELETE FROM export_logs WHERE created_at < datetime('now', '-90 days')");
    
    // Clean up notification logs older than 30 days
    $db->exec("DELETE FROM notification_logs WHERE created_at < datetime('now', '-30 days')");
    
    return $removed;
}

/**
 * Optimize database
 */
function optimizeDatabase() {
    $db = getDB();
    $db->exec("VACUUM");
    $db->exec("ANALYZE");
    return true;
}

/**
 * Send weekly summary to admin
 */
function sendWeeklySummary($stats) {
    $settings = getSettings();
    $adminEmail = $settings['backup_email'] ?? '';
    
    if (empty($adminEmail)) return;
    
    $subject = "Weekly Library Report - " . date('Y-m-d');
    $message = "
        <html>
        <body>
            <h3>Weekly Library Statistics</h3>
            <p><strong>Week:</strong> " . date('Y-m-d', strtotime('last monday')) . " to " . date('Y-m-d') . "</p>
            <table border='1' cellpadding='5' cellspacing='0'>
                <tr><th>Metric</th><th>Value</th></tr>
                <tr><td>Backups Removed</td><td>{$stats['backups_removed']}</td></tr>
                <tr><td>Reports Generated</td><td>{$stats['reports_generated']}</td></tr>
                <tr><td>Google Drive Sync</td><td>{$stats['google_drive_sync']}</td></tr>
                <tr><td>Temp Files Cleaned</td><td>{$stats['temp_files_cleaned']}</td></tr>
                <tr><td>Database Optimized</td><td>" . ($stats['db_optimized'] ? 'Yes' : 'No') . "</td></tr>
            </table>
            <p><small>This is an automated weekly report from your Library System.</small></p>
        </body>
        </html>
    ";
    
    sendEmail($adminEmail, $subject, $message);
}
?>