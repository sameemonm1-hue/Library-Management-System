#!/usr/bin/env php
<?php
/**
 * Daily Fine Calculation
 */

if (php_sapi_name() !== 'cli') {
    echo "WARNING: CLI only. Continuing for testing...\n";
}

date_default_timezone_set('Asia/Kolkata');
require_once __DIR__ . '/config.php';

$jobName = 'daily_fines';
if (!acquire_lock($jobName)) exit(1);

try {
    cron_log("=== Starting daily fine calculation ===");
    $db = getDB();
    if (!$db) throw new Exception("DB connection failed");
    $db->beginTransaction();

    $sql = "SELECT c.id as circulation_id, c.admno, c.due_date, c.issue_date,
                   m.id as member_id, m.total_fines as current_fines, m.member_category,
                   b.item_category, b.title
            FROM circulation c
            JOIN members m ON c.admno = m.admno
            JOIN books b ON c.barcode = b.barcode
            WHERE c.return_date IS NULL AND c.due_date < DATE('now')
            ORDER BY c.due_date ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $overdueLoans = $stmt->fetchAll();
    cron_log("Found " . count($overdueLoans) . " overdue loans.");

    $totalFinesSum = 0;
    $chargesInserted = 0;
    $settings = getSettings();

    foreach ($overdueLoans as $loan) {
        $rule = getLoanRule($loan['member_category'], $loan['item_category']);
        $finePerDay = $rule['fine_per_day'] ?? ($settings['fine_per_day'] ?? 2);
        $gracePeriod = $rule['grace_period'] ?? ($settings['fine_grace_period'] ?? 0);
        $dueDate = new DateTime($loan['due_date']);
        $today = new DateTime();
        $daysOverdue = $today->diff($dueDate)->days;
        $chargeableDays = max(0, $daysOverdue - $gracePeriod);
        $fineAmount = $chargeableDays * $finePerDay;
        $maxFine = (float)($settings['max_fine_amount'] ?? 0);
        if ($maxFine > 0 && ($loan['current_fines'] + $fineAmount) > $maxFine) {
            $fineAmount = max(0, $maxFine - $loan['current_fines']);
        }
        if ($fineAmount <= 0) continue;

        $check = $db->prepare("SELECT id FROM fine_charges WHERE circulation_id = ? AND charge_date = DATE('now')");
        $check->execute([$loan['circulation_id']]);
        if ($check->fetch()) continue;

        $db->prepare("INSERT INTO fine_charges (circulation_id, member_id, member_admno, amount, days_overdue, charge_date, status) VALUES (?, ?, ?, ?, ?, DATE('now'), 'pending')")
           ->execute([$loan['circulation_id'], $loan['member_id'], $loan['admno'], $fineAmount, $daysOverdue]);
        $db->prepare("UPDATE members SET total_fines = total_fines + ? WHERE id = ?")->execute([$fineAmount, $loan['member_id']]);
        $totalFinesSum += $fineAmount;
        $chargesInserted++;
        cron_log("Added fine {$fineAmount} for member {$loan['admno']} ({$daysOverdue} days overdue)");
    }
    $db->commit();
    cron_log("Fine calculation completed. Total fines added: " . number_format($totalFinesSum, 2) . " | Charges: $chargesInserted");

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    cron_log("ERROR: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine(), "ERROR");
    echo "ERROR: " . $e->getMessage() . PHP_EOL;
    exit(1);
} finally {
    release_lock($jobName);
}